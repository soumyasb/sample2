import axios from "axios";

//NEWSITEMS ACTIONS
export const getNewsItemPage = data => ({
  type: "GET_NEWSITEMS",
  data: data
});

export const initNewsItemPage = () => {
  return dispatch => {
      axios.get("http://localhost:32610/api/NewsItems", {crossDomain: true}).then(response => {
        dispatch(getNewsItemPage(response.data));
        console.log ("data from get news items api");
        console.log(response.data);
      }).catch((error) => {
        console.log(error);
      });
    
    ;
     
  };
};

export const getCreateNewsItemObj = data => ({
  type: "GET_CREATENEWSITEM",
  data: data
});

export const initCreateNewsItemObj = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/NewsItems/CreateNewsItem").then(response => {
      dispatch(getCreateNewsItemObj(response.data));
      console.log ("data from get create news items api");
      console.log(response.data);
    }).catch((error) => {
      console.log(error);
    });
  };
};

export const getEditNewsItemObj = data => ({
  type: "GET_EDITNEWSITEM",
  data: data
});

export const initEditNewsItemObj = (newsId) => {
  console.log("edit api getting called");
  return dispatch => {
    axios.get("http://localhost:32610/api/NewsItems/EditNewsItem/"+newsId).then(response => {
      dispatch(getEditNewsItemObj(response.data));
      console.log ("data from get edit news items api");
      console.log(response.data);
    }).catch((error) => {
      console.log(error);
    });
  };
};

export const getNewsItemDetailsObj = data => ({
  type: "GET_NEWSITEMDETAILS",
  data: data
});

// export const startGettingDetailsData = () => ({
//   type: "START_GET_DETAILSDATA"
// });

export const initNewsItemDetails = (newsId) => {
  
  return dispatch => {
   // dispatch(startGettingDetailsData());
    axios.get("http://localhost:32610/api/NewsItems/GetNewsItemDetails/"+newsId).then(response => {
      dispatch(getNewsItemDetailsObj(response.data));
      console.log ("data from get news items details api");
      console.log(response.data);
    }).catch((error) => {
      console.log(error);
    });
   // dispatch((newsItemDetailsData));
};
  };

  export const getSaveNewsItemStatus = data => ({
    type: "GET_SAVENEWSITEM",
    data: data
  });
  
  export const initSaveNewsItem = (newsItem) => {
    return dispatch => {
      axios.post("http://localhost:32610/api/NewsItems/AddNewsItem",newsItem).then(response => {
        console.log(response);
    }).catch((error) => {
      console.log(error);
    });
 
      //dispatch(getSaveNewsItemStatus(createNewsItemData));
  };
  };

  export const getModifyNewsItemStatus = data => ({
    //save operation
  });
  
  export const initModifyNewsItem = (newsItem) => {
    return dispatch => {
      axios.post("http://localhost:32610/api/NewsItems/ModifyNewsItem",newsItem).then(response => {
        console.log(response);
        if(response.status === 201)
        {
          dispatch(initNewsItemPage());
        }
    }).catch((error) => {
      console.log(error);
    });

      //dispatch(getModifyNewsItemStatus(newsItem));
  };
  };

  export const getDeleteNewsItemStatus = data => ({
    type: "GET_DELETETENEWSITEM",
    data: data
  });
  
  export const initDeleteNewsItem = (newsId) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/NewsItems/DeleteNewsItem/"+newsId).then(response => {
        console.log(response);
    }).catch((error) => {
      console.log(error);
    });
  };
  };

  export const getOfficeDetailsData = data => ({
    type: "GET_OFFICEDETAILS",
    data: data
  });
  
  export const initGetOfficeDetails = (empId, empType) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/NewsItems/GetUserOffices/"+empId+"/"+empType).then(response => {
        dispatch(getOfficeDetailsData(response.data));
        console.log ("data from get news items details api");
        console.log(response.data);
     // dispatch(getOfficeDetailsData(officeDetailsData));
  }).catch((error) => {
    console.log(error);
  });
};
  };