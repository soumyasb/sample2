import React, { Component } from "react";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { initNewsItemPage, initCreateNewsItemObj, initEditNewsItemObj, initGetOfficeDetails, initNewsItemDetails, 
    initDeleteNewsItem, initModifyNewsItem,initSaveNewsItem } from "../../../store/actions/newsItemActions";
import { Table, Button, Icon, Divider } from 'antd';
import { showModal } from "../../../store/actions/uiActions";
import moment from "moment";
import NewsModal from './NewsModal';

class NewsItem extends React.Component {

    constructor(props) {
        super(props);
        this.columns = [
            {
                title: 'Author Name',
                dataIndex: 'authorName',
                width: '6%',
                key: 'authorName'
                
            },
            {
                title: 'Priority',
                dataIndex: 'priority',
                width: '6%',
                key: 'priority',
                render: (priority) =>
                {
                    if(priority === "A")
                    {
                        return <p> Urgent </p>
                    }
                    if(priority === "B")
                    {
                        return <p> Normal </p>
                    }
                    if(priority === "C")
                    {
                        return <p> Low </p>
                    }
                }

            },
            {
                title: 'Subject',
                dataIndex: 'subject',
                width: '10%',
                key: 'subject'
            },
            {
                title: 'News Text',
                dataIndex: 'newsText',
                width: '42%',
                key: 'newsText',
                className: 'newsItemsPage-newsText',
                render: (newsText) => 
                {
                    return <div style={{wordBreak: "keep-all"}}><p>{newsText}</p></div>
                }

            },
            {
                title: 'Create Date',
                dataIndex: 'createDate',
                width: '8%',
                key: 'createDate',
                render: (createDate) =>
                    moment(createDate).format("MM/DD/YYYY")
            },
            {
                title: 'Start Date',
                dataIndex: 'startDate',
                width: '8%',
                key: 'startDate',
                render: (startDate) =>
                    moment(startDate).format("MM/DD/YYYY")
            },
            {
                title: 'End Date',
                dataIndex: 'endDate',
                width: '8%',
                key: 'endDate',
                render: (endDate) =>
                moment(endDate).format("MM/DD/YYYY")
            },
            {
                width: '8%',
                render: (item) => {
                    return (
                        <div style={{textAlign: "center"}}>
                             <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.newsId)} />
                             <Divider type="vertical" />
                             <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.newsId)} />
                             <Divider type="vertical" />
                             <Icon type="profile" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'details', item.newsId)} />
                        </div>
                    );
                },
            },
        ];

        this.state = {            
            //list: this.props.newsItem.list,
            newsItemObject: this.props.newsItem.newsItemObj,
            actionType: 'create',
            showModal: false,
            officeDetailsObj: this.props.newsItem.officeDetailsObj
          
        }

        this.showModal = this.showModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
    }

    componentWillMount() {
        this.props.initNewsItemPage();
        this.props.initCreateNewsItemObj();
       this.props.initGetOfficeDetails(220, 'R');
    //    debugger;
    //    this.props.initGetOfficeDetails(this.props.homePage.empID, this.props.homePage.empType);
    }
    componentWillReceiveProps(nextProps) {
        debugger;
        // if (this.props.newsItem.list !== nextProps.newsItem.list) {
        //     this.setState({ list: nextProps.newsItem.list });
        // } 
        if (this.props.newsItem.newsItemObj !== nextProps.newsItem.newsItemObj) {
            this.setState({ newsItemObject: nextProps.newsItem.newsItemObj });
        } 
        if (this.props.newsItem.officeDetailsObj !== nextProps.newsItem.officeDetailsObj) {
            this.setState({ officeDetailsObj: nextProps.newsItem.officeDetailsObj });
        } 
       
       
    //     // if (this.props.newsItem.editnewsItemObj !== nextProps.newsItem.editnewsItemObj) {
    //     //     this.setState({ newsItemObject: nextProps.newsItem.editnewsItemObj });
    //     // } 
    //     // if (this.props.newsItem.newsItemDetails !== nextProps.newsItem.newsItemDetails) {
    //     //     this.setState({ newsItemObject: nextProps.newsItem.newsItemDetails });
    //     //     debugger;
    //     // }
    }

    showModal(e, actype, newsId) {
        if (actype !== 'create') {
            if(newsId)
        {
            if(actype === 'edit') {
                debugger;
        this.props.initEditNewsItemObj(newsId);  
        // debugger;
        //     const newsItemObj = this.props.newsItem.editnewsItemObj;
        //     this.setState({ newsItemObj: newsItemObj }); 
        }
        if(actype === 'details') {
            this.props.initNewsItemDetails(newsId);     
            // debugger;
            //     const newsItemObj = this.props.newsItem.editnewsItemObj;
            //     this.setState({ newsItemObj: newsItemObj }); 
            }
            if(actype === 'delete') {
                this.props.initNewsItemDetails(newsId);     
                // debugger;
                //     const newsItemObj = this.props.newsItem.editnewsItemObj;
                //     this.setState({ newsItemObj: newsItemObj }); 
                }
    }
}
    
        else
        {
            this.props.initCreateNewsItemObj();
            debugger;
            if(this.state.newsItemObject !== undefined && this.state.newsItemObject.officeGroup === null)
            {           
                let newsItemObjectCopy = JSON.parse(JSON.stringify(this.state.newsItemObject));
                //make changes to ingredients
                newsItemObjectCopy.officeGroup = [];
                this.setState({
                    newsItemObject:newsItemObjectCopy 
                 });                     
            }
        }
        this.setState({ actionType: actype, showModal: true });
    }


    handleOk(e) {
        debugger;
        if(this.state.actionType === 'delete')
        {
            this.props.initDeleteNewsItem(this.state.newsItemObject.newsId);
            //this.props.initNewsItemPage();
        }
        if(this.state.actionType === 'edit')
        {
            this.props.initModifyNewsItem(this.state.newsItemObject);
        }
        if(this.state.actionType === 'create')
        {
            this.props.initSaveNewsItem(this.state.newsItemObject);
        }
            //this.modifyNewsItem(this.props.newsItem.newsItemObj);
            this.setState({ showModal: false });
        }

    handleCancel(e) {
        console.log("Canceled from news modal");
        this.setState({ showModal: false });
    }

    render() {      
      
        const columns = this.columns.map((col) => {
            return {
                ...col,
                onCell: record => ({
                    record,
                    title: col.title
                }),
            };
        });

        return (
            <ScrollPanel
                style={{
                    width: "100%",
                    height: "calc(100% - 40px)",
                    backgroundColor: "rgba(0,0,0,0)"
                }}
            >
               <div>
{this.props.newsItem.list !==undefined ||this.props.newsItem.list !== null ? 
                   <Table
                        size= {"small"}
                       //style= {{width: "80%", height: "80%"}}
                        rowKey = "newsId"
                        title={() => <div>

                                News Items<div><Button type="primary" onClick={(e) => this.showModal(e, 'create')}>Create New</Button></div>                      
              </div>} 
              showHeader = {true}
                        bordered

                        expandRowByClick={false}
                        dataSource={this.props.newsItem.list}

                        expandedRowRender={record => <p style={{ margin:10, wordBreak: "keep-all" }}>{record.newsText}</p>}
                        columns={columns}
                        pagination={{ pageSize: 8}}
                        //scroll={{ y: 800, x: 200 }}
                      />
                      :
                      <div></div>
                        }
                </div>
                
                {this.state.newsItemObject && this.state.officeDetailsObj &&
              <NewsModal 
                    modalVisible={this.state.showModal}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    actionType={this.state.actionType}
                    newsItemObj={this.state.newsItemObject}
                    officeDetailsObj={this.state.officeDetailsObj}
                />
              }
          </ScrollPanel>    
        );
    }
}

const mapStateToProps = state => {
    return {
        newsItem: state.newsItem,
        ui: state.ui,
        homePage: state.homePage
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            initNewsItemDetails,
            initSaveNewsItem,
            initModifyNewsItem,
            initDeleteNewsItem,
            initGetOfficeDetails,
           initCreateNewsItemObj,
           initEditNewsItemObj,
            initNewsItemPage,
            showModal
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsItem);
