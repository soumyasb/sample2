import axios from "axios";

//COMMON ACTIONS
export const getCaseSearchResults = data => ({
  type: "GET_CASE_SEARCHRESULTS",
  data: data
});

export const searchCases = (seachString) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/Search/"+seachString).then(response => {
      dispatch(getCaseSearchResults(response.data));
      // return { ...state, data };
    });
  };
};
