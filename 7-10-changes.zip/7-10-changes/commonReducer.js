const commonReducerDefaultState = {};

const commonreducer = (state = commonReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_CASE_SEARCHRESULTS": {
      return { ...state, ...action.data };
    }

    default:
      return state;
  }
};

export default commonreducer;
