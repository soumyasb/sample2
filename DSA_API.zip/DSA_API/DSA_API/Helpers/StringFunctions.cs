﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Helpers
{
    public static class StringFunctions
    {
        public static string ConvertUpperCaseFirst(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            return char.ToUpper(s[0]) + s.Substring(1);
        }
        public static string GetValueFromMessage(string identifier, string delimiter, string message)
        {
            identifier = " " + identifier + ": ";
            int index = message.IndexOf(identifier) + identifier.Length;

            if (index != -1)
            {
                int index2 = message.IndexOf(delimiter, index);
                if (index2 == -1)
                {
                    index2 = message.Length;
                }
                return message.Substring(index, index2 - index);
            }

            return null;
        }
    }
}
