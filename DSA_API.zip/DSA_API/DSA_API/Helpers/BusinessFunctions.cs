﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Helpers
{
    public static class BusinessFunctions
    {
        public static string GetCaseStatus(string status1, string status2)
        {
            string status = "";
            status = status1 + status2;

            switch (status)
            {
                case "10":
                    return "UN";
                case "13":
                    return "SC";
                case "15":
                case "25":
                case "35":
                    return "CL";
                case "16":
                case "26":
                case "36":
                    return "UP";
                case "20":
                    return "UR";
                case "23":
                    return "RS";
                case "30":
                    return "UC";
                case "33":
                    return "RC";
                case "11":
                case "12":
                case "21":
                case "22":
                case "31":
                case "32":
                    return "UN";
                default:
                    return "";
            }
        }
        public static string GetCaseStatusText(string status1, string status2)
        {
            string xx = "";
            string yy = "";
            if (status2 == "0")
                xx = "Unscheduled";
            else if (status2 == "1")
                xx = "Pending Batch";
            else if (status2 == "2")
                xx = "Pending Batch Force";
            else if (status2 == "3")
                xx = "Scheduled";
            else if (status2 == "5")
                xx = "Closed";

            if (status1 == "1")
                yy = xx + " (Initial)";
            else if (status1 == "2")
                yy = xx + " (Reschedule)";
            else if (status1 == "3")
                yy = xx + " (Reconvene)";
            else if (status1 == "4")
                yy = xx + "Contact Made";

            return yy;
        }

    }
}
