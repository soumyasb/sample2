﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Helpers
{
    public static class DateFunctions
    {
        public static bool ConvertStringToDate(string date, string format, out DateTime outDate)
        {
            bool success;
            return success = DateTime.TryParseExact(date, format, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out outDate);
         
        }
        public static int CompareDates(DateTime date1,  DateTime date2)
        {
            int result = DateTime.Compare(date1, date2);
            return result;
        }
    }
}
