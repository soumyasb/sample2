﻿using AspNetCore.IServiceCollection.AddIUrlHelper;
using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Services;
using DSA_API.Services.Appointments;
using DSA_API.Services.CaseClosure;
using DSA_API.Services.DataManager;
using DSA_API.Services.EmployeeProfile;
using DSA_API.Services.HearingAuth;
using DSA_API.Services.HearingRoomProfile;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Buffers;

namespace DSA_API
{
    public class Startup
    {
        private IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));

            services.AddMvc(options =>
            {
                options.OutputFormatters.Clear();
                options.OutputFormatters.Add(new JsonOutputFormatter(new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                }, ArrayPool<char>.Shared));
            });
            var connection = Configuration["ConnectionStrings:DSADevDatabase"];
            var archive_connection = Configuration["ConnectionStrings:DSADevArchiveDatabase"];
            services.AddDbContext<DSAContext>(
                options => options.UseSqlServer(connection));
            services.AddDbContext<DSARCHIVEContext>(
                options => options.UseSqlServer(archive_connection));
            // register the repository
            services.AddScoped<IAppointmentRepository, AppointmentRepository>();
            services.AddScoped<ICaseClosureRepository, CaseClosureRepository>();
            services.AddScoped<IHearingRoomProfileRepository, HearingRoomProfileRepository>();
            services.AddScoped<IHearingAuthRepository, HearingAuthRepository>();
            services.AddScoped<IEmployeeProfileRepository, EmployeeProfileRepository>();
            services.AddScoped<IHomePageRepository, HomePageRepository>();
            services.AddScoped<INewsItemRepository, NewsItemRepository>();
            services.AddScoped<INewsOfficesRepository, NewsOfficesRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IDSOfficeRepository, DSOfficeRepository>();
            services.AddScoped<IOfficeRepository, OfficeRepository>();
            services.AddScoped<IEmployeesRepository, EmployeesRepository>();
            services.AddScoped<IHearingTimeRepository, HearingTimeRepository>();
            services.AddScoped<IActivityTypeRepository, ActivityTypeRepository>();
            services.AddScoped<IReasonCategoryRepository, ReasonCategoryRepository>();
            services.AddScoped<IHolidayRepository, HolidayRepository>();
            services.AddScoped<ICaseRepository, CaseRepository>();
            services.AddScoped<IOIPRepository, OIPRepository>();
            services.AddScoped<ISearchRepository, SearchRepository>();
            services.AddScoped<ICustomerRepository, CustomerRepository>();
            services.AddScoped<IPersonRepository, PersonRepository>();
            services.AddScoped<ICommonRepository, CommonRepository>();
            services.AddScoped<ILookupRepository, LookupRepository>();
            services.AddScoped<IHearingRoomRepository, HearingRoomRepository>();
            services.AddScoped<IOIPTypeRepository,OIPTypeRepository>();
            services.AddScoped<IReferralRepository, ReferralRepository>();
            services.AddScoped<ISuspenseReasonRepository, SuspenseReasonRepository>();
            services.AddScoped<IUrlHelper>(implementationFactory =>
            {
                var actionContext = implementationFactory.GetService<IActionContextAccessor>()
                .ActionContext;
                return new UrlHelper(actionContext);
            });
            services.AddUrlHelper();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Title = "DSA API",
                    Version = "v1",
                    Description = "DSA_API Core 2 Web API"
                });
            });
            services.AddSwaggerGen(c =>
            {
                c.IncludeXmlComments(GetXmlCommentsPath());
            });

            //services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            //{
            //    builder.WithOrigins("http://localhost:4000", "http://dmvwebd09:4000", "http://localhost:56828")
            //           .AllowAnyMethod()
            //           .AllowAnyHeader()
            //           .AllowCredentials();
            //}));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(appBuilder =>
                {
                    appBuilder.Run(async context =>
                    {
                        var exceptionHandlerFeature = context.Features.Get<IExceptionHandlerFeature>();
                        if (exceptionHandlerFeature != null)
                        {
                            var logger = loggerFactory.CreateLogger("Global exception logger");
                            logger.LogError(500,
                                exceptionHandlerFeature.Error,
                                exceptionHandlerFeature.Error.Message);
                        }

                        context.Response.StatusCode = 500;
                        await context.Response.WriteAsync("An unexpected fault happened. Try again later.");

                    });
                });
            }

            AutoMapper.Mapper.Initialize(cfg =>
            {
                  cfg.CreateMap<Entities.NewsItem, Models.NewsItemDTO>();
            });

            app.UseCors("MyPolicy");

            app.UseMvc( routes =>
            {
                routes.MapRoute("OIPID", "api/oip/{type}/{oipid?}",
                     defaults: new {controller = "oip", action = "Index"});
                routes.MapRoute("OIPCaseAssign", "api/caseoip/{oipid}/{casenumber}/{type}",
                    defaults: new { controller = "caseoip", oipid = @"^\d+$" });
                routes.MapRoute("CommentAPI", "api/comment/{casenumber}/{page?}",
                    defaults: new { controller = "comment" });
                routes.MapRoute("CaseDetail", "api/case/{casenumber}",
                   defaults: new { controller = "case", action = "detail" }
                );
            });
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "DSA Web API V2");
            });

            //var builder = new ConfigurationBuilder()
            //    .SetBasePath(System.IO.Directory.GetCurrentDirectory())
            //    .AddJsonFile("appsettings.json");
            //configuration = builder.Build();
            //var appConfig = configuration.GetSection("App").Get<AppOptions>();
            
        }
        //static  public IConfigurationRoot configuration { get; set; }
        private string GetXmlCommentsPath()
        {
            return System.IO.Path.Combine(System.AppContext.BaseDirectory, "DSA_API.xml");
        }
    }
}
