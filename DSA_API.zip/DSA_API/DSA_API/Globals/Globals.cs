﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Globals
{
    public static class Globals
    {
        public const string DCSTestDate = "111519";
    }
}
