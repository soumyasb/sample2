﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using DSA_API.Entities;
using Microsoft.EntityFrameworkCore;
using DSA_API.Services;
using DSA_API.Services.HearingRoomProfile;
using DSA_API.Helpers;
using DSA_API.Models.HearingRoomProfile;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Globalization;

namespace DSA_API.Controllers.HearingRoomProfile
{
    [Produces("application/json")]
    [Route("api/HearingRoomProfile")]
    public class HearingRoomProfileController : Controller
    {
        private IConfiguration _configuration { get; }
        private IHearingRoomProfileRepository _profileRepo;
        private DSAContext _context;
        private IUserRepository _userRepository;
        private Employee _user;

        public HearingRoomProfileController(
            IConfiguration configuration, IHearingRoomProfileRepository profileRepo, IUserRepository userRepository, DSAContext context)
        {
            _profileRepo = profileRepo;
            _configuration = configuration;
            _context = context;
            _userRepository = userRepository;
        }

        [HttpGet("{HearingRoomProfileID}")]
        public IActionResult Index(int? HearingRoomProfileID)
        {
            if (HearingRoomProfileID == null)
            {
                return NotFound();
            }
            var rProfile = _profileRepo.GetHearingRoomProfile(HearingRoomProfileID.Value);

            if (rProfile == null)
            {
                return NotFound();
            }
            return Ok(rProfile);
        }
       
        [HttpGet("GetHearingRoomProfilesForRoom{LocationId}")]
        public IActionResult GetHearingRoomProfilesForRoom(int LocationId)
        {

            HearingLocationDTO HR = _profileRepo.GetHearingRoom(LocationId);
            HR.HearingRoomProfile = _profileRepo.GetHearingRoomProfileForHearingLocation(LocationId);
            if (HR == null)
            {
                return NotFound();
            }
            return Ok(HR);
        }

        [HttpGet("DefultRoomProfile{LocationId}")]
        public IActionResult DefultRoomProfile(int LocationId)
        {

            HearingLocationDTO HR = _profileRepo.GetHearingRoom(LocationId);
            HR.HearingRoomProfile = _profileRepo.GetDefultRoomProfile(LocationId);
            if (HR == null)
            {
                return NotFound();
            }
            return Ok(HR);
        }

        [HttpPost("UpdateHearingRoomProfile")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult UpdateHearingRoomProfile([FromBody] HearingRoomProfileDTO RoomProfile)
        {
            //Verify that Start / End time to have corrent format string 
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            ValidateHearingRoomTimes(RoomProfile, ModelState);

            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);



            //TODO: GET USER
            _user = _userRepository.GetEmployee("MWDXO3");

            var prof = _profileRepo.ConvertHearingRoomProfile(RoomProfile);
            prof.DtUpdtTrans = DateTime.Now;
            prof.CdUpdtTechId = _user.EmpId;
            
            var pr = _profileRepo.GetHearingRoomProfileForHearingLocation(RoomProfile.HearingRoomId);
            if (pr == null)
            {
                //ADD
                _context.Hearinglocprofile.Add(prof);
            }
            else
            {
                //Edit
                _context.Entry(prof).State = EntityState.Modified;
            }
            
            _context.SaveChanges();

            return Ok(_profileRepo.GetHearingRoomProfile(prof.LocProfileId));


        }
        [HttpGet("GetHearingLocation{OfficeId}")]
        public IActionResult GetHearingLocation(string OfficeId)
        {

            var HRList = _profileRepo.GetHearingRoomsForOffice(OfficeId);

            if (HRList == null)
            {
                return NotFound();
            }
            return Ok(HRList);
        }
        [HttpGet("GetMyDistrictOffices")]
        public IActionResult GetMyDistrictOffices()
        {
            //TODO: GET USER
            _user = _userRepository.GetEmployee("MWDXO3");

            var officeList = _profileRepo.GetDistrictOffices(_user.CdOffId);

            return Ok(officeList);
        }
        private void ValidateHearingRoomTimes(HearingRoomProfileDTO RoomProfile, ModelStateDictionary ModelState)
        {
            //Validate Time Ranges
            ValidateStringTimeRange(RoomProfile.MonStartTime, 600, 1200,"Monday Start Time", "MonStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.MonEndTime, 1400, 2000, "Monday End Time", "MonStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.TueStartTime, 600, 1200, "Tuesday Start Time", "TueStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.TueEndTime, 1400, 2000, "Tuesday End Time", "TueEndTime", ModelState);
            ValidateStringTimeRange(RoomProfile.WedStartTime, 600, 1200, "Wednesday Start Time", "WedStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.WedEndTime, 1400, 2000, "Wednesday End Time", "WedEndTime", ModelState);
            ValidateStringTimeRange(RoomProfile.ThuStartTime, 600, 1200, "Thursday Start Time", "ThuStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.ThuEndTime, 1400, 2000, "Thursday End Time", "ThuEndTime", ModelState);
            ValidateStringTimeRange(RoomProfile.FriStartTime, 600, 1200, "Friday Start Time", "FriStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.FriEndTime, 1400, 2000, "Friday End Time", "FriEndTime", ModelState);
            ValidateStringTimeRange(RoomProfile.SatStartTime, 600, 1200, "Saturday Start Time", "SatStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.SatEndTime, 1400, 2000, "Saturday End Time", "SatEndTime", ModelState);
            ValidateStringTimeRange(RoomProfile.SunStartTime, 600, 1200, "Sunday Start Time", "SunStartTime", ModelState);
            ValidateStringTimeRange(RoomProfile.SunEndTime, 1400, 2000, "Sunday End Time", "SunEndTime", ModelState);

        }

        private void ValidateStringTimeRange(string timestring, int start, int end, string name, string sKey,  ModelStateDictionary ModelState)
        {
            string[] a = timestring.Split(':');
            int t = Convert.ToInt32(a[0])*100 + Convert.ToInt32(a[1]);
            
            if((t < start || t > end) && t != 0)
            {
                string f = DateTime.ParseExact(start.ToString("D4"), "HHmm", CultureInfo.CurrentCulture).ToString("h:mm tt");
                string s = DateTime.ParseExact(end.ToString("D4"), "HHmm", CultureInfo.CurrentCulture).ToString("h:mm tt");
                ModelState.AddModelError(sKey, name +" must be between " + f + " and " + s);
            }
        }
    }
}