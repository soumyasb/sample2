﻿using System;
using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using DSA_API.Helpers;
using System.Net.Http;
using System.Net;
using Microsoft.Extensions.Configuration;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using DSA_API.Common.TCodes;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DAS")]
    public class DASController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DASController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DASInitDTO dto = new DASInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();
            dto.DSUserFieldOffice = _user.CdOff.CdOffAbbr;
            //dto.Birthdate = birthdate;
            var vopType = new List<SelectListItem>();
            vopType.Add(new SelectListItem() { Text = "BAC", Value = "A" });
            vopType.Add(new SelectListItem() { Text = "Refusal", Value = "R" });
            dto.VOPType = vopType;

            var vopTestType = new List<SelectListItem>();
            vopTestType.Add(new SelectListItem() { Text = "Blood", Value = "BL" });
            vopTestType.Add(new SelectListItem() { Text = "Breath", Value = "BR" });
            vopTestType.Add(new SelectListItem() { Text = "PAS", Value = "PA" });
            vopTestType.Add(new SelectListItem() { Text = "Refusal", Value = "RE" });
            vopTestType.Add(new SelectListItem() { Text = "Urine", Value = "UR" });
            dto.VOPTestType = vopTestType;

            var updateCopies = new List<SelectListItem>();
            updateCopies.Add(new SelectListItem() { Text = "System Generated Order", Value = " " });
            updateCopies.Add(new SelectListItem() { Text = "Update Only - No Order", Value = "0" });
            updateCopies.Add(new SelectListItem() { Text = "Manually Typed order", Value = "9" });
            dto.UpdateCopies = updateCopies;
                        
            dto.OSCode = _lookupRepository.GetStates();
            dto.CommStatusIndicator = _lookupRepository.GetCommercialStatus();
            dto.EndStay = _lookupRepository.GetEndStay(_user.CdOffId);
            dto.HearingResults = _lookupRepository.GetHearingResults();
            dto.ChgHearingType = _lookupRepository.GetChgHearingType("DAS");
            dto.CoFo = _lookupRepository.GetCOFO();
            dto.LicenseLocation = _lookupRepository.GetLicenseLocation("DAS");
            dto.OriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DAS");
            dto.DSFieldOffices = _lookupRepository.GetOfficeAbbreviations();
            return Ok(dto);
        }
        //private string getD26(string dlNumber)
        //{

        //    string outputType = "application/json";
        //    string json;

        //    //var identity = (ClaimsIdentity)User.Identity;
        //    //IEnumerable<Claim> claims = identity.Claims;

        //    //string requestorCode = identity.FindFirst("RequestorCode").Value;
        //    //string netName = identity.FindFirst("NetName").Value;
        //    //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

        //    string requestorCode = "86301";
        //    string netName = "#ADMV6LI";
        //    string employeeThreeDigit = "MPG";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
        //            // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
        //            var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                json = response.Content.ReadAsStringAsync().Result;
        //            }
        //            else
        //            {
        //                json = "error";
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        json = "Unable to connect to MQ Service at this time";
        //    }
        //    return json;
        //}
        // POST api/DAS
        /// <summary>
        /// POST A DAS Transaction
        /// </summary>
        /// <remarks> This API will post a DAS transaction the driver record</remarks>
        /// <param name="das"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDAS")]
        public IActionResult ProcessDAS([FromBody] DASUIDTO das)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DAS dasProcess = new DAS(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = dasProcess.ProcessDASTransaction(das);


            //var results = ProcessDASTransaction(das);
            //if (results.Error)
            //{
            //    return Ok(results);
            //}
            //else
            //{
            //    var x = _commonRepository.UpdateDLStats(das.Operator, das.DLNumber, "DAS", das.ThreeCharacterLastName);
            //    if (String.IsNullOrEmpty(das.EffectiveDate))
            //    {
            //        DateTime date;
            //        bool success = DateTime.TryParseExact(das.DetainDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //        if (success && (!String.IsNullOrEmpty(das.VOPTestType) || !String.IsNullOrEmpty(das.CourtCode)))
            //            x = _commonRepository.InsertOrigStat(das.Operator, das.DLNumber, "das", das.ThreeCharacterLastName, das.VOPType == "R" ? "R" : "B", das.VOPTestType, das.CourtCode, date, das.VOPBAC1 + das.VOPBAC2, das.LawEnforcementAgency);
            //    }
            //    if (!String.IsNullOrEmpty(das.EndStay))
            //    {
            //        if (das.EndStay == "4" || das.EndStay == "5")
            //        {
            //            if (!String.IsNullOrEmpty(das.EffectiveDate))
            //            {
            //                DateTime date;
            //                bool success = DateTime.TryParseExact(das.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //                x = _commonRepository.UpdateStay(das.DLNumber, date);
            //            }
            //            else
            //            {
            //                DateTime date1;
            //                DateTime date2;
            //                bool success = DateTime.TryParseExact(das.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date1);
            //                success = DateTime.TryParseExact(das.OrigEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date2);
            //                x = _commonRepository.InsertStay(das.DLNumber, das.EndStay, date1, das.OrigAuthSect, date2);
            //            }
            //        }
            //    }
              
            //}

            //// DAP transaction updated ok, lets do a DAR transaction
            //if (das.LawEnforcementAgency.Length > 0)
            //{
            //    results = ProcessDARTransaction(das);
            //    if (results.Error)
            //    {
            //        return Ok(results);
            //    }
            //    var x = _commonRepository.UpdateDLStats(das.Operator, das.DLNumber, "DAR", das.ThreeCharacterLastName);
            //}


            return Ok(results);
        }
        private DASUIDTO ProcessDASTransaction(DASUIDTO dasdto)
        {
            var testdate = "";
            //if (_env.IsDevelopment())
            //{
            //    testdate = DSA_API.Globals.Globals.DCSTestDate;
            //}
            string netName = "#ADMV6LI";
            DASUpdateDTO DTO = new DASUpdateDTO()
            {
                SBAREQCODE = dasdto.RequestorCode,
                SBAOPERATOR = dasdto.Operator,
                SBADLNUMBER = dasdto.DLNumber,
                SBALASTNAME = dasdto.ThreeCharacterLastName,
                SBABIRTHDATE = dasdto.BirthDate,
                SBADETENTIONCD = dasdto.VOPType,
                SBADETENTIONDATE = dasdto.DetainDate,
                SBATYPTST = dasdto.VOPTestType,
                SBAUPDATECOPIES = dasdto.UpdateCopies,
                SBAEFFDATE = dasdto.EffectiveDate,
                SBAMAILDATE = dasdto.MailDate,
                SBAENDSTAY = dasdto.EndStay,
                SBAORIGAUTH = dasdto.OrigAuthSect,
                SBAORIGEFFDATE = dasdto.OrigEffectiveDate,
                SBAHEARDATE = dasdto.HearingDate,
                SBAHEARRESULT = dasdto.HearingResult,
                SBAHEARMODDATE = dasdto.ModifiedHearingDate,
                SBAHRNGTYPE = dasdto.HearingType,
                SBACORRECTDETENTIONDATE = dasdto.CorrArrestDate,
                SBACOFO = dasdto.CoFo,
                SBADIFFSERVDATE = dasdto.DiffServDate,
                SBACOMMSTATUSIND = dasdto.CommercialStatusIndicator == "N" || dasdto.CommercialStatusIndicator == "" ? "" : dasdto.CommercialStatusIndicator,
                SBALICLOC  = dasdto.LicenseLocation,
                SBACREDITDAYS  = dasdto.CreditDays,
                SBAOSCODE = dasdto.OutOfStateCd,
                SBAOSDLNUMBER = dasdto.OutOfStateDLNo,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dasdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dasdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dasdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAS/" + dasdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dasdto.Error = DTO.Error;
            dasdto.DASResponse = "DAS - " + DTO.StatusMessage;

            return dasdto;
        }

        private DASUIDTO ProcessDARTransaction(DASUIDTO das)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }

            //DAPUpdateDTO dapdto = new DAPUpdateDTO();
            DARUpdateDTO DTO = new DARUpdateDTO();
            DTO.SBAOPERATOR = das.Operator;
            DTO.SBAREQCODE = "9" + das.RequestorCode.Substring(1, 4);
            DTO.SBADLNUMBER = das.DLNumber;
            DTO.SBALASTNAME = das.ThreeCharacterLastName;
            string trans = "";

            if (!String.IsNullOrEmpty(das.CorrArrestDate))
            {
                trans = "DAQ" + "9" + das.RequestorCode.Substring(1, 4) + das.Operator + das.DLNumber + das.ThreeCharacterLastName + "C";
                DTO.SBATYPEINPUT = "C";
            }
            else
            {
                trans = "DAQ" + "9" + das.RequestorCode.Substring(1, 4) + das.Operator + das.DLNumber + das.ThreeCharacterLastName + "A";
                DTO.SBATYPEINPUT = "A";
            }
            if (das.VOPTestType.Length > 0)
            {
                trans += das.VOPTestType;
                DTO.SBATESTTYPE = das.VOPTestType;
            }
            else
            {
                trans += "  ";
            }


            int x = 25 + trans.Length;
            trans += das.LawEnforcementAgency;
            trans = trans.PadRight(x, ' ');

            DTO.SBARRESTAGENCY = das.LawEnforcementAgency.Trim();

            if (!String.IsNullOrEmpty(das.DSFieldOffice))
            {
                trans += das.DSFieldOffice;
                DTO.SBAFIELDOFFICE = das.DSFieldOffice.Trim();
            }
            else
            {
                trans = trans.PadRight(3 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(das.DetainDate))
            {
                trans += das.DetainDate;
                DTO.SBAAPSARRESTDATE = das.DetainDate;
            }
            else
            {
                trans = trans.PadRight(6 + trans.Length, ' ');
            }

            trans = trans.PadRight(12 + trans.Length, ' ');

            if (!String.IsNullOrEmpty(das.VOPBAC1))
            {
                trans += das.VOPBAC1;
                DTO.SBABAC1 = das.VOPBAC1;
            }
            else
            {
                trans = trans.PadRight(2 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(das.VOPBAC2))
            {
                trans += das.VOPBAC2;
                DTO.SBABAC1 = das.VOPBAC2;
            }
            else
            {
                trans = trans.PadRight(2 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(das.LawEnforcementCaseNo))
            {
                x = 13 + trans.Length;
                trans += das.LawEnforcementCaseNo;
                trans = trans.PadRight(x, ' ');
                DTO.SBALECASENUMBER = das.LawEnforcementCaseNo.Trim();
            }
            else
            {
                x = 13 + trans.Length;
                trans = trans.PadRight(x, ' ');
            }

            if (!String.IsNullOrEmpty(das.CourtCode) && das.CourtCode != "99999")
            {
                x = 5 + trans.Length;
                trans += das.CourtCode;
                trans = trans.PadRight(x, ' ');
                DTO.SBACOURTCODE = das.CourtCode;
            }
            else
            {
                x = 5 + trans.Length;
                trans = trans.PadRight(x, ' ');
            }

            trans = trans.PadRight(1 + trans.Length, ' ');

            string netName = "#ADMV6LI";

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", das.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", das.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAR/" + das.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            das.Error = DTO.Error;
            das.DARResponse = "DAR - " + DTO.StatusMessage;

            return das;
        }

    }
}