﻿using System;
using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using DSA_API.Helpers;
using System.Net.Http;
using System.Net;
using Microsoft.Extensions.Configuration;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using DSA_API.Common.TCodes;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DAR")]
    public class DARController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DARController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }

        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DARInitDTO dto = new DARInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            //dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();
            dto.DSUserFieldOffice = _user.CdOff.CdOffAbbr;
            var TypeInput = new List<SelectListItem>();
            TypeInput.Add(new SelectListItem() { Text = "Add", Value = "A" });
            TypeInput.Add(new SelectListItem() { Text = "Change", Value = "C" });
            TypeInput.Add(new SelectListItem() { Text = "Delete", Value = "D" });
            dto.TypeInput = TypeInput;

            var TestType = new List<SelectListItem>();
            TestType.Add(new SelectListItem() { Text = "Blood", Value = "BL" });
            TestType.Add(new SelectListItem() { Text = "Breath", Value = "BR" });
            TestType.Add(new SelectListItem() { Text = "PAS", Value = "PA" });
            TestType.Add(new SelectListItem() { Text = "Refusal", Value = "RE" });
            TestType.Add(new SelectListItem() { Text = "Urine", Value = "UR" });
            dto.TestType = TestType;
            dto.DSFieldOffices = _lookupRepository.GetOfficeAbbreviations();
            return Ok(dto);
        }
        // POST api/DAP
        /// <summary>
        /// POST A DAP Transaction
        /// </summary>
        /// <remarks> This API will post a DAP transaction the driver record</remarks>
        /// <param name="dap"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDAR")]
        public IActionResult ProcessDAR([FromBody] DARUIDTO dar)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DAR darProcess = new DAR(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = darProcess.ProcessDARTransaction(dar);



            //var results = ProcessDARTransaction(dar);
            //if (results.Error)
            //{
            //    return Ok(results);
            //}
            //else
            //{
            //    var x = _commonRepository.UpdateDLStats(dar.Operator, dar.DLNumber, "DAR", dar.ThreeCharacterLastName);
            //}

        
            return Ok(results);
        }


        //private string getD26(string dlNumber)
        //{

        //    string outputType = "application/json";
        //    string json;

        //    //var identity = (ClaimsIdentity)User.Identity;
        //    //IEnumerable<Claim> claims = identity.Claims;

        //    //string requestorCode = identity.FindFirst("RequestorCode").Value;
        //    //string netName = identity.FindFirst("NetName").Value;
        //    //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

        //    string requestorCode = "86301";
        //    string netName = "#ADMV6LI";
        //    string employeeThreeDigit = "MPG";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
        //            // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
        //            var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                json = response.Content.ReadAsStringAsync().Result;
        //            }
        //            else
        //            {
        //                json = "error";
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        json = "Unable to connect to MQ Service at this time";
        //    }
        //    return json;
        //}
       
        private DARUIDTO ProcessDARTransaction(DARUIDTO dar)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }

            DARUpdateDTO DTO = new DARUpdateDTO();
            DTO.SBAOPERATOR = dar.Operator;
            DTO.SBAREQCODE = "9" + dar.RequestorCode.Substring(1, 4);
            DTO.SBADLNUMBER = dar.DLNumber;
            DTO.SBALASTNAME = dar.ThreeCharacterLastName;
            string trans = "";

           
            DTO.SBATYPEINPUT = dar.TypeInput;
            DTO.SBATESTTYPE = dar.TestType;
            DTO.SBARRESTAGENCY = dar.LawEnforcementAgency.Trim();

            if (!String.IsNullOrEmpty(dar.DSFieldOffice))
            {
               DTO.SBAFIELDOFFICE = dar.DSFieldOffice.Trim();
            }
           

            if (!String.IsNullOrEmpty(dar.OrigArrestDetainDate))
            {
               DTO.SBAAPSARRESTDATE = dar.OrigArrestDetainDate;
            }

            if (!String.IsNullOrEmpty(dar.PASDetainDate))
            {
                DTO.SBAPASDETDATE = dar.PASDetainDate;
            }

            if (!String.IsNullOrEmpty(dar.ProbDetainDate))
            {
                DTO.SBASBAPROBDETDATE = dar.ProbDetainDate;
            }

            if (!String.IsNullOrEmpty(dar.BAC1))
            {
                DTO.SBABAC1 = dar.BAC1;
            }
            

            if (!String.IsNullOrEmpty(dar.BAC2))
            {
                DTO.SBABAC1 = dar.BAC2;
            }

            if (!string.IsNullOrEmpty(dar.LawEnforcementAgency))
            {
                dar.LawEnforcementAgency = dar.LawEnforcementAgency.ToUpper().Trim();
                DTO.SBARRESTAGENCY = dar.LawEnforcementAgency;
            }



            if (!String.IsNullOrEmpty(dar.LawEnforcementCaseNo))
            {
               DTO.SBALECASENUMBER = dar.LawEnforcementCaseNo.Trim();
            }
           

            if (!String.IsNullOrEmpty(dar.CourtCode) && dar.CourtCode != "99999")
            {
                DTO.SBACOURTCODE = dar.CourtCode;
            }

            //if (!String.IsNullOrEmpty(dar.OrigArrestDetainDate)
            //{
            //    DTO.SBAMATCHDATE = dar.OrigArrestDetainDate;
            //}


            string netName = "#ADMV6LI";

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dar.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dar.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAR/" + dar.DLNumber, DTO);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dar.Error = DTO.Error;
            dar.DARResponse = "DAR - " + DTO.StatusMessage;

            return dar;
        }
    
    }
}