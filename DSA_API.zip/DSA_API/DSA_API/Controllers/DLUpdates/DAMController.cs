﻿
using DSA_API.Common.TCodes;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Customer;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DAM")]
    public class DAMController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DAMController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }

        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DAMInitDTO dto = new DAMInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();
            dto.DSUserFieldOffice = _user.CdOff.CdOffAbbr;
            //dto.Birthdate = birthdate;
            var apsType = new List<SelectListItem>();
            apsType.Add(new SelectListItem() { Text = "BAC", Value = "A" });
            apsType.Add(new SelectListItem() { Text = "Refusal", Value = "R" });
            dto.PASType = apsType;

            var pasTestType = new List<SelectListItem>();
            pasTestType.Add(new SelectListItem() { Text = "Blood", Value = "BL" });
            pasTestType.Add(new SelectListItem() { Text = "Breath", Value = "BR" });
            pasTestType.Add(new SelectListItem() { Text = "Refusal", Value = "RE" });
            pasTestType.Add(new SelectListItem() { Text = "Urine", Value = "UR" });
            dto.PASTestType = pasTestType;

            var updateCopies = new List<SelectListItem>();
            updateCopies.Add(new SelectListItem() { Text = "System Generated Order", Value = " " });
            updateCopies.Add(new SelectListItem() { Text = "Update Only - No Order", Value = "0" });
            updateCopies.Add(new SelectListItem() { Text = "Manually Typed order", Value = "9" });
            dto.UpdateCopies = updateCopies;

            var vopType = new List<SelectListItem>();
            vopType.Add(new SelectListItem() { Text = "BAC", Value = "A" });
            vopType.Add(new SelectListItem() { Text = "Refusal", Value = "R" });
            dto.VOPType = vopType;

            var vopTestType = new List<SelectListItem>();
            vopTestType.Add(new SelectListItem() { Text = "Blood", Value = "BL" });
            vopTestType.Add(new SelectListItem() { Text = "Breath", Value = "BR" });
            vopTestType.Add(new SelectListItem() { Text = "PAS", Value = "PA" });
            vopTestType.Add(new SelectListItem() { Text = "Refusal", Value = "RE" });
            vopTestType.Add(new SelectListItem() { Text = "Urine", Value = "UR" });
            dto.VOPTestType = vopTestType;

            dto.OSCode = _lookupRepository.GetStates();
            dto.CommStatusIndicator = _lookupRepository.GetCommercialStatus();
            dto.EndStay = _lookupRepository.GetEndStay(_user.CdOffId);
            dto.HearingResults = _lookupRepository.GetHearingResults();
            dto.ChgHearingType = _lookupRepository.GetChgHearingType("DAM");
            dto.CoFo = _lookupRepository.GetCOFO();
            dto.LicenseLocation = _lookupRepository.GetLicenseLocation("DAM");
            dto.PASOriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DAM");
            dto.VOPOriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DAS");
            dto.AuthSection = _lookupRepository.GetAuthoritySection("DAM");
            dto.DSFieldOffices = _lookupRepository.GetOfficeAbbreviations();
            return Ok(dto);
        }
        // POST api/DAP
        /// <summary>
        /// POST A DAP Transaction
        /// </summary>
        /// <remarks> This API will post a DAP transaction the driver record</remarks>
        /// <param name="dam"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDAM")]
        public IActionResult ProcessDAM([FromBody] DAMUIDTO dam)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DAM damProcess = new DAM(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = damProcess.ProcessDAM(dam);
            //var results = ProcessDAMTransaction(dam);
            //if (results.Error)
            //{
            //    return Ok(results);
            //}
            //else
            //{
            //    var x = _commonRepository.UpdateDLStats(dam.Operator, dam.DLNumber, "DAM", dam.ThreeCharacterLastName);
            //    if (String.IsNullOrEmpty(dam.EffectiveDate))
            //    {
            //        DateTime date;
            //        bool success = DateTime.TryParseExact(dam.DetainDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //        if (success && (!String.IsNullOrEmpty(dam.PASTestType) || !String.IsNullOrEmpty(dam.CourtCode)))
            //            x = _commonRepository.InsertOrigStat(dam.Operator, dam.DLNumber, "DAM", dam.ThreeCharacterLastName, dam.PASType == "R" ? "R" : "B", dam.PASTestType, dam.CourtCode, date, dam.BAC1 + dam.BAC2, dam.LawEnforcementAgency);
            //    }
            //    if (dam.EndStay == "5")
            //    {
            //        if (!String.IsNullOrEmpty(dam.EffectiveDate))
            //        {
            //            DateTime date;
            //            bool success = DateTime.TryParseExact(dam.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //            x = _commonRepository.UpdateStay(dam.DLNumber, date);
            //        }
            //        else
            //        {
            //            DateTime date1;
            //            DateTime date2;
            //            bool success = DateTime.TryParseExact(dam.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date1);
            //            success = DateTime.TryParseExact(dam.OrigEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date2);
            //            x = _commonRepository.InsertStay(dam.DLNumber, dam.EndStay, date1, dam.VOPOrigAuthSect, date2);
            //        }
            //    }
            //}

            //// DAP transaction updated ok, lets do a DAR transaction
            //if (dam.LawEnforcementAgency.Length > 0)
            //{
            //    results = ProcessDARTransaction(dam);
            //    if (results.Error)
            //    {
            //        return Ok(results);
            //    }
            //    var x = _commonRepository.UpdateDLStats(dam.Operator, dam.DLNumber, "DAR", dam.ThreeCharacterLastName);
            //}
            //if (dam.VOPType == "A" || dam.VOPType == "R")
            //{
            //    results = ProcessDASTransaction(dam);
            //    if (results.Error)
            //        return Ok(results);
            //    var x = _commonRepository.UpdateDLStats(dam.Operator, dam.DLNumber, "DAS", dam.ThreeCharacterLastName);
            //    if (dam.EndStay == "4" || dam.EndStay == "5")
            //    {
            //        DateTime date;
            //        bool success = DateTime.TryParseExact(dam.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //        x = _commonRepository.UpdateStay(dam.DLNumber, date);
            //    }
            //}

            ////if (dap.EffectiveDate.Length == 0)
            ////{

            ////}
            ////var tempDate = dap.ArrestDate.Substring(0, 2) + "-" + dap.ArrestDate.Substring(2, 2) + "-" + dap.ArrestDate.Substring(4, 2);
            ////var status =_commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName);
            ////status = _commonRepository.InsertOrigStat(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName, dap.APSType, dap.APSTestType, dap.CourtCode, Convert.ToDateTime(tempDate), dap.BAC1 + dap.BAC2, dap.LawEnforcementAgency);

            return Ok(results);
        }


        //private string getD26(string dlNumber)
        //{

        //    string outputType = "application/json";
        //    string json;

        //    //var identity = (ClaimsIdentity)User.Identity;
        //    //IEnumerable<Claim> claims = identity.Claims;

        //    //string requestorCode = identity.FindFirst("RequestorCode").Value;
        //    //string netName = identity.FindFirst("NetName").Value;
        //    //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

        //    string requestorCode = "86301";
        //    string netName = "#ADMV6LI";
        //    string employeeThreeDigit = "MPG";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
        //            // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
        //            var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                json = response.Content.ReadAsStringAsync().Result;
        //            }
        //            else
        //            {
        //                json = "error";
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        json = "Unable to connect to MQ Service at this time";
        //    }
        //    return json;
        //}
        //private DAMUIDTO ProcessDAMTransaction(DAMUIDTO damdto)
        //{
        //    var testdate = "";
        //    //if (_env.IsDevelopment())
        //    //{
        //    //    testdate = DSA_API.Globals.Globals.DCSTestDate;
        //    //}
        //    string netName = "#ADMV6LI";
        //    DAMUpdateDTO DTO = new DAMUpdateDTO()
        //    {
        //        SBAREQCODE = damdto.RequestorCode,
        //        SBAOPERATOR = damdto.Operator,
        //        SBADLNUMBER = damdto.DLNumber,
        //        SBALASTNAME = damdto.ThreeCharacterLastName,
        //        SBABIRTHDATE = damdto.BirthDate,
        //        SBADETCD = damdto.PASType,
        //        SBADETDT = damdto.DetainDate,
        //        SBAUPDCPY = damdto.UpdateCopies,
        //        SBAEFFDATE = damdto.EffectiveDate,
        //        SBAMAILDATE = damdto.MailDate,
        //        SBAENDSTAY = damdto.EndStay,
        //        SBAORIGAUTHSECTION = damdto.PASOrigAuthSect,
        //        SBAORIGEFFDATE = damdto.OrigEffectiveDate,
        //        SBAHEARDATE = damdto.HearingDate,
        //        SBAHEARRESULT = damdto.HearingResult,
        //        SBAHEARMODDATE = damdto.ModifiedHearingDate,
        //        SBAHRNGTYPE = damdto.HearingType,
        //        SBACORRECTARRDETDATE = damdto.CorrArrestDate,
        //        SBACOFO = damdto.CoFo,
        //        SBADIFFSERVDATE = damdto.DiffServDate,
        //        SBACOMMSTATUSIND = damdto.CommercialStatusIndicator == "N" || damdto.CommercialStatusIndicator == "" ? "" : damdto.CommercialStatusIndicator,
        //        SBALICLOC = damdto.LicenseLocation,
        //        SBACREDITDAYS = damdto.CreditDays,
        //        SBAOSCODE = damdto.OutOfStateCd,
        //        SBAOSDLNUMBER = damdto.OutOfStateDLNo,
        //        SBAAUTHSECT = damdto.AuthSection,
        //        SBASUSPTHRUDATE = damdto.SuspThruDate,
        //        SBATESTDATE = testdate
        //    };
        //    string outputType = "application/json";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            // client.DefaultRequestHeaders.Add("MQ-NetName", damdto.NetName.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName);
        //            //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", damdto.Operator.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", damdto.RequestorCode);
        //            var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAM/" + damdto.DLNumber, DTO);
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];
        //                if (DTO.Error)
        //                {
        //                    DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
        //                }
        //            }
        //            else
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];

        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        DTO.Error = true;
        //        DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
        //    }
        //    damdto.Error = DTO.Error;
        //    damdto.DAMResponse = "DAM - " + DTO.StatusMessage;

        //    return damdto;
        //}
        //private DAMUIDTO ProcessDARTransaction(DAMUIDTO dam)
        //{
        //    var testdate = "";
        //    //if (_env.IsDevelopment())
        //    //{
        //    //    testdate = DSA_API.Globals.Globals.DCSTestDate;
        //    //}

        //    DARUpdateDTO DTO = new DARUpdateDTO();
        //    DTO.SBAOPERATOR = dam.Operator;
        //    DTO.SBAREQCODE = "9" + dam.RequestorCode.Substring(1, 4);
        //    DTO.SBADLNUMBER = dam.DLNumber;
        //    DTO.SBALASTNAME = dam.ThreeCharacterLastName;
        //    string trans = "";

        //    if (!String.IsNullOrEmpty(dam.CorrArrestDate))
        //    {
        //        trans = "DAQ" + "9" + dam.RequestorCode.Substring(1, 4) + dam.Operator + dam.DLNumber + dam.ThreeCharacterLastName + "C";
        //        DTO.SBATYPEINPUT = "C";
        //    }
        //    else
        //    {
        //        trans = "DAQ" + "9" + dam.RequestorCode.Substring(1, 4) + dam.Operator + dam.DLNumber + dam.ThreeCharacterLastName + "A";
        //        DTO.SBATYPEINPUT = "A";
        //    }
        //    if (dam.PASTestType.Length > 0)
        //    {
        //        trans += dam.PASTestType;
        //        DTO.SBATESTTYPE = dam.PASTestType;
        //    }
        //    else
        //    {
        //        trans += "  ";
        //    }


        //    int x = 25 + trans.Length;
        //    trans += dam.LawEnforcementAgency;
        //    trans = trans.PadRight(x, ' ');

        //    DTO.SBARRESTAGENCY = dam.LawEnforcementAgency.Trim();

        //    if (!String.IsNullOrEmpty(dam.DSFieldOffice))
        //    {
        //        trans += dam.DSFieldOffice;
        //        DTO.SBAFIELDOFFICE = dam.DSFieldOffice.Trim();
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(3 + trans.Length, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dam.DetainDate))
        //    {
        //        trans += dam.DetainDate;
        //        DTO.SBAAPSARRESTDATE = dam.DetainDate;
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(6 + trans.Length, ' ');
        //    }

        //    trans = trans.PadRight(12 + trans.Length, ' ');

        //    if (!String.IsNullOrEmpty(dam.BAC1))
        //    {
        //        trans += dam.BAC1;
        //        DTO.SBABAC1 = dam.BAC1;
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(2 + trans.Length, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dam.BAC2))
        //    {
        //        trans += dam.BAC2;
        //        DTO.SBABAC1 = dam.BAC2;
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(2 + trans.Length, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dam.LawEnforcementCaseNo))
        //    {
        //        x = 13 + trans.Length;
        //        trans += dam.LawEnforcementCaseNo;
        //        trans = trans.PadRight(x, ' ');
        //        DTO.SBALECASENUMBER = dam.LawEnforcementCaseNo.Trim();
        //    }
        //    else
        //    {
        //        x = 13 + trans.Length;
        //        trans = trans.PadRight(x, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dam.CourtCode) && dam.CourtCode != "99999")
        //    {
        //        x = 5 + trans.Length;
        //        trans += dam.CourtCode;
        //        trans = trans.PadRight(x, ' ');
        //        DTO.SBACOURTCODE = dam.CourtCode;
        //    }
        //    else
        //    {
        //        x = 5 + trans.Length;
        //        trans = trans.PadRight(x, ' ');
        //    }

        //    trans = trans.PadRight(1 + trans.Length, ' ');

        //    string netName = "#ADMV6LI";

        //    string outputType = "application/json";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            // client.DefaultRequestHeaders.Add("MQ-NetName", damdto.NetName.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName);
        //            //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", dam.Operator.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dam.RequestorCode);
        //            var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAR/" + dam.DLNumber, DTO);

        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];
        //                if (DTO.Error)
        //                {
        //                    DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
        //                }
        //            }
        //            else
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];

        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        DTO.Error = true;
        //        DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
        //    }
        //    dam.Error = DTO.Error;
        //    dam.DARResponse = "DAR - " + DTO.StatusMessage;

        //    return dam;
        //}
        //private DAMUIDTO ProcessDASTransaction(DAMUIDTO damdto)
        //{
        //    var testdate = "";
        //    if (_env.IsDevelopment())
        //    {
        //        testdate = DSA_API.Globals.Globals.DCSTestDate;
        //    }
        //    string netName = "#ADMV6LI";

        //    DASUpdateDTO DTO = new DASUpdateDTO()
        //    {
        //        SBAREQCODE = damdto.RequestorCode,
        //        SBAOPERATOR = damdto.Operator,
        //        SBADLNUMBER = damdto.DLNumber,
        //        SBALASTNAME = damdto.ThreeCharacterLastName,
        //        SBABIRTHDATE = damdto.BirthDate,
        //        SBADETENTIONCD = damdto.VOPType,
        //        SBADETENTIONDATE = damdto.DetainDate,
        //        SBATYPTST = damdto.VOPTestType != "RE" ? damdto.VOPTestType : null,
        //        SBAEFFDATE = damdto.EffectiveDate,
        //        SBAMAILDATE = damdto.MailDate,
        //        SBAENDSTAY = damdto.EndStay,
        //        SBAORIGAUTH = damdto.PASOrigAuthSect,
        //        SBAORIGEFFDATE = damdto.OrigEffectiveDate,
        //        SBAHEARDATE = damdto.HearingDate,
        //        SBAHEARRESULT = damdto.HearingResult,
        //        SBAHEARMODDATE = damdto.ModifiedHearingDate,
        //        SBAHRNGTYPE = damdto.HearingType,
        //        SBACORRECTDETENTIONDATE = damdto.CorrArrestDate,
        //        SBAUPDATECOPIES = damdto.UpdateCopies,
        //        SBACOFO = damdto.CoFo,
        //        SBADIFFSERVDATE = damdto.DiffServDate,
        //        SBACOMMSTATUSIND = damdto.CommercialStatusIndicator == "N" || damdto.CommercialStatusIndicator == "" ? "" : damdto.CommercialStatusIndicator,
        //        SBALICLOC = damdto.LicenseLocation,
        //        SBACREDITDAYS = damdto.CreditDays,
        //        SBAOSCODE = damdto.OutOfStateCd,
        //        SBAOSDLNUMBER = damdto.OutOfStateDLNo,
        //        SBATESTDATE = testdate != "" ? testdate : null
        //    };
        //    string outputType = "application/json";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            // client.DefaultRequestHeaders.Add("MQ-NetName", damdto.NetName.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName);
        //            //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", damdto.Operator.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", damdto.RequestorCode);
        //            var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAS/" + damdto.DLNumber, DTO);
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];
        //                if (DTO.Error)
        //                {
        //                    DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
        //                }
        //            }
        //            else
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];

        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        DTO.Error = true;
        //        DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
        //    }
        //    damdto.Error = DTO.Error;
        //    damdto.DASResponse = "DAS - " + DTO.StatusMessage;

        //    return damdto;
        //}
    }
}