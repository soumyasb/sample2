﻿using System;
using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using DSA_API.Helpers;
using System.Net.Http;
using System.Net;
using Microsoft.Extensions.Configuration;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using DSA_API.Common.TCodes;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DAP")]

    public class DAPController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DAPController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }

        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DAPInitDTO dto = new DAPInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            //dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();
            dto.DSUserFieldOffice = _user.CdOff.CdOffAbbr;
            //dto.Birthdate = birthdate;
            var apsType = new List<SelectListItem>();
            apsType.Add(new SelectListItem() { Text = "BAC", Value = "A" });
            apsType.Add(new SelectListItem() { Text = "Refusal", Value = "R" });
            dto.APSType = apsType;

            var apsTestType = new List<SelectListItem>();
            apsTestType.Add(new SelectListItem() { Text = "Blood", Value = "BL" });
            apsTestType.Add(new SelectListItem() { Text = "Breath", Value = "BR" });
            apsTestType.Add(new SelectListItem() { Text = "Refusal", Value = "RE" });
            apsTestType.Add(new SelectListItem() { Text = "Urine", Value = "UR" });
            dto.APSTestType = apsTestType;

            var updateCopies = new List<SelectListItem>();
            updateCopies.Add(new SelectListItem() { Text = "System Generated Order", Value = " " });
            updateCopies.Add(new SelectListItem() { Text = "Update Only - No Order", Value = "0" });
            updateCopies.Add(new SelectListItem() { Text = "Manually Typed order", Value = "9" });
            dto.UpdateCopies = updateCopies;

            var vopType = new List<SelectListItem>();
            vopType.Add(new SelectListItem() { Text = "BAC", Value = "A" });
            vopType.Add(new SelectListItem() { Text = "Refusal", Value = "R" });
            dto.VOPType = vopType;

            var vopTestType = new List<SelectListItem>();
            vopTestType.Add(new SelectListItem() { Text = "Blood", Value = "BL" });
            vopTestType.Add(new SelectListItem() { Text = "Breath", Value = "BR" });
            vopTestType.Add(new SelectListItem() { Text = "PAS", Value = "PA" });
            vopTestType.Add(new SelectListItem() { Text = "Refusal", Value = "RE" });
            vopTestType.Add(new SelectListItem() { Text = "Urine", Value = "UR" });
            dto.VOPTestType = vopTestType;

            dto.OSCode = _lookupRepository.GetStates();
            dto.CommStatusIndicator = _lookupRepository.GetCommercialStatus();
            dto.EndStay = _lookupRepository.GetEndStay(_user.CdOffId);
            dto.HearingResults = _lookupRepository.GetHearingResults();
            dto.ChgHearingType = _lookupRepository.GetChgHearingType("DAP");
            dto.CoFo = _lookupRepository.GetCOFO();
            dto.LicenseLocation = _lookupRepository.GetLicenseLocation("DAP");
            dto.APSOriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DAP");
            dto.VOPOriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DAS");
            dto.DSFieldOffices = _lookupRepository.GetOfficeAbbreviations();
            return Ok(dto);
        }
        // POST api/DAP
        /// <summary>
        /// POST A DAP Transaction
        /// </summary>
        /// <remarks> This API will post a DAP transaction the driver record</remarks>
        /// <param name="dap"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDAP")]
        public IActionResult ProcessDAP([FromBody] DAPUIDTO dap)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DAP dapProcess = new DAP(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = dapProcess.ProcessDAP(dap);
            //var results = ProcessDAPTransaction(dap);
            //if (results.Error)
            //{
            //    return Ok(results);
            //}
            //else
            //{
            //    var x = _commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName);
            //    if (String.IsNullOrEmpty(dap.EffectiveDate))
            //    {
            //        DateTime date;
            //        bool success = DateTime.TryParseExact(dap.ArrestDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //        if (success && (!String.IsNullOrEmpty(dap.APSTestType) || !String.IsNullOrEmpty(dap.CourtCode)))
            //            x = _commonRepository.InsertOrigStat(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName, dap.APSType == "R" ? "R" : "B", dap.APSTestType, dap.CourtCode, date, dap.BAC1 + dap.BAC2, dap.LawEnforcementAgency);
            //    }
            //    if (dap.EndStay == "5")
            //    {
            //        if (!String.IsNullOrEmpty(dap.EffectiveDate))
            //        {
            //            DateTime date;
            //            bool success = DateTime.TryParseExact(dap.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //            x = _commonRepository.UpdateStay(dap.DLNumber, date);
            //        }
            //        else
            //        {
            //            DateTime date1;
            //            DateTime date2;
            //            bool success = DateTime.TryParseExact(dap.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date1);
            //            success = DateTime.TryParseExact(dap.OrigEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date2);
            //            x = _commonRepository.InsertStay(dap.DLNumber, dap.EndStay, date1, dap.VOPOrigAuthSect, date2);
            //        }
            //    }
            //}

            //// DAP transaction updated ok, lets do a DAR transaction
            //if (dap.LawEnforcementAgency.Length > 0)
            //{
            //    results = ProcessDARTransaction(dap);
            //    if (results.Error)
            //    {
            //        return Ok(results);
            //    }
            //    var x = _commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAR", dap.ThreeCharacterLastName);
            //}
            //if (dap.VOPType == "A" || dap.VOPType == "R")
            //{
            //    results = ProcessDASTransaction(dap);
            //    if (results.Error)
            //        return Ok(results);
            //    var x = _commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAS", dap.ThreeCharacterLastName);
            //    if (dap.EndStay == "4" || dap.EndStay == "5")
            //    {
            //        DateTime date;
            //        bool success = DateTime.TryParseExact(dap.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
            //        x = _commonRepository.UpdateStay(dap.DLNumber, date);
            //    }
            //}

            ////if (dap.EffectiveDate.Length == 0)
            ////{

            ////}
            ////var tempDate = dap.ArrestDate.Substring(0, 2) + "-" + dap.ArrestDate.Substring(2, 2) + "-" + dap.ArrestDate.Substring(4, 2);
            ////var status =_commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName);
            ////status = _commonRepository.InsertOrigStat(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName, dap.APSType, dap.APSTestType, dap.CourtCode, Convert.ToDateTime(tempDate), dap.BAC1 + dap.BAC2, dap.LawEnforcementAgency);

            return Ok(results);
        }


        //private string getD26(string dlNumber)
        //{

        //    string outputType = "application/json";
        //    string json;

        //    //var identity = (ClaimsIdentity)User.Identity;
        //    //IEnumerable<Claim> claims = identity.Claims;

        //    //string requestorCode = identity.FindFirst("RequestorCode").Value;
        //    //string netName = identity.FindFirst("NetName").Value;
        //    //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

        //    string requestorCode = "86301";
        //    string netName = "#ADMV6LI";
        //    string employeeThreeDigit = "MPG";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
        //            // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
        //            var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                json = response.Content.ReadAsStringAsync().Result;
        //            }
        //            else
        //            {
        //                json = "error";
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        json = "Unable to connect to MQ Service at this time";
        //    }
        //    return json;
        //}
        //private DAPUIDTO ProcessDAPTransaction(DAPUIDTO dapdto)
        //{
        //    var testdate = "";
        //    //if (_env.IsDevelopment())
        //    //{
        //    //    testdate = DSA_API.Globals.Globals.DCSTestDate;
        //    //}
        //    string netName = "#ADMV6LI";
            
        //   DAPUpdateDTO DTO = new DAPUpdateDTO()
        //   {
        //        SBAREQCODE = dapdto.RequestorCode,
        //        SBAOPERATOR = dapdto.Operator,
        //        SBADLNUMBER = dapdto.DLNumber,
        //        SBALASTNAME = dapdto.ThreeCharacterLastName,
        //        SBABIRTHDATE = dapdto.BirthDate,
        //        SBAARRCD = dapdto.APSType,
        //        SBAARRDT = dapdto.ArrestDate,
        //        SBATYPTST = dapdto.APSTestType,
        //        SBAUPDCPY = dapdto.UpdateCopies,
        //        SBAEFFDATE = dapdto.EffectiveDate,
        //        SBAMAILDATE = dapdto.MailDate,
        //        SBAENDSTAY = dapdto.EndStay,
        //        SBAAUTHSECT = dapdto.PASOrigAuthSect,
        //        SBAORIGEFFDATE = dapdto.OrigEffectiveDate,
        //        SBAHEARDATE = dapdto.HearingDate,
        //        SBAHEARRESULT = dapdto.HearingResult,
        //        SBAHEARMODDATE = dapdto.ModifiedHearingDate,
        //        SBAHRNGTYPE = dapdto.HearingType,
        //        SBACORRECTARRDETDATE = dapdto.CorrArrestDate,
        //        SBACOFO = dapdto.CoFo,
        //        SBADIFFSERVDATE = dapdto.DiffServDate,
        //        SBACOMMSTATUSIND = dapdto.CommercialStatusIndicator == "N" || dapdto.CommercialStatusIndicator == "" ? "" : dapdto.CommercialStatusIndicator,
        //        SBALICLOC1 = dapdto.LicenseLocation,
        //        SBACREDITDAYS1 = dapdto.CreditDays,
        //        SBALICLOC2 = dapdto.LicenseLocation,
        //        SBACREDITDAYS2 = dapdto.CreditDays,
        //        SBAOSCODE = dapdto.OutOfStateCd,
        //        SBAOSDLNUMBER = dapdto.OutOfStateDLNo,
        //        SBATESTDATE = testdate
        //    };
        //    string outputType = "application/json";
         
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName);
        //            //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", dapdto.Operator.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dapdto.RequestorCode);
        //            var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAP/" + dapdto.DLNumber, DTO);
        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];
        //                if (DTO.Error)
        //                {
        //                    DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
        //                }
        //            }
        //            else
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];

        //            }
        //        }
        //    }
        //    catch (Exception e) 
        //    {
        //        DTO.Error = true;
        //        DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
        //    }
        //    dapdto.Error = DTO.Error;
        //    dapdto.DAPResponse = "DAP - " + DTO.StatusMessage;

        //    return dapdto;
        //}
        //private DAPUIDTO ProcessDARTransaction(DAPUIDTO dap)
        //{
        //    var testdate = "";
        //    if (_env.IsDevelopment())
        //    {
        //        testdate = DSA_API.Globals.Globals.DCSTestDate;
        //    }

        //    //DAPUpdateDTO dapdto = new DAPUpdateDTO();
        //    DARUpdateDTO DTO = new DARUpdateDTO();
        //    DTO.SBAOPERATOR = dap.Operator;
        //    DTO.SBAREQCODE = "9" + dap.RequestorCode.Substring(1, 4);
        //    DTO.SBADLNUMBER = dap.DLNumber;
        //    DTO.SBALASTNAME = dap.ThreeCharacterLastName;
        //    string trans = "";

        //    if (!String.IsNullOrEmpty(dap.CorrArrestDate))
        //    {
        //        trans = "DAQ" + "9" + dap.RequestorCode.Substring(1, 4) + dap.Operator + dap.DLNumber + dap.ThreeCharacterLastName + "C";
        //        DTO.SBATYPEINPUT = "C";
        //    }
        //    else
        //    {
        //        trans = "DAQ" + "9" + dap.RequestorCode.Substring(1, 4) + dap.Operator + dap.DLNumber + dap.ThreeCharacterLastName + "A";
        //        DTO.SBATYPEINPUT = "A";
        //    }
        //    if (dap.APSTestType.Length > 0)
        //    {
        //        trans += dap.APSTestType;
        //        DTO.SBATESTTYPE = dap.APSTestType;
        //    }
        //    else
        //    {
        //        trans += "  ";
        //    }


        //    int x = 25 + trans.Length;
        //    trans += dap.LawEnforcementAgency;
        //    trans = trans.PadRight(x, ' ');

        //    DTO.SBARRESTAGENCY = dap.LawEnforcementAgency.Trim();

        //    if (!String.IsNullOrEmpty(dap.DSFieldOffice))
        //    {
        //        trans += dap.DSFieldOffice;
        //        DTO.SBAFIELDOFFICE = dap.DSFieldOffice.Trim();
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(3 + trans.Length, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dap.ArrestDate))
        //    {
        //        trans += dap.ArrestDate;
        //        DTO.SBAAPSARRESTDATE = dap.ArrestDate;
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(6 + trans.Length, ' ');
        //    }

        //    trans = trans.PadRight(12 + trans.Length, ' ');

        //    if (!String.IsNullOrEmpty(dap.BAC1))
        //    {
        //        trans += dap.BAC1;
        //        DTO.SBABAC1 = dap.BAC1;
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(2 + trans.Length, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dap.BAC2))
        //    {
        //        trans += dap.BAC2;
        //        DTO.SBABAC1 = dap.BAC2;
        //    }
        //    else
        //    {
        //        trans = trans.PadRight(2 + trans.Length, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dap.LawEnforcementCaseNo))
        //    {
        //        x = 13 + trans.Length;
        //        trans += dap.LawEnforcementCaseNo;
        //        trans = trans.PadRight(x, ' ');
        //        DTO.SBALECASENUMBER = dap.LawEnforcementCaseNo.Trim();
        //    }
        //    else
        //    {
        //        x = 13 + trans.Length;
        //        trans = trans.PadRight(x, ' ');
        //    }

        //    if (!String.IsNullOrEmpty(dap.CourtCode) && dap.CourtCode != "99999")
        //    {
        //        x = 5 + trans.Length;
        //        trans += dap.CourtCode;
        //        trans = trans.PadRight(x, ' ');
        //        DTO.SBACOURTCODE = dap.CourtCode;
        //    }
        //    else
        //    {
        //        x = 5 + trans.Length;
        //        trans = trans.PadRight(x, ' ');
        //    }

        //    trans = trans.PadRight(1 + trans.Length, ' ');

        //    string netName = "#ADMV6LI";

        //    string outputType = "application/json";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName);
        //            //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", dap.Operator.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dap.RequestorCode);
        //            var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAR/" + dap.DLNumber, DTO);

        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];
        //                if (DTO.Error)
        //                {
        //                    DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
        //                }
        //            }
        //            else
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];

        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        DTO.Error = true;
        //        DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
        //    }
        //    dap.Error = DTO.Error;
        //    dap.DARResponse = "DAR - " + DTO.StatusMessage;

        //    return dap;
        //}
        //private DAPUIDTO ProcessDASTransaction(DAPUIDTO dapdto)
        //{
        //    var testdate = "";
        //    if (_env.IsDevelopment())
        //    {
        //        testdate = DSA_API.Globals.Globals.DCSTestDate;
        //    }
        //    string netName = "#ADMV6LI";
            
        //    DASUpdateDTO DTO = new DASUpdateDTO()
        //    {
        //        SBAREQCODE = dapdto.RequestorCode,
        //        SBAOPERATOR = dapdto.Operator,
        //        SBADLNUMBER = dapdto.DLNumber,
        //        SBALASTNAME = dapdto.ThreeCharacterLastName,
        //        SBABIRTHDATE = dapdto.BirthDate,
        //        SBADETENTIONCD = dapdto.VOPType,
        //        SBADETENTIONDATE = dapdto.ArrestDate,
        //        SBATYPTST = dapdto.VOPTestType != "RE" ? dapdto.VOPTestType: null,
        //        SBAEFFDATE = dapdto.EffectiveDate,
        //        SBAMAILDATE = dapdto.MailDate,
        //        SBAENDSTAY = dapdto.EndStay,
        //        SBAORIGAUTH = dapdto.PASOrigAuthSect,
        //        SBAORIGEFFDATE = dapdto.OrigEffectiveDate,
        //        SBAHEARDATE = dapdto.HearingDate,
        //        SBAHEARRESULT = dapdto.HearingResult,
        //        SBAHEARMODDATE = dapdto.ModifiedHearingDate,
        //        SBAHRNGTYPE = dapdto.HearingType,
        //        SBACORRECTDETENTIONDATE = dapdto.CorrArrestDate,
        //        SBAUPDATECOPIES = dapdto.UpdateCopies,
        //        SBACOFO = dapdto.CoFo,
        //        SBADIFFSERVDATE = dapdto.DiffServDate,
        //        SBACOMMSTATUSIND = dapdto.CommercialStatusIndicator == "N" || dapdto.CommercialStatusIndicator == "" ? "" : dapdto.CommercialStatusIndicator,
        //        SBALICLOC = dapdto.LicenseLocation,
        //        SBACREDITDAYS = dapdto.CreditDays,
        //        SBAOSCODE = dapdto.OutOfStateCd,
        //        SBAOSDLNUMBER = dapdto.OutOfStateDLNo,
        //        SBATESTDATE = testdate != "" ? testdate: null
        //    };
        //    string outputType = "application/json";
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //            // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
        //            client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
        //            client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
        //            // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-NetName", netName);
        //            //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeID", dapdto.Operator.ToUpper());
        //            client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dapdto.RequestorCode);
        //            var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAS/" + dapdto.DLNumber, DTO);

        //            if (response.Result.IsSuccessStatusCode)
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];
        //                if (DTO.Error)
        //                {
        //                    DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
        //                }
        //            }
        //            else
        //            {
        //                JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
        //                DTO.Error = (bool)json["error"];
        //                DTO.Title = (string)json["title"];
        //                DTO.StatusMessage = (string)json["statusMessage"];

        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        DTO.Error = true;
        //        DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
        //    }
        //    dapdto.Error = DTO.Error;
        //    dapdto.DASResponse = "DAS - " + DTO.StatusMessage;

        //    return dapdto;
        //}
    }
}