﻿using DSA_API.Common.TCodes;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DUK")]
    public class DUKController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUKController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DUKInitDTO dto = new DUKInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            var processType = new List<SelectListItem>();
            processType.Add(new SelectListItem() { Text = "Add", Value = "A" });
            processType.Add(new SelectListItem() { Text = "Change", Value = "C" });
            processType.Add(new SelectListItem() { Text = "Delete", Value = "D" });
            dto.Process1 = processType;
            dto.Process2 = processType;
            dto.Process3 = processType;
            dto.Code1 = _lookupRepository.GetDUKCodes("*");
            dto.Code2 = _lookupRepository.GetDUKCodes("*");
            dto.Code3 = _lookupRepository.GetDUKCodes("*");
            dto.PurgeCode = _lookupRepository.GetPurgeCodes("*");
            dto.Info = _lookupRepository.GetPullNotInfo("*");
            dto.Condition = _lookupRepository.GetPullNotice("*");
            dto.Reason = _lookupRepository.GetPullNoticeReason("*");
            return Ok(dto);
        }
        // POST api/DUK
        /// <summary>
        /// POST A DUK Transaction
        /// </summary>
        /// <remarks> This API will post a DUK transaction the driver record</remarks>
        /// <param name="duk"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDUK")]
        public IActionResult ProcessDUK([FromBody] DUKUIDTO duk)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DUK dukProcess = new DUK(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = dukProcess.ProcessDUK(duk);
            return Ok(results);
        }
        // POST api/GetData
        /// <summary>
        /// Get data for Dropdown
        /// </summary>
        /// <remarks> This API will get data based on codes</remarks>
        /// <param name="code"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetDropDownData")]
        public IActionResult GetDropDownData(string code)
        {
            IEnumerable<SelectListItem> myDataList = null;
            switch (code)
            {
                case "D":
                    myDataList = _lookupRepository.GetDeceasedCodes("*");
                    break;
                case "F":
                    myDataList = _lookupRepository.GetFieldFile();
                    break;
                case "I":
                    myDataList = _lookupRepository.GetRestrictions("*");
                    break;
                case "J":
                    myDataList = _lookupRepository.GetAttachments("*");
                    break;
                case "K":
                    myDataList = _lookupRepository.GetFileConditions("*");
                    break;
                case "L":
                    myDataList = _lookupRepository.GetPMCode("*");
                    break;
                case "M":
                    myDataList = _lookupRepository.GetLicenseLocationByOffice("ALL");
                    break;
                case "P":
                    myDataList = _lookupRepository.GetCommFileCond("*");
                    break;
                default:
                    break;

            }
            return Ok(myDataList);
        }
    }
}