﻿using DSA_API.Common.TCodes;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DUX")]
    public class DUXController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUXController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DUXInitDTO dto = new DUXInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.Location = _user.CdOff.CdOffAbbr;
            //dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();

            //dto.Birthdate = birthdate;

            dto.AuthoritySection = _lookupRepository.GetAuthoritySection("DUX");
            dto.OriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DUX");
            dto.Reasons = _lookupRepository.GetReasons();
            var updateCopies = new List<SelectListItem>();
            updateCopies.Add(new SelectListItem() { Text = "System Generated Order", Value = " " });
            updateCopies.Add(new SelectListItem() { Text = "Update Only - No Order", Value = "0" });
            updateCopies.Add(new SelectListItem() { Text = "Manually Typed order", Value = "9" });
            dto.UpdateCopies = updateCopies;
           
            dto.CommStatusIndicator = _lookupRepository.GetCommercialStatus();
            dto.ChgHearingType = _lookupRepository.GetChgHearingType("DUX");
            dto.HearingResults = _lookupRepository.GetHearingResults();
            dto.Locations = _lookupRepository.GetOfficeAbbreviations();
            dto.CoFo = _lookupRepository.GetCOFO();
            dto.PMCode = _lookupRepository.GetPMCode("*");
            dto.Restrictions1 = _lookupRepository.GetRestrictions("*");
            dto.Restrictions2 = _lookupRepository.GetRestrictions("*");
            dto.Restrictions3 = _lookupRepository.GetRestrictions("*");
            dto.ParaIns = _lookupRepository.GetParaIns("*");
            return Ok(dto);
        }
        // POST api/DUX
        /// <summary>
        /// POST A DUX Transaction
        /// </summary>
        /// <remarks> This API will post a DUZ transaction the driver record</remarks>
        /// <param name="dux"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDUX")]
        public IActionResult ProcessDUX([FromBody] DUXUIDTO dux)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DUX duxProcess = new DUX(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = duxProcess.ProcessDUX(dux);
            return Ok(results);
        }
    }
}