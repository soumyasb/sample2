﻿using DSA_API.Common.TCodes;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DUP")]
    public class DUPController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUPController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DUPInitDTO dto = new DUPInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DSUserFieldOffice = _user.CdOff.CdOffAbbr;
            //dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();

            //dto.Birthdate = birthdate;
            dto.TypeAction = _lookupRepository.GetTypeAction(1, "DUP");
            dto.Reasons = _lookupRepository.GetReasons();
            dto.AuthoritySection1 = _lookupRepository.GetAuthoritySection("DUP");
            dto.AuthoritySection2 = _lookupRepository.GetAuthoritySection("DUP");
            dto.OriginalAuthoritySection = _lookupRepository.GetAuthoritySection("DUP");
            dto.PMCode = _lookupRepository.GetPMCode("*");
            dto.CoFo = _lookupRepository.GetCOFO();
            dto.Rest1 = _lookupRepository.GetRestrictions("*");
            dto.Rest2 = _lookupRepository.GetRestrictions("*");
            dto.Rest3 = _lookupRepository.GetRestrictions("*");
            dto.LicenseLocation = _lookupRepository.GetLicenseLocationByOffice(_user.CdOff.CdOffAbbr);
            return Ok(dto);
        }
        // POST api/DUP
        /// <summary>
        /// POST A DUP Transaction
        /// </summary>
        /// <remarks> This API will post a DUP transaction the driver record</remarks>
        /// <param name="dup"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDUP")]
        public IActionResult ProcessDUP([FromBody] DUPUIDTO dup)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DUP dupProcess = new DUP(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = dupProcess.ProcessDUP(dup);
            return Ok(results);
        }
    }
}