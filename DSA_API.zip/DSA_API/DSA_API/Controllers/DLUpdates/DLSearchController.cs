﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using Microsoft.Extensions.Configuration;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DLSearch")]
    public class DLSearchController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        public DLSearchController(
            IUserRepository userRepository,
            IConfiguration configuration,
            DSAContext context)
        {
            _context = context;
            _userRepository = userRepository;
            _configuration = configuration;
        }
    
        // GET: InitialPage
        [HttpGet("GetDlData")]
        public IActionResult GetDLData(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
            DLSearchDTO dto = new DLSearchDTO();
            var d26Model = getD26(dlNumber);
            if (d26Model == "null")
            {
                return NotFound();
            }
            var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<DLSearchDTO>(d26Model);

            dto.DLNumber = dlNumber;
            dto.ThreeCharacterName = dlResults.ThreeCharacterName;
            dto.Birthdate = dlResults.Birthdate;
            return Ok(dto);
        }
        private string getD26(string dlNumber)
        {

            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("D26simple/D26/001/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }
            return json;
        }
    }
}