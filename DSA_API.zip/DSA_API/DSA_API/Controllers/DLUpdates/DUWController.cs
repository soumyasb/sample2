﻿using DSA_API.Common.TCodes;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/DUW")]
    public class DUWController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUWController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null)
            {
                return NotFound();
            }
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            DUWInitDTO dto = new DUWInitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.Location = _user.CdOff.CdOffAbbr;
            //dto.DLNumber = dlNumber;
            //dto.ThreeCharacterName = lastname.Substring(0, 3).ToUpper();

            //dto.Birthdate = birthdate;
            dto.HearingType = _lookupRepository.GetChgHearingType("DUW");
            dto.HearingLocations = _lookupRepository.GetOfficeAbbreviations();
            dto.HearingReasons = _lookupRepository.GetReasons();
            dto.HearingResults = _lookupRepository.GetHearingResults();
            dto.TypeAction = _lookupRepository.GetTypeAction(0, "DUW");
            dto.FieldFile = _lookupRepository.GetFieldFile();
            return Ok(dto);
        }
        // POST api/DUW
        /// <summary>
        /// POST A DUW Transaction
        /// </summary>
        /// <remarks> This API will post a DUW transaction the driver record</remarks>
        /// <param name="duw"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessDUW")]
        public IActionResult ProcessDUW([FromBody] DUWUIDTO duw)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            DUW duwProcess = new DUW(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
            var results = duwProcess.ProcessDUW(duw);
            return Ok(results);
        }
    }
}