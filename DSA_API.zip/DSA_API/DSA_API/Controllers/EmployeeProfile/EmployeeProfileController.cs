﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DSA_API.Helpers;
using DSA_API.Models.Customer;
using DSA_API.Services;
using Microsoft.Extensions.Configuration;
using DSA_API.Services.EmployeeProfile;
using DSA_API.Models.EmployeeProfile;
using DSA_API.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Globalization;
using Microsoft.AspNetCore.Cors;

namespace DSA_API.Controllers.EmployeeProfile
{
    [Produces("application/json")]
    [Route("api/EmployeeProfile")]
    public class EmployeeProfileController : Controller
    {
        private IConfiguration _configuration { get; }
        private IEmployeeProfileRepository _profileRepo;
        private DSAContext _context;
        private IUserRepository _userRepository;
        private Employee _user;

        public EmployeeProfileController(
            IConfiguration configuration, IEmployeeProfileRepository profileRepo, IUserRepository userRepository, DSAContext context)
        {
            _profileRepo = profileRepo;
            _configuration = configuration;
            _context = context;
            _userRepository = userRepository;
        }


        // GET: EmployeeProfile
        [HttpGet("{profileID}")]
        public IActionResult Index(int? profileID)
        {
            if (profileID == null)
            {
                return NotFound();
            }
            EmployeeProfileDTO profile = _profileRepo.GetProfile(profileID.Value);
            profile.ProfileDays = _profileRepo.GetAllProfileDays(profile.ProfileId);
            if (profile == null)
            {
                return NotFound();
            }
            return Ok(profile);
        }

        // GET: GetAllProfilesForEmployee
        [HttpGet("GetAllProfilesForEmployee/{EmpId}")]
        public IActionResult GetAllProfilesForEmployee(int EmpId)
        {
            IEnumerable<EmployeeProfileDTO> profiles = _profileRepo.GetAllProfiles(EmpId);
            if(profiles != null)
            {
                foreach (var p in profiles)
                {
                    p.ProfileDays = _profileRepo.GetAllProfileDays(p.ProfileId);
                }
            } else
            {
                return NotFound();
            }
            
            return Ok(profiles);
        }

        // GET: IntitialPage
        [HttpGet("IntitialPage")]
        public IActionResult IntitialPage()
        {
            //TODO: GET USER
            _user = _userRepository.GetEmployee("MWDXO3");

            EmployeeProfileInitialDTO dto = new EmployeeProfileInitialDTO();
            dto.EmployeeListForRegion = _profileRepo.GetAllDistrictProfileEmployees(_user.CdOffId);
            dto.ClassificationList = _profileRepo.GetClassificationList();
            dto.OfficeListForRegion = _profileRepo.GetDistrictOfficeList(_user.CdOffId);
            if (dto.EmployeeListForRegion.Count() > 0)
            {
                dto.SelectedEmployeeId = dto.EmployeeListForRegion.First().Empid;
                dto.EmpProfiles = _profileRepo.GetAllProfiles(dto.SelectedEmployeeId);
                foreach (var p in dto.EmpProfiles)
                {
                    p.ProfileDays = _profileRepo.GetAllProfileDays(p.ProfileId);
                }
            }

            return Ok(dto);
        }
        // GET: IntitialPage
        [HttpGet("CreateTemplateForEmployee/{EmpId}")]
        public IActionResult CreateTemplateForEmployee(int EmpId, int ProfileID = 0)
        {
            //TODO: GET USER
            _user = _userRepository.GetEmployee("MWDXO3");

            EmployeeProfileDTO empProfile = new EmployeeProfileDTO();
            var emp = _context.Employee.AsNoTracking().Where(e => e.EmpId == EmpId).FirstOrDefault();
            //GET DIFFULTS or LAST ACTIVE PROFILE

            empProfile.EmpID = EmpId;
            empProfile.OfficeID = emp.CdOffId;
            empProfile.EffectiveStartDate = DateTime.Today;
            empProfile.WorkWeekType = "1";
            if(ProfileID == 0)
                empProfile.ProfileDays = _profileRepo.GetDefultProfileDays();
            else
            {
                empProfile.ProfileDays = _profileRepo.GetAllProfileDays(ProfileID);
                foreach (var d in empProfile.ProfileDays)
                {
                    d.ID = 0;
                    d.ProfileID = 0;
                }
            }

            return Ok(empProfile);
        }
        [HttpPost("CreateEmployeeProfile")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult CreateEmployeeProfile([FromBody] EmployeeProfileDTO empProfile)
        {
            //Validations//
            //Future Start Date
            if (empProfile.EffectiveStartDate < DateTime.Today)
            {
                ModelState.AddModelError("", "Effective Start Date must be today or a future date");
            }
            if (empProfile.EffectiveEndDate < DateTime.Today && empProfile.EffectiveEndDate != null)
            {
                ModelState.AddModelError("", "Effective End Date must be today or a future date");
            }

            foreach (var day in empProfile.ProfileDays)
            {
                // Validate time range
                if (day.DayActive)
                {
                    ValidateEmployeeProfileDayDTO(day, ModelState);
                }
                //Validate Travel to and From 
                if (day.TravelToStart == null && day.TravelToEnd != null)
                {
                    ModelState.AddModelError("", "Missing Travel To End date");
                }
                else if (day.TravelToStart != null && day.TravelToEnd == null)
                {
                    ModelState.AddModelError("", "Missing Travel To Start date");
                }
                else if (day.TravelToStart != null && day.TravelToEnd != null && day.TravelToStart > day.TravelToEnd)
                {
                    ModelState.AddModelError("", "Travel To End date must be after Travel To Start date");
                }

                if (day.TravelFromStart == null && day.TravelFromEnd != null)
                {
                    ModelState.AddModelError("", "Missing Travel From End date");
                }
                else if (day.TravelFromStart != null && day.TravelFromEnd == null)
                {
                    ModelState.AddModelError("", "Missing Travel From Start date");
                }
                else if (day.TravelFromStart != null && day.TravelFromEnd != null && day.TravelToStart > day.TravelToEnd)
                {
                    ModelState.AddModelError("", "Travel From End date must be after Travel From Start date");
                }

            }

            // Check for Profile Conflict
            IEnumerable<EmployeeProfileDTO> profileConflictList;
            var newProf = empProfile;
            if (empProfile.EffectiveEndDate == null)
            {
                profileConflictList = _profileRepo.GetAllProfiles(newProf.EmpID)
                                        .Where(p => p.EffectiveEndDate == null || p.EffectiveEndDate >= newProf.EffectiveStartDate).ToList();
            }
            else
            {
                profileConflictList = _profileRepo.GetAllProfiles(newProf.EmpID)
                                        .Where(p => p.EffectiveEndDate == null && p.EffectiveStartDate <= newProf.EffectiveEndDate ||
                                        p.EffectiveStartDate >= newProf.EffectiveStartDate && p.EffectiveStartDate <= newProf.EffectiveEndDate ||
                                        p.EffectiveEndDate >= newProf.EffectiveStartDate && p.EffectiveEndDate <= newProf.EffectiveEndDate ||
                                        p.EffectiveStartDate <= newProf.EffectiveStartDate && p.EffectiveEndDate >= newProf.EffectiveEndDate).ToList();
            }

            // TODO: Take out when there will no other types of profile
            //Select only profiles of type 1
            profileConflictList = profileConflictList.Where(p => p.WorkWeekType == "1");
            bool isProfConflict = false;
            foreach (var item in profileConflictList)
            {
                var d = _profileRepo.GetAllProfileDays(item.ProfileId).ToList();
                for (int i = 0; i < d.Count(); i++)
                {
                    var day = empProfile.ProfileDays.Where(m => m.DayCount == i + 1).FirstOrDefault();


                    int currStart = d[i].DayStart.Hour * 100 + d[i].DayStart.Minute;
                    int currEnd = d[i].DayEnd.Hour * 100 + d[i].DayEnd.Minute;
                    int newStart = day.DayStart.Hour * 100 + day.DayStart.Minute;
                    int newEnd = day.DayEnd.Hour * 100 + day.DayEnd.Minute;

                    if (currStart >= newStart && currStart < newEnd || currEnd > newStart && currEnd <= newEnd)
                    {
                        ModelState.AddModelError("Conflict", "Conflict Day: " + Enum.GetName(typeof(DayOfWeek), i) + " in office " + item.OfficeID);
                        isProfConflict = true;
                    }
                }
            }

            //End of Custom Validation
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            // Check for Scheduled Contact Conflicts
            if (!isProfConflict)
            {
                var cList = _profileRepo.GetAllConflicts(empProfile.EmpID, empProfile.EffectiveStartDate, empProfile.EffectiveEndDate);
                //var otherActiveProfileList = profileRepo.getAllProfiles(employeeProfileVM.Profile.EmpID).Where(p => p.EffectiveEndDate == null || p.EffectiveEndDate >= DateTime.Today).ToList();

                var ConflictList = new List<ConflictDTO>();
                foreach (ConflictDTO c in cList)
                {
                    // Conflict due to different office
                    if (c.OfficeId != empProfile.OfficeID)
                    {
                        ConflictList.Add(c);
                    }
                    else
                    {
                        // Conflict if the contact is outside the new start/end time
                        int cStart = c.ConflictDateTimeStart.Hour * 100 + c.ConflictDateTimeStart.Minute;
                        int cEnd = c.ConfilctDateTimeEnd.Hour * 100 + c.ConfilctDateTimeEnd.Minute;
                        int cDayofWeek = (int)c.ConflictDateTimeStart.DayOfWeek;
                        EmployeeProfileDayDTO prof1 = new EmployeeProfileDayDTO();
                        prof1 = empProfile.ProfileDays.ElementAt(cDayofWeek);

                        int pStart = prof1.DayStart.Hour * 100 + prof1.DayStart.Minute;
                        int pEnd = prof1.DayEnd.Hour * 100 + prof1.DayEnd.Minute;
                        if (cStart < pStart || cEnd > pEnd || prof1.DayActive == false)
                        {
                            ConflictList.Add(c);
                        }
                    }
                }

                if (ConflictList != null)
                {
                    if (ConflictList.Count != 0)
                    {
                        //ModelState.AddModelError("ConflictInScheduledHearings", "Conflict Scheduled Hearings: " + ConflictList.Count + " Hearings");
                        return StatusCode(423, ConflictList);
                    }
                }
            }


            //End of Custom Validation
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //TODO: GET USER
            _user = _userRepository.GetEmployee("MWDXO3");

            var prof = _profileRepo.ConvertProfile(empProfile);
            prof.DtUpdtTrans = DateTime.Now;
            prof.CdUpdtTechId = _user.EmpId;
            prof.CdProfileTyp = "1";

            _context.Profile1.Add(prof);

            foreach (var pDay in empProfile.ProfileDays)
            {
                Profileday day = new Profileday();
                if (pDay.DayActive == true)
                {
                    day = _profileRepo.ConvertProfileDay(pDay);
                }
                else
                {
                    day = _profileRepo.GetEmptyDay(pDay.DayCount);
                }
                day.ProfileId = prof.ProfileId;
                _context.Profileday.Add(day);
            }

            _context.SaveChanges();

            return Ok(_profileRepo.GetProfile(prof.ProfileId));
            //todo
            //return CreatedAtRoute("GetEmployee",new { id = prof.ProfileId },prof);
            
        }

        //[HttpPost("UpdateEmployeeProfile")]
        //public IActionResult UpdateEmployeeProfile([FromBody] EmployeeProfileDTO profile)
        //{
        //    if (!ModelState.IsValid)
        //        return new UnprocessableEntityObjectResult(ModelState);
            
        //    //TODO: GET USER
        //    _user = _userRepository.GetEmployee("MWDXO3");
            
        //    var prof = _profileRepo.ConvertProfile(profile);
        //    prof.CdUpdtTechId = _user.EmpId;
        //    prof.DtUpdtTrans = DateTime.Now;
            
        //    _context.Entry(prof).State = EntityState.Modified;

        //    foreach (var pDay in profile.ProfileDays)
        //    {
        //        Profileday day = new Profileday();
        //        if (pDay.DayActive == true)
        //        {
        //            day = _profileRepo.ConvertProfileDay(pDay);
        //        }
        //        else
        //        {
        //            day = _profileRepo.GetEmptyDay(pDay.DayCount);
        //        }
        //        day.ProfileId = prof.ProfileId;
        //        _context.Entry(day).State = EntityState.Modified;
        //    }

        //    _context.SaveChanges();

        //    //todo
        //    //return CreatedAtRoute("GetEmployeeProfile",new { id = prof.ProfileId},Profile1);

        //    return Ok();
        //}

        [HttpPost("DeleteEmployeeProfile/{ProfileId}")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult DeleteEmployeeProfile(int ProfileId, DateTime? EndEffectiveDate = null)
        {
            if (ProfileId == 0)
                return BadRequest();
           
            Profile1 prof1 = _context.Profile1.Where(p => p.ProfileId == ProfileId).FirstOrDefault();
            if (prof1 == null)
                return NotFound();

            // Check if the old Temp date is past
            if (prof1.DtEffEnd < DateTime.Now)
                ModelState.AddModelError("","This profile has already ended");

            var oldEndDate = prof1.DtEffEnd;

            //prof1.DtEffEnd = DateTime.Today;
            if (EndEffectiveDate == null)
                prof1.DtEffEnd = DateTime.Today;
            else
            {
                if(EndEffectiveDate >= DateTime.Today)
                {
                    prof1.DtEffEnd = EndEffectiveDate;
                }
                else
                {
                    ModelState.AddModelError("EndEffectiveDate", "End Effective Date must be today or a future date");
                }
            }

            //validate ModelState
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //TODO:  ===> CHECK for Hearing Schedule Conflicts <====

            // Get all of the contacts after new term date and before the old
            var cList = _profileRepo.GetAllConflicts(prof1.EmpId, prof1.DtEffEnd.Value, oldEndDate);
            
            var ConflictList = new List<ConflictDTO>();
            foreach (ConflictDTO c in cList)
            {
                // contact is in the same office
                if (c.OfficeId == prof1.CdOffId)
                {
                    ConflictList.Add(c);
                }
            }

            if (ConflictList != null)
            {
                if (ConflictList.Count != 0)
                {
                    //ModelState.AddModelError("ConflictInScheduledHearings", "Conflict Scheduled Hearings: " + ConflictList.Count + " Hearings");
                    return StatusCode(423, ConflictList);
                }
            }
            
            //TODO: GET USER
            _user = _userRepository.GetEmployee("MWDXO3");

            prof1.CdUpdtTechId = _user.EmpId;
            prof1.DtUpdtTrans = DateTime.Now;

            _context.Entry(prof1).State = EntityState.Modified;
            _context.SaveChanges();

            var a = _profileRepo.GetProfile(ProfileId);
            a.ProfileDays = _profileRepo.GetAllProfileDays(ProfileId);

            return Ok(a);
        }

        private void ValidateEmployeeProfileDayDTO(EmployeeProfileDayDTO profDay, ModelStateDictionary ModelState)
        {
            timeBetween(profDay.DayStart, 600, 1200, "Day Start", ModelState);
            timeBetween(profDay.DayEnd, 1400, 2000, "Day End", ModelState);
            timeBetween(profDay.AMBreakStart, 700, 1300, "AM Break Start", ModelState);
            timeBetween(profDay.AMBreakEnd, 700, 1300, "AM Break End", ModelState);
            timeBetween(profDay.PMBreakStart, 1200, 1700, "PM Break Start", ModelState);
            timeBetween(profDay.PMBreakEnd, 1200, 1700, "PM Break End", ModelState);
            timeBetween(profDay.LunchBreakStart, 900, 1500, "Lunch Start", ModelState);
            timeBetween(profDay.LunchBreakEnd, 1000, 1600, "Lunch End", ModelState);
        }
        private void timeBetween(DateTime time, int start, int end, string name, ModelStateDictionary ModelState)
        {
            int timevalue = (time.Hour * 100 + time.Minute);

            if ((timevalue < start || timevalue > end) && timevalue != 0)
            {
                string f = DateTime.ParseExact(start.ToString("D4"), "HHmm", CultureInfo.CurrentCulture).ToString("h:mm tt");
                string s = DateTime.ParseExact(end.ToString("D4"), "HHmm", CultureInfo.CurrentCulture).ToString("h:mm tt");
                ModelState.AddModelError("", name + "must be between " + f + " and " + s);
            }
        }
    }
}