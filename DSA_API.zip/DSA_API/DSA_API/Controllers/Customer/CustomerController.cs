﻿using DSA_API.Helpers;
using DSA_API.Models.Customer;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;

namespace DSA_API.Controllers.Customer
{

    [Produces("application/json")]
    [Route("api/Customer")] 
    public class CustomerController : Controller
    {
        private ICustomerRepository _customerRepository;
        private ICaseRepository _caseRepository;
        private IPersonRepository _personRepository;
        private ISearchRepository _searchRepository;
        private IConfiguration _configuration { get; }

        public CustomerController(ICaseRepository caseRepository,
            ICustomerRepository customerRepository,
            IPersonRepository personRepository,
            ISearchRepository searchRepository,
            IConfiguration configuration)
        {
            _caseRepository = caseRepository;
            _customerRepository = customerRepository;
            _personRepository = personRepository;
            _searchRepository = searchRepository;
            _configuration = configuration;
        }

        // GET: Customer
        [HttpGet("{dlNumber}", Name = "GetCustomer") ]
        public IActionResult Index(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null || dlNumber.ToLower() == "index")
            {
                return NotFound();
            }

            var d26Model = getD26(dlNumber);
            if (d26Model == "null")
            {
                return NotFound();
            }
            CustomerDTO customer = new CustomerDTO(); 
            var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);
            if (!dlResults.ValidationOK)
            {
                customer.D26ValidationMessage = dlResults.ValidationMessage;
                customer.D26ValidationOK = false;
                return Ok(customer);
            }
            
            customer = _customerRepository.getCustomerDetail(dlNumber);
            var Archived = false;
            var ArchivedMessage = "";
            if (customer == null || customer.Archived)
            {
                if (customer.Archived)
                {
                    Archived = true;
                    ArchivedMessage =  dlNumber + " Cases for this Drivers License are archived - please contact LOD MIS Group for Information ";
                }
                if (customer == null)
                {
                    customer = _customerRepository.AddCustomer(dlResults);
                }
                customer.Message = ArchivedMessage;
                customer.Archived = Archived;
            }
         
            customer.ErrorMessage = dlResults.ErrorMessage;
            customer.D26ValidationMessage = dlResults.ValidationMessage;
            customer.D26ValidationOK = dlResults.ValidationOK;

            bool UpdatePersonInfo = false;
            List<string> msgs = new List<string>();
            if (customer.LastName.Trim().ToUpper() != dlResults.lastName.Trim())
            {
                msgs.Add("DCS Compare - Last Name is Different.  Old - " + customer.LastName.Trim() + " New - " + dlResults.lastName.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.FirstName.Trim().ToUpper() != dlResults.firstName.Trim())
            {
                msgs.Add("DCS Compare - First Name is Different.  Old - " + customer.FirstName.Trim() + " New - " + dlResults.firstName.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.MiddleName.Trim().ToUpper() != dlResults.middleName.Trim())
            {
                msgs.Add("DCS Compare - Middle Name is Different.  Old - " + customer.MiddleName.Trim() + " New - " + dlResults.middleName.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.Suffix.Trim().ToUpper() != dlResults.suffix.Trim())
            {
                msgs.Add("DCS Compare - Suffix is Different.  Old - " + customer.Suffix.Trim() + " New - " + dlResults.suffix.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.DOB.Trim() != dlResults.BirthDate.Trim())
            {
                msgs.Add("DCS Compare - Birthdate is Different.  Old - " + customer.DOB + " New - " + dlResults.BirthDate);
                UpdatePersonInfo = true;
            }
            if (customer.Address1.Trim().ToUpper().ToUpper() != dlResults.MAddr.Trim().ToUpper())
            {
                msgs.Add("DCS Compare - Address is Different.  Old - " + customer.MailingAddress.Trim() + " New - " + dlResults.MAddr.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.City.Trim().ToUpper() != dlResults.MCity.Trim().ToUpper())
            {
                msgs.Add("DCS Compare - City is Different.  Old - " + customer.City.Trim() + " New - " + dlResults.MCity.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.State.Trim().ToUpper() != dlResults.MState.Trim())
            {
                msgs.Add("DCS Compare - State is Different.  Old - " + customer.State.Trim() + " New - " + dlResults.MState.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.Zip == null) customer.Zip = "";
            if (customer.Zip.Trim() != dlResults.ZIP.Trim())
            {
                msgs.Add("DCS Compare - Zip code is Different.  Old - " + customer.Zip.Trim() + " New - " + dlResults.ZIP.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.Class1.Trim() != dlResults.Class1.Trim())
            {
                msgs.Add("DCS Compare - Driver's classification is Different.  Old - " + customer.Class1.Trim() + " New - " + dlResults.Class1.Trim());
                UpdatePersonInfo = true;
            }
            if (customer.Class2.Trim() != dlResults.Class2.Trim())
            {
                msgs.Add("DCS Compare - Driver's classification is Different.  Old - " + customer.Class2.Trim() + " New - " + dlResults.Class2.Trim());
                UpdatePersonInfo = true;
            }
       

            if (UpdatePersonInfo)
            {
                string BirthWork = "";
                if (dlResults.BirthDate == "00-00-0000")
                {
                    BirthWork = "01-01-1753";
                }
                else
                {
                    BirthWork = dlResults.BirthDate;
                }
                var flgAddr = (dlResults.flgAddr == null) ? " " : dlResults.flgAddr.Trim();

                string SSNWork = dlResults.SSN.Substring(0, 3) + dlResults.SSN.Substring(4, 2) + dlResults.SSN.Substring(7, 3); 
                bool UpdateOk = _customerRepository.UpdatePersonFromDCS(StringFunctions.ConvertUpperCaseFirst(dlNumber), StringFunctions.ConvertUpperCaseFirst(dlResults.MAddr.Trim().ToUpper()),
                    StringFunctions.ConvertUpperCaseFirst(dlResults.MCity.Trim()), dlResults.Class1.Trim(), dlResults.Class2.Trim(),
                    dlResults.MState.Trim(), dlResults.ZIP.Trim(), BirthWork, flgAddr, SSNWork, 
                    StringFunctions.ConvertUpperCaseFirst(dlResults.firstName.Trim()), StringFunctions.ConvertUpperCaseFirst(dlResults.middleName.Trim()),
                    StringFunctions.ConvertUpperCaseFirst(dlResults.suffix.Trim()), StringFunctions.ConvertUpperCaseFirst(dlResults.lastName.Trim()));
                if (UpdateOk)
                {
                    msgs.Add("Driver Safety Database updated with differences from DCS");
                }
                else
                {
                    msgs.Add("Driver Safety Database update failed with differences from DCS - notify ISD");
                }
            }
            foreach (var item in msgs)
            {
                customer.DCSDifferences.Add(item);
            }

            foreach ( var item in dlResults.Accidents)
            {
                customer.Accidents.Add(item);
            }
            customer.AccidentMessage = dlResults.AccidentMessage;

            customer.cases = _caseRepository.GetCasesByDLNumber(customer.DLNumber);
            
            return Ok(customer);
        }
        // GET api/Case/GetCustomerD26Info
        /// <summary>
        /// Get Customer DLMaster Information
        /// </summary>
        /// <remarks> This API will get Customer DLMaster Information including FR responsibility data</remarks>
        /// <param name="dlNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetCustomerD26Info/{dlNumber}")]
        public IActionResult GetCustomerD26Info(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            if (dlNumber == null || dlNumber.ToLower() == "index")
            {
                return NotFound();
            }

            var d26Model = getD26(dlNumber);
            if (d26Model == "null")
            {
                return NotFound();
            }
  
            var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);
        
            return Ok(dlResults);
      
        }
        private string getD26(string dlNumber)
        {

            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }
            return json;
        }
        // GET api/Customer/Search
        /// <summary>
        /// Search DS database for subject, case 
        /// </summary>
        /// <remarks> This API will search and retreive the DS database for subject and it's cases</remarks>
        /// <param name="keyword"></param>
        /// <returns>JSON</returns>
        [HttpGet("Search/{keyword}")]
        public IActionResult Search(string keyword)
        {
            keyword = keyword.Trim().ToLower();
            var model = _searchRepository.CaseSearch(keyword);
            if (model.ResultCount == 0)
            {
                model.Message = "No results found for your search";
            }
            if (model.ResultCount == 1)
            {
                return RedirectToAction("Index", "Customer", new { dlNumber = model.results[0].dlNumber });
            }
            return Ok(model);
        }

    }
   
}