﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Appointments;
using DSA_API.Models.EmployeeProfile;
using DSA_API.Services;
using DSA_API.Services.Appointments;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.Appointments
{
    [Produces("application/json")]
    [Route("api/EmployeeAppointment")]
    public class EmployeeAppointmentController : Controller
    {
        private IAppointmentRepository _appRepo;
        private DSAContext _context;
        private IUserRepository _userRepository;
        private IEmployeesRepository _employeeRepo;
        private Employee _user;


        public EmployeeAppointmentController(IAppointmentRepository appRepo, IUserRepository userRepository, DSAContext context, IEmployeesRepository employeeRepo)
        {
            _appRepo = appRepo;
            _context = context;
            _userRepository = userRepository;
            _employeeRepo = employeeRepo;
        }
        [HttpGet("{appId}")]
        public IActionResult Index(int? appId)
        {
            if (appId == null)
            {
                return NotFound();
            }
            var app = _appRepo.GetEmployeeAppointment(appId.Value);

            if (app == null)
            {
                return NotFound();
            }
            return Ok(app);
        }
        [HttpGet("GetEmployeeAppointmentByEmployee")]
        [ProducesResponseType(422)]
        
        public IActionResult GetEmployeeAppointmentByEmployee(List<int> empIDList, int month, int year)
        {
            if (month < 1 || month > 12)
            {
                ModelState.AddModelError("Month", "Month paramenter must be 1 - 12");
            }
            if (year < 1900 || year > 2100)
            {
                ModelState.AddModelError("Year", "Year paramenter must be 1900 - 2100");
            }
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);


            DateTime monthStart = new DateTime(year, month, 1);
            DateTime monthEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month));
            DateTime NoEndDate = new DateTime(9999, 12, 31);
            var appList = _appRepo.GetEmployeeAppointmentByEmployees(empIDList);
            
            var selectedList = appList.Where(p => p.EndTime == NoEndDate && p.StartTime <= monthEnd ||
                                            p.StartTime >= monthStart && p.StartTime <= monthEnd ||
                                            p.EndTime >= monthStart && p.EndTime <= monthEnd ||
                                            p.StartTime <= monthStart && p.EndTime >= monthEnd).ToList();
            return Ok(selectedList);
        }

        [HttpGet("GetEmployeeAppointmentForEdit{ReacurrenceNumber}")]
        public IActionResult GetEmployeeAppointmentForEdit(int ReacurrenceNumber, int? AppintmentNumber )
        {

            var editDTO = new EmployeeAppointmentEditDTO();
            editDTO.EmployeeProfileList = _appRepo.GetEmployeeAppointmentByReacurrenceNumber(ReacurrenceNumber, AppintmentNumber);

            // GET selected employee list?

            // get activity type
            editDTO.ActivityTypeList = _appRepo.GetActivityType();

            return Ok(editDTO);
        }
        [HttpGet("GetEmployeeAppointmentForCreate")]
        public IActionResult GetActivityTypeList()
        {
            
            _user = _userRepository.GetEmployee("MWDXO3"); //TODO:
            var createDTO = new EmployeeAppointmentCreateDTO();
            createDTO.DefultAppointment = _appRepo.GetDefultAppointment();

            // GET selected employee list?
            // TODO: Replace funtrion "getAllActiveEmployees" with one that returns only the active employees for the office
            createDTO.EmployeeListForOffice = _employeeRepo.getAllActiveEmployees().Where(a => a.OfficeID == _user.CdOffId);
            // get activity type
            createDTO.ActivityTypeList = _appRepo.GetActivityType();

            return Ok(createDTO);
        }
        [HttpPost("CreateEmployeeAppointment")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult CreateEmployeeAppointment([FromBody] IEnumerable<EmployeeAppointmentDTO> EmpAppointmentList)
        {
            if (EmpAppointmentList == null)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);


            var nowDate = DateTime.Now;
            var reaccurance = 0;
            int? appNumber = null;

            //Validate Scheduled Hearings
            var ConflictList = new List<ConflictDTO>();
            //TODO: If appointment is not the same for the whole list update the following validation
            // calculate all reacuring instances for compare  
            var c = _appRepo.CalculateReacurance(EmpAppointmentList.FirstOrDefault(), DateTime.Today, (DateTime.Today.AddDays(90)));
            
            foreach (var app in EmpAppointmentList)
            {   
                ConflictList.AddRange(_appRepo.ScheuledHearingConflicts(c, app.EmpId));
            }
            
            if(ConflictList != null)
            {
                if (ConflictList.Count > 0)
                    return StatusCode(423, ConflictList);
            }
            

            _user = _userRepository.GetEmployee("MWDXO3");

            //Assign a ReaccuranceNumber
            var reacc = _context.ApptCntl.Where(cnt => cnt.NbrTyp == 1).FirstOrDefault();
            reacc.NbrSeq++;
            reaccurance = reacc.NbrSeq.Value;
            _context.Entry(reacc).State = EntityState.Modified;
            _context.SaveChanges();

            //Assign AppointmentNumber - null if single occurance, 0 for reaccuring
            var firstA = EmpAppointmentList.FirstOrDefault();
            if (firstA.StartTime.Date != firstA.EndTime.Date)
            {
                appNumber = 0;
            }
            
            foreach (var a in EmpAppointmentList)
            {
                a.UpdatedBy = _user.EmpId;
                a.DateUpdated = nowDate;
                a.ReacurrenceNumber = reaccurance;
                a.AppointmentNumber = appNumber;
                Appointment app = new Appointment();
                app = _appRepo.ConvertEmployeeAppointment(a);
                _context.Appointment.Add(app);
            }
            _context.SaveChanges();

            return Ok(_appRepo.GetEmployeeAppointmentByReacurrenceNumber(reaccurance,appNumber));

        }

        [HttpPost("EditEmployeeAppointment")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult EditEmployeeAppointment([FromBody] IEnumerable<EmployeeAppointmentDTO> EmpAppointmentList)
        {
            var nowDate = DateTime.Now;
            int? nbrAppt = null;
            int? maxAppNum;
            
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //Validate Scheduled Hearings
            var ConflictList = new List<ConflictDTO>();
            //TODO: If appointment is not the same for the whole list update the following validation 
            var c = _appRepo.CalculateReacurance(EmpAppointmentList.FirstOrDefault(), DateTime.Today, (DateTime.Today.AddDays(90)));

            foreach (var app in EmpAppointmentList)
            {
                ConflictList.AddRange(_appRepo.ScheuledHearingConflicts(c, app.EmpId));
            }

            if (ConflictList != null)
            {
                if (ConflictList.Count > 0)
                    return StatusCode(423, ConflictList);
            }
            
            _user = _userRepository.GetEmployee("MWDXO3");

            var firstApp = EmpAppointmentList.FirstOrDefault();

            //Incrament AppointmentNumber - null if single occurance, 0 for reaccuring
            if(firstApp.AppointmentNumber != null)
            {
                maxAppNum = _context.Appointment.Where(a => a.NbrRcurApt == firstApp.ReacurrenceNumber).Max(n => n.NbrAppt);

                nbrAppt = maxAppNum + 1;
            }

            foreach (var a in EmpAppointmentList)
            {
                a.UpdatedBy = _user.EmpId;
                a.DateUpdated = nowDate;
                a.AppointmentNumber = nbrAppt;

                Appointment app = new Appointment();
                app = _appRepo.ConvertEmployeeAppointment(a);
                _context.Entry(app).State = EntityState.Modified;
                
            }
            _context.SaveChanges();

            return Ok(_appRepo.GetEmployeeAppointmentByReacurrenceNumber(firstApp.ReacurrenceNumber, nbrAppt));
        }

        [HttpPost("DeleteEmployeeAppointment")]
        public IActionResult DeleteEmployeeAppointment(int ReaccuranceNumber, int? AppintmentNumber = null)
        {
            var nowDate = DateTime.Now;

            var EmpAppointmentList = _context.Appointment
                    .Where(a => a.NbrRcurApt == ReaccuranceNumber && a.NbrAppt == AppintmentNumber && a.FlgDelete != "1").ToList();

            if (EmpAppointmentList == null)
            {
                return NotFound();
            }

            _user = _userRepository.GetEmployee("MWDXO3"); //TODO: Replace hard code user info

            foreach (var a in EmpAppointmentList)
            {
                a.CdUpdtTechId = _user.EmpId;
                a.DtUpdtTrans = nowDate;
                a.FlgDelete = "1";

                //Appointment app = new Appointment();
                _context.Entry(a).State = EntityState.Modified;
            }
            _context.SaveChanges();

            return Ok();

        }
        [HttpGet("GetEmployeesForMyOffice")]
   
        public IActionResult GetEmployeesForMyOffice()
        {
            _user = _userRepository.GetEmployee("MWDXO3");
            
            // TODO: Update with a direct call
            var EmployeeListForOffice = _employeeRepo.getAllActiveEmployees().Where(a => a.OfficeID == _user.CdOffId);
            
            return Ok(EmployeeListForOffice);
        }

    }
}