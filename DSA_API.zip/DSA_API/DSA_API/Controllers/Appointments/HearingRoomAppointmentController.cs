﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Appointments;
using DSA_API.Models.EmployeeProfile;
using DSA_API.Services;
using DSA_API.Services.Appointments;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.Appointments
{
    [Produces("application/json")]
    [Route("api/HearingRoom")]
    public class HearingRoomAppointmentController : Controller
    {
        private IAppointmentRepository _appRepo;
        private DSAContext _context;
        private IUserRepository _userRepository;
        private IEmployeesRepository _employeeRepo;
        private Employee _user;


        public HearingRoomAppointmentController(IAppointmentRepository appRepo, IUserRepository userRepository, DSAContext context, IEmployeesRepository employeeRepo)
        {
            _appRepo = appRepo;
            _context = context;
            _userRepository = userRepository;
            _employeeRepo = employeeRepo;
        }
        [HttpGet("{appId}")]
        public IActionResult Index(int? appId)
        {
            if (appId == null)
            {
                return NotFound();
            }
            var app = _appRepo.GetHearingRoomAppointment(appId.Value);


            return Ok(app);
        }
        [HttpGet("GetHearingRoomAppointmentByHearingRoom{LocationId}")]
        [ProducesResponseType(422)]
        public IActionResult GetHearingRoomAppointmentByHearingRoom(int LocationId, int month, int year)
        {
            if (month < 1 || month > 12)
            {
                ModelState.AddModelError("Month", "Month paramenter must be 1 - 12");
            }
            if (year < 1900 || year > 2100)
            {
                ModelState.AddModelError("Year", "Year paramenter must be 1900 - 2100");
            }
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //TODO: Optimize query
            DateTime monthStart = new DateTime(year, month, 1);
            DateTime monthEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month));
            DateTime NoEndDate = new DateTime(9999, 12, 31);
            var appList = _appRepo.GetHearingRoomAppointmentByHearingRoom(LocationId);

            var selectedList = appList.Where(p => p.EndTime == NoEndDate && p.StartTime <= monthEnd ||
                                            p.StartTime >= monthStart && p.StartTime <= monthEnd ||
                                            p.EndTime >= monthStart && p.EndTime <= monthEnd ||
                                            p.StartTime <= monthStart && p.EndTime >= monthEnd).ToList();

            return Ok(selectedList);
        }

        [HttpGet("GetHearingRoomAppointmentForEdit{ReacurrenceNumber}")]
        public IActionResult GetHearingRoomAppointmentForEdit(int ReacurrenceNumber, int? AppintmentNumber)
        {

            var editDTO = _appRepo.GetHearingRoomAppointmentByReacurrenceNumber(ReacurrenceNumber, AppintmentNumber).FirstOrDefault();

            return Ok(editDTO);
        }

        [HttpGet("GetHearingRoomAppointmentForCreate")]
        public IActionResult GetHearingRoomAppointmentForCreate()
        {
            _user = _userRepository.GetEmployee("MWDXO3"); //TODO:

            var createDTO = _appRepo.GetDefultHearingRoomAppointment();

            return Ok(createDTO);
        }

        [HttpPost("CreateHearingRoomAppointment")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult CreateHearingRoomAppointment([FromBody] HearingRoomAppointmentDTO HearingRoomAppointment)
        {
            var nowDate = DateTime.Now;
            var reaccurance = 0;
            int? appNumber = null;

            // Validate State Model
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
            
            //Validate Scheduled Hearings
            var ConflictList = new List<ConflictDTO>();
            var cList = _appRepo.CalculateReacuranceRoom(HearingRoomAppointment, DateTime.Today, (DateTime.Today.AddDays(90)));
            ConflictList.AddRange(_appRepo.ScheuledHearingConflictsRoom(cList, HearingRoomAppointment.HearingRoomId));
            
            // Return Scheduled Hearing Conflicts
            if (ConflictList != null)
            {
                if (ConflictList.Count > 0)
                    return StatusCode(423, ConflictList);
            }
            
            _user = _userRepository.GetEmployee("MWDXO3");

            //Assign a ReaccuranceNumber
            var reacc = _context.ApptCntl.Where(c => c.NbrTyp == 1).FirstOrDefault();
            reacc.NbrSeq++;
            reaccurance = reacc.NbrSeq.Value;
            _context.Entry(reacc).State = EntityState.Modified;
            _context.SaveChanges();

            //Assign AppointmentNumber - null if single occurance, 0 for reaccuring

            if (HearingRoomAppointment.StartTime.Date != HearingRoomAppointment.EndTime.Date)
            {
                appNumber = 0;
            }
            HearingRoomAppointment.UpdatedBy = _user.EmpId;
            HearingRoomAppointment.DateUpdated = nowDate;
            HearingRoomAppointment.ReacurrenceNumber = reaccurance;
            HearingRoomAppointment.AppointmentNumber = appNumber;
            Appointment app = new Appointment();
            app = _appRepo.ConvertEmployeeAppointment(HearingRoomAppointment);
            _context.Appointment.Add(app);
            
            _context.SaveChanges();

            return Ok(_appRepo.GetHearingRoomAppointmentByReacurrenceNumber(reaccurance, appNumber));
        }

        [HttpPost("EditHearingRoomAppointment")]
        [ProducesResponseType(422)]
        [ProducesResponseType(423)]
        public IActionResult EditHearingRoomAppointment([FromBody] HearingRoomAppointmentDTO HearingRoomAppointment)
        {
            var nowDate = DateTime.Now;
            int? nbrAppt = null;
            int? maxAppNum;
            // Validate State Model
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //Validate Scheduled Hearings
            var ConflictList = new List<ConflictDTO>();
            var cList = _appRepo.CalculateReacuranceRoom(HearingRoomAppointment, DateTime.Today, (DateTime.Today.AddDays(90)));
            ConflictList.AddRange(_appRepo.ScheuledHearingConflictsRoom(cList, HearingRoomAppointment.HearingRoomId));

            // Return Scheduled Hearing Conflicts
            if (ConflictList != null)
            {
                if (ConflictList.Count > 0)
                    return StatusCode(423, ConflictList);
            }

            //TODO: UPDATE USER 
            _user = _userRepository.GetEmployee("MWDXO3");

            //Incrament AppointmentNumber - null if single occurance, 0 for reaccuring
            if (HearingRoomAppointment.AppointmentNumber != null)
            {
                maxAppNum = _context.Appointment.Where(a => a.NbrRcurApt == HearingRoomAppointment.ReacurrenceNumber).Max(n => n.NbrAppt);

                nbrAppt = maxAppNum + 1;
            }

            HearingRoomAppointment.UpdatedBy = _user.EmpId;
            HearingRoomAppointment.DateUpdated = nowDate;
            HearingRoomAppointment.AppointmentNumber = nbrAppt;
            Appointment app = new Appointment();
            app = _appRepo.ConvertEmployeeAppointment(HearingRoomAppointment);
            _context.Entry(app).State = EntityState.Modified;

            _context.SaveChanges();

            return Ok(_appRepo.GetHearingRoomAppointmentByReacurrenceNumber(HearingRoomAppointment.ReacurrenceNumber, nbrAppt));
        }
        [HttpPost("DeleteHearingRoomAppointment")]
        public IActionResult DeleteHearingRoomAppointment(int AppointmentId)
        {
            var nowDate = DateTime.Now;

            var app = _context.Appointment
                    .Where(a => a.AppointmentId == AppointmentId && a.FlgDelete != "1").FirstOrDefault();
            
            if (app == null) //Not a room appointment
            {
                return NotFound();
            }
            if(app.EmpId != null)
            {
                return NotFound();
            }

            _user = _userRepository.GetEmployee("MWDXO3"); //TODO: Replace hard code user info
            
            app.CdUpdtTechId = _user.EmpId;
            app.DtUpdtTrans = nowDate;
            app.FlgDelete = "1";

            //Appointment app = new Appointment();
            _context.Entry(app).State = EntityState.Modified;
            
            _context.SaveChanges();

            return Ok();

        }
    }
}