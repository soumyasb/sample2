﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DSA_API.Helpers;
using DSA_API.Models.Customer;
using DSA_API.Services;
using Microsoft.Extensions.Configuration;
using DSA_API.Services.EmployeeProfile;
using DSA_API.Models.EmployeeProfile;
using DSA_API.Entities;
using Microsoft.EntityFrameworkCore;
using DSA_API.Services.HearingAuth;
using DSA_API.Models.HearingAuth;

namespace DSA_API.Controllers.HearingAuth
{
    [Produces("application/json")]
    [Route("api/HearingAuth")]
    public class HearingAuthController : Controller
    {
        private IConfiguration _configuration { get; }
        private IHearingAuthRepository _authRepo;
        private DSAContext _context;

        public HearingAuthController(IConfiguration configuration, IHearingAuthRepository authRepo,  DSAContext context)
        {
            _authRepo = authRepo;
            _configuration = configuration;
            _context = context;
      
        }
        [HttpGet("{EmpID}")]
        public IActionResult Index(int? EmpID)
        {
            if (EmpID == null)
            {
                return NotFound();
            }
            var hAuth = _authRepo.GetHearingAuth(EmpID.Value);
         
            if (hAuth == null)
            {
                return NotFound();
            }
            return Ok(hAuth);
        }
        
        [HttpPost("CreateHearingAuth")]
        [ProducesResponseType(422)]
        public IActionResult CreateHearingAuth([FromBody] IEnumerable<HearingAuthDTO> hAuthList)
        {
            // validate that there is no current Hearing Authority 
            // validate all the list is full
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            var hCount = _authRepo.GetHearingAuth(hAuthList.First().EmpID).Count();

            if(hCount == 0)
            {
                //ADD
                foreach (var hAuth in hAuthList)
                {
                    Hoauthtype1 h = new Hoauthtype1();
                    h = _authRepo.ConvertHearingAuth(hAuth);
                    h.LastUpdatedDate = DateTime.Now;
                    _context.Hoauthtype1.Add(h);
                }
            }
            else
            {
                //Edit
                foreach (var hAuth in hAuthList)
                {
                    Hoauthtype1 h = new Hoauthtype1();
                    h = _authRepo.ConvertHearingAuth(hAuth);
                    h.LastUpdatedDate = DateTime.Now;
                    _context.Entry(h).State = EntityState.Modified;
                }
            }
            

            _context.SaveChanges();

            return Ok();
        }

        //[HttpPost("EditHearingAuth")]
        //public IActionResult EditHearingAuth([FromBody] IEnumerable<HearingAuthDTO> hAuthList)
        //{
        //    if (!ModelState.IsValid)
        //        return new UnprocessableEntityObjectResult(ModelState);
            
        //    foreach (var hAuth in hAuthList)
        //    {
        //        Hoauthtype1 h = new Hoauthtype1();
        //        h = _authRepo.ConvertHearingAuth(hAuth);
        //        _context.Entry(h).State = EntityState.Modified;
        //    }
        //    _context.SaveChanges();

        //    return Ok();
        //}
    }
}