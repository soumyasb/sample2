﻿using AutoMapper;
using DSA_API.Entities;
using Microsoft.AspNetCore.Cors;
using DSA_API.Helpers;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;



namespace DSA_API.Controllers.Admin
{
    [Produces("application/json")]
    [Route("api/NewsItems")]

    public class NewsItemsController : Controller
    {
        private INewsOfficesRepository _newsOfficesRepository;
        private IUserRepository _userRepository;
        private IDSOfficeRepository _dSOfficeRepository;
        private Employee _user;

        public NewsItemsController(IHomePageRepository homePageRepository, INewsOfficesRepository newsOfficesRepository, IUserRepository userRepository,
            IDSOfficeRepository dSOfficeRepository, DSAContext context)
        {
            _newsOfficesRepository = newsOfficesRepository;
            _userRepository = userRepository;
            _dSOfficeRepository = dSOfficeRepository;
           // _context = context;
        }
        [HttpGet(Name = "GetNewsItemsForUser")]
        public IActionResult GetNewsItemsForUser()
        {
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
    
            if (_user.CdEmpTyp != "D" & _user.CdEmpTyp != "R" & _user.CdEmpTyp != "O")
            {
                return Unauthorized();
            }
            var newsItems = _newsOfficesRepository.GetNewsItems(_user.EmpId);

            return Ok(newsItems);
        }
        // GET: NewsItems/Details/5
        [HttpGet("GetNewsItemDetails/{id}", Name = "GetNewsItem")]
        public IActionResult GetNewsItemDetails(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            NewsItem newsItem = _newsOfficesRepository.GetNewsItem(id);
            if (newsItem == null)
            {
                return NotFound();
            }
            return Ok(newsItem);
        }

        // GET: NewsItems/Create
        [HttpGet("CreateNewsItem")]
        public IActionResult CreateNewsItem()
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
            if (_user.CdEmpTyp != "O" & _user.CdEmpTyp != "R" & _user.CdEmpTyp != "D")
            {
                  ModelState.AddModelError(nameof(NewsItemDTO),
                        "Only managers can create news items.");
            }
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
            NewsItemDTO newsItem = new NewsItemDTO();
            newsItem.EmpId = _user.EmpId;
            newsItem.AuthorName = _user.NmeFrstPrsn + " " + _user.NmeSurnmePrsn;
            newsItem.StartDate = DateTime.Now;
            newsItem.EndDate = DateTime.Now;
            newsItem.EmployeeType = _user.CdEmpTyp;
            return Ok(newsItem);
        }

        // GET: NewsItems/EditNewsItem/5
        [HttpGet("EditNewsItem/{id}")]
        public IActionResult EditNewsItem(int id)
        {
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            _user = _userRepository.GetEmployee("MWMPG4");
            if (_user == null)
            {
                return NotFound();
            }
            if (id == 0)
            {
                return BadRequest();
            }

            var newsItemFromRepo = _newsOfficesRepository.GetNewsItem(id);
            if (newsItemFromRepo == null)
            {
                return NotFound();
            }

            var newsItemForUser = Mapper.Map<NewsItemDTO>(newsItemFromRepo);


            newsItemForUser.EmployeeType = _user.CdEmpTyp;
            List<string> offices = new List<string>();

            var officeNewsItems = _newsOfficesRepository.GetOfficeNewsItems(id);

            foreach (OfficeNewsItem o in officeNewsItems)
            {
                offices.Add(o.CdOffId);
            }
          
            if (offices.Count > 0)
               newsItemForUser.officeGroup = offices;

            return Ok(newsItemForUser);
        }

        // POST: NewsItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost ("ModifyNewsItem")]
        // [ValidateAntiForgeryToken]
        public IActionResult ModifyNewsItem([FromBody] NewsItemDTO newsItem)
        {
            if (newsItem == null)
            {
                return BadRequest();
            }

            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = userRepo.GetEmployee(identity.Name, true);
            //_user = _userRepository.GetEmployee("MWMPG4");

                       
            bool updateOk = _newsOfficesRepository.ModifyNewsItems(newsItem);
            bool modifyOk = _newsOfficesRepository.ModifyOfficeNewsItems(newsItem);
            return RedirectToAction("GetNewsItemsForUser", "NewsItems");
             
            //return CreatedAtRoute("GetNewsItem",
            //    new { id = newsItem.NewsId },
            //    newsItem);
        }

        // POST: NewsItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("AddNewsItem")]
        //  [ValidateAntiForgeryToken]
        public ActionResult AddNewsItem([FromBody] NewsItemDTO newsItem)
        {
            if (newsItem == null)
            {
                return BadRequest();
            }

            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = _userRepository.GetEmployee(identity.Name, true);
            //_user = _userRepository.GetEmployee("MWMPG4");
          

      
            int newsId = _newsOfficesRepository.CreateNewsItems(newsItem);
            return RedirectToAction("GetNewsItemsForUser", "NewsItems");
            ////return CreatedAtRoute("GetNewsItem",
            ////              new { id = newsId },
            ////              newsItem);
        }
        [HttpGet("DeleteNewsItem/{id}")]
        public IActionResult DeleteNewsItem(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            NewsItem newsitem = _newsOfficesRepository.GetNewsItem(id);
            _newsOfficesRepository.DeleteNewsItem(newsitem);
            return NoContent();
        }
        // GET api/NewsItems/GetUserOffices
        /// <summary>
        /// GET User Offices for newsItem maintenance
        /// </summary>
        /// <remarks> This API get the office(s) of the the Driver Safety Chief or Region Manager or the office manager.  The will pick all offices or select individual offices 
        ///    Values for employee type are:
        ///      D = Driver Safety Chief....will get all driver safety offices in the state 
        ///      R = Regional Manager....will get all driver safety offices in the manager's region
        ///      O = office Manager...will return only that office id  ( not really necessary to use this API)....just pass office id into the DTO of list of offices.
        /// </remarks>
        /// <param name="empid"></param>
        /// <param name="employeetype"></param>
    
        /// <returns>JSON</returns>

        [HttpGet("GetUserOffices/{empid}/{employeetype}")]
        public IActionResult GetUserOffices(int empid, string employeetype)
        {
            if (empid == 0)
            {
                return BadRequest();
            }
            if (employeetype == null || employeetype == "")
            {
                return BadRequest();
            }
            if (employeetype != "D" & employeetype != "R" & employeetype != "O")
            {
                return BadRequest();
            }
            // _user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
            List<RegionOfficeDTO> offices = new List<RegionOfficeDTO>();
            RegionOfficeDTO office = new RegionOfficeDTO();
       
            switch (employeetype)
            {
                case "D":
                    offices = _dSOfficeRepository.GetRegionOffices(empid, "D");
                    break;
                case "R":
                    offices = _dSOfficeRepository.GetRegionOffices(empid, "R");
                    break;
                case "O":
                    office.OfficeId = _user.CdOffId;
                    offices.Add(office);
                    break;
                default:
                    break;
            }
            return Ok(offices);
        }

    }
}