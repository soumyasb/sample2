﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.CaseClosure;
using DSA_API.Services.CaseClosure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DSA_API.Controllers.CaseClosure
{
    [Produces("application/json")]
    [Route("api/CaseClosure")]
    public class CaseClosureController : Controller
    {
        //private IConfiguration _configuration { get; }
        private ICaseClosureRepository _ccRepo;
        private DSAContext _context;
        //private IUserRepository _userRepository;
        private Employee _user;

        public CaseClosureController(
              DSAContext context, ICaseClosureRepository CCRepo)
        {
            _ccRepo = CCRepo;
            //_configuration = configuration;
            _context = context;
            //_userRepository = userRepository;
        }

        // GET: Get all Cases
        [HttpGet("GetAllCases/{EmpId}")]
        public IActionResult GetAllCases(int EmpId)
        {
            //TODO

            return Ok();
        }
        //// GET: Get all Cases
        //[HttpGet("GetAllCases/{EmpId}")]
        //public IActionResult GetStayInfo(string reason, string TypeActionOne, string TypeActionTwo)
        //{
        //    //TODO
        //    string stay = "";
        //    var s = _context.CaseClosureFormIndex
        //        .Where(c => c.ReasonCode == reason && c.TypeAction1 == TypeActionOne && c.TypeAction2 == TypeActionTwo)
        //        .ToList();
        //    if(s == null)
        //    {
        //        stay = "";
        //    }
        //    else if (s.Count == 1)
        //    {
        //        stay = s.First().StayIndicator;
        //    }
        //    else if (s.Count == 2)
        //    {
        //        stay = "B";
        //    }
        //    return Ok(stay);
        //}


        //[HttpGet("GetCCForm")]
        //public IActionResult GetCCForm(string reason, string TypeActionOne, string TypeActionTwo, string Stay, string HType)
        //{
        //    //Validation
        //    //TODO: Validate the parameters

        //    var ccForm = new CCForm();

        //    var formCode = _context.CaseClosureFormIndex
        //        .Where(c => c.ReasonCode == reason && 
        //                    c.TypeAction1 == TypeActionOne && 
        //                    c.TypeAction2 == TypeActionTwo && 
        //                    c.StayIndicator == Stay).FirstOrDefault().FormId;

        //    ccForm = _ccRepo.GetCCForm(formCode);

        //    // Addition Changes to the form
        //    switch (ccForm.FormID)
        //    {
        //        case "13A":
        //        case "13B":
        //        case "1366A":
        //        case "1366B":
        //        case "14A":
        //        case "14B":
        //        case "1466A":
        //        case "1466B":
        //        case "15A":
        //        case "15B":
        //        case "1566A":
        //        case "1566B":
        //            if (HType == "4" || HType == "7")
        //            {
        //                ccForm.FirstAuthSect1.Text = "14105";
        //                ccForm.FirstOriginalAuthSect.Text = "14103";
        //            }
        //            else if (HType == "1")
        //            {
        //                ccForm.FirstAuthSect1.Text = "141055";
        //                ccForm.FirstOriginalAuthSect.Text = "14105";
        //            }

        //            break;
        //        case "15H":
        //            if (HType == "4" || HType == "7")
        //            {
        //                ccForm.FirstAuthSect1.Text = "14105";
        //                ccForm.FirstOriginalAuthSect.Text = "13953";
        //            }
        //            else if (HType == "1")
        //            {
        //                ccForm.FirstAuthSect1.Text = "141055";
        //                ccForm.FirstOriginalAuthSect.Text = "14105";
        //            }

        //            break;

        //        default:
        //            break;
        //    }

        //    return Ok(ccForm);
        //}

        [HttpPost("UpdateDecision")]
        [ProducesResponseType(422)]
        public IActionResult UpdateDecision([FromBody] CCUpdateDTO CCUpdate)
        {
            // TODO: Validate
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            var DsrCase = _context.Dsrcase.Where(c => c.CdCase == CCUpdate.CaseNumber).FirstOrDefault();
            string HType = DsrCase.CdHrngTyp;
            string Reason = DsrCase.CdRsn;

            //var Hearing = _context.Contact.Where(c => c.CdCase == CCUpdate.CaseNumber).ToList();

            //Populate aditional defult values
            switch (CCUpdate.Form.FormID)
            {
                //case "":
                //    if(HType == "4" || HType == "7")
                //    {
                //        CCUpdate.Form.FirstAuthSect1.Text = "14105";
                //        CCUpdate.Form.FirstOriginalAuthSect.Text = "14103";
                //    }
                //    else if (HType == "1")
                //    {
                //        CCUpdate.Form.FirstAuthSect1.Text = "141055";
                //        CCUpdate.Form.FirstOriginalAuthSect.Text = "14105";
                //    }

                //    break;
                case "9A":
                    CCUpdate.Form.FirstAuthSect1.Text = "12809B";
                    break;
                default:
                    break;
            }


            // Get TCodes

            // Process TCodes
            string ProcessId = CCUpdate.TypeActionTwo + CCUpdate.TypeActionTwo;









            return Ok();
        }

        class DUPClass
        {
            public string TypeAction { get; set; }
            public string Reason { get; set; }
            public string AuthorSect { get; set; }
            public DateTime EffectiveDate { get; set; }
            public DateTime MailDate { get; set; }
            public string CountyCode { get; set; }
        }
        class DUWClass
        {
            public string TypeAction { get; set; }
            public DateTime MailDate { get; set; }
            public string FieldFile { get; set; }

        }
        class DUZClass
        {
            public string  TypeAction { get; set; }
            public string StaySecondAuthSect { get; set; }
            public string FirstAuth { get; set; }
            public string  SecondAuth { get; set; }
            public string OriginalAuth { get; set; }
            public DateTime EffectiveDate { get; set; }
            public string ThroughDate { get; set; }
            public string OrigEffectiveDate { get; set; }
            public DateTime MailDate { get; set; }
            public string COFO { get; set; }
            public string UpdateCopies { get; set; }
            public string Restrictions { get; set; }
            public string LicenseLocation { get; set; }
            public string Reason { get; set; }
            public string CommercialIndicator { get; set; }
            public string OSDL { get; set; }
            public string OSCODE { get; set; }


        }
        class DUJClass
        {
            public string DueDate { get; set; }
            public string TypeInput { get; set; }
            public string Reason { get; set; }
            public string Dest { get; set; }

        }
        private void ProcessTCode(string TCode, string ProcessID, CCUpdateDTO CCUpdate, string Reason, string HearingType)
        {
            switch (TCode)
            {
                case "DAM":




                    break;

                case "DUP":
                    DUPClass dup = new DUPClass();

                    // Reason Code
                    dup.Reason = Reason;
                    switch (ProcessID)
                    {
                        case "9":

                            dup.Reason = Reason;
                            break;
                        //case "":
                        //    dup.Reason = "";
                        //    break;
                        //case "":
                        //    dup.Reason = "" // Another place;
                        //    break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    //Type Action
                    switch (ProcessID)
                    {
                        case "9":
                        case "10":
                            dup.TypeAction = CCUpdate.TypeActionOne;
                            break;
                        case " ":
                            dup.TypeAction = CCUpdate.TypeActionTwo;
                            break;
                        case "":
                            dup.TypeAction = "XX";
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    //AuthorSect

                    if (new[] { "9", "10" }.Contains(ProcessID))
                    {
                        dup.AuthorSect = CCUpdate.Form.FirstAuthSect1.Text;
                    }

                    // Effective Date

                    if (new[] { "9", "10" }.Contains(ProcessID))
                    {
                        dup.EffectiveDate = CCUpdate.Form.FirstEffectiveDate.CCDate.Value;
                    }
                    

                    //Mail Date
                    dup.MailDate = CCUpdate.Form.MailDate.CCDate.Value;

                    //
                    break;


                case "DUW":
                    DUWClass duw = new DUWClass();
                    //TypeAction
                    switch (ProcessID)
                    {
                        case "":
                            duw.TypeAction = CCUpdate.TypeActionOne;
                            break;
                        case " ":
                            duw.TypeAction = CCUpdate.TypeActionTwo;
                            break;
                        case "9":
                            duw.TypeAction = "XX";
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }
                    //Mail Date
                    switch (ProcessID)
                    {
                        case "":
                            duw.MailDate = CCUpdate.Form.MailDate.CCDate.Value;
                            break;
                        case "9":
                            duw.TypeAction = "";
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    // NO FieldFile in the new app
                    duw.FieldFile = "";

                    break;
                    
                case "DUZ":
                case "DUZ1":
                case "DUZ2":
                    DUZClass duz = new DUZClass();
                    // ReasonCode
                    switch (ProcessID)
                    {
                        case "13":
                        case "1366":
                        case "14":
                        case "1466":
                        case "15":
                        case "1566":
                            duz.Reason = Reason;
                            break;
                        case " ":
                            duz.Reason = CCUpdate.Form.SecondReasonCode.Text;
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }
                    //TypeAction
                    switch (ProcessID)
                    {
                        // Double DUZ
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                                duz.TypeAction = CCUpdate.TypeActionOne;
                            else if (TCode == "DUZ2")
                                duz.TypeAction = CCUpdate.TypeActionTwo;
                            else
                            { }//TODO: error - not supported
                              
                            break;
                        case "13":
                        case "14":
                        case "15":
                            duz.TypeAction = CCUpdate.TypeActionOne;
                            break;
                        case "":
                            duz.TypeAction = CCUpdate.TypeActionTwo;
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }
                    // Stay
                    switch (ProcessID)
                    {
                        // Double DUZ
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1" && CCUpdate.Stay == "Y")
                            {
                                if (HearingType == "5")
                                {
                                    duz.StaySecondAuthSect = "4";
                                }
                                else
                                {
                                    duz.StaySecondAuthSect = "5";
                                }

                            }
                            else if (TCode == "DUZ2")
                            {
                                duz.StaySecondAuthSect = "";
                            }

                            else
                            {
                                //TODO: error - not supported
                            }

                            break;
                        case "13":
                        case "14":
                        case "15":
                            if (CCUpdate.Stay == "Y")
                            {
                                if(HearingType == "5")
                                {
                                    duz.StaySecondAuthSect = "4";
                                }
                                else
                                {
                                    duz.StaySecondAuthSect = "5";
                                }
                            }
                                
                            break;
                        case "":
                            duz.StaySecondAuthSect = "";
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }
                    // Authority Section
                    switch (ProcessID)
                    {
                        case "13":
                        case "1366":
                        case "14":
                        case "1466":
                        case "15":
                        case "1566":
                            duz.FirstAuth = CCUpdate.Form.FirstAuthSect1.Text;
                            break;
                        case " ":
                            duz.FirstAuth = CCUpdate.Form.SecondAuthSect1.Text;
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }
                    // Original Authority Section and Date
                    switch (ProcessID)
                    {
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                            {   duz.OriginalAuth = CCUpdate.Form.FirstOriginalAuthSect.Text;
                                duz.OrigEffectiveDate = CCUpdate.Form.OriginalEffectiveDate.CCDate.ToString();
                            }
                            else if (TCode == "DUZ2")
                            {
                                duz.OriginalAuth = "";
                                duz.OrigEffectiveDate = "";
                            }
                            else
                            { } // Error Unsuported TCode Action
                            break;
                        case "13":
                        case "14":
                        case "15":
                            duz.OriginalAuth = CCUpdate.Form.FirstOriginalAuthSect.Text;
                            duz.OrigEffectiveDate = CCUpdate.Form.OriginalEffectiveDate.CCDate.ToString();
                            break;
                        case " ":
                            duz.OriginalAuth = "";
                            duz.OrigEffectiveDate = "";
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    // Effective Date
                    switch (ProcessID)
                    {
                        // Double DUZ
                        
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                            {
                                duz.EffectiveDate = CCUpdate.Form.FirstEffectiveDate.CCDate.Value;
                            }   
                            else if (TCode == "DUZ2")
                            {
                                duz.EffectiveDate = CCUpdate.Form.SecondEffectiveDate.CCDate.Value;
                            }
                            else
                            { } // Error Unsuported TCode Action
                            break;
                        case "13":
                        case "1366":
                        case "14":
                        case "15":
                            duz.EffectiveDate = CCUpdate.Form.FirstEffectiveDate.CCDate.Value;
                            break;
                        case "":
                            duz.EffectiveDate = CCUpdate.Form.SecondEffectiveDate.CCDate.Value;
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    // Through Date
                    switch (ProcessID)
                    {
                        // Double DUZ
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                                if (ProcessID == "1366")
                                    duz.ThroughDate = "";
                                else
                                    duz.ThroughDate = CCUpdate.Form.FirstThroughDate.Text;
                            else if (TCode == "DUZ2")
                            {
                                duz.ThroughDate = CCUpdate.Form.SecondThroughDate.Text;
                            }
                            else
                            { } // Error Unsuported TCode Action
                            break;
                        case "13":
                            duz.ThroughDate = "";
                            break;

                        case "14":
                        case "15":
                            duz.ThroughDate = CCUpdate.Form.FirstThroughDate.Text;
                            break;
                        case "":
                            duz.ThroughDate = CCUpdate.Form.SecondThroughDate.Text;
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    // Original Effective Date
                    //
                    // See Original Auth ^^^^^^^^

                    // Restrictions
                    switch (ProcessID)
                    {
                        // Double DUZ
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                                duz.Restrictions = "";
                            else if (TCode == "DUZ2")
                            {
                                if (CCUpdate.Form.IsAdd.Field)
                                    duz.Restrictions = "A"
                                            + CCUpdate.Form.Restriction1.Text.Trim()
                                            + CCUpdate.Form.Restriction1.Text.Trim()
                                            + CCUpdate.Form.Restriction1.Text.Trim();
                                //else if (CCUpdate.Form.IsDelete.Field)
                                //    duz.Restrictions = "D"
                                //            + CCUpdate.Form.Restriction1.Text.Trim()
                                //            + CCUpdate.Form.Restriction1.Text.Trim()
                                //            + CCUpdate.Form.Restriction1.Text.Trim();
                                else
                                    duz.Restrictions = "";
                            }
                            else
                            { } // Error Unsuported TCode Action
                            break;
                        case "13":
                        case "14":
                        case "15":
                            if (CCUpdate.Form.IsAdd.Field)
                                duz.Restrictions = "A"
                                        + CCUpdate.Form.Restriction1.Text.Trim()
                                        + CCUpdate.Form.Restriction1.Text.Trim()
                                        + CCUpdate.Form.Restriction1.Text.Trim();
                            else if (CCUpdate.Form.IsDelete.Field)
                                duz.Restrictions = "D"
                                        + CCUpdate.Form.Restriction1.Text.Trim()
                                        + CCUpdate.Form.Restriction1.Text.Trim()
                                        + CCUpdate.Form.Restriction1.Text.Trim();
                            else
                                duz.Restrictions = "";
                            break;

                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }
                    // Licence Location
                    switch (ProcessID)
                    {
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                            {
                                duz.LicenseLocation = CCUpdate.Form.LicenceLocation.Text;
                            }
                            else
                            {
                                duz.LicenseLocation = "";
                            }
                            break;
                        case "14":
                        case "15":
                            duz.LicenseLocation = CCUpdate.Form.LicenceLocation.Text;
                            break;
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    // Commercial Indicator
                    switch (ProcessID)
                    {
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1" && CCUpdate.Form.CommercialStatusIndicator.Text != "N")
                            {
                                duz.LicenseLocation = CCUpdate.Form.LicenceLocation.Text;
                            }
                            else
                            {
                                duz.LicenseLocation = "";
                            }
                            break;                        
                        default:
                            if (CCUpdate.Form.CommercialStatusIndicator.Text == "N")
                            {
                                duz.CommercialIndicator = "";
                            }
                            else
                            {
                                duz.CommercialIndicator = CCUpdate.Form.CommercialStatusIndicator.Text;
                            }
                            break;
                    }
                    
                    // CoFo
                    switch (ProcessID)
                    {
                        case "1366":
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                            {
                                duz.COFO = CCUpdate.Form.CoFo.Text;
                            }
                            else
                            {
                                duz.LicenseLocation = "";
                            }
                            break;
                        default:
                            duz.COFO = CCUpdate.Form.CoFo.Text;
                            break;
                    }

                    // OS DL
                    switch (ProcessID)
                    {
                        case "1466":
                        case "1566":
                            if (TCode == "DUZ1")
                            {
                                duz.OSDL = CCUpdate.Form.OSDLNumber.Text;
                                duz.OSCODE = CCUpdate.Form.OSCode.Text;
                            }
                            else
                            {
                                duz.OSDL = "";
                                duz.OSCODE = "";
                            }
                            break;
                        default:
                            duz.OSDL = CCUpdate.Form.OSDLNumber.Text;
                            duz.OSCODE = CCUpdate.Form.OSCode.Text;
                            break;
                    }





                    break;
                case "DUJ":
                    DUJClass duj = new DUJClass();
                    switch (ProcessID)
                    {
                        case "13":
                        case "15":
                            duj.DueDate = CCUpdate.Form.MedicalSuspenceDueDate.Text;
                            duj.TypeInput = "A";
                            duj.Reason = "67";
                            //duj.Dest = RequesterCode; // Need a requester code
                            break;
                        
                        default:
                            // TODO: ERROR - Unsuported
                            break;
                    }

                    break;

                default:
                    break;
            }

        }
    }
}