﻿using DSA_API.Entities;
using DSA_API.Models.Home;
using DSA_API.Services;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

namespace DSA_API.Controllers.Home
{
    [Produces("application/json")]
    [Route("api/HomePage")]
    public class HomePageController : Controller
    {
        private IHomePageRepository _homePageRepository;
        private INewsItemRepository _newsItemRepository;
        private IUserRepository _userRepository;
        private IDSOfficeRepository _dSOfficeRepository;
        private Employee _user;
        private Dsoffice _office;
        private ILogger<HomePageController> _logger;

        public HomePageController(IHomePageRepository homePageRepository, INewsItemRepository newsItemRepository, IUserRepository userRepository, 
            IDSOfficeRepository dSOfficeRepository, ILogger<HomePageController> logger)
        {
            _homePageRepository = homePageRepository;
            _newsItemRepository = newsItemRepository;
            _userRepository = userRepository;
            _dSOfficeRepository = dSOfficeRepository;
            _logger = logger;
        }
       
        [HttpGet(Name = "Index")]
 
        public IActionResult Index()
        {
            // _identity = (ClaimsIdentity)User.Identity;

            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee(identity.Name, true);



            _user = _userRepository.GetEmployee("MWMPG4");
            _logger.LogInformation(100, $"User {_user.CdLgnId} logged in at {DateTime.Now} ");
            var dSOfficeDTO = _dSOfficeRepository.getDSOffice(_user.CdOffId);
            _office = _dSOfficeRepository.convertDSOffice(dSOfficeDTO);
            if (_user == null)
            {
                return NotFound();
            }
            var homePageDTO = new HomePageDTO
            {
                EmpID = _user.EmpId,
                EmpInitial = _user.CdEmpId,
                EmpType = _user.CdEmpTyp,
                FirstName = _user.NmeFrstPrsn,
                LastName = _user.NmeSurnmePrsn,
                LoginId = _user.CdLgnId
            };

            if (_user.FlgLoan == "1" && _user.DtLoanStrt <= DateTime.Now && _user.DtLoanEnd >= DateTime.Now)
            {
                homePageDTO.LoanFlag = _user.FlgLoan;
                homePageDTO.LoanOfficeId = _user.CdLoanOff;
                homePageDTO.Office = _office;
            }
            else
            {
                homePageDTO.OfficeId = _user.CdOffId;
                homePageDTO.Office = _office;
            }

            switch (homePageDTO.EmpType)
            {
                case "A":
                    homePageDTO.Classification = "Administrator";
                    break;
                case "D":
                    homePageDTO.Classification = "Driver Safety Chief";
                    break;
                case "E":
                    homePageDTO.Classification = "Elevated SMVT";
                    break;
                case "H":
                    homePageDTO.Classification = "Hearing Officer";
                    break;
                case "M":
                    homePageDTO.Classification = "Manager";
                    break;
                case "O":
                    homePageDTO.Classification = "Office Manager";
                    break;
                case "R":
                    homePageDTO.Classification = "Regional Manager";
                    break;
                case "S":
                    homePageDTO.Classification = "Support Staff";
                    break;
                case "V":
                    homePageDTO.Classification = "SMVT";
                    break;
                default:
                    homePageDTO.Classification = "Unknown";
                    break;
            }

            //int suspensecount;
            homePageDTO.Suspense = _homePageRepository.GetEmployeeSuspense(homePageDTO.EmpInitial);
            homePageDTO.SuspenseCount = homePageDTO.Suspense.Count();
            int newscount;
            homePageDTO.News = _newsItemRepository.GetNewsItems(_user.CdOffId, out newscount);
            homePageDTO.NewsCount = newscount;
            return Ok(homePageDTO);

        }
    }
}