﻿using DSA_API.Models.Customer;
using DSA_API.Models.InquiryTCodes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Cors;
using DSA_API.Helpers;
using System.Web;

using DSA_API.Entities;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;

namespace DSA_API.Controllers.Inquiry
{
    [Produces("application/json")]
    [Route("api/Inquiry")]

    public class InquiryController : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public InquiryController(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }

        // POST api/getD26
        /// <summary>
        /// GET D26 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="d26dto"></param>
        /// <returns>JSON</returns>
        [HttpPost("getD26")]
        [Produces("text/plain")]
        //  [ValidateAntiForgeryToken]
        public IActionResult getD26([FromBody] D26DTO d26dto)
        {
            string dlNumber = d26dto.DLNumber;
            string outputType = "application/json";
            string json;
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                                        
                    var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
        // POST api/geth6
        /// <summary>
        /// GET H6 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="h6dto"></param>
        /// <returns>JSON</returns>
        [HttpPost("geth6")]
        //  [ValidateAntiForgeryToken]
        public IActionResult geth6([FromBody] H6DTO h6dto)
        {
            string dlNumber = h6dto.DLNumber;
            string outputType = "application/json";
            string json;
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("inquiry/DAD/H6/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
        // POST api/geth6
        /// <summary>
        /// GET H6 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="dlNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("geth6")]
        //  [ValidateAntiForgeryToken]
        public IActionResult geth6(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("inquiry/DAD/H6/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                        if (json == "null")
                            json = "Information not found for DL Number";
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
        // GET api/getME1
        /// <summary>
        /// GET ME1 Information for driver
        /// </summary>
        /// <remarks> This API will get ME1 information from the driver record</remarks>
        /// <param name="dlNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("getME1/{dlNumber}")]
        //  [ValidateAntiForgeryToken]
        public IActionResult getME1(string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("ME1/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                        if (json == "null")
                            json = "Information not found for DL Number";
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }

        // POST api/getDLInq data
        /// <summary>
        /// GET DL Inq TCode Information for driver
        /// </summary>
        /// <remarks> This API will get DL Inq TCode information from the driver record</remarks>
        /// <param name="dlInqdto"></param>
        /// <returns>JSON</returns>
        [HttpPost("getDLInqData")]
        //  [ValidateAntiForgeryToken]
        public IActionResult getDLInqData([FromBody] InquiryDTO dlInqdto)
        {
            string tCode = dlInqdto.TCode;
            string outputType = "application/json";
            string json;
            // dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            var response = new HttpResponseMessage();
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    switch (tCode)
                    {
                        case "DAD":
                        case "DA2":
                        case "DAK":
                        case "DF1":
                        case "DM3":
                            response = client.GetAsync("inquiry/" + tCode + "/" + dlInqdto.InfoCode + "/" + dlInqdto.ParameterObj.DLNumber).Result;
                            break;
                        case "A01":
                        case "A04":
                        case "ANI":
                            if(dlInqdto.ParameterObj.Zone == "")
                            {
                                dlInqdto.ParameterObj.Zone = "test";
                            }
                            response = client.GetAsync("aTCodes/" + dlInqdto.TCode + "/" + dlInqdto.InfoCode + "/"+ dlInqdto.ParameterObj.Name.Split(",")[0]+ "/" + dlInqdto.ParameterObj.Name.Split(",")[1] + "/" + dlInqdto.ParameterObj.BirthDate + "/" + dlInqdto.ParameterObj.Address + "/" +dlInqdto.ParameterObj.City + "/" +dlInqdto.ParameterObj.Zone).Result;
                            break;
                        case "ME1":
                        case "DLD":
                        case "LTR":
                            if (dlInqdto.TCode == "ME1" && dlInqdto.ParameterObj.ThreeCharacterLastName == "")
                            {
                                dlInqdto.ParameterObj.ThreeCharacterLastName = "test";
                            }
                            if (dlInqdto.TCode == "LTR" && dlInqdto.ParameterObj.DLNumber == "" && dlInqdto.ParameterObj.ThreeCharacterLastName == "")
                            {
                                dlInqdto.ParameterObj.ThreeCharacterLastName = "test";
                                dlInqdto.ParameterObj.DLNumber = "test";
                            }
                            response = client.GetAsync("ME1DLDLTR/" + dlInqdto.TCode + "/" + dlInqdto.ParameterObj.DLNumber + "/" + dlInqdto.ParameterObj.ThreeCharacterLastName).Result;
                            break;
                        case "DCI":
                        case "R60":
                        case "R67":
                            if(dlInqdto.TCode == "DCI" && dlInqdto.InfoCode == "" && dlInqdto.FileCode == "" && dlInqdto.ParameterObj.VLNumber == "")
                            {
                                dlInqdto.InfoCode = "test";
                                dlInqdto.FileCode = "test";
                                dlInqdto.ParameterObj.VLNumber = "test";
                            }
                            else
                            {
                                dlInqdto.ParameterObj.CourtNumber1 = "test";
                                dlInqdto.ParameterObj.CourtNumber2 = "test";
                                dlInqdto.ParameterObj.CourtNumber3 = "test";
                            }
                            response = client.GetAsync("RTCodesAndDCI/" + dlInqdto.TCode + "/" + dlInqdto.InfoCode + "/" + dlInqdto.FileCode + "/" + dlInqdto.ParameterObj.VLNumber + "/" + dlInqdto.ParameterObj.CourtNumber1 + "/" + dlInqdto.ParameterObj.CourtNumber2 + "/" + dlInqdto.ParameterObj.CourtNumber3).Result;
                            break;
                        case "HRP":
                            {
                                HRPDTO DTO = new HRPDTO()
                                {                              
                                    HRPDLNUMBER = dlInqdto.ParameterObj.DLNumber,
                                    HRPNAME = dlInqdto.ParameterObj.ThreeCharacterLastName,
                                    HRPTACODE = dlInqdto.ParameterObj.TACode,
                                    HRPREASONCODE = dlInqdto.ParameterObj.ReasonCode,
                                    HRPEFFECTIVEDATE = dlInqdto.ParameterObj.EffectiveDate,
                                    HRPAUTHSEC1 = dlInqdto.ParameterObj.AuthSec1,
                                    HRPAUTHSEC2 = dlInqdto.ParameterObj.AuthSec2,
                                    HRPAUTHSEC3 = dlInqdto.ParameterObj.AuthSec3
                                };

                                response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "inquiry/HRP/" + dlInqdto.ParameterObj.DLNumber, DTO).Result;
                            }
                            break;
                        default:
                            break;
                    }

                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }



            return Ok(json);
        }


        // GET api/getDAD
        /// <summary>
        /// GET DAD infocodes Information for driver
        /// </summary>
        /// <remarks> This API will get DAD infocodes information from the driver record</remarks>
        /// <param name="dlNumber"></param>
        ///  <param name="infoCode"></param>
        /// <returns>JSON</returns>
        [HttpGet("getDAD")]
        //  [ValidateAntiForgeryToken]
        public IActionResult getDLInquiry(string tCode, string infoCode, string dlNumber)
        {
            dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            var response = new HttpResponseMessage();

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);

                    switch (tCode)
                    {
                        case "DAD":
                        case "DA2":
                        case "DAK":
                        case "DF1":
                        case "DM3":
                            response = client.GetAsync("inquiry/"+tCode+"/"+infoCode+"/"+dlNumber).Result;
                            break;
                        default:
                            break;
                    }



                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                        if (json == "null")
                            json = "Information not found for DL Number";
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
    }
}