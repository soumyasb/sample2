﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Common;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;


namespace DSA_API.Controllers.MEProcessing
{
    [Produces("application/json")]
    [Route("api/ME5")]
    public class ME5Controller : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public ME5Controller(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber, string lastName)
        {
            //dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //if (dlNumber == null)
            //{
            //    return NotFound();
            //}
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "99999";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            ME5InitDTO dto = new ME5InitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DLNumber = dlNumber;
            dto.ThreeCharacterName = lastName.Substring(0, 3).ToUpper();

            IdentityDTO identity = new IdentityDTO();
            identity.RequestorCode = requestorCode;
            identity.EmployeeInitials = employeeThreeDigit;
            identity.NetName = netName;
            identity.RacfID = loginId;
            getMEInfo me1 = new getMEInfo(dto.DLNumber, identity, _configuration);
            var message = me1.GetME1Data();
            if (message.Contains("Medical and Self Certificate Information: NONE"))
            {
                dto.Message = "Medical and Self Certificate Information: NONE";
                return Ok(dto);
            }
            var results = StringFunctions.GetValueFromMessage("STATUS CODE", "<BR/>", message);
            dto.Status = results.Substring(0, 1);
            if (dto.Status == "I")
            {
                dto.StatusMessage = "Status - Invalid Med Cert";
            }
            else if (dto.Status == "N")
            {
                dto.StatusMessage = "Status - Non Current Med Cert";
            }
            else
            {
                dto.StatusMessage = "Status - Current Med Cert";
            }
            results = StringFunctions.GetValueFromMessage("ISSUE DATE", "<BR/>", message);
            dto.MedCertIssueDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("EXPIRATION DATE", "<BR/>", message);
            dto.MedCertExpireDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("MED EXAMINER NUMBER", "<BR/>", message);
            dto.ExaminerLicense = results.Substring(4, 14).Trim();
            dto.ExaminerState = results.Substring(0, 2);

            return Ok(dto);
        }
        // POST api/ME5
        /// <summary>
        /// POST A ME5 Transaction
        /// </summary>
        /// <remarks> This API will post a ME5 transaction to the driver record</remarks>
        /// <param name="me5"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessME5")]
        public IActionResult ProcessME5([FromBody] ME5UIDTO me5)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            //string tempIssueDate = me2dto.MedCertIssueDate.ToString("MMddyyyy");
            //string tempExpireDate = me2dto.MedCertExpireDate.ToString("MMddyyyy");
            //string tempReceiveDate = me2dto.MedCertReceivedDate.ToString("MMddyyyy");
            ME5UpdateDTO DTO = new ME5UpdateDTO()
            {
                SBAREQCODE = me5.RequestorCode,
                SBADLNUMBER = me5.DLNumber,
                SBANAME = me5.ThreeCharacterLastName,
                SBAISSUEDATE = me5.MedCertIssueDate.ToString("MMddyyyy"),
                SBAEXPIREDATE = me5.MedCertExpireDate.ToString("MMddyyyy"),
                SBALICENSESTATE = me5.ExaminerState,
                SBALICENSENUMBER = me5.ExaminerLicense,
                SBAMARKINVALID = "I"
            };

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", me5.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", me5.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/ME5/" + me5.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                        {
                            if (DTO.StatusMessage.Contains("MED EXP DATE UPDATED"))
                            {
                                var x = _commonRepository.UpdateDLStats(me5.Operator, me5.DLNumber, "ME5", me5.ThreeCharacterLastName);
                            }
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }

            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            me5.Error = DTO.Error;
            me5.ME5Response = "ME5 - " + DTO.StatusMessage;
            return Ok(me5);
        }
    }
}