﻿using DSA_API.Models.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DSA_API.Controllers.MEProcessing
{
    [Produces("application/json")]
    [Route("api/ME1")]
    public class ME1Controller : Controller
    {
        private IConfiguration _configuration { get; }
        public ME1Controller(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        // POST api/getME1
        /// <summary>
        /// GET Medical Certification Information for driver
        /// </summary>
        /// <remarks> This API will get Medical Certification information from the driver record</remarks>
        /// <param name="dlNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("getME1")]
        //  [ValidateAntiForgeryToken]
        public IActionResult getME1(string dlNumber)
        {
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            IdentityDTO identity = new IdentityDTO();
            identity.EmployeeInitials = "MPG";
            identity.NetName = "#ADMV6LI";
            identity.RacfID = "MWMPG4";
            identity.RequestorCode = "86301";
            getMEInfo me1 = new getMEInfo(dlNumber, identity, _configuration);
            var results = me1.GetME1Data();
            return Ok(results);
        }
    }
}