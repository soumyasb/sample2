﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace DSA_API.Controllers.DLUpdates
{
    [Produces("application/json")]
    [Route("api/ME2")]
    public class ME2Controller : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public ME2Controller(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber, string lastName)
        {
            //dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //if (dlNumber == null)
            //{
            //    return NotFound();
            //}
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "99999";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            ME2InitDTO dto = new ME2InitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DLNumber = dlNumber;
            dto.ThreeCharacterName = lastName.Substring(0, 3).ToUpper();

            //dto.Birthdate = birthdate;
            var restrictions = new List<SelectListItem>();
            restrictions.Add(new SelectListItem() { Text = "Wearing corrective lenses.", Value = "1" });
            restrictions.Add(new SelectListItem() { Text = "Wearing hearing aid.", Value = "2" });
            restrictions.Add(new SelectListItem() { Text = "Accompanied by a waiver / exemption.", Value = "3" });
            restrictions.Add(new SelectListItem() { Text = "Driving within an exempt intra city zone.", Value = "4" });
            restrictions.Add(new SelectListItem() { Text = "Accompanied by a Skill Performance Evaluation certificate (SPE).", Value = "5" });
            dto.RestrictionCodes = restrictions;

            var suffix = new List<SelectListItem>();
            suffix.Add(new SelectListItem() { Text = "JR", Value = "JR" });
            suffix.Add(new SelectListItem() { Text = "SR", Value = "SR" });
            suffix.Add(new SelectListItem() { Text = "I", Value = "I" });
            suffix.Add(new SelectListItem() { Text = "II", Value = "II" });
            suffix.Add(new SelectListItem() { Text = "III", Value = "III" });
            suffix.Add(new SelectListItem() { Text = "IV", Value = "IV" });
            suffix.Add(new SelectListItem() { Text = "V", Value = "V" });
            suffix.Add(new SelectListItem() { Text = "VI", Value = "VI" });
            suffix.Add(new SelectListItem() { Text = "VII", Value = "VII" });
            suffix.Add(new SelectListItem() { Text = "VIII", Value = "VIII" });
            suffix.Add(new SelectListItem() { Text = "IX", Value = "IX" });
            suffix.Add(new SelectListItem() { Text = "1ST", Value = "1ST" });
            suffix.Add(new SelectListItem() { Text = "2ND", Value = "2ND" });
            suffix.Add(new SelectListItem() { Text = "3RD", Value = "3RD" });
            suffix.Add(new SelectListItem() { Text = "4TH", Value = "4TH" });
            suffix.Add(new SelectListItem() { Text = "5TH", Value = "5th" });
            suffix.Add(new SelectListItem() { Text = "6TH", Value = "6TH" });
            suffix.Add(new SelectListItem() { Text = "7TH", Value = "7th" });
            suffix.Add(new SelectListItem() { Text = "8TH", Value = "8TH" });
            suffix.Add(new SelectListItem() { Text = "9TH", Value = "9th" });
            dto.ExaminerSuffix = suffix;

            var title = new List<SelectListItem>();
            title.Add(new SelectListItem() { Text = "Advance Practice Nurse", Value = "AN" });
            title.Add(new SelectListItem() { Text = "Chiropractor", Value = "CH" });
            title.Add(new SelectListItem() { Text = "Osteopathic Doctor", Value = "DO" });
            title.Add(new SelectListItem() { Text = "Medical Doctor", Value = "MD" });
            title.Add(new SelectListItem() { Text = "Physician Assistant", Value = "PA" });
            title.Add(new SelectListItem() { Text = "Other", Value = "XX" });
            dto.ExaminerTitle = title;

            var selfcert = new List<SelectListItem>();
            selfcert.Add(new SelectListItem() { Text = "NA", Value = "NA" });
            selfcert.Add(new SelectListItem() { Text = "NI", Value = "NI" });
            dto.SelfCertCode = selfcert;

            var states = new List<SelectListItem>();
            states.Add(new SelectListItem() { Text = "Alabama", Value = "AL" });
            states.Add(new SelectListItem() { Text = "AK-Alaska", Value = "AK" });
            states.Add(new SelectListItem() { Text = "AZ-Arizona", Value = "AZ" });
            states.Add(new SelectListItem() { Text = "AR-Arkansas", Value = "AR" });
            //states.Add (new SelectListItem() { Text = "California", value = "CA"}); Exclude California.  Select out-of - states only.
            states.Add(new SelectListItem() { Text = "CO-Colorado", Value = "CO" });
            states.Add(new SelectListItem() { Text = "CT-Connecticut", Value = "CT" });
            states.Add(new SelectListItem() { Text = "DE-Delaware", Value = "DE" });
            states.Add(new SelectListItem() { Text = "DC-District of Columbia", Value = "DC" });
            states.Add(new SelectListItem() { Text = "FL-Florida", Value = "FL" });
            states.Add(new SelectListItem() { Text = "GA-Georgia", Value = "GA" });
            states.Add(new SelectListItem() { Text = "HI-Hawaii", Value = "HI" });
            states.Add(new SelectListItem() { Text = "ID-Idaho", Value = "ID" });
            states.Add(new SelectListItem() { Text = "IL-Illinois", Value = "IL" });
            states.Add(new SelectListItem() { Text = "IN-Indiana", Value = "IN" });
            states.Add(new SelectListItem() { Text = "IA-Iowa", Value = "IA" });
            states.Add(new SelectListItem() { Text = "KS-Kansas", Value = "KS" });
            states.Add(new SelectListItem() { Text = "KY-Kentucky", Value = "KY" });
            states.Add(new SelectListItem() { Text = "LA-Louisiana", Value = "LA" });
            states.Add(new SelectListItem() { Text = "ME-Maine", Value = "ME" });
            states.Add(new SelectListItem() { Text = "MD-Maryland", Value = "MD" });
            states.Add(new SelectListItem() { Text = "MA-Massachusetts", Value = "MA" });
            states.Add(new SelectListItem() { Text = "MI-Michigan", Value = "MI" });
            states.Add(new SelectListItem() { Text = "MN-Minnesota", Value = "MN" });
            states.Add(new SelectListItem() { Text = "MS-Mississippi", Value = "MS" });
            states.Add(new SelectListItem() { Text = "MO-Missouri", Value = "MO" });
            states.Add(new SelectListItem() { Text = "MT-Montana", Value = "MT" });
            states.Add(new SelectListItem() { Text = "NE-Nebraska", Value = "NE" });
            states.Add(new SelectListItem() { Text = "NV-Nevada", Value = "NV" });
            states.Add(new SelectListItem() { Text = "NH-New Hampshire", Value = "NH" });
            states.Add(new SelectListItem() { Text = "NJ-New Jersey", Value = "NJ" });
            states.Add(new SelectListItem() { Text = "NM-New Mexico", Value = "NM" });
            states.Add(new SelectListItem() { Text = "NY-New York", Value = "NY" });
            states.Add(new SelectListItem() { Text = "NC-North Carolina", Value = "NC" });
            states.Add(new SelectListItem() { Text = "ND-North Dakota", Value = "ND" });
            states.Add(new SelectListItem() { Text = "OH-Ohio", Value = "OH" });
            states.Add(new SelectListItem() { Text = "OK-Oklahoma", Value = "OK" });
            states.Add(new SelectListItem() { Text = "OR-Oregon", Value = "OR" });
            states.Add(new SelectListItem() { Text = "PA-Pennsylvania", Value = "PA" });
            states.Add(new SelectListItem() { Text = "RI-Rhode Island", Value = "RI" });
            states.Add(new SelectListItem() { Text = "SC-South Carolina", Value = "SC" });
            states.Add(new SelectListItem() { Text = "SD-South Dakota", Value = "SD" });
            states.Add(new SelectListItem() { Text = "TN-Tennessee", Value = "TE" });
            states.Add(new SelectListItem() { Text = "TX-Texas", Value = "TX" });
            states.Add(new SelectListItem() { Text = "UT-Utah", Value = "UT" });
            states.Add(new SelectListItem() { Text = "VT-Vermont", Value = "VT" });
            states.Add(new SelectListItem() { Text = "VA-Virginia", Value = "VA" });
            states.Add(new SelectListItem() { Text = "WA-Washington", Value = "WA" });
            states.Add(new SelectListItem() { Text = "WV-West Virginia", Value = "WV" });
            states.Add(new SelectListItem() { Text = "WI-Wisconsin", Value = "WI" });
            states.Add(new SelectListItem() { Text = "WY-Wyoming", Value = "Wy" });

            dto.States = states;

            dto.CheckCA = true;

            return Ok(dto);
        }
        // POST api/ME2
        /// <summary>
        /// POST A ME2 Transaction
        /// </summary>
        /// <remarks> This API will post a ME2 transaction to the driver record</remarks>
        /// <param name="me2"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessME2")]
        public IActionResult ProcessME2([FromBody] ME2UIDTO me2)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var results = ProcessME2Transaction(me2);
            if (results.Error)
            {
                return Ok(results);
            }
            else
            {
                var x = _commonRepository.UpdateDLStats(me2.Operator, me2.DLNumber, "ME2", me2.ThreeCharacterLastName);


                if (me2.InValid == true)
                {
                    results = ProcessME5Transaction(me2);
                    if (results.Error)
                    {
                        return Ok(results);
                    }
                    x = _commonRepository.UpdateDLStats(me2.Operator, me2.DLNumber, "ME5", me2.ThreeCharacterLastName);
                }


                if (me2.SelfCertCode != "")
                {
                    results = ProcessME6Transaction(me2);
                    if (results.Error)
                    {
                        return Ok(results);
                    }
                    x = _commonRepository.UpdateDLStats(me2.Operator, me2.DLNumber, "ME6", me2.ThreeCharacterLastName);
                }
            }
            return Ok(results);
        }
        private ME2UIDTO ProcessME2Transaction(ME2UIDTO me2dto)
        {
            var testdate = "";
            //if (_env.IsDevelopment())
            //{
            //    testdate = DSA_API.Globals.Globals.DCSTestDate;
            //}
            string netName = "#ADMV6LI";

            //string tempIssueDate = me2dto.MedCertIssueDate.ToString("MMddyyyy");
            //string tempExpireDate = me2dto.MedCertExpireDate.ToString("MMddyyyy");
            //string tempReceiveDate = me2dto.MedCertReceivedDate.ToString("MMddyyyy");
            ME2UpdateDTO DTO = new ME2UpdateDTO()
            {
                SBAREQCODE = me2dto.RequestorCode,
                SBADLNUMBER = me2dto.DLNumber,
                SBANAME = me2dto.ThreeCharacterLastName,
                SBAISSUEDATE = me2dto.MedCertIssueDate.ToString("MMddyyyy"),
                SBAEXPIREDATE = me2dto.MedCertExpireDate.ToString("MMddyyyy"),
                SBALICENSESTATE = me2dto.ExaminerState,
                SBALICENSENUMBER = me2dto.ExaminerLicense,
                SBAREGISTRYNUMBER = me2dto.NationalRegistry,
                SBASPECIALTY = me2dto.ExaminerTitle,
                SBAAREACODE = me2dto.ExaminerPhoneNumber.Substring(0, 3),
                SBAPREFIX = me2dto.ExaminerPhoneNumber.Substring(3, 3),
                SBANUMBER = me2dto.ExaminerPhoneNumber.Substring(6, 4),
                SBAEXAMLASTNAME = me2dto.ExaminerLastName.ToUpper(),
                SBAEXAMFIRSTNAME = me2dto.ExaminerFirstName.ToUpper(),
                SBAEXAMMIDDLENAME = me2dto.ExaminerMiddleName.ToUpper(),
                SBAEXAMSUFFIX = me2dto.ExaminerSuffix,
                SBACODE1 = me2dto.Restr1,
                SBACODE2 = me2dto.Restr2,
                SBACODE3 = me2dto.Restr3,
                SBACODE4 = me2dto.Restr4,
                SBACODE5 = me2dto.Restr5,
                SBACODE6 = me2dto.Restr6,
                SBACODE7 = me2dto.Restr7,
                SBACODE8 = me2dto.Restr8,
                SBACODE9 = me2dto.Restr9,
                SBACODE10 = me2dto.Restr10,
                SBARECEIVEDDATE = me2dto.MedCertReceivedDate.ToString("MMddyyyy"),
                SBAMARKINVALID = me2dto.InValid == true ? "I" : ""
            };

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", me2dto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", me2dto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/ME2/" + me2dto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }

            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            me2dto.Error = DTO.Error;
            me2dto.ME2Response = "ME2 - " + DTO.StatusMessage;
            return me2dto;
        }
        private ME2UIDTO ProcessME5Transaction(ME2UIDTO me2dto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            ME5UpdateDTO DTO = new ME5UpdateDTO()
            {
                SBAREQCODE = me2dto.RequestorCode,
                SBADLNUMBER = me2dto.DLNumber,
                SBANAME = me2dto.ThreeCharacterLastName,
                SBAISSUEDATE = me2dto.MedCertIssueDate.ToString("MMddyyyy"),
                SBAEXPIREDATE = me2dto.MedCertExpireDate.ToString("MMddyyyy"),
                SBALICENSESTATE = me2dto.ExaminerState,
                SBALICENSENUMBER = me2dto.ExaminerLicense,
                SBAMARKINVALID = me2dto.InValid == true ? "I": ""
            };
            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", me2dto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", me2dto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", me2dto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/ME5/" + me2dto.DLNumber, DTO);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            me2dto.Error = DTO.Error;
            me2dto.ME5Response = "ME5 - " + DTO.StatusMessage;

            return me2dto;
        }

  
        private ME2UIDTO ProcessME6Transaction(ME2UIDTO me2dto)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            ME6UpdateDTO DTO = new ME6UpdateDTO()
            {
                SBAREQCODE = me2dto.RequestorCode,
                SBADLNUMBER = me2dto.DLNumber,
                SBANAME = me2dto.ThreeCharacterLastName.ToUpper(),
                SBASELFCERTCODE= me2dto.SelfCertCode,
                SBASELFCERTRECEIVEDATE = me2dto.MedCertReceivedDate.ToString("MMddyyyy"),
                SBAACTION = me2dto.PurgeFlag == "1" ? "P": " "
            };
            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", me2dto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", me2dto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", me2dto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/ME6/" + me2dto.DLNumber, DTO);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            me2dto.Error = DTO.Error;
            me2dto.ME6Response = "ME6 - " + DTO.StatusMessage;

            return me2dto;
        }

       
    }
}