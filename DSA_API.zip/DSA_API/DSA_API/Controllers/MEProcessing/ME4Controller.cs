﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Common;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;


namespace DSA_API.Controllers.MEProcessing
{
    [Produces("application/json")]
    [Route("api/ME4")]
    public class ME4Controller : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public ME4Controller(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber, string lastName)
        {
            //dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //if (dlNumber == null)
            //{
            //    return NotFound();
            //}
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
            string requestorCode = "99999";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;

            ME4InitDTO dto = new ME4InitDTO();
            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DLNumber = dlNumber;
            dto.ThreeCharacterName = lastName.Substring(0, 3).ToUpper();

            //dto.Birthdate = birthdate;
            var restrictions = new List<SelectListItem>();
            restrictions.Add(new SelectListItem() { Text = "Wearing corrective lenses.", Value = "1" });
            restrictions.Add(new SelectListItem() { Text = "Wearing hearing aid.", Value = "2" });
            restrictions.Add(new SelectListItem() { Text = "Accompanied by a waiver / exemption.", Value = "3" });
            restrictions.Add(new SelectListItem() { Text = "Driving within an exempt intra city zone.", Value = "4" });
            restrictions.Add(new SelectListItem() { Text = "Accompanied by a Skill Performance Evaluation certificate (SPE).", Value = "5" });
            dto.RestrictionCodes = restrictions;

            var waivers = new List<SelectListItem>();
            waivers.Add(new SelectListItem() { Text = "Vision Exemption.", Value = "V" });
            waivers.Add(new SelectListItem() { Text = "Diabetes Exemption.", Value = "D" });
            waivers.Add(new SelectListItem() { Text = "Both Vision and Diabetes.", Value = "B" });

            dto.WaiverTypeSelect = waivers;

            var suffixSelect = new List<SelectListItem>();
            suffixSelect.Add(new SelectListItem() { Text = "JR", Value = "JR" });
            suffixSelect.Add(new SelectListItem() { Text = "SR", Value = "SR" });
            suffixSelect.Add(new SelectListItem() { Text = "I", Value = "I" });
            suffixSelect.Add(new SelectListItem() { Text = "II", Value = "II" });
            suffixSelect.Add(new SelectListItem() { Text = "III", Value = "III" });
            suffixSelect.Add(new SelectListItem() { Text = "IV", Value = "IV" });
            suffixSelect.Add(new SelectListItem() { Text = "V", Value = "V" });
            suffixSelect.Add(new SelectListItem() { Text = "VI", Value = "VI" });
            suffixSelect.Add(new SelectListItem() { Text = "VII", Value = "VII" });
            suffixSelect.Add(new SelectListItem() { Text = "VIII", Value = "VIII" });
            suffixSelect.Add(new SelectListItem() { Text = "IX", Value = "IX" });
            suffixSelect.Add(new SelectListItem() { Text = "1ST", Value = "1ST" });
            suffixSelect.Add(new SelectListItem() { Text = "2ND", Value = "2ND" });
            suffixSelect.Add(new SelectListItem() { Text = "3RD", Value = "3RD" });
            suffixSelect.Add(new SelectListItem() { Text = "4TH", Value = "4TH" });
            suffixSelect.Add(new SelectListItem() { Text = "5TH", Value = "5th" });
            suffixSelect.Add(new SelectListItem() { Text = "6TH", Value = "6TH" });
            suffixSelect.Add(new SelectListItem() { Text = "7TH", Value = "7th" });
            suffixSelect.Add(new SelectListItem() { Text = "8TH", Value = "8TH" });
            suffixSelect.Add(new SelectListItem() { Text = "9TH", Value = "9th" });
            dto.ExaminerSuffixSelect = suffixSelect;

            var titleSelect = new List<SelectListItem>();
            titleSelect.Add(new SelectListItem() { Text = "Advance Practice Nurse", Value = "AN" });
            titleSelect.Add(new SelectListItem() { Text = "Chiropractor", Value = "CH" });
            titleSelect.Add(new SelectListItem() { Text = "Osteopathic Doctor", Value = "DO" });
            titleSelect.Add(new SelectListItem() { Text = "Medical Doctor", Value = "MD" });
            titleSelect.Add(new SelectListItem() { Text = "Physician Assistant", Value = "PA" });
            titleSelect.Add(new SelectListItem() { Text = "Other", Value = "XX" });
            dto.ExaminerTitleSelect = titleSelect;
            
            IdentityDTO identity = new IdentityDTO();
            identity.RequestorCode = requestorCode;
            identity.EmployeeInitials = employeeThreeDigit;
            identity.NetName = netName;
            identity.RacfID = loginId;
            getMEInfo me1 = new getMEInfo(dto.DLNumber, identity, _configuration);
            var message = me1.GetME1Data();
            if (message.Contains("Medical and Self Certificate Information: NONE"))
            {
                dto.Message = "Medical and Self Certificate Information: NONE";
                return Ok(dto);
            }
            var results = StringFunctions.GetValueFromMessage("STATUS CODE", "<BR/>", message);
            dto.Status = results.Substring(0, 1);
            if (dto.Status == "I")
            {
                dto.StatusMessage = "Status - Invalid Med Cert";
            }
            else if (dto.Status == "N")
            {
                dto.StatusMessage = "Status - Non Current Med Cert";
            }
            else
            {
                dto.StatusMessage = "Status - Current Med Cert";
            }
            results = StringFunctions.GetValueFromMessage("ISSUE DATE", "<BR/>", message);
            dto.MedCertIssueDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("EXPIRATION DATE", "<BR/>", message);
            dto.MedCertExpireDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("MED EXAMINER NUMBER", "<BR/>", message);
            dto.ExaminerLicense = results.Substring(4, 14).Trim();
            dto.ExaminerState = results.Substring(0, 2);
            results = StringFunctions.GetValueFromMessage("MED CERT REC'D DATE", "<BR/>", message);
            dto.MedCertReceiptDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("MED CERT RESTRICTIONS", "<BR/>", message);
            dto.Restr1 = results.Substring(0, 1).Trim();
            dto.Restr2 = results.Substring(2, 1).Trim();
            dto.Restr3 = results.Substring(4, 1).Trim();
            dto.Restr4 = results.Substring(6, 1).Trim();
            dto.Restr5 = results.Substring(8, 1).Trim();
            dto.Restr6 = results.Substring(10, 1).Trim();
            dto.Restr7 = results.Substring(12, 1).Trim();
            dto.Restr8 = results.Substring(14, 1).Trim();
            dto.Restr9 = results.Substring(16, 1).Trim();
            dto.Restr10 = results.Substring(18, 1).Trim();
            results = StringFunctions.GetValueFromMessage("DRIVER WAIVER TYPE", "<BR/>", message);
            dto.WaiverType = results.Substring(0, 1).Trim();
            var s = results.Substring(0, 1);
            if (s != " ")
                dto.WaiverType = s;
            else
                dto.WaiverType = null;
            results = StringFunctions.GetValueFromMessage("EFF DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.WaiverEffectiveDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.WaiverEffectiveDate = null;
            results = StringFunctions.GetValueFromMessage("EXP DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.WaiverExpirationDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.WaiverExpirationDate = null;
            results = StringFunctions.GetValueFromMessage("RESCIND DT", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.WaiverRescindDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.WaiverRescindDate = null;
            results = StringFunctions.GetValueFromMessage("SPE EFF DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.SPEEffectiveDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.SPEEffectiveDate = null;
            results = StringFunctions.GetValueFromMessage("SPE EXP DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.SPEExpirationDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.SPEExpirationDate = null;
            results = StringFunctions.GetValueFromMessage("SPE CANCEL DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.SPECancelDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.SPECancelDate = null;
            results = StringFunctions.GetValueFromMessage("LAST_NAME", "<BR/>", message);
            s = results.Substring(0, 40).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.ExaminerLastName = results.Substring(0, 40).Trim();
            else
                dto.ExaminerLastName = null;
            results = StringFunctions.GetValueFromMessage("FIRST_NAME", "<BR/>", message);
            s = results.Substring(0, 40).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.ExaminerFirstName = results.Substring(0, 40).Trim();
            else
                dto.ExaminerFirstName = null;
            results = StringFunctions.GetValueFromMessage("MIDDLE_NAME", "<BR/>", message);
            s = results.Substring(0, 35).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.ExaminerMiddleName = results.Substring(0, 35).Trim();
            else
                dto.ExaminerMiddleName = null;
            results = StringFunctions.GetValueFromMessage("SUFFIX", "<BR/>", message);
            s = results.Substring(0, 5).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.ExaminerSuffix = results.Substring(0, 5).Trim();
            else
                dto.ExaminerSuffix = null;
            results = StringFunctions.GetValueFromMessage("SPECIALTY", "<BR/>", message);
            s = results.Substring(0, 2).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.ExaminerTitle = results.Substring(0, 2).Trim();
            else
                dto.ExaminerTitle = null;
            results = StringFunctions.GetValueFromMessage("MED EXAMINER PHONE NUMBER", "<BR/>", message);
            s = results.Substring(0, 10).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.ExaminerPhoneNumber = "(" + results.Substring(0, 3) + ")" + results.Substring(3,3) + "-" + results.Substring(6,4);
            else
                dto.ExaminerPhoneNumber = null;
            results = StringFunctions.GetValueFromMessage("MED REGISTRY NUMBER", "<BR/>", message);
            s = results.Substring(0, 14).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.NationalRegistry = results.Substring(0,14);
            else
                dto.NationalRegistry = null;
            return Ok(dto);
        }
        // POST api/ME4
        /// <summary>
        /// POST A ME4 Transaction
        /// </summary>
        /// <remarks> This API will post a ME4 transaction to the driver record</remarks>
        /// <param name="me4"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessME4")]
        public IActionResult ProcessME4([FromBody] ME4UIDTO me4)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            //string tempIssueDate = me2dto.MedCertIssueDate.ToString("MMddyyyy");
            //string tempExpireDate = me2dto.MedCertExpireDate.ToString("MMddyyyy");
            //string tempReceiveDate = me2dto.MedCertReceivedDate.ToString("MMddyyyy");
            ME4UpdateDTO DTO = new ME4UpdateDTO()
            {
                SBAREQCODE = me4.RequestorCode,
                SBANAME = me4.ThreeCharacterLastName,
                SBADLNUMBER = me4.DLNumber,
                SBAISSUEDATE = me4.MedCertIssueDate.ToString("MMddyyyy"),
                SBAEXPIREDATE = me4.MedCertExpireDate.ToString("MMddyyyy"),
                SBALICENSESTATE = me4.ExaminerState,
                SBALICENSENUMBER = me4.ExaminerLicense,
                SBARECEIVEDDATE = me4.MedCertReceiptDate.ToString("MMddyyyy"),
                SBAPURGE = me4.Purge == true ? "P" : "",
                SBACODE1 = me4.Restr1,
                SBACODE2 = me4.Restr2,
                SBACODE3 = me4.Restr3,
                SBACODE4 = me4.Restr4,
                SBACODE5 = me4.Restr5,
                SBACODE6 = me4.Restr6,
                SBACODE7 = me4.Restr7,
                SBACODE8 = me4.Restr8,
                SBACODE9 = me4.Restr9,
                SBACODE10 = me4.Restr10,
                SBAWAIVERTYPE = me4.WaiverType,
                SBAWAIVEREFFECTIVEDATE = me4.WaiverEffectiveDate,
                SBAWAIVEREXPIRATIONDATE = me4.WaiverExpirationDate,
                SBAWAIVERRESCINDDATE = me4.WaiverRescindDate,
                SBASPEEFFECTIVEDATE = me4.SPEEffectiveDate,
                SBASPEEXPIRATIONDATE = me4.SPEExpirationDate,
                SBASPECANCELDATE = me4.SPECancelDate,
                SBAEXAMLASTNAME = me4.ExaminerLastName.ToUpper(),
                SBAEXAMFIRSTNAME = me4.ExaminerFirstName.ToUpper(),
                SBAEXAMMIDDLENAME = me4.ExaminerMiddleName.ToUpper(),
                SBAEXAMSUFFIX = me4.ExaminerSuffix,
                SBASPECIALTY = me4.ExaminerTitle,
                SBAAREACODE = me4.ExaminerPhoneNumber.Substring(0,3),
                SBAPREFIX = me4.ExaminerPhoneNumber.Substring(3,3),
                SBANUMBER = me4.ExaminerPhoneNumber.Substring(6,4),
                SBAREGISTRYNUMBER = me4.NationalRegistry
            };

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", me4.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", me4.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/me4/" + me4.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                        else
                        {
                            if (DTO.StatusMessage.Contains("DB2 UPDATED"))
                            {
                                var x = _commonRepository.UpdateDLStats(me4.Operator, me4.DLNumber, "ME4", me4.ThreeCharacterLastName);
                            }
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }

            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            me4.Error = DTO.Error;
            me4.ME4Response = "ME4 - " + DTO.StatusMessage;
            return Ok(me4);
        }
    }
}