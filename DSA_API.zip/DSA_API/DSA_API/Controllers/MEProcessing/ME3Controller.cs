﻿using DSA_API.Entities;
using DSA_API.Services;
using DSA_API.Models.UpdateTCodes;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using DSA_API.Models.Common;
using DSA_API.Helpers;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;

namespace DSA_API.Controllers.MEProcessing
{
    [Produces("application/json")]
    [Route("api/ME3")]
    public class ME3Controller : Controller
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public ME3Controller(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        // GET: InitialPage
        [HttpGet("InitialPage")]
        public IActionResult InitialPage(string dlNumber, string lastName)
        {
            //dlNumber = StringFunctions.ConvertUpperCaseFirst(dlNumber);
            //if (dlNumber == null)
            //{
            //    return NotFound();
            //}
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            //var d26Model = getD26(dlNumber);
            //if (d26Model == "null")
            //{
            //    return NotFound();
            //}
            //var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);

            //var lastname = dlResults.lastName;
            //var birthdate = dlResults.BirthDate;
           
            string requestorCode = "99999";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            string loginId = _user.CdLgnId;
            ME3InitDTO dto = new ME3InitDTO();

            dto.RequestorCode = requestorCode;
            dto.Operator = employeeThreeDigit;
            dto.NetName = netName;
            dto.LoginId = _user.CdLgnId;
            dto.DLNumber = dlNumber;
            dto.ThreeCharacterName = lastName.Substring(0, 3).ToUpper();

            //dto.Birthdate = birthdate;
            var waivers = new List<SelectListItem>();
            waivers.Add(new SelectListItem() { Text = "Vision Exemption.", Value = "V" });
            waivers.Add(new SelectListItem() { Text = "Diabetes Exemption.", Value = "D" });
            waivers.Add(new SelectListItem() { Text = "Both Vision and Diabetes.", Value = "B" });
       
            dto.WaiverTypeSelect = waivers;
            IdentityDTO identity = new IdentityDTO();
            identity.RequestorCode = requestorCode;
            identity.EmployeeInitials = employeeThreeDigit;
            identity.NetName = netName;
            identity.RacfID = loginId;
           
            getMEInfo me1 = new getMEInfo(dto.DLNumber,  identity, _configuration);
            var message = me1.GetME1Data();
            if (message.Contains("Medical and Self Certificate Information: NONE"))
            {
                dto.Message = "Medical and Self Certificate Information: NONE";
                return Ok(dto);
            }
            var results = StringFunctions.GetValueFromMessage("STATUS CODE", "<BR/>", message);
            dto.Status = results.Substring(0, 1);
            if (dto.Status == "I")
            {
                dto.StatusMessage = "Status - Invalid Med Cert";
            }
            else if (dto.Status == "N")
            {
                dto.StatusMessage = "Status - Non Current Med Cert";
            }
            else 
            {
                dto.StatusMessage = "Status - Current Med Cert";
            }
            results = StringFunctions.GetValueFromMessage("ISSUE DATE", "<BR/>", message);
            dto.MedCertIssueDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("EXPIRATION DATE", "<BR/>", message);
            dto.MedCertExpireDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            results = StringFunctions.GetValueFromMessage("MED EXAMINER NUMBER", "<BR/>", message);
            dto.ExaminerLicense = results.Substring(4, 14).Trim();
            dto.ExaminerState = results.Substring(0,2);

            results = StringFunctions.GetValueFromMessage("DRIVER WAIVER TYPE", "<BR/>", message);
            dto.WaiverType = results.Substring(0, 1).Trim();
            var s = results.Substring(0, 1);
            if ( s != " ")
                dto.WaiverType = s;
            else
                dto.WaiverType = null;
            results = StringFunctions.GetValueFromMessage("EFF DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.WaiverEffectiveDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.WaiverEffectiveDate = null;
            results = StringFunctions.GetValueFromMessage("EXP DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.WaiverExpirationDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.WaiverExpirationDate = null;
            results = StringFunctions.GetValueFromMessage("RESCIND DT", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.WaiverRescindDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.WaiverRescindDate = null;
            results = StringFunctions.GetValueFromMessage("SPE EFF DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.SPEEffectiveDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.SPEEffectiveDate = null;
            results = StringFunctions.GetValueFromMessage("SPE EXP DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.SPEExpirationDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.SPEExpirationDate = null;
            results = StringFunctions.GetValueFromMessage("SPE CANCEL DATE", "<BR/>", message);
            s = results.Substring(0, 1).Trim();
            if (!string.IsNullOrEmpty(s))
                dto.SPECancelDate = results.Substring(5, 5) + "-" + results.Substring(0, 4);
            else
                dto.SPECancelDate = null;
            return Ok(dto); ;
        }
        // POST api/ME3
        /// <summary>
        /// POST A ME3 Transaction
        /// </summary>
        /// <remarks> This API will post a ME2 transaction to the driver record</remarks>
        /// <param name="me3"></param>
        /// <returns>JSON</returns>
        [HttpPost("ProcessME3")]
        public IActionResult ProcessME3([FromBody] ME3UIDTO me3)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            //string tempIssueDate = me2dto.MedCertIssueDate.ToString("MMddyyyy");
            //string tempExpireDate = me2dto.MedCertExpireDate.ToString("MMddyyyy");
            //string tempReceiveDate = me2dto.MedCertReceivedDate.ToString("MMddyyyy");
            ME3UpdateDTO DTO = new ME3UpdateDTO()
            {
                SBAREQCODE = me3.RequestorCode,
                SBADLNUMBER = me3.DLNumber,
                SBASTATUS = me3.Status,
                SBAOPERATOR = me3.Operator,
                SBAISSUEDATE = me3.MedCertIssueDate.ToString("MMddyyyy"),
                SBAEXPIREDATE = me3.MedCertExpireDate.ToString("MMddyyyy"),
                SBALICENSESTATE = me3.ExaminerState,
                SBALICENSENUMBER = me3.ExaminerLicense,
                SBAWAIVERTYPE = me3.WaiverType,
                SBAWAIVEREFFECTIVEDATE = me3.WaiverEffectiveDate,
                SBAWAIVEREXPIRATIONDATE = me3.WaiverExpirationDate,
                SBAWAIVERRESCINDDATE = me3.WaiverRescindDate,
                SBASPEEFFECTIVEDATE = me3.SPEEffectiveDate,
                SBASPEEXPIRATIONDATE = me3.SPEExpirationDate,
                SBASPECANCELDATE = me3.SPECancelDate
            };

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", me3.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", me3.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/ME3/" + me3.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                        else
                        {
                            if (DTO.StatusMessage.Contains("WAIVER/EXEMPTION UPDATED"))
                            {
                                var x = _commonRepository.UpdateDLStats(me3.Operator, me3.DLNumber, "ME3", me3.ThreeCharacterLastName);
                            }
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }

            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            me3.Error = DTO.Error;
            me3.ME3Response = "ME3 - " + DTO.StatusMessage;
            return Ok(me3);
        }
    }
    
}