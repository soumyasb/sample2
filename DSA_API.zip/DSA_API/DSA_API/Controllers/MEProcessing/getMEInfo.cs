﻿using DSA_API.Helpers;
using DSA_API.Models.Common;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace DSA_API.Controllers.MEProcessing
{
    public class getMEInfo
    {
        //private string _requestorCode;
        //private string _netname;
        //private string _empInitials;
        //private string _racfID;
        private string _dlNumber;
        private IdentityDTO _id;
        private IConfiguration _configuration { get; }
        public getMEInfo(string dlNumber, IdentityDTO id, IConfiguration configuration)
        {
            _dlNumber = dlNumber;
            _id = id; 
            _configuration = configuration;
        }
        public string GetME1Data()
        {
            IConfiguration configuration;
            _dlNumber = StringFunctions.ConvertUpperCaseFirst(_dlNumber);
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            //string requestorCode = "86301";
            //string netName = "#ADMV6LI";
            //string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", _id.NetName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", _id.RacfID);
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", _id.EmployeeInitials);
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", _id.RequestorCode);
                    var response = client.GetAsync("ME1/" + _dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                        if (json == "null")
                            json = "Information not found for DL Number";
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return json;
        }

    }
}
