﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/Oipsearch")]

    public class OipsearchController : Controller
    {
        private IOIPRepository _OipRepository;
       
        public OipsearchController(IOIPRepository oIPRepository)
        {
            _OipRepository = oIPRepository;
        }
        [HttpPost("{caseNumber}")]
        public IEnumerable<OIPDTO> Post([FromBody] OIPDTO oipdto, string caseNumber)
        {
            

            switch (oipdto.CDPRTYTYP)
            {
                case "N":
                    return _OipRepository.InterpreterAgencySearch(oipdto, caseNumber);
                case "M":
                    return _OipRepository.InterpreterOIPPersonSearch(oipdto, caseNumber);
                case "L":
                    return _OipRepository.LawEnforcementAgencySearch(oipdto, caseNumber);
                default:
                    return _OipRepository.OIPPersonSearchByType(oipdto, caseNumber);
            }


        }
    }
}