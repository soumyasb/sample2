﻿using DSA_API.Entities;
using DSA_API.Models.Customer;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Models;
using DSA_API.Services;
using DSA_API.Helpers;
using DSA_API.Globals;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;

namespace DSA_API.Controllers.Case
{

    [Produces("application/json")]
    [Route("api/Case")]
     public class CaseController : Controller
    {
        private ICustomerRepository _customerRepository;
        private ICaseRepository _caseRepository;
        private IOIPRepository _oIPRepository;
        private ISearchRepository _searchRepository;
        private IUserRepository _userRepository;
        private ICommonRepository _commomRepository;
        private IUrlHelper _urlHelper;
        private UserDTO _user;
        private IConfiguration _configuration { get; }
        private IHostingEnvironment _env;

        public CaseController(ICaseRepository caseRepository,
            ICustomerRepository customerRepository,
            IOIPRepository oIPRepository,
            ISearchRepository searchRepository,
            IUserRepository userRepository,
            ICommonRepository commonRepository,
            IUrlHelper urlHelper,
            IConfiguration configuration,
            IHostingEnvironment env)
        {
            _caseRepository = caseRepository;
            _customerRepository = customerRepository;
            _oIPRepository = oIPRepository;
            _searchRepository = searchRepository;
            _userRepository = userRepository;
            _commomRepository = commonRepository;
            _urlHelper = urlHelper;
            _configuration = configuration;
            _env = env;
        }
        // GET api/Case/Detail
        /// <summary>
        /// Get case detail 
        /// </summary>
        /// <remarks> This API will retreive case detail for the case number provided</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("{caseNumber}", Name = "Detail")]
        public IActionResult Detail(string caseNumber)
        {
            if (caseNumber == null)
            {
                return NotFound();
            }
        
            var CaseDetailModel = _caseRepository.GetCaseDetails(caseNumber, false);
            var CustModel = _customerRepository.getCustomerDetail(CaseDetailModel.DLNumber);
            CaseDetailModel.CaseComments = _caseRepository.GetCaseComments(caseNumber);
            CaseDetailModel.Customer = CustModel;
            CaseDetailModel.CaseOIPs = new CaseOIPDTO();
            CaseDetailModel.CaseOIPs.OIPs = GetCaseOIPs(caseNumber);
            CaseDetailModel.CaseContacts = _caseRepository.GetCaseContacts(caseNumber);
            CaseDetailModel.EmployeeContacts = _caseRepository.GetCaseEmployeeContacts(caseNumber);
            CaseDetailModel.RescheduleList = _caseRepository.GetCaseReschedules(caseNumber);
            return Ok(CaseDetailModel);
        }
        // POST: Case/CreateNewCase
        [HttpPost("CreateNewCase")]
        public IActionResult CreateNewCase([FromBody] CustomerDTO customer)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");

            if (customer == null)
            {
                return BadRequest();
            }

            CaseDetailForAddDTO caseDetail = new CaseDetailForAddDTO();
            caseDetail.DLNumber = customer.DLNumber;
            caseDetail.FirstName = customer.FirstName;
            caseDetail.LastName = customer.LastName;
            caseDetail.MiddleName = customer.MiddleName;
            caseDetail.DT_BIRTH_PRSN = customer.DT_BIRTH_PRSN;
            caseDetail.Address1 = customer.Address1;
            caseDetail.Address2 = customer.Address2;
            caseDetail.City = customer.City;
            caseDetail.State = customer.State;
            caseDetail.Zip = customer.Zip;
            caseDetail.PhoneNumber = customer.PhoneNumber;
            caseDetail.classLicense = customer.classLicense;
            caseDetail.Accidents = customer.Accidents;
            caseDetail.CaseStatus = "10";
            caseDetail.DT_RCPT = DateTime.Now;
            return Ok(caseDetail);
        }
        // POST api/Case/AddCase
        /// <summary>
        /// POST Case Add 
        /// </summary>
        /// <remarks> This API will add a case </remarks>
        /// <returns>JSON</returns>
        [HttpPost("AddCase")]
        public IActionResult AddCase([FromBody] CaseDetailForAddDTO caseDetail)
        {
            if (caseDetail == null)
            {
                return BadRequest();
            }

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            _user = _userRepository.GetUser("MWMPG4");

            var errors = ValidateCaseDetailsOnAdd(caseDetail);
            if (errors.Count > 0)
            {
                for (int i = 0; i < errors.Count; i++)
                {
                    ModelState.AddModelError(nameof(CaseDetailForAddDTO), errors[i]);
                }
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var result = _caseRepository.AddCase(caseDetail, _user);
            if (result)
            {
                caseDetail.Message = "Case Added - New Case Number: " + caseDetail.CaseNumber;
            }
            else
            {
                ModelState.AddModelError(nameof(CaseDetailForAddDTO), "Case Added - Failed");
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return Ok(caseDetail);          
      
        }
        // POST api/Case/ModifyCase
        /// <summary>
        /// POST Case Modify 
        /// </summary>
        /// <remarks> This API will modify a case </remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpPost("ModifyCase/{caseNumber}")]
        public IActionResult ModifyCase(string caseNumber, [FromBody] CaseDetailDTO caseDetail)
        {
            if (caseNumber == null)
            {
                return BadRequest(); 
            }
            if (caseDetail == null)
            {
                return BadRequest();
            }

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
        
            var errors = ValidateCaseDetails(caseDetail);
            if (errors.Count > 0)
            {
                for (int i = 0; i < errors.Count; i++)
                {
                    ModelState.AddModelError(nameof(CaseDetailDTO), errors[i]);
                }
                return new UnprocessableEntityObjectResult(ModelState);
            }

            HearingReasonCodesDTO codes = new HearingReasonCodesDTO();
            codes = _caseRepository.GetCaseHearingTypeReasonCode(caseNumber);
                
            if ((codes.HearingType != caseDetail.CD_HRNG_TYP)  || (codes.ReasonCode != caseDetail.CD_RSN))
            {
                if (codes.OrigHearingDate != DateTime.MinValue)
                {
                    var lastName = caseDetail.lastName.Substring(0, 3).ToUpper();
                    var formattedDate = codes.OrigHearingDate.ToString("MMddyy");
                    var testDate = "";
                    if (_env.IsDevelopment())
                    {
                        testDate = DSA_API.Globals.Globals.DCSTestDate;
                    }
                    var postObj = new DUVUpdateDTO
                    {
                        SBALASTNAME = lastName,
                        SBADLNUMBER = caseDetail.Customer.DLNumber,
                        SBAHEARTYPE = caseDetail.CD_HRNG_TYP,
                        SBAHEARDT = "",
                        SBAHEARLOC = "",
                        SBANEWREASON = caseDetail.CD_RSN,
                        SBAMATCHDATE = formattedDate,
                        SBAREASON = codes.ReasonCode,
                        SBATESTDATE = testDate
                    };
                    var results = ProcessDUV(postObj);
                    if (results.Error)
                    {
                        ModelState.AddModelError(nameof(CaseDetailDTO), "Case Not Updated - Error processing DUV -  " + results.StatusMessage);
                        return new UnprocessableEntityObjectResult(ModelState);
                    }
                  
                }
            }
            var result = _caseRepository.UpdateCaseDetails(caseDetail, "MPG");
            if (!result)
            {
                ModelState.AddModelError(nameof(CaseDetailDTO), "Case Update error");
                return new UnprocessableEntityObjectResult(ModelState);
            }
            caseDetail.Message = "Case Updated"; 
            return Ok(caseDetail);
            //return CreatedAtRoute("Detail",
            //   new { caseNumber = caseDetail.CaseNumber },
            //   value: caseDetail);
        }
      

        private List<string> ValidateCaseDetails(CaseDetailDTO CaseDetailModel)
        {
            List<string> errors = new List<string>();
            if (CaseDetailModel.CaseStatusCode == "CL" || CaseDetailModel.CaseStatusCode == "UP")
            {
                errors.Add("Cannot modify a case that is closed or updated pending report");
            }
            if (CaseDetailModel.CD_RSN == "" || CaseDetailModel.CD_RSN == null)
            {
                errors.Add("Reason Code required");
            }
            if (CaseDetailModel.CD_REFR_SRCE_TYP == "" || CaseDetailModel.CD_REFR_SRCE_TYP == null)
            {
                errors.Add("Referral Code required");
            }
            if (CaseDetailModel.CD_HRNG_TYP == "" || CaseDetailModel.CD_HRNG_TYP == null)
            {
                errors.Add("Hearing type required");
            }
            if (CaseDetailModel.CD_RSN == "950" & CaseDetailModel.FRCaseNumber == null)
            {
                errors.Add("Financial Responsibility Case required when Reason Code is 950");
            }
            return errors;
        }

      
        private List<string> ValidateCaseDetailsOnAdd(CaseDetailForAddDTO CaseDetailModel)
        {
            List<string> errors = new List<string>();

            if (CaseDetailModel.CD_RSN == "" || CaseDetailModel.CD_RSN == null)
            {
                errors.Add("Reason Code required"); 
            }
            if (CaseDetailModel.CD_HRNG_TYP == "" || CaseDetailModel.CD_HRNG_TYP == null)
            {
                errors.Add("Hearing type required");
            }
            if (CaseDetailModel.CD_RSN == "950" & CaseDetailModel.FRCaseNumber == null)
            {
                errors.Add("Financial Responsibility Case required when Reason Code is 950");
            }
            if ((CaseDetailModel.CD_RSN == "871" || CaseDetailModel.CD_RSN == "875" || CaseDetailModel.CD_RSN == "880" ||
                CaseDetailModel.CD_RSN == "881" || CaseDetailModel.CD_RSN == "882" || CaseDetailModel.CD_RSN == "883" ||
                CaseDetailModel.CD_RSN == "884" || CaseDetailModel.CD_RSN == "885" || CaseDetailModel.CD_RSN == "887" ||
                CaseDetailModel.CD_RSN == "888" || CaseDetailModel.CD_RSN == "889" || CaseDetailModel.CD_RSN == "891" ||
                CaseDetailModel.CD_RSN == "892" || CaseDetailModel.CD_RSN == "894" || CaseDetailModel.CD_RSN == "897" ||
                CaseDetailModel.CD_RSN == "898") & (CaseDetailModel.CD_ENDR == "" || CaseDetailModel.CD_ENDR == null))
            {
                errors.Add("Special Certs/Endorsements Required");
            }

            return errors;
        }
        private DUVUpdateDTO ProcessDUV(DUVUpdateDTO postObj)
        {
                 
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";

            postObj.SBAREQCODE = requestorCode;
            postObj.SBAOPERATOR = employeeThreeDigit;
            string outputType = "application/json";


            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    //var response = client.PostAsJsonAsync("update/DUK/" + NewComment.DLNumber, postObj);
                    var DTOJson = Newtonsoft.Json.JsonConvert.SerializeObject(postObj);
                    var DTOString = new StringContent(DTOJson, System.Text.Encoding.UTF8, "application/json");
                    var response = client.PostAsync("update/DUV/" + postObj.SBADLNUMBER, DTOString);
                    //var response = HttpClientExtensions.PostAsJsonAsync(client, "update/DUV/" + postObj.SBADLNUMBER, postObj);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        postObj.Error = (bool)json["error"];
                        postObj.Title = (string)json["title"];
                        postObj.StatusMessage = (string)json["statusMessage"];
                        if (postObj.Error)
                        {
                            postObj.StatusMessage = postObj.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                        else
                        {
                            var status = _commomRepository.UpdateDLStats(postObj.SBAOPERATOR, postObj.SBADLNUMBER, "DUV", postObj.SBALASTNAME);
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        postObj.Error = (bool)json["error"];
                        postObj.Title = (string)json["title"];
                        postObj.StatusMessage = (string)json["statusMessage"];
                    }
                }
            }
            catch (Exception e)
            {
                postObj.Error = true;
                postObj.StatusMessage = "<br />Unable to connect to MQ Service at this time - contact ISD";
             
            }
            return postObj;
        }
      
        // GET api/Case/Search
        /// <summary>
        /// Search DS database for subject, case 
        /// </summary>
        /// <remarks> This API will search and retreive the DS database for subject and it's cases</remarks>
        /// <param name="keyword"></param>
        /// <returns>JSON</returns>
        [HttpGet("Search/{keyword}")]
        public IActionResult Search(string keyword)
        {
            keyword = keyword.Trim().ToLower();
            var model = _searchRepository.CaseSearch(keyword);
            if (model.ResultCount == 0)
            {
                model.Message = "No results found for your search";
            }
            return Ok(model);
        }

        // POST api/geth6
        /// <summary>
        /// GET H6 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="h6dto"></param>
        /// <returns>JSON</returns>
        [HttpPost("geth6")]
      //  [ValidateAntiForgeryToken]
        public IActionResult geth6([FromBody] H6DTO h6dto)
        {
            string dlNumber = h6dto.DLNumber;
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                   // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("inquiry/DAD/H6/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        ModelState.AddModelError(nameof(H6DTO), "Unable to connect to MQ Service at this time");
                        return new UnprocessableEntityObjectResult(ModelState);
                    }
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError(nameof(H6DTO), "Unable to connect to MQ Service at this time");
                return new UnprocessableEntityObjectResult(ModelState);
            }


            return Ok(json);
        }
        // GET api/Case/GetScheduledCases
        /// <summary>
        /// Get scheduled cases assigned to the user's office 
        /// </summary>
        /// <remarks> This API will retreive scheduled cases for the user's office.
        /// sort 1 - contact start date, dlNumber
        /// sort 2 - Office name, dlNumber
        /// sort 3 - Dl Number
        /// sort 4 - Employee last name, first name, DL number
        /// sort 5 - Person last name, person first name, Dl number
        /// sort 6 - Reason, DL number
        /// sort 7 - Type, Dl number
        /// sort 8 - Location, Dl number</remarks>
        /// <param name="officeid"></param>
        /// <param name="sort"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetScheduledCases")]
        public IActionResult GetScheduledCases(string officeid, string sort = "1")
        {
            //string json = "";
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            //sort = "1";

            //var results = _caseRepository.GetScheduledCases(identity.Name.ToUpper());
            var results = _caseRepository.GetScheduledCases(officeid, sort);
            return Ok(results);
        }
        // GET api/Case/GetUnscheduledCases
        /// <summary>
        /// Get unscheduled cases assigned to the user's office 
        /// </summary>
        /// <remarks> This API will retreive unscheduled cases for the user's office.
        /// sort 1 - Case number, dlNumber
        /// sort 2 - receipt date, dlNumber
        /// sort 3 - Dl Number
        /// sort 4 - location, DL number
        /// sort 5 - Person last name, person first name, Dl number
        /// sort 6 - Reason, DL number
        /// sort 7 - Type, Dl number
        /// sort 8 - DL number, receipt date, reason</remarks>
        /// <param name="officeid"></param>
        /// <param name="sort"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetUnScheduledCases")]
        public IActionResult GetUnScheduledCases(string officeid, string sort)
        {
            var results = _caseRepository.GetUnScheduledCases(officeid, sort);
            return Ok(results);
        }

        //public string jwt()
        //{
        //    string jwt = "eyJ1bmlxdWVfbmFtZSI6Im13ZHdzNCIsIm5hbWVpZCI6Im13ZHdzNCIsIk5ldE5hbWUiOiIjQURNVjJZVCIsIlJlcXVlc3RvckNvZGUiOiI4NjMwMSIsIkVtcGxveWVlSUQiOiIzMjciLCJFbXBsb3llZVRocmVlRGlnaXQiOiJEV1MiLCJyb2xlIjpbIkRTQSIsIkRTQV9SX0RFVkVMT1BFUiIsIklUSU1fUl9VU0VSIl0sImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6MzYzNDAvIiwiZXhwIjoxNDk5MzY1OTU0LCJuYmYiOjE0OTkzNjQxNTR9";
        //    byte[] data = Convert.FromBase64String(jwt);
        //    string decodedString = Encoding.UTF8.GetString(data);
        //    return decodedString;
        //}

        //[System.Web.Http.HttpPost]
        //public string headers()
        //{
        //    var headers = Request.Headers;

        //    return headers.ToString();
        //}


        //public string cookie()
        //{
        //    var cookies = Request.Cookies.Keys;

        //    string output = "";

        //    foreach (var c in cookies)
        //    {
        //        output += c + ", ";
        //    }

        //    return output;
        //}

        // GET api/Case/GetCaseOIPs
        /// <summary>
        /// Get case's Other interested parties
        /// </summary>
        /// <remarks> This API will retreive the cases' OIPs</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        private List<OIPDTO> GetCaseOIPs(string caseNumber)
        {
            List<OIPDTO> OIPs = new List<OIPDTO>();
            OIPs = _caseRepository.GetAssignedOIPs(caseNumber);
            foreach (OIPDTO o in OIPs)
            {
                o.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = o.OIPID, type = o.CDPRTYTYP });
                o.caseAssignURI = _urlHelper.RouteUrl("OIPCaseAssign", new { oipid = o.OIPID, casenumber = caseNumber, type = o.CDPRTYTYP });
            }
            return OIPs;
        }


        // GET api/Case/GetCaseCoverSheet
        /// <summary>
        /// Get case's coversheet data when creating or closing a case.
        /// </summary>
        /// <remarks> This API will retreive the cases' OIPs</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetCaseCoverSheet")]
        public IActionResult GetCaseCoverSheet(string caseNumber)
        {
            CaseCoverSheetDTO coversheet = new CaseCoverSheetDTO();
            coversheet = _caseRepository.GetCaseCoverSheetInfo(caseNumber);
          
            return Ok(coversheet);
        }
        // GET api/Case/GetClosedCaseDetail
        /// <summary>
        /// Get a closed case's (CL or UP Case Status) detail.
        /// </summary>
        /// <remarks> This API will retreive the cases' detail information</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet(" GetClosedCaseDetail")]
        public IActionResult GetClosedCaseDetail(string caseNumber)
        {
            ClosedCaseConvertDetailDTO closedcase = new ClosedCaseConvertDetailDTO();
            closedcase = _caseRepository.GetClosedCaseDetail(caseNumber);

            return Ok(closedcase);
        }

        // GET api/Case/GetCaseSuspense
        /// <summary>
        /// Get a case's suspense information.
        /// </summary>
        /// <remarks> This API will retreive the cases suspense</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet(" GetCaseSuspense")]
        public IActionResult GetCaseSuspense(string caseNumber)
        {
            if (caseNumber == null)
            {
                return BadRequest();
            }

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;


            string employeeThreeDigit = "MPG";

            SuspenseCasesDTO cases = new SuspenseCasesDTO();
            cases = _caseRepository.GetSuspenseCases(caseNumber);
            
            SuspenseCaseEmployeeDTO summary = new SuspenseCaseEmployeeDTO();
            summary = _caseRepository.GetSuspenseEmployee(caseNumber);
            summary.EmployeeRequestor = employeeThreeDigit;
            if (cases.ResultCount > 0)
            {
                for (int i = 0; i < cases.ResultCount; i++)
                {
                    SuspenseDetailDTO detail = new SuspenseDetailDTO();
                    detail.Suspense_ID = cases.results[i].Suspense_ID;
                    detail.NBR_SEQUENCE = cases.results[i].NBR_SEQUENCE;
                    detail.SuspenseDate = cases.results[i].SuspenseDate.ToString("MM-dd-yy");
                    detail.RequestedBy = cases.results[i].RequestedBy;
                    detail.SuspenseReason = cases.results[i].SuspenseReason;
                    detail.UpdatedBy = cases.results[i].UpdatedBy;
                    detail.UpdateDate = cases.results[i].UpdateDate.ToString("MM-dd-yy");
                    detail.SuspenseDescription = cases.results[i].SuspenseDescription;
                    summary.Suspense.Add(detail);
                }
                return Ok(summary);
            }
            else
            {
                return Ok(summary);
            }
         
        }
        // POST api/Case/AddCaseSuspense
        /// <summary>
        /// Add a case suspense.
        /// </summary>
        /// <remarks> This API will add case suspense</remarks>
        /// <returns>JSON</returns>
        [HttpPost(" AddCaseSuspense")]
        public IActionResult AddCaseSuspense([FromBody] SuspenseCaseAddDTO Suspense)
        {


            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            string employeeThreeDigit = "MPG";
            SuspenseCasesDTO cases = new SuspenseCasesDTO();
            cases = _caseRepository.GetSuspenseCases(Suspense.CD_CASE);
            if (cases.ResultCount == 3)
            {
                ModelState.AddModelError(nameof(SuspenseCaseAddDTO),
                   "Case has three suspenses, cannot add more suspense.");
                return new UnprocessableEntityObjectResult(ModelState);
            }
            Suspense.RequestedBy = employeeThreeDigit;
            Suspense.UpdatedBy = employeeThreeDigit;
            Suspense = _caseRepository.AddCaseSuspense(Suspense);
            if (Suspense.ErrorMessage != "")
            {
                ModelState.AddModelError(nameof(SuspenseCaseAddDTO),
                                  Suspense.ErrorMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return Ok(Suspense);
        }
        // POST api/Case/AddCaseSuspense
        /// <summary>
        /// Modify a case suspense.
        /// </summary>
        /// <remarks> This API will modify case suspense</remarks>
        /// <returns>JSON</returns>
        [HttpPost(" ModifyCaseSuspense")]
        public IActionResult ModifyCaseSuspense([FromBody] SuspenseCaseModifyDTO Suspense)
        {


            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            string employeeThreeDigit = "MPG";
            Suspense.RequestedBy = employeeThreeDigit;
            Suspense.UpdatedBy = employeeThreeDigit;
            Suspense = _caseRepository.ModifyCaseSuspense(Suspense);
            if (Suspense.ErrorMessage != "")
            {
                ModelState.AddModelError(nameof(SuspenseCaseAddDTO),
                                  Suspense.ErrorMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return Ok(Suspense);
        }
        // POST api/Case/DeleteCaseSuspense
        /// <summary>
        /// Delete a case suspense.
        /// </summary>
        /// <remarks> This API will delete case suspense</remarks>
        /// <param name="suspenseId"></param>
        /// <returns>JSON</returns>
        [HttpPost(" DeleteCaseSuspense")]
        public IActionResult DeleteCaseSuspense(int suspenseId)
        {


            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
         
            var results = _caseRepository.DeleteCaseSuspense(suspenseId);
            if (!results)
            {
                ModelState.AddModelError("SuspenseDelete",
                                  "Suspensed Delete failed");
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return Ok();
        }
        // GET api/Case/GetCaseScheduledDetail
        /// <summary>
        /// Get a scheduled case detail.
        /// </summary>
        /// <remarks> This API will retreive scheduled case detail - contacts, OIP, reschedules</remarks>
        /// <param name="dlNumber"></param>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetCaseScheduleDetail")]
        public IActionResult GetCaseScheduleDetail(string dlNumber, string caseNumber)
        {
            ScheduledCaseDetailDTO scheduledCaseDetail = new ScheduledCaseDetailDTO();
            scheduledCaseDetail.CaseDetail = _caseRepository.GetCaseDetailForScheduledCase(dlNumber, caseNumber);
            scheduledCaseDetail.OIPs = _caseRepository.GetAssignedOIPs(caseNumber);
            scheduledCaseDetail.Reschedules = _caseRepository.GetCaseReschedules(caseNumber);
            scheduledCaseDetail.EmployeeContacts = _caseRepository.GetCaseEmployeeContacts(caseNumber);
            scheduledCaseDetail.Contacts = _caseRepository.GetCaseContacts(caseNumber);
            return Ok(scheduledCaseDetail);
        }

    }
}
