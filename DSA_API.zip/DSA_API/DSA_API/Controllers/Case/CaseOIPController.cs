﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Cors;
using DSA_API.Helpers;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/CaseOIP")]

    public class CaseOIPController : Controller
    {
        private ICaseRepository _caseRepository;
        private IUrlHelper _urlHelper;
        public CaseOIPController(ICaseRepository caseRepository, IUrlHelper urlHelper)
        {
            _caseRepository = caseRepository;
            _urlHelper = urlHelper;
        }
        [HttpPost]
        public Object Post([FromBody] OIPCaseDTO model )
        {
            //var identity = (ClaimsIdentity)User.Identity;

            OIPDTO newOIP = new OIPDTO();
            OIPDTO OIP;
            newOIP.CDUPDTTECHID = "MPG";
            //newOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            newOIP.CdCase = model.CaseNumber;
            newOIP.OIPID = model.OIPID;
            newOIP.CDPRTYTYP = model.Type;

            
            bool error = true;
           
            //var ResourceURI = new UrlHelper(actionContext);
            string statusMessage = "Error - Unable to assign this OIP to case, or case may already be assigned";
            string title = "OIP Case Assignment";

            bool result = false;

            //  Check for agency vs OIPPerson assigment
            if (model.Type == "N" || model.Type == "L")
            {
                result = _caseRepository.AssignAgencyByCaseNumber(newOIP);
                OIP = _caseRepository.GetAgency(model.OIPID);
            }
            else
            {
                result = _caseRepository.AssignOIPByCaseNumber(newOIP);
                OIP = _caseRepository.GetOIP(model.OIPID);
            }


            if (result)
            {
                error = false;
                statusMessage = "OIP successfully assigned to case: " + model.CaseNumber;
            }
            else
            {
                ModelState.AddModelError(nameof(OIPDTO), statusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
         
            return new
            {
                Error = error,
                Title = title,
                StatusMessage = statusMessage,
                OIP = OIP,
                ResourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = model.OIPID, type = model.Type })
            };
        }
        // POST api/CaseOIP/Remove
        /// <summary>
        /// POST CaseOIP Remove
        /// </summary>
        /// <remarks> This API will remove a OIP from a case </remarks>
        /// <param name="model"></param>
        /// <returns>JSON</returns>
        [HttpPost("Remove")]
        public object Remove([FromBody] OIPCaseDTO model)
        {
            OIPDTO oipdto = new OIPDTO();
            oipdto.CdCase = model.CaseNumber;
            oipdto.OIPID = model.OIPID;
            bool success = (model.Type == "N" || model.Type == "L") ? _caseRepository.RemoveAssignedAgencyByCaseNumber(oipdto) : _caseRepository.RemoveAssignedOIPByCaseNumber(oipdto);
            bool error = (success) ? false : true;
            string Title = (!error) ? "Success" : "Error";
            string StatusMessage = (!error) ? "The OIP was successfully removed" : "Unable to Remove OIP from this Case";
            if (error)
            {
                ModelState.AddModelError(nameof(OIPDTO), StatusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return new
            {
                Error = error,
                Title = Title,
                StatusMessage = StatusMessage
            };
        }
        // POST api/CaseOIP/Delete
        /// <summary>
        /// POST CaseOIP Delete
        /// </summary>
        /// <remarks> This API will Delete a OIP globally and optionally remove from a case </remarks>
        /// <param name="model"></param>
        /// <returns>JSON</returns>
        [HttpPost("Delete")]
        public object Delete([FromBody] OIPCaseDTO model)
        {
            bool success = (model.Type == "N" || model.Type == "L") ? _caseRepository.DeleteAgency(model) : _caseRepository.DeleteOIP(model);
            bool error = (success) ? false : true;
            string Title = (!error) ? "Success" : "Error";
            string StatusMessage = (!error) ? "The OIP was successfully deleted" : "Unable to Delete OIP";
            if (error)
            {
                ModelState.AddModelError(nameof(OIPDTO), StatusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return new
            {
                Error = error,
                Title = Title,
                StatusMessage = StatusMessage
            };
        }
    }
}