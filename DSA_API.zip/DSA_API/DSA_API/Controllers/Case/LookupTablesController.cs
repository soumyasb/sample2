﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/case/LookupTables")]

    public class LookupTablesController : Controller
    {
        private ICaseRepository _caseRepository;
        private IOIPRepository _oIPRepository;
        public LookupTablesController(ICaseRepository caseRepository, IOIPRepository oipRepository)
        {
            _caseRepository = caseRepository;
            _oIPRepository = oipRepository;
        }
        // GET api/Case/LookupTables/GetHearingTypes
        /// <summary>
        /// Get hearing types for cases 
        /// </summary>
        /// <remarks> This API will get hearing types for cases</remarks>
        /// <returns>JSON</returns>
        [HttpGet("GetHearingTypes")]
        public IActionResult GetHearingTypes()
        {
            var model = _caseRepository.GetHearingTypes();
            return Ok(model);
        }
        // GET api/Case/LookupTables/GetCaseReasons
        /// <summary>
        /// Get reason codes for cases 
        /// </summary>
        /// <remarks> This API will get reason codes for cases</remarks>
        /// <returns>JSON</returns>
        [HttpGet("GetCaseReasons")]
        public IActionResult GetCaseReasons()
        {
            var model = _caseRepository.GetReasons();
            return Ok(model);
        }
        // GET api/Case/LookupTables/GetCaseReferrals
        /// <summary>
        /// Get referrals codes for cases 
        /// </summary>
        /// <remarks> This API will get reason codes for cases</remarks>
        /// <returns>JSON</returns>
        [HttpGet("GetCaseReferrals")]
        public IActionResult GetCaseReferrals()
        {
            var model = _caseRepository.GetReferrals();
            return Ok(model);
        }
        // GET api/Case/LookupTables/GetCaseCertifications
        /// <summary>
        /// Get certifcation and endorsemwnt codes for cases 
        /// </summary>
        /// <remarks> This API will get certifcation and endorsemwnt for cases</remarks>
        /// <returns>JSON</returns>
        [HttpGet(" GetCaseCertifications")]
        public IActionResult GetCaseCertifications()
        {
            var model = _caseRepository.GetCerts();
            return Ok(model);
        }

        // GET api/Case/LookupTables/GetOIPType
        /// <summary>
        /// Get OIP Types 
        /// </summary>
        /// <remarks> This API will get OIP Types</remarks>
        /// <returns>JSON</returns>
        [HttpGet(" GetOIPTypes")]
        public IActionResult GetOIPTypes()
        {
            var model = _oIPRepository.getOIPTypes();
            return Ok(model);
        }
        // GET api/Case/LookupTables/GetOIPLanguages
        /// <summary>
        /// Get languages for OIP interpretors 
        /// </summary>
        /// <remarks> This API will get languages for OIP languages</remarks>
        /// <returns>JSON</returns>
        [HttpGet(" GetOIPLanguages")]
        public IActionResult GetOIPLanguages()
        {
            var model = _oIPRepository.getLanguages();
            return Ok(model);
        }
        // GET api/Case/GetSuspenseCaseReasons
        /// <summary>
        /// Get suspense case reasons.
        /// </summary>
        /// <remarks> This API will retreive suspense reason codes for suspending cases</remarks>

        /// <returns>JSON</returns>
        [HttpGet("GetSuspenseCaseReasons")]
        public IActionResult GetSuspenseReasons()
        {
            var model = _caseRepository.GetSuspenseReasons();
            return Ok(model);
        }
    }
   
}