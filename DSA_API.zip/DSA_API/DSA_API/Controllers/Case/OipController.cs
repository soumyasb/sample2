﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using DSA_API.Helpers;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/Oip")]

    public class OipController : Controller
    {
        private ICaseRepository _caseRepository;
        private IOIPRepository _oipRepository;
        private IUrlHelper _urlHelper;
        public OipController(ICaseRepository caseRepository, IOIPRepository oipRepository ,IUrlHelper urlHelper)
        {
            _caseRepository = caseRepository;
            _oipRepository = oipRepository;
            _urlHelper = urlHelper;
        }

        [HttpGet("GetAll/{CaseNumber}")]
        public IEnumerable<OIPDTO> GetAll(string CaseNumber)
        {
            List<OIPDTO> oipList, oipLangList = new List<OIPDTO>();
            oipList = _caseRepository.GetAssignedOIPs(CaseNumber);
            int count = 0;
            foreach (OIPDTO oipobj in oipList)
            {
                if (oipobj.CDPRTYTYP == "M" || oipobj.CDPRTYTYP == "N")
                {
                    oipobj.Languages = _oipRepository.GetOIPLanguages(oipobj.CDPRTYTYP, oipobj.OIPID, out count);
                    if (count == 0) oipobj.Languages = null;
                }
                oipLangList.Add(oipobj);
            }
            return oipLangList;              
        }


        [HttpGet("GetOIP/{type}/{oipid}")]
        public OIPDTO Get(string type, int oipid)
        {
            int count = 0;
            OIPDTO Model = (type == "N" || type == "L") ? _caseRepository.GetAgency(oipid) : _caseRepository.GetOIP(oipid);
            if (type == "M" || type == "N")
            {
                Model.Languages = _oipRepository.GetOIPLanguages(type, oipid, out count);
                if (count == 0) Model.Languages = null; 
            }
            Model.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = Model.OIPID, type = Model.CDPRTYTYP });
            return Model;
        }
        // POST api/Oip/AddOIP
        /// <summary>
        /// POST OIP Add
        /// </summary>
        /// <remarks> This API will add an OIP </remarks>
        /// <param name="type"></param>
        ///
        /// <returns>JSON</returns>
        [HttpPost("{type}")]
        public object AddOIP([FromBody] OIPDTO OIPObj, string type)
        {
            if (type == "N" || type == "M")
            {
                if (String.IsNullOrEmpty(OIPObj.NBRPHONE))
                {
                    ModelState.AddModelError(nameof(OIPDTO), "Phone Number is required ");
                    return new UnprocessableEntityObjectResult(ModelState);
                }
                if (String.IsNullOrEmpty(OIPObj.CDLANGUAGE))
                {
                    ModelState.AddModelError(nameof(OIPDTO), "Language is Required ");
                    return new UnprocessableEntityObjectResult(ModelState);
                }
            }

            if (type == "L" || type == "N")
            {
                return SaveNewAgency(OIPObj);
            }
            else
            {
                return SaveNewOIP(OIPObj);
            }
        }

        // POST api/Oip/UpdateOIP
        /// <summary>
        /// POST OIP Update
        /// </summary>
        /// <remarks> This API will update an OIP </remarks>
        /// <param name="type"></param>
        /// <param name="oipid"></param>
        /// <returns>JSON</returns>
        [HttpPost("{type}/{oipid}")]
        public object UpdateOIP([FromBody] OIPDTO OIPObj, string type, int oipid)
        {
            if (type == "N" || type == "M")
            {
                if (String.IsNullOrEmpty(OIPObj.NBRPHONE))
                {
                    ModelState.AddModelError(nameof(OIPDTO), "Phone Number is required ");
                    return new UnprocessableEntityObjectResult(ModelState);
                }
                //if (String.IsNullOrEmpty(OIPObj.CDLANGUAGE))
                //{
                //    ModelState.AddModelError(nameof(OIPDTO), "Language is Required ");
                //    return new UnprocessableEntityObjectResult(ModelState);
                //}
            }
            
            if (type == "L" || type == "N")
            {
                return UpdateAgency((int)oipid, OIPObj);
            }
            else
            {
                return UpdateOIP((int)oipid, OIPObj);
            }
        }

        private object SaveNewOIP(OIPDTO NewOIP)
        {

            //var identity = (ClaimsIdentity)User.Identity;
            string StatusMessage;
            bool error;
            //var helper = new UrlHelper(Request);
            //NewOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            NewOIP.CDUPDTTECHID = "MPG";
            var result = _caseRepository.NewOIP(NewOIP);

            NewOIP.OIPID = result;

            if (result != 0)
            {
                StatusMessage = "New OIP Saved";
                error = false;
            }
            else
            {
                StatusMessage = "Failed to Save";
                error = true;
            }
            if (error)
            {
                ModelState.AddModelError(nameof(OIPDTO), StatusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return new
            {
                Action = "SAVE",
                OIPID = result,
                OIP = NewOIP,
                APIURI = _urlHelper.RouteUrl("OIPID", new { type = NewOIP.CDPRTYTYP, oipid = result }),
                NME_FRST_PRSN = NewOIP.NMEFRSTPRSN,
                NME_SURNME_PRSN = NewOIP.NMESURNMEPRSN,
                Error = error,
                Title = "New OIP",
                StatusMessage = StatusMessage
            };
        }


        private object UpdateOIP(int oipid, OIPDTO EditOIP)
        {

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            string StatusMessage;
            bool error;
            //EditOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            EditOIP.CDUPDTTECHID = "MPG";
            if (!_caseRepository.UpdateOIP(EditOIP).Error)
            {
                StatusMessage = "OIP Update Successful";
                error = false;
            }
            else
            {
                StatusMessage = "OIP Update Failed";
                error = true;
            }
            if (error)
            {
                ModelState.AddModelError(nameof(OIPDTO), StatusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return new
            {
                Action = "UPDATE",
                OIPID = oipid,
                OIP = EditOIP,
                APIURI = _urlHelper.RouteUrl("OIPID", new { type = EditOIP.CDPRTYTYP, oipid = oipid }),
                NME_FRST_PRSN = EditOIP.NMEFRSTPRSN,
                NME_SURNME_PRSN = EditOIP.NMESURNMEPRSN,
                Error = error,
                Title = "Update OIP",
                StatusMessage = StatusMessage
            };
        }


        private object SaveNewAgency(OIPDTO NewOIP)
        {
            //var identity = (ClaimsIdentity)User.Identity;

            string StatusMessage;
            bool error;
            //NewOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            NewOIP.CDUPDTTECHID = "MPG";
            var result = _caseRepository.NewAgency(NewOIP);

            NewOIP.OIPID = result;

            if (result != 0)
            {
                StatusMessage = "New OIP Agency Saved";
                error = false;
            }
            else
            {
                StatusMessage = "Failed to Save";
                error = true;
            }
            if (error)
            {
                ModelState.AddModelError(nameof(OIPDTO), StatusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return new
            {
                Action = "SAVE",
                OIPID = result,
                OIP = NewOIP,
                APIURI = _urlHelper.RouteUrl("OIPID", new { oipid = result, type = NewOIP.CDPRTYTYP }),
                NME_AGENCY = NewOIP.NMEAGENCY,
                Error = error,
                Title = "New OIP Agency",
                StatusMessage = StatusMessage
            };
        }

        private object UpdateAgency(int oipid, OIPDTO EditOIP)
        {
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
                        
            string StatusMessage;
            bool error;
            //EditOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            EditOIP.CDUPDTTECHID = "MPG";
            if (!_caseRepository.UpdateAgency(EditOIP).Error)
            {
                StatusMessage = "OIP Agency Update Successful";
                error = false;
            }
            else
            {
                StatusMessage = "OIP Agency Update Failed";
                error = true;
            }
            if (error)
            {
                ModelState.AddModelError(nameof(OIPDTO), StatusMessage);
                return new UnprocessableEntityObjectResult(ModelState);
            }
            return new
            {
                Action = "UPDATE",
                OIP = EditOIP,
                OIPID = oipid,
                APIURI = _urlHelper.RouteUrl("OIPID", new { oipid = oipid, type = EditOIP.CDPRTYTYP }),
                NME_AGENCY = EditOIP.NMEAGENCY,
                Error = error,
                Title = "Update OIP",
                StatusMessage = StatusMessage
            };
        }
    }
   
}