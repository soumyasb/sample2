﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Newtonsoft.Json.Linq;
using DSA_API.Helpers;
using Microsoft.AspNetCore.Cors;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/Comment")]

    public class CommentController : Controller
    {
        private ICaseRepository _caseRepository;
        private IUrlHelper _urlHelper;
        private IConfiguration _configuration { get; }
        private IUserRepository _userRepository;
        private UserDTO _user;
        public CommentController(ICaseRepository caseRepository, IUrlHelper urlHelper, IConfiguration configuration, IUserRepository userRepository)
        {
            _caseRepository = caseRepository;
            _urlHelper = urlHelper;
            _configuration = configuration;
            _userRepository = userRepository;
        }
        // GET api/Comment/Get
        /// <summary>
        /// GET Comments   
        /// </summary>
        /// <remarks> This API will get comments for a case </remarks>
        /// <param name="CaseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("{CaseNumber}")]
        public CaseCommentsDTO Get(string CaseNumber)
        {
           // var helper = new UrlHelper(Request);
            var query = _caseRepository.GetCaseComments(CaseNumber);
            return query;
        }

        //// GET api/Comment/Get
        ///// <summary>
        ///// GET Comment   
        ///// </summary>
        ///// <remarks> This API will get comments for a case </remarks>
        ///// <param name="CaseNumber"></param>
        ///// <param name="page"></param>
        ///// <returns>JSON</returns>
        //[HttpGet("{CaseNumber}/{page?}")]
        //public CaseCommentsDTO Get(string CaseNumber, int page = 1)
        //{
        //    // var helper = new UrlHelper(Request);
        //    var query = _caseRepository.GetCaseComments(CaseNumber, page);
        //    query.baseURI = _urlHelper.RouteUrl("CommentAPI", new { page = "" });
        //    query.PrevPageURL = page > 1 ? _urlHelper.RouteUrl("CommentAPI", new { page = page - 1 }) : "";
        //    query.NextPageURL = page != query.TotalPages ? _urlHelper.RouteUrl("CommentAPI", new { page = page + 1 }) : "";
        //    return query;
        //}

        // POST api/Comment/Post
        /// <summary>
        /// POST Comment Add 
        /// </summary>
        /// <remarks> This API will add a case comment </remarks>
        /// <param name="CaseNumber"></param>
        /// <returns>JSON</returns>

        [HttpPost("{CaseNumber}")]
        public IActionResult Post(string CaseNumber, [FromBody] CommentDTO NewComment)
        {
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            string employeeThreeDigit = "MPG";
            _user = _userRepository.GetUser("MWMPG4");
            string officeid = _user.Office.CdOffAbbr;
            
            CommentDTO DTO = new CommentDTO();
            DTO.Error = false; //   Default to no errorson DTO

            //var helper = new UrlHelper(Request);
            CommentDTO DSA, DL;

            if (String.IsNullOrEmpty(NewComment.commentTextInput) || NewComment.commentTextInput.ToLower() == NewComment.placeholder.ToLower())
            {
                ModelState.AddModelError(nameof(CommentDTO),
                      "Error - Comment cannot be empty.");
            }

            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
            if (NewComment.CommentType == "D" || NewComment.CommentType == "CD")
            {
                //  Validation

                if (String.IsNullOrEmpty(NewComment.PurgeDate))
                {
                    ModelState.AddModelError(nameof(CommentDTO),
                          "Error - Purge Date cannot be empty.");
                }
                if (String.IsNullOrEmpty(NewComment.CommentNumber))
                {
                    ModelState.AddModelError(nameof(CommentDTO),
                          "Error - Comment Number cannot be empty.");
                }
                bool CaseNumberValid = true;
                switch (NewComment.CommentNumber)
                {
                    case "00":
                    case "01":
                    case "02":
                    case "03":
                    case "04":
                    case "05":
                    case "06":
                    case "S1":
                    case "S2":
                    case "S3":
                    case "S4":
                    case "S5":
                    case "S6":
                    case "S7":
                    case "S8":
                    case "S9":
                        CaseNumberValid = true;
                        break;
                    default:
                        CaseNumberValid = false;
                        break;
                }
                if (!CaseNumberValid)
                {
                    ModelState.AddModelError(nameof(CommentDTO),
                         "Error - Comment Number Invalid, must be 00-06 or S1-S9.");
                }
                if (!ModelState.IsValid)
                    return new UnprocessableEntityObjectResult(ModelState);

                if (NewComment.PurgeDate.Contains("-"))
                {
                    NewComment.PurgeDate = NewComment.PurgeDate.Replace("-", "");
                }
            }

            switch (NewComment.CommentType)
            {
                case "C":
                    DSA = saveCommentDSA(CaseNumber, NewComment, employeeThreeDigit, officeid);
                    if (DSA.Error)
                    {
                        DTO.StatusMessage = DSA.StatusMessage;
                        DTO.Error = DSA.Error;
                        ModelState.AddModelError(nameof(CommentDTO),
                         "Error - Unable to Save Comment, Database Error.");
                        return new UnprocessableEntityObjectResult(ModelState);
                    }
                    break;

                case "CD":
                    DL = saveCommentDL(CaseNumber, NewComment);
                    if (DL.Error)
                    {
                        DTO.StatusMessage = DL.StatusMessage;
                        DTO.Error = DL.Error;
                        ModelState.AddModelError(nameof(CommentDTO), DTO.StatusMessage);
                        return new UnprocessableEntityObjectResult(ModelState);
                    }
                    DSA = saveCommentDSA(CaseNumber, NewComment, employeeThreeDigit, officeid);
                    if (DSA.Error)
                    {
                        DTO.StatusMessage = DSA.StatusMessage;
                        DTO.Error = DSA.Error;
                        ModelState.AddModelError(nameof(CommentDTO),
                         "Error - Unable to Save Comment, Database Error.");
                        return new UnprocessableEntityObjectResult(ModelState);
                    }
                    break;

                case "D":
                    DL = saveCommentDL(CaseNumber, NewComment);
                    if (DL.Error)
                    {
                        DTO.StatusMessage = DL.StatusMessage;
                        DTO.Error = DL.Error;
                        ModelState.AddModelError(nameof(CommentDTO), DTO.StatusMessage);
                        return new UnprocessableEntityObjectResult(ModelState);
                    }
                    break;
            }
            return Ok(DTO);
        }

        // POST api/Comment/DeleteComment
        /// <summary>
        /// POST Comment Delete 
        /// </summary>
        /// <remarks> This API will Delete a case comment </remarks>
        /// <param name="CaseNumber"></param>
        /// <returns>JSON</returns>
        [HttpPost("DeleteCase/{CaseNumber}")]
      
        public IActionResult DeleteComment(string CaseNumber, [FromBody] CaseCommentDeleteDTO DeleteComment)
        {
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            string employeeThreeDigit = "MPG";

            //DeleteComment.Error = false; //   Default to no errorson DTO
            if (String.IsNullOrEmpty(CaseNumber))
            {
                ModelState.AddModelError(nameof(CaseCommentDeleteDTO),
                      "Error - Case Number cannot be empty.");
            }

            if (String.IsNullOrEmpty(DeleteComment.CommentNumber))
            {
                ModelState.AddModelError(nameof(CaseCommentDeleteDTO),
                     "Error - Comment Number cannot be empty.");
            }
            if (String.IsNullOrEmpty(DeleteComment.DLNumber))
            {
                ModelState.AddModelError(nameof(CaseCommentDeleteDTO),
                   "Error - DLNumber cannot be empty.");
            }
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
           
            DeleteComment = _caseRepository.DeleteCaseComment(CaseNumber, DeleteComment, employeeThreeDigit );

            return Ok(DeleteComment);
        }




        private CommentDTO saveCommentDSA(string CaseNumber, CommentDTO NewComment, string UserID, string OfficeId)
        {
            CommentDTO DTO = new CommentDTO();

            if (_caseRepository.SaveNewComment(CaseNumber, NewComment.commentTextInput, UserID, NewComment.DLNumber, OfficeId))
            {
                DTO.Error = false;
                DTO.Title = "Database Success";
                DTO.StatusMessage = "Comment Successfully Saved!";
            }
            else
            {
                DTO.Error = true;
                DTO.Title = "Database Error";
                DTO.StatusMessage = "Unable to Save Comment, Database Error";
            }
            return DTO;
        }



        private CommentDTO saveCommentDL(string CaseNumber, CommentDTO NewComment)
        {
            CommentDTO DTO = new CommentDTO();

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";

            var postObj = new
            {
                SBALASTNAME = NewComment.LastnameFirst3,
                SBACOMMNUMBER = NewComment.CommentNumber,
                SBAPURGEDATE1 = NewComment.PurgeDate,
                SBACOMMENT = NewComment.commentTextInput
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var DTOJson = Newtonsoft.Json.JsonConvert.SerializeObject(DTO);
                    var DTOString = new StringContent(DTOJson, System.Text.Encoding.UTF8, "application/json");
                    var response = client.PostAsync("update/DUK/" + NewComment.DLNumber, DTOString);
                    //var response = HttpClientExtensions.PostAsJsonAsync(client, "update/DUK/" + NewComment.DLNumber, postObj);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
   
            return DTO;
        }
    }
}