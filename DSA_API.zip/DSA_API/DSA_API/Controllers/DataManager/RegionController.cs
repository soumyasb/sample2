﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/Region")]
    public class RegionController : Controller
    {
        private DSAContext _context;
        public RegionController(DSAContext context)
        {
            _context = context;
        }
        [HttpGet("GetRegions", Name = "GetRegions")]
        public IActionResult GetRegions()
        {
            var regions = (from r in _context.Region
                           join o in _context.Dsoffice on r.CdDistId equals o.CdOffId
                           select new
                           {
                               DistrictID = r.CdDistId,
                               DistrictName = o.NmeOff,
                               RegionID = r.CdRgnId,
                               RegionName = r.NmeRgn,
                               EndDate = r.DtTerm
                           }).ToList();
            List<RegionDetailDTO> regionList = new List<RegionDetailDTO>();

            foreach (var item in regions)
            {
                RegionDetailDTO r = new RegionDetailDTO();
                r.DistrictID = item.DistrictID;
                r.DistrictName = item.DistrictName;
                r.RegionID = item.RegionID;
                r.RegionName = item.RegionName;
                r.EndDate = item.EndDate;
                regionList.Add(r);
            }
            return Ok(regionList);
        }
        [HttpGet("Create")]
        public IActionResult Create()
        {
            RegionDetailDTO region = new RegionDetailDTO();
            region.Districts = new SelectList(_context.Dsoffice
                .Where(o => o.CdDistId == o.CdOffId).ToList()
                .OrderBy(o => o.CdDistId)
                .Select(o => new
                {
                    DistName = String.Format("{0} {1} {2}", o.CdDistId, "-", o.NmeOff),
                    DistrictID = o.CdOffId
                }), "DistrictID", "DistName");
            return Ok(region);
        }
        // POST: REGIONs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Create")]
        //   [ValidateAntiForgeryToken]
        public IActionResult Create(RegionDetailDTO dto)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            var found = _context.Region.Any(r => r.CdRgnId == dto.RegionID && r.CdDistId == dto.DistrictID);
            if (found)
            {
                dto.Districts = new SelectList(_context.Dsoffice
                .Where(o => o.CdDistId == o.CdOffId).ToList()
                .OrderBy(o => o.CdDistId)
                .Select(o => new
                {
                    DistName = String.Format("{0} {1} {2}", o.CdDistId, "-", o.NmeOff),
                    DistrictID = o.CdDistId
                }), "DistrictID", "DistName");
                dto.Message = "Duplicate record found";
                return Ok(dto);
            }
            Region region = new Region();
            region.CdDistId = dto.DistrictID;
            region.CdRgnId = dto.RegionID;
            region.NmeRgn = dto.RegionName;
            region.DtTerm = dto.EndDate;
            _context.Region.Add(region);
            _context.SaveChanges();
            return RedirectToAction("GetRegions");
        }
        // GET: REGIONs/Edit/5
        [HttpGet("Edit/{rgnId}/{distId}")]
        public IActionResult Edit(string rgnId, string distId)
        {
            if (rgnId == null && distId == null)
            {
                return BadRequest();
            }
            Region rEGION = _context.Region.Find(rgnId, distId);
            if (rEGION == null)
            {
                return NotFound();
            }
            RegionDetailDTO regionDTO = new RegionDetailDTO();

            regionDTO.DistrictID = rEGION.CdDistId;
            regionDTO.RegionID = rEGION.CdRgnId;
            regionDTO.RegionName = rEGION.NmeRgn;
            regionDTO.EndDate = rEGION.DtTerm;

            regionDTO.Districts = new SelectList(_context.Dsoffice
               .Where(o => o.CdDistId == o.CdOffId).ToList()
               .OrderBy(o => o.CdDistId)
               .Select(o => new
               {
                   DistName = String.Format("{0} {1} {2}", o.CdDistId, "-", o.NmeOff),
                   DistrictID = o.CdDistId
               }), "DistrictID", "DistName");
            return Ok(regionDTO);
        }
        // POST: REGIONs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit")]
        // [ValidateAntiForgeryToken]
        public IActionResult Edit(RegionDetailDTO regionDTO)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            Region region = _context.Region.Find(regionDTO.RegionID, regionDTO.DistrictID);
            if (region == null)
            {
                Region regionNew = new Region();
                regionNew.CdDistId = regionDTO.DistrictID;
                regionNew.CdRgnId = regionDTO.RegionID;
                regionNew.NmeRgn = regionDTO.RegionName;
                regionNew.DtTerm = regionDTO.EndDate;
                _context.Entry(regionNew).State = EntityState.Added;
            }
            else
            {
                region.CdDistId = regionDTO.DistrictID;
                region.CdRgnId = regionDTO.RegionID;
                region.NmeRgn = regionDTO.RegionName;
                region.DtTerm = regionDTO.EndDate;
                _context.Entry(region).State = EntityState.Modified;
            }
            _context.SaveChanges();
            return RedirectToAction("GetRegions");

        }
        // GET: REGIONs/Delete/5
        [HttpGet("Delete/{rgnId}/{distId}")]
        public IActionResult Delete(string rgnId, string distId)
        {
            if (rgnId == null && distId == null)
            {
                return BadRequest();
            }
            Region rEGION = _context.Region.Find(rgnId, distId);
            if (rEGION == null)
            {
                return NotFound();
            }
            return Ok(rEGION);
        }

        // POST: REGIONs/Delete/5
        [HttpPost("DeleteConfirmed/{rgnId}/{distId}")]
        //  [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string rgnId, string distId)
        {
            Region rEGION = _context.Region.Find(rgnId, distId);
            _context.Region.Remove(rEGION);
            _context.SaveChanges();
            return RedirectToAction("GetRegions");
        }
    }
}