﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;


using Microsoft.AspNetCore.Mvc;
using DSA_API.Entities;
using DSA_API.Services.DataManager;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;


namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/Holiday")]
    public class HolidayController : Controller
    {
        private DSAContext _context;
        private IHolidayRepository _repo;
        public HolidayController(DSAContext context, IHolidayRepository repo)
        {
            _context = context;
            _repo = repo;
        }
        [HttpGet("GetHolidays", Name = "GetHolidays")]
        // GET: Holidays/getholidays
        public IActionResult GetHolidays()
        {

            var model = _repo.getAllHOlidays();

            return Ok(model);
        }

        // GET: HOLIDAYs/Details/5
        [HttpGet("Details/{id}")]
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var holiday = _repo.getHoliday(id.Value);
            if (holiday == null)
            {
                return NotFound();
            }
            return Ok(holiday);
        }

        // GET: HOLIDAYs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            var model = new HolidayDTO();
            return Ok(model);
        }

        // POST: HOLIDAYs/Create
        [HttpPost("Create")]
      //  [ValidateAntiForgeryToken]
        public IActionResult Create(HolidayDTO holiday)
        {
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
         
            var curr = _context.Holiday.AsNoTracking().Where(h => h.DtHoli == holiday.HolidayDate).FirstOrDefault();
            if (curr == null)
            {
                var h = _repo.convertHoliday(holiday);
                _context.Holiday.Add(h);
                _context.SaveChanges();
                return RedirectToAction("GetHolidays");

            }
            // TODO: Validation Message => "This date already exists"
            else
            {
                if (curr.DtTerm == null)
                {
                    ModelState.AddModelError("Holiday", holiday.HolidayDate.Value.Date.ToString("D") + " Already Exist");
                    return new UnprocessableEntityObjectResult(ModelState);
                }
                else
                {
                    var h = _repo.convertHoliday(holiday);
                    h.Id = curr.Id;
                    h.DtTerm = null;
                    _context.Entry(h).State = EntityState.Modified;
                    _context.SaveChanges();
                    return RedirectToAction("GetHolidays");
                    //return new HttpStatusCodeResult(HttpStatusCode.Created);
                }
            }
        }

        // GET: HOLIDAYs/Edit/5
        [HttpGet("Edit/{id}")]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var h = _repo.getHoliday(id.Value);

            if (h == null)
            {
                return NotFound();
            }
            return Ok(h);
        }

        // POST: HOLIDAYs/Edit/5
        [HttpPost("Edit")]
        //  [ValidateAntiForgeryToken]
        public IActionResult Edit(HolidayDTO holiday)
        {
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            var h = _repo.convertHoliday(holiday);
            _context.Entry(h).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetHolidays");
        }

        // GET: HOLIDAYs/Delete/5
        [HttpGet("Delete/{id}")]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var h = _repo.getHoliday(id.Value);
            if (h == null)
            {
                return NotFound();
            }
            return Ok(h);
        }

        // POST: HOLIDAYs/Delete/5
        [HttpPost("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            Holiday hOLIDAY = _context.Holiday.Find(id);
            hOLIDAY.DtTerm = DateTime.Now;
            _context.Entry(hOLIDAY).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetHolidays");
        }
    }
    
}