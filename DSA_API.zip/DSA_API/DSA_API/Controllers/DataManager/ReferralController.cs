﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/Referral")]
    public class ReferralController : Controller
    {
        private DSAContext _context;
        private IReferralRepository _referralRepository;
        public ReferralController(DSAContext context, IReferralRepository referral)
        {
            _context = context;
            _referralRepository = referral;
        }
        // GET: Referrals/getReferrals
        [HttpGet("GetReferrals", Name = "GetReferrals")]
        public IActionResult GetReferrals()
        {
            var model = _referralRepository.getAllReferrals();
            return Ok(model);
        }
        // GET: OIPTYPEs/Details/5
        [HttpGet("Details/{type}")]
        public IActionResult Details(string type)
        {
            if (type == null)
            {
                return BadRequest();
            }
            ReferralDTO referral = _referralRepository.getReferral(type);

            if (referral == null)
            {
                return NotFound();
            }
            return Ok(referral);
        }
        // GET: OIPTYPEs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            ReferralDTO model = new ReferralDTO();
            return Ok(model);
        }

        // POST:Referral/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.

        // [ValidateAntiForgeryToken]
        [HttpPost("Create")]
        public IActionResult Create(ReferralDTO referral)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //TODO: Check for existing?
            bool codeExist = _context.Referral.Any(c => c.CdRefrSrceTyp.Equals(referral.Type));

            if (codeExist)
            {
                ModelState.AddModelError("Referral", "Code " + referral.Type + " already exist!");
                if (!ModelState.IsValid)
                    return new UnprocessableEntityObjectResult(ModelState);
            }


            var o = _referralRepository.convertReferral(referral);
            _context.Referral.Add(o);

            //Add 1 more record with Hearing Types = "S";
            try
            {
                _context.SaveChanges();
            }
            catch (SqlException e)
            {
                return StatusCode(422, "SQL Error!");

            }
            return Ok(o);
        }
        // GET: Referral/Edit/5
        [HttpGet("Edit/{type}")]
        public IActionResult Edit(string type)
        {
            if (type == null)
            {
                return BadRequest();
            }
            ReferralDTO model = _referralRepository.getReferral(type);

            if (model == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

        // POST: Referral/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit")]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit(ReferralDTO type)
        {

            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);


            var o = _referralRepository.convertReferral(type);
            _context.Entry(o).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetReferrals");

        }

        // GET: Referral/Delete/5
        [HttpGet("Delete/{type}")]
        public IActionResult Delete(string type)
        {
            if (type == null)
            {
                return BadRequest();
            }
            ReferralDTO o = _referralRepository.getReferral(type);
            if (o == null)
            {
                return NotFound();
            }
            return Ok(o);
        }

        // POST: Referral/Delete/5
        [HttpPost("DeleteConfirmed/{type}")]
        //  [HttpPost, ActionName("Delete")]
        //  [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string type)
        {
            ReferralDTO referral = _referralRepository.getReferral(type);
            referral.TermDate = DateTime.Now;
            var o = _referralRepository.convertReferral(referral);
            _context.Entry(o).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetReferrals");
        }
    }
}
