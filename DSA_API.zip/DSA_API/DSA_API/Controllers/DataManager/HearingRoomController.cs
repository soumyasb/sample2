﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DSA_API.Services.DataManager;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/HearingRoom")]
    public class HearingRoomController : Controller
    {
        private DSAContext _context;
        private IHearingRoomRepository _hearingRoomRepository;
        public HearingRoomController(DSAContext context, IHearingRoomRepository hearingRoomRepository)
        {
            _context = context;
            _hearingRoomRepository = hearingRoomRepository; 
        }
        [HttpGet("InitializeHearingRoom", Name = "InitializeHearingRoom")]
        public IActionResult InitializeHearingRoom()
        {
            HearingRoomInitDTO model = new HearingRoomInitDTO();
            model.OfficeList = _hearingRoomRepository.getOfficeList();
            return Ok(model);
        }
        // GET: DSOFFICEs/Details/5
        [HttpGet("GetHearingRooms/{id}", Name = "GetHearingRooms")]
        public IActionResult GetHearingRooms(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var model = _hearingRoomRepository.getOfficeRooms(id);
          
            return Ok(model);
        }

        [HttpGet("CreateTemplateForHearingRoom")]
        public IActionResult CreateTemplateForHearingRoom()
        {
            HearingRoomDTO model = new HearingRoomDTO();
            model.hearingRoom = new HearingRoomDetailDTO();
            model.OfficeList = _hearingRoomRepository.getOfficeList();
            return Ok(model);
        }
        [HttpPost("CreateHearingRoom")]
        //      [ValidateAntiForgeryToken]
        public IActionResult CreateHearingRoom(HearingRoomDTO roomDTO)
        {
            var match = _hearingRoomRepository.checkHearingRoom(roomDTO.hearingRoom.OfficeID, roomDTO.hearingRoom.RoomNumber);
            if (!match)
            {
                if (!ModelState.IsValid)
                {
                    return new UnprocessableEntityObjectResult(ModelState);
                }
                var hearinglocation = _hearingRoomRepository.convertHearingRoom(roomDTO.hearingRoom);

                _context.Hearinglocation.Add(hearinglocation);
                _context.SaveChanges();
                return RedirectToAction("GetHearingRooms", "HearingRoom", new { id = roomDTO.hearingRoom.OfficeID });
            }
            else
            {
                roomDTO.message = "Room already exists in this office";
            }
            return Ok(roomDTO);
        }
        [HttpGet("EditTemplateOffice/{officeid}/{roomnumber}")]
        public IActionResult EditTemplateHearingRoom(string officeid, string roomnumber)
        {
            if (officeid == null || roomnumber == null)
            {
                return NotFound();
            }
            HearingRoomDetailDTO hearingroom = _hearingRoomRepository.getHearingRoom(officeid, roomnumber);
            if (hearingroom == null)
            {
                return NotFound();
            }
            HearingRoomDTO model = new HearingRoomDTO();
            model.hearingRoom = hearingroom;
          //  model.OfficeList = _hearingRoomRepository.getOfficeList();
            return Ok(model);
        }
        [HttpPost("EditHearingRoom")]
        //    [ValidateAntiForgeryToken]
        public IActionResult EditHearingRoom(HearingRoomDetailDTO roomDTO)
        {
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var room =_hearingRoomRepository.convertHearingRoom(roomDTO);
            _context.Entry(room).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetHearingRooms", "HearingRoom", new { id = roomDTO.OfficeID });

        }
        
        [HttpPost("DeleteHearingRoom/{officeid}/{roomnumber}")]
        public IActionResult DeleteHearingRoom(string officeid, string roomnumber)
        {
            if (officeid == null || roomnumber == null)
            {
                return NotFound();
            }
            HearingRoomDTO model = new HearingRoomDTO();
            model.hearingRoom = _hearingRoomRepository.getHearingRoom(officeid, roomnumber);
            if (model.hearingRoom == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

     
        [HttpPost("DeleteConfirmed/{id}")]
        // [HttpPost, ActionName("DeleteConfirmed/{id}")]
        // [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            Hearinglocation room = _context.Hearinglocation.Find(id);
            room.DtClosed = DateTime.Today;
            _context.Entry(room).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetHearingRooms", "HearingRoom", new { id = room.CdOffId });
        }
    }
  

}