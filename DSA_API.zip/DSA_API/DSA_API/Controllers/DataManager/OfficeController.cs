﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/Office")]
    public class OfficeController : Controller
    {
        private DSAContext _context;
        private IOfficeRepository _officeRepository;

        public OfficeController(IOfficeRepository officeRepository, DSAContext context)
        {
            _context = context;
            _officeRepository = officeRepository;
        }

        //GET Api/Offices
   
        [HttpGet("GetAllOffices", Name = "GetAllOffices")]
        public IActionResult GetAllOffices()
        {
            var model = _officeRepository.getAllDSOffices();
            return Ok(model);
        }

        // GET: DSOFFICEs/Details/5
        [HttpGet("GetOffice/{id}", Name = "GetOffice")]
        public IActionResult GetOffice(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            OfficeDTO model = new OfficeDTO();
            model.office = _officeRepository.getDSOffice(id);
            if (model.office == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

        // GET: DSOFFICEs/CreateInitialOffice
        [HttpGet("CreateTemplateForOffice")]
        public IActionResult CreateTemplateForOffice()
        {
            OfficeDTO model = new OfficeDTO();
            model.office = new OfficeDetailDTO();
            model.districtOfficeList = _officeRepository.getOfficeList();
            return Ok(model);
        }

        // POST: DSOFFICEs/Create

        [HttpPost("CreateOffice")]
  //      [ValidateAntiForgeryToken]
        public IActionResult CreateOffice(OfficeDTO officeDTO)
        {
            var match = _officeRepository.getDSOffice(officeDTO.office.OfficeID);
            if (match == null)
            {
                if (!ModelState.IsValid)
                {
                    return new UnprocessableEntityObjectResult(ModelState);
                }
                var dSOFFICE = _officeRepository.convertDSOffice(officeDTO.office);

                _context.Dsoffice.Add(dSOFFICE);
                _context.SaveChanges();
                return RedirectToAction("GetAllOffices");
            }
            else
            {
                officeDTO.message = "Office with this ID already exist";
            }
            return Ok(officeDTO);
        }

        // GET: DSOFFICEs/EditTempleteOffice/5
        [HttpGet("EditTemplateOffice/{id}")]
        public IActionResult EditTemplateOffice(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            OfficeDetailDTO dSOFFICE = _officeRepository.getDSOffice(id);
            if (dSOFFICE == null)
            {
                return NotFound();
            }
            OfficeDTO model = new OfficeDTO();
            model.office = dSOFFICE;
            model.districtOfficeList = _officeRepository.getOfficeList();
            return Ok(model);
        }

        // POST: DSOFFICEs/EditOffice/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("EditOffice")]
    //    [ValidateAntiForgeryToken]
        public IActionResult EditOffice(OfficeDTO officeDTO)
        {

            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            var office = _officeRepository.convertDSOffice(officeDTO.office);
            _context.Entry(office).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetAllOffices");
          
        }

        // GET: DSOFFICEs/DeleteOffice/5
        [HttpGet("DeleteOffice/{id}")]
        public IActionResult DeleteOffice(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            OfficeDTO model = new OfficeDTO();
            model.office = _officeRepository.getDSOffice(id);
            if (model.office == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

        // POST: DSOFFICEs/DeleteConfirmed/5
        [HttpPost("DeleteConfirmed/{id}")]
        // [HttpPost, ActionName("DeleteConfirmed/{id}")]
        // [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            Dsoffice dSOFFICE = _context.Dsoffice.Find(id);
            dSOFFICE.DtTerm = DateTime.Today;
            _context.Entry(dSOFFICE).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetAllOffices");
        }

   //     // GET: DSOFFICEs/activate/5
   //     public IActionResult Activate(string id)
   //     {
   //         if (id == null)
   //         {
   //             return NotFound(); 
   //         }
   //         OfficeDTO model = new OfficeDTO();
   //         model.office = _officeRepository.getDSOffice(id);
   //         if (model.office == null)
   //         {
   //             return NotFound();
   //         }
   //         return Ok(model);
   //     }

   //     // POST: DSOFFICEs/Activate/5
   //     [HttpPost, ActionName("Activate")]
   ////     [ValidateAntiForgeryToken]
   //     public IActionResult ActivateConfirmed(string id)
   //     {
   //        Dsoffice dSOFFICE = _context.Dsoffice.Find(id);
   //         dSOFFICE.DtTerm = null;
   //         _context.Entry(dSOFFICE).State = EntityState.Modified;
   //         _context.SaveChanges();
   //         return RedirectToAction("Index");
   //     }

    }
}