﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/ReasonCategory")]
    public class ReasonCategoryController : Controller
    {
        private DSAContext _context;
        private IReasonCategoryRepository _reasonCategory;
        public ReasonCategoryController(DSAContext context, IReasonCategoryRepository reasonCategoryRepository)
        {
            _context = context;
            _reasonCategory = reasonCategoryRepository;
        }
        // GET: ReasonCategory/getrcs
        [HttpGet("GetReasonCategories", Name = "GetReasonCategories")]
        public IActionResult GetReasonCategories()
        {

            var model = _reasonCategory.getAllReasonCategories();

            return Ok(model);
        }

        // GET: ReasonCategory/Details/5
        [HttpGet("Details/{id}")]
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            ReasonCategoryDTO reacat = _reasonCategory.getReasonCategory(id.Value);
            if (reacat == null)
            {
                return NotFound();
            }
            return Ok(reacat);
        }

        // GET: ReasonCategory/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            ReasonCategoryDTO model = new ReasonCategoryDTO();
            return Ok(model);
        }

        // POST: ReasonCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Create")]
        // [ValidateAntiForgeryToken]
        public IActionResult Create(ReasonCategoryDTO reacat)
        {
            if(!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            reacat.UpdateDay = DateTime.Today;
            //TODO:
            //reacat.UpdatedBy = 
            var rc = _reasonCategory.convertReasonCategory(reacat);

            _context.Reacat.Add(rc);
            _context.SaveChanges();
            return RedirectToAction("GetReasonCategories");
          

        }

        // GET: ReasonCategory/Edit/5
        [HttpGet("Edit/{id}")]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            ReasonCategoryDTO rc = _reasonCategory.getReasonCategory(id.Value);

            if (rc == null)
            {
                return NotFound();
            }
            return Ok(rc);
        }

        // POST: ReasonCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit")]
        //  [ValidateAntiForgeryToken]
        public IActionResult Edit(ReasonCategoryDTO rc)
        {
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            Reacat reacat = _reasonCategory.convertReasonCategory(rc);

            _context.Entry(reacat).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetReasonCategories");
            
        }

        // GET: ReasonCategory/Delete/5
        [HttpGet("Delete/{id}")]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            ReasonCategoryDTO rc = _reasonCategory.getReasonCategory(id.Value);

            if (rc == null)
            {
                return NotFound();
            }
            return Ok(rc);
        }

        // POST: ReasonCategory/Delete/5
        [HttpPost("DeleteConfirmed/{id}")]
        //   [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            ReasonCategoryDTO rc = _reasonCategory.getReasonCategory(id);
            Reacat reacat = _reasonCategory.convertReasonCategory(rc);
            reacat.DtTerm = DateTime.Now;

            _context.Entry(reacat).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetReasonCategories");
        }

    }
}