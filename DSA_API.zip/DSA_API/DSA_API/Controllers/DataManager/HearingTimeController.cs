﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/HearingTime")]
    public class HearingTimeController : Controller
    {
        private DSAContext _context;
        private IHearingTimeRepository _hearingTimeRepository;
        public HearingTimeController(DSAContext context, IHearingTimeRepository hearingTimeRepository)
        {
            _context = context;
            _hearingTimeRepository = hearingTimeRepository;
        }
        // GET: Hearingtimes/getDHTs
        [HttpGet("GetHearingTimes", Name = "GetHearingTimes")]
        public IActionResult GetHearingTimes()
        {

            var model = _hearingTimeRepository.getAllHearingTimes();

            return Ok(model);
        }

        // GET: HEARINGTIMEs/Details/5
        [HttpGet("Details/{id}")]
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var ht = _hearingTimeRepository.getHearingTime(id.Value);
            if (ht == null)
            {
                return NotFound();
            }
            return Ok(ht);
        }

        // GET: HEARINGTIMEs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            var model = new HearingTimeForAddDTO();
          
            return Ok(model);
        }

        // POST: HEARINGTIMEs/Create
      
        //  [ValidateAntiForgeryToken]
        [HttpPost("Create")]
        public IActionResult Create(HearingTimeForAddDTO model)
        {
            if(!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            
            //TODO:DUPLICATES
            var htime = _context.Hearingtime1.AsNoTracking().Where(h => h.Category == model.Category).FirstOrDefault();
            if (htime == null)
            {
                var ht = _hearingTimeRepository.convertHearingTime(model);
                _context.Hearingtime1.Add(ht);
                _context.SaveChanges();
                return RedirectToAction("GetHearingTimes");
            }
           
            ModelState.AddModelError("HeariingTime" , "Duplicate Category: The category " + model.Category + " already exists");
            return new UnprocessableEntityObjectResult(ModelState);
           
   
        }

        // GET: HEARINGTIMEs/Edit/5
        [HttpGet("Edit/{id}")]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var model = new HearingTimeDTO();
            model = _hearingTimeRepository.getHearingTime(id.Value);

            if (model == null)
            {
                return NotFound();
            }
        
            return Ok(model);
        }

        // POST: HEARINGTIMEs/Edit/5

        [HttpPost("Edit")]
        //    [ValidateAntiForgeryToken]

        public IActionResult Edit(HearingTimeDTO model)
        {
            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            Hearingtime1 ht = new Hearingtime1();
            ht.Id = model.ID;
            ht.Category = model.Category;
            ht.HearingTime = model.HearingTime;
            ht.InterviewTime = model.InterviewTime;
            ht.ReExamTime = model.ReExamTime;

            //var ht = _hearingTimeRepository.convertHearingTime(model);
            _context.Entry(ht).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetHearingTimes");

        }

        // GET: HEARINGTIMEs/Delete/5
        [HttpGet("Delete/{id}")]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var ht = _hearingTimeRepository.getHearingTime(id.Value);

            if (ht == null)
            {
                return NotFound();
            }
            return Ok(ht);
        }

        // POST: HEARINGTIMEs/Delete/5
        [HttpPost("DeleteConfirmed/{id}")]
        //[ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
           

            Hearingtime1 ht = _context.Hearingtime1.Find(id);
          
            _context.Hearingtime1.Remove(ht);
            _context.SaveChanges();
            return RedirectToAction("GetHearingTimes");
        }

    }
}