﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/SuspenseReason")]
    public class SuspenseReasonController : Controller
    {
        private DSAContext _context;
        private ISuspenseReasonRepository _suspenseReasonRepository;
        public SuspenseReasonController(DSAContext context, ISuspenseReasonRepository suspense)
        {
            _context = context;
            _suspenseReasonRepository = suspense;
        }
        [HttpGet("GetSuspenseReasons", Name = "GetSuspenseReasons")]
        public IActionResult GetSuspenseReasons()
        {
            var model = _suspenseReasonRepository.getSuspenseReasons();
            return Ok(model);
        }
        // GET: OIPTYPEs/Details/5
        [HttpGet("Details/{type}")]
        public IActionResult Details(string code)
        {
            if (code == null)
            {
                return BadRequest();
            }
            SuspenseReasonDTO suspense = _suspenseReasonRepository.getSuspenseReason(code);

            if (suspense == null)
            {
                return NotFound();
            }
            return Ok(suspense);
        }
        // GET: OIPTYPEs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            SuspenseReasonDTO model = new SuspenseReasonDTO();
            return Ok(model);
        }

        // POST:Referral/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.

        // [ValidateAntiForgeryToken]
        [HttpPost("Create")]
        public IActionResult Create(SuspenseReasonDTO suspense)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //TODO: Check for existing?
            bool codeExist = _context.SuspRsn.Any(c => c.CdSuspRsn.Equals(suspense.Code));

            if (codeExist)
            {
                ModelState.AddModelError("Suspense Reason", "Code " + suspense.Code + " already exist!");
                if (!ModelState.IsValid)
                    return new UnprocessableEntityObjectResult(ModelState);
            }

            var o = _suspenseReasonRepository.convertSuspenseReason(suspense);
            _context.SuspRsn.Add(o);

            //Add 1 more record with Hearing Types = "S";
            try
            {
                _context.SaveChanges();
            }
            catch (SqlException e)
            {
                return StatusCode(422, "SQL Error!");

            }
            return Ok(o);
        }
        // GET: Referral/Edit/5
        [HttpGet("Edit/{code}")]
        public IActionResult Edit(string code)
        {
            if (code == null)
            {
                return BadRequest();
            }
            SuspenseReasonDTO model = _suspenseReasonRepository.getSuspenseReason(code);

            if (model == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

        // POST: Referral/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit")]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit(SuspenseReasonDTO susp)
        {

            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);


            var o = _suspenseReasonRepository.convertSuspenseReason(susp);
            _context.Entry(o).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetSuspenseReasons");

        }

        // GET: Referral/Delete/5
        [HttpGet("Delete/{code}")]
        public IActionResult Delete(string code)
        {
            if (code == null)
            {
                return BadRequest();
            }
            SuspenseReasonDTO o = _suspenseReasonRepository.getSuspenseReason(code);
            if (o == null)
            {
                return NotFound();
            }
            return Ok(o);
        }

        // POST: Referral/Delete/5
        [HttpPost("DeleteConfirmed/{code}")]
        //  [HttpPost, ActionName("Delete")]
        //  [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string code)
        {
            SuspenseReasonDTO suspense = _suspenseReasonRepository.getSuspenseReason(code);
            suspense.TermDate = DateTime.Now;
            var o = _suspenseReasonRepository.convertSuspenseReason(suspense);
            _context.Entry(o).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetSuspenseReasons");
        }
    }
}