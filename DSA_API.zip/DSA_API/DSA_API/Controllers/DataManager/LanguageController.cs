﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DSA_API.Entities;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/Language")]
    public class LanguageController : Controller
    {
        private DSAContext _context;
        public LanguageController(DSAContext context)
        {
            _context = context;
        }
        // GET: Languages/GetLanguages
       [HttpGet("GetLanguages", Name = "GetLanguages")]
        public IActionResult GetLanguages()
        {
            var model = _context.Language.ToList();
            return Ok(model);
        }

        // GET: LANGUAGEs/Details/5
        [HttpGet("Details/{id}")]
        public IActionResult Details(string id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Language lANGUAGE = _context.Language.Find(id);
            if (lANGUAGE == null)
            {
                return NotFound();
            }
            return Ok(lANGUAGE);
        }

        // GET: LANGUAGEs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            var model = _context.Language;
            return Ok(model);
        }

        // POST: LANGUAGEs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Create")]
        //[ValidateAntiForgeryToken]
        public IActionResult Create(Language lANGUAGE)
        {
            if (ModelState.IsValid)
            {
                var curr = _context.Language.AsNoTracking().Where(l => l.CdLanguage == lANGUAGE.CdLanguage).FirstOrDefault();

                if (curr == null)
                {
                    lANGUAGE.DescLanguage = lANGUAGE.DescLanguage.ToUpper();
                    _context.Language.Add(lANGUAGE);
                    _context.SaveChanges();
                    return RedirectToAction("GetLanguages");
                }
                else
                {
                    ModelState.AddModelError("Language", "Code " + lANGUAGE.CdLanguage + " Already Exist");
                    return new UnprocessableEntityObjectResult(ModelState);
                  
                }

                //var x = db.LANGUAGEs.OrderByDescending(s => s.CD_LANGUAGE)
                //                    .FirstOrDefault().CD_LANGUAGE;
                //var y = Convert.ToInt16(x) + 1;
                //lANGUAGE.CD_LANGUAGE = y.ToString("00");
                //lANGUAGE.DESC_LANGUAGE = lANGUAGE.DESC_LANGUAGE.ToUpper();
                //db.LANGUAGEs.Add(lANGUAGE);
                //db.SaveChanges();
                //return RedirectToAction("Index");
            }

            return new UnprocessableEntityObjectResult(ModelState);
        }

        // GET: LANGUAGEs/Edit/5
        [HttpGet("Edit/{id}")]
        public IActionResult Edit(string id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Language lANGUAGE = _context.Language.Find(id);
            if (lANGUAGE == null)
            {
                return NotFound();
            }
            return Ok(lANGUAGE);
        }

        // POST: LANGUAGEs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit")]
        //[ValidateAntiForgeryToken]
        public IActionResult Edit(Language lANGUAGE)
        {
            if (ModelState.IsValid)
            {
                lANGUAGE.DescLanguage = lANGUAGE.DescLanguage.ToUpper();
                _context.Entry(lANGUAGE).State = EntityState.Modified;
                _context.SaveChanges();
                return RedirectToAction("GetLanguages");
            }
            return Ok(lANGUAGE);
        }

        // GET: LANGUAGEs/Delete/5
        [HttpGet("Delete/{id}")]
        public IActionResult Delete(string id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Language lANGUAGE = _context.Language.Find(id);
            if (lANGUAGE == null)
            {
                return NotFound();
            }
            return View(lANGUAGE);
        }

        // POST: LANGUAGEs/Delete/5
        [HttpPost("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            Language lANGUAGE = _context.Language.Find(id);
           _context.Language.Remove(lANGUAGE);
            _context.SaveChanges();
            return RedirectToAction("GetLanguages");
        }
    }
}