﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/ActivityType")]
    public class ActivityTypeController : Controller
    {
        private DSAContext _context;
        private IActivityTypeRepository _activityTypeRepository;
        public ActivityTypeController(DSAContext context, IActivityTypeRepository activityType)
        {
            _context = context;
            _activityTypeRepository = activityType;
        }
        //// GET: ACTIVITYTYPEs
        //public ActionResult Index()
        //{
        //    //return View(repo.getAllActicityType());
        //    return View();
        //}

        // GET: activitytypes/getActTypes
        [HttpGet("GetActTypes", Name = "GetActTypes")]
        public IActionResult GetActTypes()
        {

            var model = _activityTypeRepository.getAllActivityType();

            return Ok(model);
        }

        // GET: ACTIVITYTYPEs/Details/5
        [HttpGet("Details/{id}")]
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            ActivityTypeDMDTO aCTIVITYTYPE = _activityTypeRepository.getActivityType(id.Value);

            if (aCTIVITYTYPE == null)
            {
                return NotFound();
            }
            return Ok(aCTIVITYTYPE);
        }

        // GET: ACTIVITYTYPEs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            ActivityTypeDMDTO model = new ActivityTypeDMDTO();
            return Ok(model);
        }

        // POST: ACTIVITYTYPEs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
   
        // [ValidateAntiForgeryToken]
        [HttpPost("Create")]
        public IActionResult Create(ActivityTypeDMDTO activityType)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
            
            //TODO: Check for existing?
            bool codeExist = _context.Activitytype.Any(c => c.CdActvyTyp.Equals(activityType.Code));

            if (codeExist)
            {
                ModelState.AddModelError("Activity Code", "Code " + activityType.Code + " already exist!");
                if (!ModelState.IsValid)
                    return new UnprocessableEntityObjectResult(ModelState);
            }

            activityType.lastUpdatedBy = (from u in _context.Employee
                                              //  where u.CdLgnId == User.Identity.Name
                                          where u.CdLgnId == "MPMPG4"
                                          select u.CdEmpId).FirstOrDefault();
            activityType.lastUpdetedDate = DateTime.Now;
            activityType.HearingTypes = "H";

            var at = _activityTypeRepository.convertActivityType(activityType);
            _context.Activitytype.Add(at);

            //Add 1 more record with Hearing Types = "S";
            try
            {
                _context.SaveChanges();
            }
            catch (SqlException e)
            {
                return StatusCode(422, "SQL Error!");
               
            }

            at.CdTypes = "S";
            _context.Activitytype.Add(at);

            try
            {
                _context.SaveChanges();
            }
            catch (SqlException e)
            {
                return StatusCode(410, "SQL Error!");
            }
            return Ok(at);

        }

        // GET: ACTIVITYTYPEs/Edit/5
        [HttpGet("Edit/{id}")]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            ActivityTypeDMDTO model = _activityTypeRepository.getActivityType(id.Value);

            if (model == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

        // POST: ACTIVITYTYPEs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit")]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit(ActivityTypeDMDTO activityType)
        {

        if (!ModelState.IsValid)
            return new UnprocessableEntityObjectResult(ModelState);


         
            activityType.lastUpdatedBy = (from u in _context.Employee
                                                //  where u.CdLgnId == User.Identity.Name
                                            where u.CdLgnId == "MPMPG4"
                                            select u.CdEmpId).FirstOrDefault();
            activityType.lastUpdetedDate = DateTime.Now;

            var at = _activityTypeRepository.convertActivityType(activityType);
            _context.Entry(at).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetActTypes");
           
        }

        // GET: ACTIVITYTYPEs/Delete/5
        [HttpGet("Delete/{id}")]
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            ActivityTypeDMDTO at = _activityTypeRepository.getActivityType(id.Value);
            if (at == null)
            {
                return NotFound();
            }
            return Ok(at);
        }

        // POST: ACTIVITYTYPEs/Delete/5
        [HttpPost("DeleteConfirmed/{id}")]
        //  [HttpPost, ActionName("Delete")]
        //  [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ActivityTypeDMDTO activityType = _activityTypeRepository.getActivityType(id);
            activityType.TermDate = DateTime.Now;
            //TODO:
            activityType.lastUpdatedBy = (from u in _context.Employee
                                              //  where u.CdLgnId == User.Identity.Name
                                          where u.CdLgnId == "MPMPG4"
                                          select u.CdEmpId).FirstOrDefault();
            activityType.lastUpdetedDate = DateTime.Now;

            var at = _activityTypeRepository.convertActivityType(activityType);

            _context.Entry(at).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetActTypes");
        }
    }
}