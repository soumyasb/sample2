﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/OIPType")]
    public class OIPTypeController : Controller
    {
        private DSAContext _context;
        private IOIPTypeRepository _oipTypeRepository;
        public OIPTypeController(DSAContext context, IOIPTypeRepository oipType)
        {
            _context = context;
            _oipTypeRepository = oipType;
        }
        // GET: oiptypes/getOIPTypes
        [HttpGet("GetOIPTypes", Name = "GetOIPTypes")]
        public IActionResult GetOIPTypes()
        {

            var model = _oipTypeRepository.getAllOIPType();

            return Ok(model);
        }
        // GET: OIPTYPEs/Details/5
        [HttpGet("Details/{type}")]
        public IActionResult Details(string type)
        {
            if (type == null)
            {
                return BadRequest();
            }
            OIPTypeDTO oiptype = _oipTypeRepository.getOIPType(type);

            if (oiptype == null)
            {
                return NotFound();
            }
            return Ok(oiptype);
        }
        // GET: OIPTYPEs/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            OIPTypeDTO model = new OIPTypeDTO();
            return Ok(model);
        }

        // POST: OIPTYPEs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.

        // [ValidateAntiForgeryToken]
        [HttpPost("Create")]
        public IActionResult Create(OIPTypeDTO oipType)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);

            //TODO: Check for existing?
            bool codeExist = _context.Oiptype.Any(c => c.CdPrtyTyp.Equals(oipType.Type));

            if (codeExist)
            {
                ModelState.AddModelError("OIP Code", "Code " + oipType.Type + " already exist!");
                if (!ModelState.IsValid)
                    return new UnprocessableEntityObjectResult(ModelState);
            }


            var o = _oipTypeRepository.convertOIPType(oipType);
            _context.Oiptype.Add(o);

            //Add 1 more record with Hearing Types = "S";
            try
            {
                _context.SaveChanges();
            }
            catch (SqlException e)
            {
                return StatusCode(422, "SQL Error!");

            }
            return Ok(o);
        }
        // GET: OIPTYPEs/Edit/5
        [HttpGet("Edit/{type}")]
        public IActionResult Edit(string type)
        {
            if (type == null)
            {
                return BadRequest();
            }
            OIPTypeDTO model = _oipTypeRepository.getOIPType(type);

            if (model == null)
            {
                return NotFound();
            }
            return Ok(model);
        }

        // POST: OIPTYPEs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Edit/{type}")]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit(OIPTypeDTO type)
        {

            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
       

            var o = _oipTypeRepository.convertOIPType(type);
            _context.Entry(o).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetOIPTypes");

        }

        // GET: OIPTYPEs/Delete/5
        [HttpGet("Delete/{type}")]
        public IActionResult Delete(string type)
        {
            if (type == null)
            {
                return BadRequest();
            }
            OIPTypeDTO o = _oipTypeRepository.getOIPType(type);
            if (o == null)
            {
                return NotFound();
            }
            return Ok(o);
        }

        // POST: OIPTYPEs/Delete/5
        [HttpPost("DeleteConfirmed/{type}")]
        //  [HttpPost, ActionName("Delete")]
        //  [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string type)
        {
            OIPTypeDTO oipType = _oipTypeRepository.getOIPType(type);
            oipType.TermDate = DateTime.Now;
            var o = _oipTypeRepository.convertOIPType(oipType);
            _context.Entry(o).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("GetOIPTypes");
        }
    }

}