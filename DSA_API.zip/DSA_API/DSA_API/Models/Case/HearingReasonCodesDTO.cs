﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class HearingReasonCodesDTO
    {
        public string HearingType { get; set; }
        public string ReasonCode { get; set; }
        public DateTime OrigHearingDate { get; set; }
        public string Message { get; set; }
    }
}
