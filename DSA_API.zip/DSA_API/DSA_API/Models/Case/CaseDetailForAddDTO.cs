﻿using DSA_API.Models.Customer;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models
{
    public class CaseDetailForAddDTO
    {
        private string _classLicense;
        private string _phoneNumber;
        private string _caseStatus;
        public string CaseNumber { get; set; }
        public string DLNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public System.DateTime? DT_BIRTH_PRSN { get; set; }
        public string PhoneNumber { get; set; }
        public string MailingAddress
        {
            get
            {
                if (!String.IsNullOrEmpty(Address2))
                {
                    Address2 = Address2 + System.Environment.NewLine;
                }
                return Address1 + System.Environment.NewLine + Address2 + City + ", " + State + " " + ZipFull;
            }
        }

        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipFull { get; set; }
        public string Zip { get; set; }
        //public string PhoneNumber
        //{
        //    set
        //    {
        //        _phoneNumber = String.IsNullOrEmpty(value) ? value : value.Trim();
        //    }
        //    get
        //    {
        //        return String.IsNullOrEmpty(_phoneNumber) ? "" : String.Format("{0:(###) ###-####}", double.Parse(_phoneNumber));
        //    }
        //}


        public string DOB
        {
            get
            {
                return DT_BIRTH_PRSN != null ? DT_BIRTH_PRSN.Value.ToString(@"MM\-dd\-yyyy") : "";
            }
        }
        public string classLicense
        {
            get
            {
                return DetermineLicenseClass(_classLicense);
            }

            set
            {
                _classLicense = value;
            }
        }
        public System.DateTime DT_RCPT { get; set; }

        public string CD_REFR_SRCE_TYP { get; set; }

        public string CD_RSN { get; set; }

        public string CD_ENDR { get; set; }

        public string CD_HRNG_TYP { get; set; }

        public string DESC_RSN { get; set; }

        public ICollection<AccidentDTO> Accidents { get; set; }
            = new List<AccidentDTO>();
        public string FRCaseNumber { get; set; }
        public DateTime AccidentDate { get; set; }
        public string AccidentCity { get; set; }
        public string Message { get; set; }
        public string ErrorMessage { get; set; }
        public string CaseStatus
        {
            get
            {
                return DetermineCaseStatus(_caseStatus);
            }

            set
            {
                _caseStatus = value;
            }
        }


        public string CaseStatusCode
        {
            get
            {
                return DetermineCaseStatus(_caseStatus).Substring(0, 2);
            }
            set
            {
                _caseStatus = value;
            }
        }
        private string DetermineCaseStatus(string status)
        {
            string output = "";
            switch (status)
            {
                case "10":
                    output = "UN - UnScheduled";
                    break;
                case "13":
                    output = "SC - Scheduled";
                    break;
                case "15":
                case "25":
                case "35":
                    output = "CL - Closed";
                    break;
                case "16":
                case "26":
                case "36":
                    output = "UP - Updated/Report not completed";
                    break;
                case "20":
                    output = "UR - UnScheduled/Reschedule";
                    break;
                case "30":
                    output = "UC - UnScheduled/Reconvene";
                    break;
                case "23":
                    output = "RS - Rescheduled";
                    break;
                case "33":
                    output = "RC - Reconvened";
                    break;
                case "11":
                case "12":
                case "21":
                case "22":
                case "31":
                case "32":
                    output = "UN - UnScheduled";
                    break;
                default:
                    output = status;
                    break;
            }
            return output;
        }
        private string DetermineLicenseClass(string licclass)
        {
            string output = "";
            switch (licclass)
            {
                case "A":
                case "D":
                    output = "A";
                    break;
                case "B":
                case "E":
                    output = "B";
                    break;
                case "C":
                case "F":
                    output = "C";
                    break;
                case "N":
                    output = "1";
                    break;
                case "P":
                    output = "2";
                    break;
                case "R":
                    output = "3";
                    break;
                case "S":
                    output = "4";
                    break;
                case "U":
                    output = "M1";
                    break;
                case "Y":
                    output = "M2";
                    break;
                default:
                    output = licclass;
                    break;
            }
            return output;
        }

    }
}
