﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class ScheduledCaseDetailDTO
    {
        public CaseDetailScheduledDTO CaseDetail { get; set; }
        public List<OIPDTO> OIPs { get; set; }
          = new List<OIPDTO>();
        public CaseRescheduleListDTO Reschedules { get; set; }
       
        public EmployeeContactsDTO EmployeeContacts { get; set; }
       
        public CaseContactsDTO Contacts { get; set; }
        
    }
}
