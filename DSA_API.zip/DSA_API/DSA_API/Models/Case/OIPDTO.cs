﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class OIPDTO
    {
        public string resourceURI { get; set; }
        public string caseAssignURI { get; set; }
        public int OIPID { get; set; }
        public string NbrOIP { get; set; }
        public string CDUPDTTECHID { get; set; }
        public string NMEFRSTPRSN { get; set; }
        public string NMESURNMEPRSN { get; set; }
        public string NMEMIDPRSN { get; set; }
        public string NMESUFXPRSN { get; set; }
        public string NBRPHONE { get; set; }
        public string NBRCELLPHONE { get; set; }
        public string NBRFAX { get; set; }
        public string EmailAddress { get; set; }
        public string ADDRLN1 { get; set; }
        public string CDCITY { get; set; }
        public string CDSTATE { get; set; }
        public string CDZIP { get; set; }
        public string NMEAGENCY { get; set; }
        public string TXTCOMM { get; set; }
        public string CDPRTYTYP { get; set; }
        public string DESCPRTYTYP { get; set; }
        public string CdCase { get; set; }
        public string  CDLANGUAGE { get; set; }
        public List<LanguageDTO> Languages { get; set; }
        public bool Error { get; set; }

        //
        //  variables below used by javascript for displaying only the dto values listed in detailsDisplayed &
        //  with the clean titles matching the index in detailsCleanNames
        //
        public string[] detailsDisplayed = new string[4] { "NME_AGENCY", "NBR_PHONE", "NBR_CELL_PHONE", "NBR_FAX" };
        public string[] detailsCleanNames = new string[4] { "Agency Name", "Phone Number", "Cell Number", "Fax Number" };
    }
}
