﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models
{
    public class ClosedCaseConvertDetailDTO
    {
        public string DlNumber { get; set; }
        public string CaseNumber { get; set; }
        public string SubjectName { get; set; }
        public string Type { get; set; }
        public string HearingDate { get; set; }
        public string Location { get; set; }
        public string Reason { get; set; }
        public string ScheduledResults { get; set; }
        public string TypeAction { get; set; }
        public string ModifiedDate { get; set; }
        public string AuthoritySection1 { get; set; }
        public string AuthoritySection2 { get; set; }
        public string AuthoritySection3 { get; set; }
        public string EffectiveDate { get; set; }
        public string ThroughDate { get; set; }
        public string ActionTermDate { get; set; }
        public string MailDate { get; set; }
        public string OriginalAuthoritySection { get; set; }
        public string OriginalEffectiveDate { get; set; }
        public string ScheduledTo { get; set; }
        public string DateUpdated { get; set; }
        public string UpdatedBy { get; set; }
        public string DateClosed { get; set; }
        public string ClosedBy { get; set; }
    }
}
