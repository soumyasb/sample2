﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class ClosedCaseDetailDTO
    {

        public string CD_CASE_CLSE_ID { get; set; }
        public DateTime DT_CASE_CLSE { get; set; }
        public DateTime DT_MOD_SCHED_HR { get; set; }
        public string CD_SCHED_RSL { get; set; }
        public string CD_TYP_ACT { get; set; }
        public DateTime DT_TYP_ACT_EFF { get; set; }
        public DateTime DT_TYP_ACT_MOD { get; set; }
        public DateTime DT_TYP_ACT_END { get; set; }
        public DateTime DT_TYP_ACT_TERM { get; set; }
        public string CD_VEH_AUTH_ORIG { get; set; }
        public string CD_VEH_AUTH1 { get; set; }
        public string  CD_VEH_AUTH2 { get; set; }
        public string CD_VEH_AUTH3 { get; set; }
        public DateTime DT_SCHED_HRNG { get; set; }
        public DateTime DT_MAIL { get; set; }
        public string CD_DL_UPDATE_ID { get; set; }
        public DateTime DT_DL_UPDATE { get; set; }
        public string CD_OFF_ABBR { get; set; }
        public string CD_EMP_ID { get; set; }
        public string NBR_DL { get; set; }
        public string CD_RSN { get; set; }
        public string CD_HRNG_TYP { get; set; }
        public string SUBJECT_FIRST_NAME { get; set; }
        public string SUBJECT_LAST_NAME { get; set; }
        public string SCHEDULED_EMPLOYEE_FIRST_NAME { get; set; }
        public string SCHEDULED_EMPLOYEE_LAST_NAME { get; set; }
        public string CLOSED_EMPLOYEE_FIRST_NAME { get; set; }
        public string CLOSED_EMPLOYEE_LAST_NAME { get; set; }
        public string UPDATED_EMPLOYEE_FIRST_NAME { get; set; }
        public string UPDATED_EMPLOYEE_LAST_NAME { get; set; }
        public string NBR_CASE_ACC_FR { get; set; }
        public string FLG_HEARING { get; set; }
        public string CD_FLD_DSO_ALPHA { get; set; }
       
    }
}
