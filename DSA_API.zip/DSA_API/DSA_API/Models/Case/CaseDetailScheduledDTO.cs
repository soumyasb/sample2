﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CaseDetailScheduledDTO
    {
        public string DLNumber { get; set; }
        public string SubjectName { get; set; }
        public string ReceiptDate { get; set; }
        public string HearingType { get; set; }
        public string Reason { get; set; }
    }
}
