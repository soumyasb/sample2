﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CoverSheetContactDTO
    {
        public DateTime dt_cntct_strt_tim { get; set; }
        public string CD_HRNG_TYP { get; set; }
        public string CD_RSN { get; set; }
        public string CD_EMP_ID { get; set; }
        public string CD_OFF_ABBR { get; set; }
        public string NBR_ROOM { get; set; }
        public string CD_REFR_SRCE_TYP { get; set; }
        public string Comment { get; set; }
        public string CD_AUTH_ID { get; set; }
    }
}
