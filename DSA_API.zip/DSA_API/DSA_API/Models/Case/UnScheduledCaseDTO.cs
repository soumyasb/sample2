﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class UnScheduledCaseDTO
    {
        public string CD_STATUS_REC { get; set; }
        public DateTime DT_RCPT { get; set; }
        public string CD_RSN { get; set; }
        public string NBR_DL { get; set; }
        public string CD_CASE { get; set; }
        public string PersonFirstName { get; set; }
        public string PersonLastName { get; set; }
        public string CD_FLD_DSO_ALPHA { get; set; }
        public string CD_HRNG_TYP { get; set; }
    }
}

