﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models
{
    public class CaseCommentDeleteDTO
    {
        bool value = true;
        public string DLNumber { get; set; }
        public string CommentNumber { set; get; }
        public string Message { get; set; }
        public bool DeleteFlag
        {
            get { return this.value;}
            set { this.value = value; }
        }
        public bool Error { get; set; }
    }
}
