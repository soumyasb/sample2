﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class SuspenseDetailDTO
    {
        public int Suspense_ID { get; set; }
        public int NBR_SEQUENCE { get; set; }
        public string SuspenseDate { get; set; }
        public string RequestedBy { get; set; }
        public string SuspenseReason { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdateDate { get; set; }
        public string SuspenseDescription { get; set; }
    }
}
