﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class SuspenseCaseEmployeeDTO
    {
        public string CD_CASE { get; set; }
        public string DLNumber { get; set; }
        public string SubjectName { get; set; }
        public string EmployeeRequestor { get; set; }

        public List<SuspenseDetailDTO> Suspense { get; set; }
           = new List<SuspenseDetailDTO>();
        public string  Message { get; set; }
        public string  ErrorMessage { get; set; }
    }
}
