﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class SuspenseCaseDTO
    {
        public int Suspense_ID { get; set; }
        public string CD_CASE { get; set; }
        public int NBR_SEQUENCE { get; set; }
        public DateTime SuspenseDate { get; set; }
        public string RequestedBy { get; set; }
        public string SuspenseReason { get; set; }
        public string  UpdatedBy { get; set; }
        public DateTime UpdateDate { get; set; }
        public string SuspenseDescription { get; set; }
       
    }
}
