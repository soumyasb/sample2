﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CaseContactsDTO
    {
        public List<CaseContactDTO> results { get; set; }

        public int ResultCount
        {
            get { return results.Count(); }
        }
    }
}
