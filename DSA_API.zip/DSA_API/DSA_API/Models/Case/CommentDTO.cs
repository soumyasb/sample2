﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models
{
    public class CommentDTO
    {
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
        public string commentTextInput { get; set; }
        public string placeholder { get; set; }
        public string DLNumber { get; set; }
        public string CommentType { get; set; }
        public string CommentNumber { set; get; }
        public string EmployeeID { set; get; }
        public string LastnameFirst3 { set; get; }
        public string PurgeDate { set; get; }
        public string RefreshLink { get; set; }
        public Dictionary<string, string> ErrorFields = new Dictionary<string, string>();
    }
}
