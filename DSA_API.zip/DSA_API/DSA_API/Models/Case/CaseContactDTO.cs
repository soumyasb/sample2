﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CaseContactDTO
    {
        public string SCHEDBY_NME_FRST_PRSN { get; set; }
        public string SCHEDBY_NME_SRNME_PRSN { get; set; }
        public string  ScheduledBy { get; set; }
        public string dt_cntct_strt_tim { get; set; }
        public string dt_cntct_end_tim { get; set; }
        public string ScheduledOn { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }

        public string Nme_Off { get; set; }
        public string Location { get; set; }
        public string DT_SCHED_TRANS { get; set; }
        public string ScheduledDate { get; set; }
        public string Status { get; set; }
        public string ROOM { get; set; }
    }
}
