﻿using DSA_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CaseCommentsDTO
    {
        public string resourceURI { get; set; }
        public int TotalComments { get; set; }
        public double TotalPages { get; set; }
        public string baseURI { get; set; }
        public string NextPageURL { get; set; }
        public string PrevPageURL { get; set; }
        public int CurrentPage { get; set; }
        public List<CustomerCommentDTO> Comments { get; set; }
    }
}
