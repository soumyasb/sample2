﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.CaseClosure
{
    public class CCBoolDTO
    {
        public bool Field { get; set; }
        public string Status { get; set; }
    }
}
