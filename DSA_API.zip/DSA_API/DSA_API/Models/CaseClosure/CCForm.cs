﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.CaseClosure
{
    public class CCForm
    {
        public string FormID { get; set; }

        //Authority Section
        public CCStringDTO FirstAuthSect1 { get; set; }
        public CCStringDTO FirstAuthSect2 { get; set; }
        public CCStringDTO FirstOriginalAuthSect { get; set; }
        public CCStringDTO SecondAuthSect1 { get; set; }
        public CCStringDTO SecondAuthSect2 { get; set; }
        public CCStringDTO SecondOriginalAuthSect { get; set; }

        //Dates
        public CCDateDTO FirstEffectiveDate { get; set; }
        public CCStringDTO FirstThroughDate { get; set; }
        public CCDateDTO OriginalEffectiveDate { get; set; }
        public CCDateDTO SecondEffectiveDate { get; set; }
        public CCStringDTO SecondThroughDate { get; set; }
        public CCStringDTO MedicalSuspenceDueDate { get; set; }
        public CCDateDTO ArrestDetainDate { get; set; }
        public CCDateDTO MailDate { get; set; }

        //Miscellaneous
        public CCStringDTO UpdateCopies { get; set; }
        public CCStringDTO CoFo { get; set; }
        public CCStringDTO PMCode { get; set; }
        public CCStringDTO CommercialStatusIndicator { get; set; }

        //Restrictions
        public CCBoolDTO IsAdd { get; set; }
        public CCBoolDTO IsDelete { get; set; }
        public CCStringDTO Restriction1 { get; set; }
        public CCStringDTO Restriction2 { get; set; }
        public CCStringDTO Restriction3 { get; set; }

        //VOP Type
        public CCBoolDTO IsAPS { get; set; }
        public CCBoolDTO IsAPSRefusal { get; set; }
        public CCBoolDTO IsPAS { get; set; }
        public CCBoolDTO IsPASRefusal { get; set; }

        //Type
        public CCBoolDTO IsVOPBAC { get; set; }
        public CCBoolDTO IsVOPRefusal { get; set; }

        public CCStringDTO FieldFile { get; set; }
        public CCStringDTO RouteCode { get; set; }
        public CCStringDTO MedicalSuspence { get; set; }
        public CCStringDTO CreditDays { get; set; }
        public CCStringDTO InsertParagraph { get; set; }
        public CCStringDTO CountyCode { get; set; }
        public CCStringDTO LicenceLocation { get; set; }

        //Out of state
        public CCStringDTO OSDLNumber { get; set; }
        public CCStringDTO OSCode { get; set; }

        public CCStringDTO SecondReasonCode { get; set; }

        public CCBoolDTO ProbationSuspance01opt{ get; set; } //button for a DUJ screen (suspanse)
        public CCBoolDTO ServiceOfOrderOpt { get; set; }







    }
}
