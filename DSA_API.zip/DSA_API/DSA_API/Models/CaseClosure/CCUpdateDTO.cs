﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.CaseClosure
{
    public class CCUpdateDTO
    {

        public string CaseNumber { get; set; }
        public string ScheduledResults { get; set; }
        public string TypeActionOne { get; set; }
        public string TypeActionTwo { get; set; }
        public string Stay { get; set; }
        public string StayValue { get; set; }
        public CCForm Form { get; set; }


    }
}
