﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.CaseClosure
{
    public class CaseClosurePageDTO
    {
        
        //Subject

        //Hearing

        //
        public string ScheduledResults { get; set; }
        public string TypeActionOne { get; set; }
        public string TypeActionTwo { get; set; }
        public bool? IsStayed { get; set; }
        public string Stay { get; set; }

        //
        public CCForm CaseClosureForm { get; set; }



    }
}
