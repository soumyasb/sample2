﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.InquiryTCodes
{
    public class DLInqParams
    {
        public string DLNumber { get; set; }
        public string VLNumber { get; set; }
        public string Name { get; set; }
        public string ThreeCharacterLastName { get; set; }
        public string BirthDate { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Zone { get; set; }
        public string CourtNumber1 { get; set; }
        public string CourtNumber2 { get; set; }
        public string CourtNumber3 { get; set; }
        public string TACode { get; set; }
        public string EffectiveDate { get; set; }
        public string AuthSec1 { get; set; }
        public string AuthSec2 { get; set; }
        public string AuthSec3 { get; set; }
        public string DocumentDate { get; set; }
        public string DocumentOffice { get; set; }
        public string ReasonCode { get; set; }
    }
}
