﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.InquiryTCodes
{
    public class HRPDTO
    {
        public string HRPDLNUMBER { get; set; }
        public string HRPLASTNAME { get; set; }
        public string HRPTACODE { get; set; }
        public string HRPREASONCODE { get; set; }
        public string HRPEFFECTIVEDATE { get; set; }
        public string HRPAUTHSEC1 { get; set; }
        public string HRPAUTHSEC2 { get; set; }
        public string HRPAUTHSEC3 { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}

