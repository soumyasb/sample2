﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.InquiryTCodes
{
    public class InquiryDTO
    {
        public string TCode { get; set; }
        public string InfoCode { get; set; }
        public string FileCode { get; set; }
        public DLInqParams ParameterObj { get; set; }
    }
}
