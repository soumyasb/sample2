﻿using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.EmployeeProfile
{
    public class EmployeeProfileInitialDTO
    {
        public int SelectedEmployeeId { get; set; }
        public IEnumerable<EmployeeProfileDTO> EmpProfiles { get; set; }
        public IEnumerable<EmployeeDTO> EmployeeListForRegion { get; set; }
        public IEnumerable<SelectListItem> OfficeListForRegion { get; set; }
        public IEnumerable<SelectListItem> ClassificationList { get; set; }
    }
}
