﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.EmployeeProfile
{
    public class EmployeeProfileDayDTO
    {
        [Display(Name = "Id")]
        public int ID { get; set; }
        [Display(Name = "Profile Id")]
        public int ProfileID { get; set; }
        [Display(Name = "Day of Week")]
        public int DayCount { get; set; }
        [Display(Name = "Day Start")]
        [DataType(DataType.Time)]
        //[ValidateTimeInRange(600, 1200)]
        public DateTime DayStart { get; set; }
        [Display(Name = "Day End")]
        //[ValidateTimeInRange(1400, 2000)]
        [DataType(DataType.Time)]
        public DateTime DayEnd { get; set; }
        [Display(Name = "AM Break Start")]
        //[ValidateTimeInRange(700, 1300)]
        [DataType(DataType.Time)]
        public DateTime AMBreakStart { get; set; }
        [Display(Name = "AM Break End")]
        //[ValidateTimeInRange(700, 1300)]
        [DataType(DataType.Time)]
        public DateTime AMBreakEnd { get; set; }
        [Display(Name = "PM Break Start")]
        //[ValidateTimeInRange(1200, 1700)]
        [DataType(DataType.Time)]
        public DateTime PMBreakStart { get; set; }
        [Display(Name = "PM Break End")]
        //[ValidateTimeInRange(1200, 1700)]
        [DataType(DataType.Time)]
        public DateTime PMBreakEnd { get; set; }
        [Display(Name = "Lunch Start")]
        //[ValidateTimeInRange(900, 1500)]
        [DataType(DataType.Time)]
        public DateTime LunchBreakStart { get; set; }
        [Display(Name = "Lunch End")]
        //[ValidateTimeInRange(1000, 1600)]
        [DataType(DataType.Time)]
        public DateTime LunchBreakEnd { get; set; }
        [Display(Name = "Alternative Day")]
        public bool IsAlternitiveDay { get; set; }
        [Display(Name = "Telecomute Day")]
        public bool IsTelecomuteDay { get; set; }
        [Display(Name = "Travel To - Start")]
        [DataType(DataType.Time)]
        public DateTime? TravelToStart { get; set; }
        [Display(Name = "Travel To - End")]
        [DataType(DataType.Time)]
        public DateTime? TravelToEnd { get; set; }
        [Display(Name = "Travel From - Start")]
        [DataType(DataType.Time)]
        public DateTime? TravelFromStart { get; set; }
        [Display(Name = "Travel From - End")]
        [DataType(DataType.Time)]
        public DateTime? TravelFromEnd { get; set; }
        //public IEnumerable<string> TimeBlockList { get; set; }
        public bool DayActive { get; set; }
    }
}
