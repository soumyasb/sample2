﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.EmployeeProfile
{
    public class ConflictDTO
    {
        public DateTime ConflictDateTimeStart { get; set; }
        public DateTime ConfilctDateTimeEnd { get; set; }
        public string OfficeId { get; set; }
        public string DLNumber { get; set; }
        public string CaseNumber { get; set; }
        public int EmpID { get; set; }
    }
}
