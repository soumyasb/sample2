﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.EmployeeProfile
{
    public class EmployeeProfileDTO 
    {
        public int ProfileId { get; set; }
        public int EmpID { get; set; }
        [Display(Name = "Office")]
        public string OfficeID { get; set; }
        [Display(Name = "Effective Start Date")]
        [DataType(DataType.Date)]
        public DateTime EffectiveStartDate { get; set; }
        [Display(Name = "Effective End Date")]
        [DataType(DataType.Date)]

        public DateTime? EffectiveEndDate { get; set; }
        public string WorkWeekType { get; set; }
        public int? UpdatedByID { get; set; }
        public DateTime? UpdatedDay { get; set; }
        public IEnumerable<EmployeeProfileDayDTO> ProfileDays { get; set; }
    }
}
