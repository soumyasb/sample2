﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.HearingRoomProfile
{
    public class HearingRoomProfileDTO
    {
        public int Id { get; set; }
        public int HearingRoomId { get; set; }
        //public DateTime EffectiveStartDate { get; set; }
        //public DateTime? EffectiveEndDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool isActive { get; set; }
        //public bool isPhoneAvailable { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Monday Start Time must be HH:MM format")]
        public string MonStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Modnay End Time must be HH:MM format")]
        public string MonEndTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Tuesday Start Time must be HH:MM format")]
        public string TueStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Tuesday End Time must be HH:MM format")]
        public string TueEndTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Wednesday Start Time must be HH:MM format")]
        public string WedStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Wednesday End Time must be HH:MM format")]
        public string WedEndTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Thursday Start Time must be HH:MM format")]
        public string ThuStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Thursday End Time must be HH:MM format")]
        public string ThuEndTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Friday Start Time must be HH:MM format")]
        public string FriStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Friday End Time must be HH:MM format")]
        public string FriEndTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Satruday Start Time must be HH:MM format")]
        public string SatStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Saturday End Time must be HH:MM format")]
        public string SatEndTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Sunday Start Time must be HH:MM format")]
        public string SunStartTime { get; set; }
        [RegularExpression(@"^([0-1][0-9]|2[0-3]):([0-5][0-9])$", ErrorMessage = "Sunday End Time must be HH:MM format")]
        public string SunEndTime { get; set; }

    }
}
