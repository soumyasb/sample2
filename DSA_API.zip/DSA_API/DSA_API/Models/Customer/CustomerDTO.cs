﻿using DSA_API.Models.Customer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class CustomerDTO
    {
        private string _classLicense;
        private string _phoneNumber;

        public string DLNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Suffix { get; set; }
        public string SSN { get; set; }
        public System.DateTime? DT_BIRTH_PRSN { get; set; }
        public string PhoneNumber  { get; set; }
                                           //public string PhoneNumber
                                           //{
                                           //    set
                                           //    {
                                           //        _phoneNumber = String.IsNullOrEmpty(value) ? value : value.Trim();
                                           //    }
                                           //    get
                                           //    {
                                           //        return String.IsNullOrEmpty(_phoneNumber) ? "" : String.Format("{0:(###) ###-####}", double.Parse(_phoneNumber));
                                           //    }
                                           //}


        public string DOB
        {
            get
            {
                return DT_BIRTH_PRSN != null ? DT_BIRTH_PRSN.Value.ToString(@"MM\-dd\-yyyy") : "";
            }
        }

       
        public string MailingAddress
        {
            get
            {
                if (!String.IsNullOrEmpty(Address2))
                {
                    Address2 = Address2 + System.Environment.NewLine;
                }
                return Address1 + System.Environment.NewLine + Address2 + City + ", " + State + " " + ZipFull;
            }
        }
        public string flgAddr { get; set; }
        public bool ConfidentialAddress
        {
            get
            {
                if (!String.IsNullOrEmpty(flgAddr))
                {
                    if (flgAddr == "1")
                        return true;
                    if (flgAddr == "Y")
                        return true;
                    if (flgAddr == "N")
                        return false;
                }
                return false;
            }
        }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipFull { get; set; }
        public string Zip { get; set; }
        public IEnumerable<CaseDetailDTO> cases { get; set; }

        [DisplayName("License Class")]
        public string classLicense
        {
            get
            {
                return DetermineLicenseClass(_classLicense);
            }

            set
            {
                _classLicense = value;
            }
        }
        public string Class1 { get; set; }
        public string Class2 { get; set; }
        public List<string> DCSDifferences { get; set; }
           = new List<string>();
     
        public string D26ValidationMessage { get; set; }
        public bool D26ValidationOK { get; set; }
        public string AccidentMessage { get; set; }
        public ICollection<AccidentDTO> Accidents { get; set; }
             = new List<AccidentDTO>();
        public string FRCaseNumber { get; set; }
        public string AccidentCity { get; set; }
        public DateTime AccidentDate { get; set; }
        public bool Archived { get; set; }
        public string Message { get; set; }
        public string ErrorMessage { get; set; }
        private string DetermineLicenseClass(string licclass)
        {
            string output = "";
            switch (licclass)
            {
                case "A":
                case "D":
                    output = "A";
                    break;
                case "B":
                case "E":
                    output = "B";
                    break;
                case "C":
                case "F":
                    output = "C";
                    break;
                case "N":
                    output = "1";
                    break;
                case "P":
                    output = "2";
                    break;
                case "R":
                    output = "3";
                    break;
                case "S":
                    output = "4";
                    break;
                case "U":
                    output = "M1";
                    break;
                case "Y":
                    output = "M2";
                    break;
                default:
                    output = licclass;
                    break;
            }
            return output;
        }

    }
}
