﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class LicenseRestrictionsDTO
    {
        public string Restriction { get; set; }
    }

      
}

