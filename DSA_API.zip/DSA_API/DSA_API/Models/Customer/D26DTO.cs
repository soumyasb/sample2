﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class D26DTO
    {

            public string DLNumber { get; set; }
            public string __RequestVerificationToken { get; set; }
    }
}

