﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.HearingAuth
{
    public class HearingAuthDTO
    {
        public int ID { get; set; }
        public int EmpID { get; set; }
        public int CategoryID { get; set; }
        [Display(Name = "Catergory")]
        public string CategoryName { get; set; }

        [Display(Name = "Hearing")]
        public int HearingTime { get; set; }
        [Display(Name = "Interview")]
        public int InterviewTime { get; set; }
        [Display(Name = "Reexamination")]
        public int ReExamTime { get; set; }
        [Display(Name = "Last Updated")]
        [DataType(DataType.Date)]
        public DateTime LastUpdated { get; set; }
        [Display(Name = "Active")]
        public bool Active { get; set; }
    }
}
