﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME4UpdateDTO 
    {
        public string SBAREQCODE { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBANAME { get; set; }
        public string SBAISSUEDATE { get; set; }
        public string SBAEXPIREDATE { get; set; }
        public string SBALICENSESTATE { get; set; }
        public string SBALICENSENUMBER { get; set; }
        public string SBAPURGE { get; set; }
        public string SBAREGISTRYNUMBER { get; set; }
        public string SBASPECIALTY { get; set; }
        public string SBAAREACODE { get; set; }
        public string SBAPREFIX { get; set; }
        public string SBANUMBER { get; set; }
        public string SBAEXAMLASTNAME { get; set; }
        public string SBAEXAMFIRSTNAME { get; set; }
        public string SBAEXAMMIDDLENAME { get; set; }
        public string SBAEXAMSUFFIX { get; set; }
        public string SBACODE1 { get; set; }
        public string SBACODE2 { get; set; }
        public string SBACODE3 { get; set; }
        public string SBACODE4 { get; set; }
        public string SBACODE5 { get; set; }
        public string SBACODE6 { get; set; }
        public string SBACODE7 { get; set; }
        public string SBACODE8 { get; set; }
        public string SBACODE9 { get; set; }
        public string SBACODE10 { get; set; }
        public string SBARECEIVEDDATE { get; set; }
        public string SBAWAIVERTYPE { get; set; }
        public string SBAWAIVEREFFECTIVEDATE { get; set; }
        public string SBAWAIVEREXPIRATIONDATE { get; set; }
        public string SBAWAIVERRESCINDDATE { get; set; }
        public string SBASPEEFFECTIVEDATE { get; set; }
        public string SBASPEEXPIRATIONDATE { get; set; }
        public string SBASPECANCELDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
