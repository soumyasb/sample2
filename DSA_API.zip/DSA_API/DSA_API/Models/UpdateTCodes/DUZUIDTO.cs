﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUZUIDTO : IValidatableObject
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]

        public string BirthDate { get; set; }

        [Required]
        public string AuthoritySection { get; set; }
        [Required]
        public string TypeAction { get; set; }
        [Required]
        public string Reason { get; set; }

        public string NewEffectiveDate { get; set; }
        public string ThroughDate { get; set; }
        public string MailDate { get; set; }
        public string OrigAuthoritySection { get; set; }
        public string OrigEffectiveDate { get; set; }
        public string UpdateCopies { get; set; }
        [StringLength(25)]
        public string OutOfStateDLNo { get; set; }
        public string OutOfStateCd { get; set; }
        public string CommercialStatusIndicator { get; set; }
        public string HearingType { get; set; }
        public string HearingDate { get; set; }
        public string HearingLocation { get; set; }
        public string HearingResult { get; set; }
        public string ModifiedHearingDate { get; set; }
        public string EndStay { get; set; }
        public bool PMOption { get; set; }
        public string PMCode { get; set; }
        public string RestrictionsOptions { get; set; }
        public string Restriction1 { get; set; }
        public string Restriction2 { get; set; }
        public string Restriction3 { get; set; }
        public string CoFo { get; set; }
        public string LicenseLocation { get; set; }
        public string FieldFile { get; set; }
        [StringLength(4)]
        public string RouteCode { get; set; }
        [StringLength(2)]
        public string MedicalSuspense { get; set; }
        public string DUZResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (RestrictionsOptions == "A" || RestrictionsOptions == "D")
            {
                if (String.IsNullOrEmpty(Restriction1) && String.IsNullOrEmpty(Restriction2) && String.IsNullOrEmpty(Restriction3) )
                {
                    yield return new ValidationResult(
                  "Restrictions are missing when restriction options are A or D",
                   new[] { "Restrictions" });
                }
            }
        }
    }
}
