﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using DSA_API.Helpers;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DASUIDTO : IValidatableObject
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]

        public string BirthDate { get; set; }
        [Required]
        [StringLength(1)]
        public string VOPType { get; set; }
        [Required]
        public string DetainDate { get; set; }
      
        [StringLength(2)]
        public string VOPTestType { get; set; }
        [StringLength(1)]
        public string UpdateCopies { get; set; }
        [StringLength(25)]
        public string LawEnforcementAgency { get; set; }
        [Required]
        [StringLength(5)]
        public string CourtCode { get; set; }
        [StringLength(13)]
        public string LawEnforcementCaseNo { get; set; }
        [Required]
        [StringLength(3)]
        public string DSFieldOffice { get; set; }
       
        [StringLength(2)]
        public string VOPBAC1 { get; set; }
       
        [StringLength(2)]
        public string VOPBAC2 { get; set; }
        [StringLength(25)]
        public string OutOfStateDLNo { get; set; }
        [StringLength(2)]
        public string OutOfStateCd { get; set; }
        [Required]
        [StringLength(1)]
        public string CommercialStatusIndicator { get; set; }

        public string EffectiveDate { get; set; }
        public string MailDate { get; set; }
        public string EndStay { get; set; }
        public string OrigAuthSect { get; set; }
        public string OrigEffectiveDate { get; set; }
        public string HearingDate { get; set; }
        [StringLength(1)]
        public string HearingResult { get; set; }
        [StringLength(1)]
        public string HearingType { get; set; }

        public string ModifiedHearingDate { get; set; }

        public string CorrArrestDate { get; set; }
        [StringLength(1)]
        public string CoFo { get; set; }

        public string DiffServDate { get; set; }
        [StringLength(2)]
        public string LicenseLocation { get; set; }
        [StringLength(3)]
        public string CreditDays { get; set; }
        public string DASResponse { get; set; }

        public string DARResponse { get; set; }
        public string NextDLNumber { get; set; }
        public string TestDate { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            DateTime date1;
            DateTime date2;
            bool success;
            int result;
            if (DLNumber.Length < 8)
            {
                yield return new ValidationResult(
                    $"Please enter a valid DL Number",
                    new[] { "DLNumber" });
            }

            if (ThreeCharacterLastName.Length < 3)
            {
                yield return new ValidationResult(
                    $"The name is not in the correct format",
                    new[] { "ThreeCharacterLastName" });
            }


            if (CourtCode.Length < 5)
            {
                yield return new ValidationResult(
                    $"Court Code must be 5 digits long.",
                    new[] { "CourtCode" });
            }
            if (VOPType == "A" && String.IsNullOrEmpty(VOPTestType))
            {
                yield return new ValidationResult(
                    $"When VOP type is BAC .01% is checked, VOP Type Test must be entered.",
                    new[] { "VOPTestType" });
            }

            if (!string.IsNullOrEmpty(CoFo))
            {
                if (CoFo.Substring(0, 1) == "B" && string.IsNullOrEmpty(EffectiveDate))
                {
                    yield return new ValidationResult(
                        "Effective Date required with CO/FO code",
                        new[] { "COFO" });
                }
            }
           
        
            DateFunctions.ConvertStringToDate(EffectiveDate, "MMddyy", out date1);
            DateFunctions.ConvertStringToDate(DetainDate, "MMddyy", out date2);
            result = DateFunctions.CompareDates(date1, date2);
            if (!string.IsNullOrEmpty(EffectiveDate) && !string.IsNullOrEmpty(DetainDate))
            { 
                if (result < 0)
                {
                    yield return new ValidationResult(
                        "Effective Date after Detention Date",
                        new[] { "Effective Date" });
                }
            }
            if (VOPType == "A" && !CheckBloodContent("VOP", VOPTestType) && !CheckReimpose())
            {
                yield return new ValidationResult(
                     ErrorMessage,
                      new[] { "VOPType" });
            }

            if (string.IsNullOrEmpty(EndStay) && !string.IsNullOrEmpty(CoFo))
            {
                yield return new ValidationResult(
                     "When End Stay is used, CO/FO must not be used.",
                      new[] { "EndStay" });
            }
            if (string.IsNullOrEmpty(EndStay) && !CheckReimpose())
            {
                yield return new ValidationResult(
                     "Reimpose data required.",
                      new[] { "EndStay" });
            }
            if (!string.IsNullOrEmpty(EndStay))
            {
                if ((EndStay.Substring(0, 1) == "4" || EndStay.Substring(0, 1) == "5") && string.IsNullOrEmpty(MailDate))
                {
                    yield return new ValidationResult(
                        "Mail Date required.",
                         new[] { "MailDate" });
                }
            }
           
            if (!string.IsNullOrEmpty(CoFo))
            {
                if ((CoFo.Substring(0, 1) == "B" || UpdateCopies.Substring(0, 1) == "9") && string.IsNullOrEmpty(MailDate))
                {
                    yield return new ValidationResult(
                        "Mail Date required.",
                         new[] { "MailDate" });
                }
            }
          
            if (string.IsNullOrEmpty(EndStay) && !string.IsNullOrEmpty(CreditDays))
            {
                yield return new ValidationResult(
                    "End Stay required.",
                     new[] { "EndStay" });
            }
            DateFunctions.ConvertStringToDate(EffectiveDate, "MMddyy", out date1);
            DateFunctions.ConvertStringToDate(DetainDate, "MMddyy", out date2);
            result = DateFunctions.CompareDates(date1, date2);
            if (!string.IsNullOrEmpty(DiffServDate) && !string.IsNullOrEmpty(DetainDate))
            {
                if (result < 0)
                {
                    yield return new ValidationResult(
                        "Different Service Date must be greater then Detention Date",
                        new[] { "Different Service Date" });
                }
            }

            if (!string.IsNullOrEmpty(DiffServDate) && !string.IsNullOrEmpty(DetainDate))
            {
                date1.AddDays(30);
                result = DateFunctions.CompareDates(date1, date2);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Different Service Date must not be greater then 30 days beyond the Detention Date",
                        new[] { "Different Service Date" });
                }
            }

            if (!string.IsNullOrEmpty(DiffServDate))
            {
                if (UpdateCopies.Substring(0,1) != "9")
                {
                    yield return new ValidationResult(
                        "If different service date is present then Update/Copies must be 9",
                        new[] { "Update Copies" });
                }
            }

            if (!string.IsNullOrEmpty(CreditDays) && !string.IsNullOrEmpty(EndStay))
            {
                if(EndStay.Substring(0,1) != "4'" && EndStay.Substring(0,1) != "5")
                {
                    yield return new ValidationResult(
                      "End Stay must be 4 or 5 when Credits Days are present",
                      new[] { "End Stay" });
                }
            }
            if (!string.IsNullOrEmpty(CoFo) && !string.IsNullOrEmpty(EndStay))
            {
                yield return new ValidationResult(
                      "CO/FO not valid with End Stay",
                      new[] { "Co/Fo" });
            }
            if (string.IsNullOrEmpty(CoFo) && !string.IsNullOrEmpty(CorrArrestDate))
            {
                yield return new ValidationResult(
                      "CO/FO must have a value when COrrect Detain date is used",
                      new[] { "Co/Fo" });
            }

            if (CheckReimpose() && !string.IsNullOrEmpty(CorrArrestDate) && !string.IsNullOrEmpty(EndStay))
            {
                yield return new ValidationResult(
                      "When reimposing and Correct Detain Date has a date, end stay should not have a value",
                      new[] { "Reimpose" });
            }
            if (string.IsNullOrEmpty(CourtCode))
            {
                yield return new ValidationResult(
                      "Court code must be entered",
                      new[] { "Court Code" });
            }

            if (!string.IsNullOrEmpty(CorrArrestDate))
            {
                DateFunctions.ConvertStringToDate(CorrArrestDate, "MMddyy", out date1);
                result = DateFunctions.CompareDates(date1, DateTime.Now);
                if (result > 0)
                {
                    yield return new ValidationResult(
                    "Correct Arrest Date cannot be greater then current date",
                    new[] { "Detain Date" });
                }
            }
            if (!string.IsNullOrEmpty(DetainDate))
            {
                if (!string.IsNullOrEmpty(TestDate))
                {

                    DateFunctions.ConvertStringToDate(DetainDate, "MMddyy", out date1);
                    result = DateFunctions.CompareDates(date1,DateTime.Now);
                    if (result > 0)
                    {
                        yield return new ValidationResult(
                        "Detain Date connect be in the future",
                        new[] { "Detain Date" });
                    }
                }
                else
                {

                }
            }
            if (!String.IsNullOrEmpty(EndStay))
            {
                if (EndStay.Length > 2)
                {
                    yield return new ValidationResult(
                   "End Stay cannot be greater than length of 2",
                    new[] { "EndStay" });
                }
            }
            if (!String.IsNullOrEmpty(OrigAuthSect))
            {
                if (OrigAuthSect.Length > 7)
                {
                    yield return new ValidationResult(
                   "OrigAuthSect cannot be greater than length of 7",
                    new[] { "OrigAuthSect" });
                }
            }
        

        }
        private bool CheckBloodContent(string type, string testtype)
        {

          
            if (testtype == "BR")
            {
                if (!string.IsNullOrEmpty(VOPBAC1) && !string.IsNullOrEmpty(VOPBAC2))
                {
                    return true;
                }
            }
            else if (testtype == "PA")
            {
                if (!string.IsNullOrEmpty(VOPBAC1))
                {
                    return true;
                }
            }
            else
                return true;
           

            switch (type)
            {
               
                case "VOP":
                    if (testtype == "BR")
                    {
                        ErrorMessage = "When VOP Type of Test is BR, must have two BAC results.";
                    }
                    if (testtype == "PA")
                    {
                        ErrorMessage = "When BAC .01% is checked, the first VOP BAC must have a value.";
                    }
                    break;
            }

            return false;
        }
      
        private bool CheckReimpose()
        {
           
            if (!string.IsNullOrEmpty(EffectiveDate) && !string.IsNullOrEmpty(MailDate) &
                !string.IsNullOrEmpty(OrigEffectiveDate) && !string.IsNullOrEmpty(OrigAuthSect))
                return true;

            return false;
        }
    }
}
