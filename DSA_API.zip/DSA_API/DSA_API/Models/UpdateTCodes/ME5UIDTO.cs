﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME5UIDTO 
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }

        public string Status { get; set; }
        public string StatusMessage { get; set; }
        [Required]
        [Display(Name = "Med Cert Issue Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertIssueDate { get; set; }
        [Required]
        [Display(Name = "Med Cert Expire Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertExpireDate { get; set; }
        [Required]
        [StringLength(14)]
        [Display(Name = "Examiner License #")]
        public string ExaminerLicense { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "State of Issue")]
        public string ExaminerState { get; set; }
        public string ME5Response { get; set; }
        public string NextTran { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
