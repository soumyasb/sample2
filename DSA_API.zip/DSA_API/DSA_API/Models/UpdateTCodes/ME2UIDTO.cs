﻿using DSA_API.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME2UIDTO : IValidatableObject
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]
        [Display(Name = "Med Cert Issue Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertIssueDate { get; set; }
        [Required]
        [Display(Name = "Med Cert Expire Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertExpireDate { get; set; }
        [Required]
        [Display(Name = "Med Cert Received Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertReceivedDate { get; set; }
        [StringLength(1)]
        public string Restr1 { get; set; }
        [StringLength(1)]
        public string Restr2 { get; set; }
        [StringLength(1)]
        public string Restr3 { get; set; }
        [StringLength(1)]
        public string Restr4 { get; set; }
        [StringLength(1)]
        public string Restr5 { get; set; }
        [StringLength(1)]
        public string Restr6 { get; set; }
        [StringLength(1)]
        public string Restr7 { get; set; }
        [StringLength(1)]
        public string Restr8 { get; set; }
        [StringLength(1)]
        public string Restr9 { get; set; }
        [StringLength(1)]
        public string Restr10 { get; set; }
        [Required]
        [StringLength(10)]
        [Display(Name = "Examiner Phone #")]
        public string ExaminerPhoneNumber { get; set; }
        [Required]
        [StringLength(40)]
        [Display(Name = "Examiner Last Name")]
        public string ExaminerLastName { get; set; }
        [Required]
        [StringLength(40)]
        [Display(Name = "Examiner First Name")]
        public string ExaminerFirstName { get; set; }
        [StringLength(35)]
        [Display(Name = "Examiner Middle Name")]
        public string ExaminerMiddleName { get; set; }
        [StringLength(5)]
        [Display(Name = "Examiner Suffix")]
        public string ExaminerSuffix { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "Examiner Title")]
        public string ExaminerTitle { get; set; }
        [Required]
        [StringLength(14)]
        [Display(Name = "Examiner License #")]
        public string ExaminerLicense { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "State of Issue")]
        public string ExaminerState { get; set; }
        [StringLength(15)]
        [Display(Name = "National Registry #")]
        public string NationalRegistry { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "Self-Cert Code")]
        public string SelfCertCode { get; set; }
        [StringLength(1)]
        [Display(Name = "PURGE THIS RECORD")]
        public string PurgeFlag { get; set; }
        [Display(Name = "Valid")]
        public bool Valid { get; set; }
        [Display(Name = "InValid")]
        public bool InValid { get; set; }
        public string ME2Response { get; set; }
        public string ME5Response { get; set; }
        public string ME6Response { get; set; }
        public string NextTran { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
      
       
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            int result;
            DateTime tempDate;
            if (DLNumber.Length < 8)
            {
                yield return new ValidationResult(
                    $"Please enter a valid DL Number",
                    new[] { "DLNumber" });
            }

            if (ThreeCharacterLastName.Length < 3)
            {
                yield return new ValidationResult(
                    $"The name is not in the correct format",
                    new[] { "ThreeCharacterLastName" });
            }
            tempDate = MedCertExpireDate.AddYears(-2);
            result = DateFunctions.CompareDates(MedCertIssueDate, tempDate);
            if (result < 0)
            {
                yield return new ValidationResult(
                    "Med Cert Expire date is more than 2 years from the Med Cert Issue date",
                    new[] { "Med Cert Expire date" });
            }
           
            result = DateFunctions.CompareDates(MedCertExpireDate, MedCertIssueDate);
            if (result < 0)
            {
                yield return new ValidationResult(
                    "Med Cert Expiration Date cannot be less than Med Cert Issue Date",
                    new[] { "Med Cert Expire date" });
            }

            result = DateFunctions.CompareDates(MedCertIssueDate, DateTime.Now);
            if (result > 0)
            {
                yield return new ValidationResult(
                    "Med Cert Issue Date cannot be greater than today",
                    new[] { "Med Cert Issue Date" });
            }
            result = DateFunctions.CompareDates(MedCertReceivedDate, MedCertIssueDate);
            if (result < 0)
            {
                yield return new ValidationResult(
                    "Med Cert Received Date cannot be less than Med Cert Issue Date",
                    new[] { "Med Cert Received Date" });
            }
            result = DateFunctions.CompareDates(MedCertReceivedDate, DateTime.Now);
            if (result > 0)
            {
                yield return new ValidationResult(
                    "Med Cert Received Date cannot be greater than today",
                    new[] { "Med Cert Received Date" });
            }
            result = DateFunctions.CompareDates(MedCertExpireDate, DateTime.Now);
            if (result < 0 && NextTran == "ME3")
            {
                yield return new ValidationResult(
                    "Cannot transfer to ME3, Med Cert is expired",
                    new[] { "Med Cert Expired Date" });
            }
            if (Valid == false && InValid == false )
            {
                yield return new ValidationResult(
                    "Either Valid and Invalid must be checked",
                    new[] { "Valid/Invalid" });
            }
            if (Valid == true && InValid == true)
            {
                yield return new ValidationResult(
                    "Both Valid and Invalid cannot be checked",
                    new[] { "Valid/Invalid" });
            }
        }
    }
}
