﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUKInitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string DSUserFieldOffice { get; set; }
        public IEnumerable<SelectListItem> Process1 { get; set; }
        public IEnumerable<SelectListItem> Code1 { get; set; }
        public IEnumerable<SelectListItem> Process2 { get; set; }
        public IEnumerable<SelectListItem> Code2 { get; set; }
        public IEnumerable<SelectListItem> Process3 { get; set; }
        public IEnumerable<SelectListItem> Code3 { get; set; }
        public IEnumerable<SelectListItem> PurgeCode { get; set; }
        public IEnumerable<SelectListItem> Condition { get; set; }
        public IEnumerable<SelectListItem> Reason { get; set; }
        public IEnumerable<SelectListItem> Info { get; set; }
      
    }
}
