﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DARUIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]
        [StringLength(1)]
        public string TypeInput { get; set; }
        [Required]
        [StringLength(25)]
        public string LawEnforcementAgency { get; set; }
        [Required]
        [StringLength(5)]
        public string CourtCode { get; set; }
        [StringLength(2)]
        public string BAC1 { get; set; }
        [StringLength(2)]
        public string BAC2 { get; set; }
        [StringLength(13)]
        public string LawEnforcementCaseNo { get; set; }
        public string APSArrestDate { get; set; }
        public string PASDetainDate { get; set; }
        public string ProbDetainDate { get; set; }
        [Required]
        [StringLength(2)]
        public string TestType { get; set; }
        public string OrigArrestDetainDate { get; set; }
        [StringLength(3)]
        public string DSFieldOffice { get; set; }
        public string DARResponse { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
