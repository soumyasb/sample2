﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUNUIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }
        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]
        public string ProcessType { get; set; }
      
        public string DUNResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
