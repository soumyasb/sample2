﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME6UIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [StringLength(1)]
        [Display(Name = "PURGE THIS RECORD")]
        public string PurgeFlag { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "Self-Cert Code")]
        public string SelfCertCode { get; set; }
        [Required]
        [Display(Name = "Med Cert Receipt Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertReceiptDate { get; set; }
        public string ME6Response { get; set; }
        public string NextTran { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
