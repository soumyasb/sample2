﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUFInitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string DSUserFieldOffice { get; set; }
        public IEnumerable<SelectListItem> Stay { get; set; }
        public IEnumerable<SelectListItem> FirstAuthoritySection { get; set; }
        public IEnumerable<SelectListItem> SecondAuthoritySection { get; set; }
        public IEnumerable<SelectListItem> ThirdAuthoritySection { get; set; }
        public IEnumerable<SelectListItem> UpdateCopies { get; set; }
        public IEnumerable<SelectListItem> OSCode { get; set; }
        public IEnumerable<SelectListItem> CommStatusIndicator { get; set; }
        public IEnumerable<SelectListItem> HearingType { get; set; }
        public IEnumerable<SelectListItem> DSFieldOffices { get; set; }
        public IEnumerable<SelectListItem> HearingResults { get; set; }
        public IEnumerable<SelectListItem> CoFo { get; set; }
        public IEnumerable<SelectListItem> ParaIns { get; set; }






    }
}
