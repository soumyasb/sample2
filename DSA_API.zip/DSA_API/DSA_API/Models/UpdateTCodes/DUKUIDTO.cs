﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUKUIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }
        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        public string Process1 { get; set; }
        public string Code1 { get; set; }
        public string Info1 { get; set; }
        public string Process2 { get; set; }
        public string Code2 { get; set; }
        public string Info2 { get; set; }
        public string Process3 { get; set; }
        public string Code3 { get; set; }
        public string Info3 { get; set; }
        [StringLength(2)]
        public string CommentNumber { get; set; }
        public string CommentPurgeDate { get; set; }
        [StringLength(85)]
        public string Comment { get; set; }
       
        public string PullNoticePurgeDate { get; set; }
      
        public string PurgeCode { get; set; }
       
        public string Condition { get; set; }
    
        public string Reason { get; set; }
      
        public string Info { get; set; }
        [StringLength(5)]
  
        public string Destination { get; set; }
        [StringLength(69)]
        public string MiscInfo { get; set; }
        public string DUKResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
