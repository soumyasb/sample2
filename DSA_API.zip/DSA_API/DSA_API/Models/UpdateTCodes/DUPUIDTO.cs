﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUPUIDTO : IValidatableObject
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]

        public string BirthDate { get; set; }

        [Required]
        public string TypeAction { get; set; }
      
        public string Reason { get; set; }
        public string AuthoritySection1 { get; set; }
        public string AuthoritySection2 { get; set; }

        public string OriginalHearingDate { get; set; }
        public string EffectiveDate { get; set; }
        public string ActionTermDate { get; set; }
        public string MailDate { get; set; }
        [StringLength(4)]
        public string RouteCode { get; set; }
        public string PMOptions { get; set; }
        public string PMCode { get; set; }
        public string RestrictionsOptions { get; set; }
        public string Restriction1 { get; set; }
        public string Restriction2 { get; set; }
        public string Restriction3 { get; set; }
        public string LicenseLocation { get; set; }
        [StringLength(2)]
        public string CountyCode { get; set; }
        public string OrigAuthoritySection { get; set; }
        public string OrigEffectiveDate { get; set; }
      
        public string CoFo { get; set; }
      
        public string DUPResponse { get; set; }
        public string DUKResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (RestrictionsOptions == "A" || RestrictionsOptions == "D")
            {
                if (String.IsNullOrEmpty(Restriction1) && String.IsNullOrEmpty(Restriction2) && String.IsNullOrEmpty(Restriction3))
                {
                    yield return new ValidationResult(
                  "Restrictions are missing when restriction options are A or D",
                   new[] { "Restrictions" });
                }
            }
        }
    }
}
