﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUWUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBAHEARINGTYPE { get; set; }
        public string SBAHEARINGDATE { get; set; }
        public string SBAHEARINGLOCATION { get; set; }
        public string SBAHEARINGREASON { get; set; }
        public string SBASCHEDULERESULT { get; set; }
        public string SBATYPEACTION { get; set; }
        public string SBAMODIFIEDHEARINGDATE { get; set; }
        public string SBAMAILDATE { get; set; }
        public string SBAFIELDFILE { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
