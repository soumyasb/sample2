﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUZUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBABIRTHDATE { get; set; }
        public string SBAAUTHORITYSECTION { get; set; }
        public string SBAAUTHORITYSECTION2 { get; set; }
        public string SBATYPEACTION { get; set; }
        public string SBAREASON { get; set; }
        public string SBAMAILDATE { get; set; }
        public string SBAEFFECTIVEDATE { get; set; }
        public string SBATHROUGHDATE { get; set; }
        public string SBACOFO { get; set; }
        public string SBAORIGAUTHORITYSECTION { get; set; }
        public string SBAORIGEFFECTIVEDATE { get; set; }
        public string SBAORIGHEARINGDATE { get; set; }
        public string SBAORIGHEARINGRESULTS { get; set; }
        public string SBAMODIFIEDHEARINGDATE { get; set; }
        public string SBAHEARINGTYPE { get; set; }
        public string SBAHEARINGLOCATION { get; set; }
        public string SBAPMCODE { get; set; }
        public string SBARESTRICTION { get; set; }
        public string SBAROUTECODE { get; set; }
        public string SBAUPDATECOPIES { get; set; }
        public string SBAFIELDFILE { get; set; }
        public string SBALICLOC { get; set; }
        public string SBAMEDICALSUSPENSE { get; set; }
        public string SBACOUNTYCODE { get; set; }
        public string SBACOMMSTATUSIND { get; set; }
        public string SBAOSCODE { get; set; }
        public string SBAOSDLNUMBER { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
