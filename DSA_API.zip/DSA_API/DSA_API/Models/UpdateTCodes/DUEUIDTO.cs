﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUEUIDTO 
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]

        public string BirthDate { get; set; }

        [Required]
        public string AuthSect1 { get; set; }
     
        public string AuthSect2 { get; set; }
        [Required]
        public string Reason { get; set; }
     
        public string EffectiveDate { get; set; }
        [Required]
        public string MailDate { get; set; }
      
        public string CoFo { get; set; }
        public string OrigAuthSect { get; set; }
        public string OrigEffectiveDate { get; set; }
     
        public string UpdateCopies { get; set; }
        public string ViolationDate { get; set; }
        public string FieldFile { get; set; }
        [StringLength(2)]
        public string CountyCode { get; set; }
        [StringLength(25)]
        public string OutOfStateDLNo { get; set; }
        public string OutOfStateCd { get; set; }
        public string CommercialStatusIndicator { get; set; }
        public string HearingType { get; set; }
        public string HearingDate { get; set; }
        [StringLength(3)]
        public string DSFieldOffice { get; set; }

        public string HearingResult { get; set; }
        public string ModifiedHearingDate { get; set; }

        public string DUEResponse { get; set; }
   
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }

      
    }
}
