﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUKUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBAACD1 { get; set; }
        public string SBACODE1 { get; set; }
        public string SBADATA1 { get; set; }
        public string SBAACD2 { get; set; }
        public string SBACODE2 { get; set; }
        public string SBADATA2 { get; set; }
        public string SBAACD3 { get; set; }
        public string SBACODE3 { get; set; }
        public string SBADATA3 { get; set; }
        public string SBAPROCCODE { get; set; }
        public string SBACODE4 { get; set; }
        public string SBACOMMNUMBER { get; set; }
        public string SBAPURGEDATE1 { get; set; }
        public string SBACOMMENT { get; set; }
        public string SBACODE5 { get; set; }
        public string SBACODE6 { get; set; }
        public string SBAPURGEDATE2 { get; set; }
        public string SBAPURGECODE { get; set; }
        public string SBACONDITION { get; set; }
        public string SBAREASON { get; set; }
        public string SBAINFOCODE { get; set; }
        public string SBADESTINATION { get; set; }
        public string SBADACASENUMBER { get; set; }
        public string SBAMISCINFO { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
