﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DARUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBATYPEINPUT { get; set; }
        public string SBATESTTYPE { get; set; }
        public string SBARRESTAGENCY { get; set; }
        public string SBAFIELDOFFICE { get; set; }
        public string SBAAPSARRESTDATE { get; set; }
        public string SBAPASDETDATE { get; set; }
        public string SBASBAPROBDETDATE { get; set; }
        public string SBABAC1 { get; set; }
        public string SBABAC2 { get; set; }
        public string SBALECASENUMBER { get; set; }
        public string SBACOURTCODE { get; set; }
        public string SBAMATCHDATE { get; set; }
        public string SBACLOSURECODE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
