﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUJUpdateDTO
    {
       
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBATYPEINPUT { get; set; }
        public string SBADUEDATE { get; set; }
        public string SBAREASON { get; set; }
        public string SBADESTINATION { get; set; }
        public string SBACHANGETODATE { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
