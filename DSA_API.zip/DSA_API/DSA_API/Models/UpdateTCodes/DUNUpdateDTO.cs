﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUNUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBADELETE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
