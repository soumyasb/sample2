﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DAPUpdateDTO
    {

        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBABIRTHDATE { get; set; }
        public string SBAARRCD { get; set; }
        public string SBAARRDT { get; set; }
        public string SBATYPTST { get; set; }
        public string SBAUPDCPY { get; set; }
        public string SBAEFFDATE { get; set; }
        public string SBAMAILDATE { get; set; }
        public string SBAENDSTAY { get; set; }
        public string SBAAUTHSECT { get; set; }
        public string SBAORIGEFFDATE { get; set; }
        public string SBAHEARDATE { get; set; }
        public string SBAHEARRESULT { get; set; }
        public string SBAHEARMODDATE { get; set; }
        public string SBAHRNGTYPE { get; set; }
        public string SBACORRECTARRDETDATE { get; set; }
        public string SBACOFO { get; set; }
        public string SBADIFFSERVDATE { get; set; }
        public string SBACOMMSTATUSIND { get; set; }
        public string SBALICLOC1 { get; set; }
        public string SBALICLOC2 { get; set; }
        public string SBACREDITDAYS1 { get; set; }
        public string SBACREDITDAYS2 { get; set; }
        public string SBAOSCODE { get; set; }
        public string SBAOSDLNUMBER { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
