﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME4InitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Birthdate { get; set; }
        public string Status { get; set; }
        public string StatusMessage { get; set; }
        public string MedCertIssueDate { get; set; }

        public string MedCertExpireDate { get; set; }
        public string MedCertReceiptDate { get; set; }

        public string ExaminerLicense { get; set; }
     
        public string ExaminerState { get; set; }
       
        public string Restr1 { get; set; }
     
        public string Restr2 { get; set; }
     
        public string Restr3 { get; set; }
   
        public string Restr4 { get; set; }
      
        public string Restr5 { get; set; }
     
        public string Restr6 { get; set; }
        
        public string Restr7 { get; set; }
       
        public string Restr8 { get; set; }
       
        public string Restr9 { get; set; }
      
        public string Restr10 { get; set; }
        public IEnumerable<SelectListItem> RestrictionCodes { get; set; }
        public IEnumerable<SelectListItem> WaiverTypeSelect { get; set; }
        public string  WaiverType { get; set; }
        public string WaiverEffectiveDate { get; set; }
    
       
        public string WaiverExpirationDate { get; set; }
      
    
        public string WaiverRescindDate { get; set; }
       
        public string SPEEffectiveDate { get; set; }
   
        public string SPEExpirationDate { get; set; }
  
        public string SPECancelDate { get; set; }
        public string ExaminerLastName { get; set; }
      
        public string ExaminerFirstName { get; set; }
   
        public string ExaminerMiddleName { get; set; }

        public IEnumerable<SelectListItem> ExaminerSuffixSelect { get; set; }

        public IEnumerable<SelectListItem> ExaminerTitleSelect { get; set; }
        public string ExaminerSuffix { get; set; }
        public string ExaminerTitle { get; set; }

        public string ExaminerPhoneNumber { get; set; }
        public string NationalRegistry { get; set; }
        public string  Message { get; set; }

    }
}
