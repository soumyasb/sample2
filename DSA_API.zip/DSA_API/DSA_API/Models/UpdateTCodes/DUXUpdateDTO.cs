﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUXUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBAAUTHORITYSECTION { get; set; }
        public string SBAEFFECTIVEDATE { get; set; }
        public string SBAORIGAUTHORITYSECTION { get; set; }
        public string SBAORIGEFFECTIVEDATE { get; set; }
        public string SBAINSERTPARAGRAPH1 { get; set; }
        public string SBAINSERTPARAGRAPH2 { get; set; }
        public string SBAINSERTPARAGRAPH3 { get; set; }
        public string SBAPROOFCODE { get; set; }
        public string SBAUPDATECOPIES { get; set; }
        public string SBACOFO { get; set; }
        public string SBAROUTECODE { get; set; }
        public string SBARESTRICTION { get; set; }
        public string SBAPMCODE { get; set; }
        public string SBAHEARINGDATE { get; set; }
        public string SBAACTIONTERMDATE { get; set; }
        public string SBALICLOC { get; set; }
        public string SBAREMAILDATE { get; set; }
        public string SBACOUNTYCODE { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
