﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUXUIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }
        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
      
        public string HearingType { get; set; }
   
        public string HearingDate { get; set; }
      
        public string HearingLocation { get; set; }
      
        public string HearingReason { get; set; }
      
        public string HearingResult { get; set; }
        public string ModifiedHearingDate { get; set; }
    
        public string AuthoritySection { get; set; }
        public string EffectiveDate { get; set; }
        public string UpdateCopies { get; set; }
        public string OrigAuthoritySection { get; set; }
        public string OrigEffectiveDate { get; set; }
     
        public string CoFo { get; set; }
        public string PMOptions { get; set; }
        public string PMCode { get; set; }
        public string RestrictionsOptions { get; set; }
        public string Restriction1 { get; set; }
        public string Restriction2 { get; set; }
        public string Restriction3 { get; set; }
        public string InsertParagraph { get; set; }
        [StringLength(4)]
        public string RouteCode { get; set; }
        public string CountyCode { get; set; }
        public string DUXResponse { get; set; }
        public string DUWResponse { get; set; }
        public string DUKResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
