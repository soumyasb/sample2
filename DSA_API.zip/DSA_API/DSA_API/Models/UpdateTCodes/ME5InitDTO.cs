﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME5InitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Status { get; set; }
        public string StatusMessage { get; set; }

        public string MedCertIssueDate { get; set; }

        public string MedCertExpireDate { get; set; }

        public string ExaminerLicense { get; set; }

        public string ExaminerState { get; set; }
        public string Message { get; set; }
    }
}
