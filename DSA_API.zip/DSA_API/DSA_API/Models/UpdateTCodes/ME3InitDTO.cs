﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME3InitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Status { get; set; }
        public string StatusMessage { get; set; }
        public string MedCertIssueDate { get; set; }
       
        public string MedCertExpireDate { get; set; }
        
        public string ExaminerLicense { get; set; }
      
        public string ExaminerState { get; set; }
        public string WaiverType { get; set; }
        public string WaiverEffectiveDate { get; set; }
       
        public string WaiverExpirationDate { get; set; }
       
        public string WaiverRescindDate { get; set; }
       
        public string SPEEffectiveDate { get; set; }
       
        public string SPEExpirationDate { get; set; }
        
        public string SPECancelDate { get; set; }
        public IEnumerable<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> WaiverTypeSelect { get; set; }
        public string Message { get; set; }
    }
}
