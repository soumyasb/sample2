﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUHUIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
       
        public string ServiceDate { get; set; }
        public string ServiceCode { get; set; }
       
        public string OriginalEffectiveDate { get; set; }
        public string LicenseLocation { get; set; }
        public string TypeInput { get; set; }
        public string ViolationDate { get; set; }
        public string TestDate { get; set; }
        public string DUHResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
