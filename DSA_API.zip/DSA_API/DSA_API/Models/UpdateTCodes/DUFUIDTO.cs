﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUFUIDTO 
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]

        public string FRNumber { get; set; }

        [Required]
        public string Stay { get; set; }

        public string AuthoritySection1 { get; set; }
        public string AuthoritySection2 { get; set; }
        public string AuthoritySection3 { get; set; }

        public string NewEffectiveDate { get; set; }
        public string OriginalEffectiveDate { get; set; }

        public string OriginalHearingDate { get; set; }
        public string UpdateCopies { get; set; }
        [StringLength(25)]
        public string OutOfStateDLNo { get; set; }
        public string OutOfStateCd { get; set; }
        public string CommercialStatusIndicator { get; set; }

        public string HearingType { get; set; }
        public string HearingDate { get; set; }
        public string HearingLocation { get; set; }
        public string HearingResult { get; set; }

        public string ModDate { get; set; }
        public string MailDate { get; set; }
        public string CoFo { get; set; }
        public bool ProofBypass { get; set; }
        public string AccidentDate { get; set; }
        [StringLength(13)]
        public string AccidentLocation { get; set; }
        [StringLength(4)]
        public string RouteCode { get; set; }
       

        public string InsertParagraph { get; set; }

        public string DUFResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }

       
    }
}
