﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME2InitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Birthdate { get; set; }
        public IEnumerable<SelectListItem> RestrictionCodes { get; set; }
        public IEnumerable<SelectListItem> ExaminerSuffix { get; set; }
        public IEnumerable<SelectListItem> ExaminerTitle { get; set; }
        public bool CheckCA { get; set; }
        public IEnumerable<SelectListItem> States { get; set; }
        public IEnumerable<SelectListItem> SelfCertCode { get; set; }
    }
}
