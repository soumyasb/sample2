﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DAMUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBABIRTHDATE { get; set; }
        public string SBADETCD { get; set; }
        public string SBADETDT { get; set; }
        public string SBAUPDCPY { get; set; }
        public string SBACOFO { get; set; }
        public string SBAEFFDATE { get; set; }
        public string SBAMAILDATE { get; set; }
        public string SBAAUTHSECT { get; set; }
        public string SBASUSPTHRUDATE { get; set; }
        public string SBAORIGAUTHSECTION { get; set; }
        public string SBAORIGEFFDATE { get; set; }
        public string SBAHEARDATE { get; set; }
        public string SBAHEARRESULT { get; set; }
        public string SBAHEARMODDATE { get; set; }
        public string SBAHRNGTYPE { get; set; }
        public string SBACORRECTARRDETDATE { get; set; }
        public string SBADIFFSERVDATE { get; set; }
        public string SBALICLOC { get; set; }
        public string SBAENDSTAY { get; set; }
        public string SBACREDITDAYS { get; set; }
        public string SBACOMMSTATUSIND { get; set; }
        public string SBAOSCODE { get; set; }
        public string SBAOSDLNUMBER { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }

    }
}
