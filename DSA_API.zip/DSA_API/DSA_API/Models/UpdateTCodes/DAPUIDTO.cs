﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DAPUIDTO : IValidatableObject
    {

        public string LoginId { get; set; }
        public string NetName { get; set; }
    
        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]
       
        public string BirthDate { get; set; }
        [Required]
        [StringLength(1)]
        public string APSType { get; set; }
        [Required]
        
        public string ArrestDate { get; set; }
        [Required]
        [StringLength(2)]
        public string APSTestType { get; set; }
        [StringLength(1)]
        public string UpdateCopies { get; set; }
        [Required]
        [StringLength(1)]
        public string VOPType { get; set; }
   
        [StringLength(2)]
        public string VOPTestType { get; set; }
        [StringLength(25)]
        public string LawEnforcementAgency { get; set; }
        [Required]
        [StringLength(5)]
        public string CourtCode { get; set; }
        [StringLength(2)]
        public string BAC1 { get; set; }
        [StringLength(2)]
        public string BAC2 { get; set; }
        [StringLength(13)]
        public string LawEnforcementCaseNo { get; set; }
        [Required]
        [StringLength(3)]
        public string DSFieldOffice { get; set; }
       
        [StringLength(2)]
        public string VOPBAC1 { get; set; }
   
        [StringLength(2)]
        public string VOPBAC2 { get; set; }
        [StringLength(25)]
        public string OutOfStateDLNo { get; set; }
        [StringLength(2)]
        public string OutOfStateCd { get; set; }
        [Required]
        [StringLength(1)]
        public string CommercialStatusIndicator { get; set; }
      
        public string EffectiveDate { get; set; }
        
        public string MailDate { get; set; }
       
        public string PASOrigAuthSect { get; set; }
    
        public string OrigEffectiveDate { get; set; }
      
        public string EndStay { get; set; }
   
        public string VOPOrigAuthSect { get; set; }
     
        public string HearingDate { get; set; }
        [StringLength(1)]
        public string HearingResult { get; set; }
        [StringLength(1)]
        public string HearingType { get; set; }
       
        public string ModifiedHearingDate { get; set; }
     
        public string CorrArrestDate { get; set; }
        [StringLength(1)]
        public string CoFo { get; set; }
       
        public string DiffServDate { get; set; }
        [StringLength(2)]
        public string LicenseLocation { get; set; }
        [StringLength(3)]
        public string CreditDays { get; set; }
        public string DAPResponse { get; set; }
        public string DARResponse { get; set; }
        public string DASResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string  ErrorMessage { get; set; }
        public bool Error { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (DLNumber.Length < 8)
            {
                yield return new ValidationResult(
                    $"Please enter a valid DL Number",
                    new[] { "DLNumber" });
            }

            if (ThreeCharacterLastName.Length < 3)
            {
                yield return new ValidationResult(
                    $"The name is not in the correct format",
                    new[] { "ThreeCharacterLastName" });
            }

            if ((VOPType == "R" || VOPType == "A") && (APSTestType == "" || APSTestType == null ))
            { 
                yield return new ValidationResult(
                    $"APS Type is required when VOP Type-BAC .01% or VOP Refusal selected.  Otherwise, use DAS screen for update.",
                    new[] { "ASPType" });
            }
         

            if (VOPType == "R" && APSType != "R")
            {
                yield return new ValidationResult(
                    $"VOP Type-Refusal not allowed with APS Type-BAC.",
                    new[] { "VOPType" });
            }
            if (CourtCode.Length < 5)
            {
                yield return new ValidationResult(
                    $"Court Code must be 5 digits long.",
                    new[] { "CourtCode" });
            }
            if (VOPType == "A" && String.IsNullOrEmpty(VOPTestType))
            {
                yield return new ValidationResult(
                    $"When VOP type is BAC .01% is checked, VOP Type Test must be entered.",
                    new[] { "VOPTestType" });
            }
            if (APSType == "A" && !CheckBloodContent("APS", APSTestType) && !CheckStay())
            {
                yield return new ValidationResult(
                    ErrorMessage,
                    new[] { "APSTestType" });
            }
            if (VOPType == "A" && !CheckBloodContent("VOP", VOPTestType) && !CheckStay())
            {
                yield return new ValidationResult(
                   ErrorMessage,
                    new[] { "VOPTestType" });
            }
            if (!String.IsNullOrEmpty(EndStay))
            {
                if(EndStay.Length > 2)
                {
                    yield return new ValidationResult(
                   "End Stay cannot be greater than length of 2",
                    new[] { "EndStay" });
                }
            }
            if (!String.IsNullOrEmpty(PASOrigAuthSect))
            {
                if (PASOrigAuthSect.Length > 7)
                {
                    yield return new ValidationResult(
                   "PASOrigAuthSect cannot be greater than length of 7",
                    new[] { "PASOrigAuthSect" });
                }
            }
            if (!String.IsNullOrEmpty(VOPOrigAuthSect))
            {
                if (VOPOrigAuthSect.Length > 7)
                {
                    yield return new ValidationResult(
                   "VOPOrigAuthSect cannot be greater than length of 7",
                    new[] { "VOPOrigAuthSect" });
                }
            }
            if (!string.IsNullOrEmpty(LawEnforcementAgency))
            {
                LawEnforcementAgency = LawEnforcementAgency.ToUpper();
            }
            if (APSTestType == "RE")
            {
                APSTestType = "";
            }
            if (VOPTestType == "RE")
            {
                VOPTestType = "";
            }

        }
        private bool CheckBloodContent(string type, string testtype)
        {
            
            if (type == "APS")
            {
                if (testtype == "BR")
                {
                    if (!string.IsNullOrEmpty(BAC1) && !string.IsNullOrEmpty(BAC2))
                    {
                        return true;
                    }
                }
                else if (testtype == "PA")
                {
                    if (!string.IsNullOrEmpty(BAC1))
                    {
                        return true;
                    }
                }
                else
                    return true;
            }
            else
            {
                if (testtype == "BR")
                {
                    if (!string.IsNullOrEmpty(VOPBAC1) && !string.IsNullOrEmpty(VOPBAC2))
                    {
                        return true;
                    }
                }
                else if (testtype == "PA")
                {
                    if (!string.IsNullOrEmpty(VOPBAC1))
                    {
                        return true;
                    }
                }
                else
                    return true;
            }
          
            switch(type)
            {
                case "APS":
                    if(testtype == "BR")
                    {
                        ErrorMessage = "When APS Type of Test is BR, must have two BAC results.";
                    }
                    if (testtype == "PA")
                    {
                        ErrorMessage = "When APS Type is checked, the first BAC must have a value.";
                    }
                    break;
                case "VOP":
                    if (testtype == "BR")
                    {
                        ErrorMessage = "When VOP Type of Test is BR, must have two BAC results.";
                    }
                    if (testtype == "PA")
                    {
                        ErrorMessage = "When BAC .01% is checked, the first VOP BAC must have a value.";
                    }
                    break;
            }

            return false;
        }

        private bool CheckStay()
        {
        
            if (!string.IsNullOrEmpty(EffectiveDate) || !string.IsNullOrEmpty(MailDate) ||
                !string.IsNullOrEmpty(EndStay) || !string.IsNullOrEmpty(PASOrigAuthSect) || !string.IsNullOrEmpty(VOPOrigAuthSect))
                return true;

            return false;
        }
    }
}
