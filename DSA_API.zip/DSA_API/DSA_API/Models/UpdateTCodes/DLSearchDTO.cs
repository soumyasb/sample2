﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DLSearchDTO
    {
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Birthdate { get; set; }
    }
}
