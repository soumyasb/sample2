﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUVInitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Location { get; set; }
        public IEnumerable<SelectListItem> HearingType { get; set; }
        public IEnumerable<SelectListItem> HearingLocations { get; set; }
        public IEnumerable<SelectListItem> HearingReasons { get; set; }
        public IEnumerable<SelectListItem> OriginalHearingReason { get; set; }
       
    }
}
