﻿using DSA_API.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME4UIDTO : IValidatableObject
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [StringLength(1)]
        public string Status { get; set; }
        public string StatusMessage { get; set; }
        [Required]
        [Display(Name = "Med Cert Issue Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertIssueDate { get; set; }
        [Required]
        [Display(Name = "Med Cert Expire Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertExpireDate { get; set; }
        [Required]
        [StringLength(14)]
        [Display(Name = "Examiner License #")]
        public string ExaminerLicense { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "State of Issue")]
        public string ExaminerState { get; set; }
        [Required]
        [Display(Name = "Med Cert Received Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertReceiptDate { get; set; }
        [Display(Name = "Purge This Record")]
        public bool Purge { get; set; }
        [StringLength(1)]
        public string Restr1 { get; set; }
        [StringLength(1)]
        public string Restr2 { get; set; }
        [StringLength(1)]
        public string Restr3 { get; set; }
        [StringLength(1)]
        public string Restr4 { get; set; }
        [StringLength(1)]
        public string Restr5 { get; set; }
        [StringLength(1)]
        public string Restr6 { get; set; }
        [StringLength(1)]
        public string Restr7 { get; set; }
        [StringLength(1)]
        public string Restr8 { get; set; }
        [StringLength(1)]
        public string Restr9 { get; set; }
        [StringLength(1)]
        public string Restr10 { get; set; }
        [StringLength(1)]
        [Display(Name = "Type")]
        public string WaiverType { get; set; }

        [Display(Name = "Effective Date")]
        
        public string WaiverEffectiveDate { get; set; }
        [Display(Name = "Expiration Date")]
      
        public string WaiverExpirationDate { get; set; }
        [Display(Name = "Rescind Date")]
       
        public string WaiverRescindDate { get; set; }
        [Display(Name = "SPE Effective Date")]
      
        public string SPEEffectiveDate { get; set; }
        [Display(Name = "SPE Expiration Date")]
     
        public string SPEExpirationDate { get; set; }
        [Display(Name = "SPE Cancel Date")]
       
        public string SPECancelDate { get; set; }
        [Required]
        [StringLength(40)]
        [Display(Name = "Examiner Last Name")]
        public string ExaminerLastName { get; set; }
        [Required]
        [StringLength(40)]
        [Display(Name = "Examiner First Name")]
        public string ExaminerFirstName { get; set; }
        [StringLength(35)]
        [Display(Name = "Examiner Middle Name")]
        public string ExaminerMiddleName { get; set; }
        [StringLength(5)]
        [Display(Name = "Examiner Suffix")]
        public string ExaminerSuffix { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "Examiner Title")]
        public string ExaminerTitle { get; set; }
        [Required]
        [StringLength(10)]
        [Display(Name = "Examiner Phone #")]
        public string ExaminerPhoneNumber { get; set; }
        [StringLength(15)]
        [Display(Name = "National Registry #")]
        public string NationalRegistry { get; set; }
        public string ME4Response { get; set; }
        public string NextTran { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            int result;
            DateTime tempDate;
            string strDate;
            DateTime date1;
            DateTime date2;
            if (DLNumber.Length < 8)
            {
                yield return new ValidationResult(
                    $"Please enter a valid DL Number",
                    new[] { "DLNumber" });
            }

            if (ThreeCharacterLastName.Length < 3)
            {
                yield return new ValidationResult(
                    $"The name is not in the correct format",
                    new[] { "ThreeCharacterLastName" });
            }
            if (!string.IsNullOrEmpty(WaiverEffectiveDate.ToString()))
            {
                DateFunctions.ConvertStringToDate(WaiverEffectiveDate, "MMddyyyy", out date1);
                result = DateFunctions.CompareDates(date1, DateTime.Now);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Waiver Effective Date cannot be greater than today",
                        new[] { "Waiver Effective Date" });
                }
            }
            if (WaiverEffectiveDate != null && WaiverExpirationDate != null)
            {
                DateFunctions.ConvertStringToDate(WaiverEffectiveDate, "MMddyyyy", out date1);
                DateFunctions.ConvertStringToDate(WaiverExpirationDate, "MMddyyyy", out date2);
                result = DateFunctions.CompareDates(date1,date2);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Waiver Expiration Date cannot be before the Waiver Effective Date",
                        new[] { "Waiver Expiration Date" });
                }
            }

            if (SPEEffectiveDate != null)
            {
                DateFunctions.ConvertStringToDate(SPEEffectiveDate, "MMddyyyy", out date1);
                result = DateFunctions.CompareDates(date1, DateTime.Now);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Driver SPE Effective Date cannot be greater than today",
                        new[] { "SPE Effective Date" });
                }
            }
            if (SPEEffectiveDate != null && SPEExpirationDate != null)
            {
                DateFunctions.ConvertStringToDate(SPEEffectiveDate, "MMddyyyy", out date1);
                DateFunctions.ConvertStringToDate(SPEExpirationDate, "MMddyyyy", out date2);
                result = DateFunctions.CompareDates(date1, date2);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "SPE Expiration Date cannot be before the SPE Effective Date",
                        new[] { "SPE Expiration Date" });
                }
            }
            if (Status == "I")
            {
                yield return new ValidationResult(
                                       "Cannot update an invalid certificate",
                                       new[] { "Invalid Status" });
            }

            if (!string.IsNullOrEmpty(WaiverType) && WaiverEffectiveDate == null)
            {
                yield return new ValidationResult(
                    "Waiver Effective Date must be present",
                    new[] { "Waiver Effective Date" });
            }


        }
    }
}
