﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUJUIDTO
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
        [Required]
        public string TypeInput { get; set; }
        [Required]
        public string DueDate { get; set; }
        [Required]
        public string Reason { get; set; }
        [StringLength(4)]
        [Required]
        public string Destination { get; set; }
        public string ChangeToDate { get; set; }
        public string TestDate { get; set; }
        public string DUJResponse { get; set; }
        public string NextDLNumber { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }
    }
}
