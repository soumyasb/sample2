﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUVUpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBALASTNAME { get; set; }
        public string SBAHEARTYPE { get; set; }
        public string SBAHEARDT { get; set; }
        public string SBAHEARLOC { get; set; }
        public string SBAREASON { get; set; }
        public string SBAMATCHDATE { get; set; }
        public string SBANEWREASON { get; set; }
        public string SBATESTDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
       
    }
}
