﻿using DSA_API.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME3UIDTO : IValidatableObject
    {
        public string LoginId { get; set; }
        public string NetName { get; set; }

        [Required]
        public string RequestorCode { get; set; }
        [Required]
        public string Operator { get; set; }

        [Required]
        public string DLNumber { get; set; }
        [Required]
        [StringLength(3)]
        public string ThreeCharacterLastName { get; set; }
       
        public string Status { get; set; }
        public string StatusMessage  { get; set; }
        [Required]
        [Display(Name = "Med Cert Issue Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertIssueDate { get; set; }
        [Required]
        [Display(Name = "Med Cert Expire Date")]
        [DataType(DataType.Date)]
        public DateTime MedCertExpireDate { get; set; }
        [Required]
        [StringLength(14)]
        [Display(Name = "Examiner License #")]
        public string ExaminerLicense { get; set; }
        [Required]
        [StringLength(2)]
        [Display(Name = "State of Issue")]
        public string ExaminerState { get; set; }
        [StringLength(1)]
        [Display(Name = "Type")]
        public string WaiverType { get; set; }
   
        [Display(Name = "Effective Date")]
       
        public string WaiverEffectiveDate { get; set; }
        [Display(Name = "Expiration Date")]
      
        public string WaiverExpirationDate { get; set; }
        [Display(Name = "Rescind Date")]
        
        public string WaiverRescindDate { get; set; }
        [Display(Name = "SPE Effective Date")]
       
        public string SPEEffectiveDate { get; set; }
        [Display(Name = "SPE Expiration Date")]
       
        public string SPEExpirationDate { get; set; }
        [Display(Name = "SPE Cancel Date")]
       
        public string SPECancelDate { get; set; }
        public string ME3Response { get; set; }
        public string NextTran { get; set; }
        private string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            int result;
            DateTime tempDate;
            string strDate;
            DateTime date1;
            DateTime date2;
            if (DLNumber.Length < 8)
            {
                yield return new ValidationResult(
                    $"Please enter a valid DL Number",
                    new[] { "DLNumber" });
            }

            if (ThreeCharacterLastName.Length < 3)
            {
                yield return new ValidationResult(
                    $"The name is not in the correct format",
                    new[] { "ThreeCharacterLastName" });
            }

            if (!string.IsNullOrEmpty(WaiverEffectiveDate))
            {
                DateFunctions.ConvertStringToDate(WaiverEffectiveDate, "MMddyyyy", out date1);
                result = DateFunctions.CompareDates(date1, DateTime.Now);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Waiver Effective Date cannot be greater than today",
                        new[] { "Waiver Effective Date" });
                }
            }
            if (WaiverEffectiveDate != null && WaiverExpirationDate != null)
            {
                DateFunctions.ConvertStringToDate(WaiverEffectiveDate, "MMddyyyy", out date1);
                DateFunctions.ConvertStringToDate(WaiverExpirationDate, "MMddyyyy", out date2);
                result = DateFunctions.CompareDates(date1, date2);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Waiver Expiration Date cannot be before the Waiver Effective Date",
                        new[] { "Waiver Expiration Date" });
                }
            }
         
            if (SPEEffectiveDate != null)
            {
                DateFunctions.ConvertStringToDate(SPEEffectiveDate, "MMddyyyy", out date1);
                result = DateFunctions.CompareDates(date1, DateTime.Now);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "Driver SPE Effective Date cannot be greater than today",
                        new[] { "SPE Effective Date" });
                }
            }
            if (SPEEffectiveDate != null && SPEExpirationDate != null)
            {
                DateFunctions.ConvertStringToDate(SPEEffectiveDate, "MMddyyyy", out date1);
                DateFunctions.ConvertStringToDate(SPEExpirationDate, "MMddyyyy", out date2);
                result = DateFunctions.CompareDates(date1, date2);
                if (result > 0)
                {
                    yield return new ValidationResult(
                        "SPE Expiration Date cannot be before the SPE Effective Date",
                        new[] { "SPE Expiration Date" });
                }
            }
            if (Status == "I")
            {
                yield return new ValidationResult(
                                       "Cannot update an invalid certificate",
                                       new[] { "Invalid Status" });
            }
           
            if (!string.IsNullOrEmpty(WaiverType) && WaiverEffectiveDate == null)
            {
                yield return new ValidationResult(
                    "Waiver Effective Date must be present",
                    new[] { "Waiver Effective Date" });
            }
        }
    }
    
}
