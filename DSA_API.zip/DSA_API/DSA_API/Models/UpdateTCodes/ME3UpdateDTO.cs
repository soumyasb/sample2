﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class ME3UpdateDTO
    {
        public string SBAREQCODE { get; set; }
        public string SBASTATUS { get; set; }
        public string SBAOPERATOR { get; set; }
        public string SBADLNUMBER { get; set; }
        public string SBAISSUEDATE { get; set; }
        public string SBAEXPIREDATE { get; set; }
        public string SBALICENSESTATE { get; set; }
        public string SBALICENSENUMBER { get; set; }
        public string SBAWAIVERTYPE { get; set; }
        public string SBAWAIVEREFFECTIVEDATE { get; set; }
        public string SBAWAIVEREXPIRATIONDATE { get; set; }
        public string SBAWAIVERRESCINDDATE { get; set; }
        public string SBASPEEFFECTIVEDATE { get; set; }
        public string SBASPEEXPIRATIONDATE { get; set; }
        public string SBASPECANCELDATE { get; set; }
        public bool Error { get; set; }
        public string Title { get; set; }
        public string StatusMessage { get; set; }
    }
}
