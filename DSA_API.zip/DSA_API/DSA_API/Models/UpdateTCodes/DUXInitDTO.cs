﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.UpdateTCodes
{
    public class DUXInitDTO
    {
        public string RequestorCode { get; set; }
        public string Operator { get; set; }
        public string NetName { get; set; }
        public string LoginId { get; set; }
        public string DLNumber { get; set; }
        public string ThreeCharacterName { get; set; }
        public string Location { get; set; }
        public IEnumerable<SelectListItem> ChgHearingType { get; set; }
        public IEnumerable<SelectListItem> Locations { get; set; }
        public IEnumerable<SelectListItem> Reasons { get; set; }
        public IEnumerable<SelectListItem> HearingResults { get; set; }
        public IEnumerable<SelectListItem> AuthoritySection { get; set; }
        public IEnumerable<SelectListItem> UpdateCopies { get; set; }
        public IEnumerable<SelectListItem> OriginalAuthoritySection { get; set; }
       
        public IEnumerable<SelectListItem> CoFo { get; set; }
        public IEnumerable<SelectListItem> PMCode { get; set; }
        public IEnumerable<SelectListItem> Restrictions1 { get; set; }
        public IEnumerable<SelectListItem> Restrictions2 { get; set; }
        public IEnumerable<SelectListItem> Restrictions3 { get; set; }
        public IEnumerable<SelectListItem> ParaIns { get; set; }
        public IEnumerable<SelectListItem> CommStatusIndicator { get; set; }
        
       
      
    }
}
