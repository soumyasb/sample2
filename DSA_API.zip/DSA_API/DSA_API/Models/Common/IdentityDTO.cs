﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Common
{
    public class IdentityDTO
    {
        public string RequestorCode { get; set; }
        public string NetName { get; set; }
        public string EmployeeInitials { get; set; }
        public string RacfID { get; set; }
      
    }
}
