﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class HolidayDTO
    {
        [Required]
        [Display(Name = "ID")]
        public int ID { get; set; }
        [Required]
        [Display(Name = "Holiday")]
        [DataType(DataType.Date)]
        public DateTime? HolidayDate { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Teminated Date")]
        public DateTime? TermDate { get; set; }
        [Display(Name = "Last Updeted By")]
        [MaxLength(40)]
        public string LastUpdatedBy { get; set; }
        [Display(Name = "Last Updeted Date")]
        [DataType(DataType.Date)]
        public DateTime? LastUpdatedDate { get; set; }

        //public string MMDD { get; set; }

        public string CCYY { get; set; }
    }
}
