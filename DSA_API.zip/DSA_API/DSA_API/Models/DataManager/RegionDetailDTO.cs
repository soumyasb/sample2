﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class RegionDetailDTO
    {
        [Required]
        [RegularExpression(@"\d{1}", ErrorMessage = "Region ID must be 1 digit")]
        [Display(Name = "Region ID")]
        public string RegionID { get; set; }
        [Required]
        [RegularExpression(@"\d{3}", ErrorMessage = "District ID must be 3 digits")]
        [Display(Name = "District ID")]
        public string DistrictID { get; set; }
        [Required]
        [Display(Name = "Region Name")]
        public string RegionName { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "End Date Date")]
        public DateTime? EndDate { get; set; }
        public SelectList Districts { get; set; }
        public string DistrictName { get; set; }
        public string Message { get; set; }
    }
}
