﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class HearingRoomInitDTO
    {
       
        [Display(Name = "Office ID")]
        public string OfficeID { get; set; }

        

        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; }

       

        [Display(Name = "Room Description")]
        public string Description { get; set; }


        [DataType(DataType.Date)]
        [Display(Name = "Closed Date")]
        public DateTime? DateClosed { get; set; }

        public IEnumerable<SelectListItem> OfficeList { get; set; }
    }
}
