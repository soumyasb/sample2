﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class OfficeDetailDTO
    {
        //public int id { get; set; }
        [Required]
        [RegularExpression(@"\d{3}", ErrorMessage = "Office ID must be 3 digits")]
        [Display(Name = "Office RU")]
        public string OfficeID { get; set; }
        [Required]
        [MaxLength(35)]
        [Display(Name = "Office Name")]
        public string Name { get; set; }
        [Required]
        [MaxLength(35)]
        [Display(Name = "Address")]
        public string AddressLineOne { get; set; }
        [Required]
        [MaxLength(13)]
        [Display(Name = "City")]
        public string City { get; set; }
        [Required]
        [MaxLength(5)]
        [Display(Name = "Zip")]
        public string Zip { get; set; }
        [MaxLength(4)]
        [Display(Name = "Zip 4")]
        public string Zip4 { get; set; }
        [Required]
        [MaxLength(10)]
        [RegularExpression(@"\d{10}", ErrorMessage = "Phone Number must be 10 digits")]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }
        [Required]
        [RegularExpression(@"\d{3}", ErrorMessage = "District ID must be 3 digits")]
        [Display(Name = "District ID")]
        public string DistrictID { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Effective Date")]
        public DateTime? EffectiveDate { get; set; }
        [RegularExpression(@"[a-zA-Z]{3}", ErrorMessage = "Abbriviation must be 3 alpha characters")]
        [Display(Name = "Office ID")]
        public string NameAbbriv { get; set; }
        [RegularExpression(@"[a-zA-Z]{2}", ErrorMessage = "Feild File must be 2 alpha characters")]
        [Display(Name = "Field File Abbr")]
        public string FieldFileDsg { get; set; }
        [MaxLength(5)]
        [RegularExpression(@"\d{5}", ErrorMessage = "Requester Code must be 5 digits")]
        [Display(Name = "Requestor Code")]
        public string RequestorCode { get; set; }
        [MaxLength(10)]
        [RegularExpression(@"\d{10}", ErrorMessage = "Fax Number must be 10 digits")]
        [Display(Name = "Fax Number")]
        public string FaxNumber { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Termination Date")]
        public DateTime? TerminationDate { get; set; }

    }
}
