﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class HearingTimeDTO
    {
        [Required]
        [Display(Name = "ID")]
        public int ID { get; set; }
        [Required]
      
        [Display(Name = "Category")]
        public string Category { get; set; }
        [Range(1, 999)]
        [Display(Name = "Hearing Time")]
        public int HearingTime { get; set; }
        [Range(1, 999)]
        [Display(Name = "Interview Time")]
        public int InterviewTime { get; set; }
        [Range(1, 999)]
        [Display(Name = "ReExam Time")]
        public int ReExamTime { get; set; }
        [MaxLength(40)]
        [Display(Name = "Last Updated By")]
        public string LastUpdatedBy { get; set; }

        [Display(Name = "Last Updated Date")]
        [DataType(DataType.Date)]
        public DateTime? LastUpdatedDate { get; set; }
        public string message { get; set; }

    }
}
