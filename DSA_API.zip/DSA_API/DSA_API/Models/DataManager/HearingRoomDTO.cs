﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class HearingRoomDTO
    {
        public HearingRoomDetailDTO hearingRoom { get; set; }
        public IEnumerable<SelectListItem> OfficeList { get; set; }
        public string message { get; set; }

    }
}
