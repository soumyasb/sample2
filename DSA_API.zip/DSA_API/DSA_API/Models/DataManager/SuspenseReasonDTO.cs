﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class SuspenseReasonDTO
    {
        [Required]
        [RegularExpression(@"[a-zA-Z0-9]{3}", ErrorMessage = "Code must be 3 alpha numeric character")]
        [Display(Name = "Type")]
        public string Code { get; set; }
        [Required]
        [Display(Name = "Suspense Description")]
        public string Description { get; set; }
        [Display(Name = "End Effective Date")]
        public DateTime? TermDate { get; set; }
    }
}
