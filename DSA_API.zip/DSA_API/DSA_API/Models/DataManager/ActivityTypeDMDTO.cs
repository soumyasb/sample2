﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class ActivityTypeDMDTO
    {
        [Required]
        [Display(Name = "ID")]
        public int ID { get; set; }
        [Required]
        [RegularExpression(@"[a-zA-Z0-9]{1}", ErrorMessage = "Code must be 1 alpha numeric character")]
        [Display(Name = "Code")]
        public string Code { get; set; }
        [Required]
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Required]
        [Display(Name = "Abbreviation")]
        public string Abbr { get; set; }
        public string HearingTypes { get; set; }

        [Display(Name = "Confidential")]
        public bool Confidential { get; set; }

        [Display(Name = "End Effective Date")]
        public DateTime? TermDate { get; set; }

        [Display(Name = "Last Updeted By")]
        public string lastUpdatedBy { get; set; }
        [Display(Name = "Last Updated Date")]
        [DataType(DataType.Date)]
        public DateTime? lastUpdetedDate { get; set; }
    }
}
