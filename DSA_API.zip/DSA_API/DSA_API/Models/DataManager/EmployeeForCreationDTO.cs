﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class EmployeeForCreationDTO
    {

        public EmployeeDTO employee { get; set; }
        public IEnumerable<SelectListItem> OfficeList { get; set; }
        public IEnumerable<SelectListItem> ClassificationList { get; set; }
        public IEnumerable<SelectListItem> ClassList { get; set; }

    }
}
