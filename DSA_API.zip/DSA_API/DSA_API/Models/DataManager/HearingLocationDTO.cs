﻿using DSA_API.Models.HearingRoomProfile;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class HearingLocationDTO
    {
        [Required]
        public int HearingLocationId { get; set; }
        [Required]
        [RegularExpression(@"\d{3}", ErrorMessage = "Must be three cheracters")] //three digits
        public string OfficeId { get; set; }
        [Required]
        [MaxLength(3)]
        public string RoomNumber { get; set; }
        public string RoomDescription { get; set; }
        public DateTime? ClosedDate { get; set; }
        public HearingRoomProfileDTO HearingRoomProfile { get; set; }

    }
}
