﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class OIPTypeDTO
    {
        [Required]
        [RegularExpression(@"[a-zA-Z0-9]{1}", ErrorMessage = "Code must be 1 alpha numeric character")]
        [Display(Name = "Type")]
        public string Type { get; set; }
        [Required]
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "End Effective Date")]
        public DateTime? TermDate { get; set; }
    }
}
