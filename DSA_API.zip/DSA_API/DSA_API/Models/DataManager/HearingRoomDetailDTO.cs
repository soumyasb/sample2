﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class HearingRoomDetailDTO
    {

        public int HearingLocationId { get; set; }
        [Required]
        [Display(Name = "Office ID")]
        public string OfficeID { get; set; }

        [Required]
        
        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; }

        [Required]
     
        [Display(Name = "Room Description")]
        public string Description { get; set; }
      

        [DataType(DataType.Date)]
        [Display(Name = "Closed Date")]
        public DateTime? DateClosed { get; set; }
     
    
    }
}
