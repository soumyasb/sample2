﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class ReasonCategoryDTO
    {
        [Display(Name = "ID")]
        public int ID { get; set; }
        [Required]
        [MaxLength(3)]
        [Display(Name = "From Category")]
        public string FromCategory { get; set; }
        [Required]
        [MaxLength(3)]
        [Display(Name = "To Category")]
        public string ToCategory { get; set; }
        [Required]
        [MaxLength(30)]
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "Special Cert")]
        public bool SpecialCert { get; set; }
        [Display(Name = "Updated By")]
        public string UpdatedBy { get; set; }
        [Display(Name = "Update Date")]
        public DateTime? UpdateDay { get; set; }
        [Display(Name = "Temination Date")]
        public DateTime? TermDate { get; set; }
    }
}
