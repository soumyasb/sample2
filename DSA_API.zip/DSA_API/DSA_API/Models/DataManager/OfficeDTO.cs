﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class OfficeDTO
    {
        public OfficeDetailDTO office { get; set; }
        public IEnumerable<SelectListItem> districtOfficeList { get; set; }
        public string message { get; set; }
    }
}
