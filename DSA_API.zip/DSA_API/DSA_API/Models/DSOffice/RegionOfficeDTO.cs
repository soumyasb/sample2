﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class RegionOfficeDTO
    {
        public List<RegionOfficeDTO> results { get; set; }
        public string RegionId { get; set; }
        public string RegionName { get; set; }
        public string OfficeId { get; set; }
        public string OfficeName { get; set; }

        public static implicit operator List<object>(RegionOfficeDTO v)
        {
            throw new NotImplementedException();
        }
    }
}
