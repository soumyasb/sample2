﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Appointments
{
    public class ActivityTypeDTO
    {
        public int ActivityTypeId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string Abbriviation { get; set; }
        public string Types { get; set; }
        public bool isConfidential { get; set; }
        public DateTime? TeminationDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdateDate { get; set; }

    }
}
