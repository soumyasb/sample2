﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Appointments
{
    public class EmployeeAppointmentEditDTO
    {
        public IEnumerable<EmployeeAppointmentDTO> EmployeeProfileList { get; set; }
        public IEnumerable<ActivityTypeDTO> ActivityTypeList { get; set; }

    }
}
