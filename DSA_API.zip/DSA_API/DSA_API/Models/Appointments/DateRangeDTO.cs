﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Appointments
{
    public class DateRangeDTO
    {
        public DateTime Start { get; set; }
        public DateTime End { get; set; }

    }
}
