﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Appointments
{
    public class HearingRoomAppointmentDTO
    {
        [Required]
        public int AppointmentId { get; set; }
        [Required]
        public int ReacurrenceNumber { get; set; }
        //[Required]
        //[MaxLength(1)]
        //public string ActivityType { get; set; }
        [MaxLength(1)]
        public string DayType { get; set; }
        [MaxLength(1)]
        [RegularExpression(@"[1-7]", ErrorMessage = "Day of the Week must be a number between 1-7")]
        public string DayOfTheWeek { get; set; }
        [Required]
        public int HearingRoomId { get; set; }
        [RegularExpression(@"^([1-9]|1[0-2])$", ErrorMessage = "Month of the Year must be a number between 1-12")]
        public string MonthOfTheYear { get; set; }
        [RegularExpression(@"^([0-9]|[1-2][0-9]|3[0-1])$", ErrorMessage = "Day of the Month must be a number between 1-31")]
        public string DayOfTheMonth { get; set; }
        [MaxLength(1)]
        public string OccuranceType { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public DateTime? DateUpdated { get; set; }
        public bool isDispayComment { get; set; }
        public string Comment { get; set; }
        public int? AppointmentNumber { get; set; }
        public bool isAllDay { get; set; }
    }
}
