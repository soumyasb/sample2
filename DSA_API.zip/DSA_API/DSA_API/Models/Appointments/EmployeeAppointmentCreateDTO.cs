﻿using DSA_API.Models.DataManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Appointments
{
    public class EmployeeAppointmentCreateDTO
    {
        public EmployeeAppointmentDTO DefultAppointment { get; set; }
        public IEnumerable<ActivityTypeDTO> ActivityTypeList { get; set; }
        public IEnumerable<EmployeeDTO> EmployeeListForOffice { get; set; }
    }
}
