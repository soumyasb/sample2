﻿using DSA_API.Entities;
using DSA_API.Models;

namespace DSA_API.Services 
{
    public interface IUserRepository
    {
        Employee GetEmployee(string loginId);
        UserDTO GetUser(string UserName);
    }
}