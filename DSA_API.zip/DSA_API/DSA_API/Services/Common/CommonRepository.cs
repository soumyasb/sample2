﻿using DSA_API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services 
{
    public class CommonRepository : ICommonRepository
    {
        private DSAContext _context;
        public CommonRepository(DSAContext context)
        {
            _context = context;
        }
        public bool UpdateDLStats(string TechID, string dlNumber, string tCode, string name3Pos)
        {
            DateTime newDate = System.Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd h:mm tt"));
            Dlupdstats stats = new Dlupdstats()
            {
                CdEmpId = TechID,
                DtTrans = newDate,
                NbrDl = dlNumber,
                CdTcode = tCode,
                Nme3pos = name3Pos
            };
            _context.Dlupdstats.Add(stats);
            return (_context.SaveChanges() >= 0);
        }
        public bool InsertOrigStat(string TechID, string DLNumber, string TCode, string N3Pos, string ArrestType = "",
            string testType = "", string CourtCode = "", DateTime? ArrestDate = null, string BACLevel = "", string LawAgency = "")
        {
            DateTime arrestdate = DateTime.MinValue;
            if (ArrestDate != null)
                arrestdate = Convert.ToDateTime(ArrestDate);

            DateTime newDate = System.Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd h:mm tt"));
           
            OrigDAMDAP damdap = new OrigDAMDAP()
            {
                NbrDl = DLNumber,
                CdTcode = TCode,
                Nme3pos = N3Pos,
                DtTrans = newDate,
                CdEmpId = TechID,
                ArrestType = ArrestType,
                TestType = testType,
                CourtCode = CourtCode,
                ArrestDate = arrestdate,
                BACLevel = BACLevel,
                LawAgency = LawAgency

            };
            _context.OrigDAMDAP.Add(damdap);
            return (_context.SaveChanges() >= 0);
        }
    
        public bool InsertStay( string DLNumber, string EndStay, DateTime EffectiveDate, string OrigAuthSection, DateTime OrigEffectiveDate)
        {
            StayStats stay = new StayStats()
            {
                NbrDl = DLNumber,
                AuthSection = EndStay,
                EffDate = EffectiveDate,
                OrigAuthSection = OrigAuthSection,
                OrigEffDate = OrigEffectiveDate
            };
            _context.Add(stay);
            return (_context.SaveChanges() >= 0);
        }
        public bool UpdateStay(string DLNumber, DateTime EndStayDate)
        {
            bool exist = _context.StayStats.Where(x => x.NbrDl == DLNumber).Any();
            if (!exist)
            {
                return false;
            }
            EndStayDate = EndStayDate.AddDays(-1); 
            StayStats stay = new StayStats()
            {
                NbrDl = DLNumber,
                EndStayDate = EndStayDate
            };
            return (_context.SaveChanges() >= 0);
        }
    }
}
