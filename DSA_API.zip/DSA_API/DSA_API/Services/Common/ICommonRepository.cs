﻿using System;

namespace DSA_API.Services
{
    public interface ICommonRepository
    {
        bool UpdateDLStats(string TechID, string dlNumber, string tCode, string name3Pos);
        bool InsertOrigStat(string TechID, string DLNumber, string TCode, string N3Pos, string ArrestType = "",
            string testType = "", string CourtCode = "", DateTime? ArrestDate = null, string BACLevel = "", string LawAgency = "");
        bool InsertStay(string DLNumber, string EndStay, DateTime EffectiveDate, string OrigAuthSection, DateTime OrigEffectiveDate);
        bool UpdateStay(string DLNumber, DateTime EndStayDate);
    }
}