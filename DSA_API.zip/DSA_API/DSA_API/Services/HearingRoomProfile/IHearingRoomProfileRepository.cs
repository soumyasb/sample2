﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Models;
using DSA_API.Models.HearingRoomProfile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.HearingRoomProfile
{
    public interface IHearingRoomProfileRepository
    {
        HearingRoomProfileDTO GetHearingRoomProfile(int HearingRoomProfileId);
        Hearinglocprofile ConvertHearingRoomProfile(HearingRoomProfileDTO RoomProfile);
        //IEnumerable<HearingRoomProfileDTO> GetHearingRoomProfileForOffice(string OfficeId);
        HearingRoomProfileDTO GetHearingRoomProfileForHearingLocation(int HearingLocationId);
        HearingLocationDTO GetHearingRoom(int HearingLocationId);
        IEnumerable<HearingLocationDTO> GetHearingRoomsForOffice(string OfficeId);
        HearingRoomProfileDTO GetDefultRoomProfile(int HearingRoomProfileId);
        IEnumerable<DSOfficeDTO> GetDistrictOffices(string OfficeID);
    }
}
