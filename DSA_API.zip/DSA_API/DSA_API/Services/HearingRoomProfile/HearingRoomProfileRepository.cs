﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Models;
using DSA_API.Models.HearingRoomProfile;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.HearingRoomProfile
{
    public class HearingRoomProfileRepository : IHearingRoomProfileRepository
    {
        private DSAContext _context;
        public HearingRoomProfileRepository(DSAContext context)
        {
            _context = context;
        }

        public HearingRoomProfileDTO GetHearingRoomProfile(int HearingRoomProfileId)
        {

            var rProfile = (from h in _context.Hearinglocprofile.AsNoTracking()
                            where (h.LocProfileId == HearingRoomProfileId)
                            select new HearingRoomProfileDTO()
                            {
                                Id = h.LocProfileId,
                                HearingRoomId = h.HearingLocationId,
                                //EffectiveStartDate = h.DtEffStrt,
                                //EffectiveEndDate = h.DtEffEnd.Value,
                                UpdatedBy = h.CdUpdtTechId.Value,
                                UpdatedDate = h.DtUpdtTrans.Value,
                                isActive = h.FlgActive == "1" ? true: false,
                                //isPhoneAvailable = h.FlgPhoneAvb == "1" ? true : false,
                                MonStartTime = h.TmeMonStrt,
                                MonEndTime = h.TmeMonEnd,
                                TueStartTime = h.TmeTueStrt,
                                TueEndTime = h.TmeTueEnd,
                                WedStartTime = h.TmeWedStrt,
                                WedEndTime = h.TmeWedEnd,
                                ThuStartTime = h.TmeThuStrt,
                                ThuEndTime = h.TmeThuEnd,
                                FriStartTime = h.TmeFriStrt,
                                FriEndTime = h.TmeFriEnd,
                                SatStartTime = h.TmeSatStrt,
                                SatEndTime = h.TmeSatEnd,
                                SunStartTime = h.TmeSunStrt,
                                SunEndTime = h.TmeSunEnd
                                
                            }).FirstOrDefault();

            return rProfile;
        }
        
        public HearingRoomProfileDTO GetHearingRoomProfileForHearingLocation(int HearingLocationId)
        {
            
            var rProfiles = (from h in _context.Hearinglocprofile.AsNoTracking()
                            where (h.HearingLocationId == HearingLocationId)
                            orderby h.DtUpdtTrans descending
                            select new HearingRoomProfileDTO()
                            {

                                Id = h.LocProfileId,
                                HearingRoomId = h.HearingLocationId,
                                //EffectiveStartDate = h.DtEffStrt,
                                //EffectiveEndDate = h.DtEffEnd.Value,
                                UpdatedBy = h.CdUpdtTechId.Value,
                                UpdatedDate = h.DtUpdtTrans.Value,
                                isActive = h.FlgActive == "1" ? true : false,
                                //isPhoneAvailable = h.FlgPhoneAvb == "1" ? true : false,
                                MonStartTime = h.TmeMonStrt,
                                MonEndTime = h.TmeMonEnd,
                                TueStartTime = h.TmeTueStrt,
                                TueEndTime = h.TmeTueEnd,
                                WedStartTime = h.TmeWedStrt,
                                WedEndTime = h.TmeWedEnd,
                                ThuStartTime = h.TmeThuStrt,
                                ThuEndTime = h.TmeThuEnd,
                                FriStartTime = h.TmeFriStrt,
                                FriEndTime = h.TmeFriEnd,
                                SatStartTime = h.TmeSatStrt,
                                SatEndTime = h.TmeSatEnd,
                                SunStartTime = h.TmeSunStrt,
                                SunEndTime = h.TmeSunEnd

                            }).FirstOrDefault();

            return rProfiles;
        }

        public HearingRoomProfileDTO GetDefultRoomProfile(int HearingRoomProfileId)
        {

            var rProfile = new HearingRoomProfileDTO()
                            {
                                Id = 0,
                                HearingRoomId = HearingRoomProfileId,
                                //EffectiveStartDate = h.DtEffStrt,
                                //EffectiveEndDate = h.DtEffEnd.Value,
                                UpdatedBy = null,
                                UpdatedDate = null,
                                isActive = true,
                                //isPhoneAvailable = false,
                                MonStartTime = "08:00",
                                MonEndTime = "17:00",
                                TueStartTime = "08:00",
                                TueEndTime = "17:00",
                                WedStartTime = "08:00",
                                WedEndTime = "17:00",
                                ThuStartTime = "08:00",
                                ThuEndTime = "17:00",
                                FriStartTime = "08:00",
                                FriEndTime = "17:00",
                                SatStartTime = "08:00",
                                SatEndTime = "17:00",
                                SunStartTime = "08:00",
                                SunEndTime = "17:00"
            };

            return rProfile;
        }

        public Hearinglocprofile ConvertHearingRoomProfile(HearingRoomProfileDTO RoomProfile)
        {

            var h = new Hearinglocprofile();

            h.LocProfileId = RoomProfile.Id;
            h.HearingLocationId = RoomProfile.HearingRoomId;
            h.DtEffStrt = new DateTime(1900,1,1);
            //h.DtEffEnd = RoomProfile.EffectiveEndDate;
            h.CdUpdtTechId =RoomProfile.UpdatedBy;
            h.DtUpdtTrans = RoomProfile.UpdatedDate;
            h.FlgActive = RoomProfile.isActive ? "1" : "0";
            h.FlgPhoneAvb = "1";
            h.TmeMonStrt = RoomProfile.MonStartTime;
            h.TmeMonEnd = RoomProfile.MonEndTime;
            h.TmeTueStrt = RoomProfile.TueStartTime;
            h.TmeTueEnd = RoomProfile.TueEndTime;
            h.TmeWedStrt = RoomProfile.WedStartTime;
            h.TmeWedEnd = RoomProfile.WedEndTime;
            h.TmeThuStrt = RoomProfile.ThuStartTime;
            h.TmeThuEnd = RoomProfile.ThuEndTime;
            h.TmeFriStrt = RoomProfile.FriStartTime;
            h.TmeFriEnd = RoomProfile.FriEndTime;
            h.TmeSatStrt = RoomProfile.SatStartTime;
            h.TmeSatEnd = RoomProfile.SatEndTime;
            h.TmeSunStrt = RoomProfile.SunStartTime;
            h.TmeSunEnd = RoomProfile.SunEndTime;

            return h;
        }

        public HearingLocationDTO GetHearingRoom(int HearingLocationId)
        {

            var hRoom = (from h in _context.Hearinglocation.AsNoTracking()
                             where (h.Id == HearingLocationId)
                             select new HearingLocationDTO()
                             {
                                 HearingLocationId = h.Id,
                                 OfficeId = h.CdOffId,
                                 RoomNumber = h.NbrRoom,
                                 RoomDescription = h.DescRoom,
                                 ClosedDate = h.DtClosed
                             }).FirstOrDefault();

            return hRoom;
        }
        public IEnumerable<HearingLocationDTO> GetHearingRoomsForOffice(string OfficeId)
        {

            var hRoom = (from h in _context.Hearinglocation.AsNoTracking()
                         where (h.CdOffId == OfficeId)
                         select new HearingLocationDTO()
                         {
                             HearingLocationId = h.Id,
                             OfficeId = h.CdOffId,
                             RoomNumber = h.NbrRoom,
                             RoomDescription = h.DescRoom,
                             ClosedDate = h.DtClosed
                         }).ToList();

            return hRoom;
        }
        public Hearinglocation ConvertHearingRoom(HearingLocationDTO HearingLoc)
        {
            var h = new Hearinglocation();

            h.Id = HearingLoc.HearingLocationId;
            h.CdOffId = HearingLoc.OfficeId;
            h.NbrRoom = HearingLoc.RoomNumber;
            h.DescRoom = HearingLoc.RoomDescription;
            h.DtClosed = HearingLoc.ClosedDate;

            return h;
        }
        public IEnumerable<DSOfficeDTO> GetDistrictOffices(string OfficeID)
        {
            string districtID = _context.Dsoffice.AsNoTracking()
                .Where(o => o.CdOffId == OfficeID)
                .Select(o => o.CdDistId).FirstOrDefault();
            return (_context.Dsoffice.AsNoTracking()
                .Where(o => o.CdDistId == districtID)
                .Select(o => new DSOfficeDTO
            {
                OfficeID = o.CdOffId,
                Name = o.NmeOff,
                AddressLineOne = o.AddrLn1,
                City = o.CdCity,
                Zip = o.CdZip,
                Zip4 = o.CdZipAddrLst4,
                PhoneNumber = o.NbrPhone,
                DistrictID = o.CdDistId,
                EffectiveDate = o.DtEff,
                NameAbbriv = o.CdOffAbbr,
                FieldFileDsg = o.CdFldFileDsg,
                RequestorCode = o.CdRqstr,
                FaxNumber = o.NbrFax,
                TerminationDate = o.DtTerm
            }));
        }

    }
}
