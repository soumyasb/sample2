﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DSA_API.Services
{
    public class DSOfficeRepository : IDSOfficeRepository
    {
        private DSAContext _context;

        public DSOfficeRepository(DSAContext context)
        {
            _context = context; 
        }
        public IEnumerable<DSOfficeDTO> getAllDSOffices()
        {
            var officeList = _context.Dsoffice
                        .Select(o => new DSOfficeDTO()
                        {
                            OfficeID = o.CdOffId,
                            Name = o.NmeOff,
                            AddressLineOne = o.AddrLn1,
                            City = o.CdCity,
                            Zip = o.CdZip,
                            Zip4 = o.CdZipAddrLst4,
                            PhoneNumber = o.NbrPhone,
                            DistrictID = o.CdDistId,
                            EffectiveDate = o.DtEff,
                            NameAbbriv = o.CdOffAbbr,
                            FieldFileDsg = o.CdFldFileDsg,
                            RequestorCode = o.CdRqstr,
                            FaxNumber = o.NbrFax,
                            TerminationDate = o.DtTerm
                        }
                        ).ToList();
            return officeList;
        }

        public DSOfficeDTO getDSOffice(string id)
        {
            var office = _context.Dsoffice.AsNoTracking()
                        .Where(o => o.CdOffId == id)
                        .Select(o => new DSOfficeDTO()
                        {
                            OfficeID = o.CdOffId,
                            Name = o.NmeOff,
                            AddressLineOne = o.AddrLn1,
                            City = o.CdCity,
                            Zip = o.CdZip,
                            Zip4 = o.CdZipAddrLst4,
                            PhoneNumber = o.NbrPhone,
                            DistrictID = o.CdDistId,
                            EffectiveDate = o.DtEff,
                            NameAbbriv = o.CdOffAbbr,
                            FieldFileDsg = o.CdFldFileDsg,
                            RequestorCode = o.CdRqstr,
                            FaxNumber = o.NbrFax,
                            TerminationDate = o.DtTerm
                        }
                        ).FirstOrDefault();
            return office;
        }

        public Dsoffice convertDSOffice(DSOfficeDTO office)
        {
            Dsoffice o = new Dsoffice();

            o.CdOffId = office.OfficeID;
            o.NmeOff = office.Name;
            o.AddrLn1 = office.AddressLineOne;
            o.CdCity = office.City;
            o.CdZip = office.Zip;
            o.CdZipAddrLst4 = office.Zip4;
            o.NbrPhone = office.PhoneNumber;
            o.CdDistId = office.DistrictID;
            o.DtEff = office.EffectiveDate;
            o.CdOffAbbr = office.NameAbbriv;
            o.CdFldFileDsg = office.FieldFileDsg;
            o.CdRqstr = office.RequestorCode;
            o.NbrFax = office.FaxNumber;
            o.DtTerm = office.TerminationDate;

            return o;
        }


        public IEnumerable<SelectListItem> getOfficeList()
        {
            return (_context.Dsoffice.Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff)
            }));
        }

        public List<RegionOfficeDTO> GetRegionOffices(int empid, string emptype)
        {
            if (empid == 0)
            {
                return null;
            }
            if (String.IsNullOrEmpty(emptype))
            {
                return null;
            }

            var officeid = (from e in _context.Employee
                            where e.EmpId == empid
                            select e.CdOffId).First();

                           

            if (emptype == "D")
            {
                var results = (from r in _context.Region
                               join o in _context.Dsoffice on r.CdDistId equals o.CdDistId
                               where r.DtTerm == null && o.DtTerm == null && r.NmeRgn != o.NmeOff
                               //orderby r.CD_RGN_ID, o.CD_OFF_ID
                               orderby o.NmeOff
                               select new RegionOfficeDTO
                               {
                                   RegionId = r.CdRgnId,
                                   RegionName = r.NmeRgn,
                                   OfficeId = o.CdOffId,
                                   OfficeName = o.NmeOff
                               }).ToList();
                return results;
            }
            if (emptype == "O")
            {
                var results = (from r in _context.Region
                               join o in _context.Dsoffice on r.CdDistId equals o.CdDistId
                               where r.DtTerm == null && o.DtTerm == null && r.NmeRgn != o.NmeOff && o.CdOffId == officeid
                               orderby o.NmeOff
                               select new RegionOfficeDTO
                               {
                                   RegionId = r.CdRgnId,
                                   RegionName = r.NmeRgn,
                                   OfficeId = o.CdOffId,
                                   OfficeName = o.NmeOff
                               }).ToList();
                return results;
            }
            if (emptype == "R")
            {

                var regionId = (from e in _context.Employee
                                join o in _context.Dsoffice on e.CdOffId equals o.CdOffId
                                join r in _context.Region on o.CdDistId equals r.CdDistId
                                where e.EmpId == empid && r.DtTerm == null
                                select r.CdRgnId).SingleOrDefault().ToString();

                var results = (from r in _context.Region
                               join o in _context.Dsoffice on r.CdDistId equals o.CdDistId
                               where r.DtTerm == null && o.DtTerm == null && r.NmeRgn != o.NmeOff && r.CdRgnId == regionId
                               orderby o.NmeOff
                               select new RegionOfficeDTO
                               {
                                   RegionId = r.CdRgnId,
                                   RegionName = r.NmeRgn,
                                   OfficeId = o.CdOffId,
                                   OfficeName = o.NmeOff
                               }).ToList();
                return results;
            }
            return null;
        }

    }
}

