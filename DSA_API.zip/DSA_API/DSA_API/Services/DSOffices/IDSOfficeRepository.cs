﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services
{
    public interface IDSOfficeRepository
    {
        Dsoffice convertDSOffice(DSOfficeDTO office);
        IEnumerable<DSOfficeDTO> getAllDSOffices();
        DSOfficeDTO getDSOffice(string id);
        IEnumerable<SelectListItem> getOfficeList();
        List<RegionOfficeDTO> GetRegionOffices(int empid, string emptype);
    }
}