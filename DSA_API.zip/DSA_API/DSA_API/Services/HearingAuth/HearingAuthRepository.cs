﻿using DSA_API.Entities;
using DSA_API.Models.HearingAuth;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.HearingAuth
{
    public class HearingAuthRepository : IHearingAuthRepository
    {
        private DSAContext _context;
        public HearingAuthRepository(DSAContext context)
        {
            _context = context;
        }

        public IEnumerable<HearingAuthDTO> GetHearingAuth(int EmpID)
        {

            var HearingAuthList = (from h in _context.Hoauthtype1.AsNoTracking()
                                   from c in _context.Hearingtime1.Where(c => c.Id == h.CategoryId).DefaultIfEmpty()
                                   where (h.EmpId == EmpID)
                                   select new HearingAuthDTO()
                                   {
                                       ID = h.Id,
                                       EmpID = h.EmpId,
                                       CategoryID = h.CategoryId,
                                       //CategoryName = h.Category.Category,
                                       CategoryName = c.Category,
                                       LastUpdated = h.LastUpdatedDate,
                                       HearingTime = h.HearingTime,
                                       InterviewTime = h.InterviewTime,
                                       ReExamTime = h.ReExamTime,
                                       Active = (h.HearingTime == 0 && h.InterviewTime == 0 && h.ReExamTime == 0) ? false : true

                                   }).ToList();

            return HearingAuthList;
        }
        public IEnumerable<HearingAuthDTO> GetDefultHearingAuth(int EmpId)
        {
            var HearingAuthList = (from h in _context.Hearingtime1.AsNoTracking()

                                   select new HearingAuthDTO()
                                   {
                                       //ID = h.ID,
                                       EmpID = EmpId,
                                       CategoryID = h.Id,
                                       CategoryName = h.Category,
                                       //LastUpdated = DateTime.Now,
                                       HearingTime = h.HearingTime,
                                       InterviewTime = h.InterviewTime,
                                       ReExamTime = h.ReExamTime,
                                       Active = (h.HearingTime == 0 && h.InterviewTime == 0 && h.ReExamTime == 0) ? false : true

                                   }).ToList();

            return HearingAuthList;
        }

        public Hoauthtype1 ConvertHearingAuth(HearingAuthDTO Auth)
        {
            Hoauthtype1 h = new Hoauthtype1();

            h.Id = Auth.ID;
            h.EmpId = Auth.EmpID;
            h.CategoryId = Auth.CategoryID;
            h.LastUpdatedDate = Auth.LastUpdated;
            h.HearingTime = Auth.HearingTime;
            h.InterviewTime = Auth.InterviewTime;
            h.ReExamTime = Auth.ReExamTime;


            return h;
        }
    }
}
