﻿using DSA_API.Models.HearingAuth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;

namespace DSA_API.Services.HearingAuth
{
    public interface IHearingAuthRepository
    {
        IEnumerable<HearingAuthDTO> GetHearingAuth(int EmpID);
        IEnumerable<HearingAuthDTO> GetDefultHearingAuth(int EmpId);
        Hoauthtype1 ConvertHearingAuth(HearingAuthDTO Auth);
    }
}
