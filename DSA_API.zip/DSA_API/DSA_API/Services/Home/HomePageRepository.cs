﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Home;
using System;
using System.Collections.Generic;

namespace DSA_API.Services
{
    public class HomePageRepository : IHomePageRepository
    {
        private DSAContext _context;

        public HomePageRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<SuspenseDTO> GetEmployeeSuspense(string userId)
        {

            IList<SuspenseDTO> suspense = new List<SuspenseDTO>();
            suspense = _context.LoadStoredProc("rmselCaseInfo")
                           .WithSqlParam("ID", userId)
                           .WithSqlParam("LastDate", Convert.ToDateTime("01/20/2012"))
                           .ExecuteStoredProc<SuspenseDTO>();
            
            return suspense;
            
        }
    }
}
