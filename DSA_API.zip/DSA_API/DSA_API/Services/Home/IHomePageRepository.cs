﻿using System.Collections.Generic;
using DSA_API.Models.Home;

namespace DSA_API.Services
{
    public interface IHomePageRepository
    {
        IEnumerable<SuspenseDTO> GetEmployeeSuspense(string userId);
    }
}