﻿using DSA_API.Models.Customer;

namespace DSA_API.Services
{
    public interface IPersonRepository
    {
        bool UpdatePersonFromDCS(string dlNumber, string address1, string city, string class1, string class2, string state, string zip, string birthdate, string flgAddr, string ssn, string firstname, string middlename, string suffix, string lastname);
        CustomerDTO AddPerson(D26ResultsDTO dlResults);
    };

}