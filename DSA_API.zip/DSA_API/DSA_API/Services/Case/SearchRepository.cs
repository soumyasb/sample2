﻿using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Models.Customer;
using DSA_API.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using Microsoft.Extensions.Configuration;

namespace DSA_API.Services
{
    public class SearchRepository : ISearchRepository
    {
        private DSAContext _context;
        private DSARCHIVEContext _archived_context;
        private ICustomerRepository _customerRepository;
        private IConfiguration _configuration { get; }
        public SearchRepository(DSAContext context, 
            DSARCHIVEContext archiveContext, ICustomerRepository customerRepository, IConfiguration configuration)
        {
            _context = context;
            _archived_context = archiveContext;
            _customerRepository = customerRepository;
            _configuration = configuration;
        }

        SearchResultsDTO peopleCases = new SearchResultsDTO();

        public SearchResultsDTO CaseSearch(string keyword)
        {
            if (String.IsNullOrEmpty(keyword))
            {
                return peopleCases;
            }
            bool dlPresent = true;
            peopleCases.results = new List<SearchResultDTO>();
 
            Match match = Regex.Match(keyword, @"^[a-zA-Z]\d{7}$");
            if (match.Success)
            {
                dlPresent = true;
                keyword = StringFunctions.ConvertUpperCaseFirst(keyword);
            }
            else
            {
                dlPresent = false;
            }
       
            if (dlPresent)  // Dl Number Searches only....
            {
                var custAdd = false;
                if (!_context.Person.Any(p => p.NbrDl == keyword))
                {
                    custAdd = true;
                }
                if (custAdd)
                {
                    var d26Model = getD26(keyword);
                    if (d26Model != "null")
                    {
                        CustomerDTO customer = new CustomerDTO();
                        var dlResults = Newtonsoft.Json.JsonConvert.DeserializeObject<D26ResultsDTO>(d26Model);
                        if (dlResults.ValidationOK)
                        {
                            if (dlResults.DoubledDLCounter > 0)
                            {
                                peopleCases.Message = dlResults.ValidationMessage;
                                return peopleCases;
                            }
                            customer = _customerRepository.AddCustomer(dlResults);
                        }
                        else
                        {
                            peopleCases.Message = keyword + " " + dlResults.ValidationMessage;
                        }
                    }
                }

             
                var personResults = (from p in _context.Person
                           where  p.NbrDl.Contains(keyword)
                           select new
                           {
                               PERSON = p,
                               DSRCASE = p.Dsrcase
                           })
                            .AsQueryable();

                foreach (var r in personResults)
                {
                    peopleCases.results.Add(
                    new SearchResultDTO()
                    {
                        FirstName = r.PERSON.NmeFrstPrsn,
                        LastName = r.PERSON.NmeSurnmePrsn,
                        dlNumber = r.PERSON.NbrDl

                    });
                }
                return peopleCases;
            }

            // this portion of the search is for Name searches or Case searches
            var results = (from p in _context.Person
                        join c in _context.Dsrcase on p.NbrDl equals c.NbrDl
                        where p.NmeFrstPrsn.Contains(keyword) ||
                        p.NmeSurnmePrsn.Contains(keyword) ||
                        p.NbrDl.Contains(keyword) ||
                        c.CdCase == keyword
                        select new
                        {
                            PERSON = p,
                            DSRCASE = p.Dsrcase
                        })
                        .AsQueryable();

            foreach (var r in results)
            {
                //List<CaseDetailViewModel> cases = new List<CaseDetailViewModel>();
                //foreach (var ca in r.DSRCASE)
                //{
                //    cases.Add(new CaseDetailViewModel()
                //    {
                //        CaseNumber = ca.CD_CASE,
                //        DT_ORIG_TRANS = ca.DT_ORIG_TRANS
                //    });
                //}

                if (peopleCases.results.Exists(p => p.dlNumber == r.PERSON.NbrDl))
                {

                }
                else
                {
                    peopleCases.results.Add(
                    new SearchResultDTO()
                    {
                        FirstName = r.PERSON.NmeFrstPrsn,
                        LastName = r.PERSON.NmeSurnmePrsn,
                        dlNumber = r.PERSON.NbrDl,
                        //Cases = cases.OrderBy(x => x.DT_ORIG_TRANS).ToList()
                    });
                }
            }
                    
            return peopleCases;
        }
        private string getD26(string dlNumber)
        {

            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("D26search/D26/001/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = null;
                    }
                }
            }
            catch (Exception e)
            {
                json = null;
            }
            return json;
        }
    }
}
