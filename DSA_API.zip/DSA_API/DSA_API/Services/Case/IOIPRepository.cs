﻿using System.Collections.Generic;
using DSA_API.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services
{
    public interface IOIPRepository
    {
        IEnumerable<SelectListItem> getLanguages();
        IEnumerable<SelectListItem> getOIPTypes();
        IEnumerable<OIPDTO> InterpreterAgencySearch(OIPDTO oipdto, string caseNumber);
        IEnumerable<OIPDTO> InterpreterOIPPersonSearch(OIPDTO oipdto, string caseNumber);
        IEnumerable<OIPDTO> LawEnforcementAgencySearch(OIPDTO oipdto, string caseNumber);
        IEnumerable<OIPDTO> OIPPersonSearchByType(OIPDTO oipdto, string caseNumber);
        List<LanguageDTO> GetOIPLanguages(string type, int oipid, out int count);
    }
}