﻿using System.Collections.Generic;
using DSA_API.Models;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services
{
    public interface ICaseRepository : IBaseRespository
    {
        bool AssignAgencyByCaseNumber(OIPDTO newOIP);
        bool AssignOIPByCaseNumber(OIPDTO newOIP);
        OIPDTO GetAgency(int OIPID);
        List<OIPDTO> GetAssignedOIPs(string CaseNumber);
        //CaseCommentsDTO GetCaseComments(string CaseNumber, int page);
        CaseCommentsDTO GetCaseComments(string CaseNumber);
        CaseDetailDTO GetCaseDetails(string CaseNumber, bool Archive);
        List<CaseDetailDTO> GetCasesByDLNumber(string dlNumber);
        IEnumerable<SelectListItem> GetCerts();
        CaseDetailScheduledDTO GetCaseDetailForScheduledCase(string CaseNumber, string DlNumber);
        IEnumerable<SelectListItem> GetHearingTypes();
        OIPDTO GetOIP(int OIPID);
        IEnumerable<SelectListItem> GetReasons();
        IEnumerable<SelectListItem> GetReferrals();
        int NewAgency(OIPDTO OIPObj);
        int NewOIP(OIPDTO OIPObj);
        bool RemoveAssignedAgencyByCaseNumber(OIPDTO oipdto);
        bool RemoveAssignedOIPByCaseNumber(OIPDTO oipdto);
        bool DeleteAgency(OIPCaseDTO oipdto);
        bool DeleteOIP(OIPCaseDTO oipdto);
        CaseCommentDeleteDTO DeleteCaseComment(string CaseNumber, CaseCommentDeleteDTO CaseComment, string Employee3Digit);
        bool SaveNewComment(string CaseNumber, string Comment, string Employee3Digit, string DLNumber, string OfficeId);
        OIPDTO UpdateAgency(OIPDTO OIPObj);
        OIPDTO UpdateOIP(OIPDTO OIPObj);
        ScheduledCasesDTO GetScheduledCases(string officeId, string sort);
        UnScheduledCasesDTO GetUnScheduledCases(string officeId, string sort);
        CaseContactsDTO GetCaseContacts(string caseNumber);
        EmployeeContactsDTO GetCaseEmployeeContacts(string caseNumber);
        CaseRescheduleListDTO GetCaseReschedules(string caseNumber);
        CaseCoverSheetDTO GetCaseCoverSheetInfo(string casenumber);
        ClosedCaseConvertDetailDTO GetClosedCaseDetail(string casenumber);
        IEnumerable<SelectListItem> GetSuspenseReasons();
        SuspenseCaseAddDTO AddCaseSuspense(SuspenseCaseAddDTO suspense);
        SuspenseCaseModifyDTO ModifyCaseSuspense(SuspenseCaseModifyDTO suspense);
        bool DeleteCaseSuspense(int suspenseId);
        bool TestForEmployeeExistence(string EmpId, string OfficeId);
        SuspenseCasesDTO GetSuspenseCases(string casenumber);
        SuspenseCaseEmployeeDTO GetSuspenseEmployee(string casenumber);
        HearingReasonCodesDTO GetCaseHearingTypeReasonCode(string casenumber);
        bool UpdateCaseDetails(CaseDetailDTO caseDetail, string techID);
        bool AddCase(CaseDetailForAddDTO caseDetail, UserDTO user);
        string GetNewCaseNumber(string officeid, string officeAbrev);
     
    }
}