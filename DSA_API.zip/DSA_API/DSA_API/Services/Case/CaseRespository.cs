﻿using AutoMapper;
using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Helpers;
using DSA_API.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DSA_API.Services
{
    public class CaseRepository : ICaseRepository
    {
        private DSAContext _context;
        private DSARCHIVEContext _archived_context;

        private MapperConfiguration _config;
        private IMapper _mapper;
        public CaseRepository(DSAContext context, DSARCHIVEContext archived_context)
        {
            _context = context;
            _archived_context = archived_context;
            _config = new MapperConfiguration(cfg => {
                cfg.CreateMap<OIPDTO, Oippersn>();
                cfg.CreateMap<OIPDTO, Agency>();
                cfg.CreateMap<OIPDTO, Caseoip>();
                cfg.CreateMap<OIPDTO, Caseagny>();
            });
            _mapper = _config.CreateMapper();
        }


        /// <summary>
        /// GET Case Details by CaseNumber
        /// </summary>
        /// <param name="CaseNumber"></param>
        /// <param name="Archived"></param>
        /// <returns></returns>
        public CaseDetailDTO GetCaseDetails(string CaseNumber, bool Archived)
        {
            var casedetail = new CaseDetailDTO();

            var result = _context.Dsrcase.AsNoTracking()
                    .Where(e => e.CdCase == CaseNumber)
                    .FirstOrDefault();
            if (result == null)
                Archived = true;

            if (!Archived)
            {
                casedetail = (from c in _context.Dsrcase.AsNoTracking()

                            //Left Join Alternative(one liner)
                        from r in _context.Reason.Where(r => r.CdRsn == c.CdRsn).DefaultIfEmpty()
                        from h in _context.Hearingtype.Where(h => h.CdHrngTyp == c.CdHrngTyp).DefaultIfEmpty()
                        from p in _context.Person.Where(p => p.NbrDl == c.NbrDl).DefaultIfEmpty()

                            //Simulated Left Join(Long Way)
                            //join r in _context.REASONs.AsNoTracking().DefaultIfEmpty() on c.CD_RSN equals r.CD_RSN into trsn
                            //from newrsn in trsn.DefaultIfEmpty()

                            //Simple Join (No Good)
                            //join r in _context.REASONs.AsNoTracking() on c.CD_RSN equals r.CD_RSN
                            //join h in _context.HEARINGTYPEs.AsNoTracking() on c.CD_HRNG_TYP equals h.CD_HRNG_TYP
                            //join p in _context.People.AsNoTracking() on c.NBR_DL equals p.NBR_DL
                        where c.CdCase == CaseNumber
                        select new CaseDetailDTO()
                        {
                            CaseNumber = c.CdCase,
                            DLNumber = c.NbrDl,
                            lastName = p.NmeSurnmePrsn,
                            firstName = p.NmeFrstPrsn,
                            CD_HRNG_TYP = c.CdHrngTyp,
                            DESC_HRNG_TYP = h.DescHrngTyp,
                            DT_ORIG_TRANS = c.DtOrigTrans,
                            CaseStatus = c.CdStatusRec + c.CdStatusRec2,
                            DT_RCPT = c.DtRcpt,
                            CD_REFR_SRCE_TYP = c.CdRefrSrceTyp,
                            CD_RSN = c.CdRsn,
                            CD_ENDR = c.CdEndr,
                            DESC_RSN = r.DescRsn,
                            FRCaseNumber = c.NbrCaseAccFr,
                            AccidentCity = c.CdCityAcc,
                            AccidentDate = Convert.ToDateTime(c.DtAcc),
                            Archived = false
                        }).FirstOrDefault();
            }
            else
            {
                casedetail = (from c in _archived_context.Dsrcase.AsNoTracking()
                              where c.CdCase == CaseNumber
                              select new CaseDetailDTO()
                              {
                                  CaseNumber = c.CdCase,
                                  DLNumber = c.NbrDl,
                                  CD_HRNG_TYP = c.CdHrngTyp,
                                  DT_ORIG_TRANS = c.DtOrigTrans,
                                  CaseStatus = c.CdStatusRec + c.CdStatusRec2,
                                  DT_RCPT = c.DtRcpt,
                                  CD_REFR_SRCE_TYP = c.CdRefrSrceTyp,
                                  CD_RSN = c.CdRsn,
                                  CD_ENDR = c.CdEndr,
                                  Archived = true
                              }).FirstOrDefault();
                //casedetail.CaseNumber = CaseNumber;
                //casedetail.Message = "Case is Archived";
                //casedetail.CaseStatus = "35";
                //casedetail.DT_ORIG_TRANS = DateTime.MaxValue;
                //casedetail.Archived = true;
            }
            return casedetail;
        }
       
        public CaseDetailScheduledDTO GetCaseDetailForScheduledCase(string DlNumber, string CaseNumber)
        {
           
            var results = (from per in _context.Person.AsNoTracking()
                           join cse in _context.Dsrcase.AsNoTracking() on per.NbrDl equals cse.NbrDl
                           join res in _context.Reason.AsNoTracking() on cse.CdRsn equals res.CdRsn
                           join her in _context.Hearingtype.AsNoTracking() on cse.CdHrngTyp equals her.CdHrngTyp
                           where per.NbrDl == DlNumber && cse.CdCase == CaseNumber && res.DtTerm == null && her.DtTerm == null
                           select new CaseDetailScheduledDTO
                           {
                               DLNumber = per.NbrDl,
                               SubjectName = per.NmeFrstPrsn.Trim() +  " " + per.NmeSurnmePrsn.Trim(),
                               ReceiptDate = cse.DtRcpt.ToString("MM-dd-yyyy"),
                               HearingType = her.CdHrngTyp + "-" + her.DescHrngTyp,
                               Reason = cse.CdRsn + "-" + res.DescRsn
                           }).FirstOrDefault();

         
     
            return results;
        }


        public IEnumerable<SelectListItem> GetHearingTypes()
        {
            var HearingTypes = (from h in _context.Hearingtype.AsNoTracking()
                                orderby h.CdHrngTyp ascending
                                select new SelectListItem()
                                {
                                    Text = h.CdHrngTyp + " - " + h.DescHrngTyp,
                                    Value = h.CdHrngTyp
                                }).ToList();

            HearingTypes.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });

            return HearingTypes;
        }



        public IEnumerable<SelectListItem> GetReasons()
        {
            var reasons = (from r in _context.Reason.AsNoTracking()
                            orderby r.CdRsn ascending
                            select new SelectListItem()
                            {
                                Text = r.CdRsn + " - " + r.DescRsn,
                                Value = r.CdRsn
                            }).ToList();
            reasons.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return reasons;
        }



        public IEnumerable<SelectListItem> GetReferrals()
        {
            var referrals = (from r in _context.Referral.AsNoTracking()
                                orderby r.CdRefrSrceTyp ascending
                                select new SelectListItem()
                                {
                                    Text = r.CdRefrSrceTyp + " - " + r.DescRefrSrceTyp,
                                    Value = r.CdRefrSrceTyp
                                }).ToList();
            referrals.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return referrals;
        }




        public IEnumerable<SelectListItem> GetCerts()
        {
            var certs = (from c in _context.Cert.AsNoTracking()
                            orderby c.CdCertEndr ascending
                            select new SelectListItem()
                            {
                                Text = c.CdCertEndr + " - " + c.DescCertEndr,
                                Value = c.CdCertEndr
                            }).ToList();
            certs.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return certs;
        }



        public List<CaseDetailDTO> GetCasesByDLNumber(string dlNumber)
        {
            List<CaseDetailDTO> casesDetailed = new List<CaseDetailDTO>();

            var cases = (from c in _context.Dsrcase.AsNoTracking()
                            where c.NbrDl == dlNumber
                            orderby c.DtOrigTrans descending
                            select c.CdCase)
                            .ToArray();
            var archive_cases = (from c in _archived_context.Dsrcase.AsNoTracking()
                                 where c.NbrDl == dlNumber
                                 orderby c.DtOrigTrans descending
                                 select c.CdCase)
                            .ToArray();

          
            foreach (var i in cases)
            {
                casesDetailed.Add(GetCaseDetails(i, false));
            }
            foreach (var i in archive_cases)
            {
                casesDetailed.Add(GetCaseDetails(i, true));
            }
            return casesDetailed;
        }

       

        public CaseCommentsDTO GetCaseComments(string CaseNumber)
        {
           var query = (from c in _context.Dsrcomm
                         join emp in _context.Employee on c.CdUpdtTechId equals emp.CdEmpId
                         where c.CdCase == CaseNumber && c.DeleteFlag == false
                         select new CustomerCommentDTO()
                         {
                             TXT_COMM = c.TxtComm,
                             CD_UPDT_TECH_ID = c.CdUpdtTechId,
                             DT_UPDT_TRANS = c.DtUpdtTrans,
                             NBR_COMM = c.NbrComm,
                             EmployeeFullName = emp.NmeFrstPrsn + " " + emp.NmeSurnmePrsn
                         })
                            .AsQueryable();
            var TotalCount = query.Count();
            // var TotalPages = Math.Ceiling((double)TotalCount / PAGE_SIZE);

            var results = query.OrderByDescending(c => c.DT_UPDT_TRANS);
                          

            return new CaseCommentsDTO()
            {
                TotalComments = TotalCount,
                //TotalPages = TotalPages,
                Comments = results.ToList()
               // CurrentPage = page
            };
        }
        public CaseCommentDeleteDTO DeleteCaseComment(string CaseNumber, CaseCommentDeleteDTO CaseComment, string Employee3Digit)
        {

            CaseComment.Error = false;
            try
            {
                var comment = (from c1 in _context.Dsrcomm
                               where c1.CdCase == CaseNumber && c1.NbrDl == CaseComment.DLNumber && c1.NbrComm.ToString() == CaseComment.CommentNumber
                               select c1).First();
                comment.DeleteFlag = CaseComment.DeleteFlag;
                comment.DtUpdtTrans = DateTime.Now;
                comment.CdUpdtTechId = Employee3Digit;
                ////_context.Dsrcomm.Remove(comment);
                if (_context.SaveChanges() >= 0)
                {
                    if (CaseComment.DeleteFlag)
                    {
                        CaseComment.Message = "Comment Deleted";
                    }
                    else
                    {
                        CaseComment.Message = "Comment Activated";
                    }
                    CaseComment.Error = false;
                    return CaseComment;
                }
                else
                {
                    CaseComment.Message = "Comment Deletion Failed";
                    CaseComment.Error = true;
                    return CaseComment;
                }
            }
            catch (Exception e)
            {
                CaseComment.Message = "Comment Deletion Failed";
                CaseComment.Error = true;
                return CaseComment;
            }
        }

        public bool SaveNewComment(string CaseNumber, string Comment, string Employee3Digit, string DLNumber, string OfficeId)
        {
            int newestCommentNumber = 0;

            var caseCount = (from c in _context.Dsrcomm.AsNoTracking()
                                where c.CdCase == CaseNumber
                                select c.NbrComm
                                        ).ToArray();

            if (caseCount.Count() != 0)
            {
                newestCommentNumber = caseCount.Max();
            }

            try
            {
                using (_context)
                {
                    _context.Dsrcomm.Add(new Dsrcomm
                    {
                        TxtComm = Comment,
                        CdCase = CaseNumber,
                        CdUpdtTechId = Employee3Digit,
                        NbrDl = DLNumber,
                        NbrComm = ++newestCommentNumber,
                        CdFldDsoAlpha = OfficeId,
                        DtUpdtTrans = System.DateTime.Now
                    });

                    _context.SaveChanges();
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }



        public List<OIPDTO> GetAssignedOIPs(string CaseNumber)
        {
            List<OIPDTO> OIPs = new List<OIPDTO>();
            List<OIPDTO> Agencies = new List<OIPDTO>();

            OIPs = (from p in _context.Oippersn.AsNoTracking()
                    join c in _context.Caseoip.AsNoTracking() on p.Oipid equals c.Oipid
                    join d in _context.Dsrcase.AsNoTracking() on c.CdCase equals d.CdCase
                    join t in _context.Oiptype.AsNoTracking() on p.CdPrtyTyp equals t.CdPrtyTyp
                    where d.CdCase == CaseNumber
                    select new OIPDTO()
                    {
                        NMEFRSTPRSN = p.NmeFrstPrsn,
                        NMESURNMEPRSN = p.NmeSurnmePrsn,
                        NMEMIDPRSN = p.NmeMidPrsn,
                        NMESUFXPRSN = p.NmeSufxPrsn,
                        NBRPHONE = p.NbrPhone,
                        NBRCELLPHONE = p.NbrCellPhone,
                        NBRFAX = p.NbrFax,
                        EmailAddress = p.EmailAddress,
                        NMEAGENCY = p.NmeAgency,
                        ADDRLN1 = p.AddrLn1,
                        CDCITY = p.CdCity,
                        CDSTATE = p.CdState,
                        CDZIP = p.CdZip,
                        TXTCOMM = p.TxtComm,
                        CDPRTYTYP = p.CdPrtyTyp,
                        DESCPRTYTYP = t.DescPrtyTyp,
                        OIPID = p.Oipid,
                        NbrOIP = p.NbrOip
                    }).OrderBy(m => m.NMESURNMEPRSN).ThenBy(m => m.NMEFRSTPRSN).ToList();

            Agencies = (from a in _context.Agency.AsNoTracking()
                        join c in _context.Caseagny.AsNoTracking() on a.Oipid equals c.Oipid
                        join d in _context.Dsrcase.AsNoTracking() on c.CdCase equals d.CdCase
                        join t in _context.Oiptype.AsNoTracking() on a.CdPrtyTyp equals t.CdPrtyTyp
                        where d.CdCase == CaseNumber
                        select new OIPDTO()
                        {
                            NMEAGENCY = a.NmeAgency,
                            NBRPHONE = a.NbrPhone,
                            NBRCELLPHONE = a.NbrCellPhone,
                            NBRFAX = a.NbrFax,
                            EmailAddress = a.EmailAddress,
                            ADDRLN1 = a.AddrLn1,
                            CDCITY = a.CdCity,
                            CDSTATE = a.CdState,
                            CDZIP = a.CdZip,
                            TXTCOMM = a.TxtComm,
                            CDPRTYTYP = a.CdPrtyTyp,
                            DESCPRTYTYP = t.DescPrtyTyp,
                            OIPID = a.Oipid,
                            NbrOIP = a.NbrOip
                        }).OrderBy(m => m.NMEAGENCY).ToList();

            foreach (OIPDTO vm in OIPs)
            {
                
                
                //vm.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = vm.OIPID, type = vm.CD_PRTY_TYP });
                //vm.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = vm.OIPID, casenumber = CaseNumber, type = vm.CD_PRTY_TYP });
            }

            foreach (OIPDTO vm in Agencies)
            {
                //vm.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = vm.OIPID, type = vm.CD_PRTY_TYP });
                //vm.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = vm.OIPID, casenumber = CaseNumber, type = vm.CD_PRTY_TYP });
            }

            OIPs.AddRange(Agencies);

            return OIPs;
        }


        public OIPDTO GetOIP(int OIPID)
        {
            var OIP = (from p in _context.Oippersn
                        where p.Oipid == OIPID
                        select new OIPDTO()
                        {
                            OIPID = p.Oipid,
                            NbrOIP = p.NbrOip,
                            NMEFRSTPRSN = p.NmeFrstPrsn,
                            NMESURNMEPRSN = p.NmeSurnmePrsn,
                            NMEMIDPRSN = p.NmeMidPrsn,
                            NMESUFXPRSN = p.NmeSufxPrsn,
                            NBRPHONE = p.NbrPhone,
                            NBRCELLPHONE = p.NbrCellPhone,
                            NBRFAX = p.NbrFax,
                            EmailAddress = p.EmailAddress,
                            NMEAGENCY = p.NmeAgency,
                            ADDRLN1 = p.AddrLn1,
                            CDCITY = p.CdCity,
                            CDSTATE = p.CdState,
                            CDZIP = p.CdZip,
                            TXTCOMM = p.TxtComm,
                            CDPRTYTYP = p.CdPrtyTyp
                        }).First();
            return OIP;
        }


        public OIPDTO GetAgency(int OIPID)
        {
            OIPDTO OIPVM = new OIPDTO();
            try
            {
                var OIP = (from a in _context.Agency
                            where a.Oipid == OIPID
                            select new OIPDTO()
                            {
                                OIPID = a.Oipid,
                                NbrOIP = a.NbrOip,
                                NBRPHONE = a.NbrPhone,
                                NBRCELLPHONE = a.NbrCellPhone,
                                NBRFAX = a.NbrFax,
                                EmailAddress = a.EmailAddress,
                                NMEAGENCY = a.NmeAgency,
                                ADDRLN1 = a.AddrLn1,
                                CDCITY = a.CdCity,
                                CDSTATE = a.CdState,
                                CDZIP = a.CdZip,
                                TXTCOMM = a.TxtComm,
                                CDPRTYTYP = a.CdPrtyTyp
                            }).First();
                return OIP;
            }
            catch (Exception e)
            {
                return OIPVM;
            }
        }


        public OIPDTO UpdateOIP(OIPDTO OIPObj)
        {
            Oippersn mappedObj = _mapper.Map<OIPDTO, Oippersn>(OIPObj);

            try
            {
                _context.Oippersn.Attach(mappedObj);

                var update = _context.Entry(mappedObj);
                update.State = EntityState.Modified;

                update.Property(e => e.DtUpdtTrans).IsModified = false;

                _context.SaveChanges();

                if (OIPObj.CDPRTYTYP == "M")
                {
                    if (_context.Interpre.Count((i) => i.Oipid == OIPObj.OIPID && i.CdLanguage == OIPObj.CDLANGUAGE && i.CdPrtyTyp == OIPObj.CDPRTYTYP) == 0)
                    {
                        Interpre i = new Interpre();
                        i.CdLanguage = OIPObj.CDLANGUAGE;
                        i.CdPrtyTyp = OIPObj.CDPRTYTYP;
                        i.DtTerm = null;
                        i.Oipid = OIPObj.OIPID;
                        i.NbrPhoneAc = OIPObj.NBRPHONE.Substring(0, 3);
                        _context.Interpre.Add(i);
                        _context.SaveChanges();
                    }
                    else
                    {
                        Entities.Interpre c = (from i in _context.Interpre
                                               where i.Oipid == OIPObj.OIPID && i.CdLanguage == OIPObj.CDLANGUAGE && i.CdPrtyTyp == OIPObj.CDPRTYTYP
                                               select i).First();
                        c.NbrPhoneAc = OIPObj.NBRPHONE.Substring(0,3);
                        if (_context.SaveChanges() >= 0)
                        {
                            OIPObj.Error = false;
                        }
                        else
                        {
                            OIPObj.Error = true;
                        }
                    }
                }

                OIPObj.Error = false;
            }
            catch (Exception e)
            {
                OIPObj.Error = true;
            }

            return OIPObj;
        }


        public int NewOIP(OIPDTO OIPObj)
        {
            Oippersn mappedObj = _mapper.Map<OIPDTO, Oippersn>(OIPObj);
            int OIPID;
            try
            {
                _context.Oippersn.Add(mappedObj);

                _context.SaveChanges();

                OIPID = mappedObj.Oipid;

                _context.Caseoip.Add(new Caseoip
                {
                    CdCase = OIPObj.CdCase,
                    Oipid = OIPID,
                    CdUpdtTechId = OIPObj.CDUPDTTECHID
                });

                _context.SaveChanges();
                 
                if (OIPObj.CDPRTYTYP == "M")
                {
                    Interpre i = new Interpre();
                    i.CdLanguage = OIPObj.CDLANGUAGE;
                    i.CdPrtyTyp = OIPObj.CDPRTYTYP;
                    i.DtTerm = null;
                    i.Oipid = OIPID;
                    i.NbrPhoneAc = OIPObj.NBRPHONE.Substring(0, 3);
                    _context.Interpre.Add(i);
                    _context.SaveChanges();
                }

                return OIPID;
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        public int NewAgency(OIPDTO OIPObj)
        {
            Agency mappedObj = _mapper.Map<OIPDTO, Agency>(OIPObj);
            int OIPID;
            try
            {
                
                _context.Agency.Add(mappedObj);

                _context.SaveChanges();

                OIPID = mappedObj.Oipid;

                _context.Caseagny.Add(new Caseagny
                {
                    CdCase = OIPObj.CdCase,
                    Oipid = OIPID,
                    CdUpdtTechId = OIPObj.CDUPDTTECHID
                });

                _context.SaveChanges();

                if (OIPObj.CDPRTYTYP == "N")
                {
                    Interpre i = new Interpre();
                    i.CdLanguage = OIPObj.CDLANGUAGE;
                    i.CdPrtyTyp = OIPObj.CDPRTYTYP;
                    i.DtTerm = null;
                    i.Oipid = OIPID;
                    i.NbrPhoneAc = OIPObj.NBRPHONE.Substring(0, 3);
                    _context.Interpre.Add(i);
                    _context.SaveChanges();
                }

                return OIPID;
            }
            catch (Exception e)
            {
                return 0;
            }
        }


        public OIPDTO UpdateAgency(OIPDTO OIPObj)
        {
            Agency mappedObj = _mapper.Map<OIPDTO, Agency>(OIPObj);

            try
            {
                _context.Agency.Attach(mappedObj);

                var update = _context.Entry(mappedObj);
                update.State = EntityState.Modified;

                update.Property(e => e.DtUpdtTrans).IsModified = false;

                _context.SaveChanges();

                if (OIPObj.CDPRTYTYP == "N" && OIPObj.CDLANGUAGE != null)
                {
                    if (_context.Interpre.Count((i) => i.Oipid == OIPObj.OIPID && i.CdLanguage == OIPObj.CDLANGUAGE && i.CdPrtyTyp == OIPObj.CDPRTYTYP) == 0)
                    {
                        Interpre i = new Interpre();
                        i.CdLanguage = OIPObj.CDLANGUAGE;
                        i.CdPrtyTyp = OIPObj.CDPRTYTYP;
                        i.DtTerm = null;
                        i.Oipid = OIPObj.OIPID;
                        i.NbrPhoneAc = OIPObj.NBRPHONE.Substring(0, 3);
                        _context.Interpre.Add(i);
                        if (_context.SaveChanges() >= 0)
                        {
                            OIPObj.Error = false;
                        }
                        else
                        {
                            OIPObj.Error = true;
                        }
                    }
                    else
                    {
                        Entities.Interpre c = (from i in _context.Interpre
                                               where i.Oipid == OIPObj.OIPID && i.CdLanguage == OIPObj.CDLANGUAGE && i.CdPrtyTyp == OIPObj.CDPRTYTYP
                                               select i).First();
                        c.NbrPhoneAc = OIPObj.NBRPHONE.Substring(0, 3);
                        if (_context.SaveChanges() >= 0)
                        {
                            OIPObj.Error = false;
                        }
                        else
                        {
                            OIPObj.Error = true;
                        }
                    }
                }

                OIPObj.Error = false;
            }
            catch (Exception e)
            {
                OIPObj.Error = true;
            }

            return OIPObj;
        }


        public bool AssignOIPByCaseNumber(OIPDTO newOIP)
        {
            try
            {
                var exists = (from c in _context.Caseoip
                                where c.Oipid == newOIP.OIPID && c.CdCase == newOIP.CdCase
                                select c.CdCase).Count();

                if (exists == 0)
                {
                    _context.Caseoip.Add(new Caseoip
                    {
                        CdCase = newOIP.CdCase,
                        Oipid = newOIP.OIPID,
                        CdUpdtTechId = newOIP.CDUPDTTECHID
                    });

                    _context.SaveChanges();
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool AssignAgencyByCaseNumber(OIPDTO newOIP)
        {
            try
            {
               
                var exists = (from c in _context.Caseagny
                                where c.Oipid == newOIP.OIPID && c.CdCase == newOIP.CdCase
                                select c.CdCase).Count();

                if (exists == 0)
                {
                    _context.Caseagny.Add(new Caseagny
                    {
                        CdCase = newOIP.CdCase,
                        Oipid = newOIP.OIPID,
                        CdUpdtTechId = newOIP.CDUPDTTECHID
                    });

                    _context.SaveChanges();
                }
                else
                {
                    return false;
                }
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool RemoveAssignedOIPByCaseNumber(OIPDTO oipdto)
        {
            Caseoip mappedOIP = _mapper.Map<OIPDTO, Caseoip>(oipdto);
            try
            {
               
                _context.Caseoip.Attach(mappedOIP);
                _context.Caseoip.Remove(mappedOIP);
                _context.SaveChanges();
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool RemoveAssignedAgencyByCaseNumber(OIPDTO oipdto)
        {
            Caseagny mappedOIP = _mapper.Map<OIPDTO, Caseagny>(oipdto);
            try
            {
               
                _context.Caseagny.Attach(mappedOIP);
                _context.Caseagny.Remove(mappedOIP);
                _context.SaveChanges();
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public bool DeleteOIP(OIPCaseDTO oipdto)
        {

            try
            {
                if (oipdto.Type == "M")
                {
                    Interpre i = (from x in _context.Interpre
                                  where x.Oipid == oipdto.OIPID
                                  select x).FirstOrDefault();
                    _context.Remove(i);
                    if (_context.SaveChanges() >= 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

                if (!String.IsNullOrEmpty(oipdto.CaseNumber))
                {
                    Caseoip i = (from x in _context.Caseoip
                                 where x.Oipid == oipdto.OIPID && x.CdCase == oipdto.CaseNumber
                                 select x).First();

                    if (i != null)
                    {
                        _context.Remove(i);
                        _context.SaveChanges();
                    }
                }
                Caseoip c = (from ca in _context.Caseoip
                             where ca.Oipid == oipdto.OIPID
                             select ca).FirstOrDefault();
                if (c != null)
                {
                    Oippersn op = (from p in _context.Oippersn
                                   where p.Oipid == oipdto.OIPID
                                   select p).First();
                    op.DtTerm = DateTime.Now;
                    _context.SaveChanges();
                }
                else
                {
                    Oippersn op = (from p in _context.Oippersn
                                   where p.Oipid == oipdto.OIPID
                                   select p).First();
                    _context.Remove(op);
                    _context.SaveChanges();
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool DeleteAgency(OIPCaseDTO oipdto)
        {
            try
            {
                if (oipdto.Type == "N")
                {
                    Interpre i = (from x in _context.Interpre
                                  where x.Oipid == oipdto.OIPID
                                  select x).First();
                    _context.Remove(i);
                    if (_context.SaveChanges() >= 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                if (!String.IsNullOrEmpty(oipdto.CaseNumber))
                {
                    Caseagny i = (from x in _context.Caseagny
                                  where x.Oipid == oipdto.OIPID && x.CdCase == oipdto.CaseNumber
                                  select x).First();

                    if (i != null)
                    {
                        _context.Remove(i);
                        _context.SaveChanges();
                    }
                }
                Caseagny c = (from ca in _context.Caseagny
                              where ca.Oipid == oipdto.OIPID
                              select ca).FirstOrDefault();
                if (c != null)
                {
                    Agency op = (from p in _context.Agency
                                 where p.Oipid == oipdto.OIPID
                                 select p).First();
                    op.DtTerm = DateTime.Now;
                    _context.SaveChanges();
                }
                else
                {
                    Agency op = (from p in _context.Agency
                                 where p.Oipid == oipdto.OIPID
                                 select p).First();
                    _context.Remove(op);
                    _context.SaveChanges();
                }

                return true;
            }
            catch (Exception e)
            {

                return false;
            }
        
        }




        public ScheduledCasesDTO GetScheduledCases(string officeId, string sort)
        {
            ScheduledCasesDTO scheduledCases = new ScheduledCasesDTO();
           
            scheduledCases.results = new List<ScheduledCaseDTO>();

            if (String.IsNullOrEmpty(officeId))
            {
                return scheduledCases;
            }
            if (sort == "1")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cnt.DtCntctStrtTim, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "2")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby dso.NmeOff, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "3")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "4")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby emp.NmeSurnmePrsn, emp.NmeFrstPrsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "5")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby per.NmeSurnmePrsn, per.NmeFrstPrsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "6")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdRsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "7")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdHrngTyp, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }


            if (sort == "8")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby dso.CdOffAbbr, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            return scheduledCases;
        }
        public UnScheduledCasesDTO GetUnScheduledCases(string officeId, string sort)
        {
            UnScheduledCasesDTO UnscheduledCases = new UnScheduledCasesDTO();

            UnscheduledCases.results = new List<UnScheduledCaseDTO>();
           
            if (String.IsNullOrEmpty(officeId))
            {
                return UnscheduledCases;
            }
            if (sort == "1")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdCase, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "2")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.DtRcpt, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "3")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "4")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdFldDsoAlpha, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "5")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby per.NmeSurnmePrsn, per.NmeFrstPrsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = r.CdStatusRec,
                       // CD_STATUS_REC2 = r.CdStatusRec2,
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "6")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdRsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "7")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdHrngTyp, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }


            if (sort == "8")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.NbrDl, cse.DtRcpt, cse.CdRsn
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                //results.OrderBy(o => o.NbrDl).ThenBy(o => o.DtRcpt).ThenBy(o => o.CdRsn).ToList();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            return UnscheduledCases;
        }
       
        public CaseContactsDTO GetCaseContacts(string caseNumber)
        {
            CaseContactsDTO CaseContacts = new CaseContactsDTO();

            CaseContacts.results = new List<CaseContactDTO>();

            if (String.IsNullOrEmpty(caseNumber))
            {
                return CaseContacts;
            }

            var results = (from cnt in _context.Contact.AsNoTracking()
                           join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                           join off in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals off.CdOffId
                           where cnt.CdCase == caseNumber && Convert.ToInt16(cnt.CdStatus2) == 3 && off.DtTerm == null
                           select new
                           {
                               cnt.DtCntctStrtTim,
                               cnt.DtCntctEndTim,
                               off.NmeOff,
                               emp.NmeFrstPrsn,
                               emp.NmeSurnmePrsn,
                               cnt.DtSchedTrans,
                               cnt.CdStatus,
                               cnt.CdStatus2,
                               cnt.NbrRoom
                           }).AsQueryable();


            foreach (var r in results)
            {
                CaseContacts.results.Add(
                new CaseContactDTO()
                {
                    SCHEDBY_NME_FRST_PRSN = r.NmeFrstPrsn,
                    SCHEDBY_NME_SRNME_PRSN = r.NmeSurnmePrsn,
                    ScheduledBy = r.NmeFrstPrsn + " " + r.NmeSurnmePrsn,
                    dt_cntct_strt_tim = Convert.ToString(r.DtCntctStrtTim),
                    dt_cntct_end_tim = Convert.ToString(r.DtCntctEndTim),
                    ScheduledOn = r.DtCntctStrtTim.ToString("MM/dd/yyyy"),
                    StartTime = r.DtCntctStrtTim.ToString("hh:mm tt"),
                    EndTime = r.DtCntctEndTim.ToString("hh:mm tt"),
                    Nme_Off = r.NmeOff,
                    Location = r.NmeOff,
                    DT_SCHED_TRANS = Convert.ToString(r.DtSchedTrans),
                    ScheduledDate = r.DtSchedTrans.ToString("MM/dd/yyyy"),
                    Status = BusinessFunctions.GetCaseStatusText(r.CdStatus, r.CdStatus2),
                    ROOM = "Rm: " + r.NbrRoom
                });
            }

            return CaseContacts;
        }
        public EmployeeContactsDTO GetCaseEmployeeContacts(string caseNumber)
        {
            EmployeeContactsDTO EmployeeContacts = new EmployeeContactsDTO();

            EmployeeContacts.results = new List<EmployeeContactDTO>();

            if (String.IsNullOrEmpty(caseNumber))
            {
                return EmployeeContacts;
            }
            var results = (from cnt in _context.Contact.AsNoTracking()
                           join emp in _context.Employee.AsNoTracking() on cnt.CdUpdtTechId equals emp.CdEmpId
                           where cnt.CdCase == caseNumber && Convert.ToInt16(cnt.CdStatus2) == 3   
                           select new
                           {
                               emp.NmeFrstPrsn,
                               emp.NmeSurnmePrsn
                           }).AsQueryable();


            foreach (var r in results)
            {
                EmployeeContacts.results.Add(
                new EmployeeContactDTO
                {
                    NME_FRST_PRSN = r.NmeFrstPrsn,
                    NME_SURNME_PRSN = r.NmeSurnmePrsn,
                    HearingOfficer = r.NmeFrstPrsn.Trim() + " " + r.NmeSurnmePrsn.Trim()
                });
            }

            return EmployeeContacts;
        }
        public CaseRescheduleListDTO GetCaseReschedules(string caseNumber)
        {
            CaseRescheduleListDTO reschedules = new CaseRescheduleListDTO();

            reschedules.results = new List<CaseRescheduleDTO>();

            if (String.IsNullOrEmpty(caseNumber))
            {
                reschedules.ErrorMessage = "Case Number not entered";
                return reschedules;
            }

            var results = _context.LoadStoredProc("SelReschedList")
                             .WithSqlParam("Case", caseNumber)
                             .ExecuteStoredProc<CaseRescheduleDTO>();

            foreach (var r in results)
            {
                reschedules.results.Add(
                new CaseRescheduleDTO
                {
                   
                    ScheduleDate = r.ScheduleDate,
                    ScheduleTime = r.ScheduleTime,
                    Location = r.Location,
                    Comment = r.Comment,
                    HearingOfficer = r.HearingOfficer,
                    ScheduledBy = r.ScheduledBy,
                    AuthorizedBy = r.AuthorizedBy
                });
            }


            return reschedules;
        }
        public CaseCoverSheetDTO GetCaseCoverSheetInfo(string casenumber)
        {
            CaseCoverSheetDTO coversheet = new CaseCoverSheetDTO();

            var results = (from c in _context.Dsrcase.AsNoTracking()
                           join p in _context.Person.AsNoTracking() on c.NbrDl equals p.NbrDl
                           where c.CdCase == casenumber 
                           select new
                           {
                               p.NbrDl,
                               p.DtBirthPrsn,
                               p.NmeSurnmePrsn,
                               p.NbrPhone
                           }).SingleOrDefault();
            coversheet.DLNumber = results.NbrDl;
            coversheet.BirthDate = Convert.ToDateTime(results.DtBirthPrsn);
            coversheet.LastName = results.NmeSurnmePrsn;
            coversheet.PhoneNumber = results.NbrPhone;

            CoverSheetOIPPersonListDTO oippersons = new CoverSheetOIPPersonListDTO();
            oippersons.results = new List<CoverSheetOIPPersonDTO>();

            var oip = (from co in _context.Caseoip.AsNoTracking()
                       join op in _context.Oippersn.AsNoTracking() on co.Oipid equals op.Oipid
                       where co.CdCase == casenumber
                       select new
                       {
                           op.CdPrtyTyp,
                           op.NbrPhone,
                           op.NmeFrstPrsn,
                           op.NmeSurnmePrsn,
                           op.NmeAgency,
                           op.AddrLn1,
                           op.CdCity,
                           op.CdState,
                           op.CdZip
                       }).AsQueryable();

            foreach (var r in oip)
            {
                oippersons.results.Add(
                    new CoverSheetOIPPersonDTO        
                    {
                        OIP_CD_PRTY_TYP = r.CdPrtyTyp,
                        OIP_NBR_PHONE = r.NbrPhone,
                        OIP_NME_FRST_PRSN = r.NmeFrstPrsn,
                        OIP_NME_SURNME_PRSN = r.NmeSurnmePrsn,
                        OIP_ADDR_LN1 = r.AddrLn1,
                        OIP_CITY = r.CdCity,
                        OIP_STATE = r.CdState,
                        OIP_ZIP = r.CdZip
                     });
            }
            coversheet.OIPPersons = oippersons;

            CoverSheetOIPAgencyListDTO oipagencies = new CoverSheetOIPAgencyListDTO();
            oipagencies.results = new List<CoverSheetOIPAgencyDTO>();

            var ag = (from ca in _context.Caseagny.AsNoTracking()
                       join a in _context.Agency.AsNoTracking() on ca.Oipid equals a.Oipid
                       where ca.CdCase == casenumber
                       select new
                       {
                           a.CdPrtyTyp,
                           a.NbrPhone,
                           ca.NmeSurnmePrsn,
                           a.NmeAgency,
                           a.AddrLn1,
                           a.CdCity,
                           a.CdState,
                           a.CdZip
                       }).AsQueryable();

            foreach (var i in ag)
            {
                oipagencies.results.Add(
                    new CoverSheetOIPAgencyDTO
                    {
                        AGENCY_CD_PRTY_TYP = i.CdPrtyTyp,
                        AGENCY_NBR_PHONE = i.NbrPhone,
                        AGENCY_NME_SURNME_PRSN = i.NmeSurnmePrsn,
                        AGENCY_NME_FRST_PRSN = i.NmeAgency,
                        AGENCY_ADDR_LN1 = i.AddrLn1,
                        AGENCY_CITY = i.CdCity,
                        AGENCY_STATE = i.CdState,
                        AGENCY_ZIP = i.CdZip
                    });
            }
            coversheet.OIPAgencies = oipagencies;

            CoverSheetContactListDTO contacts = new CoverSheetContactListDTO();
            contacts.results = new List<CoverSheetContactDTO>();

            var cnt = (from con in _context.Contact.AsNoTracking()
                      join dso in _context.Dsoffice.AsNoTracking() on con.CdOffId equals dso.CdOffId
                      join cse in _context.Dsrcase.AsNoTracking() on con.CdCase equals cse.CdCase 
                      where cse.CdCase == casenumber && dso.DtTerm == null
                      orderby con.DtCntctStrtTim
                      select new
                      {
                          con.DtCntctStrtTim,
                          cse.CdHrngTyp,
                          cse.CdRsn,
                          con.CdEmpId,
                          dso.CdOffAbbr,
                          con.NbrRoom,
                          con.CdSchedTechId,
                          con.DtSchedTrans,
                          cse.CdRefrSrceTyp,
                          con.TxtComment,
                          con.CdAuthId
                      }).AsQueryable();

            foreach (var i in cnt)
            {
                contacts.results.Add(
                    new CoverSheetContactDTO
                    {
                        dt_cntct_strt_tim = i.DtCntctStrtTim,
                        CD_HRNG_TYP = i.CdHrngTyp,
                        CD_RSN = i.CdRsn,
                        CD_EMP_ID = i.CdEmpId,
                        CD_OFF_ABBR = i.CdOffAbbr,
                        NBR_ROOM = i.NbrRoom,
                        CD_REFR_SRCE_TYP = i.CdRefrSrceTyp,
                        Comment = i.TxtComment,
                        CD_AUTH_ID = i.CdAuthId
                    });
            }
            coversheet.Contacts = contacts;

            CoverSheetCommentListDTO comments = new CoverSheetCommentListDTO();
            comments.results = new List<CoverSheetCommentDTO>();

            var cm = (from com in _context.Dsrcomm.AsNoTracking()
                       where com.CdCase == casenumber 
                       orderby com.DtUpdtTrans
                       select new
                       {
                          com.DtUpdtTrans,
                          com.CdUpdtTechId,
                          com.CdFldDsoAlpha,
                          com.TxtComm
                       }).AsQueryable();

            foreach (var i in cm)
            {
                comments.results.Add(
                    new CoverSheetCommentDTO
                    {
                       DT_UPDT_TRANS = i.DtUpdtTrans,
                       CD_UPDT_TECH_ID = i.CdUpdtTechId,
                       CD_FLD_DSO_ALPHA = i.CdFldDsoAlpha,
                       TXT_COMMENT = i.TxtComm
                    });
            }
            coversheet.Comments = comments;



            return coversheet;
        }
        public ClosedCaseConvertDetailDTO GetClosedCaseDetail(string casenumber)
        {
            ClosedCaseConvertDetailDTO closeCaseDetail = new ClosedCaseConvertDetailDTO();

            if (String.IsNullOrEmpty(casenumber))
            {
               return closeCaseDetail;
            }

            var results = _context.LoadStoredProc("cc_selClosedCaseData")
                             .WithSqlParam("CaseNumber", casenumber)
                             .ExecuteStoredProc<ClosedCaseDetailDTO>();
          
            foreach (var r in results)
            {
                closeCaseDetail.DlNumber = r.NBR_DL;
                closeCaseDetail.CaseNumber = casenumber;
                closeCaseDetail.SubjectName = r.SUBJECT_FIRST_NAME.Trim() + " " + r.SUBJECT_LAST_NAME.Trim();
                closeCaseDetail.Type = r.CD_HRNG_TYP;
                closeCaseDetail.HearingDate = r.DT_SCHED_HRNG.ToString("MM-dd-yyyy");
                if (r.FLG_HEARING == "1")                  
                {
                    closeCaseDetail.Location = r.CD_FLD_DSO_ALPHA.Trim();
                }
                else
                {
                    closeCaseDetail.Location = r.CD_OFF_ABBR;
                }
                closeCaseDetail.Reason = r.CD_RSN;
                closeCaseDetail.ScheduledResults = r.CD_SCHED_RSL;
                closeCaseDetail.TypeAction = r.CD_TYP_ACT;
                if (r.DT_MOD_SCHED_HR == DateTime.MinValue) 
                {
                    closeCaseDetail.ModifiedDate = null;
                }
                else
                {
                    closeCaseDetail.ModifiedDate = r.DT_MOD_SCHED_HR.ToString("MM-dd-yyyy");
                }
                closeCaseDetail.AuthoritySection1 = r.CD_VEH_AUTH1;
                closeCaseDetail.AuthoritySection2 = r.CD_VEH_AUTH2;
                closeCaseDetail.AuthoritySection3 = r.CD_VEH_AUTH3;
                if (r.DT_TYP_ACT_MOD == DateTime.MinValue)
                {
                    closeCaseDetail.EffectiveDate = null;
                }
                else
                {
                    closeCaseDetail.EffectiveDate = r.DT_TYP_ACT_MOD.ToString("MM-dd-yyyy");
                }

                if (r.DT_TYP_ACT_END == DateTime.MinValue)
                {
                    closeCaseDetail.ThroughDate = null;
                }
                else
                {
                    closeCaseDetail.ThroughDate = r.DT_TYP_ACT_END.ToString("MM-dd-yyyy");
                }

                if (r.DT_TYP_ACT_TERM == DateTime.MinValue)
                {
                    closeCaseDetail.ActionTermDate = null;
                }
                else
                {
                    closeCaseDetail.ActionTermDate = r.DT_TYP_ACT_TERM.ToString("MM-dd-yyyy");
                }

                if (r.DT_MAIL == DateTime.MinValue)
                {
                    closeCaseDetail.MailDate = null;
                }
                else
                {
                    closeCaseDetail.MailDate = r.DT_MAIL.ToString("MM-dd-yyyy");
                }

                closeCaseDetail.OriginalAuthoritySection = r.CD_VEH_AUTH_ORIG;

                if (r.DT_TYP_ACT_EFF == DateTime.MinValue)
                {
                    closeCaseDetail.OriginalEffectiveDate = null;
                }
                else
                {
                    closeCaseDetail.OriginalEffectiveDate = r.DT_TYP_ACT_EFF.ToString("MM-dd-yyyy");
                }

                if (r.SCHEDULED_EMPLOYEE_FIRST_NAME == null & r.SCHEDULED_EMPLOYEE_LAST_NAME == null)
                {
                    closeCaseDetail.ScheduledTo = null;
                }
                else
                {
                    closeCaseDetail.ScheduledTo = r.CD_EMP_ID + " - " + r.SCHEDULED_EMPLOYEE_FIRST_NAME.Trim() + " " + r.SCHEDULED_EMPLOYEE_LAST_NAME.Trim();
                }

                if (r.CLOSED_EMPLOYEE_FIRST_NAME == null & r.CLOSED_EMPLOYEE_LAST_NAME == null)
                {
                    closeCaseDetail.ClosedBy = null;
                }
                else
                {
                    if ((r.CLOSED_EMPLOYEE_FIRST_NAME.Trim() + r.CLOSED_EMPLOYEE_LAST_NAME.Trim()).Length > 0)
                    {
                        closeCaseDetail.ClosedBy = r.CD_CASE_CLSE_ID + " - " + r.CLOSED_EMPLOYEE_FIRST_NAME.Trim() + " " + r.CLOSED_EMPLOYEE_LAST_NAME.Trim();
                    }
                    else
                    {
                        closeCaseDetail.ClosedBy = r.CD_CASE_CLSE_ID;
                    }
                }
                
                closeCaseDetail.DateUpdated = r.DT_DL_UPDATE.ToString("MM-dd-yyyy");

                if (r.UPDATED_EMPLOYEE_FIRST_NAME == null & r.UPDATED_EMPLOYEE_LAST_NAME == null)
                {
                    closeCaseDetail.UpdatedBy = r.CD_DL_UPDATE_ID;
                }
                else
                {
                    closeCaseDetail.UpdatedBy = r.CD_DL_UPDATE_ID + " - " + r.UPDATED_EMPLOYEE_FIRST_NAME.Trim() + " " + r.UPDATED_EMPLOYEE_LAST_NAME.Trim();
                }

                closeCaseDetail.DateClosed = r.DT_CASE_CLSE.ToString("MM-dd-yyyy");
            }

            return closeCaseDetail;

        }
        public SuspenseCasesDTO GetSuspenseCases(string casenumber)
        {

            SuspenseCasesDTO SuspenseCases = new SuspenseCasesDTO();

            SuspenseCases.results = new List<SuspenseCaseDTO>();

            if (String.IsNullOrEmpty(casenumber))
            {
                return SuspenseCases;
            }
            var results = _context.LoadStoredProc("selSuspense")
                          .WithSqlParam("case", casenumber)
                          .ExecuteStoredProc<SuspenseCaseDTO>();

            foreach (var r in results)
            {
                SuspenseCases.results.Add(
                new SuspenseCaseDTO()
                {
                    Suspense_ID = r.Suspense_ID,
                    CD_CASE = r.CD_CASE,
                    NBR_SEQUENCE = r.NBR_SEQUENCE,
                    SuspenseDate = r.SuspenseDate,
                    RequestedBy = r.RequestedBy,
                    SuspenseReason = r.SuspenseReason,
                    UpdatedBy = r.UpdatedBy,
                    UpdateDate = r.UpdateDate,
                    SuspenseDescription =  r.SuspenseDescription
                });
            }
            return SuspenseCases;

        }
        public SuspenseCaseEmployeeDTO GetSuspenseEmployee(string casenumber)
        {
            var per = (from cse in _context.Dsrcase.AsNoTracking()
                       join p in _context.Person.AsNoTracking() on cse.NbrDl equals p.NbrDl
                       where cse.CdCase == casenumber
                       select new
                       {
                           p.NbrDl,
                           p.NmeFrstPrsn,
                           p.NmeMidPrsn,
                           p.NmeSurnmePrsn
                       }).First();
            SuspenseCaseEmployeeDTO emp = new SuspenseCaseEmployeeDTO();
            emp.CD_CASE = casenumber;
            emp.DLNumber = per.NbrDl;
            emp.SubjectName = per.NmeFrstPrsn.Trim() + " " + per.NmeMidPrsn.Trim() + " " + per.NmeSurnmePrsn.Trim();
            return emp; 
        }
        public IEnumerable<SelectListItem> GetSuspenseReasons()
        {
            var SuspenseReasons = (from h in _context.SuspRsn
                                orderby h.CdSuspRsn
                                where h.DtTerm > DateTime.Now  || h.DtTerm == null
                                select new SelectListItem()
                                {
                                    Text = h.CdSuspRsn + " - " + h.DescSuspRsn,
                                    Value = h.CdSuspRsn
                                }).ToList();

            SuspenseReasons.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });

            return SuspenseReasons;
        }
        public SuspenseCaseAddDTO AddCaseSuspense(SuspenseCaseAddDTO suspense)
        {
            //var c  = (from s in _context.CaseSuspense.AsNoTracking()
            //           where s.CdCase == suspense.CD_CASE
            //           orderby s.NbrSequence ascending
            //           select new
            //           {
            //               s.NbrSequence
            //           }).Last();
            //var newSequence = c.NbrSequence + 1;

            CaseSuspense newSuspense = new CaseSuspense();
            newSuspense.CdCase = suspense.CD_CASE;
            newSuspense.NbrSequence = 0;
            newSuspense.DtSusp = suspense.SuspenseDate;
            newSuspense.CdSuspReqBy = suspense.RequestedBy;
            newSuspense.CdSuspRsn = suspense.SuspenseReason;
            newSuspense.TxtSusp = suspense.SuspenseDescription;
            newSuspense.CdUpdtTechId = suspense.UpdatedBy;
            newSuspense.DtUpdtTrans = DateTime.Now;
            _context.CaseSuspense.Add(newSuspense);
            if (_context.SaveChanges() >= 0)
            {
                suspense.Message = "Case Suspense Added";
                suspense.ErrorMessage = "";
            }
            else
            {
                suspense.ErrorMessage = "Case Suspense Add Failed";
            }
            return suspense;
          
        }

        public SuspenseCaseModifyDTO ModifyCaseSuspense(SuspenseCaseModifyDTO suspense)
        {
            Entities.CaseSuspense c = (from x in _context.CaseSuspense
                                  where x.SuspenseId == suspense.SuspenseID
                                  select x).First();
            c.DtSusp = suspense.SuspenseDate;
            c.CdSuspReqBy = suspense.RequestedBy;
            c.CdSuspRsn = suspense.SuspenseReason;
            c.TxtSusp = suspense.SuspenseDescription;
            c.DtUpdtTrans = DateTime.Now;
            c.CdUpdtTechId = suspense.UpdatedBy;
            if (_context.SaveChanges() >= 0)
            {
                suspense.Message = "Case Suspense Modified";
                suspense.ErrorMessage = "";
            }
            else
            {
                suspense.ErrorMessage = "Case Suspense Add Failed";
            }
            return suspense;
        }
        public bool DeleteCaseSuspense(int suspenseId)
        {
            Entities.CaseSuspense c = (from x in _context.CaseSuspense
                                       where x.SuspenseId == suspenseId
                                       select x).First();

            _context.Remove(c);
            if (_context.SaveChanges() >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool TestForEmployeeExistence(string EmpId, string OfficeId)
        {
            
            if (_context.Employee.Count((e)=>e.CdEmpId== EmpId && e.CdOffId == OfficeId) ==0)
            {
                return false;
            }
            else
            {
                return true;
            }
            
        }

        public HearingReasonCodesDTO GetCaseHearingTypeReasonCode( string casenumber)
        {
            //var codes = new HearingReasonCodesDTO();
            //if (String.IsNullOrEmpty(casenumber))
            //{
            //    codes.Message = "No Case Number passed";
            //    return codes;
            //}
            var result = _context.Dsrcase.AsNoTracking()
                       .Where(c => c.CdCase == casenumber)
                       .Select(c => new HearingReasonCodesDTO()
                       {
                           HearingType = c.CdHrngTyp,
                           ReasonCode = c.CdRsn,
                           OrigHearingDate = Convert.ToDateTime(c.DtSchedHrng)
                       }).ToList().FirstOrDefault();
            return result;
        }

        public bool UpdateCaseDetails(CaseDetailDTO caseDetail, string techID)
        {
            Entities.Dsrcase c = (from x in _context.Dsrcase
                         where x.CdCase == caseDetail.CaseNumber
                         select x).First();
            c.CdCityAcc = caseDetail.AccidentCity;
            c.CdEndr = caseDetail.CD_ENDR;
            c.CdRefrSrceTyp = caseDetail.CD_REFR_SRCE_TYP;
            c.CdRsn = caseDetail.CD_RSN;
            c.CdUpdtTechId = techID;
            if (caseDetail.FRCaseNumber == null)
                caseDetail.FRCaseNumber = "";
            if (caseDetail.FRCaseNumber.Trim() != "")
                c.DtAcc = caseDetail.AccidentDate;
            //if (caseDetail.FRCaseNumber != null  & caseDetail.FRCaseNumber.Trim() != "")
            //    c.DtAcc = caseDetail.AccidentDate;
            c.DtUpdtTrans = DateTime.Now;
            c.NbrCaseAccFr = caseDetail.FRCaseNumber;
            c.NbrDl = caseDetail.DLNumber;
            c.CdHrngTyp = caseDetail.CD_HRNG_TYP;

            return (_context.SaveChanges() >= 0);

        }
        public bool AddCase(CaseDetailForAddDTO caseDetail, UserDTO user)
        {
            DSA_API.Entities.Dsrcase newCase = new DSA_API.Entities.Dsrcase();
            var caseNumber = GetNewCaseNumber(user.OfficeID, user.Office.CdOffAbbr);
            newCase.CdCase = caseNumber;
            caseDetail.CaseNumber = caseNumber;
            newCase.CdEndr = caseDetail.CD_ENDR;
            newCase.CdFldDsoAlpha = user.Office.CdOffAbbr;
            newCase.CdOrigTechId = user.EmployeeThreeDigit;
            newCase.DtUpdtTrans = DateTime.Now;
            newCase.CdOrigTechId = user.EmployeeThreeDigit;
            newCase.CdUpdtTechId = user.EmployeeThreeDigit;
            newCase.CdRefrSrceTyp = caseDetail.CD_REFR_SRCE_TYP;
            newCase.CdRsn = caseDetail.CD_RSN;
            newCase.DtOrigTrans = DateTime.Now;
            newCase.CdHrngTyp = caseDetail.CD_HRNG_TYP;
            newCase.DtRcpt = DateTime.Now;
            newCase.NbrCaseAccFr = caseDetail.FRCaseNumber;
            newCase.CdCityAcc = caseDetail.AccidentCity;
            if (caseDetail.FRCaseNumber != null)
                newCase.DtAcc = caseDetail.AccidentDate;
            newCase.NbrDl = caseDetail.DLNumber;
            newCase.CdStatusRec = "1";
            newCase.CdStatusRec2 = "0";
            _context.Dsrcase.Add(newCase);
            return (_context.SaveChanges() >= 0);
        }
       public string GetNewCaseNumber(string officeid, string officeAbrev)
        {
            var newcaseid = "";
            var newSeq = 0;

            var myDate = DateTime.Now;
            var julian = string.Format("{0:yy}{1:D3}", myDate, myDate.DayOfYear);

            Entities.Casecntl c = (from x in _context.Casecntl
                                  where x.CdOffId == officeid
                                  select x).First();
            if (c.LastUpdate < DateTime.Now.Date  || c.LastUpdate == null)
            {
                newSeq = 1;
                c.LastUpdate = DateTime.Now.Date;
                c.NbrSeq = Convert.ToInt16(newSeq);
                _context.SaveChanges();
            }
            else
            {
                newSeq = c.NbrSeq + 1;
                c.NbrSeq = Convert.ToInt16(newSeq);
                _context.SaveChanges();
            }

            var tempNum = Convert.ToString(newSeq);

            switch(tempNum.Length)
            {
                case 1:
                    tempNum = "000" + tempNum;
                    break;
                case 2:
                    tempNum = "00" + tempNum;
                    break;
                case 3:
                    tempNum = "0" + tempNum;
                    break;
                case 4:
                    break;
            }
            return newcaseid = officeAbrev + julian + tempNum;
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }
       
    }

}



