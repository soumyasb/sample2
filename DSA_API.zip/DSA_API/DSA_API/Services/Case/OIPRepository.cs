﻿using DSA_API.Entities;
using DSA_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class OIPRepository : IOIPRepository
    {
        private DSAContext _context;
        private IUrlHelper _urlHelper;
        public OIPRepository(DSAContext context, IUrlHelper urlHelper)
        {
            _context = context;
            _urlHelper = urlHelper;
        }
        public IEnumerable<OIPDTO> OIPPersonSearchByType(OIPDTO oipdto, string caseNumber)
        {
            string AreaCode = "";
            List<OIPDTO> finalList = new List<OIPDTO>();

            if (!String.IsNullOrEmpty(oipdto.NBRPHONE))
            {
                AreaCode = oipdto.NBRPHONE.Substring(0, 3).ToString();
            }

            try
            {
                //  Get's list of OIPID's assigned to case
                var minusQuery = (from c in _context.Caseoip.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();

                //  Get's List of 
                var query = (from o in _context.Oippersn.AsNoTracking()
                                where o.CdPrtyTyp == oipdto.CDPRTYTYP && !o.DtTerm.HasValue
                                && (
                                    (
                                    (String.IsNullOrEmpty(oipdto.NMEFRSTPRSN) || o.NmeFrstPrsn.StartsWith(oipdto.NMEFRSTPRSN))
                                    && (String.IsNullOrEmpty(oipdto.NMESURNMEPRSN) || o.NmeSurnmePrsn.StartsWith(oipdto.NMESURNMEPRSN))
                                    )
                                    && (String.IsNullOrEmpty(oipdto.NBRPHONE) || (
                                        (o.NbrPhone.Substring(0, 3) == AreaCode && o.NbrPhone != "")
                                        || (o.NbrCellPhone.Substring(0, 3) == AreaCode && o.NbrCellPhone != "")
                                        || (o.NbrFax.Substring(0, 3) == AreaCode && o.NbrFax != "")
                                    )
                                    )
                                )

                                select new OIPDTO()
                                {
                                    OIPID = o.Oipid,
                                    CDPRTYTYP = o.CdPrtyTyp,
                                    NMEFRSTPRSN = o.NmeFrstPrsn,
                                    NMESURNMEPRSN = o.NmeSurnmePrsn,
                                    NBRPHONE = o.NbrPhone,
                                    NBRCELLPHONE = o.NbrCellPhone,
                                    NBRFAX = o.NbrFax,
                                    ADDRLN1 = o.AddrLn1,
                                    CDCITY = o.CdCity,
                                    CDSTATE = o.CdState,
                                    CDZIP = o.CdZip,
                                    NMEAGENCY = o.NmeAgency
                                }).Distinct().ToList();

                for (int i = 0; i < query.Count; i++)
                {
                    if (!minusQuery.Contains(query[i].OIPID))
                    {
                        finalList.Add(query[i]);
                    }
                }

                foreach (OIPDTO dto in finalList)
                {
                    dto.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = dto.OIPID, type = dto.CDPRTYTYP });
                    dto.caseAssignURI = _urlHelper.RouteUrl("OIPCaseAssign", new { oipid = dto.OIPID, casenumber = caseNumber, type = dto.CDPRTYTYP });
                }
                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }
        }


        public IEnumerable<OIPDTO> LawEnforcementAgencySearch(OIPDTO oipdto, string caseNumber)
        {
            List<OIPDTO> finalList = new List<OIPDTO>();

            try
            {
                var minusQuery = (from c in _context.Caseagny.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();


                var agencies = (from a in _context.Agency
                                where a.CdPrtyTyp == oipdto.CDPRTYTYP
                                && a.NmeAgency.Contains(oipdto.NMEAGENCY)
                                && !a.DtTerm.HasValue
                                select new OIPDTO()
                                {
                                    OIPID = a.Oipid,
                                    CDPRTYTYP = a.CdPrtyTyp,
                                    NBRPHONE = a.NbrPhone,
                                    ADDRLN1 = a.AddrLn1,
                                    CDCITY = a.CdCity,
                                    CDSTATE = a.CdState,
                                    CDZIP = a.CdZip,
                                    NMEAGENCY = a.NmeAgency
                                }).Distinct().ToList();

                for (int i = 0; i < agencies.Count; i++)
                {
                    if (!minusQuery.Contains(agencies[i].OIPID))
                    {
                        finalList.Add(agencies[i]);
                    }
                }

                foreach (OIPDTO dto in finalList)
                {
                    dto.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = dto.OIPID, type = dto.CDPRTYTYP });
                    dto.caseAssignURI = _urlHelper.RouteUrl("OIPCaseAssign", new { oipid = dto.OIPID, casenumber = caseNumber, type = dto.CDPRTYTYP });
                }
                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }

        }


        public IEnumerable<OIPDTO> InterpreterAgencySearch(OIPDTO oipdto, string caseNumber)
        {
            List<OIPDTO> finalList = new List<OIPDTO>();

            try
            {
                var minusQuery = (from c in _context.Caseagny.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();

                var agencies = (from a in _context.Agency
                                join i in _context.Interpre on a.Oipid equals i.Oipid
                                where a.CdPrtyTyp == oipdto.CDPRTYTYP
                                && i.CdLanguage == oipdto.CDLANGUAGE
                                && !a.DtTerm.HasValue
                                select new OIPDTO()
                                {
                                    OIPID = a.Oipid,
                                    CDPRTYTYP = a.CdPrtyTyp,
                                    NBRPHONE = a.NbrPhone,
                                    ADDRLN1 = a.AddrLn1,
                                    CDCITY = a.CdCity,
                                    CDSTATE = a.CdState,
                                    CDZIP = a.CdZip,
                                    NMEAGENCY = a.NmeAgency
                                }).Distinct().ToList();

                for (int i = 0; i < agencies.Count; i++)
                {
                    if (!minusQuery.Contains(agencies[i].OIPID))
                    {
                        finalList.Add(agencies[i]);
                    }
                }

                foreach (OIPDTO dto in finalList)
                {
                    dto.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = dto.OIPID, type = dto.CDPRTYTYP });
                    dto.caseAssignURI = _urlHelper.RouteUrl("OIPCaseAssign", new { oipid = dto.OIPID, casenumber = caseNumber, type = dto.CDPRTYTYP });
                }
                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }

        }


        public IEnumerable<OIPDTO> InterpreterOIPPersonSearch(OIPDTO oipdto, string caseNumber)
        {
            List<OIPDTO> finalList = new List<OIPDTO>();

            try
            {
                //  Get's list of OIPID's assigned to case
                var minusQuery = (from c in _context.Caseoip.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();

                var OIPS = (from p in _context.Oippersn
                            join i in _context.Interpre on p.Oipid equals i.Oipid
                            where p.CdPrtyTyp == oipdto.CDPRTYTYP
                            && i.CdLanguage == oipdto.CDLANGUAGE
                            && !i.DtTerm.HasValue

                            select new OIPDTO()
                            {
                                OIPID = p.Oipid,
                                CDPRTYTYP = p.CdPrtyTyp,
                                NMEFRSTPRSN = p.NmeFrstPrsn,
                                NMESURNMEPRSN = p.NmeSurnmePrsn,
                                NBRPHONE = p.NbrPhone,
                                NBRCELLPHONE = p.NbrCellPhone,
                                NBRFAX = p.NbrFax,
                                ADDRLN1 = p.AddrLn1,
                                CDCITY = p.CdCity,
                                CDSTATE = p.CdState,
                                CDZIP = p.CdZip,
                                NMEAGENCY = p.NmeAgency
                            }).Distinct().ToList();

                for (int i = 0; i < OIPS.Count; i++)
                {
                    if (!minusQuery.Contains(OIPS[i].OIPID))
                    {
                        finalList.Add(OIPS[i]);
                    }
                }

                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }
        }


        //
        //  Get's All OIP Types into Select List (UI Utility)
        //
        public IEnumerable<SelectListItem> getOIPTypes()
        {
           
            var types = (from o in _context.Oiptype
                            where !o.DtTerm.HasValue
                            orderby o.CdPrtyTyp ascending
                            select new SelectListItem()
                            {
                                Text = o.CdPrtyTyp + " - " + o.DescPrtyTyp,
                                Value = o.CdPrtyTyp.ToString()
                            }).ToList();
            types.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return types;
            
        }


        //
        //  Get's All Interpreter Languages into Select List (UI Utility)
        //
        public IEnumerable<SelectListItem> getLanguages()
        {
            var types = (from l in _context.Language
                            where !l.DtTerm.HasValue
                            orderby l.DescLanguage ascending
                            select new SelectListItem()
                            {
                                Text = l.DescLanguage,
                                Value = l.CdLanguage.ToString()
                            }).ToList();
            types.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return types;
        }
        public List<LanguageDTO> GetOIPLanguages(string type, int oipid, out int count)
        {
            List<LanguageDTO> languages = new List<LanguageDTO>();
            if (type == "M")
            {
                languages = (from l in _context.Language.AsNoTracking()
                             join i in _context.Interpre.AsNoTracking() on l.CdLanguage equals i.CdLanguage
                             join o in _context.Oippersn.AsNoTracking() on i.Oipid equals o.Oipid
                             where o.Oipid == oipid
                             select new LanguageDTO()
                             {
                                 CDLanguage = l.CdLanguage,
                                 LanguageDescription = l.DescLanguage
                             }).ToList();
            }
            if (type == "N")
            {
                languages = (from l in _context.Language.AsNoTracking()
                             join i in _context.Interpre.AsNoTracking() on l.CdLanguage equals i.CdLanguage
                             join o in _context.Agency.AsNoTracking() on i.Oipid equals o.Oipid
                             where o.Oipid == oipid
                             select new LanguageDTO()
                             {
                                 CDLanguage = l.CdLanguage,
                                 LanguageDescription = l.DescLanguage
                             }).ToList();
            }
            count = languages.Count;
            return languages;

        }

    }
}
