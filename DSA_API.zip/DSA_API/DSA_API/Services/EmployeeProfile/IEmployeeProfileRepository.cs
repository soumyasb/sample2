﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Models.EmployeeProfile;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.EmployeeProfile
{
    public interface IEmployeeProfileRepository
    {
        IEnumerable<EmployeeProfileDTO> GetAllProfiles(int EmpID);
        EmployeeProfileDTO GetProfile(int ID);
        IEnumerable<EmployeeProfileDayDTO> GetAllProfileDays(int ProfileId);
        IEnumerable<EmployeeProfileDayDTO> GetDefultProfileDays();
        Profile1 ConvertProfile(EmployeeProfileDTO employeeProfile);
        Profileday ConvertProfileDay(EmployeeProfileDayDTO profileDay);
        Profileday GetEmptyDay(int dayofweek);
        EmployeeProfileDayDTO GetDefultModFriDay(int dayofweek);
        IList<ConflictDTO> GetAllConflicts(int EmpId, DateTime ProfileStart, DateTime? ProfileEnd);
        IEnumerable<SelectListItem> GetClassList();
        IEnumerable<SelectListItem> GetOfficeList();
        IEnumerable<SelectListItem> GetDistrictOfficeList(string OfficeID);
        IEnumerable<SelectListItem> GetClassificationList();
        IEnumerable<EmployeeDTO> GetAllDistrictProfileEmployees(string OfficeID);

    }
}
