﻿using DSA_API.Entities;
using DSA_API.Models.EmployeeProfile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DSA_API.Models.DataManager;
using DSA_API.Models;

namespace DSA_API.Services.EmployeeProfile
{
    public class EmployeeProfileRepository : IEmployeeProfileRepository
    {
        private DSAContext _context;
        public EmployeeProfileRepository(DSAContext context)
        {
            _context = context;
            
        }
        public IEnumerable<EmployeeProfileDTO> GetAllProfiles(int EmpID)
        {
            var profileList = _context.Profile1.AsNoTracking()
                               .Where(p => p.EmpId == EmpID)
                               .Select(p => new EmployeeProfileDTO()
                               {
                                   ProfileId = p.ProfileId,
                                   EmpID = p.EmpId,
                                   OfficeID = p.CdOffId,
                                   EffectiveStartDate = p.DtEffStrt,
                                   EffectiveEndDate = p.DtEffEnd,
                                   WorkWeekType = p.CdWrkWkTyp,
                                   UpdatedByID = p.CdUpdtTechId,
                                   UpdatedDay = p.DtUpdtTrans
                                   

                               }).ToList();
            return profileList;

        }
        public EmployeeProfileDTO GetProfile(int ID)
        {
            var profileList = _context.Profile1.AsNoTracking()
                               .Where(p => p.ProfileId == ID)
                               .Select(p => new EmployeeProfileDTO()
                               {
                                   ProfileId = p.ProfileId,
                                   EmpID = p.EmpId,
                                   OfficeID = p.CdOffId,
                                   EffectiveStartDate = p.DtEffStrt,
                                   EffectiveEndDate = p.DtEffEnd,
                                   WorkWeekType = p.CdWrkWkTyp,
                                   UpdatedByID = p.CdUpdtTechId,
                                   UpdatedDay = p.DtUpdtTrans
                                   
                               }).ToList().FirstOrDefault();
            return profileList;
        }

        public IEnumerable<EmployeeProfileDayDTO> GetAllProfileDays(int ProfileId)
        {
            DateTime defultDate = new DateTime(1900, 01, 01);

            var profileDays = _context.Profileday.AsNoTracking()
                               .Where(p => p.ProfileId == ProfileId)
                               .Select(p => new EmployeeProfileDayDTO()
                               {
                                   ID = p.ProfileDayId,
                                   ProfileID = p.ProfileId,
                                   DayCount = p.DayOfWkMonth,
                                   DayStart = p.TmeWrkStrt,
                                   DayEnd = p.TmeWrkEnd,
                                   AMBreakStart = p.TmeAmBrkStrt,
                                   AMBreakEnd = p.TmeAmBrkEnd,
                                   LunchBreakStart = p.TmeLchBrkStrt,
                                   LunchBreakEnd = p.TmeLchBrkEnd,
                                   PMBreakStart = p.TmePmBrkStrt,
                                   PMBreakEnd = p.TmePmBrkEnd,
                                   IsAlternitiveDay = (p.FlgAlt == "1") ? true : false,
                                   IsTelecomuteDay = (p.FlgTelc == "1") ? true : false,
                                   TravelFromStart = p.TrvlTmeFroStrt,
                                   TravelFromEnd = p.TrvlTmeFroEnd,
                                   TravelToStart = p.TrvlTmeToStrt,
                                   TravelToEnd = p.TrvlTmeToEnd,
                                   
                                   DayActive = (p.TmeWrkStrt == defultDate && p.TmeWrkEnd == defultDate) ? false : true
                               }).ToList();

            return profileDays;
        }

        public IEnumerable<EmployeeProfileDayDTO> GetDefultProfileDays()
        {

            var pList = new List<EmployeeProfileDayDTO>();

            pList.Add(GetEmptyDayDTO(1));
            pList.Add(GetDefultModFriDay(2));
            pList.Add(GetDefultModFriDay(3));
            pList.Add(GetDefultModFriDay(4));
            pList.Add(GetDefultModFriDay(5));
            pList.Add(GetDefultModFriDay(6));
            pList.Add(GetEmptyDayDTO(7));

            return pList;

        }

        public Profile1 ConvertProfile(EmployeeProfileDTO employeeProfile)
        {
            var p = new Profile1();
            p.ProfileId = employeeProfile.ProfileId;
            p.EmpId = employeeProfile.EmpID;
            p.CdOffId = employeeProfile.OfficeID;
            p.DtEffStrt = employeeProfile.EffectiveStartDate;
            p.DtEffEnd = employeeProfile.EffectiveEndDate;
            p.CdWrkWkTyp = employeeProfile.WorkWeekType;
            p.CdUpdtTechId = employeeProfile.UpdatedByID;
            p.DtUpdtTrans = employeeProfile.UpdatedDay;

            return p;
        }

        public Profileday ConvertProfileDay(EmployeeProfileDayDTO profileDay)
        {
            var p = new Profileday();
            p.DayOfWkMonth = profileDay.DayCount;
            p.TmeWrkStrt = new DateTime(1900, 1, 1, profileDay.DayStart.Hour, profileDay.DayStart.Minute, 0);
            p.TmeWrkEnd = new DateTime(1900, 1, 1, profileDay.DayEnd.Hour, profileDay.DayEnd.Minute, 0);
            p.TmeAmBrkStrt = new DateTime(1900, 1, 1, profileDay.AMBreakStart.Hour, profileDay.AMBreakStart.Minute, 0);
            p.TmeAmBrkEnd = new DateTime(1900, 1, 1, profileDay.AMBreakEnd.Hour, profileDay.AMBreakEnd.Minute, 0);
            p.TmeLchBrkStrt = new DateTime(1900, 1, 1, profileDay.LunchBreakStart.Hour, profileDay.LunchBreakStart.Minute, 0);
            p.TmeLchBrkEnd = new DateTime(1900, 1, 1, profileDay.LunchBreakEnd.Hour, profileDay.LunchBreakEnd.Minute, 0);
            p.TmePmBrkStrt = new DateTime(1900, 1, 1, profileDay.PMBreakStart.Hour, profileDay.PMBreakStart.Minute, 0);
            p.TmePmBrkEnd = new DateTime(1900, 1, 1, profileDay.PMBreakEnd.Hour, profileDay.PMBreakEnd.Minute, 0);
            p.FlgAlt = (profileDay.IsAlternitiveDay == true) ? "1" : "0";
            p.FlgTelc = (profileDay.IsTelecomuteDay == true) ? "1" : "0";

            if (profileDay.TravelFromStart != null)
            {
                p.TrvlTmeFroStrt = new DateTime(1900, 1, 1, profileDay.TravelFromStart.Value.Hour, profileDay.TravelFromStart.Value.Minute, 0);
            }
            else { p.TrvlTmeFroStrt = null; }

            if (profileDay.TravelFromEnd != null)
            {
                p.TrvlTmeFroEnd = new DateTime(1900, 1, 1, profileDay.TravelFromEnd.Value.Hour, profileDay.TravelFromEnd.Value.Minute, 0);
            }
            else { p.TrvlTmeFroEnd = null; }

            if (profileDay.TravelToStart != null)
            {
                p.TrvlTmeToStrt = new DateTime(1900, 1, 1, profileDay.TravelToStart.Value.Hour, profileDay.TravelToStart.Value.Minute, 0);
            }
            else { p.TrvlTmeToStrt = null; }

            if (profileDay.TravelToEnd != null)
            {
                p.TrvlTmeToEnd = new DateTime(1900, 1, 1, profileDay.TravelToEnd.Value.Hour, profileDay.TravelToEnd.Value.Minute, 0);
            }
            else { p.TrvlTmeToEnd = null; }

            return p;
        }

        public Profileday GetEmptyDay(int dayofweek)
        {
            var p = new Profileday();
            p.DayOfWkMonth = dayofweek;
            p.TmeWrkStrt = new DateTime(1900, 1, 1);
            p.TmeWrkEnd = new DateTime(1900, 1, 1);
            p.TmeAmBrkStrt = new DateTime(1900, 1, 1);
            p.TmeAmBrkEnd = new DateTime(1900, 1, 1);
            p.TmeLchBrkStrt = new DateTime(1900, 1, 1);
            p.TmeLchBrkEnd = new DateTime(1900, 1, 1);
            p.TmePmBrkStrt = new DateTime(1900, 1, 1);
            p.TmePmBrkEnd = new DateTime(1900, 1, 1);
            p.FlgAlt = "0";
            p.FlgTelc = "0";
            p.TrvlTmeFroStrt = null;
            p.TrvlTmeFroEnd = null;
            p.TrvlTmeToStrt = null;
            p.TrvlTmeToEnd = null;

            return p;
        }
        public EmployeeProfileDayDTO GetEmptyDayDTO(int dayofweek)
        {
            var p = new EmployeeProfileDayDTO();
            p.DayCount = dayofweek;
            p.DayStart = new DateTime(1900, 1, 1);
            p.DayEnd = new DateTime(1900, 1, 1);
            p.AMBreakStart = new DateTime(1900, 1, 1);
            p.AMBreakEnd = new DateTime(1900, 1, 1);
            p.LunchBreakStart = new DateTime(1900, 1, 1);
            p.LunchBreakEnd = new DateTime(1900, 1, 1);
            p.PMBreakStart = new DateTime(1900, 1, 1);
            p.PMBreakEnd = new DateTime(1900, 1, 1);
            p.IsAlternitiveDay = false;
            p.IsTelecomuteDay = false;
            p.TravelToStart = null;
            p.TravelToEnd = null;
            p.TravelFromStart = null;
            p.TravelFromEnd = null;
            p.DayActive = false;

            return p;
        }
        public EmployeeProfileDayDTO GetDefultModFriDay(int dayofweek)
        {
            var p = new EmployeeProfileDayDTO();
            p.DayCount = dayofweek;
            p.DayStart = new DateTime(1900, 1, 1, 8, 0, 0);
            p.DayEnd = new DateTime(1900, 1, 1, 17, 0, 0);
            p.AMBreakStart = new DateTime(1900, 1, 1, 10, 0, 0);
            p.AMBreakEnd = new DateTime(1900, 1, 1, 10, 15, 0);
            p.LunchBreakStart = new DateTime(1900, 1, 1, 12, 0, 0);
            p.LunchBreakEnd = new DateTime(1900, 1, 1, 13, 0, 0);
            p.PMBreakStart = new DateTime(1900, 1, 1, 15, 0, 0);
            p.PMBreakEnd = new DateTime(1900, 1, 1, 15, 15, 0);
            p.IsAlternitiveDay = false;
            p.IsTelecomuteDay = false;
            p.TravelToStart = null;
            p.TravelToEnd = null;
            p.TravelFromStart = null;
            p.TravelFromEnd = null;
            p.DayActive = true;

            return p;
        }
        public IList<ConflictDTO> GetAllConflicts(int EmpId, DateTime ProfileStart, DateTime? ProfileEnd)
        {
            DateTime defultDate = new DateTime(1900, 01, 01);

            var profileDays = new List<ConflictDTO>();
            if (ProfileEnd == null)
            {
                profileDays = (from p in _context.Contact.AsNoTracking()
                               from c in _context.Dsrcase.Where(c => c.CdCase == p.CdCase).DefaultIfEmpty()
                               where p.EmpId == EmpId && p.DtCntctStrtTim > ProfileStart && (p.CdStatus2 == "3" || p.CdStatus2 == "4")

                               select new ConflictDTO()
                               {
                                   CaseNumber = p.CdCase,
                                   ConflictDateTimeStart = p.DtCntctStrtTim,
                                   ConfilctDateTimeEnd = p.DtCntctEndTim,
                                   OfficeId = p.CdOffId,
                                   EmpID = p.EmpId,
                                   DLNumber = c.NbrDl

                               }).ToList();
            }
            else
            {
                profileDays = (from p in _context.Contact.AsNoTracking()
                               from c in _context.Dsrcase.Where(c => c.CdCase == p.CdCase).DefaultIfEmpty()
                               where p.EmpId == EmpId && p.DtCntctStrtTim > ProfileStart &&
                                                p.DtCntctEndTim < ProfileEnd.Value &&
                                                (p.CdStatus2 == "3" || p.CdStatus2 == "4")

                               select new ConflictDTO()
                               {
                                   CaseNumber = p.CdCase,
                                   ConflictDateTimeStart = p.DtCntctStrtTim,
                                   ConfilctDateTimeEnd = p.DtCntctEndTim,
                                   OfficeId = p.CdOffId,
                                   EmpID = p.EmpId,
                                   DLNumber = c.NbrDl

                               }).ToList();
            }
            

            return profileDays;
        }

        public IEnumerable<SelectListItem> GetClassList()
        {
            return (_context.EmployeeClass.AsNoTracking().Select(c => new SelectListItem
            {
                Value = (c.CdEmpClass.ToString() + "      "),
                Text = (c.CdEmpClass + " - " + c.CdDesc)
            }));
        }

        public IEnumerable<SelectListItem> GetOfficeList()
        {
            return (_context.Dsoffice.AsNoTracking().Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff)
            }));
        }

        public IEnumerable<SelectListItem> GetDistrictOfficeList(string OfficeID)
        {
            string districtID = _context.Dsoffice.AsNoTracking().Where(o => o.CdOffId == OfficeID).Select(o => o.CdDistId).FirstOrDefault();
            return (_context.Dsoffice.AsNoTracking().Where(o => o.CdDistId == districtID).Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff)
            }));
        }

        public IEnumerable<SelectListItem> GetClassificationList()
        {
            return (_context.EmployeeRole.AsNoTracking().Select(e => new SelectListItem
            {
                Value = e.RoleId.ToString(),
                Text = (e.RoleId + " - " + e.RoleDescription)
            }));

        }
        public IEnumerable<EmployeeDTO> GetAllDistrictProfileEmployees(string OfficeID)
        {
            var distOff = _context.Dsoffice.Where(o => o.CdOffId == OfficeID).Select(o => o.CdDistId).FirstOrDefault().ToString();
            var offList = _context.Dsoffice.Where(o => o.CdDistId == distOff).Select(o => o.CdOffId).ToList();
            List<string> val = new List<string>() { "A", "E", "M", "O", "R", "H" };
            var empList = _context.Employee.AsNoTracking()
                        .Where(e => offList.Contains(e.CdOffId) && val.Contains(e.CdEmpTyp))
                        .Select(e => new EmployeeDTO()
                        {
                            Empid = e.EmpId,
                            FirstName = e.NmeFrstPrsn,
                            MiddleName = e.NmeMidPrsn,
                            LastName = e.NmeSurnmePrsn,
                            NameSuffix = e.NmeSufxPrsn,
                            UserID = e.CdLgnId,
                            ShortID = e.CdEmpId,
                            OfficeID = e.CdOffId,
                            Classification = e.CdEmpTyp,
                            EmployeeClass = e.CdEmpClass,
                            DateTerminated = e.DtTerminated,
                            LoanFlag = (e.FlgLoan == "1") ? true : false,
                            TransferFlag = (e.FlgTransfer == "1") ? true : false,
                            TransferOffice = e.CdTransferOff,
                            TransferDate = e.DtTransfer,
                            LoanOffice = e.CdLoanOff,
                            LoanStart = e.DtLoanStrt,
                            LoanEnd = e.DtLoanEnd
                        }
                        ).ToList();

            return empList;
        }
       

    }
}
