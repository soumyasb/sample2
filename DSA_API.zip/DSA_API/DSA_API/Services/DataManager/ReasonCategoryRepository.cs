﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class ReasonCategoryRepository : IReasonCategoryRepository
    {
        private DSAContext _context;
        public ReasonCategoryRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<ReasonCategoryDTO> getAllReasonCategories()
        {
            var reasonCategory = _context.Reacat.AsNoTracking()
                        .OrderBy(r => r.CdBgnRsn)
                        .Select(r => new ReasonCategoryDTO()
                        {
                            ID = r.Id,
                            FromCategory = r.CdBgnRsn,
                            ToCategory = r.CdEndRsn,
                            Description = r.DescCatgry,
                            SpecialCert = (r.CdNodef == "1") ? true : false,
                            UpdatedBy = null,
                            UpdateDay = null,
                            TermDate = r.DtTerm
                        }
                        ).ToList();
            return reasonCategory;
        }

        public ReasonCategoryDTO getReasonCategory(int id)
        {
            var reasonCategory = _context.Reacat.AsNoTracking()
                        .Where(r => r.Id == id)
                        .Select(r => new ReasonCategoryDTO()
                        {
                            ID = r.Id,
                            FromCategory = r.CdBgnRsn,
                            ToCategory = r.CdEndRsn,
                            Description = r.DescCatgry,
                            SpecialCert = (r.CdNodef == "1") ? true : false,
                            UpdatedBy = null,
                            UpdateDay = null,
                            TermDate = r.DtTerm
                        }
                        ).FirstOrDefault();
            return reasonCategory;
        }
        public Reacat convertReasonCategory(ReasonCategoryDTO reasonCategory)
        {
            Reacat rc = new Reacat();
            rc.Id = reasonCategory.ID;
            rc.CdBgnRsn = reasonCategory.FromCategory;
            rc.CdEndRsn = reasonCategory.ToCategory;
            rc.DescCatgry = reasonCategory.Description;
            rc.CdNodef = (reasonCategory.SpecialCert == true) ? "1" : "0";
            //UpdatedBy = null;
            //UpdateDay = null;
            rc.DtTerm = reasonCategory.TermDate;


            return rc;
        }
    }
}
