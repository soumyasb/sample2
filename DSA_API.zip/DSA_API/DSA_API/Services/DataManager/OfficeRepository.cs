﻿using DSA_API.Entities;
using DSA_API.Models;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class OfficeRepository : IOfficeRepository
    {
        private DSAContext _context;

        public OfficeRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<OfficeDetailDTO> getAllDSOffices()
        {
            var officeList = _context.Dsoffice.AsNoTracking()
                        .Select(o => new OfficeDetailDTO()
                        {
                            OfficeID = o.CdOffId,
                            Name = o.NmeOff,
                            AddressLineOne = o.AddrLn1,
                            City = o.CdCity,
                            Zip = o.CdZip,
                            Zip4 = o.CdZipAddrLst4,
                            PhoneNumber = o.NbrPhone,
                            DistrictID = o.CdDistId,
                            EffectiveDate = o.DtEff,
                            NameAbbriv = o.CdOffAbbr,
                            FieldFileDsg = o.CdFldFileDsg,
                            RequestorCode = o.CdRqstr,
                            FaxNumber = o.NbrFax,
                            TerminationDate = o.DtTerm
                        }
                        ).ToList();
            return officeList;
        }

        public OfficeDetailDTO getDSOffice(string id)
        {
            var office = _context.Dsoffice.AsNoTracking()
                        .Where(o => o.CdOffId == id)
                        .Select(o => new OfficeDetailDTO()
                        {
                            OfficeID = o.CdOffId,
                            Name = o.NmeOff,
                            AddressLineOne = o.AddrLn1,
                            City = o.CdCity,
                            Zip = o.CdZip,
                            Zip4 = o.CdZipAddrLst4,
                            PhoneNumber = o.NbrPhone,
                            DistrictID = o.CdDistId,
                            EffectiveDate = o.DtEff,
                            NameAbbriv = o.CdOffAbbr,
                            FieldFileDsg = o.CdFldFileDsg,
                            RequestorCode = o.CdRqstr,
                            FaxNumber = o.NbrFax,
                            TerminationDate = o.DtTerm
                        }
                        ).FirstOrDefault();
            return office;
        }

        public Dsoffice convertDSOffice(OfficeDetailDTO office)
        {
            Dsoffice o = new Dsoffice();

            o.CdOffId = office.OfficeID;
            o.NmeOff = office.Name;
            o.AddrLn1 = office.AddressLineOne;
            o.CdCity = office.City;
            o.CdZip = office.Zip;
            o.CdZipAddrLst4 = office.Zip4;
            o.NbrPhone = office.PhoneNumber;
            o.CdDistId = office.DistrictID;
            o.DtEff = office.EffectiveDate;
            o.CdOffAbbr = office.NameAbbriv;
            o.CdFldFileDsg = office.FieldFileDsg;
            o.CdRqstr = office.RequestorCode;
            o.NbrFax = office.FaxNumber;
            o.DtTerm = office.TerminationDate;

            return o;
        }


        public IEnumerable<SelectListItem> getOfficeList()
        {
            return (_context.Dsoffice.Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff)
            }));
        }

       
    }
}
