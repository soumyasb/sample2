﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class RegionRepository 
    {
        private DSAContext _context;

        public RegionRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<RegionDetailDTO> getAllRegions()
        {
            var regionList = _context.Region.AsNoTracking()
                        .Select(r => new RegionDetailDTO()
                        {
                            RegionID = r.CdRgnId,
                            DistrictID = r.CdDistId,
                            RegionName = r.NmeRgn,
                            EndDate = r.DtTerm
                        }
                        ).ToList();
            return regionList;
        }

        public RegionDetailDTO getRegion(string regionid, string districtid)
        {
            var region = _context.Region.AsNoTracking()
                        .Where(r => r.CdRgnId == regionid && r.CdDistId == districtid)
                        .Select(r => new RegionDetailDTO()
                        {
                            RegionID = r.CdRgnId,
                            DistrictID = r.CdDistId,
                            RegionName = r.NmeRgn,
                            EndDate = r.DtTerm
                        }
                        ).FirstOrDefault();
            return region;
        }

        public Region convertDSOffice(RegionDetailDTO region)
        {
            Region r = new Region();

            r.CdRgnId = region.RegionID;
            r.CdDistId = region.DistrictID;
            r.NmeRgn = region.RegionName;
            r.DtTerm = region.EndDate;
           

            return r;
        }


        public IEnumerable<SelectListItem> getOfficeList()
        {
            return (_context.Dsoffice.Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff)
            }));
        }
    }
}
