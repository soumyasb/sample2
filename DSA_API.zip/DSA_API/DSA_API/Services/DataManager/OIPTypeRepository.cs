﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class OIPTypeRepository : IOIPTypeRepository
    {
        private DSAContext _context;
        public OIPTypeRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<OIPTypeDTO> getAllOIPType()
        {
            var OIPTypeList = _context.Oiptype.AsNoTracking()
                   
                        .Select(a => new OIPTypeDTO()
                        {
                            Type = a.CdPrtyTyp,
                            Description = a.DescPrtyTyp,
                            TermDate = a.DtTerm
                        }
                        ).ToList();
            return OIPTypeList;
        }
        public OIPTypeDTO getOIPType(string type)
        {
            var OIPType = _context.Oiptype.AsNoTracking()
                        .Where(a => a.CdPrtyTyp == type)
                        .Select(a => new OIPTypeDTO()
                        {
                            Type = a.CdPrtyTyp,
                            Description = a.DescPrtyTyp,
                            TermDate = a.DtTerm
                        }
                        ).FirstOrDefault();
            return OIPType;
        }

        public Oiptype convertOIPType(OIPTypeDTO OIPType)
        {
            Oiptype a = new Oiptype();
            a.CdPrtyTyp = OIPType.Type;
            a.DescPrtyTyp = OIPType.Description;
            a.DtTerm =OIPType.TermDate;
           

            return a;
        }
    }
}
