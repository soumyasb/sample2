﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.DataManager;

namespace DSA_API.Services.DataManager
{
    public interface IHearingTimeRepository
    {
        Hearingtime1 convertHearingTime(HearingTimeForAddDTO hearingTime);
        IEnumerable<HearingTimeDTO> getAllHearingTimes();
        HearingTimeDTO getHearingTime(int id);
    }
}