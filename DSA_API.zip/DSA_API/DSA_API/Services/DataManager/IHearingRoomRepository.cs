﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services.DataManager
{
    public interface IHearingRoomRepository
    {
        Hearinglocation convertHearingRoom(HearingRoomDetailDTO room);
        IEnumerable<SelectListItem> getOfficeList();
        bool checkHearingRoom(string officeid, string roomnumber);
        HearingRoomDetailDTO getHearingRoom(string officeid, string roomnumber);
        IEnumerable<HearingRoomDetailDTO> getOfficeRooms(string id);
    }
}