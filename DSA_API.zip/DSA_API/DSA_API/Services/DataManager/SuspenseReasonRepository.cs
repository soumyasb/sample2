﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class SuspenseReasonRepository : ISuspenseReasonRepository
    {
        private DSAContext _context;
        public SuspenseReasonRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<SuspenseReasonDTO> getSuspenseReasons()
        {
            var SuspenseReasons = _context.SuspRsn.AsNoTracking()

                        .Select(a => new SuspenseReasonDTO()
                        {
                            Code = a.CdSuspRsn,
                            Description = a.DescSuspRsn,
                            TermDate = a.DtTerm
                        }
                        ).ToList();
            return SuspenseReasons;
        }
        public SuspenseReasonDTO getSuspenseReason(string code)
        {
            var SuspenseReason = _context.SuspRsn.AsNoTracking()
                        .Where(a => a.CdSuspRsn == code)
                        .Select(a => new SuspenseReasonDTO()
                        {
                            Code = a.CdSuspRsn,
                            Description = a.DescSuspRsn,
                            TermDate = a.DtTerm
                        }
                        ).FirstOrDefault();
            return SuspenseReason;
        }

        public SuspRsn convertSuspenseReason(SuspenseReasonDTO susp)
        {
            SuspRsn a = new SuspRsn();
            a.CdSuspRsn = susp.Code;
            a.DescSuspRsn = susp.Description;
            a.DtTerm = susp.TermDate;
            return a;
        }

    }
}
