﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class HearingRoomRepository : IHearingRoomRepository
    {
        private DSAContext _context;
       
        public HearingRoomRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<HearingRoomDetailDTO> getOfficeRooms(string id)
        {
            var roomList = _context.Hearinglocation.AsNoTracking()
                       .Where(o => o.CdOffId == id)
                        .Select(o => new HearingRoomDetailDTO()
                        {
                            HearingLocationId = o.Id,
                            OfficeID = o.CdOffId,
                            RoomNumber = o.NbrRoom,
                            Description = o.DescRoom,
                            DateClosed = o.DtClosed
                        }
                        ).ToList();
            return roomList;
        }
        public Hearinglocation convertHearingRoom(HearingRoomDetailDTO room)
        {
            Hearinglocation h = new Hearinglocation();
            h.Id = room.HearingLocationId;
            h.CdOffId = room.OfficeID;
            h.NbrRoom = room.RoomNumber;
            h.DescRoom = room.Description;
            h.DtClosed = room.DateClosed;
            return h;
        }
        public bool checkHearingRoom(string officeid, string roomnumber)
        {
            return _context.Hearinglocation.Any(a => a.CdOffId == officeid && a.NbrRoom == roomnumber);
        
        }
        public HearingRoomDetailDTO getHearingRoom(string officeid, string roomnumber)
        {
            var room = _context.Hearinglocation.AsNoTracking()
                        .Where(r => r.CdOffId == officeid && r.NbrRoom == roomnumber)
                        .Select(o => new HearingRoomDetailDTO()
                        {
                            HearingLocationId = o.Id,
                            OfficeID = o.CdOffId,
                            RoomNumber = o.NbrRoom,
                            Description = o.DescRoom,
                            DateClosed = o.DtClosed
                        }
                        ).FirstOrDefault();
            return room;
        }
        public IEnumerable<SelectListItem> getOfficeList()
        {
            return (_context.Dsoffice.Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff)
            }));
        }
    }
}
