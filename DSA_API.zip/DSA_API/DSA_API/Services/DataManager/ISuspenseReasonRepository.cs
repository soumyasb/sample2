﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.DataManager;

namespace DSA_API.Services.DataManager
{
    public interface ISuspenseReasonRepository
    {
        SuspRsn convertSuspenseReason(SuspenseReasonDTO susp);
        SuspenseReasonDTO getSuspenseReason(string code);
        IEnumerable<SuspenseReasonDTO> getSuspenseReasons();
    }
}