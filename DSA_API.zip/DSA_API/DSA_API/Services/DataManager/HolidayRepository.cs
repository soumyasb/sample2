﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class HolidayRepository : IHolidayRepository
    {
        private DSAContext _context;
        public HolidayRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<HolidayDTO> getAllHOlidays()
        {
            var HolidayList =_context.Holiday.AsNoTracking()
                        .Where(h => h.DtTerm == null)
                        .Select(h => new HolidayDTO()
                        {
                            ID = h.Id,
                            HolidayDate = h.DtHoli,
                            TermDate = h.DtTerm,
                            //TODO: 
                            LastUpdatedBy = null,
                            LastUpdatedDate = null,
                            //MMDD = h.DT_HOLI.Value.Month.ToString() + "-" + h.DT_HOLI.Value.Day.ToString(),
                            CCYY = h.DtHoli.Value.Year.ToString()
                        }
                        ).ToList();
            var HolidayList2 = HolidayList.OrderByDescending(x => x.HolidayDate).ToList();
            return HolidayList2;
        }

        public HolidayDTO getHoliday(int id)
        {
            var holiday = _context.Holiday.AsNoTracking()
                        .Where(h => h.Id == id)
                        .Select(h => new HolidayDTO()
                        {
                            ID = h.Id,
                            HolidayDate = h.DtHoli,
                            TermDate = h.DtTerm,
                            //TODO: 
                            LastUpdatedBy = null,
                            LastUpdatedDate = null
                        }
                        ).FirstOrDefault();
            return holiday;
        }
        public Holiday convertHoliday(HolidayDTO holiday)
        {
            Holiday h = new Holiday();
            h.Id = holiday.ID;
            h.DtHoli = holiday.HolidayDate;
            h.DtTerm = holiday.TermDate;

            //TODO:
            //h.lastUpdetedBy = holiday.LastUpdatedBy;
            //h.lastUpdatedDate = holiday.LastUpdatedDate;

            return h;
        }

    }
}
