﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public interface IOfficeRepository  
    {
        IEnumerable<OfficeDetailDTO> getAllDSOffices();
        OfficeDetailDTO getDSOffice(string id);
        Dsoffice convertDSOffice(OfficeDetailDTO office);
        IEnumerable<SelectListItem> getOfficeList();
    }
}
