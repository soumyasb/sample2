﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class ActivityTypeRepository : IActivityTypeRepository
    {
        private DSAContext _context;
        public ActivityTypeRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<ActivityTypeDMDTO> getAllActivityType()
        {
            var activityTypeList = _context.Activitytype.AsNoTracking()
                        .Where(a => a.CdTypes == "H")
                        .Select(a => new ActivityTypeDMDTO()
                        {
                            ID = a.Id,
                            Code = a.CdActvyTyp,
                            Abbr = a.TxtActvyAbbr,
                            Description = a.DescActvyTyp,
                            Confidential = (a.FlgConfTyp == 1) ? true : false,
                            //TODO:
                            lastUpdatedBy = null,
                            lastUpdetedDate = null,
                            TermDate = a.DtTerm
                        }
                        ).ToList();
            return activityTypeList;
        }
        public ActivityTypeDMDTO getActivityType(int id)
        {
            var activityType = _context.Activitytype.AsNoTracking()
                        .Where(a => a.Id == id)
                        .Select(a => new ActivityTypeDMDTO()
                        {
                            ID = a.Id,
                            Code = a.CdActvyTyp,
                            Abbr = a.TxtActvyAbbr,
                            HearingTypes = a.CdTypes,
                            Description = a.DescActvyTyp,
                            Confidential = (a.FlgConfTyp == 1) ? true : false,
                            //TODO:
                            lastUpdatedBy = a.LastUpdatedBy,
                            lastUpdetedDate = a.LastUpdatedDate,
                            TermDate = a.DtTerm
                        }
                        ).FirstOrDefault();
            return activityType;
        }

        public Activitytype convertActivityType(ActivityTypeDMDTO activityType)
        {
            Activitytype a = new Activitytype();
            a.Id = activityType.ID;
            a.CdActvyTyp = activityType.Code;
            a.TxtActvyAbbr = activityType.Abbr;
            a.CdTypes = activityType.HearingTypes;
            a.DescActvyTyp = activityType.Description;
            a.FlgConfTyp = Convert.ToByte(activityType.Confidential);
            //Todo:
            a.LastUpdatedBy = activityType.lastUpdatedBy;
            a.LastUpdatedDate = activityType.lastUpdetedDate;
            a.DtTerm = activityType.TermDate;

            return a;
        }
    }
}
