﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using DSA_API.Services.DataManager;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;


namespace DSA_API.Services.DataManager
{
    public class ReferralRepository : IReferralRepository
    {
        private DSAContext _context;
        public ReferralRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<ReferralDTO> getAllReferrals()
        {
            var ReferralList = _context.Referral.AsNoTracking()

                        .Select(a => new ReferralDTO()
                        {
                            Type = a.CdRefrSrceTyp,
                            Description = a.DescRefrSrceTyp,
                            TermDate = a.DtTerm
                        }
                        ).ToList();
            return ReferralList;
        }
        public ReferralDTO getReferral(string type)
        {
            var Referral = _context.Referral.AsNoTracking()
                        .Where(a => a.CdRefrSrceTyp == type)
                        .Select(a => new ReferralDTO()
                        {
                            Type = a.CdRefrSrceTyp,
                            Description = a.DescRefrSrceTyp,
                            TermDate = a.DtTerm
                        }
                        ).FirstOrDefault();
            return Referral;
        }

        public Referral convertReferral(ReferralDTO type)
        {
            Referral a = new Referral();
            a.CdRefrSrceTyp = type.Type;
            a.DescRefrSrceTyp = type.Description;
            a.DtTerm = type.TermDate;
            return a;
        }
    }
}
