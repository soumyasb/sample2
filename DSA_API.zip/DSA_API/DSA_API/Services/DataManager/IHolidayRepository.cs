﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.DataManager;

namespace DSA_API.Services.DataManager
{
    public interface IHolidayRepository
    {
        Holiday convertHoliday(HolidayDTO holiday);
        IEnumerable<HolidayDTO> getAllHOlidays();
        HolidayDTO getHoliday(int id);
    }
}