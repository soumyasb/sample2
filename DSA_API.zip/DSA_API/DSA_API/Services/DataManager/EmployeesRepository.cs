﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services 
{
    public class EmployeesRepository : IEmployeesRepository
    {
        private DSAContext _context;
        public EmployeesRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<EmployeeDTO> getAllEmployees()
        {
            var empList = _context.Employee.AsNoTracking()
                        .Select(e => new EmployeeDTO()
                        {
                            Empid = e.EmpId,
                            FirstName = e.NmeFrstPrsn,
                            MiddleName = e.NmeMidPrsn,
                            LastName = e.NmeSurnmePrsn,
                            NameSuffix = e.NmeSufxPrsn,
                            UserID = e.CdLgnId,
                            ShortID = e.CdEmpId,
                            OfficeID = e.CdOffId,
                            Classification = e.CdEmpTyp,
                            EmployeeClass = e.CdEmpClass,
                            DateTerminated = e.DtTerminated,
                            LoanFlag = (e.FlgLoan == "1") ? true : false,
                            TransferFlag = (e.FlgTransfer == "1") ? true : false,
                            TransferOffice = e.CdTransferOff,
                            TransferDate = e.DtTransfer,
                            LoanOffice = e.CdLoanOff,
                            LoanStart = e.DtLoanStrt,
                            LoanEnd = e.DtLoanEnd

                        }
                        ).ToList().OrderBy(m => m.LastName);
            return empList;
        }

        public IEnumerable<EmployeeDTO> getAllActiveEmployees()
        {
            var empList = _context.Employee.AsNoTracking()
                        .Where(e => e.DtTerminated == null)
                        .Select(e => new EmployeeDTO()
                        {
                            Empid = e.EmpId,
                            FirstName = e.NmeFrstPrsn,
                            MiddleName = e.NmeMidPrsn,
                            LastName = e.NmeSurnmePrsn,
                            NameSuffix = e.NmeSufxPrsn,
                            UserID = e.CdLgnId,
                            ShortID = e.CdEmpId,
                            OfficeID = e.CdOffId,
                            Classification = e.CdEmpTyp,
                            EmployeeClass = e.CdEmpClass,
                            DateTerminated = e.DtTerminated,
                            LoanFlag = (e.FlgLoan == "1") ? true : false,
                            TransferFlag = (e.FlgTransfer == "1") ? true : false,
                            TransferOffice = e.CdTransferOff,
                            TransferDate = e.DtTransfer,
                            LoanOffice = e.CdLoanOff,
                            LoanStart = e.DtLoanStrt,
                            LoanEnd = e.DtLoanEnd

                        }
                        ).ToList();
            return empList;
        }
        public EmployeeDTO getEmployee(int EmployeeID)
        {
            var emp = _context.Employee.AsNoTracking()
                        .Where(e => e.EmpId == EmployeeID)
                        .Select(e => new EmployeeDTO()
                        {
                            Empid = e.EmpId,
                            FirstName = e.NmeFrstPrsn,
                            LastName = e.NmeSurnmePrsn,
                            NameSuffix = e.NmeSufxPrsn,
                            UserID = e.CdLgnId,
                            ShortID = e.CdEmpId,
                            OfficeID = e.CdOffId,
                            Classification = e.CdEmpTyp,
                            EmployeeClass = e.CdEmpClass,
                            DateTerminated = e.DtTerminated,
                            LoanFlag = (e.FlgLoan == "1") ? true : false,
                            TransferFlag = (e.FlgTransfer == "1") ? true : false,
                            TransferOffice = e.CdTransferOff,
                            TransferDate = e.DtTransfer,
                            LoanOffice = e.CdLoanOff,
                            LoanStart = e.DtLoanStrt,
                            LoanEnd = e.DtLoanEnd
                        }
                        ).ToList().FirstOrDefault();
            return emp;
        }

        public Employee Convert(EmployeeDTO emp)
        {
            Employee e = new Employee();

            e.EmpId = emp.Empid;
            e.NmeFrstPrsn = emp.FirstName;
            e.NmeMidPrsn = emp.MiddleName;
            e.NmeSurnmePrsn = emp.LastName;
            e.NmeSufxPrsn = emp.NameSuffix;
            e.CdLgnId = emp.UserID;
            e.CdEmpId = emp.ShortID;
            e.CdUpdtTechId = emp.LastUpdBy;
            e.DtUpdtTrans = DateTime.Now;
            e.CdOffId = emp.OfficeID;
            e.CdEmpTyp = emp.Classification;
            e.CdEmpClass = emp.EmployeeClass;
            e.DtTerminated = emp.DateTerminated;
            e.FlgLoan = (emp.LoanFlag == true) ? "1" : "";
            e.FlgTransfer = (emp.TransferFlag == true) ? "1" : "";
            e.CdTransferOff = emp.TransferOffice;
            e.DtTransfer = emp.TransferDate;
            e.CdLoanOff = emp.LoanOffice;
            e.DtLoanStrt = emp.LoanStart;
            e.DtLoanEnd = emp.LoanEnd;

            return e;

        }
        public Employee ConvertForCreate(EmployeeForCreationDTO emp)
        {
            Employee e = new Employee();

            e.NmeFrstPrsn = emp.employee.FirstName;
            e.NmeMidPrsn = emp.employee.MiddleName;
            e.NmeSurnmePrsn = emp.employee.LastName;
            e.NmeSufxPrsn = emp.employee.NameSuffix;
            e.CdLgnId = emp.employee.UserID;
            e.CdEmpId = emp.employee.ShortID;
            e.CdUpdtTechId = emp.employee.LastUpdBy;
            e.DtUpdtTrans = DateTime.Now;
            e.CdOffId = emp.employee.OfficeID;
            e.CdEmpTyp = emp.employee.Classification;
            e.CdEmpClass = emp.employee.EmployeeClass;
            e.DtTerminated = emp.employee.DateTerminated;
            e.FlgLoan = (emp.employee.LoanFlag == true) ? "1" : "";
            e.FlgTransfer = (emp.employee.TransferFlag == true) ? "1" : "";
            e.CdTransferOff = emp.employee.TransferOffice;
            e.DtTransfer = emp.employee.TransferDate;
            e.CdLoanOff = emp.employee.LoanOffice;
            e.DtLoanStrt = emp.employee.LoanStart;
            e.DtLoanEnd = emp.employee.LoanEnd;

            return e;

        }

        public bool DeleteEmployee(Employee employee)
        {
            
            return (_context.SaveChanges() >= 0);
        }

        public IEnumerable<SelectListItem> getClassList()
        {
            return (_context.EmployeeClass.AsNoTracking().Select(c => new SelectListItem
            {
                Value = (c.CdEmpClass.ToString() + "      "),
                Text = (c.CdEmpClass + " - " + c.CdDesc)
            }));
        }

        public IEnumerable<SelectListItem> getOfficeList()
        {
            return (_context.Dsoffice.AsNoTracking().Select(o => new SelectListItem
            {
                Value = o.CdOffId.ToString(),
                Text = (o.CdOffId + " - " + o.NmeOff
                                                            )
            }));
        }

        public IEnumerable<SelectListItem> getClassificationList()
        {
            return (_context.EmployeeRole.AsNoTracking().Select(e => new SelectListItem
            {
                Value = e.RoleId.ToString(),
                Text = (e.RoleId + " - " + e.RoleDescription)
            }));
        }
        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }

    }
}
