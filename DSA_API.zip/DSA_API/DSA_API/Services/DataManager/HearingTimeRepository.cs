﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public class HearingTimeRepository : IHearingTimeRepository
    {
        private DSAContext _context;
        public HearingTimeRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<HearingTimeDTO> getAllHearingTimes()
        {
            var hearingTimeList = _context.Hearingtime1.AsNoTracking()
                        .Select(h => new HearingTimeDTO()
                        {
                            ID = h.Id,
                            Category = h.Category,
                            HearingTime = h.HearingTime,
                            InterviewTime = h.InterviewTime,
                            ReExamTime = h.ReExamTime,
                            //TODO: 
                            LastUpdatedBy = null,
                            LastUpdatedDate = null
                          
                        }
                        ).ToList();
            return hearingTimeList;
        }

     

        public HearingTimeDTO getHearingTime(int id)
        {
            var hearingTime = _context.Hearingtime1.AsNoTracking()
                        .Where(h => h.Id == id)
                        .Select(h => new HearingTimeDTO()
                        {
                            ID = h.Id,
                            Category = h.Category,
                            HearingTime = h.HearingTime,
                            InterviewTime = h.InterviewTime,
                            ReExamTime = h.ReExamTime,
                            //TODO: 
                            LastUpdatedBy = null,
                            LastUpdatedDate = null
                        }
                        ).FirstOrDefault();
            return hearingTime;
        }
        public Hearingtime1 convertHearingTime(HearingTimeForAddDTO hearingTime)
        {
            Hearingtime1 h = new Hearingtime1();
            h.Category = hearingTime.Category;

            h.HearingTime = hearingTime.HearingTime;
            h.InterviewTime = hearingTime.InterviewTime;
            h.ReExamTime = hearingTime.ReExamTime;
            //TODO:
            //h.lastUpdetedBy = hearingTime.LastUpdatedBy;
            //h.lastUpdatedDate = hearingTime.LastUpdatedDate;

            return h;
        }

  
    }
}
