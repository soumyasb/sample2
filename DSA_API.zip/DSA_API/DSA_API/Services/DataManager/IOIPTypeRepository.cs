﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.DataManager;

namespace DSA_API.Services.DataManager
{
    public interface IOIPTypeRepository
    {
        Oiptype convertOIPType(OIPTypeDTO OIPType);
        IEnumerable<OIPTypeDTO> getAllOIPType();
        OIPTypeDTO getOIPType(string type);
    }
}