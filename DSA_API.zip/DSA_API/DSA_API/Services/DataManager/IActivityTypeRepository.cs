﻿using DSA_API.Entities;
using DSA_API.Models.DataManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.DataManager
{
    public interface IActivityTypeRepository
    {
        IEnumerable<ActivityTypeDMDTO> getAllActivityType();
        ActivityTypeDMDTO getActivityType(int id);
        Activitytype convertActivityType(ActivityTypeDMDTO activityType);
    }
}
