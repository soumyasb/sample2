﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services
{
    public interface ILookupRepository
    {
        IEnumerable<SelectListItem> GetStates();
        IEnumerable<SelectListItem> GetReasons();
        IEnumerable<SelectListItem> GetFieldFile();
        IEnumerable<SelectListItem> GetCommercialStatus();
        IEnumerable<SelectListItem> GetEndStay(string officeID);
        IEnumerable<SelectListItem> GetHearingResults();
        IEnumerable<SelectListItem> GetChgHearingType(string trans);
        IEnumerable<SelectListItem> GetCOFO();
        IEnumerable<SelectListItem> GetLicenseLocation(string trans);
        IEnumerable<SelectListItem> GetLicenseLocationByOffice(string office);
        IEnumerable<SelectListItem> GetAuthoritySection(string trans, string section = "*");
        IEnumerable<SelectListItem> GetOfficeAbbreviations();
        IEnumerable<SelectListItem> GetTypeAction(int code, string trans, string ta = null);
        IEnumerable<SelectListItem> GetPMCode(string code);
        IEnumerable<SelectListItem> GetRestrictions(string code);
        IEnumerable<SelectListItem> GetServiceCodes();
        IEnumerable<SelectListItem> GetParaIns(string code);
        IEnumerable<SelectListItem> GetDUKCodes(string code);
        IEnumerable<SelectListItem> GetPurgeCodes(string code);
        IEnumerable<SelectListItem> GetPullNotInfo(string code);
        IEnumerable<SelectListItem> GetPullNotice(string code);
        IEnumerable<SelectListItem> GetPullNoticeReason(string code);
        IEnumerable<SelectListItem> GetDeceasedCodes(string code);
        IEnumerable<SelectListItem> GetAttachments(string code);
        IEnumerable<SelectListItem> GetFileConditions(string code);
        IEnumerable<SelectListItem> GetCommFileCond(string code);
    }
}