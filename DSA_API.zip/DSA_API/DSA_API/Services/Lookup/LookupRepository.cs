﻿using DSA_API.Entities;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services 
{
    public class LookupRepository : ILookupRepository
    {
        private DSAContext _context;
        public LookupRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<SelectListItem> GetStates()
        {
            var states = (from s in _context.State.AsNoTracking()
                          orderby s.CdAlpState
                          select new SelectListItem()
                          {
                              Value = s.CdAlpState,
                              Text = s.NmeState
                          }).ToList();
            states.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return states;
        }
        public IEnumerable<SelectListItem> GetReasons()
        {
            var reason = (from s in _context.Reason.AsNoTracking()
                          where s.DtTerm == null
                          orderby s.CdRsn
                          select new SelectListItem()
                          {
                              Value = s.CdRsn,
                              Text = s.DescRsn.Trim()
                          }).ToList();
            reason.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return reason;
        }
        public IEnumerable<SelectListItem> GetFieldFile()
        {
            var field = (from s in _context.FieldFile.AsNoTracking()
                         where s.DtTerm == null
                         select new SelectListItem()
                         {
                             Value = s.Code,
                             Text = s.Descr.Trim()
                         }).ToList();
            field.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return field;
        }
        public IEnumerable<SelectListItem> GetCommercialStatus()
        {
            var commstatus = (from c in _context.CommercialStatusInd.AsNoTracking()
                              where c.DtEndEff == null
                              select new SelectListItem()
                              {
                                  Value = c.CdCode,
                                  Text = c.CdDesc.Trim()
                              }).ToList();
            commstatus.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return commstatus;
        }
        public IEnumerable<SelectListItem> GetEndStay(string officeID)
        {

            if (officeID == "420" || officeID == "421")
            {
                var endstay1 = (from c in _context.Endstaycodes.AsNoTracking()
                                where c.DtTerm == null
                                select new SelectListItem()
                                {
                                    Value = c.CdEndstay.Trim(),
                                    Text = c.DescEndstay.Trim()
                                }).ToList();
                endstay1.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return endstay1;
            }
            else
            {
                var endstay2 = (from c in _context.Endstaycodes.AsNoTracking()
                                where c.DtTerm == null && c.CdEndstay != "4"
                                select new SelectListItem()
                                {
                                    Value = c.CdEndstay.Trim(),
                                    Text = c.DescEndstay.Trim()
                                }).ToList();
                endstay2.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return endstay2;
            }
        }
        public IEnumerable<SelectListItem> GetHearingResults()
        {
            var results = (from c in _context.Schedresults.AsNoTracking()
                           where c.DtTerm == null
                           orderby c.CdSchedRsl
                           select new SelectListItem()
                           {
                               Value = c.CdSchedRsl,
                               Text = c.DescSchedRsl.Trim()
                           }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }

        public IEnumerable<SelectListItem> GetChgHearingType(string trans)
        {
            var results = (from t in _context.Transtypehrng.AsNoTracking()
                           join o in _context.Hearingtype.AsNoTracking() on t.CdHrngTyp equals o.CdHrngTyp
                           where t.CdTrans == trans && t.DtTerm == null && o.DtTerm == null
                           select new SelectListItem()
                           {
                               Text = o.DescHrngTyp.Trim(),
                               Value = t.CdHrngTyp
                           }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }
        public IEnumerable<SelectListItem> GetCOFO()
        {
            var results = (from c in _context.Cofocodes.AsNoTracking()
                           where c.DtTerm == null
                           orderby c.CdCofo
                           select new SelectListItem()
                           {
                               Text = c.DescCofo.Trim(),
                               Value = c.CdCofo
                           }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }
        public IEnumerable<SelectListItem> GetLicenseLocation(string trans)
        {
            var results = (from t in _context.TransLicLoc.AsNoTracking()
                           join l in _context.Licloc.AsNoTracking() on t.CdLicloc equals l.CdLicloc
                           where t.CdTrans == trans && t.DtTerm == null & l.DtTerm == null
                           select new SelectListItem()
                           {
                               Text = l.DescLicloc.Trim(),
                               Value = t.CdLicloc
                           }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }
        public IEnumerable<SelectListItem> GetLicenseLocationByOffice(string office)
        {
            var results = (from t in _context.Licloc.AsNoTracking()
                         
                           where (t.CdOffice == office  || t.CdOffice == "ALL") && t.DtTerm == null
                           select new SelectListItem()
                           {
                               Text = t.DescLicloc.Trim(),
                               Value = t.CdLicloc
                           }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }
        public IEnumerable<SelectListItem> GetAuthoritySection(string trans, string section = "*")
        {
            if (section == "*")
            {
                var results = (from a in _context.Authoritysection.AsNoTracking()
                               where a.CdTransaction == trans && a.DtTerm == null
                               select new SelectListItem()
                               {
                                   Text = a.DescAuthority.Trim(),
                                   Value = a.CdVc.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from a in _context.Authoritysection.AsNoTracking()
                               where a.CdTransaction == trans && a.CdVc == section && a.DtTerm == null
                               select new SelectListItem()
                               {
                                   Text = a.DescAuthority.Trim(),
                                   Value = a.CdVc.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }

        public IEnumerable<SelectListItem> GetOfficeAbbreviations()
        {

            var results = (from a in _context.Dsoffice.AsNoTracking().OrderBy(x => x.CdOffAbbr)

                           select new SelectListItem()
                           {
                               Text = a.NmeOff.Trim(),
                               Value = a.CdOffAbbr
                           }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }
        public IEnumerable<SelectListItem> GetTypeAction(int code, string trans, string ta = null)
        {
            if (code == 1)
            {
                var results = (from t in _context.TransTypeAction.AsNoTracking()
                               where t.CdTypAct == ta && t.CdTrans == trans && t.DtTerm == null
                               select new SelectListItem()
                               {
                                  Value = t.CdTypAct
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from t in _context.TransTypeAction.AsNoTracking()
                               join a in _context.Typeaction.AsNoTracking() on t.CdTypAct equals a.CdTypAct
                               where t.CdTrans == trans && a.DtTerm == null && t.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = t.CdTypAct,
                                   Text = a.DescTypAct.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

            
        }
        public IEnumerable<SelectListItem> GetPMCode(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Pandm.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdPandm,
                                   Text = p.DescPandm.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Pandm.AsNoTracking()
                               where p.DtTerm == null && p.CdPandm == code
                               select new SelectListItem()
                               {
                                  Text = p.DescPandm.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }


        }
        public IEnumerable<SelectListItem> GetRestrictions(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Restriction.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdRestrict,
                                   Text = p.DescRestrict.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Restriction.AsNoTracking()
                               where p.DtTerm == null && p.CdRestrict == code
                               select new SelectListItem()
                               {
                                   Value = p.CdRestrict,
                                   Text = p.DescRestrict.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }


        }
        public IEnumerable<SelectListItem> GetServiceCodes()
        {
           
            var results = (from s in _context.Service.AsNoTracking()
                            where s.DtTerm == null
                            select new SelectListItem()
                            {
                                Value = s.CdService,
                                Text = s.TxtDescService.Trim()
                            }).ToList();
            results.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return results;
        }
        public IEnumerable<SelectListItem> GetParaIns(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.ParaIns.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdCode,
                                   Text = p.CdDesc.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.ParaIns.AsNoTracking()
                               where p.DtTerm == null && p.CdCode == code
                               select new SelectListItem()
                               {
                                   Text = p.CdDesc.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }


        }
        public IEnumerable<SelectListItem> GetDUKCodes(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Dukcodes.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdDuk,
                                   Text = p.DescDuk.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Dukcodes.AsNoTracking()
                               where p.DtTerm == null && p.CdDuk == code
                               select new SelectListItem()
                               {
                                   Text = p.DescDuk.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }


        }
        public IEnumerable<SelectListItem> GetPurgeCodes(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Pullnotpurge.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdPullnotpurge,
                                   Text = p.DescPullnotpurge.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Pullnotpurge.AsNoTracking()
                               where p.DtTerm == null && p.CdPullnotpurge == code
                               select new SelectListItem()
                               {
                                   Text = p.CdPullnotpurge.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }


        }
        public IEnumerable<SelectListItem> GetPullNotInfo(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Pullnotinfo.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdPullnotinfo,
                                   Text = p.DescPullnotinfo.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Pullnotinfo.AsNoTracking()
                               where p.DtTerm == null && p.CdPullnotinfo == code
                               select new SelectListItem()
                               {
                                   Text = p.DescPullnotinfo.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }


        }
        public IEnumerable<SelectListItem> GetPullNotice(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Pullnotice.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdPullnotice,
                                   Text = p.DescPullnotice.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Pullnotice.AsNoTracking()
                               where p.DtTerm == null && p.CdPullnotice == code
                               select new SelectListItem()
                               {
                                   Text = p.DescPullnotice.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }
        public IEnumerable<SelectListItem> GetPullNoticeReason(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Pullnotreas.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdPullnotreas,
                                   Text = p.DescPullnotreas.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Pullnotreas.AsNoTracking()
                               where p.DtTerm == null && p.CdPullnotreas == code
                               select new SelectListItem()
                               {
                                   Text = p.DescPullnotreas.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }
        public IEnumerable<SelectListItem> GetDeceasedCodes(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Deceasedcodes.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdDeceased,
                                   Text = p.DescDeceased.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Deceasedcodes.AsNoTracking()
                               where p.DtTerm == null && p.CdDeceased == code
                               select new SelectListItem()
                               {
                                   Text = p.DescDeceased.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }
        public IEnumerable<SelectListItem> GetAttachments(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Attachments.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdAttachments,
                                   Text = p.DescAttachments.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Attachments.AsNoTracking()
                               where p.DtTerm == null && p.CdAttachments == code
                               select new SelectListItem()
                               {
                                   Text = p.DescAttachments.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }
        public IEnumerable<SelectListItem> GetFileConditions(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.Filecondition.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdFilecond,
                                   Text = p.DescFilecond.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.Filecondition.AsNoTracking()
                               where p.DtTerm == null && p.CdFilecond == code
                               select new SelectListItem()
                               {
                                   Text = p.DescFilecond.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }
        public IEnumerable<SelectListItem> GetCommFileCond(string code)
        {
            if (code == "*")
            {
                var results = (from p in _context.CommFileCond.AsNoTracking()
                               where p.DtTerm == null
                               select new SelectListItem()
                               {
                                   Value = p.CdCode,
                                   Text = p.CdDesc.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }
            else
            {
                var results = (from p in _context.CommFileCond.AsNoTracking()
                               where p.DtTerm == null && p.CdCode == code
                               select new SelectListItem()
                               {
                                   Text = p.CdDesc.Trim()
                               }).ToList();
                results.Insert(0, new SelectListItem()
                {
                    Text = "Select Option",
                    Value = ""
                });
                return results;
            }

        }

    }

}

