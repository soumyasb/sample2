﻿using DSA_API.Entities;
using DSA_API.Models;
using System.Collections.Generic;

namespace DSA_API.Services
{
    public interface INewsOfficesRepository
    {
        int CreateNewsItems(NewsItemDTO newsItemModel);
        IEnumerable<NewsItem> GetNewsItems(int empid);
        NewsItem GetNewsItem(int newsid);
        IEnumerable<OfficeNewsItem> GetOfficeNewsItems(int newsid);
        bool ModifyNewsItems(NewsItemDTO newsItemModel);
        bool ModifyOfficeNewsItems(NewsItemDTO newsItem);
        bool DeleteNewsItem(NewsItem newsitem);
        bool DeleteOfficeNewsItems(NewsItem newsitem);
    }
}