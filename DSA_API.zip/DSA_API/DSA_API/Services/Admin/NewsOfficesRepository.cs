﻿using DSA_API.Entities;
using DSA_API.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DSA_API.Services
{
    public class NewsOfficesRepository : INewsOfficesRepository
    {
        private DSAContext _context;
        private IDSOfficeRepository _dSOfficeRepository;
        public NewsOfficesRepository(DSAContext context, IDSOfficeRepository dSOfficeRepository)
        {
            _context = context;
            _dSOfficeRepository = dSOfficeRepository;
        }
      
       
        public IEnumerable<NewsItem> GetNewsItems(int empid)
        {
            var newsitems = _context.NewsItem.AsNoTracking()
                     .Where(e => e.EmpId == empid)
                     .ToList();
            return newsitems;

        }
        public NewsItem GetNewsItem(int newsid)
        {
            var newsitem = _context.NewsItem.AsNoTracking()
                     .Include(n => n.OfficeNewsItem)
                     .Where(e => e.NewsId == newsid)
                     .FirstOrDefault();
            return newsitem;

        }

        public IEnumerable<OfficeNewsItem> GetOfficeNewsItems(int newsid)
        {
            var officeNewsitem = _context.OfficeNewsItem.AsNoTracking()
                     .Where(e => e.NewsId == newsid)
                     .ToList();
            return officeNewsitem;

        }
        public bool ModifyNewsItems(NewsItemDTO newsItemModel)
        {
            NewsItem newsItem = _context.NewsItem.Find(newsItemModel.NewsId);
            _context.Entry(newsItem).State = EntityState.Modified;
            newsItem.Subject = newsItemModel.Subject;
            newsItem.NewsText = newsItemModel.NewsText;
            newsItem.Priority = newsItemModel.Priority;
            newsItem.StartDate = newsItemModel.StartDate;
            newsItem.EndDate = newsItemModel.EndDate;
            newsItem.AllOffices = newsItemModel.AllOffices;
            if (DeleteOfficeNewsItems(newsItem))
                _context.SaveChanges();
            return true;
        }

        public bool ModifyOfficeNewsItems(NewsItemDTO newsItem)
        {
            var office = new Dsoffice();

            var officeNews = new OfficeNewsItem();
            if (newsItem.EmployeeType == "O")
            {
                var officeid = (from e in _context.Employee
                                where e.EmpId == newsItem.EmpId
                                select e.CdOffId).First();
                officeNews.CdOffId = officeid;
                officeNews.NewsId = newsItem.NewsId;
                _context.OfficeNewsItem.Add(officeNews);
                _context.SaveChanges();
                return true;
            }


            if (newsItem.AllOffices)
            {
                List<RegionOfficeDTO> offices = new List<RegionOfficeDTO>();
                switch (newsItem.EmployeeType)
                {
                    case "D":
                        offices = _dSOfficeRepository.GetRegionOffices(newsItem.EmpId, "D");
                        break;
                    case "R":
                        offices = _dSOfficeRepository.GetRegionOffices(newsItem.EmpId, "R");
                        break;
                    default:
                        break;
                }
                foreach (var item in offices)
                {
                    officeNews.CdOffId = item.OfficeId;
                    officeNews.NewsId = newsItem.NewsId;
                    _context.OfficeNewsItem.Add(officeNews);
                    _context.SaveChanges();
                }
            }
            else
            {
                foreach (var ofc in newsItem.officeGroup)
                {
                    officeNews.CdOffId = ofc;
                    officeNews.NewsId = newsItem.NewsId;
                    _context.OfficeNewsItem.Add(officeNews);
                    _context.SaveChanges();
                }
            }



            //NewsItem newsItem = _context.NewsItem.Find(newsItemModel.NewsId);
            //var officeNews = new OfficeNewsItem();
            //if (newsItem.officeGroup == null)
            //{
            //    //foreach (var ofc in offices)
            //    //{
            //    //    officeNews.CdOffId = ofc;
            //    //    officeNews.NewsId = newsItem.NewsId;
            //    //    _context.OfficeNewsItem.Add(officeNews);
            //    //    _context.SaveChanges();
            //    //}
            //}
            //else
            //{
            //    foreach (var ofc in newsItem.officeGroup)
            //    {
            //        officeNews.CdOffId = ofc;
            //        officeNews.NewsId = newsItem.NewsId;
            //        _context.OfficeNewsItem.Add(officeNews);
            //        _context.SaveChanges();
            //    }
            //}
            ////_context.SaveChanges();

            return true;

        }

        public int CreateNewsItems(NewsItemDTO newsItem)
        {
            NewsItem news = new NewsItem();
            news.EmpId = newsItem.EmpId;
            news.CreateDate = DateTime.Now;
            news.AuthorName = newsItem.AuthorName;
            news.StartDate = newsItem.StartDate;
            news.EndDate = newsItem.EndDate;
            news.Subject = newsItem.Subject;
            news.NewsText = newsItem.NewsText;
            news.AllOffices = newsItem.AllOffices;
            switch (newsItem.Priority)
            {
                case "Urgent":
                    news.Priority = "A";
                    break;
                case "Normal":
                    news.Priority = "B";
                    break;
                case "Low":
                    news.Priority = "C";
                    break;
                default:
                    news.Priority = "B";
                    break;
            }
            _context.NewsItem.Add(news);
           
            _context.SaveChanges();

            var officeNews = new OfficeNewsItem();
            if (newsItem.EmployeeType == "O")
            {
                var officeid = (from e in _context.Employee
                                where e.EmpId == newsItem.EmpId
                                select e.CdOffId).First();
                officeNews.CdOffId = officeid;
                officeNews.NewsId = news.NewsId;
                _context.OfficeNewsItem.Add(officeNews);
                _context.SaveChanges();
                return news.NewsId;
            }
           
          
            if (newsItem.AllOffices)
            {
                List<RegionOfficeDTO> offices = new List<RegionOfficeDTO>();
                switch (newsItem.EmployeeType)
                {
                    case "D":
                        offices = _dSOfficeRepository.GetRegionOffices(newsItem.EmpId, "D");
                        break;
                    case "R":
                        offices = _dSOfficeRepository.GetRegionOffices(newsItem.EmpId, "R");
                        break;
                    default:
                        break;
                }
                foreach (var item in offices)
                {
                    officeNews.CdOffId = item.OfficeId;
                    officeNews.NewsId = news.NewsId;
                    _context.OfficeNewsItem.Add(officeNews);
                    _context.SaveChanges();
                }
            }
            else
            {
                foreach (var ofc in newsItem.officeGroup)
                {
                    officeNews.CdOffId = ofc;
                    officeNews.NewsId = news.NewsId;
                    _context.OfficeNewsItem.Add(officeNews);
                    _context.SaveChanges();
                }
            }
            return news.NewsId ;
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }
        public bool DeleteNewsItem(NewsItem newsitem)
        {
            //var officeNewsItems = _context.OfficeNewsItem.AsNoTracking()
            //         .Where(e => e.NewsId == newsitem.NewsId)
            //         .ToList();
            //foreach(OfficeNewsItem o in officeNewsItems)
            //{
            //    _context.OfficeNewsItem.Remove(o);
            //    _context.SaveChanges();
            //}
            _context.NewsItem.Remove(newsitem);
            return (_context.SaveChanges() >= 0); 
        }

        public bool DeleteOfficeNewsItems(NewsItem newsitem)
        {
            var officeNewsItems = _context.OfficeNewsItem.AsNoTracking()
                     .Where(e => e.NewsId == newsitem.NewsId)
                     .ToList();
            foreach (OfficeNewsItem o in officeNewsItems)
            {
                _context.OfficeNewsItem.Remove(o);
                _context.SaveChanges();
            }
            return true;
        }

    }

}
