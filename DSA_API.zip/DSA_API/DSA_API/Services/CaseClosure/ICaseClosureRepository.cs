﻿using DSA_API.Models.CaseClosure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.CaseClosure
{
    public interface ICaseClosureRepository
    {
        CCForm GetCCForm(string formID);
    }
}
