﻿using DSA_API.Entities;
using DSA_API.Models.CaseClosure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.CaseClosure
{
    public class CaseClosureRepository : ICaseClosureRepository
    {
        private DSAContext _context;
        public CaseClosureRepository(DSAContext context)
        {
            _context = context;
        }
        public CCForm GetCCForm(string formID)
        {
            CCForm f = GetEmptyCCForm();

            var l = _context.CaseClosureFormRules.Where(c => c.FormId == formID).ToList();

            foreach (var i in l)
            {
                switch (i.ControlName)
                {
                    case "FirstAuthSect1":
                        f.FirstAuthSect1.Status = i.Action;
                        f.FirstAuthSect1.Text = i.Value;
                        break;
                    case "FirstAuthSect2":
                        f.FirstAuthSect2.Status = i.Action;
                        f.FirstAuthSect2.Text = i.Value;
                        break;
                    case "FirstOriginalAuthSect":
                        f.FirstOriginalAuthSect.Status = i.Action;
                        f.FirstOriginalAuthSect.Text = i.Value;
                        break;
                    case "SecondAuthSect1":
                        f.SecondAuthSect1.Status = i.Action;
                        f.SecondAuthSect1.Text = i.Value;
                        break;
                    case "SecondAuthSect2":
                        f.SecondAuthSect2.Status = i.Action;
                        f.SecondAuthSect2.Text = i.Value;
                        break;
                    case "SecondOriginalAuthSect":
                        f.SecondOriginalAuthSect.Status = i.Action;
                        f.SecondOriginalAuthSect.Text = i.Value;
                        break;
                    case "FirstEffectiveDate":
                        f.FirstEffectiveDate.Status = i.Action;
                        if(i.Value == "today") f.FirstEffectiveDate.CCDate = DateTime.Today;
                        break;
                    case "FirstThroughDate":
                        f.FirstThroughDate.Status = i.Action;
                        if (i.Value == "today") f.FirstThroughDate.CCDate = DateTime.Today;
                        break;
                    case "OriginalEffectiveDate":
                        f.OriginalEffectiveDate.Status = i.Action;
                        if (i.Value == "today") f.OriginalEffectiveDate.CCDate = DateTime.Today;
                        break;
                    case "SecondEffectiveDate":
                        f.SecondEffectiveDate.Status = i.Action;
                        if (i.Value == "today") f.SecondEffectiveDate.CCDate = DateTime.Today;
                        break;
                    case "SecondThroughDate":
                        f.SecondThroughDate.Status = i.Action;
                        if (i.Value == "today") f.SecondThroughDate.CCDate = DateTime.Today;
                        break;
                    case "ArrestDetainDate":
                        f.ArrestDetainDate.Status = i.Action;
                        if (i.Value == "today") f.ArrestDetainDate.CCDate = DateTime.Today;
                        break;
                    case "MailDate":
                        f.MailDate.Status = i.Action;
                        if (i.Value == "today") f.MailDate.CCDate = DateTime.Today;
                        break;
                    case "UpdateCopies":
                        f.UpdateCopies.Status = i.Action;
                        f.UpdateCopies.Text = i.Value;
                        break;
                    case "CoFo":
                        f.CoFo.Status = i.Action;
                        f.CoFo.Text = i.Value;
                        break;
                    case "PMCode":
                        f.PMCode.Status = i.Action;
                        f.PMCode.Text = i.Value;
                        break;
                    case "CommercialStatusIndicator":
                        f.CommercialStatusIndicator.Status = i.Action;
                        f.CommercialStatusIndicator.Text = i.Value;
                        break;
                    case "IsAdd":
                        f.IsAdd.Status = i.Action;
                        f.IsAdd.Field = (i.Value == "1")? true : false;
                        break;
                    case "IsDelete":
                        f.IsDelete.Status = i.Action;
                        f.IsDelete.Field = (i.Value == "1") ? true : false;
                        break;
                    case "Restriction1":
                        f.Restriction1.Status = i.Action;
                        f.Restriction1.Text = i.Value;
                        break;
                    case "Restriction2":
                        f.Restriction2.Status = i.Action;
                        f.Restriction2.Text = i.Value;
                        break;
                    case "Restriction3":
                        f.Restriction3.Status = i.Action;
                        f.Restriction3.Text = i.Value;
                        break;
                    case "IsAPS":
                        f.IsAPS.Status = i.Action;
                        f.IsAPS.Field = (i.Value == "1") ? true : false;
                        break;
                    case "IsAPSRefusal":
                        f.IsAPSRefusal.Status = i.Action;
                        f.IsAPSRefusal.Field = (i.Value == "1") ? true : false;
                        break;
                    case "IsPAS":
                        f.IsPAS.Status = i.Action;
                        f.IsPAS.Field = (i.Value == "1") ? true : false;
                        break;
                    case "IsPASRefusal":
                        f.IsPASRefusal.Status = i.Action;
                        f.IsPASRefusal.Field = (i.Value == "1") ? true : false;
                        break;
                    case "IsVOPBAC":
                        f.IsVOPBAC.Status = i.Action;
                        f.IsVOPBAC.Field = (i.Value == "1") ? true : false;
                        break;
                    case "IsVOPRefusal":
                        f.IsVOPRefusal.Status = i.Action;
                        f.IsVOPRefusal.Field = (i.Value == "1") ? true : false;
                        break;
                    case "FieldFile":
                        f.FieldFile.Status = i.Action;
                        f.FieldFile.Text = i.Value;
                        break;
                    case "RouteCode":
                        f.RouteCode.Status = i.Action;
                        f.RouteCode.Text = i.Value;
                        break;
                    case "MedicalSuspence":
                        f.MedicalSuspence.Status = i.Action;
                        f.MedicalSuspence.Text = i.Value;
                        break;
                    case "CreditDays":
                        f.CreditDays.Status = i.Action;
                        f.CreditDays.Text = i.Value;
                        break;
                    case "InsertParagraph":
                        f.InsertParagraph.Status = i.Action;
                        f.InsertParagraph.Text = i.Value;
                        break;
                    case "CountyCode":
                        f.CountyCode.Status = i.Action;
                        f.CountyCode.Text = i.Value;
                        break;
                    case "LicenceLocation":
                        f.LicenceLocation.Status = i.Action;
                        f.LicenceLocation.Text = i.Value;
                        break;
                    case "OSDLNumber":
                        f.OSDLNumber.Status = i.Action;
                        f.OSDLNumber.Text = i.Value;
                        break;
                    case "OSCode":
                        f.OSCode.Status = i.Action;
                        f.OSCode.Text = i.Value;
                        break;
                    case "SecondReasonCode":
                        f.SecondReasonCode.Status = i.Action;
                        f.SecondReasonCode.Text = i.Value;
                        break;
                    case "ProbationSuspance01opt":
                        f.ProbationSuspance01opt.Status = i.Action;
                        f.ProbationSuspance01opt.Field = (i.Value == "1") ? true : false;
                        break;
                    case "ServiceOfOrderOpt":
                        f.ServiceOfOrderOpt.Status = i.Action;
                        f.ServiceOfOrderOpt.Field = (i.Value == "1") ? true : false;
                        break;
                    case "MedicalSuspenceDueDate":
                        f.MedicalSuspenceDueDate.Status = i.Action;
                        f.MedicalSuspenceDueDate.Text = i.Value;
                        break;
                    default:
                        break;
                }
            }

            return f;
        }
        public CCForm GetEmptyCCForm()
        {
            string defult = "0";
            var f = new CCForm();
            f.FirstAuthSect1.Status = defult;
            f.FirstAuthSect2.Status = defult;
            f.FirstOriginalAuthSect.Status = defult;
            f.SecondAuthSect1.Status = defult;
            f.SecondAuthSect2.Status = defult;
            f.SecondOriginalAuthSect.Status = defult;

            f.FirstEffectiveDate.Status = defult;
            f.FirstThroughDate.Status = defult;
            f.OriginalEffectiveDate.Status = defult;
            f.SecondEffectiveDate.Status = defult;
            f.SecondThroughDate.Status = defult;
            f.ArrestDetainDate.Status = defult;
            f.MailDate.Status = defult;

            f.UpdateCopies.Status = defult;
            f.CoFo.Status = defult;
            f.PMCode.Status = defult;
            f.CommercialStatusIndicator.Status = defult;

            f.IsAdd.Status = defult;
            f.IsDelete.Status = defult;
            f.Restriction1.Status = defult;
            f.Restriction2.Status = defult;
            f.Restriction3.Status = defult;

            f.IsAPS.Status = defult;
            f.IsAPSRefusal.Status = defult;
            f.IsPAS.Status = defult;
            f.IsPASRefusal.Status = defult;

            f.IsVOPBAC.Status = defult;
            f.IsVOPRefusal.Status = defult;
            
            f.FieldFile.Status = defult;
            f.RouteCode.Status = defult;
            f.MedicalSuspence.Status = defult;
            f.CreditDays.Status = defult;
            f.InsertParagraph.Status = defult;
            f.CountyCode.Status = defult;
            f.LicenceLocation.Status = defult;

            f.OSDLNumber.Status = defult;
            f.OSCode.Status = defult;

            f.ProbationSuspance01opt.Status = defult;
            f.ServiceOfOrderOpt.Status = defult;
            f.MedicalSuspenceDueDate.Status = defult;

            return f;
        }
    }
}
