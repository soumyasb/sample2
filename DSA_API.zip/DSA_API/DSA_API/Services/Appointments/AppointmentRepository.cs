﻿using DSA_API.Entities;
using DSA_API.Models.Appointments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DSA_API.Models.DataManager;
using DSA_API.Models.EmployeeProfile;

namespace DSA_API.Services.Appointments
{
    public class AppointmentRepository : IAppointmentRepository
    {
        private DSAContext _context;
        public AppointmentRepository(DSAContext context)
        {
            _context = context;
        }
        public EmployeeAppointmentDTO GetEmployeeAppointment(int AppointmentId)
        {

            var app = (from a in _context.Appointment.AsNoTracking()
                       where (a.AppointmentId == AppointmentId && a.FlgDelete != "1")
                       select new EmployeeAppointmentDTO()
                       {
                           AppointmentId = a.AppointmentId,
                           ReacurrenceNumber = a.NbrRcurApt,
                           ActivityType = a.CdActvyTyp,
                           DayType = a.CdDayTyp,
                           DayOfTheWeek = a.CdDteTyp,
                           EmpId = a.EmpId.Value,
                           MonthOfTheYear = a.CdMonTyp,
                           DayOfTheMonth = a.CdOccDayTyp,
                           OccuranceType = a.CdOccTyp,
                           UpdatedBy = a.CdUpdtTechId,
                           StartTime = a.DtStrtTim,
                           EndTime = a.DtEndTim,
                           DateUpdated = a.DtUpdtTrans,
                           isDispayComment = (a.FlgDispCmt == "1") ? true : false,
                           Comment = a.TxtComment,
                           AppointmentNumber = a.NbrAppt,
                           isAllDay = (a.FlgAllDay == "1") ? true : false,
                           //isDeleted = (a.FlgDelete == "1") ? true : false
                       }).FirstOrDefault();

            return app;
        }
        public IEnumerable<EmployeeAppointmentDTO> GetEmployeeAppointmentByEmployees(List<int> EmpIdList)
        {

            if (EmpIdList.Count == 1)
            {
                var appList = (from a in _context.Appointment.AsNoTracking()
                               where (a.EmpId == EmpIdList.First() && a.FlgDelete != "1")
                               select new EmployeeAppointmentDTO()
                               {
                                   AppointmentId = a.AppointmentId,
                                   ReacurrenceNumber = a.NbrRcurApt,
                                   ActivityType = a.CdActvyTyp,
                                   DayType = a.CdDayTyp,
                                   DayOfTheWeek = a.CdDteTyp,
                                   EmpId = a.EmpId.Value,
                                   MonthOfTheYear = a.CdMonTyp,
                                   DayOfTheMonth = a.CdOccDayTyp,
                                   OccuranceType = a.CdOccTyp,
                                   UpdatedBy = a.CdUpdtTechId,
                                   StartTime = a.DtStrtTim,
                                   EndTime = a.DtEndTim,
                                   DateUpdated = a.DtUpdtTrans,
                                   isDispayComment = (a.FlgDispCmt == "1") ? true : false,
                                   Comment = a.TxtComment,
                                   AppointmentNumber = a.NbrAppt,
                                   isAllDay = (a.FlgAllDay == "1") ? true : false,
                                   //isDeleted = (a.FlgDelete == "1") ? true : false
                               }).ToList();

                return appList;
            }
            else
            {

                var match = _context.Appointment.AsNoTracking()
                    .Where(a => EmpIdList.Any(e => a.EmpId == e))
                    .GroupBy(g => new { g.NbrRcurApt, g.NbrAppt })
                    .Where(g => g.Count() == EmpIdList.Count())
                    .Select(a => a.Key)
                    .ToList();

                //var idList = _context.Appointment.AsNoTracking().Where(a => match.Any(m => m.NbrAppt == a.NbrAppt && m.NbrAppt == a.NbrAppt));

                var appList = (from a in _context.Appointment.AsNoTracking()
                               where (match.Any(m => a.NbrRcurApt == m.NbrRcurApt && a.NbrAppt == m.NbrAppt) && a.FlgDelete != "1")
                               group a by new
                               {
                                   a.NbrRcurApt,
                                   a.CdActvyTyp,
                                   a.CdDayTyp,
                                   a.CdDteTyp,
                                   a.CdMonTyp,
                                   a.CdOccDayTyp,
                                   a.CdOccTyp,
                                   a.CdUpdtTechId,
                                   a.DtStrtTim,
                                   a.DtEndTim,
                                   a.DtUpdtTrans,
                                   a.NbrAppt,
                                   a.FlgDispCmt,
                                   a.TxtComment,
                                   a.FlgAllDay
                               } into g
                               select new EmployeeAppointmentDTO()
                               {
                                   AppointmentId = 0,
                                   ReacurrenceNumber = g.Key.NbrRcurApt,
                                   ActivityType = g.Key.CdActvyTyp,
                                   DayType = g.Key.CdDayTyp,
                                   DayOfTheWeek = g.Key.CdDteTyp,
                                   EmpId = 0,
                                   MonthOfTheYear = g.Key.CdMonTyp,
                                   DayOfTheMonth = g.Key.CdOccDayTyp,
                                   OccuranceType = g.Key.CdOccTyp,
                                   UpdatedBy = g.Key.CdUpdtTechId,
                                   StartTime = g.Key.DtStrtTim,
                                   EndTime = g.Key.DtEndTim,
                                   DateUpdated = g.Key.DtUpdtTrans,
                                   isDispayComment = (g.Key.FlgDispCmt == "1") ? true : false,
                                   Comment = g.Key.TxtComment,
                                   AppointmentNumber = g.Key.NbrAppt,
                                   isAllDay = (g.Key.FlgAllDay == "1") ? true : false,
                                   //isDeleted = (a.FlgDelete == "1") ? true : false
                               }).ToList();
                //var l =appList.Distinct();
                return appList;
            }

        }
        public IEnumerable<EmployeeAppointmentDTO> GetEmployeeAppointmentByReacurrenceNumber(int ReacurrenceNumber, int? AppointmentNumber)
        {

            var appList = (from a in _context.Appointment.AsNoTracking()
                           where (a.NbrRcurApt == ReacurrenceNumber && a.FlgDelete != "1" && a.NbrAppt == AppointmentNumber)
                           select new EmployeeAppointmentDTO()
                           {
                               AppointmentId = a.AppointmentId,
                               ReacurrenceNumber = a.NbrRcurApt,
                               ActivityType = a.CdActvyTyp,
                               DayType = a.CdDayTyp,
                               DayOfTheWeek = a.CdDteTyp,
                               EmpId = a.EmpId.Value,
                               MonthOfTheYear = a.CdMonTyp,
                               DayOfTheMonth = a.CdOccDayTyp,
                               OccuranceType = a.CdOccTyp,
                               UpdatedBy = a.CdUpdtTechId,
                               StartTime = a.DtStrtTim,
                               EndTime = a.DtEndTim,
                               DateUpdated = a.DtUpdtTrans,
                               isDispayComment = (a.FlgDispCmt == "1") ? true : false,
                               Comment = a.TxtComment,
                               AppointmentNumber = a.NbrAppt,
                               isAllDay = (a.FlgAllDay == "1") ? true : false,
                               //isDeleted = (a.FlgDelete == "1") ? true : false
                           }).ToList();

            return appList;
        }
        public Appointment ConvertEmployeeAppointment(EmployeeAppointmentDTO app)
        {
            Appointment a = new Appointment();
            a.AppointmentId = app.AppointmentId;
            a.NbrRcurApt = app.ReacurrenceNumber;
            a.CdActvyTyp = app.ActivityType;
            a.CdDayTyp = app.DayType;
            a.CdDteTyp = app.DayOfTheWeek;
            a.EmpId = app.EmpId;
            a.CdMonTyp = app.MonthOfTheYear;
            a.CdOccDayTyp = app.DayOfTheMonth;
            a.CdOccTyp = app.OccuranceType;
            a.CdUpdtTechId = app.UpdatedBy;
            a.DtStrtTim = app.StartTime;
            a.DtEndTim = app.EndTime;
            a.DtUpdtTrans = app.DateUpdated;
            a.FlgDispCmt = (app.isDispayComment) ? "1" : "0";
            a.TxtComment = app.Comment;
            a.NbrAppt = app.AppointmentNumber;
            a.FlgAllDay = (app.isAllDay) ? "1" : "0";
            a.FlgDelete = "0";
            return a;
        }
        public EmployeeAppointmentDTO GetDefultAppointment()
        {
            var a = new EmployeeAppointmentDTO()
            {
                AppointmentId = 0,
                ReacurrenceNumber = 0,
                ActivityType = "A",
                DayType = null,
                DayOfTheWeek = null,
                EmpId = 0,
                MonthOfTheYear = null,
                DayOfTheMonth = null,
                OccuranceType = null,
                UpdatedBy = null,
                StartTime = DateTime.Today,
                EndTime = DateTime.Today,
                DateUpdated = null,
                isDispayComment = false,
                Comment = null,
                AppointmentNumber = null,
                isAllDay = false,
                //isDeleted = false
            };


            return a;
        }

        public IEnumerable<ActivityTypeDTO> GetActivityType()
        {

            var appList = (from a in _context.Activitytype.AsNoTracking()
                           where a.CdTypes == "H" && a.DtTerm == null
                           select new ActivityTypeDTO()
                           {
                               ActivityTypeId = a.Id,
                               Code = a.CdActvyTyp,
                               Description = a.DescActvyTyp,
                               Abbriviation = a.TxtActvyAbbr,
                               Types = a.CdTypes,
                               isConfidential = (a.FlgConfTyp == 1) ? true : false,
                               TeminationDate = a.DtTerm,
                               UpdatedBy = null, //TODO: Change DB table to have EmpId
                               UpdateDate = a.LastUpdatedDate

                           }).ToList();

            return appList;
        }


        public HearingRoomAppointmentDTO GetHearingRoomAppointment(int AppointmentId)
        {

            var app = (from a in _context.Appointment.AsNoTracking()
                       where (a.AppointmentId == AppointmentId && a.FlgDelete != "1")
                       select new HearingRoomAppointmentDTO()
                       {
                           AppointmentId = a.AppointmentId,
                           ReacurrenceNumber = a.NbrRcurApt,
                           //ActivityType = a.CdActvyTyp,
                           DayType = a.CdDayTyp,
                           DayOfTheWeek = a.CdDteTyp,
                           HearingRoomId = a.HearingLocaitonId.Value,
                           MonthOfTheYear = a.CdMonTyp,
                           DayOfTheMonth = a.CdOccDayTyp,
                           OccuranceType = a.CdOccTyp,
                           UpdatedBy = a.CdUpdtTechId,
                           StartTime = a.DtStrtTim,
                           EndTime = a.DtEndTim,
                           DateUpdated = a.DtUpdtTrans,
                           isDispayComment = (a.FlgDispCmt == "1") ? true : false,
                           Comment = a.TxtComment,
                           AppointmentNumber = a.NbrAppt,
                           isAllDay = (a.FlgAllDay == "1") ? true : false,
                           //isDeleted = (a.FlgDelete == "1") ? true : false
                       }).FirstOrDefault();

            return app;
        }
        public IEnumerable<HearingRoomAppointmentDTO> GetHearingRoomAppointmentByHearingRoom(int HearingLocationId)
        {

            var appList = (from a in _context.Appointment.AsNoTracking()
                           where (a.HearingLocaitonId == HearingLocationId && a.FlgDelete != "1")
                           select new HearingRoomAppointmentDTO()
                           {
                               AppointmentId = a.AppointmentId,
                               ReacurrenceNumber = a.NbrRcurApt,
                               //ActivityType = a.CdActvyTyp,
                               DayType = a.CdDayTyp,
                               DayOfTheWeek = a.CdDteTyp,
                               HearingRoomId = a.HearingLocaitonId.Value,
                               MonthOfTheYear = a.CdMonTyp,
                               DayOfTheMonth = a.CdOccDayTyp,
                               OccuranceType = a.CdOccTyp,
                               UpdatedBy = a.CdUpdtTechId,
                               StartTime = a.DtStrtTim,
                               EndTime = a.DtEndTim,
                               DateUpdated = a.DtUpdtTrans,
                               isDispayComment = (a.FlgDispCmt == "1") ? true : false,
                               Comment = a.TxtComment,
                               AppointmentNumber = a.NbrAppt,
                               isAllDay = (a.FlgAllDay == "1") ? true : false,
                               //isDeleted = (a.FlgDelete == "1") ? true : false
                           }).ToList();

            return appList;
        }
        public IEnumerable<HearingRoomAppointmentDTO> GetHearingRoomAppointmentByReacurrenceNumber(int ReacurrenceNumber, int? AppointmentNumber)
        {

            var appList = (from a in _context.Appointment.AsNoTracking()
                           where (a.NbrRcurApt == ReacurrenceNumber && a.FlgDelete != "1" && a.NbrAppt == AppointmentNumber)
                           select new HearingRoomAppointmentDTO()
                           {
                               AppointmentId = a.AppointmentId,
                               ReacurrenceNumber = a.NbrRcurApt,
                               //ActivityType = a.CdActvyTyp,
                               DayType = a.CdDayTyp,
                               DayOfTheWeek = a.CdDteTyp,
                               HearingRoomId = a.HearingLocaitonId.Value,
                               MonthOfTheYear = a.CdMonTyp,
                               DayOfTheMonth = a.CdOccDayTyp,
                               OccuranceType = a.CdOccTyp,
                               UpdatedBy = a.CdUpdtTechId,
                               StartTime = a.DtStrtTim,
                               EndTime = a.DtEndTim,
                               DateUpdated = a.DtUpdtTrans,
                               isDispayComment = (a.FlgDispCmt == "1") ? true : false,
                               Comment = a.TxtComment,
                               AppointmentNumber = a.NbrAppt,
                               isAllDay = (a.FlgAllDay == "1") ? true : false,
                               //isDeleted = (a.FlgDelete == "1") ? true : false
                           }).ToList();

            return appList;
        }
        public Appointment ConvertEmployeeAppointment(HearingRoomAppointmentDTO app)
        {
            Appointment a = new Appointment();
            a.AppointmentId = app.AppointmentId;
            a.NbrRcurApt = app.ReacurrenceNumber;
            a.CdActvyTyp = "";
            a.CdDayTyp = app.DayType;
            a.CdDteTyp = app.DayOfTheWeek;
            a.HearingLocaitonId = app.HearingRoomId;
            a.CdMonTyp = app.MonthOfTheYear;
            a.CdOccDayTyp = app.DayOfTheMonth;
            a.CdOccTyp = app.OccuranceType;
            a.CdUpdtTechId = app.UpdatedBy;
            a.DtStrtTim = app.StartTime;
            a.DtEndTim = app.EndTime;
            a.DtUpdtTrans = app.DateUpdated;
            a.FlgDispCmt = (app.isDispayComment) ? "1" : "0";
            a.TxtComment = app.Comment;
            a.NbrAppt = app.AppointmentNumber;
            a.FlgAllDay = (app.isAllDay) ? "1" : "0";
            a.FlgDelete = "0";
            return a;
        }
        public HearingRoomAppointmentDTO GetDefultHearingRoomAppointment()
        {
            var a = new HearingRoomAppointmentDTO()
            {
                AppointmentId = 0,
                ReacurrenceNumber = 0,
                //ActivityType = "A",
                DayType = null,
                DayOfTheWeek = null,
                HearingRoomId = 0,
                MonthOfTheYear = null,
                DayOfTheMonth = null,
                OccuranceType = null,
                UpdatedBy = null,
                StartTime = DateTime.Today,
                EndTime = DateTime.Today,
                DateUpdated = null,
                isDispayComment = false,
                Comment = null,
                AppointmentNumber = null,
                isAllDay = false
                //isDeleted = false
            };
            
            return a;
        }

        public List<DateRangeDTO> CalculateReacuranceRoom(HearingRoomAppointmentDTO ReaccuringApp, DateTime Start, DateTime End)
        {
            EmployeeAppointmentDTO app = new EmployeeAppointmentDTO()
            {
                AppointmentId = 0,
                ReacurrenceNumber = 0,
                //ActivityType = "A",
                DayType = ReaccuringApp.DayType,
                DayOfTheWeek = ReaccuringApp.DayOfTheWeek,
                EmpId = 0,
                MonthOfTheYear = ReaccuringApp.MonthOfTheYear,
                DayOfTheMonth = ReaccuringApp.DayOfTheMonth,
                OccuranceType = ReaccuringApp.OccuranceType,
                UpdatedBy = null,
                StartTime = ReaccuringApp.StartTime,
                EndTime = ReaccuringApp.EndTime,
                DateUpdated = null,
                isDispayComment = false,
                Comment = null,
                AppointmentNumber = ReaccuringApp.AppointmentNumber,
                isAllDay = ReaccuringApp.isAllDay
            };

            return CalculateReacurance(app, Start, End);
        }

        public List<DateRangeDTO> CalculateReacurance(EmployeeAppointmentDTO ReaccuringApp, DateTime Start, DateTime End)
        {
            var l = new List<DateRangeDTO>();

            DateTime s = (ReaccuringApp.StartTime > Start) ? ReaccuringApp.StartTime : Start;
            DateTime e = (ReaccuringApp.EndTime < End) ? ReaccuringApp.EndTime : End;

            // IF All DAY
            if(ReaccuringApp.isAllDay)
            {
                s = s.Date;
                e = new DateTime(e.Year, e.Month, e.Day, 23,59,59);
            }

            DateTime temp = s.Date;
            DateTime sTemp = new DateTime();
            DateTime eTemp = new DateTime();
            
            if (ReaccuringApp.OccuranceType == "D")
            {
                if (ReaccuringApp.DayType == "1")
                {
                    while (!(temp.Date > e.Date))
                    {
                        sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                        eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);

                        l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                        temp = temp.AddDays(1);
                    }
                }
                else
                {
                    while (!(temp.Date > e.Date))
                    {
                        if (temp.DayOfWeek != DayOfWeek.Saturday || temp.DayOfWeek != DayOfWeek.Sunday)
                        {
                            sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                            eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);

                            l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                        }
                        
                        temp = temp.AddDays(1);
                    }

                }
            }
            else if(ReaccuringApp.OccuranceType == "W")
            {
                DayOfWeek pDayOfWeek =new DayOfWeek();
                if (ReaccuringApp.DayOfTheWeek == "1") { pDayOfWeek = DayOfWeek.Sunday; }
                else if (ReaccuringApp.DayOfTheWeek == "2") { pDayOfWeek = DayOfWeek.Monday; }
                else if (ReaccuringApp.DayOfTheWeek == "3") { pDayOfWeek = DayOfWeek.Tuesday; }
                else if (ReaccuringApp.DayOfTheWeek == "4") { pDayOfWeek = DayOfWeek.Wednesday; }
                else if (ReaccuringApp.DayOfTheWeek == "5") { pDayOfWeek = DayOfWeek.Thursday; }
                else if (ReaccuringApp.DayOfTheWeek == "6") { pDayOfWeek = DayOfWeek.Friday; }
                else if (ReaccuringApp.DayOfTheWeek == "7") { pDayOfWeek = DayOfWeek.Saturday; }

                while (!(temp.Date > e.Date))
                {
                    if (temp.DayOfWeek == pDayOfWeek)
                    {
                        sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                        eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);
                        l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                    }
                    temp = temp.AddDays(1);
                }
            }
            else if (ReaccuringApp.OccuranceType == "M")
            {
                if (ReaccuringApp.DayOfTheMonth != null)
                {
                    int pDayOfMonth; 
                    Int32.TryParse(ReaccuringApp.DayOfTheWeek, out pDayOfMonth);
                    
                    while (!(temp.Date > e.Date))
                    {
                        if (temp.Day == pDayOfMonth)
                        {
                            sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                            eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);
                            l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                            temp = temp.AddMonths(1);
                        }
                        else
                        {
                            temp = temp.AddDays(1);
                        }
                    }
                }
                else if(ReaccuringApp.DayOfTheWeek != null && ReaccuringApp.DayType != null)
                {
                    DayOfWeek pDayOfWeek = new DayOfWeek();
                    if (ReaccuringApp.DayOfTheWeek == "1") { pDayOfWeek = DayOfWeek.Sunday; }
                    else if (ReaccuringApp.DayOfTheWeek == "2") { pDayOfWeek = DayOfWeek.Monday; }
                    else if (ReaccuringApp.DayOfTheWeek == "3") { pDayOfWeek = DayOfWeek.Tuesday; }
                    else if (ReaccuringApp.DayOfTheWeek == "4") { pDayOfWeek = DayOfWeek.Wednesday; }
                    else if (ReaccuringApp.DayOfTheWeek == "5") { pDayOfWeek = DayOfWeek.Thursday; }
                    else if (ReaccuringApp.DayOfTheWeek == "6") { pDayOfWeek = DayOfWeek.Friday; }
                    else if (ReaccuringApp.DayOfTheWeek == "7") { pDayOfWeek = DayOfWeek.Saturday; }

                    temp = new DateTime(temp.Year, temp.Month, 1);

                    while (!(temp.Date >= e.Date))
                    {
                        
                        if (ReaccuringApp.DayType != "L")
                        {
                            int pDayType;
                            Int32.TryParse(ReaccuringApp.DayType, out pDayType);

                            while (temp.DayOfWeek != pDayOfWeek)
                            {
                                temp = temp.AddDays(1);
                            }
                            temp = temp.AddDays((pDayType - 1) * 7);
                        }
                        else
                        {
                            // Last week
                            temp = temp.AddMonths(1);
                            while (temp.DayOfWeek != pDayOfWeek)
                            {
                                temp = temp.AddDays(-1);
                            }
                        }
                        if(temp.Date >= s.Date && temp.Date <= e.Date)
                        {
                            sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                            eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);
                            l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                        }
                        
                        temp = new DateTime(temp.Year, temp.Month + 1, 1);

                    }
                }
            }
            else if (ReaccuringApp.OccuranceType == "Y")
            {
                if (ReaccuringApp.DayOfTheMonth != null && ReaccuringApp.MonthOfTheYear != null)
                {
                    int pDayOfMonth; 
                    Int32.TryParse(ReaccuringApp.DayOfTheMonth, out pDayOfMonth);
                    int pMonthOfYear;
                    Int32.TryParse(ReaccuringApp.MonthOfTheYear, out pMonthOfYear);

                    temp = new DateTime(temp.Year, pMonthOfYear, pDayOfMonth);
                    if(temp.Date < s.Date)
                    {
                        temp = temp.AddYears(1);
                    }
                    while (!(temp.Date > e.Date))
                    {
                        sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                        eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);
                        l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                        temp = temp.AddYears(1);
                    }

                }

                else if (ReaccuringApp.DayOfTheWeek != null && ReaccuringApp.DayType != null && ReaccuringApp.MonthOfTheYear !=null)
                {
                    DayOfWeek pDayOfWeek = new DayOfWeek();
                    if (ReaccuringApp.DayOfTheWeek == "1") { pDayOfWeek = DayOfWeek.Sunday; }
                    else if (ReaccuringApp.DayOfTheWeek == "2") { pDayOfWeek = DayOfWeek.Monday; }
                    else if (ReaccuringApp.DayOfTheWeek == "3") { pDayOfWeek = DayOfWeek.Tuesday; }
                    else if (ReaccuringApp.DayOfTheWeek == "4") { pDayOfWeek = DayOfWeek.Wednesday; }
                    else if (ReaccuringApp.DayOfTheWeek == "5") { pDayOfWeek = DayOfWeek.Thursday; }
                    else if (ReaccuringApp.DayOfTheWeek == "6") { pDayOfWeek = DayOfWeek.Friday; }
                    else if (ReaccuringApp.DayOfTheWeek == "7") { pDayOfWeek = DayOfWeek.Saturday; }
                    int pMonth;
                    Int32.TryParse(ReaccuringApp.MonthOfTheYear, out pMonth);

                    if(pMonth < s.Month)
                    {
                        temp = new DateTime(temp.Year + 1, pMonth, 1);
                    }
                    else
                    {
                        temp = new DateTime(temp.Year, pMonth, 1);
                    }
                    
                    while (!(temp.Date >= e.Date))
                    {

                        if (ReaccuringApp.DayType != "L")
                        {
                            int pDayType;
                            Int32.TryParse(ReaccuringApp.DayType, out pDayType);

                            while (temp.DayOfWeek != pDayOfWeek)
                            {
                                temp = temp.AddDays(1);
                            }
                            temp = temp.AddDays((pDayType - 1) * 7);
                        }
                        else
                        {
                            // Last week
                            temp = temp.AddMonths(1);
                            while (temp.DayOfWeek != pDayOfWeek)
                            {
                                temp = temp.AddDays(-1);
                            }
                        }
                        if (temp.Date >= s.Date && temp.Date <= e.Date)
                        {
                            sTemp = new DateTime(temp.Year, temp.Month, temp.Day, s.Hour, s.Minute, s.Second);
                            eTemp = new DateTime(temp.Year, temp.Month, temp.Day, e.Hour, e.Minute, e.Second);
                            l.Add(new DateRangeDTO { Start = sTemp, End = eTemp });
                        }

                        temp = new DateTime(temp.Year + 1, temp.Month, 1);
                    }
                }

            }
            return l;
        }

        public List<ConflictDTO> ScheuledHearingConflicts(List<DateRangeDTO> AppRangeList, int EmpId)
        {
            var l = new List<ConflictDTO>();

            foreach (var c1 in AppRangeList)
            {
                var contacts = _context.Contact
                .Where(a => a.EmpId == EmpId &&
                    (a.CdStatus2 == "3" || a.CdStatus2 == "4") &&
                    (a.DtCntctStrtTim >= c1.Start && a.DtCntctStrtTim <= c1.End ||
                     a.DtCntctEndTim >= c1.Start && a.DtCntctEndTim <= c1.End ||
                     a.DtCntctStrtTim <= c1.Start && a.DtCntctEndTim >= c1.End))
                     .Select(p => new ConflictDTO()
                     {
                         CaseNumber = p.CdCase,
                         ConflictDateTimeStart = p.DtCntctStrtTim,
                         ConfilctDateTimeEnd = p.DtCntctEndTim,
                         OfficeId = p.CdOffId,
                         EmpID = p.EmpId
                     })
                     .ToList();

                l.AddRange(contacts);
            }
            
            return l;
        }
        public List<ConflictDTO> ScheuledHearingConflictsRoom(List<DateRangeDTO> AppRangeList, int RoomId)
        {
            var l = new List<ConflictDTO>();

            foreach (var c1 in AppRangeList)
            {
                
                var room = _context.Hearinglocation.Where(r => r.Id == RoomId).FirstOrDefault();
                var contacts = _context.Contact
                .Where(a => a.NbrRoom == room.NbrRoom && a.CdOffId == room.CdOffId && //TODO: Update to Location ID
                    (a.DtCntctStrtTim >= c1.Start && a.DtCntctStrtTim <= c1.End ||
                     a.DtCntctEndTim >= c1.Start && a.DtCntctEndTim <= c1.End ||
                     a.DtCntctStrtTim <= c1.Start && a.DtCntctEndTim >= c1.End))
                     .Select(p => new ConflictDTO()
                     {
                         CaseNumber = p.CdCase,
                         ConflictDateTimeStart = p.DtCntctStrtTim,
                         ConfilctDateTimeEnd = p.DtCntctEndTim,
                         OfficeId = p.CdOffId,
                         EmpID = p.EmpId
                     })
                     .ToList();

                l.AddRange(contacts);
            }

            return l;
        }


    }
}
