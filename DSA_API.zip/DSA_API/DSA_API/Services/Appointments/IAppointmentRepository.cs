﻿using DSA_API.Entities;
using DSA_API.Models.Appointments;
using DSA_API.Models.EmployeeProfile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services.Appointments
{
    public interface IAppointmentRepository
    {
        EmployeeAppointmentDTO GetEmployeeAppointment(int AppointmentId);
        IEnumerable<EmployeeAppointmentDTO> GetEmployeeAppointmentByEmployees(List<int> EmpId);
        Appointment ConvertEmployeeAppointment(EmployeeAppointmentDTO app);
        IEnumerable<EmployeeAppointmentDTO> GetEmployeeAppointmentByReacurrenceNumber(int ReacurrenceNumber, int? AppointmentNumber);
        IEnumerable<ActivityTypeDTO> GetActivityType();
        EmployeeAppointmentDTO GetDefultAppointment();
        HearingRoomAppointmentDTO GetHearingRoomAppointment(int AppointmentId);
        IEnumerable<HearingRoomAppointmentDTO> GetHearingRoomAppointmentByHearingRoom(int HearingLocationId);
        IEnumerable<HearingRoomAppointmentDTO> GetHearingRoomAppointmentByReacurrenceNumber(int ReacurrenceNumber, int? AppointmentNumber);
        Appointment ConvertEmployeeAppointment(HearingRoomAppointmentDTO app);
        HearingRoomAppointmentDTO GetDefultHearingRoomAppointment();
        List<DateRangeDTO> CalculateReacurance(EmployeeAppointmentDTO ReaccuringApp, DateTime Start, DateTime End);
        List<ConflictDTO> ScheuledHearingConflicts(List<DateRangeDTO> AppRangeList, int EmpId);
        List<ConflictDTO> ScheuledHearingConflictsRoom(List<DateRangeDTO> AppRangeList, int RoomId);
        List<DateRangeDTO> CalculateReacuranceRoom(HearingRoomAppointmentDTO ReaccuringApp, DateTime Start, DateTime End);



    }
}
