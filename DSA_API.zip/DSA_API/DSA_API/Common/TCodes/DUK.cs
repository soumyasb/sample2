﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;


namespace DSA_API.Common.TCodes
{
    public class DUK
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUK(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DUKUIDTO ProcessDUK(DUKUIDTO duk)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");


            var results = ProcessDUKTransaction(duk);
            if (results.Error)
            {
                return results;
            }
            else
            {
                var x = _commonRepository.UpdateDLStats(duk.Operator, duk.DLNumber, "DUK", duk.ThreeCharacterLastName);
                return results;
            }
        }
        private DUKUIDTO ProcessDUKTransaction(DUKUIDTO dukdto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";


            if (!string.IsNullOrEmpty(dukdto.Code1) && (dukdto.Code1 == "I"))
            {
                if (dukdto.Info1.Length > 2)
                {
                    dukdto.Code1 = "I";
                    dukdto.Info1 = dukdto.Info1.Substring(0, 2);
                    dukdto.Process2 = dukdto.Process1;
                    dukdto.Code2 = "I";
                    dukdto.Info2 = dukdto.Info2.Substring(2, 2);
                }
                if (dukdto.Info1.Length > 4)
                {
                    dukdto.Code1 = "I";
                    dukdto.Info1 = dukdto.Info1.Substring(0, 2);
                    dukdto.Process2 = dukdto.Process1;
                    dukdto.Code2 = "I";
                    dukdto.Info2 = dukdto.Info2.Substring(2, 2);
                    dukdto.Process3 = dukdto.Process1;
                    dukdto.Code3 = "I";
                    dukdto.Info3 = dukdto.Info2.Substring(4, 2);
                }
            }

            DUKUpdateDTO DTO = new DUKUpdateDTO()
            {
                SBAREQCODE = dukdto.RequestorCode,
                SBAOPERATOR = dukdto.Operator,
                SBADLNUMBER = dukdto.DLNumber,
                SBALASTNAME = dukdto.ThreeCharacterLastName,
                SBAACD1 = !string.IsNullOrEmpty(dukdto.Process1) ? dukdto.Process1 : null,
                SBACODE1 = !string.IsNullOrEmpty(dukdto.Code1) ? dukdto.Code1 : null,
                SBADATA1 = !string.IsNullOrEmpty(dukdto.Info1) ? dukdto.Info1 : null,
                SBAACD2 = !string.IsNullOrEmpty(dukdto.Process2) ? dukdto.Process2 : null,
                SBACODE2 = !string.IsNullOrEmpty(dukdto.Code2) ? dukdto.Code2 : null,
                SBADATA2 = !string.IsNullOrEmpty(dukdto.Info2) ? dukdto.Info2 : null,
                SBAACD3 = !string.IsNullOrEmpty(dukdto.Process3) ? dukdto.Process3 : null,
                SBACODE3 = !string.IsNullOrEmpty(dukdto.Code3) ? dukdto.Code3 : null,
                SBADATA3 = !string.IsNullOrEmpty(dukdto.Info3) ? dukdto.Info3 : null,
                SBAPROCCODE = !string.IsNullOrEmpty(dukdto.CommentNumber) && !string.IsNullOrEmpty(dukdto.CommentPurgeDate) && !string.IsNullOrEmpty(dukdto.Comment) ? "A" : null,
                SBACODE4 = !string.IsNullOrEmpty(dukdto.CommentNumber) && !string.IsNullOrEmpty(dukdto.CommentPurgeDate) && !string.IsNullOrEmpty(dukdto.Comment) ? "C" : null,
                SBACOMMNUMBER = !string.IsNullOrEmpty(dukdto.CommentNumber) && !string.IsNullOrEmpty(dukdto.CommentPurgeDate) && !string.IsNullOrEmpty(dukdto.Comment) ? dukdto.CommentNumber : null,
                SBAPURGEDATE1 = !string.IsNullOrEmpty(dukdto.CommentNumber) && !string.IsNullOrEmpty(dukdto.CommentPurgeDate) && !string.IsNullOrEmpty(dukdto.Comment) ? dukdto.CommentPurgeDate : null,
                SBACOMMENT = !string.IsNullOrEmpty(dukdto.CommentNumber) && !string.IsNullOrEmpty(dukdto.CommentPurgeDate) && !string.IsNullOrEmpty(dukdto.Comment) ? dukdto.Comment : null,
                SBACODE5 = !string.IsNullOrEmpty(dukdto.PullNoticePurgeDate) && !string.IsNullOrEmpty(dukdto.Destination) && !string.IsNullOrEmpty(dukdto.Reason) ? "A" : null,
                SBACODE6 = !string.IsNullOrEmpty(dukdto.PullNoticePurgeDate) && !string.IsNullOrEmpty(dukdto.Destination) && !string.IsNullOrEmpty(dukdto.Reason) ? "G" : null,
                SBAPURGEDATE2 = !string.IsNullOrEmpty(dukdto.PullNoticePurgeDate) ? dukdto.PullNoticePurgeDate : null,
                SBAPURGECODE = !string.IsNullOrEmpty(dukdto.PurgeCode) ? dukdto.PurgeCode : null,
                SBACONDITION = !string.IsNullOrEmpty(dukdto.Condition) ? dukdto.Condition : null,
                SBAREASON = !string.IsNullOrEmpty(dukdto.Reason) ? dukdto.Reason : null,
                SBAINFOCODE = !string.IsNullOrEmpty(dukdto.Info) ? dukdto.Info : null,
                SBADESTINATION = !string.IsNullOrEmpty(dukdto.Destination) ? dukdto.Destination : null,
                SBAMISCINFO = !string.IsNullOrEmpty(dukdto.MiscInfo) ? dukdto.Destination : null
            };
            
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", duzdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dukdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dukdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DUK/" + dukdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dukdto.Error = DTO.Error;
            dukdto.DUKResponse = "DUK - " + DTO.StatusMessage;

            return dukdto;
        }
    }
}
