﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace DSA_API.Common.TCodes
{
    public class DUF
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUF(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DUFUIDTO ProcessDUF(DUFUIDTO duf)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");


            var results = ProcessDUFTransaction(duf);
            if (results.Error)
            {
                return results;
            }
            else
            {
                var x = _commonRepository.UpdateDLStats(duf.Operator, duf.DLNumber, "DUF", duf.ThreeCharacterLastName);


                return results;
            }
        }
        private DUFUIDTO ProcessDUFTransaction(DUFUIDTO dufdto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            DUFUpdateDTO DTO = new DUFUpdateDTO()
            {
                SBAREQCODE = dufdto.RequestorCode,
                SBAOPERATOR = dufdto.Operator,
                SBADLNUMBER = dufdto.DLNumber,
                SBALASTNAME = dufdto.ThreeCharacterLastName,
                SBAFRNUMBER = dufdto.FRNumber.Replace("-",""),
                SBAAUTHORITYSECTION = dufdto.AuthoritySection1,
                SBAAUTHORITYSECTION2 = dufdto.AuthoritySection2,
                SBAAUTHORITYSECTION3 = dufdto.AuthoritySection3,
                SBAEFFECTIVEDATE = dufdto.NewEffectiveDate,
                SBAORIGEFFECTIVEDATE = dufdto.OriginalEffectiveDate,
                SBAUPDATECOPIES = dufdto.UpdateCopies,
                SBAOSDLNUMBER = dufdto.OutOfStateDLNo,
                SBAOSCODE = dufdto.OutOfStateCd,
                SBACOMMSTATUSIND = dufdto.CommercialStatusIndicator,
                SBAHEARINGTYPE = dufdto.HearingType,
                SBAHEARINGDATE = dufdto.HearingDate,
                SBAHEARINGLOCATION = dufdto.HearingLocation,
                SBAHEARINGRESULT = dufdto.HearingResult,
                SBAMODIFIEDHEARINGDATE = dufdto.ModDate,
                SBAMAILDATE = dufdto.MailDate,
                SBACOFO = dufdto.CoFo,
                SBAPROOFBYPASS = dufdto.ProofBypass == true ?  "1" : "" ,
                SBAACCIDENTDATE = dufdto.AccidentDate,
                SBAACCIDENTLOCATION = dufdto.AccidentLocation,
                SBAROUTECODE = dufdto.RouteCode,
                SBAINSERTPARAGRAPH1 = dufdto.InsertParagraph,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dufdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dufdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dufdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DUF/" + dufdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dufdto.Error = DTO.Error;
            dufdto.DUFResponse = "DUF - " + DTO.StatusMessage;

            return dufdto;
        }
    }
}
