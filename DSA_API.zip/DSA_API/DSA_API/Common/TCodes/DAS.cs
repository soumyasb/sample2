﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace DSA_API.Common.TCodes
{
    public class DAS
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DAS(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DASUIDTO ProcessDASTransaction(DASUIDTO dasdto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";
            DASUpdateDTO DTO = new DASUpdateDTO()
            {
                SBAREQCODE = dasdto.RequestorCode,
                SBAOPERATOR = dasdto.Operator,
                SBADLNUMBER = dasdto.DLNumber,
                SBALASTNAME = dasdto.ThreeCharacterLastName,
                SBABIRTHDATE = dasdto.BirthDate,
                SBADETENTIONCD = dasdto.VOPType,
                SBADETENTIONDATE = dasdto.DetainDate,
                SBATYPTST = dasdto.VOPTestType,
                SBAUPDATECOPIES = dasdto.UpdateCopies,
                SBAEFFDATE = dasdto.EffectiveDate,
                SBAMAILDATE = dasdto.MailDate,
                SBAENDSTAY = dasdto.EndStay,
                SBAORIGAUTH = dasdto.OrigAuthSect,
                SBAORIGEFFDATE = dasdto.OrigEffectiveDate,
                SBAHEARDATE = dasdto.HearingDate,
                SBAHEARRESULT = dasdto.HearingResult,
                SBAHEARMODDATE = dasdto.ModifiedHearingDate,
                SBAHRNGTYPE = dasdto.HearingType,
                SBACORRECTDETENTIONDATE = dasdto.CorrArrestDate,
                SBACOFO = dasdto.CoFo,
                SBADIFFSERVDATE = dasdto.DiffServDate,
                SBACOMMSTATUSIND = dasdto.CommercialStatusIndicator == "N" || dasdto.CommercialStatusIndicator == "" ? "" : dasdto.CommercialStatusIndicator,
                SBALICLOC = dasdto.LicenseLocation,
                SBACREDITDAYS = dasdto.CreditDays,
                SBAOSCODE = dasdto.OutOfStateCd,
                SBAOSDLNUMBER = dasdto.OutOfStateDLNo,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dasdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dasdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dasdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAS/" + dasdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }

            if (!DTO.Error)
            {
                var x = _commonRepository.UpdateDLStats(dasdto.Operator, dasdto.DLNumber, "DAS", dasdto.ThreeCharacterLastName);
                if (String.IsNullOrEmpty(dasdto.EffectiveDate))
                {
                    DateTime date;
                    bool success = DateTime.TryParseExact(dasdto.DetainDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
                    if (success && (!String.IsNullOrEmpty(dasdto.VOPTestType) || !String.IsNullOrEmpty(dasdto.CourtCode)))
                        x = _commonRepository.InsertOrigStat(dasdto.Operator, dasdto.DLNumber, "das", dasdto.ThreeCharacterLastName, dasdto.VOPType == "R" ? "R" : "B", dasdto.VOPTestType, dasdto.CourtCode, date, dasdto.VOPBAC1 + dasdto.VOPBAC2, dasdto.LawEnforcementAgency);
                }
                //if (!String.IsNullOrEmpty(dasdto.EndStay))
                //{
                //    if (dasdto.EndStay == "4" || dasdto.EndStay == "5")
                //    {
                //        if (!String.IsNullOrEmpty(dasdto.EffectiveDate))
                //        {
                //            DateTime date;
                //            bool success = DateTime.TryParseExact(dasdto.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
                //            x = _commonRepository.UpdateStay(dasdto.DLNumber, date);
                //        }
                //        else
                //        {
                //            DateTime date1;
                //            DateTime date2;
                //            bool success = DateTime.TryParseExact(dasdto.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date1);
                //            success = DateTime.TryParseExact(dasdto.OrigEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date2);
                //            x = _commonRepository.InsertStay(dasdto.DLNumber, dasdto.EndStay, date1, dasdto.OrigAuthSect, date2);
                //        }
                //    }
                //}
                if (dasdto.LawEnforcementAgency.Length > 0)
                {
                    var results = ProcessDARTransaction(dasdto);
                    if (results.Error)
                    {
                        return results;
                    }
                    x = _commonRepository.UpdateDLStats(dasdto.Operator, dasdto.DLNumber, "DAR", dasdto.ThreeCharacterLastName);
                }
            }

            dasdto.Error = DTO.Error;
            dasdto.DASResponse = "DAS - " + DTO.StatusMessage;

            return dasdto;
        }

        private DASUIDTO ProcessDARTransaction(DASUIDTO das)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }

            //DAPUpdateDTO dapdto = new DAPUpdateDTO();
            DARUpdateDTO DTO = new DARUpdateDTO();
            DTO.SBAOPERATOR = das.Operator;
            DTO.SBAREQCODE = "9" + das.RequestorCode.Substring(1, 4);
            DTO.SBADLNUMBER = das.DLNumber;
            DTO.SBALASTNAME = das.ThreeCharacterLastName;
            string trans = "";

            if (!String.IsNullOrEmpty(das.CorrArrestDate))
            {
                trans = "DAQ" + "9" + das.RequestorCode.Substring(1, 4) + das.Operator + das.DLNumber + das.ThreeCharacterLastName + "C";
                DTO.SBATYPEINPUT = "C";
            }
            else
            {
                trans = "DAQ" + "9" + das.RequestorCode.Substring(1, 4) + das.Operator + das.DLNumber + das.ThreeCharacterLastName + "A";
                DTO.SBATYPEINPUT = "A";
            }
            if (das.VOPTestType.Length > 0)
            {
                trans += das.VOPTestType;
                DTO.SBATESTTYPE = das.VOPTestType;
            }
            else
            {
                trans += "  ";
            }


            int x = 25 + trans.Length;
            trans += das.LawEnforcementAgency;
            trans = trans.PadRight(x, ' ');

            DTO.SBARRESTAGENCY = das.LawEnforcementAgency.Trim();

            if (!String.IsNullOrEmpty(das.DSFieldOffice))
            {
                trans += das.DSFieldOffice;
                DTO.SBAFIELDOFFICE = das.DSFieldOffice.Trim();
            }
            else
            {
                trans = trans.PadRight(3 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(das.DetainDate))
            {
                trans += das.DetainDate;
                DTO.SBAAPSARRESTDATE = das.DetainDate;
            }
            else
            {
                trans = trans.PadRight(6 + trans.Length, ' ');
            }

            trans = trans.PadRight(12 + trans.Length, ' ');

            if (!String.IsNullOrEmpty(das.VOPBAC1))
            {
                trans += das.VOPBAC1;
                DTO.SBABAC1 = das.VOPBAC1;
            }
            else
            {
                trans = trans.PadRight(2 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(das.VOPBAC2))
            {
                trans += das.VOPBAC2;
                DTO.SBABAC1 = das.VOPBAC2;
            }
            else
            {
                trans = trans.PadRight(2 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(das.LawEnforcementCaseNo))
            {
                x = 13 + trans.Length;
                trans += das.LawEnforcementCaseNo;
                trans = trans.PadRight(x, ' ');
                DTO.SBALECASENUMBER = das.LawEnforcementCaseNo.Trim();
            }
            else
            {
                x = 13 + trans.Length;
                trans = trans.PadRight(x, ' ');
            }

            if (!String.IsNullOrEmpty(das.CourtCode) && das.CourtCode != "99999")
            {
                x = 5 + trans.Length;
                trans += das.CourtCode;
                trans = trans.PadRight(x, ' ');
                DTO.SBACOURTCODE = das.CourtCode;
            }
            else
            {
                x = 5 + trans.Length;
                trans = trans.PadRight(x, ' ');
            }

            trans = trans.PadRight(1 + trans.Length, ' ');

            string netName = "#ADMV6LI";

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", das.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", das.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAR/" + das.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            das.Error = DTO.Error;
            das.DARResponse = "DAR - " + DTO.StatusMessage;

            return das;
        }
    }
}
