﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
namespace DSA_API.Common.TCodes
{
    public class DUZ
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUZ(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DUZUIDTO ProcessDUZ(DUZUIDTO duz)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");


            var results = ProcessDUZTransaction(duz);
            if (results.Error)
            {
                return results;
            }
            else
            {
                var x = _commonRepository.UpdateDLStats(duz.Operator, duz.DLNumber, "DUZ", duz.ThreeCharacterLastName);
                //if (duz.EndStay == "5")
                //{
                //    if (!String.IsNullOrEmpty(duz.NewEffectiveDate))
                //    {
                //        DateTime date;
                //        bool success = DateTime.TryParseExact(duz.NewEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
                //        x = _commonRepository.UpdateStay(duz.DLNumber, date);
                //    }
                //    else
                //    {
                //        DateTime date1;
                //        DateTime date2;
                //        bool success = DateTime.TryParseExact(duz.NewEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date1);
                //        success = DateTime.TryParseExact(duz.OrigEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date2);
                //        x = _commonRepository.InsertStay(duz.DLNumber, duz.EndStay, date2, duz.OrigAuthoritySection, date2);
                //    }
                //}

                return results;
            }
        }
        private DUZUIDTO ProcessDUZTransaction(DUZUIDTO duzdto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            if (!String.IsNullOrEmpty(duzdto.OrigAuthoritySection))
            {
                if (duzdto.OrigAuthoritySection.Length < 7)
                {
                    var padlength = 7 - duzdto.OrigAuthoritySection.Length;
                    duzdto.OrigAuthoritySection = duzdto.OrigAuthoritySection.PadRight(padlength);
                }
            }
          
            var restrictions = "";
            if (!String.IsNullOrWhiteSpace(duzdto.RestrictionsOptions))
            {
                if (duzdto.RestrictionsOptions == "A" || duzdto.RestrictionsOptions == "D")
                {
                    if (duzdto.Restriction1 != "" && String.IsNullOrEmpty(duzdto.Restriction2) && String.IsNullOrEmpty(duzdto.Restriction3))
                    {
                        restrictions = duzdto.Restriction1;
                    }
                    if (duzdto.Restriction2 != "" && duzdto.Restriction2 != "" && String.IsNullOrEmpty(duzdto.Restriction3))
                    {
                        restrictions = duzdto.Restriction1 + duzdto.Restriction2;
                    }
                    if (duzdto.Restriction2 != "" && duzdto.Restriction2 != "" && duzdto.Restriction3 != "")
                    {
                        restrictions = duzdto.Restriction1 + duzdto.Restriction2 + duzdto.Restriction3;
                    }
                    restrictions = duzdto.RestrictionsOptions + restrictions;
                }
            }
           

            DUZUpdateDTO DTO = new DUZUpdateDTO()
            {
                SBAREQCODE = duzdto.RequestorCode,
                SBAOPERATOR = duzdto.Operator,
                SBADLNUMBER = duzdto.DLNumber,
                SBALASTNAME = duzdto.ThreeCharacterLastName,
                SBABIRTHDATE = duzdto.BirthDate,
                SBAAUTHORITYSECTION = duzdto.AuthoritySection,
                SBATYPEACTION = duzdto.TypeAction,
                SBAREASON = duzdto.Reason,
                SBAEFFECTIVEDATE = duzdto.NewEffectiveDate,
                SBAMAILDATE = duzdto.MailDate,
                SBATHROUGHDATE = duzdto.ThroughDate,
                SBACOFO = duzdto.CoFo,
                SBAORIGAUTHORITYSECTION = duzdto.OrigAuthoritySection,
                SBAORIGEFFECTIVEDATE = duzdto.OrigEffectiveDate,
                SBAORIGHEARINGDATE = duzdto.HearingDate,
                SBAORIGHEARINGRESULTS = duzdto.HearingResult,
                SBAMODIFIEDHEARINGDATE = duzdto.ModifiedHearingDate,
                SBAHEARINGTYPE = duzdto.HearingType,
                SBAHEARINGLOCATION = duzdto.HearingLocation,
                SBAPMCODE = duzdto.PMOption == true ?  duzdto.PMCode : "",
                SBARESTRICTION = restrictions,
                SBAROUTECODE = duzdto.RouteCode,
                SBAUPDATECOPIES = duzdto.UpdateCopies,
                SBAFIELDFILE = duzdto.FieldFile,
                SBALICLOC = duzdto.LicenseLocation,
                SBAMEDICALSUSPENSE = duzdto.MedicalSuspense,
                SBAOSDLNUMBER = duzdto.OutOfStateDLNo,
                SBAOSCODE = duzdto.OutOfStateCd,
                SBACOMMSTATUSIND = duzdto.CommercialStatusIndicator == "N" || duzdto.CommercialStatusIndicator == "" ? "" : duzdto.CommercialStatusIndicator,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", duzdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", duzdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", duzdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DUZ/" + duzdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            duzdto.Error = DTO.Error;
            duzdto.DUZResponse = "DUZ - " + DTO.StatusMessage;

            return duzdto;
        }

    }
}
