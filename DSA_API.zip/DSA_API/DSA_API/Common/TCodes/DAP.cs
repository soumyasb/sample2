﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


namespace DSA_API.Common.TCodes
{
    public class DAP
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DAP(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DAPUIDTO ProcessDAP( DAPUIDTO dap)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
          

            var results = ProcessDAPTransaction(dap);
            if (results.Error)
            {
                return results;
            }
            else
            {
                var x = _commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName);
                if (String.IsNullOrEmpty(dap.EffectiveDate))
                {
                    DateTime date;
                    bool success = DateTime.TryParseExact(dap.ArrestDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
                    if (success && (!String.IsNullOrEmpty(dap.APSTestType) || !String.IsNullOrEmpty(dap.CourtCode)))
                        x = _commonRepository.InsertOrigStat(dap.Operator, dap.DLNumber, "DAP", dap.ThreeCharacterLastName, dap.APSType == "R" ? "R" : "B", dap.APSTestType, dap.CourtCode, date, dap.BAC1 + dap.BAC2, dap.LawEnforcementAgency);
                }
                //if (dap.EndStay == "5")
                //{
                //    if (!String.IsNullOrEmpty(dap.EffectiveDate))
                //    {
                //        DateTime date;
                //        bool success = DateTime.TryParseExact(dap.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
                //        x = _commonRepository.UpdateStay(dap.DLNumber, date);
                //    }
                //    else
                //    {
                //        DateTime date1;
                //        DateTime date2;
                //        bool success = DateTime.TryParseExact(dap.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date1);
                //        success = DateTime.TryParseExact(dap.OrigEffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date2);
                //        x = _commonRepository.InsertStay(dap.DLNumber, dap.EndStay, date2, dap.VOPOrigAuthSect, date2);
                //    }
                //}
            }

            // DAP transaction updated ok, lets do a DAR transaction
            if (dap.LawEnforcementAgency.Length > 0)
            {
                results = ProcessDARTransaction(dap);
                if (results.Error)
                {
                    return results;
                }
                var x = _commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAR", dap.ThreeCharacterLastName);
            }
            if (dap.VOPType == "A" || dap.VOPType == "R")
            {
                results = ProcessDASTransaction(dap);
                if (results.Error)
                    return results;
                var x = _commonRepository.UpdateDLStats(dap.Operator, dap.DLNumber, "DAS", dap.ThreeCharacterLastName);
                if (dap.EndStay == "4" || dap.EndStay == "5")
                {
                    DateTime date;
                    bool success = DateTime.TryParseExact(dap.EffectiveDate, "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date);
                    x = _commonRepository.UpdateStay(dap.DLNumber, date);
                }
            }
           
            return results;
        }
        private DAPUIDTO ProcessDAPTransaction(DAPUIDTO dapdto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            DAPUpdateDTO DTO = new DAPUpdateDTO()
            {
                SBAREQCODE = dapdto.RequestorCode,
                SBAOPERATOR = dapdto.Operator,
                SBADLNUMBER = dapdto.DLNumber,
                SBALASTNAME = dapdto.ThreeCharacterLastName,
                SBABIRTHDATE = dapdto.BirthDate,
                SBAARRCD = dapdto.APSType,
                SBAARRDT = dapdto.ArrestDate,
                SBATYPTST = dapdto.APSTestType,
                SBAUPDCPY = dapdto.UpdateCopies,
                SBAEFFDATE = dapdto.EffectiveDate,
                SBAMAILDATE = dapdto.MailDate,
                SBAENDSTAY = dapdto.EndStay,
                SBAAUTHSECT = dapdto.PASOrigAuthSect,
                SBAORIGEFFDATE = dapdto.OrigEffectiveDate,
                SBAHEARDATE = dapdto.HearingDate,
                SBAHEARRESULT = dapdto.HearingResult,
                SBAHEARMODDATE = dapdto.ModifiedHearingDate,
                SBAHRNGTYPE = dapdto.HearingType,
                SBACORRECTARRDETDATE = dapdto.CorrArrestDate,
                SBACOFO = dapdto.CoFo,
                SBADIFFSERVDATE = dapdto.DiffServDate,
                SBACOMMSTATUSIND = dapdto.CommercialStatusIndicator == "N" || dapdto.CommercialStatusIndicator == "" ? "" : dapdto.CommercialStatusIndicator,
                SBALICLOC1 = dapdto.LicenseLocation,
                SBACREDITDAYS1 = dapdto.CreditDays,
                SBALICLOC2 = dapdto.LicenseLocation,
                SBACREDITDAYS2 = dapdto.CreditDays,
                SBAOSCODE = dapdto.OutOfStateCd,
                SBAOSDLNUMBER = dapdto.OutOfStateDLNo,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dapdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dapdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAP/" + dapdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dapdto.Error = DTO.Error;
            dapdto.DAPResponse = "DAP - " + DTO.StatusMessage;

            return dapdto;
        }
        private DAPUIDTO ProcessDARTransaction(DAPUIDTO dap)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }

            //DAPUpdateDTO dapdto = new DAPUpdateDTO();
            DARUpdateDTO DTO = new DARUpdateDTO();
            DTO.SBAOPERATOR = dap.Operator;
            DTO.SBAREQCODE = "9" + dap.RequestorCode.Substring(1, 4);
            DTO.SBADLNUMBER = dap.DLNumber;
            DTO.SBALASTNAME = dap.ThreeCharacterLastName;
            string trans = "";

            if (!String.IsNullOrEmpty(dap.CorrArrestDate))
            {
                trans = "DAQ" + "9" + dap.RequestorCode.Substring(1, 4) + dap.Operator + dap.DLNumber + dap.ThreeCharacterLastName + "C";
                DTO.SBATYPEINPUT = "C";
            }
            else
            {
                trans = "DAQ" + "9" + dap.RequestorCode.Substring(1, 4) + dap.Operator + dap.DLNumber + dap.ThreeCharacterLastName + "A";
                DTO.SBATYPEINPUT = "A";
            }
            if (dap.APSTestType.Length > 0)
            {
                trans += dap.APSTestType;
                DTO.SBATESTTYPE = dap.APSTestType;
            }
            else
            {
                trans += "  ";
            }


            int x = 25 + trans.Length;
            trans += dap.LawEnforcementAgency;
            trans = trans.PadRight(x, ' ');

            DTO.SBARRESTAGENCY = dap.LawEnforcementAgency.Trim();

            if (!String.IsNullOrEmpty(dap.DSFieldOffice))
            {
                trans += dap.DSFieldOffice;
                DTO.SBAFIELDOFFICE = dap.DSFieldOffice.Trim();
            }
            else
            {
                trans = trans.PadRight(3 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(dap.ArrestDate))
            {
                trans += dap.ArrestDate;
                DTO.SBAAPSARRESTDATE = dap.ArrestDate;
            }
            else
            {
                trans = trans.PadRight(6 + trans.Length, ' ');
            }

            trans = trans.PadRight(12 + trans.Length, ' ');

            if (!String.IsNullOrEmpty(dap.BAC1))
            {
                trans += dap.BAC1;
                DTO.SBABAC1 = dap.BAC1;
            }
            else
            {
                trans = trans.PadRight(2 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(dap.BAC2))
            {
                trans += dap.BAC2;
                DTO.SBABAC1 = dap.BAC2;
            }
            else
            {
                trans = trans.PadRight(2 + trans.Length, ' ');
            }

            if (!String.IsNullOrEmpty(dap.LawEnforcementCaseNo))
            {
                x = 13 + trans.Length;
                trans += dap.LawEnforcementCaseNo;
                trans = trans.PadRight(x, ' ');
                DTO.SBALECASENUMBER = dap.LawEnforcementCaseNo.Trim();
            }
            else
            {
                x = 13 + trans.Length;
                trans = trans.PadRight(x, ' ');
            }

            if (!String.IsNullOrEmpty(dap.CourtCode) && dap.CourtCode != "99999")
            {
                x = 5 + trans.Length;
                trans += dap.CourtCode;
                trans = trans.PadRight(x, ' ');
                DTO.SBACOURTCODE = dap.CourtCode;
            }
            else
            {
                x = 5 + trans.Length;
                trans = trans.PadRight(x, ' ');
            }

            trans = trans.PadRight(1 + trans.Length, ' ');

            string netName = "#ADMV6LI";

            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dap.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dap.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAR/" + dap.DLNumber, DTO);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dap.Error = DTO.Error;
            dap.DARResponse = "DAR - " + DTO.StatusMessage;

            return dap;
        }
        private DAPUIDTO ProcessDASTransaction(DAPUIDTO dapdto)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            DASUpdateDTO DTO = new DASUpdateDTO()
            {
                SBAREQCODE = dapdto.RequestorCode,
                SBAOPERATOR = dapdto.Operator,
                SBADLNUMBER = dapdto.DLNumber,
                SBALASTNAME = dapdto.ThreeCharacterLastName,
                SBABIRTHDATE = dapdto.BirthDate,
                SBADETENTIONCD = dapdto.VOPType,
                SBADETENTIONDATE = dapdto.ArrestDate,
                SBATYPTST = dapdto.VOPTestType != "RE" ? dapdto.VOPTestType : null,
                SBAEFFDATE = dapdto.EffectiveDate,
                SBAMAILDATE = dapdto.MailDate,
                SBAENDSTAY = dapdto.EndStay,
                SBAORIGAUTH = dapdto.PASOrigAuthSect,
                SBAORIGEFFDATE = dapdto.OrigEffectiveDate,
                SBAHEARDATE = dapdto.HearingDate,
                SBAHEARRESULT = dapdto.HearingResult,
                SBAHEARMODDATE = dapdto.ModifiedHearingDate,
                SBAHRNGTYPE = dapdto.HearingType,
                SBACORRECTDETENTIONDATE = dapdto.CorrArrestDate,
                SBAUPDATECOPIES = dapdto.UpdateCopies,
                SBACOFO = dapdto.CoFo,
                SBADIFFSERVDATE = dapdto.DiffServDate,
                SBACOMMSTATUSIND = dapdto.CommercialStatusIndicator == "N" || dapdto.CommercialStatusIndicator == "" ? "" : dapdto.CommercialStatusIndicator,
                SBALICLOC = dapdto.LicenseLocation,
                SBACREDITDAYS = dapdto.CreditDays,
                SBAOSCODE = dapdto.OutOfStateCd,
                SBAOSDLNUMBER = dapdto.OutOfStateDLNo,
                SBATESTDATE = testdate != "" ? testdate : null
            };
            string outputType = "application/json";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dapdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dapdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dapdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DAS/" + dapdto.DLNumber, DTO);

                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dapdto.Error = DTO.Error;
            dapdto.DASResponse = "DAS - " + DTO.StatusMessage;

            return dapdto;
        }

    }
    
}
