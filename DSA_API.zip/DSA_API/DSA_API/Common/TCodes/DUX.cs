﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
namespace DSA_API.Common.TCodes
{
    public class DUX
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUX(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DUXUIDTO ProcessDUX(DUXUIDTO dux)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");
            var results = new DUXUIDTO();
            if (!String.IsNullOrEmpty(dux.HearingType) && 
                !String.IsNullOrEmpty(dux.HearingDate ) && 
                !String.IsNullOrEmpty(dux.HearingLocation) && 
                !String.IsNullOrEmpty(dux.HearingReason) && 
                !String.IsNullOrEmpty(dux.HearingResult))
            {
                results = ProcessDUWTransaction(dux);
                if (results.Error)
                {
                    return results;
                }
            }

            results = ProcessDUXTransaction(dux);
            if (results.Error)
            {
                return results;
            }
            else
            {
                if (dux.PMOptions == "A" || dux.PMOptions == "D")
                {
                    DUK dukProcess = new DUK(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
                    DUKUIDTO duk = new DUKUIDTO()
                    {
                        RequestorCode = dux.RequestorCode,
                        Operator = dux.Operator,
                        DLNumber = dux.DLNumber,
                        ThreeCharacterLastName = dux.ThreeCharacterLastName,
                        Process1 = dux.PMOptions,
                        Code1 = "L",
                        Info1 = dux.PMCode
                    };

                    var DUKresults = dukProcess.ProcessDUK(duk);
                    results.DUKResponse = DUKresults.DUKResponse;
                }
                if (dux.RestrictionsOptions == "A" || dux.RestrictionsOptions == "D")
                {
                    DUK dukProcess = new DUK(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);

                    var restrictions = dux.Restriction1 + dux.Restriction2 + dux.Restriction3;

                    DUKUIDTO duk = new DUKUIDTO()
                    {
                        RequestorCode = dux.RequestorCode,
                        Operator = dux.Operator,
                        DLNumber = dux.DLNumber,
                        ThreeCharacterLastName = dux.ThreeCharacterLastName,
                        Process1 = dux.RestrictionsOptions,
                        Code1 = "I",
                        Info1 = restrictions
                    };
                    var DUKresults = dukProcess.ProcessDUK(duk);
                    if (string.IsNullOrEmpty(results.DUKResponse))
                    {
                        results.DUKResponse = DUKresults.DUKResponse;
                    }
                    else
                    {
                        results.DUKResponse = results.DUKResponse + " " + DUKresults.DUKResponse;
                    }
                        results.DUKResponse = results.DUKResponse + DUKresults.DUKResponse; 
                }
                var x = _commonRepository.UpdateDLStats(dux.Operator, dux.DLNumber, "DUX", dux.ThreeCharacterLastName);
                return results;
            }
        }
        private DUXUIDTO ProcessDUWTransaction(DUXUIDTO duxdto)
        {

            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";
            DUWUpdateDTO DTO = new DUWUpdateDTO()
            {
                SBAREQCODE = duxdto.RequestorCode,
                SBAOPERATOR = duxdto.Operator,
                SBADLNUMBER = duxdto.DLNumber,
                SBALASTNAME = duxdto.ThreeCharacterLastName,
                SBAHEARINGTYPE = duxdto.HearingType,
                SBAHEARINGDATE = duxdto.HearingDate,
                SBAHEARINGLOCATION = duxdto.HearingLocation,
                SBAHEARINGREASON = duxdto.HearingReason,
                SBASCHEDULERESULT = duxdto.HearingResult,
                SBATYPEACTION = "XX",
                SBAMODIFIEDHEARINGDATE = duxdto.ModifiedHearingDate,
                SBAMAILDATE = "",
                SBAFIELDFILE = "",
                SBATESTDATE = testdate
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", duzdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", duxdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", duxdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DUW/" + duxdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            duxdto.Error = DTO.Error;
            duxdto.DUWResponse = "DUW - " + DTO.StatusMessage;

            return duxdto;
        }

        private DUXUIDTO ProcessDUXTransaction(DUXUIDTO duxdto)
        {
            var testdate = "";
            if (_env.IsDevelopment())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            if (!String.IsNullOrEmpty(duxdto.OrigAuthoritySection))
            {
                if (duxdto.OrigAuthoritySection.Length < 7)
                {
                    var padlength = 7 - duxdto.OrigAuthoritySection.Length;
                    duxdto.OrigAuthoritySection = duxdto.OrigAuthoritySection.PadRight(padlength);
                }
            }

            //var restrictions = "";
            //if (!String.IsNullOrWhiteSpace(duxdto.RestrictionsOptions))
            //{
            //    if (duxdto.RestrictionsOptions == "A" || duxdto.RestrictionsOptions == "D")
            //    {
            //        if (duxdto.Restriction1 != "" && String.IsNullOrEmpty(duxdto.Restriction2) && String.IsNullOrEmpty(duxdto.Restriction3))
            //        {
            //            restrictions = duxdto.Restriction1;
            //        }
            //        if (duxdto.Restriction2 != "" && duxdto.Restriction2 != "" && String.IsNullOrEmpty(duxdto.Restriction3))
            //        {
            //            restrictions = duxdto.Restriction1 + duxdto.Restriction2;
            //        }
            //        if (duxdto.Restriction2 != "" && duxdto.Restriction2 != "" && duxdto.Restriction3 != "")
            //        {
            //            restrictions = duxdto.Restriction1 + duxdto.Restriction2 + duxdto.Restriction3;
            //        }
            //        restrictions = duxdto.RestrictionsOptions + restrictions;
            //    }
            //}

            DUXUpdateDTO DTO = new DUXUpdateDTO()
            {
                SBAREQCODE = duxdto.RequestorCode,
                SBAOPERATOR = duxdto.Operator,
                SBADLNUMBER = duxdto.DLNumber,
                SBALASTNAME = duxdto.ThreeCharacterLastName,
                SBAAUTHORITYSECTION = duxdto.AuthoritySection,
                SBAEFFECTIVEDATE = duxdto.EffectiveDate,
                SBAUPDATECOPIES = duxdto.UpdateCopies,
                SBAORIGAUTHORITYSECTION = duxdto.OrigAuthoritySection,
                SBAORIGEFFECTIVEDATE = duxdto.OrigEffectiveDate,
                SBACOFO = duxdto.CoFo,
                //SBAPMCODE = duxdto.PMOptions == "A" || duxdto.PMOptions == "D" ? duxdto.PMCode : null,
                //SBARESTRICTION = restrictions,
                SBAINSERTPARAGRAPH1 = duxdto.InsertParagraph,
                SBAROUTECODE = duxdto.RouteCode,
                SBACOUNTYCODE = duxdto.CountyCode,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", duxdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", duxdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", duxdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DUX/" + duxdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            duxdto.Error = DTO.Error;
            duxdto.DUXResponse = "DUX - " + DTO.StatusMessage;

            return duxdto;
        }
    }
}
