﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.UpdateTCodes;
using DSA_API.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace DSA_API.Common.TCodes
{
    public class DUP
    {
        private DSAContext _context;
        private IUserRepository _userRepository;
        private ILookupRepository _lookupRepository;
        private Employee _user;
        private IConfiguration _configuration { get; }
        private ICommonRepository _commonRepository;
        private IHostingEnvironment _env;
        public DUP(IUserRepository userRepository,
            ILookupRepository lookupRespository,
            DSAContext context,
            IConfiguration configuration,
            ICommonRepository commonRepository,
            IHostingEnvironment env)
        {
            _context = context;
            _userRepository = userRepository;
            _lookupRepository = lookupRespository;
            _commonRepository = commonRepository;
            _configuration = configuration;
            _env = env;
        }
        public DUPUIDTO ProcessDUP(DUPUIDTO dup)
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee("MWMPG4");


            var results = ProcessDUPTransaction(dup);
            if (results.Error)
            {
                return results;
            }
            else
            {
                if (dup.PMOptions == "A" || dup.PMOptions == "D")
                {
                    DUK dukProcess = new DUK(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);
                    DUKUIDTO duk = new DUKUIDTO()
                    {
                        RequestorCode = dup.RequestorCode,
                        Operator = dup.Operator,
                        DLNumber = dup.DLNumber,
                        ThreeCharacterLastName = dup.ThreeCharacterLastName,
                        Process1 = dup.PMOptions,
                        Code1 = "L",
                        Info1 = dup.PMCode
                    };

                    var DUKresults = dukProcess.ProcessDUK(duk);
                    results.DUKResponse = DUKresults.DUKResponse;
                }
                if (dup.RestrictionsOptions == "A" || dup.RestrictionsOptions == "D")
                {
                    DUK dukProcess = new DUK(_userRepository, _lookupRepository, _context, _configuration, _commonRepository, _env);

                    var restrictions = dup.Restriction1 + dup.Restriction2 + dup.Restriction3;

                    DUKUIDTO duk = new DUKUIDTO()
                    {
                        RequestorCode = dup.RequestorCode,
                        Operator = dup.Operator,
                        DLNumber = dup.DLNumber,
                        ThreeCharacterLastName = dup.ThreeCharacterLastName,
                        Process1 = dup.RestrictionsOptions,
                        Code1 = "I",
                        Info1 = restrictions
                    };
                    var DUKresults = dukProcess.ProcessDUK(duk);
                    if (string.IsNullOrEmpty(results.DUKResponse))
                    {
                        results.DUKResponse = DUKresults.DUKResponse;
                    }
                    else
                    {
                        results.DUKResponse = results.DUKResponse + " " + DUKresults.DUKResponse;
                    }
                   
                }

                var x = _commonRepository.UpdateDLStats(dup.Operator, dup.DLNumber, "DUP", dup.ThreeCharacterLastName);
                return results;
            }
        }
        private DUPUIDTO ProcessDUPTransaction(DUPUIDTO dupdto)
        {
            var testdate = "";
            if (_env.IsStaging())
            {
                testdate = DSA_API.Globals.Globals.DCSTestDate;
            }
            string netName = "#ADMV6LI";

            if (!String.IsNullOrEmpty(dupdto.OrigAuthoritySection))
            {
                if (dupdto.OrigAuthoritySection.Length < 7)
                {
                    var padlength = 7 - dupdto.OrigAuthoritySection.Length;
                    dupdto.OrigAuthoritySection = dupdto.OrigAuthoritySection.PadRight(padlength);
                }
            }

            var restrictions = "";
            if (!String.IsNullOrWhiteSpace(dupdto.RestrictionsOptions))
            {
                if (dupdto.RestrictionsOptions == "A" || dupdto.RestrictionsOptions == "D")
                {
                    if (dupdto.Restriction1 != "" && String.IsNullOrEmpty(dupdto.Restriction2) && String.IsNullOrEmpty(dupdto.Restriction3))
                    {
                        restrictions = dupdto.Restriction1;
                    }
                    if (dupdto.Restriction2 != "" && dupdto.Restriction2 != "" && String.IsNullOrEmpty(dupdto.Restriction3))
                    {
                        restrictions = dupdto.Restriction1 + dupdto.Restriction2;
                    }
                    if (dupdto.Restriction2 != "" && dupdto.Restriction2 != "" && dupdto.Restriction3 != "")
                    {
                        restrictions = dupdto.Restriction1 + dupdto.Restriction2 + dupdto.Restriction3;
                    }
                    restrictions = dupdto.RestrictionsOptions + restrictions;
                }
            }


            DUPUpdateDTO DTO = new DUPUpdateDTO()
            {
                SBAREQCODE = dupdto.RequestorCode,
                SBAOPERATOR = dupdto.Operator,
                SBADLNUMBER = dupdto.DLNumber,
                SBALASTNAME = dupdto.ThreeCharacterLastName,
                SBABIRTHDATE = dupdto.BirthDate,
                SBATYPEACTION = dupdto.TypeAction,
                SBAREASON = dupdto.Reason,
                SBAAUTHORITYSECTION1 = dupdto.AuthoritySection1,
                SBAAUTHORITYSECTION2 = dupdto.AuthoritySection2,
                SBAORIGHEARINGDATE = dupdto.OriginalHearingDate,
                SBAEFFECTIVEDATE = dupdto.EffectiveDate,
                SBAACTIONTERMDATE = dupdto.ActionTermDate,
                SBAMAILDATE = dupdto.MailDate,
                SBAROUTECODE = dupdto.RouteCode,
                SBACOFO = dupdto.CoFo,
                SBAORIGAUTHORITYSECTION = dupdto.OrigAuthoritySection,
               // SBAPMCODE = dupdto.PMOption == true ? dupdto.PMCode : "",
                SBARESTRICTION = restrictions,
                SBALICLOC = dupdto.LicenseLocation,
                SBACOUNTYCODE = dupdto.CountyCode,
                SBAORIGAUTHORITYDATE = dupdto.OrigEffectiveDate,
                SBATESTDATE = testdate
            };
            string outputType = "application/json";

            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    // client.DefaultRequestHeaders.Add("MQ-NetName", dupdto.NetName.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName);
                    //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", dupdto.Operator.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", dupdto.RequestorCode);
                    var response = HttpClientExtensionsDSA.PostAsJsonAsync(client, "update/DUP/" + dupdto.DLNumber, DTO);
                    if (response.Result.IsSuccessStatusCode)
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];
                        if (DTO.Error)
                        {
                            DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'><font color='red'>DL Update Manual</font></a> for assistance.";
                        }
                    }
                    else
                    {
                        JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                        DTO.Error = (bool)json["error"];
                        DTO.Title = (string)json["title"];
                        DTO.StatusMessage = (string)json["statusMessage"];

                    }
                }
            }
            catch (Exception e)
            {
                DTO.Error = true;
                DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
            }
            dupdto.Error = DTO.Error;
            dupdto.DUPResponse = "DUP - " + DTO.StatusMessage;

            return dupdto;
        }
    }
}
