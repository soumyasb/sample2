﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class OswithDrawalType
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
