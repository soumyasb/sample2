﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hearingtype
    {
        public string CdHrngTyp { get; set; }
        public string DescHrngTyp { get; set; }
        public string CdPhoneTyp { get; set; }
        public string TxtAbbrDesc { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
