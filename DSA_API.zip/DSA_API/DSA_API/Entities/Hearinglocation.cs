﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hearinglocation
    {
        public Hearinglocation()
        {
            Appointment = new HashSet<Appointment>();
            Hearinglocprofile = new HashSet<Hearinglocprofile>();
        }

        public int Id { get; set; }
        public string CdOffId { get; set; }
        public string NbrRoom { get; set; }
        public string DescRoom { get; set; }
        public DateTime? DtClosed { get; set; }

        public Dsoffice CdOff { get; set; }
        public ICollection<Appointment> Appointment { get; set; }
        public ICollection<Hearinglocprofile> Hearinglocprofile { get; set; }
    }
}
