﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Interpre
    {
        public int Id { get; set; }
        public string CdLanguage { get; set; }
        public string CdPrtyTyp { get; set; }
        public string NbrOip { get; set; }
        public string NbrPhoneAc { get; set; }
        public DateTime? DtTerm { get; set; }
        public int Oipid { get; set; }
    }
}
