﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class NewsItem
    {
        public NewsItem()
        {
            OfficeNewsItem = new HashSet<OfficeNewsItem>();
        }

        public int NewsId { get; set; }
        public int EmpId { get; set; }
        public string AuthorName { get; set; }
        public string Priority { get; set; }
        public string Subject { get; set; }
        public string NewsText { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool AllOffices { get; set; }

        public Employee Emp { get; set; }
        public ICollection<OfficeNewsItem> OfficeNewsItem { get; set; }
    }
}
