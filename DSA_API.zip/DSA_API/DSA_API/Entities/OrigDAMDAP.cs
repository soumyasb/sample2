﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Entities
{
    public partial class OrigDAMDAP
    {
        public int Id { get; set; }
        public string NbrDl { get; set; }
        public string CdTcode { get; set; }
        public string Nme3pos { get; set; }
        public DateTime DtTrans { get; set; }
        public string CdEmpId { get; set; }
        public string ArrestType { get; set; }
        public string TestType { get; set; }
        public string CourtCode { get; set; }
        public DateTime ArrestDate { get; set; }
        public string BACLevel { get; set; }
        public string LawAgency { get; set; }
    }
}
