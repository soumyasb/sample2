﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Profile1
    {
        public Profile1()
        {
            Profileday = new HashSet<Profileday>();
        }

        public int ProfileId { get; set; }
        public int EmpId { get; set; }
        public string CdOffId { get; set; }
        public DateTime DtEffStrt { get; set; }
        public DateTime? DtEffEnd { get; set; }
        public int? CdUpdtTechId { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string CdProfileTyp { get; set; }
        public string CdWrkWkTyp { get; set; }

        public Employee CdUpdtTech { get; set; }
        public Employee Emp { get; set; }
        public ICollection<Profileday> Profileday { get; set; }
    }
}
