﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Cofocodes
    {
        public string CdCofo { get; set; }
        public string DescCofo { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
