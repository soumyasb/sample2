﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class StayStats
    {
        public int Id { get; set; }
        public string NbrDl { get; set; }
        public string AuthSection { get; set; }
        public DateTime EffDate { get; set; }
        public string OrigAuthSection { get; set; }
        public DateTime OrigEffDate { get; set; }
        public DateTime? EndStayDate { get; set; }
    }
}
