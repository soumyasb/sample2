﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Dsrlog
    {
        public string CdCase { get; set; }
        public string NbrDl { get; set; }
        public DateTime DtStrt { get; set; }
        public string CdTechLgnId { get; set; }
        public string CdFldDsoAlpha { get; set; }
    }
}
