﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class ApptLog
    {
        public int Id { get; set; }
        public string CdEmpId { get; set; }
        public DateTime DtMod { get; set; }
        public int FlgSuccess { get; set; }
        public string FlgTyp { get; set; }
        public string CdEmpOffId { get; set; }
        public string CdActvyTyp { get; set; }
        public DateTime DtStrtTim { get; set; }
        public DateTime DtEndTim { get; set; }
        public int? NbrAppt { get; set; }
        public int? NbrRcurApt { get; set; }
        public string NbrRoom { get; set; }
    }
}
