﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Cert
    {
        public string CdCertEndr { get; set; }
        public string DescCertEndr { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
