﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Contact
    {
        public int ContactId { get; set; }
        public string CdCase { get; set; }
        public int EmpId { get; set; }
        public string CdEmpId { get; set; }
        public string CdOffId { get; set; }
        public string CdAuthId { get; set; }
        public string CdCntctTyp { get; set; }
        public string CdResult { get; set; }
        public string CdSchedTechId { get; set; }
        public string CdStatus { get; set; }
        public string CdStatus2 { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime DtCntctEndTim { get; set; }
        public DateTime DtCntctStrtTim { get; set; }
        public DateTime? DtNotc { get; set; }
        public DateTime DtSchedTrans { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string FlgPrntNotc { get; set; }
        public string NbrRoom { get; set; }
        public string TxtComment { get; set; }

        public Dsrcase CdCaseNavigation { get; set; }
        public Employee Emp { get; set; }
    }
}
