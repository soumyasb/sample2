﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Attachments
    {
        public int Id { get; set; }
        public string CdAttachments { get; set; }
        public string DescAttachments { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
