﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Dukcodes
    {
        public string CdDuk { get; set; }
        public string DescDuk { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
