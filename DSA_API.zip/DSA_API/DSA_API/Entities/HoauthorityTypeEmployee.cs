﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class HoauthorityTypeEmployee
    {
        public string EmployeeId { get; set; }
        public string HearingType { get; set; }
    }
}
