﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Dsrcase
    {
        public Dsrcase()
        {
            CaseSuspense = new HashSet<CaseSuspense>();
            Caseagny = new HashSet<Caseagny>();
            Caseoip = new HashSet<Caseoip>();
            Contact = new HashSet<Contact>();
            DocGeneration = new HashSet<DocGeneration>();
            Dsrcomm = new HashSet<Dsrcomm>();
        }

        public string CdCase { get; set; }
        public int? GroupNo { get; set; }
        public string NbrDl { get; set; }
        public string CdHrngTyp { get; set; }
        public string CdRsn { get; set; }
        public string CdRefrSrceTyp { get; set; }
        public string CdFldDsoAlpha { get; set; }
        public string CdOrigTechId { get; set; }
        public DateTime DtOrigTrans { get; set; }
        public DateTime DtRcpt { get; set; }
        public string CdStatusRec { get; set; }
        public string CdStatusRec2 { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime DtUpdtTrans { get; set; }
        public string CdCityAcc { get; set; }
        public DateTime? DtAcc { get; set; }
        public string FlgHearing { get; set; }
        public string CdEndr { get; set; }
        public string CdFldFileLoc { get; set; }
        public string NbrCaseAccFr { get; set; }
        public DateTime? DtSchedHrng { get; set; }
        public DateTime? DtModSchedHr { get; set; }
        public string CdSchedRsl { get; set; }
        public string CdTypAct { get; set; }
        public DateTime? DtTypActEff { get; set; }
        public DateTime? DtTypActMod { get; set; }
        public DateTime? DtTypActEnd { get; set; }
        public string CdCaseClseId { get; set; }
        public DateTime? DtCaseClse { get; set; }
        public string CdDlUpdateId { get; set; }
        public DateTime? DtDlUpdate { get; set; }
        public string CdVehAuthOrig { get; set; }
        public string CdVehAuth1 { get; set; }
        public string CdVehAuth2 { get; set; }
        public string CdVehAuth3 { get; set; }
        public DateTime? DtMail { get; set; }
        public DateTime? DtTypActTerm { get; set; }

        public Person NbrDlNavigation { get; set; }
        public ICollection<CaseSuspense> CaseSuspense { get; set; }
        public ICollection<Caseagny> Caseagny { get; set; }
        public ICollection<Caseoip> Caseoip { get; set; }
        public ICollection<Contact> Contact { get; set; }
        public ICollection<DocGeneration> DocGeneration { get; set; }
        public ICollection<Dsrcomm> Dsrcomm { get; set; }
    }
}
