﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Casecntl
    {
        public string CdOffId { get; set; }
        public short NbrSeq { get; set; }
        public DateTime? LastUpdate { get; set; }
    }
}
