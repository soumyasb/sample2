﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Language
    {
        public string CdLanguage { get; set; }
        public string DescLanguage { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
