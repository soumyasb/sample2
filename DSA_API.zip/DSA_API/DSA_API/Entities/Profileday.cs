﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Profileday
    {
        public int ProfileDayId { get; set; }
        public int ProfileId { get; set; }
        public int DayOfWkMonth { get; set; }
        public DateTime TmeWrkStrt { get; set; }
        public DateTime TmeWrkEnd { get; set; }
        public DateTime TmeAmBrkStrt { get; set; }
        public DateTime TmeAmBrkEnd { get; set; }
        public DateTime TmePmBrkStrt { get; set; }
        public DateTime TmePmBrkEnd { get; set; }
        public DateTime TmeLchBrkStrt { get; set; }
        public DateTime TmeLchBrkEnd { get; set; }
        public string FlgAlt { get; set; }
        public string FlgTelc { get; set; }
        public DateTime? TrvlTmeToStrt { get; set; }
        public DateTime? TrvlTmeToEnd { get; set; }
        public DateTime? TrvlTmeFroStrt { get; set; }
        public DateTime? TrvlTmeFroEnd { get; set; }

        public Profile1 Profile { get; set; }
    }
}
