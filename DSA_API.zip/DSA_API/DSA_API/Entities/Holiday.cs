﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Holiday
    {
        public int Id { get; set; }
        public DateTime? DtHoli { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
