﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Dlupdstats
    {
        public int Id { get; set; }
        public string CdEmpId { get; set; }
        public DateTime DtTrans { get; set; }
        public string NbrDl { get; set; }
        public string CdTcode { get; set; }
        public string Nme3pos { get; set; }
    }
}
