﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class RowColumnHexValues
    {
        public string Row { get; set; }
        public string Col { get; set; }
        public string Hexvalue1 { get; set; }
        public string Hexvalue2 { get; set; }
        public string Charvalue1 { get; set; }
        public string Charvalue2 { get; set; }
    }
}
