﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Activitytype
    {
        public int Id { get; set; }
        public string DescActvyTyp { get; set; }
        public string CdActvyTyp { get; set; }
        public string TxtActvyAbbr { get; set; }
        public string CdTypes { get; set; }
        public byte FlgConfTyp { get; set; }
        public DateTime? DtTerm { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}
