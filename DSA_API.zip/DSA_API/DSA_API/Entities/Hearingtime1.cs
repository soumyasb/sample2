﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hearingtime1
    {
        public Hearingtime1()
        {
            Hoauthtype1 = new HashSet<Hoauthtype1>();
        }

        public int Id { get; set; }
        public string Category { get; set; }
        public int HearingTime { get; set; }
        public int InterviewTime { get; set; }
        public int ReExamTime { get; set; }

        public ICollection<Hoauthtype1> Hoauthtype1 { get; set; }
    }
}
