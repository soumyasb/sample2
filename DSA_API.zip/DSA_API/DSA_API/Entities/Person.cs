﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Person
    {
        public Person()
        {
            Dsrcase = new HashSet<Dsrcase>();
            Dsrcomm = new HashSet<Dsrcomm>();
        }

        public string NbrDl { get; set; }
        public string AddrLn1 { get; set; }
        public string CdCity { get; set; }
        public string CdClassLic { get; set; }
        public string CdClassLic2 { get; set; }
        public string CdState { get; set; }
        public string CdZip { get; set; }
        public string CdZipAddrLst4 { get; set; }
        public DateTime? DtBirthPrsn { get; set; }
        public string FlgAddrConfdntl { get; set; }
        public string NbrPhone { get; set; }
        public int? NbrSsnPrsn { get; set; }
        public string NmeFrstPrsn { get; set; }
        public string NmeMidPrsn { get; set; }
        public string NmeSufxPrsn { get; set; }
        public string NmeSurnmePrsn { get; set; }

        public ICollection<Dsrcase> Dsrcase { get; set; }
        public ICollection<Dsrcomm> Dsrcomm { get; set; }
    }
}
