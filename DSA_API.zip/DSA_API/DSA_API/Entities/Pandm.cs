﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Pandm
    {
        public string CdPandm { get; set; }
        public string DescPandm { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
