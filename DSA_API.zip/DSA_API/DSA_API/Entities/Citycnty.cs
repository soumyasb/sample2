﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Citycnty
    {
        public int Id { get; set; }
        public string CdCity { get; set; }
        public string CdCoWthinCa { get; set; }
        public string DescCity { get; set; }
        public string FlgCityDup { get; set; }
    }
}
