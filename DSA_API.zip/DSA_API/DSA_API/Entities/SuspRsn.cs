﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class SuspRsn
    {
        public string CdSuspRsn { get; set; }
        public string DescSuspRsn { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
