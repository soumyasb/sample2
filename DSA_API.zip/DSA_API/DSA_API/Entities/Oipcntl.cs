﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Oipcntl
    {
        public string CdOip { get; set; }
        public string NbrOip { get; set; }
    }
}
