﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hearinglocprofile
    {
        public int LocProfileId { get; set; }
        public int HearingLocationId { get; set; }
        public DateTime DtEffStrt { get; set; }
        public DateTime? DtEffEnd { get; set; }
        public int? CdUpdtTechId { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string FlgActive { get; set; }
        public string FlgPhoneAvb { get; set; }
        public string TmeMonStrt { get; set; }
        public string TmeMonEnd { get; set; }
        public string TmeTueStrt { get; set; }
        public string TmeTueEnd { get; set; }
        public string TmeWedStrt { get; set; }
        public string TmeWedEnd { get; set; }
        public string TmeThuStrt { get; set; }
        public string TmeThuEnd { get; set; }
        public string TmeFriStrt { get; set; }
        public string TmeFriEnd { get; set; }
        public string TmeSatStrt { get; set; }
        public string TmeSatEnd { get; set; }
        public string TmeSunStrt { get; set; }
        public string TmeSunEnd { get; set; }

        public Employee CdUpdtTech { get; set; }
        public Hearinglocation HearingLocation { get; set; }
    }
}
