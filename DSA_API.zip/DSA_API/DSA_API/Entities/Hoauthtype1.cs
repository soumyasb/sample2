﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hoauthtype1
    {
        public int Id { get; set; }
        public int EmpId { get; set; }
        public int CategoryId { get; set; }
        public int HearingTime { get; set; }
        public int InterviewTime { get; set; }
        public int ReExamTime { get; set; }
        public DateTime LastUpdatedDate { get; set; }

        public Hearingtime1 Category { get; set; }
        public Employee Emp { get; set; }
    }
}
