﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Oiptype
    {
        public string CdPrtyTyp { get; set; }
        public string DescPrtyTyp { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
