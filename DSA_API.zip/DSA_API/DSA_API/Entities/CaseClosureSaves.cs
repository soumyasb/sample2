﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class CaseClosureSaves
    {
        public string CaseNumber { get; set; }
        public string HearingType { get; set; }
        public string HearingReason { get; set; }
        public string HearingResult { get; set; }
        public string TypeAction1 { get; set; }
        public string TypeAction2 { get; set; }
        public string Stayed { get; set; }
        public string StayType { get; set; }
        public string FormId { get; set; }
        public int TcodeStep { get; set; }
        public DateTime UpdateDate { get; set; }
        public string UpdateTechId { get; set; }
    }
}
