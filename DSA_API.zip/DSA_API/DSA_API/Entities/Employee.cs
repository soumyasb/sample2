﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Employee
    {
        public Employee()
        {
            Appointment = new HashSet<Appointment>();
            Contact = new HashSet<Contact>();
            Hearinglocprofile = new HashSet<Hearinglocprofile>();
            Hoauthtype = new HashSet<Hoauthtype>();
            Hoauthtype1 = new HashSet<Hoauthtype1>();
            NewsItem = new HashSet<NewsItem>();
            Profile = new HashSet<Profile>();
            Profile1CdUpdtTech = new HashSet<Profile1>();
            Profile1Emp = new HashSet<Profile1>();
        }

        public int EmpId { get; set; }
        public string CdEmpId { get; set; }
        public string CdEmpClass { get; set; }
        public string CdEmpTyp { get; set; }
        public string CdEmpRng { get; set; }
        public string CdLgnId { get; set; }
        public string CdOffId { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string NmeFrstPrsn { get; set; }
        public string NmeMidPrsn { get; set; }
        public string NmeSurnmePrsn { get; set; }
        public string NmeSufxPrsn { get; set; }
        public DateTime? DtTerminated { get; set; }
        public string FlgLoan { get; set; }
        public string FlgTransfer { get; set; }
        public string CdTransferOff { get; set; }
        public DateTime? DtTransfer { get; set; }
        public string CdLoanOff { get; set; }
        public DateTime? DtLoanStrt { get; set; }
        public DateTime? DtLoanEnd { get; set; }

        public EmployeeRole CdEmpTypNavigation { get; set; }
        public Dsoffice CdOff { get; set; }
        public ICollection<Appointment> Appointment { get; set; }
        public ICollection<Contact> Contact { get; set; }
        public ICollection<Hearinglocprofile> Hearinglocprofile { get; set; }
        public ICollection<Hoauthtype> Hoauthtype { get; set; }
        public ICollection<Hoauthtype1> Hoauthtype1 { get; set; }
        public ICollection<NewsItem> NewsItem { get; set; }
        public ICollection<Profile> Profile { get; set; }
        public ICollection<Profile1> Profile1CdUpdtTech { get; set; }
        public ICollection<Profile1> Profile1Emp { get; set; }
    }
}
