﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class BatchPrint
    {
        public int Id { get; set; }
        public string CdEmpId { get; set; }
        public string NbrDl { get; set; }
        public DateTime? DtPrnt { get; set; }
    }
}
