﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Pullnotinfo
    {
        public string CdPullnotinfo { get; set; }
        public string DescPullnotinfo { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
