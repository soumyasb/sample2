﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Restriction
    {
        public string CdRestrict { get; set; }
        public string DescRestrict { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
