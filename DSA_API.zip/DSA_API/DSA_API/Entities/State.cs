﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class State
    {
        public string CdNumState { get; set; }
        public string CdAlpState { get; set; }
        public string NmeState { get; set; }
    }
}
