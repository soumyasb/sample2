﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class OIPCaseDTO
    {
        public int OIPID { get; set; }
        public string CaseNumber { get; set; }
        public string Type { get; set; }
    }
}
