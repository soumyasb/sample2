﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class SearchResultDTO
    {
        private string _firstName;
        private string _lastName;

        public string FirstName
        {
            get
            {
                return new CultureInfo("en-US", false).TextInfo.ToTitleCase(_firstName.ToLower());
            }

            set
            {
                _firstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return new CultureInfo("en-US", false).TextInfo.ToTitleCase(_lastName.ToLower());
            }

            set
            {
                _lastName = value;
            }
        }
        public string dlNumber { get; set; }
        public List<CaseDetailDTO> Cases { get; set; }
    }
}
