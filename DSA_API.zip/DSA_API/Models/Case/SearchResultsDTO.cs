﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class SearchResultsDTO
    {
        public List<SearchResultDTO> results { get; set; }

        public int ResultCount
        {
            get { return results.Count(); }
        }
    }
}
