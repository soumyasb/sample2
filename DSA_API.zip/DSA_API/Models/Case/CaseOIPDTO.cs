﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class CaseOIPDTO
    {

        public List<OIPDTO> OIPs { get; set; }
        [DisplayName("OIP Type")]
        public IEnumerable<SelectListItem> OIP_TYPES { get; set; }
        public IEnumerable<SelectListItem> Language { get; set; }
        public int OIPCount
        {
            get
            {
                return OIPs.Count();
            }
        }
    }
}
