﻿using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class CaseDetailDTO
    {
        private string _caseStatus;

        public CustomerDTO Customer { get; set; }

        [DisplayName("Case Number")]
        public string CaseNumber { get; set; }

        [DisplayName("DL Number")]
        public string DLNumber { get; set; }

        public string SubjectName { get; set; }

        public System.DateTime DT_ORIG_TRANS { get; set; }

        [DisplayName("Created Date")]
        public string createdDate
        {
            get
            {
                return DT_ORIG_TRANS.ToString(@"MM\/dd\/yyyy");
            }
        }

        public string Reason { get; set; }

        public string DESC_HRNG_TYP { get; set; }

        [DisplayName("Reason")]
        public IEnumerable<SelectListItem> Reasons { get; set; }

        [DisplayName("Referral")]
        public IEnumerable<SelectListItem> Referrals { get; set; }

        [DisplayName("Special Cert/Endorsement")]
        public IEnumerable<SelectListItem> Certs { get; set; }

        [DisplayName("Hearing Type")]
        public IEnumerable<SelectListItem> HearingType { get; set; }

        [DisplayName("Case Status")]
        public string CaseStatus
        {
            get
            {
                return DetermineCaseStatus(_caseStatus);
            }

            set
            {
                _caseStatus = value;
            }
        }


        public string CaseStatusCode
        {
            get
            {
                return DetermineCaseStatus(_caseStatus).Substring(0, 2);
            }
        }

        [DisplayName("Received Date")]
        public string DateReceived
        {
            get
            {
                return DT_RCPT.ToString(@"MM\/dd\/yyyy");
            }
        }

        public System.DateTime DT_RCPT { get; set; }

        public string CD_REFR_SRCE_TYP { get; set; }

        public string CD_RSN { get; set; }

        public string CD_ENDR { get; set; }

        public string CD_HRNG_TYP { get; set; }

        public string DESC_RSN { get; set; }

        [DisplayName("First Name")]
        public string firstName { get; set; }

        [DisplayName("Last Name")]
        public string lastName { get; set; }

        public CaseCommentsDTO CaseComments { get; set; }

        public CaseOIPDTO CaseOIPs { get; set; }
        public string Message { get; set; }
        public bool Archived { get; set; }
        private string DetermineCaseStatus(string status)
        {
            string output = "";
            switch (status)
            {
                case "10":
                    output = "UN - UnScheduled";
                    break;
                case "13":
                    output = "SC - Scheduled";
                    break;
                case "15":
                case "25":
                case "35":
                    output = "CL - Closed";
                    break;
                case "16":
                case "26":
                case "36":
                    output = "UP - Updated/Report not completed";
                    break;
                case "20":
                    output = "UR - UnScheduled/Reschedule";
                    break;
                case "30":
                    output = "UC - UnScheduled/Reconvene";
                    break;
                case "23":
                    output = "RS - Rescheduled";
                    break;
                case "33":
                    output = "RC - Reconvened";
                    break;
                case "11":
                case "12":
                case "21":
                case "22":
                case "31":
                case "32":
                    output = "UN - UnScheduled";
                    break;
                default:
                    output = status;
                    break;
            }
            return output;
        }
    }
}
