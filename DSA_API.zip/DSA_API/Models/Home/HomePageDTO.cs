﻿using DSA_API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Home
{
    public class HomePageDTO
    {
        public int EmpID { get; set; }
        public string LoginId { get; set; }
        public string EmpInitial { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string OfficeId { get; set; }
        public Dsoffice Office { get; set; }
        public string NetName { get; set; }
        public string Role { get; set; }
        public string Classification { get; set; }
        public string EmpType { get; set; }
        public string LoanFlag { get; set; }
        public string LoanOfficeId { get; set; }
        public Dsoffice LoanOffice { get; set; }
        public IEnumerable<SuspenseDTO> Suspense { get; set; }
        public IEnumerable<NewsDTO> News { get; set; }
        public int NewsCount { get; set; }
        public int SuspenseCount { get; set; }
    }
}
