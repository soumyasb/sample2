﻿using AutoMapper;
using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Helpers;
using DSA_API.Models.Customer;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class CaseRepository : ICaseRepository
    {
        private DSAContext _context;
        private DSARCHIVEContext _archived_context;

        private MapperConfiguration _config;
        private IMapper _mapper;
        public CaseRepository(DSAContext context, DSARCHIVEContext archived_context)
        {
            _context = context;
            _archived_context = archived_context;
            _config = new MapperConfiguration(cfg => {
                cfg.CreateMap<OIPDTO, Oippersn>();
                cfg.CreateMap<OIPDTO, Agency>();
                cfg.CreateMap<OIPDTO, Caseoip>();
                cfg.CreateMap<OIPDTO, Caseagny>();
            });
            _mapper = _config.CreateMapper();
        }


        /// <summary>
        /// GET Case Details by CaseNumber
        /// </summary>
        /// <param name="CaseNumber"></param>
        /// <param name="Archived"></param>
        /// <returns></returns>
        public CaseDetailDTO GetCaseDetails(string CaseNumber, bool Archived)
        {
            var casedetail = new CaseDetailDTO();
            if (!Archived)
            {
                casedetail = (from c in _context.Dsrcase.AsNoTracking()

                                      //Left Join Alternative(one liner)
                                  from r in _context.Reason.Where(r => r.CdRsn == c.CdRsn).DefaultIfEmpty()
                                  from h in _context.Hearingtype.Where(h => h.CdHrngTyp == c.CdHrngTyp).DefaultIfEmpty()
                                  from p in _context.Person.Where(p => p.NbrDl == c.NbrDl).DefaultIfEmpty()

                                      //Simulated Left Join(Long Way)
                                      //join r in _context.REASONs.AsNoTracking().DefaultIfEmpty() on c.CD_RSN equals r.CD_RSN into trsn
                                      //from newrsn in trsn.DefaultIfEmpty()

                                      //Simple Join (No Good)
                                      //join r in _context.REASONs.AsNoTracking() on c.CD_RSN equals r.CD_RSN
                                      //join h in _context.HEARINGTYPEs.AsNoTracking() on c.CD_HRNG_TYP equals h.CD_HRNG_TYP
                                      //join p in _context.People.AsNoTracking() on c.NBR_DL equals p.NBR_DL
                                  where c.CdCase == CaseNumber
                                  select new CaseDetailDTO()
                                  {
                                      CaseNumber = c.CdCase,
                                      DLNumber = c.NbrDl,
                                      lastName = p.NmeSurnmePrsn,
                                      firstName = p.NmeFrstPrsn,
                                      CD_HRNG_TYP = c.CdHrngTyp,
                                      DESC_HRNG_TYP = h.DescHrngTyp,
                                      DT_ORIG_TRANS = c.DtOrigTrans,
                                      CaseStatus = c.CdStatusRec + c.CdStatusRec2,
                                      DT_RCPT = c.DtRcpt,
                                      CD_REFR_SRCE_TYP = c.CdRefrSrceTyp,
                                      CD_RSN = c.CdRsn,
                                      CD_ENDR = c.CdEndr,
                                      DESC_RSN = r.DescRsn,
                                      Archived = false
                                  }).FirstOrDefault();
            }
            else
            {
                casedetail.CaseNumber = CaseNumber;
                casedetail.CaseStatus = "35";
                casedetail.Archived = true;
            }
            return casedetail;
        }
        public IEnumerable<SelectListItem> GetHearingTypes()
        {
            var HearingTypes = (from h in _context.Hearingtype
                                orderby h.CdHrngTyp ascending
                                select new SelectListItem()
                                {
                                    Text = h.CdHrngTyp + " - " + h.DescHrngTyp,
                                    Value = h.CdHrngTyp
                                }).ToList();

            HearingTypes.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });

            return HearingTypes;
        }



        public IEnumerable<SelectListItem> GetReasons()
        {
            var reasons = (from r in _context.Reason
                            orderby r.CdRsn ascending
                            select new SelectListItem()
                            {
                                Text = r.CdRsn + " - " + r.DescRsn,
                                Value = r.CdRsn
                            }).ToList();
            reasons.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return reasons;
        }



        public IEnumerable<SelectListItem> GetReferrals()
        {
            var referrals = (from r in _context.Referral
                                orderby r.CdRefrSrceTyp ascending
                                select new SelectListItem()
                                {
                                    Text = r.CdRefrSrceTyp + " - " + r.DescRefrSrceTyp,
                                    Value = r.CdRefrSrceTyp
                                }).ToList();
            referrals.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return referrals;
        }




        public IEnumerable<SelectListItem> GetCerts()
        {
            var certs = (from c in _context.Cert
                            orderby c.CdCertEndr ascending
                            select new SelectListItem()
                            {
                                Text = c.CdCertEndr + " - " + c.DescCertEndr,
                                Value = c.CdCertEndr
                            }).ToList();
            certs.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return certs;
        }



        public List<CaseDetailDTO> GetCasesByDLNumber(string dlNumber)
        {
            List<CaseDetailDTO> casesDetailed = new List<CaseDetailDTO>();

            var archive_cases = (from c in _archived_context.Dsrcase
                         where c.NbrDl == dlNumber
                         orderby c.DtOrigTrans descending
                         select c.CdCase)
                            .ToArray();

            var cases = (from c in _context.Dsrcase
                            where c.NbrDl == dlNumber
                            orderby c.DtOrigTrans descending
                            select c.CdCase)
                            .ToArray();
           

            foreach (var i in archive_cases)
            {
                casesDetailed.Add(GetCaseDetails(i, true));
            }
            foreach (var i in cases)
            {
                casesDetailed.Add(GetCaseDetails(i, false));
            }
            return casesDetailed;
        }

        public CaseCommentsDTO GetCaseComments(string CaseNumber, int page)
        {
            const int PAGE_SIZE = 5;
            var query = (from c in _context.Dsrcomm
                            join emp in _context.Employee on c.CdUpdtTechId equals emp.CdEmpId
                            where c.CdCase == CaseNumber
                            select new CustomerCommentDTO()
                            {
                                TXT_COMM = c.TxtComm,
                                CD_UPDT_TECH_ID = c.CdUpdtTechId,
                                DT_UPDT_TRANS = c.DtUpdtTrans,
                                NBR_COMM = c.NbrComm,
                                EmployeeFullName = emp.NmeFrstPrsn + " " + emp.NmeSurnmePrsn
                            })
                            .AsQueryable();
            var TotalCount = query.Count();
            var TotalPages = Math.Ceiling((double)TotalCount / PAGE_SIZE);

            var results = query.OrderByDescending(c => c.DT_UPDT_TRANS)
                            .Skip(PAGE_SIZE * (page - 1))
                            .Take(PAGE_SIZE);

            return new CaseCommentsDTO()
            {
                TotalComments = TotalCount,
                TotalPages = TotalPages,
                Comments = results.ToList(),
                CurrentPage = page
            };
        }



        public bool SaveNewComment(string CaseNumber, string Comment, string Employee3Digit, string DLNumber)
        {
            int newestCommentNumber = 0;

            var caseCount = (from c in _context.Dsrcomm.AsNoTracking()
                                where c.CdCase == CaseNumber
                                select c.NbrComm
                                        ).ToArray();

            if (caseCount.Count() != 0)
            {
                newestCommentNumber = caseCount.Max();
            }

            try
            {
                using (_context)
                {
                    _context.Dsrcomm.Add(new Dsrcomm
                    {
                        TxtComm = Comment,
                        CdCase = CaseNumber,
                        CdUpdtTechId = Employee3Digit,
                        NbrDl = DLNumber,
                        NbrComm = ++newestCommentNumber,
                        CdFldDsoAlpha = "SAC",
                        DtUpdtTrans = System.DateTime.Now
                    });

                    _context.SaveChanges();
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }



        public List<OIPDTO> GetAssignedOIPs(string CaseNumber)
        {
            List<OIPDTO> OIPs = new List<OIPDTO>();
            List<OIPDTO> Agencies = new List<OIPDTO>();

            OIPs = (from p in _context.Oippersn
                    join c in _context.Caseoip.AsNoTracking() on p.Oipid equals c.Oipid
                    join d in _context.Dsrcase.AsNoTracking() on c.CdCase equals d.CdCase
                    where d.CdCase == CaseNumber
                    select new OIPDTO()
                    {
                        NME_FRST_PRSN = p.NmeFrstPrsn,
                        NME_SURNME_PRSN = p.NmeSurnmePrsn,
                        NME_MID_PRSN = p.NmeMidPrsn,
                        NME_SUFX_PRSN = p.NmeSufxPrsn,
                        NBR_PHONE = p.NbrPhone,
                        NBR_CELL_PHONE = p.NbrCellPhone,
                        NBR_FAX = p.NbrFax,
                        EmailAddress = p.EmailAddress,
                        NME_AGENCY = p.NmeAgency,
                        ADDR_LN1 = p.AddrLn1,
                        CD_CITY = p.CdCity,
                        CD_STATE = p.CdState,
                        CD_ZIP = p.CdZip,
                        TXT_COMM = p.TxtComm,
                        CD_PRTY_TYP = p.CdPrtyTyp,
                        OIPID = p.Oipid,
                        NBR_OIP = p.NbrOip
                    }).OrderBy(m => m.NME_SURNME_PRSN).ThenBy(m => m.NME_FRST_PRSN).ToList();

            Agencies = (from a in _context.Agency
                        join c in _context.Caseagny.AsNoTracking() on a.Oipid equals c.Oipid
                        join d in _context.Dsrcase.AsNoTracking() on c.CdCase equals d.CdCase
                        where d.CdCase == CaseNumber
                        select new OIPDTO()
                        {
                            NME_AGENCY = a.NmeAgency,
                            NBR_PHONE = a.NbrPhone,
                            NBR_CELL_PHONE = a.NbrCellPhone,
                            NBR_FAX = a.NbrFax,
                            EmailAddress = a.EmailAddress,
                            CD_CITY = a.CdCity,
                            CD_STATE = a.CdState,
                            CD_ZIP = a.CdZip,
                            TXT_COMM = a.TxtComm,
                            CD_PRTY_TYP = a.CdPrtyTyp,
                            OIPID = a.Oipid,
                            NBR_OIP = a.NbrOip
                        }).OrderBy(m => m.NME_AGENCY).ToList();

            foreach (OIPDTO vm in OIPs)
            {
                
                
                //vm.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = vm.OIPID, type = vm.CD_PRTY_TYP });
                //vm.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = vm.OIPID, casenumber = CaseNumber, type = vm.CD_PRTY_TYP });
            }

            foreach (OIPDTO vm in Agencies)
            {
                //vm.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = vm.OIPID, type = vm.CD_PRTY_TYP });
                //vm.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = vm.OIPID, casenumber = CaseNumber, type = vm.CD_PRTY_TYP });
            }

            OIPs.AddRange(Agencies);

            return OIPs;
        }


        public OIPDTO GetOIP(int OIPID)
        {
            var OIP = (from p in _context.Oippersn
                        where p.Oipid == OIPID
                        select new OIPDTO()
                        {
                            OIPID = p.Oipid,
                            NBR_OIP = p.NbrOip,
                            NME_FRST_PRSN = p.NmeFrstPrsn,
                            NME_SURNME_PRSN = p.NmeSurnmePrsn,
                            NME_MID_PRSN = p.NmeMidPrsn,
                            NME_SUFX_PRSN = p.NmeSufxPrsn,
                            NBR_PHONE = p.NbrPhone,
                            NBR_CELL_PHONE = p.NbrCellPhone,
                            NBR_FAX = p.NbrFax,
                            EmailAddress = p.EmailAddress,
                            NME_AGENCY = p.NmeAgency,
                            ADDR_LN1 = p.AddrLn1,
                            CD_CITY = p.CdCity,
                            CD_STATE = p.CdState,
                            CD_ZIP = p.CdZip,
                            TXT_COMM = p.TxtComm,
                            CD_PRTY_TYP = p.CdPrtyTyp
                        }).First();
            return OIP;
        }


        public OIPDTO GetAgency(int OIPID)
        {
            OIPDTO OIPVM = new OIPDTO();
            try
            {
                var OIP = (from a in _context.Agency
                            where a.Oipid == OIPID
                            select new OIPDTO()
                            {
                                OIPID = a.Oipid,
                                NBR_OIP = a.NbrOip,
                                NBR_PHONE = a.NbrPhone,
                                NBR_CELL_PHONE = a.NbrCellPhone,
                                NBR_FAX = a.NbrFax,
                                EmailAddress = a.EmailAddress,
                                NME_AGENCY = a.NmeAgency,
                                ADDR_LN1 = a.AddrLn1,
                                CD_CITY = a.CdCity,
                                CD_STATE = a.CdState,
                                CD_ZIP = a.CdZip,
                                TXT_COMM = a.TxtComm,
                                CD_PRTY_TYP = a.CdPrtyTyp
                            }).First();
                return OIP;
            }
            catch (Exception e)
            {
                return OIPVM;
            }
        }


        public OIPDTO UpdateOIP(OIPDTO OIPObj)
        {
            Oippersn mappedObj = _mapper.Map<OIPDTO, Oippersn>(OIPObj);

            try
            {
                _context.Oippersn.Attach(mappedObj);

                var update = _context.Entry(mappedObj);
                update.State = EntityState.Modified;

                update.Property(e => e.DtUpdtTrans).IsModified = false;

                _context.SaveChanges();

                OIPObj.Error = false;
            }
            catch (Exception e)
            {
                OIPObj.Error = true;
            }

            return OIPObj;
        }


        public int NewOIP(OIPDTO OIPObj)
        {
            Oippersn mappedObj = _mapper.Map<OIPDTO, Oippersn>(OIPObj);
            int OIPID;
            try
            {
                _context.Oippersn.Add(mappedObj);

                _context.SaveChanges();

                OIPID = mappedObj.Oipid;

                _context.Caseoip.Add(new Caseoip
                {
                    CdCase = OIPObj.CdCase,
                    Oipid = OIPID,
                    CdUpdtTechId = OIPObj.CD_UPDT_TECH_ID
                });

                _context.SaveChanges();
              

                return OIPID;
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        public int NewAgency(OIPDTO OIPObj)
        {
            Agency mappedObj = _mapper.Map<OIPDTO, Agency>(OIPObj);
            int OIPID;
            try
            {
                
                _context.Agency.Add(mappedObj);

                _context.SaveChanges();

                OIPID = mappedObj.Oipid;

                _context.Caseagny.Add(new Caseagny
                {
                    CdCase = OIPObj.CdCase,
                    Oipid = OIPID,
                    CdUpdtTechId = OIPObj.CD_UPDT_TECH_ID
                });

                _context.SaveChanges();
               

                return OIPID;
            }
            catch (Exception e)
            {
                return 0;
            }
        }


        public OIPDTO UpdateAgency(OIPDTO OIPObj)
        {
            Agency mappedObj = _mapper.Map<OIPDTO, Agency>(OIPObj);

            try
            {
                _context.Agency.Attach(mappedObj);

                var update = _context.Entry(mappedObj);
                update.State = EntityState.Modified;

                update.Property(e => e.DtUpdtTrans).IsModified = false;

                _context.SaveChanges();

                OIPObj.Error = false;
            }
            catch (Exception e)
            {
                OIPObj.Error = true;
            }

            return OIPObj;
        }


        public bool AssignOIPByCaseNumber(OIPDTO newOIP)
        {
            try
            {
                var exists = (from c in _context.Caseoip
                                where c.Oipid == newOIP.OIPID && c.CdCase == newOIP.CdCase
                                select c.CdCase).Count();

                if (exists == 0)
                {
                    _context.Caseoip.Add(new Caseoip
                    {
                        CdCase = newOIP.CdCase,
                        Oipid = newOIP.OIPID,
                        CdUpdtTechId = newOIP.CD_UPDT_TECH_ID
                    });

                    _context.SaveChanges();
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool AssignAgencyByCaseNumber(OIPDTO newOIP)
        {
            try
            {
               
                var exists = (from c in _context.Caseagny
                                where c.Oipid == newOIP.OIPID && c.CdCase == newOIP.CdCase
                                select c.CdCase).Count();

                if (exists == 0)
                {
                    _context.Caseagny.Add(new Caseagny
                    {
                        CdCase = newOIP.CdCase,
                        Oipid = newOIP.OIPID,
                        CdUpdtTechId = newOIP.CD_UPDT_TECH_ID
                    });

                    _context.SaveChanges();
                }
                else
                {
                    return false;
                }
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool RemoveAssignedOIPByCaseNumber(OIPDTO oipdto)
        {
            Caseoip mappedOIP = _mapper.Map<OIPDTO, Caseoip>(oipdto);
            try
            {
               
                _context.Caseoip.Attach(mappedOIP);
                _context.Caseoip.Remove(mappedOIP);
                _context.SaveChanges();
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool RemoveAssignedAgencyByCaseNumber(OIPDTO oipdto)
        {
            Caseagny mappedOIP = _mapper.Map<OIPDTO, Caseagny>(oipdto);
            try
            {
               
                _context.Caseagny.Attach(mappedOIP);
                _context.Caseagny.Remove(mappedOIP);
                _context.SaveChanges();
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }
}

