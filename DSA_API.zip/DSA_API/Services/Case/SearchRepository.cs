﻿using DSA_API.Entities;
using DSA_API.Models.Customer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class SearchRepository : ISearchRepository
    {
        private DSAContext _context;
        public SearchRepository(DSAContext context)
        {
            _context = context;
        }

        SearchResultsDTO peopleCases = new SearchResultsDTO();

        public SearchResultsDTO CaseSearch(string keyword)
        {
            peopleCases.results = new List<SearchResultDTO>();

            if (String.IsNullOrEmpty(keyword))
            {
                return peopleCases;
            }
            var results = (from p in _context.Person
                            join c in _context.Dsrcase on p.NbrDl equals c.NbrDl
                            where p.NmeFrstPrsn.Contains(keyword) ||
                            p.NmeSurnmePrsn.Contains(keyword) ||
                            p.NbrDl.Contains(keyword) ||
                            c.CdCase == keyword
                            select new
                            {
                                PERSON = p,
                                DSRCASE = p.Dsrcase
                            })
                            .AsQueryable();

            foreach (var r in results)
            {
                //List<CaseDetailViewModel> cases = new List<CaseDetailViewModel>();
                //foreach (var ca in r.DSRCASE)
                //{
                //    cases.Add(new CaseDetailViewModel()
                //    {
                //        CaseNumber = ca.CD_CASE,
                //        DT_ORIG_TRANS = ca.DT_ORIG_TRANS
                //    });
                //}

                if (peopleCases.results.Exists(p => p.dlNumber == r.PERSON.NbrDl))
                {

                }
                else
                {
                    peopleCases.results.Add(
                    new SearchResultDTO()
                    {
                        FirstName = r.PERSON.NmeFrstPrsn,
                        LastName = r.PERSON.NmeSurnmePrsn,
                        dlNumber = r.PERSON.NbrDl,
                        //Cases = cases.OrderBy(x => x.DT_ORIG_TRANS).ToList()
                    });
                }
            }
            

            return peopleCases;
        }
    }
}
