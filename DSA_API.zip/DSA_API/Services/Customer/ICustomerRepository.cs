﻿using DSA_API.Models.Customer;

namespace DSA_API.Services
{
    public interface ICustomerRepository
    {
        CustomerDTO getCustomerDetail(string dlNumber);
    }
}