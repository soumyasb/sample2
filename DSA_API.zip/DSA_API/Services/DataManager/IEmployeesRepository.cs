﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.DataManager;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services 
{
    public interface IEmployeesRepository
    {
        Employee Convert(EmployeeDTO emp);
        Employee ConvertForCreate(EmployeeDTO emp);
        IEnumerable<EmployeeDTO> getAllActiveEmployees();
        IEnumerable<EmployeeDTO> getAllEmployees();
        IEnumerable<SelectListItem> getClassificationList();
        IEnumerable<SelectListItem> getClassList();
        EmployeeDTO getEmployee(int EmployeeID);
        IEnumerable<SelectListItem> getOfficeList();
        bool Save();
    }
}