﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Entities;
using DSA_API.Models.Home;


namespace DSA_API.Services
{
    public class NewsItemRepository : INewsItemRepository
    {
        private DSAContext _context;

        public NewsItemRepository(DSAContext context)
        {
            _context = context;
        }

        public IEnumerable<NewsDTO> GetNewsItems(string officeid, out int newscount)
        {
           
            var news = _context.NewsItem.Where(x => x.OfficeNewsItem.Any(y => y.CdOffId == officeid) &
                 x.StartDate <= DateTime.Now & x.EndDate >= DateTime.Now).ToList();
                                
            var items = news.Select(n => new NewsDTO
            {
                AuthorName = n.AuthorName,
                Priority = n.Priority,
                CreateDate = n.CreateDate,
                Subject = n.Subject,
                NewsText = n.NewsText
            }).ToList();
            newscount = items.Count;
            return items;
        }
        public void DeleteNewsItem(NewsItem newsitem)
        {
            _context.NewsItem.Remove(newsitem);
        }
        public NewsItem GetNewsItem(int id)
        {
            return _context.NewsItem.FirstOrDefault(a => a.NewsId == id);
        }
        public void AddNewsItem(NewsItem newsitem)
        {
            _context.NewsItem.Add(newsitem);
        }
        public void UpdateNewsItem(NewsItem newsItem)
        {
            // no code in this implementation
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }
        public bool NewsitemExists(int id)
        {
            return _context.NewsItem.Any(a => a.NewsId == id);
        }



    }
}
