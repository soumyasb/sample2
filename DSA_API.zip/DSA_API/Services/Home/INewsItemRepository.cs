﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.Home;

namespace DSA_API.Services
{
    public interface INewsItemRepository
    {
        void AddNewsItem(NewsItem newsitem);
        void DeleteNewsItem(NewsItem newsitem);
        NewsItem GetNewsItem(int id);
        IEnumerable<NewsDTO> GetNewsItems(string officeid, out int newscount);
        bool NewsitemExists(int id);
        bool Save();
        void UpdateNewsItem(NewsItem newsItem);
        
    }
}