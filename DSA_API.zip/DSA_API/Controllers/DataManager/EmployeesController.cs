﻿using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.DataManager;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

namespace DSA_API.Controllers.DataManager
{
    [Produces("application/json")]
    [Route("api/DataManager/Employees")]
    public class EmployeesController : Controller
    {
        private DSAContext _context;
        private IEmployeesRepository _employeesRepository;
        private IUserRepository _userRepository;
        private Employee _user;

        public EmployeesController(IEmployeesRepository employeesRepository, IUserRepository userRepository, DSAContext context)
        {
            _context = context;
            _employeesRepository = employeesRepository;
            _userRepository = userRepository;
        }


        //GET Api/Employees
        [HttpGet (Name = "GetEmployees")]
        public IActionResult GetEmployees()
        {
            //IEnumerable<EmployeeDTO> model = new IEnumerable<EmployeeDTO>();

            //EmployeeIndexViewModel model = new EmployeeIndexViewModel();
            //model.Employees = repo.getAllEmployees().OrderBy(m => m.LastName);

            var model = _employeesRepository.getAllEmployees();

            return Ok(model);
        }

        //GET Api/Employees/1
        [HttpGet ("GetEmployee/{id}", Name = "GetEmployee")]
        public IActionResult GetEmployee(int? id)
        {
            if (id == null)
                return NotFound();

            EmployeeDTO employee = _employeesRepository.getEmployee(id.Value);
            if (employee == null)
                return NotFound(); 
            
            employee.OfficeList = _employeesRepository.getOfficeList();
            employee.ClassList = _employeesRepository.getClassList();
            employee.ClassificationList = _employeesRepository.getClassificationList();

            return Ok(employee);
        }

        //POST /api/employees
        [HttpPost ("CreateEmployee")]
       // [ValidateAntiForgeryToken]
        public IActionResult CreateEmployee([FromBody] EmployeeDTO employee)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
            employee.LastUpdBy = _user.CdUpdtTechId;
           // employee.LastUpdBy = User.Identity.Name.Substring(2, 3).ToUpper();
            employee.DateUpdated = DateTime.Now;
            var employee1 = _employeesRepository.ConvertForCreate(employee);

            _context.Employee.Add(employee1);
            _context.SaveChanges();

            //EmployeeViewModel employeeVM = new EmployeeViewModel();
            //EmployeeDTO employee2 = repo.getEmployee(employee1.EmpId);
            //employeeVM.employee = employee2;
            //employeeVM.OfficeList = repo.getOfficeList();
            //employeeVM.ClassList = repo.getClassList();
            //employeeVM.ClassificationList = repo.getClassificationList();
            return CreatedAtRoute("GetEmployee",
                new { id = employee.Empid },
                employee);
            //return Created(new Uri(Request.RequestUri + "/" + employee2.Empid), employeeVM);
        }

        //POST /api/employees/1
        [HttpPost("UpdateEmployee")]
       // [ValidateAntiForgeryToken]
        public IActionResult UpdateEmployee([FromBody] EmployeeDTO employee)
        {
            if (!ModelState.IsValid)
                return new UnprocessableEntityObjectResult(ModelState);
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
            //employee.LastUpdBy = User.Identity.Name.Substring(2, 3).ToUpper();
            employee.LastUpdBy = _user.CdUpdtTechId;
            var employee01 = _employeesRepository.Convert(employee);

            _context.Entry(employee01).State = EntityState.Modified;
            _context.SaveChanges();
            return CreatedAtRoute("GetEmployee",
                new { id = employee.Empid },
                employee);
        }

        //POST /api/employees/1
        [HttpPost ("DeleteEmployee/{id}")]
       // [ValidateAntiForgeryToken]
        public IActionResult DeleteEmployee(int id)
        {
            if (id == 0)
                return BadRequest();
            DateTime thisDate1 = new DateTime(2018, 12, 31);

            EmployeeDTO employee = _employeesRepository.getEmployee(id);

            if (employee == null)
                 return NotFound();
            employee.DateTerminated = thisDate1;
            var employee01 = _employeesRepository.Convert(employee);

            _context.Entry(employee01).State = EntityState.Modified;
            
            _context.SaveChanges();

            return NoContent();
        }
    }
}