﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DSA_API.Models.Customer;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/Oip")]
    public class OipController : Controller
    {
        private ICaseRepository _caseRepository;
        private IUrlHelper _urlHelper;
        public OipController(ICaseRepository caseRepository, IUrlHelper urlHelper)
        {
            _caseRepository = caseRepository;
            _urlHelper = urlHelper;
        }

        [HttpGet("GetAll/{CaseNumber}")]        public IEnumerable<OIPDTO> GetAll(string CaseNumber)
        {
           return _caseRepository.GetAssignedOIPs(CaseNumber);
        }


        [HttpGet("GetOIP/{type}/{oipid}")]
        public OIPDTO Get(string type, int oipid)
        {
            OIPDTO Model = (type == "N" || type == "L") ? _caseRepository.GetAgency(oipid) : _caseRepository.GetOIP(oipid);
            Model.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = Model.OIPID, type = Model.CD_PRTY_TYP });
            return Model;
        }
        [HttpPost("{type}/{oipid?}")]
        public object Post([FromBody] OIPDTO OIPObj, string type, int? oipid = null)
        {
            if (type == "L" || type == "N")
            {
                return (oipid == null) ? SaveNewAgency(OIPObj) : UpdateAgency((int)oipid, OIPObj);
            }
            else
            {
                return (oipid == null) ? SaveNewOIP(OIPObj) : UpdateOIP((int)oipid, OIPObj);
            }
        }



        private object SaveNewOIP(OIPDTO NewOIP)
        {

            //var identity = (ClaimsIdentity)User.Identity;
            string StatusMessage;
            bool error;
            //var helper = new UrlHelper(Request);
            //NewOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            NewOIP.CD_UPDT_TECH_ID = "MPG";
            var result = _caseRepository.NewOIP(NewOIP);

            NewOIP.OIPID = result;

            if (result != 0)
            {
                StatusMessage = "New OIP Saved";
                error = false;
            }
            else
            {
                StatusMessage = "Failed to Save";
                error = true;
            }
            return new
            {
                Action = "SAVE",
                OIPID = result,
                OIP = NewOIP,
                APIURI = _urlHelper.RouteUrl("OIPID", new { type = NewOIP.CD_PRTY_TYP, oipid = result }),
                NME_FRST_PRSN = NewOIP.NME_FRST_PRSN,
                NME_SURNME_PRSN = NewOIP.NME_SURNME_PRSN,
                Error = error,
                Title = "New OIP",
                StatusMessage = StatusMessage
            };
        }


        private object UpdateOIP(int oipid, OIPDTO EditOIP)
        {

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            string StatusMessage;
            bool error;
            //EditOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            EditOIP.CD_UPDT_TECH_ID = "MPG";
            if (!_caseRepository.UpdateOIP(EditOIP).Error)
            {
                StatusMessage = "OIP Update Successful";
                error = false;
            }
            else
            {
                StatusMessage = "OIP Update Failed";
                error = true;
            }

            return new
            {
                Action = "UPDATE",
                OIPID = oipid,
                OIP = EditOIP,
                APIURI = _urlHelper.RouteUrl("OIPID", new { type = EditOIP.CD_PRTY_TYP, oipid = oipid }),
                NME_FRST_PRSN = EditOIP.NME_FRST_PRSN,
                NME_SURNME_PRSN = EditOIP.NME_SURNME_PRSN,
                Error = error,
                Title = "Update OIP",
                StatusMessage = StatusMessage
            };
        }


        private object SaveNewAgency(OIPDTO NewOIP)
        {
            //var identity = (ClaimsIdentity)User.Identity;

            string StatusMessage;
            bool error;
            //NewOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            NewOIP.CD_UPDT_TECH_ID = "MPG";
            var result = _caseRepository.NewAgency(NewOIP);

            NewOIP.OIPID = result;

            if (result != 0)
            {
                StatusMessage = "New OIP Agency Saved";
                error = false;
            }
            else
            {
                StatusMessage = "Failed to Save";
                error = true;
            }
            return new
            {
                Action = "SAVE",
                OIPID = result,
                OIP = NewOIP,
                APIURI = _urlHelper.RouteUrl("OIPID", new { oipid = result, type = NewOIP.CD_PRTY_TYP }),
                NME_AGENCY = NewOIP.NME_AGENCY,
                Error = error,
                Title = "New OIP Agency",
                StatusMessage = StatusMessage
            };
        }

        private object UpdateAgency(int oipid, OIPDTO EditOIP)
        {
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
                        
            string StatusMessage;
            bool error;
            //EditOIP.CD_UPDT_TECH_ID = identity.FindFirst("EmployeeThreeDigit").Value;
            EditOIP.CD_UPDT_TECH_ID = "MPG";
            if (!_caseRepository.UpdateAgency(EditOIP).Error)
            {
                StatusMessage = "OIP Agency Update Successful";
                error = false;
            }
            else
            {
                StatusMessage = "OIP Agency Update Failed";
                error = true;
            }

            return new
            {
                Action = "UPDATE",
                OIP = EditOIP,
                OIPID = oipid,
                APIURI = _urlHelper.RouteUrl("OIPID", new { oipid = oipid, type = EditOIP.CD_PRTY_TYP }),
                NME_AGENCY = EditOIP.NME_AGENCY,
                Error = error,
                Title = "Update OIP",
                StatusMessage = StatusMessage
            };
        }
    }
   
}