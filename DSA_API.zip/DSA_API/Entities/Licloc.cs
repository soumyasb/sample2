﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Licloc
    {
        public string CdLicloc { get; set; }
        public string CdOffice { get; set; }
        public string DescLicloc { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
