﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Filecondition
    {
        public string CdFilecond { get; set; }
        public string DescFilecond { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
