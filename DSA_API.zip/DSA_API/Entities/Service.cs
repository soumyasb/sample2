﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Service
    {
        public string CdService { get; set; }
        public string TxtDescService { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
