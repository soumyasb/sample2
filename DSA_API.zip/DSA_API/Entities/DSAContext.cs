﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;


namespace DSA_API.Entities
{
    public partial class DSAContext : DbContext
    {
        internal object AGENCies;

        public DSAContext(DbContextOptions<DSAContext> options)
                : base(options)
        { }
      
        public virtual DbSet<Activitytype> Activitytype { get; set; }
        public virtual DbSet<Agency> Agency { get; set; }
        public virtual DbSet<Apperrlog> Apperrlog { get; set; }
        public virtual DbSet<Appointment> Appointment { get; set; }
        public virtual DbSet<ApptCntl> ApptCntl { get; set; }
        public virtual DbSet<ApptLog> ApptLog { get; set; }
        public virtual DbSet<Attachments> Attachments { get; set; }
        public virtual DbSet<Authoritysection> Authoritysection { get; set; }
        public virtual DbSet<BatchPrint> BatchPrint { get; set; }
        public virtual DbSet<Caseagny> Caseagny { get; set; }
        public virtual DbSet<CaseClosureFormIndex> CaseClosureFormIndex { get; set; }
        public virtual DbSet<CaseClosureFormRules> CaseClosureFormRules { get; set; }
        public virtual DbSet<CaseClosureSaves> CaseClosureSaves { get; set; }
        public virtual DbSet<Caseoip> Caseoip { get; set; }
        public virtual DbSet<CaseSuspense> CaseSuspense { get; set; }
        public virtual DbSet<Cert> Cert { get; set; }
        public virtual DbSet<Citycnty> Citycnty { get; set; }
        public virtual DbSet<Cofocodes> Cofocodes { get; set; }
        public virtual DbSet<CommercialStatusInd> CommercialStatusInd { get; set; }
        public virtual DbSet<CommFileCond> CommFileCond { get; set; }
        public virtual DbSet<Contact> Contact { get; set; }
        public virtual DbSet<Deceasedcodes> Deceasedcodes { get; set; }
        public virtual DbSet<Dlupdstats> Dlupdstats { get; set; }
        public virtual DbSet<DocGeneration> DocGeneration { get; set; }
        public virtual DbSet<Docimage> Docimage { get; set; }
        public virtual DbSet<Dsoffice> Dsoffice { get; set; }
        public virtual DbSet<Dsrcase> Dsrcase { get; set; }
        public virtual DbSet<Dsrcomm> Dsrcomm { get; set; }
        public virtual DbSet<Dsrlog> Dsrlog { get; set; }
        public virtual DbSet<Dukcodes> Dukcodes { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<EmployeeClass> EmployeeClass { get; set; }
        public virtual DbSet<EmployeeRole> EmployeeRole { get; set; }
        public virtual DbSet<Endstaycodes> Endstaycodes { get; set; }
        public virtual DbSet<FieldFile> FieldFile { get; set; }
        public virtual DbSet<Filecondition> Filecondition { get; set; }
        public virtual DbSet<Hearinglocation> Hearinglocation { get; set; }
        public virtual DbSet<Hearinglocprofile> Hearinglocprofile { get; set; }
        public virtual DbSet<Hearingtime> Hearingtime { get; set; }
        public virtual DbSet<Hearingtime1> Hearingtime1 { get; set; }
        public virtual DbSet<Hearingtype> Hearingtype { get; set; }
        public virtual DbSet<HoauthorityTypeEmployee> HoauthorityTypeEmployee { get; set; }
        public virtual DbSet<Hoauthtype> Hoauthtype { get; set; }
        public virtual DbSet<Hoauthtype1> Hoauthtype1 { get; set; }
        public virtual DbSet<Holiday> Holiday { get; set; }
        public virtual DbSet<Interpre> Interpre { get; set; }
        public virtual DbSet<Language> Language { get; set; }
        public virtual DbSet<Lawagency> Lawagency { get; set; }
        public virtual DbSet<Licloc> Licloc { get; set; }
        public virtual DbSet<NetAllProgramCostHours> NetAllProgramCostHours { get; set; }
        public virtual DbSet<NewsItem> NewsItem { get; set; }
        public virtual DbSet<OfficeNewsItem> OfficeNewsItem { get; set; }
        public virtual DbSet<Oipcntl> Oipcntl { get; set; }
        public virtual DbSet<Oippersn> Oippersn { get; set; }
        public virtual DbSet<Oiptype> Oiptype { get; set; }
        public virtual DbSet<OswithDrawalType> OswithDrawalType { get; set; }
        public virtual DbSet<Pandm> Pandm { get; set; }
        public virtual DbSet<ParaIns> ParaIns { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<Profile> Profile { get; set; }
        public virtual DbSet<Profile1> Profile1 { get; set; }
        public virtual DbSet<Profileday> Profileday { get; set; }
        public virtual DbSet<Pullnotice> Pullnotice { get; set; }
        public virtual DbSet<Pullnotinfo> Pullnotinfo { get; set; }
        public virtual DbSet<Pullnotpurge> Pullnotpurge { get; set; }
        public virtual DbSet<Pullnotreas> Pullnotreas { get; set; }
        public virtual DbSet<Reacat> Reacat { get; set; }
        public virtual DbSet<Reason> Reason { get; set; }
        public virtual DbSet<Referral> Referral { get; set; }
        public virtual DbSet<Region> Region { get; set; }
        public virtual DbSet<Reports> Reports { get; set; }
        public virtual DbSet<Restriction> Restriction { get; set; }
        public virtual DbSet<RowColumnHexValue> RowColumnHexValue { get; set; }
        public virtual DbSet<RowColumnHexValues> RowColumnHexValues { get; set; }
        public virtual DbSet<Schedresults> Schedresults { get; set; }
        public virtual DbSet<Sdttype> Sdttype { get; set; }
        public virtual DbSet<Service> Service { get; set; }
        public virtual DbSet<State> State { get; set; }
        public virtual DbSet<StayStats> StayStats { get; set; }
        public virtual DbSet<SuspenseReason> SuspenseReason { get; set; }
        public virtual DbSet<SuspRsn> SuspRsn { get; set; }
        public virtual DbSet<TransLicLoc> TransLicLoc { get; set; }
        public virtual DbSet<TransSchedResult> TransSchedResult { get; set; }
        public virtual DbSet<TransTypeAction> TransTypeAction { get; set; }
        public virtual DbSet<Transtypehrng> Transtypehrng { get; set; }
        public virtual DbSet<Typeaction> Typeaction { get; set; }
        public virtual DbSet<Updatecodes> Updatecodes { get; set; }
        public virtual DbSet<Withholdrsn> Withholdrsn { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Activitytype>(entity =>
            {
                entity.ToTable("ACTIVITYTYPE");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdActvyTyp)
                    .IsRequired()
                    .HasColumnName("CD_ACTVY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdTypes)
                    .IsRequired()
                    .HasColumnName("CD_TYPES")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DescActvyTyp)
                    .IsRequired()
                    .HasColumnName("DESC_ACTVY_TYP")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("DT_TERM")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgConfTyp).HasColumnName("FLG_CONF_TYP");

                entity.Property(e => e.LastUpdatedBy)
                    .HasColumnName("lastUpdatedBy")
                    .HasColumnType("nchar(10)");

                entity.Property(e => e.LastUpdatedDate)
                    .HasColumnName("lastUpdatedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.TxtActvyAbbr)
                    .IsRequired()
                    .HasColumnName("TXT_ACTVY_ABBR")
                    .HasColumnType("char(3)");
            });

            modelBuilder.Entity<Agency>(entity =>
            {
                entity.HasKey(e => e.Oipid);

                entity.ToTable("AGENCY");

                entity.HasIndex(e => e.Oipid)
                    .HasName("NBR_OIP_IND")
                    .IsUnique();

                entity.Property(e => e.Oipid).HasColumnName("OIPID");

                entity.Property(e => e.AddrLn1)
                    .HasColumnName("ADDR_LN1")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.CdCity)
                    .HasColumnName("CD_CITY")
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.CdPrtyTyp)
                    .IsRequired()
                    .HasColumnName("CD_PRTY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdState)
                    .HasColumnName("CD_STATE")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdZip)
                    .HasColumnName("CD_ZIP")
                    .HasColumnType("char(5)");

                entity.Property(e => e.CdZipAddrLst4)
                    .HasColumnName("CD_ZIP_ADDR_LST4")
                    .HasColumnType("char(4)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EmailAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NbrCellPhone)
                    .HasColumnName("NBR_CELL_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrFax)
                    .HasColumnName("NBR_FAX")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrOip)
                    .HasColumnName("NBR_OIP")
                    .HasColumnType("char(6)");

                entity.Property(e => e.NbrPhone)
                    .IsRequired()
                    .HasColumnName("NBR_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NmeAgency)
                    .IsRequired()
                    .HasColumnName("NME_AGENCY")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.TxtComm)
                    .HasColumnName("TXT_COMM")
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Apperrlog>(entity =>
            {
                entity.ToTable("apperrlog");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdErrTyp)
                    .IsRequired()
                    .HasColumnName("CD_ERR_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DtErr)
                    .HasColumnName("DT_ERR")
                    .HasColumnType("datetime");

                entity.Property(e => e.NbrErr)
                    .IsRequired()
                    .HasColumnName("NBR_ERR")
                    .HasColumnType("char(13)");

                entity.Property(e => e.NbrErrLine).HasColumnName("NBR_ERR_LINE");

                entity.Property(e => e.NmeModule)
                    .IsRequired()
                    .HasColumnName("NME_MODULE")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.NmeOperId)
                    .IsRequired()
                    .HasColumnName("NME_OPER_ID")
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.NmeProc)
                    .IsRequired()
                    .HasColumnName("NME_PROC")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.ValErrKey1)
                    .HasColumnName("VAL_ERR_KEY1")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Appointment>(entity =>
            {
                entity.ToTable("APPOINTMENT");

                entity.HasIndex(e => e.NbrRcurApt)
                    .HasName("indxappointment");

                entity.HasIndex(e => new { e.CdEmpOffId, e.DtStrtTim, e.DtEndTim, e.CdDayTyp, e.CdDteTyp, e.CdMonTyp, e.CdOccDayTyp, e.CdOccTyp, e.NbrRoom, e.FlgAllDay, e.FlgDelete, e.NbrAppt, e.NbrRcurApt })
                    .HasName("indxappointment2");

                entity.Property(e => e.AppointmentId).HasColumnName("APPOINTMENT_ID");

                entity.Property(e => e.CdActvyTyp)
                    .IsRequired()
                    .HasColumnName("CD_ACTVY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdDayTyp)
                    .HasColumnName("CD_DAY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdDteTyp)
                    .HasColumnName("CD_DTE_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdEmpOffId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdMonTyp)
                    .HasColumnName("CD_MON_TYP")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdOccDayTyp)
                    .HasColumnName("CD_OCC_DAY_TYP")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdOccTyp)
                    .HasColumnName("CD_OCC_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdUpdtTechId)
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtEndTim)
                    .HasColumnName("DT_END_TIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtStrtTim)
                    .HasColumnName("DT_STRT_TIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgAllDay)
                    .IsRequired()
                    .HasColumnName("FLG_ALL_DAY")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.FlgDelete)
                    .IsRequired()
                    .HasColumnName("FLG_DELETE")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.FlgDispCmt)
                    .IsRequired()
                    .HasColumnName("FLG_DISP_CMT")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.NbrAppt).HasColumnName("NBR_APPT");

                entity.Property(e => e.NbrRcurApt).HasColumnName("NBR_RCUR_APT");

                entity.Property(e => e.NbrRoom)
                    .IsRequired()
                    .HasColumnName("NBR_ROOM")
                    .HasColumnType("char(3)");

                entity.Property(e => e.TxtComment)
                    .HasColumnName("TXT_COMMENT")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.Appointment)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_APPOINTMENT_Employee");
            });

            modelBuilder.Entity<ApptCntl>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.NbrSeq).HasColumnName("NBR_SEQ");

                entity.Property(e => e.NbrTyp).HasColumnName("NBR_TYP");
            });

            modelBuilder.Entity<ApptLog>(entity =>
            {
                entity.ToTable("appt_log");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdActvyTyp)
                    .IsRequired()
                    .HasColumnName("CD_ACTVY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(8)");

                entity.Property(e => e.CdEmpOffId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtEndTim)
                    .HasColumnName("DT_END_TIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtMod)
                    .HasColumnName("DT_MOD")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtStrtTim)
                    .HasColumnName("DT_STRT_TIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgSuccess).HasColumnName("FLG_SUCCESS");

                entity.Property(e => e.FlgTyp)
                    .IsRequired()
                    .HasColumnName("FLG_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrAppt).HasColumnName("NBR_APPT");

                entity.Property(e => e.NbrRcurApt).HasColumnName("NBR_RCUR_APT");

                entity.Property(e => e.NbrRoom)
                    .IsRequired()
                    .HasColumnName("NBR_ROOM")
                    .HasColumnType("char(3)");
            });

            modelBuilder.Entity<Attachments>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdAttachments)
                    .HasColumnName("CD_ATTACHMENTS")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DescAttachments)
                    .HasColumnName("DESC_ATTACHMENTS")
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Authoritysection>(entity =>
            {
                entity.ToTable("AUTHORITYSECTION");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdTransaction)
                    .IsRequired()
                    .HasColumnName("CD_TRANSACTION")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdVc)
                    .IsRequired()
                    .HasColumnName("CD_VC")
                    .HasColumnType("char(8)");

                entity.Property(e => e.DescAuthority)
                    .IsRequired()
                    .HasColumnName("DESC_AUTHORITY")
                    .HasColumnType("char(50)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<BatchPrint>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtPrnt)
                    .HasColumnName("DT_PRNT")
                    .HasColumnType("datetime");

                entity.Property(e => e.NbrDl)
                    .IsRequired()
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)");
            });

            modelBuilder.Entity<Caseagny>(entity =>
            {
                entity.HasKey(e => new { e.Oipid, e.CdCase });

                entity.ToTable("CASEAGNY");

                entity.HasIndex(e => new { e.CdCase, e.Oipid })
                    .HasName("caseagny_ind")
                    .IsUnique();

                entity.Property(e => e.Oipid).HasColumnName("OIPID");

                entity.Property(e => e.CdCase)
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.CdSubpoe)
                    .HasColumnName("CD_SUBPOE")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FlgNotcAppt)
                    .HasColumnName("FLG_NOTC_APPT")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgNotcDec)
                    .HasColumnName("FLG_NOTC_DEC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgService)
                    .HasColumnName("FLG_SERVICE")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgSubpoeDmv)
                    .HasColumnName("FLG_SUBPOE_DMV")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgSubpoeSubj)
                    .HasColumnName("FLG_SUBPOE_SUBJ")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrOip)
                    .HasColumnName("NBR_OIP")
                    .HasColumnType("char(6)");

                entity.Property(e => e.NbrSeqOip).HasColumnName("NBR_SEQ_OIP");

                entity.Property(e => e.NmeFrstPrsn)
                    .HasColumnName("NME_FRST_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeMidPrsn)
                    .HasColumnName("NME_MID_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeSufxPrsn)
                    .HasColumnName("NME_SUFX_PRSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NmeSurnmePrsn)
                    .HasColumnName("NME_SURNME_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.TxtOther)
                    .HasColumnName("TXT_OTHER")
                    .HasMaxLength(180)
                    .IsUnicode(false);

                entity.HasOne(d => d.CdCaseNavigation)
                    .WithMany(p => p.Caseagny)
                    .HasForeignKey(d => d.CdCase)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CASEAGNY_DSRCASE");

                entity.HasOne(d => d.Oip)
                    .WithMany(p => p.Caseagny)
                    .HasForeignKey(d => d.Oipid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CASEAGNY_AGENCY");
            });

            modelBuilder.Entity<CaseClosureFormIndex>(entity =>
            {
                entity.HasKey(e => new { e.TypeAction1, e.TypeAction2, e.ReasonCode, e.StayIndicator, e.HearingType });

                entity.Property(e => e.TypeAction1)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TypeAction2)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ReasonCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.StayIndicator)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HearingType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.FormId)
                    .IsRequired()
                    .HasColumnName("FormID")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastAccessDt).HasColumnType("datetime");
            });

            modelBuilder.Entity<CaseClosureFormRules>(entity =>
            {
                entity.HasKey(e => new { e.FormId, e.ControlName, e.Action });

                entity.Property(e => e.FormId)
                    .HasColumnName("FormID")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ControlName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Action)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Value)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CaseClosureSaves>(entity =>
            {
                entity.HasKey(e => e.CaseNumber);

                entity.Property(e => e.CaseNumber)
                    .HasColumnType("char(12)")
                    .ValueGeneratedNever();

                entity.Property(e => e.FormId)
                    .IsRequired()
                    .HasColumnName("FormID")
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.HearingReason)
                    .IsRequired()
                    .HasColumnType("char(3)");

                entity.Property(e => e.HearingResult)
                    .IsRequired()
                    .HasColumnType("char(1)");

                entity.Property(e => e.HearingType)
                    .IsRequired()
                    .HasColumnType("char(1)");

                entity.Property(e => e.StayType)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Stayed)
                    .IsRequired()
                    .HasColumnType("char(1)");

                entity.Property(e => e.TypeAction1)
                    .IsRequired()
                    .HasColumnType("char(2)");

                entity.Property(e => e.TypeAction2)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UpdateTechId)
                    .IsRequired()
                    .HasColumnName("UpdateTechID")
                    .HasColumnType("char(3)");
            });

            modelBuilder.Entity<Caseoip>(entity =>
            {
                entity.HasKey(e => new { e.CdCase, e.Oipid });

                entity.ToTable("CASEOIP");

                entity.HasIndex(e => new { e.CdCase, e.Oipid })
                    .HasName("caseoip_ind")
                    .IsUnique();

                entity.Property(e => e.CdCase)
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.Oipid).HasColumnName("OIPID");

                entity.Property(e => e.CdSubpoe)
                    .HasColumnName("CD_SUBPOE")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FlgAuto)
                    .HasColumnName("FLG_AUTO")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgMed)
                    .HasColumnName("FLG_MED")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgNotcAppt)
                    .HasColumnName("FLG_NOTC_APPT")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgNotcDec)
                    .HasColumnName("FLG_NOTC_DEC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgService)
                    .HasColumnName("FLG_SERVICE")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgSubpoeDmv)
                    .HasColumnName("FLG_SUBPOE_DMV")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgSubpoeSubj)
                    .HasColumnName("FLG_SUBPOE_SUBJ")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrOip)
                    .HasColumnName("NBR_OIP")
                    .HasColumnType("char(6)");

                entity.Property(e => e.TxtOther)
                    .HasColumnName("TXT_OTHER")
                    .HasMaxLength(180)
                    .IsUnicode(false);

                entity.HasOne(d => d.CdCaseNavigation)
                    .WithMany(p => p.Caseoip)
                    .HasForeignKey(d => d.CdCase)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CASEOIP_DSRCASE");

                entity.HasOne(d => d.Oip)
                    .WithMany(p => p.Caseoip)
                    .HasForeignKey(d => d.Oipid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CASEOIP_OIPPERSN");
            });

            modelBuilder.Entity<CaseSuspense>(entity =>
            {
                entity.HasKey(e => e.SuspenseId);

                entity.Property(e => e.SuspenseId).HasColumnName("Suspense_ID");

                entity.Property(e => e.CdCase)
                    .IsRequired()
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.CdSuspReqBy)
                    .IsRequired()
                    .HasColumnName("CD_SUSP_REQ_BY")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdSuspRsn)
                    .IsRequired()
                    .HasColumnName("CD_SUSP_RSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdUpdtTechId)
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtSusp)
                    .HasColumnName("DT_SUSP")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.NbrSequence).HasColumnName("NBR_SEQUENCE");

                entity.Property(e => e.TxtSusp)
                    .HasColumnName("TXT_SUSP")
                    .HasColumnType("char(35)");

                entity.HasOne(d => d.CdCaseNavigation)
                    .WithMany(p => p.CaseSuspense)
                    .HasForeignKey(d => d.CdCase)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CaseSuspense_DSRCASE");
            });

            modelBuilder.Entity<Cert>(entity =>
            {
                entity.HasKey(e => e.CdCertEndr);

                entity.ToTable("CERT");

                entity.Property(e => e.CdCertEndr)
                    .HasColumnName("CD_CERT_ENDR")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DescCertEndr)
                    .IsRequired()
                    .HasColumnName("DESC_CERT_ENDR")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Citycnty>(entity =>
            {
                entity.ToTable("CITYCNTY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdCity)
                    .HasColumnName("CD_CITY")
                    .HasColumnType("char(13)");

                entity.Property(e => e.CdCoWthinCa)
                    .HasColumnName("CD_CO_WTHIN_CA")
                    .HasColumnType("char(2)");

                entity.Property(e => e.DescCity)
                    .HasColumnName("DESC_CITY")
                    .HasColumnType("char(35)");

                entity.Property(e => e.FlgCityDup)
                    .HasColumnName("FLG_CITY_DUP")
                    .HasColumnType("char(1)");
            });

            modelBuilder.Entity<Cofocodes>(entity =>
            {
                entity.HasKey(e => e.CdCofo);

                entity.ToTable("COFOCODES");

                entity.Property(e => e.CdCofo)
                    .HasColumnName("CD_COFO")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescCofo)
                    .IsRequired()
                    .HasColumnName("DESC_COFO")
                    .HasColumnType("char(60)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<CommercialStatusInd>(entity =>
            {
                entity.HasKey(e => e.CdCode);

                entity.Property(e => e.CdCode)
                    .HasColumnName("cd_code")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdDesc)
                    .IsRequired()
                    .HasColumnName("cd_desc")
                    .HasColumnType("char(100)");

                entity.Property(e => e.DtEndEff)
                    .HasColumnName("dt_end_eff")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<CommFileCond>(entity =>
            {
                entity.HasKey(e => e.CdCode);

                entity.Property(e => e.CdCode)
                    .HasColumnName("cd_code")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdDesc)
                    .HasColumnName("cd_desc")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Contact>(entity =>
            {
                entity.HasIndex(e => e.CdEmpId)
                    .HasName("Contact_ind2");

                entity.HasIndex(e => e.DtCntctEndTim)
                    .HasName("DT_CNTCT_END_TIM_IND");

                entity.HasIndex(e => e.DtCntctStrtTim)
                    .HasName("DT_CNTCT_STRT_TIM_IND");

                entity.HasIndex(e => new { e.CdEmpId, e.DtCntctStrtTim, e.CdStatus2 })
                    .HasName("IX_CONT_EMP_STRT_STAT2");

                entity.HasIndex(e => new { e.CdCase, e.CdEmpId, e.CdOffId, e.CdStatus2 })
                    .HasName("Contact_Ind");

                entity.HasIndex(e => new { e.CdOffId, e.NbrRoom, e.DtCntctStrtTim, e.CdStatus2 })
                    .HasName("IX_CONT_OFF_RM_STRT_STAT2");

                entity.Property(e => e.ContactId).HasColumnName("CONTACT_ID");

                entity.Property(e => e.CdAuthId)
                    .HasColumnName("CD_AUTH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdCase)
                    .IsRequired()
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.CdCntctTyp)
                    .IsRequired()
                    .HasColumnName("CD_CNTCT_TYP")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdOffId)
                    .IsRequired()
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdResult)
                    .HasColumnName("CD_RESULT")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdSchedTechId)
                    .IsRequired()
                    .HasColumnName("CD_SCHED_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdStatus)
                    .HasColumnName("CD_STATUS")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdStatus2)
                    .HasColumnName("CD_STATUS2")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdUpdtTechId)
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtCntctEndTim)
                    .HasColumnName("DT_CNTCT_END_TIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtCntctStrtTim)
                    .HasColumnName("DT_CNTCT_STRT_TIM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtNotc)
                    .HasColumnName("DT_NOTC")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtSchedTrans)
                    .HasColumnName("DT_SCHED_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgPrntNotc)
                    .HasColumnName("FLG_PRNT_NOTC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrRoom)
                    .IsRequired()
                    .HasColumnName("NBR_ROOM")
                    .HasColumnType("char(3)");

                entity.Property(e => e.TxtComment)
                    .HasColumnName("TXT_COMMENT")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.HasOne(d => d.CdCaseNavigation)
                    .WithMany(p => p.Contact)
                    .HasForeignKey(d => d.CdCase)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CONTACT_DSRCASE");

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.Contact)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CONTACT_Employee");
            });

            modelBuilder.Entity<Deceasedcodes>(entity =>
            {
                entity.HasKey(e => e.CdDeceased);

                entity.ToTable("DECEASEDCODES");

                entity.Property(e => e.CdDeceased)
                    .HasColumnName("CD_DECEASED")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescDeceased)
                    .IsRequired()
                    .HasColumnName("DESC_DECEASED")
                    .HasColumnType("char(10)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Dlupdstats>(entity =>
            {
                entity.ToTable("DLUPDStats");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdTcode)
                    .IsRequired()
                    .HasColumnName("CD_TCODE")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtTrans)
                    .HasColumnName("DT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.NbrDl)
                    .IsRequired()
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)");

                entity.Property(e => e.Nme3pos)
                    .HasColumnName("NME_3POS")
                    .HasColumnType("char(3)");
            });

            modelBuilder.Entity<DocGeneration>(entity =>
            {
                entity.HasKey(e => e.NbrDoc);

                entity.Property(e => e.NbrDoc)
                    .HasColumnName("NBR_DOC")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdCase)
                    .IsRequired()
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.CdTypDoc)
                    .IsRequired()
                    .HasColumnName("CD_TYP_DOC")
                    .HasColumnType("char(6)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtDocCreated)
                    .HasColumnName("DT_DOC_CREATED")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.CdCaseNavigation)
                    .WithMany(p => p.DocGeneration)
                    .HasForeignKey(d => d.CdCase)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DocGeneration_DSRCASE");
            });

            modelBuilder.Entity<Docimage>(entity =>
            {
                entity.HasKey(e => e.NbrDoc);

                entity.Property(e => e.NbrDoc).HasColumnName("NBR_DOC");

                entity.Property(e => e.CdDoc)
                    .IsRequired()
                    .HasColumnName("CD_DOC")
                    .HasColumnType("image");
            });

            modelBuilder.Entity<Dsoffice>(entity =>
            {
                entity.HasKey(e => e.CdOffId);

                entity.ToTable("DSOFFICE");

                entity.HasIndex(e => e.CdDistId)
                    .HasName("DISTRICTID");

                entity.HasIndex(e => e.CdOffId)
                    .HasName("dsoffice_ind")
                    .IsUnique();

                entity.Property(e => e.CdOffId)
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)")
                    .ValueGeneratedNever();

                entity.Property(e => e.AddrLn1)
                    .IsRequired()
                    .HasColumnName("ADDR_LN1")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.CdBacklog)
                    .HasColumnName("CD_BACKLOG")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.CdCity)
                    .IsRequired()
                    .HasColumnName("CD_CITY")
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.CdDistId)
                    .IsRequired()
                    .HasColumnName("CD_DIST_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdFldFileDsg)
                    .HasColumnName("CD_FLD_FILE_DSG")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.CdOffAbbr)
                    .HasColumnName("CD_OFF_ABBR")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CdRqstr)
                    .HasColumnName("CD_RQSTR")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.CdZip)
                    .IsRequired()
                    .HasColumnName("CD_ZIP")
                    .HasColumnType("char(5)");

                entity.Property(e => e.CdZipAddrLst4)
                    .HasColumnName("CD_ZIP_ADDR_LST4")
                    .HasColumnType("char(4)");

                entity.Property(e => e.DtEff)
                    .HasColumnName("DT_EFF")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.NbrFax)
                    .HasColumnName("NBR_FAX")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrPhone)
                    .IsRequired()
                    .HasColumnName("NBR_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NmeOff)
                    .IsRequired()
                    .HasColumnName("NME_OFF")
                    .HasMaxLength(35)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Dsrcase>(entity =>
            {
                entity.HasKey(e => e.CdCase)
                    .ForSqlServerIsClustered(false);

                entity.ToTable("DSRCASE");

                entity.HasIndex(e => e.CdCase)
                    .HasName("dsrcase_ind")
                    .IsUnique()
                    .ForSqlServerIsClustered();

                entity.HasIndex(e => new { e.DtRcpt, e.CdCase })
                    .HasName("inx_dt_rcpt");

                entity.HasIndex(e => new { e.NbrDl, e.CdStatusRec2, e.CdStatusRec })
                    .HasName("dsrcase_ind2");

                entity.Property(e => e.CdCase)
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdCaseClseId)
                    .HasColumnName("CD_CASE_CLSE_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdCityAcc)
                    .HasColumnName("CD_CITY_ACC")
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.CdDlUpdateId)
                    .HasColumnName("CD_DL_UPDATE_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdEndr)
                    .HasColumnName("CD_ENDR")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdFldDsoAlpha)
                    .IsRequired()
                    .HasColumnName("CD_FLD_DSO_ALPHA")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdFldFileLoc)
                    .HasColumnName("CD_FLD_FILE_LOC")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdHrngTyp)
                    .IsRequired()
                    .HasColumnName("CD_HRNG_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdOrigTechId)
                    .IsRequired()
                    .HasColumnName("CD_ORIG_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdRefrSrceTyp)
                    .IsRequired()
                    .HasColumnName("CD_REFR_SRCE_TYP")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdRsn)
                    .IsRequired()
                    .HasColumnName("CD_RSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdSchedRsl)
                    .HasColumnName("CD_SCHED_RSL")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdStatusRec)
                    .IsRequired()
                    .HasColumnName("CD_STATUS_REC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdStatusRec2)
                    .IsRequired()
                    .HasColumnName("CD_STATUS_REC2")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdTypAct)
                    .HasColumnName("CD_TYP_ACT")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdVehAuth1)
                    .HasColumnName("CD_VEH_AUTH1")
                    .HasColumnType("char(7)");

                entity.Property(e => e.CdVehAuth2)
                    .HasColumnName("CD_VEH_AUTH2")
                    .HasColumnType("char(7)");

                entity.Property(e => e.CdVehAuth3)
                    .HasColumnName("CD_VEH_AUTH3")
                    .HasColumnType("char(7)");

                entity.Property(e => e.CdVehAuthOrig)
                    .HasColumnName("CD_VEH_AUTH_ORIG")
                    .HasColumnType("char(7)");

                entity.Property(e => e.DtAcc)
                    .HasColumnName("DT_ACC")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtCaseClse)
                    .HasColumnName("DT_CASE_CLSE")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtDlUpdate)
                    .HasColumnName("DT_DL_UPDATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtMail)
                    .HasColumnName("DT_MAIL")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtModSchedHr)
                    .HasColumnName("DT_MOD_SCHED_HR")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtOrigTrans)
                    .HasColumnName("DT_ORIG_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtRcpt)
                    .HasColumnName("DT_RCPT")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtSchedHrng)
                    .HasColumnName("DT_SCHED_HRNG")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActEff)
                    .HasColumnName("DT_TYP_ACT_EFF")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActEnd)
                    .HasColumnName("DT_TYP_ACT_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActMod)
                    .HasColumnName("DT_TYP_ACT_MOD")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActTerm)
                    .HasColumnName("DT_TYP_ACT_TERM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgHearing)
                    .HasColumnName("FLG_HEARING")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrCaseAccFr)
                    .HasColumnName("NBR_CASE_ACC_FR")
                    .HasColumnType("char(9)");

                entity.Property(e => e.NbrDl)
                    .IsRequired()
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)");

                entity.HasOne(d => d.NbrDlNavigation)
                    .WithMany(p => p.Dsrcase)
                    .HasForeignKey(d => d.NbrDl)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DSRCASE_PERSON");
            });

            modelBuilder.Entity<Dsrcomm>(entity =>
            {
                entity.HasKey(e => new { e.CdCase, e.NbrDl, e.NbrComm })
                    .ForSqlServerIsClustered(false);

                entity.ToTable("DSRCOMM");

                entity.Property(e => e.CdCase)
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.NbrDl)
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)");

                entity.Property(e => e.NbrComm).HasColumnName("NBR_COMM");

                entity.Property(e => e.CdFldDsoAlpha)
                    .IsRequired()
                    .HasColumnName("CD_FLD_DSO_ALPHA")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.TxtComm)
                    .IsRequired()
                    .HasColumnName("TXT_COMM")
                    .HasMaxLength(180)
                    .IsUnicode(false);

                entity.HasOne(d => d.CdCaseNavigation)
                    .WithMany(p => p.Dsrcomm)
                    .HasForeignKey(d => d.CdCase)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DSRCOMM_DSRCASE");

                entity.HasOne(d => d.NbrDlNavigation)
                    .WithMany(p => p.Dsrcomm)
                    .HasForeignKey(d => d.NbrDl)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DSRCOMM_PERSON");
            });

            modelBuilder.Entity<Dsrlog>(entity =>
            {
                entity.HasKey(e => new { e.CdCase, e.NbrDl });

                entity.ToTable("DSRLOG");

                entity.Property(e => e.CdCase)
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)");

                entity.Property(e => e.NbrDl)
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)");

                entity.Property(e => e.CdFldDsoAlpha)
                    .IsRequired()
                    .HasColumnName("CD_FLD_DSO_ALPHA")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdTechLgnId)
                    .IsRequired()
                    .HasColumnName("CD_TECH_LGN_ID")
                    .HasColumnType("char(8)");

                entity.Property(e => e.DtStrt)
                    .HasColumnName("DT_STRT")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Dukcodes>(entity =>
            {
                entity.HasKey(e => e.CdDuk);

                entity.ToTable("DUKCODES");

                entity.Property(e => e.CdDuk)
                    .HasColumnName("CD_DUK")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescDuk)
                    .IsRequired()
                    .HasColumnName("DESC_DUK")
                    .HasColumnType("char(25)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.EmpId)
                    .ForSqlServerIsClustered(false);

                entity.HasIndex(e => e.CdEmpId)
                    .HasName("Employee_Ind")
                    .IsUnique();

                entity.HasIndex(e => e.CdLgnId)
                    .HasName("IX_EMP_Lgn");

                entity.Property(e => e.CdEmpClass)
                    .IsRequired()
                    .HasColumnName("CD_EMP_CLASS")
                    .HasColumnType("char(10)");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdEmpRng)
                    .HasColumnName("CD_EMP_RNG")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdEmpTyp)
                    .IsRequired()
                    .HasColumnName("CD_EMP_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdLgnId)
                    .IsRequired()
                    .HasColumnName("CD_LGN_ID")
                    .HasColumnType("char(8)");

                entity.Property(e => e.CdLoanOff)
                    .HasColumnName("CD_LOAN_OFF")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdOffId)
                    .IsRequired()
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdTransferOff)
                    .HasColumnName("CD_TRANSFER_OFF")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdUpdtTechId)
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtLoanEnd)
                    .HasColumnName("DT_LOAN_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtLoanStrt)
                    .HasColumnName("DT_LOAN_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTerminated)
                    .HasColumnName("DT_TERMINATED")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTransfer)
                    .HasColumnName("DT_TRANSFER")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgLoan)
                    .HasColumnName("FLG_LOAN")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgTransfer)
                    .HasColumnName("FLG_TRANSFER")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NmeFrstPrsn)
                    .IsRequired()
                    .HasColumnName("NME_FRST_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeMidPrsn)
                    .HasColumnName("NME_MID_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeSufxPrsn)
                    .HasColumnName("NME_SUFX_PRSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NmeSurnmePrsn)
                    .IsRequired()
                    .HasColumnName("NME_SURNME_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.HasOne(d => d.CdEmpTypNavigation)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.CdEmpTyp)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Employee_EmployeeRole");

                entity.HasOne(d => d.CdOff)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.CdOffId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Employee_DSOFFICE");
            });

            modelBuilder.Entity<EmployeeClass>(entity =>
            {
                entity.HasKey(e => e.CdEmpClass);

                entity.Property(e => e.CdEmpClass)
                    .HasColumnName("cd_emp_class")
                    .HasColumnType("char(4)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdDesc)
                    .IsRequired()
                    .HasColumnName("cd_desc")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<EmployeeRole>(entity =>
            {
                entity.HasKey(e => e.RoleId);

                entity.Property(e => e.RoleId)
                    .HasColumnName("ROLE_ID")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.RoleDescription)
                    .IsRequired()
                    .HasColumnName("ROLE_DESCRIPTION")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Endstaycodes>(entity =>
            {
                entity.HasKey(e => e.CdEndstay);

                entity.ToTable("ENDSTAYCODES");

                entity.Property(e => e.CdEndstay)
                    .HasColumnName("CD_ENDSTAY")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescEndstay)
                    .IsRequired()
                    .HasColumnName("DESC_ENDSTAY")
                    .HasColumnType("char(10)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<FieldFile>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.Property(e => e.Code)
                    .HasColumnName("code")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descr)
                    .IsRequired()
                    .HasColumnName("descr")
                    .HasColumnType("char(20)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Filecondition>(entity =>
            {
                entity.HasKey(e => e.CdFilecond);

                entity.ToTable("FILECONDITION");

                entity.Property(e => e.CdFilecond)
                    .HasColumnName("CD_FILECOND")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescFilecond)
                    .IsRequired()
                    .HasColumnName("DESC_FILECOND")
                    .HasColumnType("char(50)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Hearinglocation>(entity =>
            {
                entity.HasKey(e => new { e.CdOffId, e.NbrRoom });

                entity.ToTable("HEARINGLOCATION");

                entity.HasIndex(e => new { e.CdOffId, e.NbrRoom })
                    .HasName("OffIDRmNum")
                    .IsUnique();

                entity.Property(e => e.CdOffId)
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NbrRoom)
                    .HasColumnName("NBR_ROOM")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DescRoom)
                    .IsRequired()
                    .HasColumnName("DESC_ROOM")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.DtClosed)
                    .HasColumnName("DT_CLOSED")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.CdOff)
                    .WithMany(p => p.Hearinglocation)
                    .HasForeignKey(d => d.CdOffId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HEARINGLOCATION_DSOFFICE");
            });

            modelBuilder.Entity<Hearinglocprofile>(entity =>
            {
                entity.HasKey(e => new { e.CdOffId, e.NbrRoom, e.DtEffStrt });

                entity.ToTable("HEARINGLOCPROFILE");

                entity.HasIndex(e => new { e.CdOffId, e.NbrRoom, e.DtEffStrt })
                    .HasName("OffIDRmNumEffDt")
                    .IsUnique();

                entity.Property(e => e.CdOffId)
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NbrRoom)
                    .HasColumnName("NBR_ROOM")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtEffStrt)
                    .HasColumnName("DT_EFF_STRT")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.CdUpdtTechId)
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtEffEnd)
                    .HasColumnName("DT_EFF_END")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgActive).HasColumnName("FLG_ACTIVE");

                entity.Property(e => e.FlgPhoneAvb)
                    .IsRequired()
                    .HasColumnName("FLG_PHONE_AVB")
                    .HasColumnType("char(1)");

                entity.Property(e => e.TmeFriEnd)
                    .HasColumnName("TME_FRI_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeFriStrt)
                    .HasColumnName("TME_FRI_STRT")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeMonEnd)
                    .HasColumnName("TME_MON_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeMonStrt)
                    .HasColumnName("TME_MON_STRT")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeSatEnd)
                    .HasColumnName("TME_SAT_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeSatStrt)
                    .HasColumnName("TME_SAT_STRT")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeSunEnd)
                    .HasColumnName("TME_SUN_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeSunStrt)
                    .HasColumnName("TME_SUN_STRT")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeThuEnd)
                    .HasColumnName("TME_THU_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeThuStrt)
                    .HasColumnName("TME_THU_STRT")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeTueEnd)
                    .HasColumnName("TME_TUE_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeTueStrt)
                    .HasColumnName("TME_TUE_STRT")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeWedEnd)
                    .HasColumnName("TME_WED_END")
                    .HasColumnType("char(5)");

                entity.Property(e => e.TmeWedStrt)
                    .HasColumnName("TME_WED_STRT")
                    .HasColumnType("char(5)");

                entity.HasOne(d => d.Hearinglocation)
                    .WithMany(p => p.Hearinglocprofile)
                    .HasForeignKey(d => new { d.CdOffId, d.NbrRoom })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HEARINGLOCPROFILE_HEARINGLOCATION");
            });

            modelBuilder.Entity<Hearingtime>(entity =>
            {
                entity.ToTable("HEARINGTIME");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdRsn)
                    .HasColumnName("CD_RSN")
                    .HasColumnType("char(3)");
            });

            modelBuilder.Entity<Hearingtime1>(entity =>
            {
                entity.ToTable("HEARINGTIME1");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Category)
                    .IsRequired()
                    .HasColumnType("nchar(30)");
            });

            modelBuilder.Entity<Hearingtype>(entity =>
            {
                entity.HasKey(e => e.CdHrngTyp);

                entity.ToTable("HEARINGTYPE");

                entity.Property(e => e.CdHrngTyp)
                    .HasColumnName("CD_HRNG_TYP")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdPhoneTyp)
                    .HasColumnName("CD_PHONE_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DescHrngTyp)
                    .IsRequired()
                    .HasColumnName("DESC_HRNG_TYP")
                    .HasColumnType("char(35)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.TxtAbbrDesc)
                    .HasColumnName("TXT_ABBR_DESC")
                    .HasColumnType("char(3)");
            });

            modelBuilder.Entity<HoauthorityTypeEmployee>(entity =>
            {
                entity.HasKey(e => new { e.EmployeeId, e.HearingType });

                entity.ToTable("HOAuthorityTypeEmployee");

                entity.Property(e => e.EmployeeId)
                    .HasColumnName("EmployeeID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.HearingType).HasColumnType("char(1)");
            });

            modelBuilder.Entity<Hoauthtype>(entity =>
            {
                entity.ToTable("HOAUTHTYPE");

                entity.HasIndex(e => new { e.EmpId, e.CdRsn, e.DtEffStrt })
                    .HasName("AuthTypeInd")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdHrngTyp)
                    .IsRequired()
                    .HasColumnName("CD_HRNG_TYP")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdRsn)
                    .IsRequired()
                    .HasColumnName("CD_RSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtEffEnd)
                    .HasColumnName("DT_EFF_END")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DtEffStrt)
                    .HasColumnName("DT_EFF_STRT")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.TmeDefault)
                    .IsRequired()
                    .HasColumnName("TME_DEFAULT")
                    .HasColumnType("char(9)");

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.Hoauthtype)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HOAUTHTYPE_Employee");
            });

            modelBuilder.Entity<Hoauthtype1>(entity =>
            {
                entity.ToTable("HOAUTHTYPE1");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CategoryId).HasColumnName("CategoryID");

                entity.Property(e => e.EmpId).HasColumnName("EmpID");

                entity.Property(e => e.LastUpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Hoauthtype1)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HOAUTHTYPE1_HEARINGTIME1");

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.Hoauthtype1)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_HOAUTHTYPE1_Employee");
            });

            modelBuilder.Entity<Holiday>(entity =>
            {
                entity.ToTable("HOLIDAY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DtHoli)
                    .HasColumnName("DT_HOLI")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Interpre>(entity =>
            {
                entity.ToTable("INTERPRE");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdLanguage)
                    .IsRequired()
                    .HasColumnName("CD_LANGUAGE")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdPrtyTyp)
                    .IsRequired()
                    .HasColumnName("CD_PRTY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.NbrOip)
                    .IsRequired()
                    .HasColumnName("NBR_OIP")
                    .HasColumnType("char(6)");

                entity.Property(e => e.NbrPhoneAc)
                    .IsRequired()
                    .HasColumnName("NBR_PHONE_AC")
                    .HasColumnType("char(3)");

                entity.Property(e => e.Oipid).HasColumnName("OIPID");
            });

            modelBuilder.Entity<Language>(entity =>
            {
                entity.HasKey(e => e.CdLanguage);

                entity.ToTable("LANGUAGE");

                entity.HasIndex(e => new { e.CdLanguage, e.DescLanguage, e.DtTerm })
                    .HasName("Language_ind")
                    .IsUnique();

                entity.Property(e => e.CdLanguage)
                    .HasColumnName("CD_LANGUAGE")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescLanguage)
                    .IsRequired()
                    .HasColumnName("DESC_LANGUAGE")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Lawagency>(entity =>
            {
                entity.ToTable("LAWAGENCY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AddrLn1)
                    .HasColumnName("ADDR_LN1")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.CdCity)
                    .IsRequired()
                    .HasColumnName("CD_CITY")
                    .HasColumnType("char(13)");

                entity.Property(e => e.CdLawAgncy)
                    .IsRequired()
                    .HasColumnName("CD_LAW_AGNCY")
                    .HasColumnType("char(5)");

                entity.Property(e => e.NmeLawAgncy)
                    .HasColumnName("NME_LAW_AGNCY")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NmeTitle)
                    .HasColumnName("NME_TITLE")
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Licloc>(entity =>
            {
                entity.HasKey(e => e.CdLicloc);

                entity.ToTable("LICLOC");

                entity.Property(e => e.CdLicloc)
                    .HasColumnName("CD_LICLOC")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdOffice)
                    .IsRequired()
                    .HasColumnName("CD_OFFICE")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DescLicloc)
                    .IsRequired()
                    .HasColumnName("DESC_LICLOC")
                    .HasColumnType("char(60)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<NetAllProgramCostHours>(entity =>
            {
                entity.ToTable("NET_ALL_PROGRAM_COST_HOURS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ContractorHours).HasColumnName("CONTRACTOR_HOURS");

                entity.Property(e => e.CostType)
                    .HasColumnName("COST_TYPE")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DocumentPrepHrs).HasColumnName("DOCUMENT_PREP_HRS");

                entity.Property(e => e.EstimateSetId).HasColumnName("ESTIMATE_SET_ID");

                entity.Property(e => e.IntegrationTestDays).HasColumnName("INTEGRATION_TEST_DAYS");

                entity.Property(e => e.IntegrationTestTechniciansNum).HasColumnName("INTEGRATION_TEST_TECHNICIANS_NUM");

                entity.Property(e => e.ProjectCoordinationHrs).HasColumnName("PROJECT_COORDINATION_HRS");

                entity.Property(e => e.SystemTestHrs).HasColumnName("SYSTEM_TEST_HRS");
            });

            modelBuilder.Entity<NewsItem>(entity =>
            {
                entity.HasKey(e => e.NewsId);

                entity.Property(e => e.AuthorName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.NewsText)
                    .IsRequired()
                    .HasMaxLength(4000);

                entity.Property(e => e.Priority)
                    .IsRequired()
                    .HasColumnType("char(1)");

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.Property(e => e.Subject)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.NewsItem)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_NewsItem_Employee");
            });

            modelBuilder.Entity<OfficeNewsItem>(entity =>
            {
                entity.HasKey(e => new { e.CdOffId, e.NewsId });

                entity.Property(e => e.CdOffId)
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.HasOne(d => d.CdOff)
                    .WithMany(p => p.OfficeNewsItem)
                    .HasForeignKey(d => d.CdOffId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OfficeNewsItem_DSOFFICE");

                entity.HasOne(d => d.News)
                    .WithMany(p => p.OfficeNewsItem)
                    .HasForeignKey(d => d.NewsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OfficeNewsItem_NewsItem");
            });

            modelBuilder.Entity<Oipcntl>(entity =>
            {
                entity.HasKey(e => e.CdOip);

                entity.ToTable("OIPCNTL");

                entity.HasIndex(e => e.CdOip)
                    .HasName("oipcntl_ind")
                    .IsUnique();

                entity.Property(e => e.CdOip)
                    .HasColumnName("CD_OIP")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.NbrOip)
                    .IsRequired()
                    .HasColumnName("NBR_OIP")
                    .HasColumnType("char(5)");
            });

            modelBuilder.Entity<Oippersn>(entity =>
            {
                entity.HasKey(e => e.Oipid);

                entity.ToTable("OIPPERSN");

                entity.HasIndex(e => e.Oipid)
                    .HasName("oippersn_ind")
                    .IsUnique();

                entity.Property(e => e.Oipid).HasColumnName("OIPID");

                entity.Property(e => e.AddrLn1)
                    .HasColumnName("ADDR_LN1")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.CdCity)
                    .HasColumnName("CD_CITY")
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.CdPrtyTyp)
                    .IsRequired()
                    .HasColumnName("CD_PRTY_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdState)
                    .HasColumnName("CD_STATE")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdZip)
                    .HasColumnName("CD_ZIP")
                    .HasColumnType("char(5)");

                entity.Property(e => e.CdZipAddrLst4)
                    .HasColumnName("CD_ZIP_ADDR_LST4")
                    .HasColumnType("char(4)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EmailAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NbrCellPhone)
                    .HasColumnName("NBR_CELL_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrFax)
                    .HasColumnName("NBR_FAX")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrOip)
                    .HasColumnName("NBR_OIP")
                    .HasColumnType("char(6)");

                entity.Property(e => e.NbrPhone)
                    .HasColumnName("NBR_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NmeAgency)
                    .HasColumnName("NME_AGENCY")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeFrstPrsn)
                    .HasColumnName("NME_FRST_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeMidPrsn)
                    .HasColumnName("NME_MID_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.NmeSufxPrsn)
                    .HasColumnName("NME_SUFX_PRSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NmeSurnmePrsn)
                    .HasColumnName("NME_SURNME_PRSN")
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.TxtComm)
                    .HasColumnName("TXT_COMM")
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Oiptype>(entity =>
            {
                entity.HasKey(e => e.CdPrtyTyp);

                entity.ToTable("OIPTYPE");

                entity.HasIndex(e => new { e.CdPrtyTyp, e.DescPrtyTyp, e.DtTerm })
                    .HasName("OIPType_ind")
                    .IsUnique();

                entity.Property(e => e.CdPrtyTyp)
                    .HasColumnName("CD_PRTY_TYP")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescPrtyTyp)
                    .IsRequired()
                    .HasColumnName("DESC_PRTY_TYP")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<OswithDrawalType>(entity =>
            {
                entity.HasKey(e => e.Code);

                entity.ToTable("OSWithDrawalType");

                entity.Property(e => e.Code)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Pandm>(entity =>
            {
                entity.HasKey(e => e.CdPandm);

                entity.ToTable("PANDM");

                entity.Property(e => e.CdPandm)
                    .HasColumnName("CD_PANDM")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescPandm)
                    .IsRequired()
                    .HasColumnName("DESC_PANDM")
                    .HasColumnType("char(30)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<ParaIns>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdCode)
                    .IsRequired()
                    .HasColumnName("CD_Code")
                    .HasColumnType("char(4)");

                entity.Property(e => e.CdDesc)
                    .IsRequired()
                    .HasColumnName("CD_Desc")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasKey(e => e.NbrDl);

                entity.ToTable("PERSON");

                entity.Property(e => e.NbrDl)
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)")
                    .ValueGeneratedNever();

                entity.Property(e => e.AddrLn1)
                    .HasColumnName("ADDR_LN1")
                    .HasColumnType("char(35)");

                entity.Property(e => e.CdCity)
                    .HasColumnName("CD_CITY")
                    .HasColumnType("char(13)");

                entity.Property(e => e.CdClassLic)
                    .IsRequired()
                    .HasColumnName("CD_CLASS_LIC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdClassLic2)
                    .HasColumnName("CD_CLASS_LIC2")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdState)
                    .HasColumnName("CD_STATE")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdZip)
                    .HasColumnName("CD_ZIP")
                    .HasColumnType("char(5)");

                entity.Property(e => e.CdZipAddrLst4)
                    .HasColumnName("CD_ZIP_ADDR_LST4")
                    .HasColumnType("char(4)");

                entity.Property(e => e.DtBirthPrsn)
                    .HasColumnName("DT_BIRTH_PRSN")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgAddrConfdntl)
                    .HasColumnName("FLG_ADDR_CONFDNTL")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrPhone)
                    .HasColumnName("NBR_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrSsnPrsn).HasColumnName("NBR_SSN_PRSN");

                entity.Property(e => e.NmeFrstPrsn)
                    .IsRequired()
                    .HasColumnName("NME_FRST_PRSN")
                    .HasColumnType("char(35)");

                entity.Property(e => e.NmeMidPrsn)
                    .HasColumnName("NME_MID_PRSN")
                    .HasColumnType("char(35)");

                entity.Property(e => e.NmeSufxPrsn)
                    .HasColumnName("NME_SUFX_PRSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NmeSurnmePrsn)
                    .IsRequired()
                    .HasColumnName("NME_SURNME_PRSN")
                    .HasColumnType("char(35)");
            });

            modelBuilder.Entity<Profile>(entity =>
            {
                entity.ToTable("PROFILE");

                entity.HasIndex(e => new { e.CdEmpId, e.CdOffId, e.DtEffStrt, e.DayOfWkMonth })
                    .HasName("indxProfile");

                entity.Property(e => e.ProfileId).HasColumnName("PROFILE_ID");

                entity.Property(e => e.CdEmpId)
                    .IsRequired()
                    .HasColumnName("CD_EMP_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdOffId)
                    .IsRequired()
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdProfileTyp)
                    .IsRequired()
                    .HasColumnName("CD_PROFILE_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdUpdtTechId)
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdWrkWkTyp)
                    .IsRequired()
                    .HasColumnName("CD_WRK_WK_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DayOfWkMonth).HasColumnName("DAY_OF_WK_MONTH");

                entity.Property(e => e.DtEffEnd)
                    .HasColumnName("DT_EFF_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtEffStrt)
                    .HasColumnName("DT_EFF_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgAlt)
                    .IsRequired()
                    .HasColumnName("FLG_ALT")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.FlgTelc)
                    .IsRequired()
                    .HasColumnName("FLG_TELC")
                    .HasColumnType("char(1)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TmeAmBrkEnd)
                    .HasColumnName("TME_AM_BRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeAmBrkStrt)
                    .HasColumnName("TME_AM_BRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeLchBrkEnd)
                    .HasColumnName("TME_LCH_BRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeLchBrkStrt)
                    .HasColumnName("TME_LCH_BRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmePmBrkEnd)
                    .HasColumnName("TME_PM_BRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmePmBrkStrt)
                    .HasColumnName("TME_PM_BRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeWrkEnd)
                    .HasColumnName("TME_WRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeWrkStrt)
                    .HasColumnName("TME_WRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeFroEnd)
                    .HasColumnName("TRVL_TME_FRO_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeFroStrt)
                    .HasColumnName("TRVL_TME_FRO_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeToEnd)
                    .HasColumnName("TRVL_TME_TO_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeToStrt)
                    .HasColumnName("TRVL_TME_TO_STRT")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.Profile)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROFILE_Employee");
            });

            modelBuilder.Entity<Profile1>(entity =>
            {
                entity.HasKey(e => e.ProfileId);

                entity.ToTable("PROFILE1");

                entity.Property(e => e.ProfileId).HasColumnName("PROFILE_ID");

                entity.Property(e => e.CdOffId)
                    .IsRequired()
                    .HasColumnName("CD_OFF_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdProfileTyp)
                    .IsRequired()
                    .HasColumnName("CD_PROFILE_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdUpdtTechId).HasColumnName("CD_UPDT_TECH_ID");

                entity.Property(e => e.CdWrkWkTyp)
                    .IsRequired()
                    .HasColumnName("CD_WRK_WK_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DtEffEnd)
                    .HasColumnName("DT_EFF_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtEffStrt)
                    .HasColumnName("DT_EFF_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.CdUpdtTech)
                    .WithMany(p => p.Profile1CdUpdtTech)
                    .HasForeignKey(d => d.CdUpdtTechId)
                    .HasConstraintName("FK_PROFILE1_Employee1");

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.Profile1Emp)
                    .HasForeignKey(d => d.EmpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROFILE1_Employee");
            });

            modelBuilder.Entity<Profileday>(entity =>
            {
                entity.ToTable("PROFILEDAY");

                entity.Property(e => e.ProfileDayId).HasColumnName("ProfileDayID");

                entity.Property(e => e.DayOfWkMonth).HasColumnName("DAY_OF_WK_MONTH");

                entity.Property(e => e.FlgAlt)
                    .IsRequired()
                    .HasColumnName("FLG_ALT")
                    .HasColumnType("char(1)");

                entity.Property(e => e.FlgTelc)
                    .IsRequired()
                    .HasColumnName("FLG_TELC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.ProfileId).HasColumnName("ProfileID");

                entity.Property(e => e.TmeAmBrkEnd)
                    .HasColumnName("TME_AM_BRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeAmBrkStrt)
                    .HasColumnName("TME_AM_BRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeLchBrkEnd)
                    .HasColumnName("TME_LCH_BRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeLchBrkStrt)
                    .HasColumnName("TME_LCH_BRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmePmBrkEnd)
                    .HasColumnName("TME_PM_BRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmePmBrkStrt)
                    .HasColumnName("TME_PM_BRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeWrkEnd)
                    .HasColumnName("TME_WRK_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TmeWrkStrt)
                    .HasColumnName("TME_WRK_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeFroEnd)
                    .HasColumnName("TRVL_TME_FRO_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeFroStrt)
                    .HasColumnName("TRVL_TME_FRO_STRT")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeToEnd)
                    .HasColumnName("TRVL_TME_TO_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.TrvlTmeToStrt)
                    .HasColumnName("TRVL_TME_TO_STRT")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.Profileday)
                    .HasForeignKey(d => d.ProfileId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PROFILEDAY_PROFILE1");
            });

            modelBuilder.Entity<Pullnotice>(entity =>
            {
                entity.HasKey(e => e.CdPullnotice);

                entity.ToTable("PULLNOTICE");

                entity.Property(e => e.CdPullnotice)
                    .HasColumnName("CD_PULLNOTICE")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescPullnotice)
                    .IsRequired()
                    .HasColumnName("DESC_PULLNOTICE")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Pullnotinfo>(entity =>
            {
                entity.HasKey(e => e.CdPullnotinfo);

                entity.ToTable("PULLNOTINFO");

                entity.Property(e => e.CdPullnotinfo)
                    .HasColumnName("CD_PULLNOTINFO")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescPullnotinfo)
                    .IsRequired()
                    .HasColumnName("DESC_PULLNOTINFO")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Pullnotpurge>(entity =>
            {
                entity.HasKey(e => e.CdPullnotpurge);

                entity.ToTable("PULLNOTPURGE");

                entity.Property(e => e.CdPullnotpurge)
                    .HasColumnName("CD_PULLNOTPURGE")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescPullnotpurge)
                    .HasColumnName("DESC_PULLNOTPURGE")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Pullnotreas>(entity =>
            {
                entity.HasKey(e => e.CdPullnotreas);

                entity.ToTable("PULLNOTREAS");

                entity.Property(e => e.CdPullnotreas)
                    .HasColumnName("CD_PULLNOTREAS")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescPullnotreas)
                    .IsRequired()
                    .HasColumnName("DESC_PULLNOTREAS")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Reacat>(entity =>
            {
                entity.ToTable("reacat");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdBgnRsn)
                    .IsRequired()
                    .HasColumnName("CD_BGN_RSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdEndRsn)
                    .IsRequired()
                    .HasColumnName("CD_END_RSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdNodef)
                    .IsRequired()
                    .HasColumnName("CD_NODEF")
                    .HasColumnType("char(1)");

                entity.Property(e => e.DescCatgry)
                    .IsRequired()
                    .HasColumnName("DESC_CATGRY")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedBy)
                    .HasColumnName("lastUpdatedBy")
                    .HasColumnType("char(10)");

                entity.Property(e => e.LastUpdatedDate)
                    .HasColumnName("lastUpdatedDate")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Reason>(entity =>
            {
                entity.HasKey(e => e.CdRsn);

                entity.ToTable("REASON");

                entity.HasIndex(e => new { e.CdRsn, e.DescRsn, e.DtTerm })
                    .HasName("Reason_ind")
                    .IsUnique();

                entity.Property(e => e.CdRsn)
                    .HasColumnName("CD_RSN")
                    .HasColumnType("char(3)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescRsn)
                    .IsRequired()
                    .HasColumnName("DESC_RSN")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Referral>(entity =>
            {
                entity.HasKey(e => e.CdRefrSrceTyp);

                entity.ToTable("REFERRAL");

                entity.HasIndex(e => new { e.CdRefrSrceTyp, e.DescRefrSrceTyp, e.DtTerm })
                    .HasName("Referral_ind")
                    .IsUnique();

                entity.Property(e => e.CdRefrSrceTyp)
                    .HasColumnName("CD_REFR_SRCE_TYP")
                    .HasColumnType("char(3)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescRefrSrceTyp)
                    .IsRequired()
                    .HasColumnName("DESC_REFR_SRCE_TYP")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Region>(entity =>
            {
                entity.HasKey(e => new { e.CdRgnId, e.CdDistId });

                entity.ToTable("REGION");

                entity.Property(e => e.CdRgnId)
                    .HasColumnName("CD_RGN_ID")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdDistId)
                    .HasColumnName("CD_DIST_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.NmeRgn)
                    .HasColumnName("NME_RGN")
                    .HasMaxLength(35)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Reports>(entity =>
            {
                entity.ToTable("reports");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdActive)
                    .IsRequired()
                    .HasColumnName("CD_ACTIVE")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdAuth)
                    .IsRequired()
                    .HasColumnName("CD_AUTH")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdReport)
                    .HasColumnName("CD_REPORT")
                    .HasColumnType("char(6)");

                entity.Property(e => e.NmeModule)
                    .HasColumnName("NME_MODULE")
                    .HasColumnType("char(20)");

                entity.Property(e => e.NmeReport)
                    .IsRequired()
                    .HasColumnName("NME_REPORT")
                    .HasColumnType("char(40)");
            });

            modelBuilder.Entity<Restriction>(entity =>
            {
                entity.HasKey(e => e.CdRestrict);

                entity.ToTable("restriction");

                entity.Property(e => e.CdRestrict)
                    .HasColumnName("CD_RESTRICT")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescRestrict)
                    .IsRequired()
                    .HasColumnName("DESC_RESTRICT")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<RowColumnHexValue>(entity =>
            {
                entity.HasKey(e => new { e.Row, e.Col });

                entity.Property(e => e.Row)
                    .HasColumnName("row")
                    .HasColumnType("nchar(2)");

                entity.Property(e => e.Col)
                    .HasColumnName("col")
                    .HasColumnType("nchar(2)");

                entity.Property(e => e.Charvalue)
                    .HasColumnName("charvalue")
                    .HasColumnType("nchar(2)");

                entity.Property(e => e.Hexvalue)
                    .HasColumnName("hexvalue")
                    .HasColumnType("nchar(4)");
            });

            modelBuilder.Entity<RowColumnHexValues>(entity =>
            {
                entity.HasKey(e => new { e.Row, e.Col });

                entity.Property(e => e.Row)
                    .HasColumnName("row")
                    .HasColumnType("nchar(2)");

                entity.Property(e => e.Col)
                    .HasColumnName("col")
                    .HasColumnType("nchar(2)");

                entity.Property(e => e.Charvalue1)
                    .HasColumnName("charvalue1")
                    .HasColumnType("nchar(1)");

                entity.Property(e => e.Charvalue2)
                    .HasColumnName("charvalue2")
                    .HasColumnType("nchar(1)");

                entity.Property(e => e.Hexvalue1)
                    .HasColumnName("hexvalue1")
                    .HasColumnType("nchar(2)");

                entity.Property(e => e.Hexvalue2)
                    .HasColumnName("hexvalue2")
                    .HasColumnType("nchar(2)");
            });

            modelBuilder.Entity<Schedresults>(entity =>
            {
                entity.HasKey(e => e.CdSchedRsl);

                entity.ToTable("SCHEDRESULTS");

                entity.Property(e => e.CdSchedRsl)
                    .HasColumnName("CD_SCHED_RSL")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescSchedRsl)
                    .IsRequired()
                    .HasColumnName("DESC_SCHED_RSL")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Sdttype>(entity =>
            {
                entity.HasKey(e => e.CdCode);

                entity.ToTable("SDTType");

                entity.Property(e => e.CdCode)
                    .HasColumnName("CD_CODE")
                    .HasColumnType("char(3)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdDesc)
                    .HasColumnName("CD_DESC")
                    .HasMaxLength(55)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Service>(entity =>
            {
                entity.HasKey(e => e.CdService);

                entity.Property(e => e.CdService)
                    .HasColumnName("CD_SERVICE")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");

                entity.Property(e => e.TxtDescService)
                    .IsRequired()
                    .HasColumnName("TXT_DESC_SERVICE")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.HasKey(e => e.CdNumState);

                entity.ToTable("STATE");

                entity.HasIndex(e => e.CdAlpState)
                    .HasName("state_ind");

                entity.Property(e => e.CdNumState)
                    .HasColumnName("CD_NUM_STATE")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdAlpState)
                    .IsRequired()
                    .HasColumnName("CD_ALP_STATE")
                    .HasColumnType("char(2)");

                entity.Property(e => e.NmeState)
                    .IsRequired()
                    .HasColumnName("NME_STATE")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StayStats>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AuthSection)
                    .IsRequired()
                    .HasColumnType("char(7)");

                entity.Property(e => e.EffDate).HasColumnType("datetime");

                entity.Property(e => e.EndStayDate).HasColumnType("datetime");

                entity.Property(e => e.NbrDl)
                    .IsRequired()
                    .HasColumnName("nbr_dl")
                    .HasColumnType("char(8)");

                entity.Property(e => e.OrigAuthSection)
                    .IsRequired()
                    .HasColumnType("char(7)");

                entity.Property(e => e.OrigEffDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<SuspenseReason>(entity =>
            {
                entity.HasKey(e => e.CdReason);

                entity.Property(e => e.CdReason)
                    .HasColumnName("CD_REASON")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescReason)
                    .IsRequired()
                    .HasColumnName("DESC_REASON")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<SuspRsn>(entity =>
            {
                entity.HasKey(e => e.CdSuspRsn);

                entity.ToTable("SUSP_RSN");

                entity.HasIndex(e => e.CdSuspRsn)
                    .HasName("susp_rsn_ind")
                    .IsUnique();

                entity.Property(e => e.CdSuspRsn)
                    .HasColumnName("CD_SUSP_RSN")
                    .HasColumnType("char(3)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescSuspRsn)
                    .IsRequired()
                    .HasColumnName("DESC_SUSP_RSN")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TransLicLoc>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdLicloc)
                    .HasColumnName("CD_LICLOC")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdTrans)
                    .HasColumnName("CD_TRANS")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TransSchedResult>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdSchedresult)
                    .IsRequired()
                    .HasColumnName("CD_SCHEDRESULT")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdTrans)
                    .IsRequired()
                    .HasColumnName("CD_TRANS")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TransTypeAction>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdTrans)
                    .HasColumnName("CD_Trans")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdTypAct)
                    .HasColumnName("CD_TYP_ACT")
                    .HasColumnType("char(2)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Transtypehrng>(entity =>
            {
                entity.ToTable("TRANSTYPEHRNG");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CdHrngTyp)
                    .HasColumnName("CD_HRNG_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdTrans)
                    .HasColumnName("CD_TRANS")
                    .HasColumnType("char(3)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Typeaction>(entity =>
            {
                entity.HasKey(e => e.CdTypAct);

                entity.ToTable("TYPEACTION");

                entity.Property(e => e.CdTypAct)
                    .HasColumnName("CD_TYP_ACT")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescTypAct)
                    .IsRequired()
                    .HasColumnName("DESC_TYP_ACT")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Updatecodes>(entity =>
            {
                entity.HasKey(e => e.CdUpdate);

                entity.ToTable("UPDATECODES");

                entity.Property(e => e.CdUpdate)
                    .HasColumnName("CD_UPDATE")
                    .HasColumnType("char(1)")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescUpdate)
                    .IsRequired()
                    .HasColumnName("DESC_UPDATE")
                    .HasColumnType("char(45)");

                entity.Property(e => e.DtTerm)
                    .HasColumnName("dt_term")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Withholdrsn>(entity =>
            {
                entity.HasKey(e => e.CdCode);

                entity.ToTable("withholdrsn");

                entity.Property(e => e.CdCode)
                    .HasColumnName("cd_code")
                    .HasColumnType("char(2)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdDesc)
                    .IsRequired()
                    .HasColumnName("cd_desc")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DtEndEff)
                    .HasColumnName("dt_end_eff")
                    .HasColumnType("datetime");
            });
        }
    }
}
