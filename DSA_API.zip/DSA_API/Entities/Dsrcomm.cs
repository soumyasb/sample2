﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Dsrcomm
    {
        public string CdCase { get; set; }
        public string NbrDl { get; set; }
        public int NbrComm { get; set; }
        public string CdFldDsoAlpha { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime DtUpdtTrans { get; set; }
        public string TxtComm { get; set; }

        public Dsrcase CdCaseNavigation { get; set; }
        public Person NbrDlNavigation { get; set; }
    }
}
