﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Oippersn
    {
        public Oippersn()
        {
            Caseoip = new HashSet<Caseoip>();
        }

        public int Oipid { get; set; }
        public string NbrOip { get; set; }
        public string AddrLn1 { get; set; }
        public string CdCity { get; set; }
        public string CdPrtyTyp { get; set; }
        public string CdState { get; set; }
        public string CdUpdtTechId { get; set; }
        public string CdZip { get; set; }
        public string CdZipAddrLst4 { get; set; }
        public DateTime DtUpdtTrans { get; set; }
        public string NbrPhone { get; set; }
        public string NmeAgency { get; set; }
        public string NmeFrstPrsn { get; set; }
        public string NmeMidPrsn { get; set; }
        public string NmeSufxPrsn { get; set; }
        public string NmeSurnmePrsn { get; set; }
        public string TxtComm { get; set; }
        public DateTime? DtTerm { get; set; }
        public string NbrCellPhone { get; set; }
        public string EmailAddress { get; set; }
        public string NbrFax { get; set; }

        public ICollection<Caseoip> Caseoip { get; set; }
    }
}
