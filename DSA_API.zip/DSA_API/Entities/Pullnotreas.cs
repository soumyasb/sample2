﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Pullnotreas
    {
        public string CdPullnotreas { get; set; }
        public string DescPullnotreas { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
