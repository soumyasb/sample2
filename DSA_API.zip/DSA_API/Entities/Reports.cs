﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Reports
    {
        public int Id { get; set; }
        public string CdActive { get; set; }
        public string CdAuth { get; set; }
        public string CdReport { get; set; }
        public string NmeReport { get; set; }
        public string NmeModule { get; set; }
    }
}
