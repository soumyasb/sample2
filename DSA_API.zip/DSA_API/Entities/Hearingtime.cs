﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hearingtime
    {
        public int Id { get; set; }
        public string CdRsn { get; set; }
        public int? HearingTime { get; set; }
        public int? InterviewTime { get; set; }
        public int? ReExamTime { get; set; }
    }
}
