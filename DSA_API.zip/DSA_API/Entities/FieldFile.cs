﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class FieldFile
    {
        public string Code { get; set; }
        public string Descr { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
