﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Region
    {
        public string CdRgnId { get; set; }
        public string CdDistId { get; set; }
        public string NmeRgn { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
