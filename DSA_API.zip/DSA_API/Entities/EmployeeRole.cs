﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class EmployeeRole
    {
        public EmployeeRole()
        {
            Employee = new HashSet<Employee>();
        }

        public string RoleId { get; set; }
        public string RoleDescription { get; set; }

        public ICollection<Employee> Employee { get; set; }
    }
}
