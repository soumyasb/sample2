﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class TransSchedResult
    {
        public int Id { get; set; }
        public string CdTrans { get; set; }
        public string CdSchedresult { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
