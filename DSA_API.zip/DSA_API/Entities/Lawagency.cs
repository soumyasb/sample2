﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Lawagency
    {
        public int Id { get; set; }
        public string CdLawAgncy { get; set; }
        public string NmeLawAgncy { get; set; }
        public string NmeTitle { get; set; }
        public string AddrLn1 { get; set; }
        public string CdCity { get; set; }
    }
}
