﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Caseoip
    {
        public string CdCase { get; set; }
        public int Oipid { get; set; }
        public string NbrOip { get; set; }
        public string CdSubpoe { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime DtUpdtTrans { get; set; }
        public string FlgAuto { get; set; }
        public string FlgMed { get; set; }
        public string FlgNotcAppt { get; set; }
        public string FlgNotcDec { get; set; }
        public string FlgSubpoeDmv { get; set; }
        public string FlgSubpoeSubj { get; set; }
        public string TxtOther { get; set; }
        public string FlgService { get; set; }

        public Dsrcase CdCaseNavigation { get; set; }
        public Oippersn Oip { get; set; }
    }
}
