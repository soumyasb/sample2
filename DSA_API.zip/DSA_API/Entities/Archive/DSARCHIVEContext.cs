﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DSA_API.Entities.Archive
{
    public partial class DSARCHIVEContext : DbContext
    {
        public virtual DbSet<Dsrcase> Dsrcase { get; set; }
        public virtual DbSet<Person> Person { get; set; }

        public DSARCHIVEContext(DbContextOptions<DSARCHIVEContext> options)
                : base(options)
        { }

        // Unable to generate entity type for table 'dbo.DSRLOG'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.HoAuthType'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.interpre'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.StayStats'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.oippersn'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.PROFILE'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.DocGeneration'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.origDAMDAP'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.Contact'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.agency'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.APPOINTMENT'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.appt_log'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.EMPLOYEE'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.CASEAGNY_test'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.caseagny'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.caseoip'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.CaseSuspense'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.DLUPDStats'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.dsrcomm'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer(@"Server=DMVSQLD04;Database=DSRARCHIVE_DEV;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Dsrcase>(entity =>
            {
                entity.HasKey(e => e.CdCase);

                entity.ToTable("DSRCASE");

                entity.Property(e => e.CdCase)
                    .HasColumnName("CD_CASE")
                    .HasColumnType("char(12)")
                    .ValueGeneratedNever();

                entity.Property(e => e.CdCaseClseId)
                    .HasColumnName("CD_CASE_CLSE_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdCityAcc)
                    .HasColumnName("CD_CITY_ACC")
                    .HasMaxLength(13)
                    .IsUnicode(false);

                entity.Property(e => e.CdDlUpdateId)
                    .HasColumnName("CD_DL_UPDATE_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdEndr)
                    .HasColumnName("CD_ENDR")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdFldDsoAlpha)
                    .IsRequired()
                    .HasColumnName("CD_FLD_DSO_ALPHA")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdFldFileLoc)
                    .HasColumnName("CD_FLD_FILE_LOC")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdHrngTyp)
                    .IsRequired()
                    .HasColumnName("CD_HRNG_TYP")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdOrigTechId)
                    .IsRequired()
                    .HasColumnName("CD_ORIG_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdRefrSrceTyp)
                    .IsRequired()
                    .HasColumnName("CD_REFR_SRCE_TYP")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdRsn)
                    .IsRequired()
                    .HasColumnName("CD_RSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdSchedRsl)
                    .HasColumnName("CD_SCHED_RSL")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdStatusRec)
                    .IsRequired()
                    .HasColumnName("CD_STATUS_REC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdStatusRec2)
                    .IsRequired()
                    .HasColumnName("CD_STATUS_REC2")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdTypAct)
                    .HasColumnName("CD_TYP_ACT")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdUpdtTechId)
                    .IsRequired()
                    .HasColumnName("CD_UPDT_TECH_ID")
                    .HasColumnType("char(3)");

                entity.Property(e => e.CdVehAuth1)
                    .HasColumnName("CD_VEH_AUTH1")
                    .HasColumnType("char(7)");

                entity.Property(e => e.CdVehAuth2)
                    .HasColumnName("CD_VEH_AUTH2")
                    .HasColumnType("char(7)");

                entity.Property(e => e.CdVehAuth3)
                    .HasColumnName("CD_VEH_AUTH3")
                    .HasColumnType("char(7)");

                entity.Property(e => e.CdVehAuthOrig)
                    .HasColumnName("CD_VEH_AUTH_ORIG")
                    .HasColumnType("char(7)");

                entity.Property(e => e.DtAcc)
                    .HasColumnName("DT_ACC")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtCaseClse)
                    .HasColumnName("DT_CASE_CLSE")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtDlUpdate)
                    .HasColumnName("DT_DL_UPDATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtMail)
                    .HasColumnName("DT_MAIL")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtModSchedHr)
                    .HasColumnName("DT_MOD_SCHED_HR")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtOrigTrans)
                    .HasColumnName("DT_ORIG_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtRcpt)
                    .HasColumnName("DT_RCPT")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtSchedHrng)
                    .HasColumnName("DT_SCHED_HRNG")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActEff)
                    .HasColumnName("DT_TYP_ACT_EFF")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActEnd)
                    .HasColumnName("DT_TYP_ACT_END")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActMod)
                    .HasColumnName("DT_TYP_ACT_MOD")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtTypActTerm)
                    .HasColumnName("DT_TYP_ACT_TERM")
                    .HasColumnType("datetime");

                entity.Property(e => e.DtUpdtTrans)
                    .HasColumnName("DT_UPDT_TRANS")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgHearing)
                    .HasColumnName("FLG_HEARING")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrCaseAccFr)
                    .HasColumnName("NBR_CASE_ACC_FR")
                    .HasColumnType("char(9)");

                entity.Property(e => e.NbrDl)
                    .IsRequired()
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(8)");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasKey(e => e.NbrDl);

                entity.ToTable("person");

                entity.HasIndex(e => e.NbrDl)
                    .HasName("person_ind")
                    .IsUnique();

                entity.Property(e => e.NbrDl)
                    .HasColumnName("NBR_DL")
                    .HasColumnType("char(10)")
                    .ValueGeneratedNever();

                entity.Property(e => e.AddrLn1)
                    .HasColumnName("ADDR_LN1")
                    .HasColumnType("char(35)");

                entity.Property(e => e.CdCity)
                    .HasColumnName("CD_CITY")
                    .HasColumnType("char(13)");

                entity.Property(e => e.CdClassLic)
                    .IsRequired()
                    .HasColumnName("CD_CLASS_LIC")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdClassLic2)
                    .HasColumnName("CD_CLASS_LIC2")
                    .HasColumnType("char(1)");

                entity.Property(e => e.CdState)
                    .HasColumnName("CD_STATE")
                    .HasColumnType("char(2)");

                entity.Property(e => e.CdZip)
                    .HasColumnName("CD_ZIP")
                    .HasColumnType("char(5)");

                entity.Property(e => e.CdZipAddrLst4)
                    .HasColumnName("CD_ZIP_ADDR_LST4")
                    .HasColumnType("char(4)");

                entity.Property(e => e.DtBirthPrsn)
                    .HasColumnName("DT_BIRTH_PRSN")
                    .HasColumnType("datetime");

                entity.Property(e => e.FlgAddrConfdntl)
                    .HasColumnName("FLG_ADDR_CONFDNTL")
                    .HasColumnType("char(1)");

                entity.Property(e => e.NbrPhone)
                    .HasColumnName("NBR_PHONE")
                    .HasColumnType("char(10)");

                entity.Property(e => e.NbrSsnPrsn).HasColumnName("NBR_SSN_PRSN");

                entity.Property(e => e.NmeFrstPrsn)
                    .IsRequired()
                    .HasColumnName("NME_FRST_PRSN")
                    .HasColumnType("char(35)");

                entity.Property(e => e.NmeMidPrsn)
                    .HasColumnName("NME_MID_PRSN")
                    .HasColumnType("char(35)");

                entity.Property(e => e.NmeSufxPrsn)
                    .HasColumnName("NME_SUFX_PRSN")
                    .HasColumnType("char(3)");

                entity.Property(e => e.NmeSurnmePrsn)
                    .IsRequired()
                    .HasColumnName("NME_SURNME_PRSN")
                    .HasColumnType("char(35)");
            });
        }
    }
}
