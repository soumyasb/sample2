﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Dsoffice
    {
        internal readonly string CD_ZIP_ADDR_LST4;
        internal string CD_FLD_FILE_DSG;

        public Dsoffice()
        {
            Employee = new HashSet<Employee>();
            Hearinglocation = new HashSet<Hearinglocation>();
            OfficeNewsItem = new HashSet<OfficeNewsItem>();
        }

        public string CdOffId { get; set; }
        public string NmeOff { get; set; }
        public string AddrLn1 { get; set; }
        public string CdCity { get; set; }
        public string CdZip { get; set; }
        public string CdZipAddrLst4 { get; set; }
        public string NbrPhone { get; set; }
        public string CdDistId { get; set; }
        public string CdBacklog { get; set; }
        public DateTime? DtEff { get; set; }
        public string CdOffAbbr { get; set; }
        public string CdFldFileDsg { get; set; }
        public string CdRqstr { get; set; }
        public DateTime? DtTerm { get; set; }
        public string NbrFax { get; set; }

        public ICollection<Employee> Employee { get; set; }
        public ICollection<Hearinglocation> Hearinglocation { get; set; }
        public ICollection<OfficeNewsItem> OfficeNewsItem { get; set; }
    }
}
