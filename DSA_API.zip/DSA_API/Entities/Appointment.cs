﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Appointment
    {
        public int AppointmentId { get; set; }
        public int NbrRcurApt { get; set; }
        public string CdActvyTyp { get; set; }
        public string CdDayTyp { get; set; }
        public string CdDteTyp { get; set; }
        public int EmpId { get; set; }
        public string CdEmpOffId { get; set; }
        public string CdMonTyp { get; set; }
        public string CdOccDayTyp { get; set; }
        public string CdOccTyp { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime DtStrtTim { get; set; }
        public DateTime DtEndTim { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string FlgDispCmt { get; set; }
        public string NbrRoom { get; set; }
        public string TxtComment { get; set; }
        public int? NbrAppt { get; set; }
        public string FlgAllDay { get; set; }
        public string FlgDelete { get; set; }

        public Employee Emp { get; set; }
    }
}
