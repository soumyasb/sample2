﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Referral
    {
        public string CdRefrSrceTyp { get; set; }
        public string DescRefrSrceTyp { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
