import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Row, Col } from 'antd';

class UnscheduledCases extends Component {
    constructor(props) {
        super(props);

        this.state={
            unScheduledCasesList: this.props.case.unScheduledCasesList
        };
    }    

    render() {

    return (
        <div>
                <Row type="flex" justify="center">
                <Col span={15}>
        <div >
        {this.state.unScheduledCasesList && <Table rowKey = "caseNumber" 
        bordered = {false} 
        size = 'default'
        scroll="none" 
        title={() => <div><span><h1>Unscheduled Cases</h1></span></div>} 
        footer={() => <p>{this.state.unScheduledCasesList.length} cases scheduled</p>} 
        showHeader 
        columns={columns} 
        dataSource={this.state.unScheduledCasesList}
        onRow={(record) => {
            return {
              onClick: () => {}
            };
          }} />
    }
    </div>
 
    </Col>
    </Row>
    </div>   );
}    
}

    
const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            //actions needed
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(UnscheduledCases);