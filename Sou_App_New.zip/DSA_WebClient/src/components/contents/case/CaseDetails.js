import React, { Component } from 'react';
import { getCaseDetails, getHearingTypes, getCaseReasons, getCaseReferrals, getCaseCertifications } from "../../../store/actions/caseActions";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Input, Button, Select, Layout, Menu, Icon } from 'antd';
import styles from "../../../Cases.css"


const {Content,Sider } = Layout;
const { TextArea } = Input;
const { Option } = Select;
class CaseDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
          caseNumber: props.match.params.CaseNumber,
            editmode: false,
            caseDetailsObj: props.cases.caseDetailsObj
        };
       this.onButtonClick = this.onButtonClick.bind(this);   
    }    
    componentDidMount() {
      debugger;
      this.props.getCaseDetails(this.state.caseNumber);
      this.props.getHearingTypes();
      this.props.getCaseReasons();
      this.props.getCaseReferrals();
      this.props.getCaseCertifications();
  }

  componentWillReceiveProps(nextProps) {
      debugger;
      if (this.props.cases.caseDetailsObj !== nextProps.cases.caseDetailsObj) {
          if(nextProps.cases.caseDetailsObj !== undefined)
          {
          this.setState({ caseDetailsObj: nextProps.cases.caseDetailsObj});
          }
      }
  }
onButtonClick = (e,value) => 
{
  debugger;
if(value === 'Edit')
{
this.setState({editmode: true});
}
if(value === 'Cancel')
{
this.setState({editmode: false});
}
if(value === 'Save')
{
this.setState({editmode: false});
}
}
    render() {
const {caseDetailsObj} = this.state;
        return (   
          <ScrollPanel
          style={{
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(0,0,0,0)"
          }}
      >
       {caseDetailsObj !== undefined ? (
          <div> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
          <div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}><Icon type="idcard"  style={{ fontSize: 32 }}/> 
            <span style={{fontSize: "xx-large"}}>{caseDetailsObj.Customer.LastName},{caseDetailsObj.Customer.FirstName}</span>
            <span style={{fontSize: "x-large"}}>DL: {caseDetailsObj.Customer.DLNumber}</span>
            <span style={{fontSize: "x-large"}}>Case: {caseDetailsObj.CaseNumber}</span>
            </div></div>
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      {/* <Breadcrumb style={{ margin: '16px 0' }}>
        <Breadcrumb.Item>Home</Breadcrumb.Item>
        <Breadcrumb.Item>List</Breadcrumb.Item>
        <Breadcrumb.Item>App</Breadcrumb.Item>
      </Breadcrumb> */}
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['1']}
            style={{ height: '100%' }}
          >
            <Menu.Item key="1"> <Icon type="profile" />
              <span>Case Detail</span>
</Menu.Item>
<Menu.Item key="2">
<Icon type="team" />
              <span>OIP</span>
</Menu.Item>
<Menu.Item key="3"> 
<Icon type="message" />
              <span>Comments</span>
</Menu.Item>
<Menu.Item key="4">
<Icon type="schedule" />
              <span>Schedule</span>
</Menu.Item>
<Menu.Item key="5">
<Icon type="book" />
              <span>Closure</span>
</Menu.Item>
<Menu.Item key="6">
<Icon type="pause-circle" />
              <span>Suspense</span>
</Menu.Item>
<Menu.Item key="7">
<Icon type="file-text" />
              <span>DAD H6</span>
</Menu.Item>
          </Menu>
        </Sider>
        <Content style={{height: "600px" }}>
        <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
               <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>Case Detail</span>
   {this.state.editmode === true ?( <span style={{paddingLeft: '82%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button> 
   <Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button></span>) :
    <span style={{paddingLeft: '87%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Edit')}>Edit</Button></span>
  }
</div>
       <Row type="flex" justify="space-around" >
    <Col span = {6}>
    <div style={{paddingTop: "5px"}}>
           <b>Date of Birth</b>:
        <Input value={caseDetailsObj.Customer.DOB} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} />          
            </div>
            <div style={{paddingTop: "10px"}}>
   <b>DL Number</b>:
  <Input value={caseDetailsObj.Customer.DLNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
            </div>
            <div style={{paddingTop: "10px"}}>
       <b>License Class</b>:
        <Input value={caseDetailsObj.Customer.classLicense} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input value={caseDetailsObj.Customer.PhoneNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Mailing Address</b>:
        <TextArea rows="5" value={caseDetailsObj.Customer.MailingAddress} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
        </div>
       </Col>
        <Col span = {6}>
        <div style={{paddingTop: "5px"}}> <b>Case Number</b>:
        <Input value={caseDetailsObj.CaseNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Received Date</b>:
        <Input value={caseDetailsObj.DateReceived} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
        </div>          
            <div style={{paddingTop: "10px"}}> <b>Case Status</b>:
        <Input value={caseDetailsObj.CaseStatus} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} /> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Hearing Type</b>:
        {this.state.editmode === true ?
          <Select value="Hearing Type" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                 <Option value="A">Urgent</Option>
                                 <Option value="B">Normal</Option>
                                 <Option value="C">Low</Option>
                              </Select> :
                              <Select defaultValue="Hearing Type" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                                 <Option value="A">Urgent</Option>
                                 <Option value="B">Normal</Option>
                                 <Option value="C">Low</Option>
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Reason</b>:
        {this.state.editmode === true ?
          <Select value="Reason" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 <Option value="A">Urgent</Option>
                                 <Option value="B">Normal</Option>
                                 <Option value="C">Low</Option>
                              </Select> :
                              <Select value="Reason" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                                 <Option value="A">Urgent</Option>
                                 <Option value="B">Normal</Option>
                                 <Option value="C">Low</Option>
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Referral</b>:
        {this.state.editmode === true ?
        <Select value="Referral" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} >
                               <Option value="A">Urgent</Option>
                               <Option value="B">Normal</Option>
                               <Option value="C">Low</Option>
                            </Select> :
                            <Select value="Referral" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                               <Option value="A">Urgent</Option>
                               <Option value="B">Normal</Option>
                               <Option value="C">Low</Option>
                            </Select>
        }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Special Cert/Endorsement</b>:
        {this.state.editmode === true ?
          <Select value="Special Cert/Endorsement" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 <Option value="A">Urgent</Option>
                                 <Option value="B">Normal</Option>
                                 <Option value="C">Low</Option>
                              </Select> :
                              <Select value="Special Cert/Endorsement" onChange={{}} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                                 <Option value="A">Urgent</Option>
                                 <Option value="B">Normal</Option>
                                 <Option value="C">Low</Option>
                              </Select>
          }
        </div>
            </Col>
            <Col span ={6}>
           </Col>
            </Row>     
            </div>  
    </div>
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    </Row>
    </div>
       ):<div></div>}
    </ScrollPanel>
); 
    }
}

const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
          getCaseDetails,
          getCaseCertifications,
          getCaseReasons,
          getCaseReferrals,
          getHearingTypes
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CaseDetails);