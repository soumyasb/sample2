import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel"
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Layout, Menu, Icon } from 'antd';

const {Content,Sider } = Layout;
class CaseDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
            // whatever the props needed
        };
    }    

    render() {

        return (   
          <ScrollPanel
          style={{
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(0,0,0,0)"
          }}
      >
          <div> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
          <div style={{
            justify: "center",
            height: "40px",
           // backgroundColor: "navyblue",
            border: "3px solid white"}} ><Icon type="idcard" /> <span style={{fontSize: "x-large"}}>Vincent , George</span></div>
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      {/* <Breadcrumb style={{ margin: '16px 0' }}>
        <Breadcrumb.Item>Home</Breadcrumb.Item>
        <Breadcrumb.Item>List</Breadcrumb.Item>
        <Breadcrumb.Item>App</Breadcrumb.Item>
      </Breadcrumb> */}
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['1']}
            style={{ height: '100%' }}
          >
            <Menu.Item key="1"> <Icon type="profile" />
              <span>Case Detail</span>
</Menu.Item>
<Menu.Item key="2">
<Icon type="team" />
              <span>OIP</span>
</Menu.Item>
<Menu.Item key="3"> 
<Icon type="message" />
              <span>Comments</span>
</Menu.Item>
<Menu.Item key="4">
<Icon type="schedule" />
              <span>Schedule</span>
</Menu.Item>
<Menu.Item key="5">
<Icon type="book" />
              <span>Closure</span>
</Menu.Item>
<Menu.Item key="6">
<Icon type="pause-circle" />
              <span>Suspense</span>
</Menu.Item>
<Menu.Item key="7">
<Icon type="file-text" />
              <span>DAD H6</span>
</Menu.Item>
          </Menu>
        </Sider>
        <Content style={{height: "600px" }}>
        <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
                <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa"
 //  border: "3px solid white"
   }} ><Icon type="idcard" /> <span style={{fontSize: 'large'}}>Case Detail</span></div>
              <Row type="flex" justify="center">
    <Row>
        document Icon, Title, Edit, Cancel, Save buttons
    </Row>
   <Row>
     <Col>
      <Row gutter={0}>     
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
     </Col>
     <Col>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      </Col>
     <Col>
     Show financial responsibilities list when selected reason is 950
     </Col>
    </Row>
    </Row>
    </div>
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    </Row>
    </div>
    </ScrollPanel>
); 
    }
}

const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
           // Whatever the actions needed 
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CaseDetails);