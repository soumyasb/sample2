import React, { Component } from 'react';
import { getCaseDetails, getHearingTypes, getCaseReasons, getCaseReferrals, getCaseCertifications } from "../../../store/actions/caseActions";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Input, Button, Select, Layout, Menu, Icon } from 'antd';
import styles from "../../../Cases.css"


const {Content,Sider } = Layout;
const { TextArea } = Input;
const { Option } = Select;
const getDropdownList = (listObj, selectedValue) =>   
{  
  debugger;
    let list = [];   

     listObj.map(item =>
{
  if(item.Value === selectedValue)
  {
    list.push(<option key={item.Value} value={item.Value} selected>{item.Text}</option>)
  }
  else
  {
  list.push(<option key={item.Value} value={item.Value}>{item.Text}</option>)
  }

});
    
    return list;     
   }
const reqRsnCodesForCerts = ["871","875","880","881","882","883","884","885","887","888","889","891","892","894","897","898"];


class CaseDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
          caseNumber: props.match.params.CaseNumber,
            editmode: false,
            caseDetailsObj: props.cases.caseDetailsObj,
            hearingTypes: props.cases.hearingTypesList,
            caseReasons: props.cases.caseReasonsList,
            caseReferrals: props.cases.caseReferralsList,
            caseCertifications: props.cases.caseCertificationsList,
            isRequired: false
           
        };
       this.onButtonClick = this.onButtonClick.bind(this);   
       this.handleChange = this.handleChange.bind(this);
    }    
    componentDidMount() {
      debugger;
      this.props.getCaseDetails(this.state.caseNumber);
      this.props.getHearingTypes();
      this.props.getCaseReasons();
      this.props.getCaseReferrals();
      this.props.getCaseCertifications();
  }

  componentWillReceiveProps(nextProps) {
      debugger;
      if (this.props.cases.caseDetailsObj !== nextProps.cases.caseDetailsObj) {
          if(nextProps.cases.caseDetailsObj !== undefined)
          {
          this.setState({ caseDetailsObj: nextProps.cases.caseDetailsObj});
          this.setState({ hearingType: nextProps.cases.caseDetailsObj.CD_HRNG_TYP});
          this.setState({ caseReason: nextProps.cases.caseDetailsObj.CD_RSN});
          this.setState({ caseReferral: nextProps.cases.caseDetailsObj.CD_REFR_SRCE_TYP});
          this.setState({ hearingTypes: nextProps.cases.hearingTypesList});
          this.setState({ caseReasons: nextProps.cases.caseReasonsList});
          this.setState({ caseReferrals: nextProps.cases.caseReferralsList});
          this.setState({ caseCertifications: nextProps.cases.caseCertificationsList});
          }
      }
  }
onButtonClick = (e,value) => 
{
  debugger;
if(value === 'Edit')
{
this.setState({editmode: true});
}
if(value === 'Cancel')
{
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_HRNG_TYP});
  this.setState({caseReason: this.props.cases.caseDetailsObj.CD_RSN});
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_REFR_SRCE_TYP});
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_HRNG_TYP});
  this.setState({editmode: false});
}
if(value === 'Save')
{
this.setState({editmode: false});
}
}

handleChange = (e,listType) => {
  debugger;
  if(listType === 'HRNG_TYP')
{    
 this.setState({hearingType: e});
}
if(listType === 'CASE_RSN')
{    
 this.setState({caseReason: e});
}
if(listType === 'CASE_RFL')
{    
 this.setState({caseReferral: e});
}
if(listType === 'CASE_CERT')
{    
 this.setState({caseCertifications: e});
}
}
    render() {
const {caseDetailsObj} = this.state;

let hearingTypesList = [], caseReasonsList = [], caseReferralsList = [], caseCertificationsList = [];
if(this.state.hearingTypes !== undefined )
{ 
  hearingTypesList = getDropdownList(this.state.hearingTypes, this.state.caseDetailsObj.CD_HRNG_TYP);    
}
if(this.state.caseReasons !== undefined)
{ 
  caseReasonsList = getDropdownList(this.state.caseReasons, this.state.caseDetailsObj.CD_RSN);    
}
if(this.state.caseReferrals !== undefined)
{ 
  caseReferralsList = getDropdownList(this.state.caseReferrals, this.state.caseDetailsObj.CD_REFR_SRCE_TYP);    
}
if(this.state.caseCertifications !== undefined)
{ 
  caseCertificationsList = getDropdownList(this.state.caseCertifications, "");    
}
        return (   
          <ScrollPanel
          style={{
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(0,0,0,0)"
          }}
      >
       {caseDetailsObj !== undefined ? (
          <div> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
          <div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}><Icon type="idcard"  style={{ fontSize: 32 }}/> 
            <span style={{fontSize: "xx-large"}}>{caseDetailsObj.Customer.LastName},{caseDetailsObj.Customer.FirstName}</span>
            <span style={{fontSize: "x-large"}}>DL: {caseDetailsObj.Customer.DLNumber}</span>
            <span style={{fontSize: "x-large"}}>Case: {caseDetailsObj.CaseNumber}</span>
            </div></div>
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      {/* <Breadcrumb style={{ margin: '16px 0' }}>
        <Breadcrumb.Item>Home</Breadcrumb.Item>
        <Breadcrumb.Item>List</Breadcrumb.Item>
        <Breadcrumb.Item>App</Breadcrumb.Item>
      </Breadcrumb> */}
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['1']}
            style={{ height: '100%' }}
          >
            <Menu.Item key="1"> <Icon type="profile" />
              <span>Case Detail</span>
</Menu.Item>
<Menu.Item key="2">
<Icon type="team" />
              <span>OIP</span>
</Menu.Item>
<Menu.Item key="3"> 
<Icon type="message" />
              <span>Comments</span>
</Menu.Item>
<Menu.Item key="4">
<Icon type="schedule" />
              <span>Schedule</span>
</Menu.Item>
<Menu.Item key="5">
<Icon type="book" />
              <span>Closure</span>
</Menu.Item>
<Menu.Item key="6">
<Icon type="pause-circle" />
              <span>Suspense</span>
</Menu.Item>
<Menu.Item key="7">
<Icon type="file-text" />
              <span>DAD H6</span>
</Menu.Item>
          </Menu>
        </Sider>
        <Content style={{height: "600px" }}>
        <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
               <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>Case Detail</span>
   {this.state.editmode === true ?( <span style={{paddingLeft: '82%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button> 
   <Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button></span>) :
    <span style={{paddingLeft: '87%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Edit')}>Edit</Button></span>
  }
</div>
       <Row type="flex" justify="space-around" >
    <Col span = {6}>
    <div style={{paddingTop: "5px"}}>
           <b>Date of Birth</b>:
        <Input value={caseDetailsObj.Customer.DOB} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} />          
            </div>
            <div style={{paddingTop: "10px"}}>
   <b>DL Number</b>:
  <Input value={caseDetailsObj.Customer.DLNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
            </div>
            <div style={{paddingTop: "10px"}}>
       <b>License Class</b>:
        <Input value={caseDetailsObj.Customer.classLicense} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input value={caseDetailsObj.Customer.PhoneNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Mailing Address</b>:
        <TextArea rows="5" value={caseDetailsObj.Customer.MailingAddress} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
        </div>
       </Col>
        <Col span = {6}>
        <div style={{paddingTop: "5px"}}> <b>Case Number</b>:
        <Input value={caseDetailsObj.CaseNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Received Date</b>:
        <Input value={caseDetailsObj.DateReceived} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}}/> 
        </div>          
            <div style={{paddingTop: "10px"}}> <b>Case Status</b>:
        <Input value={caseDetailsObj.CaseStatus} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} /> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Hearing Type</b>:
        {this.state.editmode === true ?

          <Select value={this.state.hearingType} onChange={e => this.handleChange(e, 'HRNG_TYP')} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                 {hearingTypesList}
                              </Select> :
                              <Select value={this.state.hearingType} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >        
                                {hearingTypesList}               
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Reason</b>:
        {this.state.editmode === true ?
          <Select value={this.state.caseReason} onChange={e => this.handleChange(e, 'CASE_RSN')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseReasonsList}
                              </Select> :
                              <Select value={this.state.caseReason} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                              {caseReasonsList}
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Referral</b>:
        {this.state.editmode === true ?
        <Select value={this.state.caseReferral} onChange={e => this.handleChange(e, 'CASE_RFL')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                               {caseReferralsList}
                            </Select> :
                            <Select value={caseDetailsObj.CD_REFR_SRCE_TYP} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                            {caseReferralsList}
                            </Select>
        }
        </div>
       { reqRsnCodesForCerts.includes(this.state.caseReason) && <div style={{paddingTop: "10px"}}> <b>Special Cert/Endorsement</b>:
        {this.state.editmode === true ?
          <Select value="Select an Option" onChange={this.handleChange} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseCertificationsList}
                              </Select> :
                              <Select value="Select an Option" showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                              </Select>
          }
        </div>
       }
            </Col>
            <Col span ={6}>
           </Col>
            </Row>     
            </div>  
    </div>
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    </Row>
    </div>
       ):<div></div>}
    </ScrollPanel>
); 
    }
}

const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
          getCaseDetails,
          getCaseCertifications,
          getCaseReasons,
          getCaseReferrals,
          getHearingTypes
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CaseDetails);