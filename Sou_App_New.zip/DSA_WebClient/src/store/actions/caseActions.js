import axios from "axios";
import customerdetails from "../../mocks/customerdetails.json";

//COMMON ACTIONS
export const getCaseSearchResults = data => ({
  type: "GET_CASE_SEARCHRESULTS",
  data: data
});

export const searchCases = (seachString) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/Search/"+seachString).then(response => {
      dispatch(getCaseSearchResults(response.data));
    });
  };
};

export const getCustomerDetailsData = data => ({
  type: "GET_CUSTOMERDETAILS",
  data: data
});

export const getCustomerDetails = (dlNumber) => {
  debugger;
  return dispatch => {
    // axios.get("http://localhost:32610/api/Customer/"+dlNumber).then(response => {
    //   dispatch(getCustomerDetailsData(response.data));
    //   console.log("customer data returned");
    //   console.log(response.data);
    // });
    dispatch(getCustomerDetailsData(customerdetails));
  };
};

export const getCaseDetails = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/"+caseNumber).then(response => {
      return {
        type: "GET_CASEDETAILS",
        data: response.data
      }
    });
  };
};

export const getHearingTypes = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetHearingTypes").then(response => {
      return {
        type: "GET_HEARINGTYPES",
        data: response.data
      }
    });
  };
};

export const getCaseReasons = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetCaseReasons").then(response => {
      return {
        type: "GET_CASEREASONS",
        data: response.data
      }
    });
  };
};

export const getCaseReferrals = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetCaseReferrals").then(response => {
      return {
        type: "GET_CASEREFERRALS",
        data: response.data
      }
    });
  };
};

export const getCaseCertificationss = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetCaseCertifications").then(response => {
      return {
        type: "GET_CASECERTIFICATIONS",
        data: response.data
      }
    });
  };
};

export const getOIPTypes = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetOIPTypes").then(response => {
      return {
        type: "GET_OIPTYPES",
        data: response.data
      }
    });
  };
};

export const getOIPLanguages = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetOIPLanguages").then(response => {
      return {
        type: "GET_OIPLANGUAGES",
        data: response.data
      }
    });
  };
};

export const getCaseCoverSheet = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/GetCaseCoverSheet?caseNumber="+caseNumber).then(response => {
      return {
        type: "GET_CASECOVERSHEET",
        data: response.data
      }
    });
  };
};