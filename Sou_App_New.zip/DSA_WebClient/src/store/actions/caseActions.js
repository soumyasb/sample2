import axios from "axios";
import caseDetails from "../../mocks/casedetails.json";

//COMMON ACTIONS
export const getCaseSearchResults = data => ({
  type: "GET_CASE_SEARCHRESULTS",
  data: data
});

export const searchCases = (seachString) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/Search/"+seachString).then(response => {
      dispatch(getCaseSearchResults(response.data));
    });
  };
};

export const getCustomerDetailsData = data => ({
  type: "GET_CUSTOMERDETAILS",
  data: data
});

export const getCustomerDetails = (dlNumber) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/Customer/"+dlNumber).then(response => {
      dispatch(getCustomerDetailsData(response.data));
    });
  };
};

export const getCaseDetailsData = data => ({
  type: "GET_CASEDETAILS",
  data: data
});

export const getCaseDetails = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/"+caseNumber).then(response => {
      dispatch(getCaseDetailsData(response.data));
    });
  };
};

export const getHearingTypesData = data => ({
  type: "GET_HEARINGTYPES",
  data: data
});

export const getHearingTypes = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetHearingTypes").then(response => {
      dispatch(getHearingTypesData(response.data));
    });
  };
};

export const getCaseReasonsData = data => ({
  type: "GET_CASEREASONS",
  data: data
});

export const getCaseReasons = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetCaseReasons").then(response => {
      dispatch(getCaseReasonsData(response.data));
    });
  };
};

export const getCaseReferralsData = data => ({
  type: "GET_CASEREFERRALS",
  data: data
});

export const getCaseReferrals = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetCaseReferrals").then(response => {
      dispatch(getCaseReferralsData(response.data));
    });
  };
};

export const getCaseCertificationsData = data => ({
  type: "GET_CASECERTIFICATIONS",
  data: data
});

export const getCaseCertifications = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetCaseCertifications").then(response => {
      dispatch(getCaseCertificationsData(response.data));
    });
  };
};

export const getOIPTypes = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetOIPTypes").then(response => {
      return {
        type: "GET_OIPTYPES",
        data: response.data
      }
    });
  };
};

export const getOIPLanguages = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetOIPLanguages").then(response => {
      return {
        type: "GET_OIPLANGUAGES",
        data: response.data
      }
    });
  };
};

export const getCaseCoverSheet = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/GetCaseCoverSheet?caseNumber="+caseNumber).then(response => {
      return {
        type: "GET_CASECOVERSHEET",
        data: response.data
      }
    });
  };
};