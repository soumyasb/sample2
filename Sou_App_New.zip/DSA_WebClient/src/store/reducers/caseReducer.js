const caseReducerDefaultState = {};

const casereducer = (state = caseReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_CASE_SEARCHRESULTS": {
      return { ...state, searchList: action.data };
    }
    case "GET_CUSTOMERDETAILS": {
      return { ...state, customerDetailsObj: action.data };
    }
    case "GET_CASEDETAILS": {
      return { ...state, caseDetailsObj: action.data };
    }
    case "GET_HEARINGTYPES": {
      return { ...state, hearingTypesList: action.data };
    }
    case "GET_CASEREASONS": {
      return { ...state, caseReasonsList: action.data };
    }
    case "GET_CASEREFERRALS": {
      return { ...state, caseReferralsList: action.data };
    }
    case "GET_CASECERTIFICATIONS": {
      return { ...state, caseCertificationsList: action.data };
    }
    case "GET_OIPTYPES": {
      return { ...state, caseOIPTypesList: action.data };
    }
    case "GET_OIPLANGUAGES": {
      return { ...state, caseOIPLanguagesList: action.data };
    }
    case "GET_CASECOVERSHEET": {
      return { ...state, caseCoverSheetObj: action.data };
    }
    default:
      return state;
  }
};

export default casereducer;
