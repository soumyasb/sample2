import React, { Component } from "react";
import moment from 'moment';
import { Modal, Form, Input, Select, Checkbox, DatePicker, Button } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;

const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
};

const getModalSettings = (actionType, onOk, onCancel) => {
    let title, okText = '';
    let footer = [];

    switch(actionType) {
        case 'create': 
            title = 'Create News Item';
            okText = 'Create';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'edit': 
            title = 'Edit News Item';
            okText = 'Edit';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'details': 
            title = 'details - TODO';
            okText = 'Details';
            footer = [
                <Button key="Close" onClick={onCancel}>Close</Button>
            ];
            break;
        case 'delete': 
            title = 'delete - TODO';
            okText = 'Delete';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        default: 
            title = 'Create News Item';
    }

    return {
        title,
        okText,
        footer,
    }

}


const getOfficeDetails = (newsItemObj, editNewsItemObj, actionType) =>   
 {   
     let officedetails = [], officelist = [], officegrp = [];   
     if(actionType === 'create')   
     {   
      officelist = newsItemObj.offices.map((office) =>    
     <Option key={office.officeId}>{office.officeName}</Option>   
     );   
 }   
 else if (actionType === 'edit') {   
     editNewsItemObj.offices.forEach(element => {   
          if(editNewsItemObj.officeGroup!== null && editNewsItemObj.officeGroup.includes(element.officeId))   
          {   
             officegrp.push(element.officeId);   
        officelist.push(<Option key={element.officeId}>{element.officeName}</Option>);   
          }   
         else{   
             officelist.push(<Option key={element.officeId}>{element.officeName}</Option>);   
         }   
     });      
         
 }   
 else
 {

 }
 officedetails = {officelist, officegrp};   
    
  return officedetails;   
} 

class NewsModal extends Component {
    constructor(props) {
        super(props);

        this.state ={
            newsItemObj: props.newsItemObj,
            editNewsItemObj: props.editNewsItemObj,
            value: [""],
            newNewsItem:
            {
                "newsId": 0,
  "empId": 0,
  "authorName": "string",
  "priority": "string",
  "newsText": "string",
  "createDate": "2018-06-26T16:44:20.455Z",
  "subject": "string",
  "startDate": "2018-06-26T16:44:20.455Z",
  "endDate": "2018-06-26T16:44:20.455Z",
  "offices": [
    {
      "results": [
        null
      ],
      "regionId": "string",
      "regionName": "string",
      "officeId": "string",
      "officeName": "string"
    }
  ],
  "employeeType": "string",
  "allOffices": true,
  "officeGroup": [
    "string"
  ]
            }
        }
        this.onPriorityChange = this.onPriorityChange.bind(this);   
        this.onNewsTextChange = this.onNewsTextChange.bind(this);   
        this.onSubjectChange = this.onSubjectChange.bind(this); 
        
        //bindInstanceMethods(this);
    }

    componentWillReceiveProps(nextProps) {
        // if (this.props.newsItemObj !== nextProps.newsItemObj) {
        //     this.setState({ newsItemObj: nextProps.newsItemObj
        //          });
        // } 
    }

    onPriorityChange(val) {
        // const { newsItemObj } = this.state;
        // newsItemObj.priority = val;
        // this.setState({ newsItemObj });
        const { newNewsItem } = this.state;      
              newNewsItem.priority = val;       
              this.setState({newNewsItem }); 
    }

    onNewsTextChange(e) {
        // const { newsItemObj } = this.state;
        // newsItemObj.newsText = e.target.value;
        // this.setState({ newsItemObj });
        const { newNewsItem } = this.state;      
              newNewsItem.newsText =  e.target.value;       
              this.setState({newNewsItem }); 
        
    }

    onSubjectChange(e) {
        // const { newsItemObj } = this.state;
        // newsItemObj.subject = e.target.value;
        // this.setState({ newsItemObj });
        const { newNewsItem } = this.state;      
              newNewsItem.subject =  e.target.value;     
              this.setState({newNewsItem }); 
    }
    handleChange = (value) => { 
                console.log('onChange ', value); 
               this.setState({ value }); 
              } 
        
    handleOk() {
        this.props.onOk(this.state.newsNewsItem);
    }

    handleCancel() {
        this.setState({
            newNewsItem:
            {
                "newsId": 0,
  "empId": 0,
  "authorName": "",
  "priority": "",
  "newsText": "",
  "createDate": "",
  "subject": "",
  "startDate": "",
  "endDate": "",
  "offices": [],
  "employeeType": "",
  "allOffices": true,
  "officeGroup": [""]
            }
        })
        this.props.onCancel();
    }

    render() {
        
      
        let { newNewsItem } = this.state;
        let modalSettings = getModalSettings(this.props.actionType, this.props.onOk, this.props.onCancel);
        let officedetails = [];
        if(this.prop.actionType === 'create')
        {
            let { newsItemObj } = this.state;
            newNewsItem = JSON.parse(JSON.stringify(newsItemObj));      
        }
        if(this.prop.actionType === 'edit')
        {
            let { editNewsItemObj } = this.state;
            newNewsItem = JSON.parse(JSON.stringify(editNewsItemObj));
        }
       
        officedetails = getOfficeDetails(this.props.newsItemObj, this.props.editNewsItemObj, this.props.actionType);
       return (
            <Modal
                visible={this.props.modalVisible}
                onOk={this.handleOk}
                onCancel={this.handleCancel}
                title={modalSettings.title}
                okText={modalSettings.okText} 
                footer={modalSettings.footer}
                width={'750px'}
            >
                <div>
                    <Form layout={'horizontal'}>
                        <FormItem
                            label="Priority"
                            {...formItemLayout}
                        > 
                            {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            
                               // this.props.actionType === 'create' ?
                                <Select value={newNewsItem.priority} onChange={this.onPriorityChange}>
                                <Option value="A">Urgent</Option>
                                <Option value="B">Normal</Option>
                                <Option value="C">Low</Option>
                             </Select> 
                            //  :
                            //  <Select value={editNewsItemObj.priority} onChange={this.onPriorityChange}>
                            //     <Option value="A">Urgent</Option>
                            //     <Option value="B">Normal</Option>
                            //     <Option value="C">Low</Option>
                            //  </Select> 
                            
                            
                            :
                            <div>sdfdsfdssdf</div> 
                            }
                        </FormItem>
                        <FormItem
                            label="Subject"
                            {...formItemLayout}
                        >
                          {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                          // this.props.actionType === 'create' ?
                            <Input value={newNewsItem.subject} placeholder="Subject" onChange={this.onSubjectChange} />
                            // :
                            // <Input value={editNewsItemObj.subject} placeholder="Subject" onChange={this.onSubjectChange} />
                            :
                            <div>sdfdsfdssdf</div> 
                        }
                        </FormItem>
                        <FormItem
                            label="News Text"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                        //   this.props.actionType === 'create' ? 
                        //   <TextArea value={newsItemObj.newsText} rows="6" onChange={this.onNewsTextChange} />
                        //   :
                            <TextArea value={newNewsItem.newsText} rows="6" onChange={this.onNewsTextChange} />
                            :
                            <div>sdfdsfdssdf</div> 
                    }
                        </FormItem>
                        <FormItem
                            label="Start Date"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                        //  this.props.actionType === 'create'?
                        //     <DatePicker placeholder="Start Date"
                        //         defaultValue={moment(newsItemObj.startDate, 'YYYY-MM-DD')} onChange={() => {}} />
                        //         :
                                <DatePicker placeholder="Start Date"
                                defaultValue={moment(newNewsItem.startDate, 'YYYY-MM-DD')} onChange={() => {}} />
                
                                :
                                <div>sdfdsfdssdf</div> 
                }
                        </FormItem>
                        <FormItem
                            label="End Date"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                        //  this.props.actionType === 'create' ?
                        //     <DatePicker placeholder="End Date"
                        //         defaultValue={moment(newsItemObj.endDate, 'YYYY-MM-DD')} onChange={() => {}} />
                           //     :
                                <DatePicker placeholder="End Date"
                                defaultValue={moment(newNewsItem.endDate, 'YYYY-MM-DD')} onChange={() => {}} />
                                :
                                <div>sdfdsfdssdf</div> 
            }
                        </FormItem>
                        <FormItem
                            label="Office Scope"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                           <Checkbox checked={this.state.checked} onChange={this.onchecked}  placeholder="input placeholder">
                                All offices in your region?
                            </Checkbox>
                             :
                             <div>sdfdsfdssdf</div> 
        }
                        </FormItem>
                      
                        <FormItem label="Select Offices" {...formItemLayout}>      
                            {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <Select   
     mode="multiple"   
     style={{ width: '100%' }}   
     placeholder="Please select"   
     defaultValue={officedetails.officegrp}   
     onChange={this.handleChange}   
   >   
   
     {officedetails.officelist}   
   </Select>   
    :
    <div>sdfdsfdssdf</div> 
                        }
                            </FormItem> 

                    </Form>
                </div>  
            </Modal>
        );
    }
}

export default NewsModal;
