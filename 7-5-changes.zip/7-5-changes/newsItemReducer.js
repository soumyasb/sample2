const newsItemReducerDefaultState = {
};

const newsitemreducer = (state = newsItemReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_NEWSITEMS": {
      return { ...state, list: action.data };
    }
    case "GET_CREATENEWSITEM":
    {
      return { ...state, newsItemObj: action.data};
    }
    case "GET_EDITNEWSITEM":
    {
      return { ...state, editNewsItemObj: action.data};
    }
    default:
      return state;
  }
};

export default newsitemreducer;
