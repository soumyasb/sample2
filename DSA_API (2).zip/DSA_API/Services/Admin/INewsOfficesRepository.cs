﻿using System.Collections.Generic;
using DSA_API.Entities;
using DSA_API.Models.Admin;
using DSA_API.Models.DSOffice;

namespace DSA_API.Services
{
    public interface INewsOfficesRepository
    {
        int CreateNewsItems(NewsItemDTO newsItemModel, List<string> offices);
        IEnumerable<NewsItem> GetNewsItems(int empid);
        NewsItem GetNewsItem(int newsid);
        IEnumerable<OfficeNewsItem> GetOfficeNewsItems(int newsid);
        bool ModifyNewsItems(NewsItemDTO newsItemModel);
        bool ModifyOfficeNewsItems(NewsItemDTO newsItem, List<string> offices);
        bool DeleteNewsItem(NewsItem newsitem);
        bool DeleteOfficeNewsItems(NewsItem newsitem);
    }
}