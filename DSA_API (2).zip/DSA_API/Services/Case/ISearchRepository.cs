﻿using DSA_API.Models.Customer;

namespace DSA_API.Services
{
    public interface ISearchRepository
    {
        SearchResultsDTO CaseSearch(string keyword);
    }
}