﻿using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Models.Customer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class CustomerRepository : ICustomerRepository
    {
        private DSAContext _context;
        private DSARCHIVEContext _archived_context;
        public CustomerRepository(DSAContext context, DSARCHIVEContext archive_context  )
        {
            _context = context;
            _archived_context = archive_context;
        }
        public CustomerDTO getCustomerDetail(string dlNumber)
        {
            var archived = _archived_context.Person.AsNoTracking()
                .Where(c => c.NbrDl == dlNumber)
                .Select(cust => new CustomerDTO()
                {
                    Message = dlNumber + " All Cases for this Drivers License are archived - please contact LOD MIS Group for Information "
                }).FirstOrDefault();
            if (archived != null)
            {
                return archived;
            }

            var customerDetail = _context.Person.AsNoTracking()
                .Where(c => c.NbrDl == dlNumber)
                .Select(cust => new CustomerDTO()
                {
                    DLNumber = cust.NbrDl,
                    FirstName = cust.NmeFrstPrsn,
                    LastName = cust.NmeSurnmePrsn,
                    MiddleName = cust.NmeMidPrsn,
                    Suffix = cust.NmeSufxPrsn,
                    DT_BIRTH_PRSN = cust.DtBirthPrsn,
                    Address1 = cust.AddrLn1,
                    City = cust.CdCity,
                    State = cust.CdState,
                    classLicense = cust.CdClassLic,
                    Class1 = cust.CdClassLic,
                    Class2 = cust.CdClassLic2,
                    ZipFull = cust.CdZip + "-" + cust.CdZipAddrLst4,
                    Zip = cust.CdZip
                })
                .FirstOrDefault();

            return customerDetail;
        }
    }
}
