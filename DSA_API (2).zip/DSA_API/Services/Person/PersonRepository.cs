﻿using DSA_API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class PersonRepository : IPersonRepository
    {
        private DSAContext _context;
        public PersonRepository(DSAContext context)
        {
            _context = context;
        }
        public bool UpdatePersonFromDCS(string dlNumber, string address1, string city,
            string class1, string class2, string state, string zip, string birthdate,
            string flgAddr, string ssn, string firstname, string middlename, string suffix,
            string lastname)
        {
            Person result = (from p in _context.Person
                             where p.NbrDl == dlNumber
                             select p).SingleOrDefault();
            result.AddrLn1 = address1;
            result.CdCity = city;
            result.CdClassLic = class1;
            result.CdClassLic2 = class2;
            result.CdState = state;
            result.CdZip = zip;
            result.DtBirthPrsn = Convert.ToDateTime(birthdate);
            result.FlgAddrConfdntl = flgAddr;
            result.NbrSsnPrsn = Convert.ToInt32(ssn);
            result.NmeFrstPrsn = firstname;
            result.NmeMidPrsn = middlename;
            result.NmeSufxPrsn = suffix;
            result.NmeSurnmePrsn = lastname;
            return (_context.SaveChanges() >= 0);
        }
    }
}
