﻿namespace DSA_API.Models.Customer
{
    public class CustomerCommentDTO
    {
        public int NBR_COMM { get; set; }
        public string CD_UPDT_TECH_ID { get; set; }
        public string EmployeeFullName { get; set; }
        public System.DateTime DT_UPDT_TRANS { get; set; }
        public string TXT_COMM { get; set; }
    }
}
