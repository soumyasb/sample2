﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class OIPDTO
    {
        public string resourceURI { get; set; }
        public string caseAssignURI { get; set; }
        public int OIPID { get; set; }
        public string NBR_OIP { get; set; }
        public string CD_UPDT_TECH_ID { get; set; }
        public string NME_FRST_PRSN { get; set; }
        public string NME_SURNME_PRSN { get; set; }
        public string NME_MID_PRSN { get; set; }
        public string NME_SUFX_PRSN { get; set; }
        public string NBR_PHONE { get; set; }
        public string NBR_CELL_PHONE { get; set; }
        public string NBR_FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ADDR_LN1 { get; set; }
        public string CD_CITY { get; set; }
        public string CD_STATE { get; set; }
        public string CD_ZIP { get; set; }
        public string NME_AGENCY { get; set; }
        public string TXT_COMM { get; set; }
        public string CD_PRTY_TYP { get; set; }
        public string CdCase { get; set; }
        public string CD_LANGUAGE { get; set; }
        public bool Error { get; set; }

        //
        //  variables below used by javascript for displaying only the dto values listed in detailsDisplayed &
        //  with the clean titles matching the index in detailsCleanNames
        //
        public string[] detailsDisplayed = new string[4] { "NME_AGENCY", "NBR_PHONE", "NBR_CELL_PHONE", "NBR_FAX" };
        public string[] detailsCleanNames = new string[4] { "Agency Name", "Phone Number", "Cell Number", "Fax Number" };
    }
}
