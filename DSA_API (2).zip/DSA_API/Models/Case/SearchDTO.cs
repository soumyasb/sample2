﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class SearchDTO
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DLNumber { get; set; }
        public List<string> CaseNumbers { get; set; }
    }
}
