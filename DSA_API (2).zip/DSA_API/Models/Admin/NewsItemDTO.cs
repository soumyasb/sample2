﻿using DSA_API.Models.DSOffice;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DSA_API.Models.Admin
{
    public class NewsItemDTO
    {
        public int NewsId { get; set; }
        public int EmpId { get; set; }
        public string AuthorName { get; set; }
        public string Priority { get; set; }

        public IEnumerable<SelectListItem> PriorityList
        {
            get
            {
                yield return new SelectListItem { Text = "Normal", Value = "B" };
                yield return new SelectListItem { Text = "Urgent", Value = "A" };
                yield return new SelectListItem { Text = "Low", Value = "C" };
            }
        }
        [Required(ErrorMessage = "You should fill out a news text.")]
        [MaxLength(4000, ErrorMessage = "The news text shouldn't have more than 4000 characters.")]
        public string NewsText { get; set; }
        public System.DateTime CreateDate { get; set; }
        [Required(ErrorMessage = "You should fill out a subject.")]
        [MaxLength(50, ErrorMessage = "The subject shouldn't have more than 50 characters.")]
        public string Subject { get; set; }
        [Required]
        public System.DateTime StartDate { get; set; }
        [Required]
        public DateTime? EndDate { get; set; }

        public List<RegionOfficeDTO> Offices { get; set; }
        public string EmployeeType { get; set; }
        public bool AllOffices { get; set; }

        public List<string> officeGroup { get; set; }

        
    }
}
