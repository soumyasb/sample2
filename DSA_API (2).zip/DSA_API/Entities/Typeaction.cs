﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Typeaction
    {
        public string CdTypAct { get; set; }
        public string DescTypAct { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
