﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class EmployeeClass
    {
        public string CdEmpClass { get; set; }
        public string CdDesc { get; set; }
    }
}
