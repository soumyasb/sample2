﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Reason
    {
        public string CdRsn { get; set; }
        public string DescRsn { get; set; }
        public DateTime? DtTerm { get; set; }
        public int? Category { get; set; }
    }
}
