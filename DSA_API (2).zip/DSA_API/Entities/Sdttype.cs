﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Sdttype
    {
        public string CdCode { get; set; }
        public string CdDesc { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
