﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class CaseSuspense
    {
        public int SuspenseId { get; set; }
        public string CdCase { get; set; }
        public int NbrSequence { get; set; }
        public DateTime DtSusp { get; set; }
        public string CdSuspReqBy { get; set; }
        public string CdSuspRsn { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string TxtSusp { get; set; }

        public Dsrcase CdCaseNavigation { get; set; }
    }
}
