﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Pullnotpurge
    {
        public string CdPullnotpurge { get; set; }
        public string DescPullnotpurge { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
