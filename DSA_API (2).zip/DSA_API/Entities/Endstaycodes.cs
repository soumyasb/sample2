﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Endstaycodes
    {
        public string CdEndstay { get; set; }
        public string DescEndstay { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
