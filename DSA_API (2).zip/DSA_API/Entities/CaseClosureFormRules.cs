﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class CaseClosureFormRules
    {
        public string FormId { get; set; }
        public string ControlName { get; set; }
        public string Action { get; set; }
        public string Value { get; set; }
    }
}
