﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class CommercialStatusInd
    {
        public string CdCode { get; set; }
        public string CdDesc { get; set; }
        public DateTime? DtEndEff { get; set; }
    }
}
