﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class RowColumnHexValue
    {
        public string Row { get; set; }
        public string Col { get; set; }
        public string Hexvalue { get; set; }
        public string Charvalue { get; set; }
    }
}
