﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class OfficeNewsItem
    {
        public string CdOffId { get; set; }
        public int NewsId { get; set; }

        public Dsoffice CdOff { get; set; }
        public NewsItem News { get; set; }
    }
}
