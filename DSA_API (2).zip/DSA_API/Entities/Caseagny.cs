﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Caseagny
    {
        public string CdCase { get; set; }
        public int Oipid { get; set; }
        public int? NbrSeqOip { get; set; }
        public string NbrOip { get; set; }
        public string CdSubpoe { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime DtUpdtTrans { get; set; }
        public string FlgNotcAppt { get; set; }
        public string FlgNotcDec { get; set; }
        public string FlgSubpoeDmv { get; set; }
        public string FlgSubpoeSubj { get; set; }
        public string NmeFrstPrsn { get; set; }
        public string NmeMidPrsn { get; set; }
        public string NmeSufxPrsn { get; set; }
        public string NmeSurnmePrsn { get; set; }
        public string TxtOther { get; set; }
        public string FlgService { get; set; }

        public Dsrcase CdCaseNavigation { get; set; }
        public Agency Oip { get; set; }
    }
}
