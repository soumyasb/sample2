﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class NetAllProgramCostHours
    {
        public int Id { get; set; }
        public int EstimateSetId { get; set; }
        public int? IntegrationTestTechniciansNum { get; set; }
        public int? IntegrationTestDays { get; set; }
        public int? SystemTestHrs { get; set; }
        public int? DocumentPrepHrs { get; set; }
        public int? ProjectCoordinationHrs { get; set; }
        public int? ContractorHours { get; set; }
        public string CostType { get; set; }
    }
}
