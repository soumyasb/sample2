﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Updatecodes
    {
        public string CdUpdate { get; set; }
        public string DescUpdate { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
