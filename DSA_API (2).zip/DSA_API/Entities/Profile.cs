﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Profile
    {
        public int ProfileId { get; set; }
        public int EmpId { get; set; }
        public string CdEmpId { get; set; }
        public string CdOffId { get; set; }
        public DateTime DtEffStrt { get; set; }
        public DateTime? DtEffEnd { get; set; }
        public string CdUpdtTechId { get; set; }
        public DateTime? DtUpdtTrans { get; set; }
        public string CdProfileTyp { get; set; }
        public string CdWrkWkTyp { get; set; }
        public int DayOfWkMonth { get; set; }
        public DateTime TmeWrkStrt { get; set; }
        public DateTime TmeWrkEnd { get; set; }
        public DateTime TmeAmBrkStrt { get; set; }
        public DateTime TmeAmBrkEnd { get; set; }
        public DateTime TmePmBrkStrt { get; set; }
        public DateTime TmePmBrkEnd { get; set; }
        public DateTime TmeLchBrkStrt { get; set; }
        public DateTime TmeLchBrkEnd { get; set; }
        public string FlgAlt { get; set; }
        public string FlgTelc { get; set; }
        public DateTime? TrvlTmeToStrt { get; set; }
        public DateTime? TrvlTmeToEnd { get; set; }
        public DateTime? TrvlTmeFroStrt { get; set; }
        public DateTime? TrvlTmeFroEnd { get; set; }

        public Employee Emp { get; set; }
    }
}
