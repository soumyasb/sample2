﻿using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Net;
using System.Net.Http;

namespace DSA_API.Controllers.Inquiry
{
    [Produces("application/json")]
    [Route("api/Inquiry")]
    public class InquiryController : Controller
    {

        private IConfiguration _configuration { get; }
        public InquiryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
      
        // POST api/getD26
        /// <summary>
        /// GET D26 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="d26dto"></param>
        /// <returns>JSON</returns>
        [HttpPost("getD26")]
        [Produces("text/plain")]
        //  [ValidateAntiForgeryToken]
        public IActionResult getD26([FromBody] D26DTO d26dto)
        {
            string dlNumber = d26dto.DLNumber;
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                                        
                    var response = client.GetAsync("D26inquiry/D26/001/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
        // POST api/geth6
        /// <summary>
        /// GET H6 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="h6dto"></param>
        /// <returns>JSON</returns>
        [HttpPost("geth6")]
        //  [ValidateAntiForgeryToken]
        public IActionResult geth6([FromBody] H6DTO h6dto)
        {
            string dlNumber = h6dto.DLNumber;
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("inquiry/DAD/H6/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
        // POST api/geth6
        /// <summary>
        /// GET H6 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="dlNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("geth6")]
        //  [ValidateAntiForgeryToken]
        public IActionResult geth6(string dlNumber)
        {
           
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                    // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("inquiry/DAD/H6/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
    }
}