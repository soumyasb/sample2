﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using DSA_API.Models.Customer;
using DSA_API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Newtonsoft.Json.Linq;
using DSA_API.Helpers;

namespace DSA_API.Controllers.Case
{
    [Produces("application/json")]
    [Route("api/Comment")]
    public class CommentController : Controller
    {
        private ICaseRepository _caseRepository;
        private IUrlHelper _urlHelper;
        private IConfiguration _configuration { get; }
        public CommentController(ICaseRepository caseRepository, IUrlHelper urlHelper, IConfiguration configuration)
        {
            _caseRepository = caseRepository;
            _urlHelper = urlHelper;
            _configuration = configuration;
        }
        [HttpGet("{CaseNumber}/{page?}")]
        public CaseCommentsDTO Get(string CaseNumber, int page = 1)
        {
           // var helper = new UrlHelper(Request);
            var query = _caseRepository.GetCaseComments(CaseNumber, page);
            query.baseURI = _urlHelper.RouteUrl("CommentAPI", new { page = "" });
            query.PrevPageURL = page > 1 ? _urlHelper.RouteUrl("CommentAPI", new { page = page - 1 }) : "";
            query.NextPageURL = page != query.TotalPages ? _urlHelper.RouteUrl("CommentAPI", new { page = page + 1 }) : "";
            return query;
        }


        [HttpPost("{caseNumber}")]
        public CommentDTO Post(string CaseNumber, [FromBody] CommentDTO NewComment)
        {
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;
            string employeeThreeDigit = "MPG";

            CommentDTO DTO = new CommentDTO();
            DTO.Error = false; //   Default to no errorson DTO

            //var helper = new UrlHelper(Request);
            CommentDTO DSA, DL;

            if (String.IsNullOrEmpty(NewComment.commentTextInput) || NewComment.commentTextInput.ToLower() == NewComment.placeholder.ToLower())
            {
                DTO.Error = true;
                DTO.Title = "Validation Error";
                DTO.ErrorFields.Add("commentTextInput", "Error - Comment cannot be empty");
            }

            if (!DTO.Error)
            {
                switch (NewComment.CommentType)
                {
                    case "C":
                        DSA = saveCommentDSA(CaseNumber, NewComment, employeeThreeDigit);
                        if (!DSA.Error)
                        {
                            DTO.RefreshLink = _urlHelper.RouteUrl("CommentAPI", new { page = 1 });
                            DTO.Title = DSA.Title;
                            DTO.StatusMessage = DSA.StatusMessage;
                            DTO.Error = DSA.Error;
                        }
                        break;

                    case "CD":
                        DL = saveCommentDL(CaseNumber, NewComment);
                        if (!DL.Error)
                        {
                            DSA = saveCommentDSA(CaseNumber, NewComment, employeeThreeDigit);
                            if (!DSA.Error)
                            {
                                DTO.RefreshLink = _urlHelper.RouteUrl("CommentAPI", new { page = 1 });
                                DTO.Title = DSA.Title;
                                DTO.StatusMessage = DSA.StatusMessage;
                                DTO.Error = DSA.Error;
                            }
                        }
                        else
                        {
                            return DL;
                        }
                        break;

                    case "D":
                        DL = saveCommentDL(CaseNumber, NewComment);
                        return DL;
                }
            }

            return DTO;
        }



        private CommentDTO saveCommentDSA(string CaseNumber, CommentDTO NewComment, string UserID)
        {
            CommentDTO DTO = new CommentDTO();

            if (_caseRepository.SaveNewComment(CaseNumber, NewComment.commentTextInput, UserID, NewComment.DLNumber))
            {
                DTO.Error = false;
                DTO.Title = "Database Success";
                DTO.StatusMessage = "Comment Successfully Saved!";
            }
            else
            {
                DTO.Error = true;
                DTO.Title = "Database Error";
                DTO.StatusMessage = "Unable to Save Comment, Database Error";
            }
            return DTO;
        }



        private CommentDTO saveCommentDL(string CaseNumber, CommentDTO NewComment)
        {
            CommentDTO DTO = new CommentDTO();

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";

            //  Validation
            if (String.IsNullOrEmpty(NewComment.PurgeDate))
            {
                DTO.Error = true;
                DTO.StatusMessage = "DUK Error";
                DTO.Title = "Validation Error";
                DTO.ErrorFields.Add("dlPurgeDate", "Purge Date cannot be empty");
            }

            if (String.IsNullOrEmpty(NewComment.CommentNumber))
            {
                DTO.Error = true;
                DTO.StatusMessage = "DUK Error";
                DTO.Title = "Validation Error";
                DTO.ErrorFields.Add("dlCommentNumber", "Comment Number cannot be empty");
            }

            if (!DTO.Error)
            {
                var postObj = new
                {
                    SBALASTNAME = NewComment.LastnameFirst3,
                    SBACOMMNUMBER = NewComment.CommentNumber,
                    SBAPURGEDATE1 = NewComment.PurgeDate,
                    SBACOMMENT = NewComment.commentTextInput
                };
                string outputType = "application/json";

                try
                {
                    using (var client = new HttpClient())
                    {
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                        // client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                        client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(outputType));
                        client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                        client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                        //client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                        client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                        client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                        client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                        //var response = client.PostAsJsonAsync("update/DUK/" + NewComment.DLNumber, postObj);
                        var response = HttpClientExtensions.PostAsJsonAsync(client, "update/DUK/" + NewComment.DLNumber, postObj);

                        if (response.Result.IsSuccessStatusCode)
                        {
                            JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                            DTO.Error = (bool)json["error"];
                            DTO.Title = (string)json["title"];
                            DTO.StatusMessage = (string)json["statusMessage"];
                            if (DTO.Error)
                            {
                                DTO.StatusMessage = DTO.StatusMessage + " <br />Please see <a target='_blank' href='http://dmvweb/?pg=/content/Work_Tools/DMV_Manuals/ISD_Drivers_License_Update_Manual/default.xml'>DL Update Manual</a> for assistance.";
                            }
                        }
                        else
                        {
                            JObject json = JObject.Parse(response.Result.Content.ReadAsStringAsync().Result);
                            DTO.Error = (bool)json["error"];
                            DTO.Title = (string)json["title"];
                            DTO.StatusMessage = (string)json["statusMessage"];
                        }
                    }
                }
                catch (Exception e)
                {
                    DTO.Error = true;
                    DTO.StatusMessage = "Unable to connect to MQ Service at this time - " + e.ToString();
                }
            }

            return DTO;
        }
    }
}