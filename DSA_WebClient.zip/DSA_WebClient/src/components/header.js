import React, {Component} from "react";
import { NavLink } from "react-router-dom";
import { Col, Row, Menu, Icon, Spin, Select, Form, Dropdown, Input, Modal, Button } from "antd";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
// import MenuItem from "antd/lib/menu/MenuItem";
import { initHomePage } from "../store/actions/homePageActions";
import { getCalendarEmployees, getCalendarEmployeesCalendars, getCalendarOffices, getOfficeCalendar, getHearingRooms, getHearingRoomCalendar } from "../store/actions/calendarActions";
import { searchCases } from "../store/actions/caseActions";
import { bindActionCreators } from "redux";
import DayPicker, { DateUtils } from 'react-day-picker';
import 'react-day-picker/lib/style.css';
import '../header.css';
const { Option } = Select; 
const  FormItem  = Form.Item;
const Search = Input.Search;

class header extends Component {
  constructor(props) {
    super(props);

    this.state={
      onCustomerPage: props.ui.onCustomerPage,
      DLNumber: "",
      keypress: false,
    selectedEmployees: [],
      caseMenuFirst: 0
    };
    this.keypress = this.keypress.bind(this);
    this.handleDayClick = this.handleDayClick.bind(this);
    this.handleChange = this.handleChange.bind(this);
}    
  componentDidMount() {
    this.props.initHomePage();
   document.getElementById('Home1').focus();
  }
    static getDerivedStateFromProps(props, prevState) {
      if(props.ui && props.ui.onCustomerPage !== prevState.onCustomerPage)
      {
        return {onCustomerPage: props.ui.onCustomerPage, caseMenuFirst: 1}
      }
if(props.homePage && props.homePage !== prevState.homePage)
{
  sessionStorage.setItem('userInfo', JSON.stringify(props.homePage)); 
  return {homePage: props.homePage}
}
if ( props.calendar.employeesCalendarsData !== prevState.employeesCalendarsData && props.calendar.employeesCalendarsData !== undefined) {
 props.history.push({ pathname: `/employeeCalendarSchedule/`, state: { officeId: prevState.OfficeId, selectedEmployeeDetails: prevState.selectedEmployeeDetails, selectedDays: prevState.selectedDays, employeesCalendarsData: props.calendar.employeesCalendarsData }});
  return{employeesCalendarsData: props.calendar.employeesCalendarsData, isLoading: false, openModal: false}
}
if ( props.calendar.officeCalendarsData !== prevState.officeCalendarsData && props.calendar.officeCalendarsData !== undefined) {
  props.history.push({ pathname: `/officeCalendar/`, state: { officeId: prevState.selectedOffice, selectedOfficeDetails: prevState.selectedOfficeDetails, selectedDays: prevState.selectedDate, officeCalendarsData: props.calendar.officeCalendarsData }});
   return{officeCalendarsData: props.calendar.officeCalendarsData, isLoading: false, openModal: false}
 }
 if ( props.calendar.hearingRoomCalendarData !== prevState.hearingRoomCalendarData && props.calendar.hearingRoomCalendarData !== undefined) {
  props.history.push({ pathname: `/hearingRoomCalendar/`, state: { hearingRoomId: prevState.selectedHR, selectedHRDetails: prevState.selectedHRDetails, selectedDays: prevState.selectedDate, hrCalendarsData: props.calendar.hearingRoomCalendarData }});
   return{hearingRoomCalendarData: props.calendar.hearingRoomCalendarData, isLoading: false, openModal: false}
 }
if(props.calendar && props.calendar.calendarEmployeesList !== prevState.calendarEmployeesList)
{ 
  return {calendarEmployeesList: props.calendar.calendarEmployeesList}
}
if(props.calendar && props.calendar.calendarOfficesList !== prevState.calendarOfficesList)
{ 
  return {calendarOfficesList: props.calendar.calendarOfficesList}
}
if(props.calendar && props.calendar.hearingRoomsList !== prevState.hearingRoomsList)
{ 
  return {hearingRoomsList: props.calendar.hearingRoomsList}
}
return "";
    }

    keypress(event, elementName, length, key)
    {    
      let {selectedKeys} = this.state;
      if (event.keyCode === 13)                     
                      {
                        document.getElementById(elementName).click();
                      }
                     if(event.keyCode === 9)
                     {
                      selectedKeys = undefined;
                      if( document.getElementById(elementName+"DD") && document.getElementById(elementName+"DD").offsetWidth > 0 && document.getElementById(elementName+"DD").offsetHeight > 0){
                           
                         document.getElementById(elementName).click();}
                   }
                       if (event.keyCode === 40)
                       {
                         if(selectedKeys === undefined)
                         {
                          selectedKeys = ["1"];
                         }
                         else
                         {
                          if((parseInt(selectedKeys[0],0)+1) > length)
                          {
                            selectedKeys = ["1"];
                          }
                          else
                          {
                            selectedKeys = [(parseInt(selectedKeys[0],0)+1).toString()];
                          }
                         }
                         document.getElementById(elementName+selectedKeys[0]).focus();
                       }
                       if (event.keyCode === 38)
                       {
                        if(selectedKeys === undefined)
                        {
                         selectedKeys = ["1"];
                        }
                        else
                        {
                        if((parseInt(selectedKeys[0],0)-1) < 1)
                        {
                           selectedKeys = [length.toString()];
                        }
                        else
                        {
                          selectedKeys = [(parseInt(selectedKeys[0],0)-1).toString()];
                        }
                      }
                      document.getElementById(elementName+selectedKeys[0]).focus();
                       }
                       
                       
                                              this.setState({selectedKeys: selectedKeys});
    }
    handleChange = (value) => {
    if(this.state.modalTitle === "Select Employee(s) & Date(s)") 
    {
      let { selectedEmployees } = this.state;
      selectedEmployees = value;
      var selectedEmployeeDetails = [];
      value.map(v => this.state.calendarEmployeesList.map((item) => {
        
        if(item.Value === v){selectedEmployeeDetails.push(item);
        return "";
      }
      return "";
      }
      ));
      this.setState({ selectedEmployees: selectedEmployees, selectedEmployeeDetails: selectedEmployeeDetails });    
    } 
    else if(this.state.modalTitle === "Select Office & Date")
    {
      let { selectedOffice } = this.state;
      selectedOffice = value;
      this.setState({ selectedOffice, selectedOfficeDetails: this.state.calendarOfficesList.map((item) => 
        {
          if(item.Value === value){
            return item;
          }
          return "";
        }) });    
    }
    else
    {
      let { selectedHR, selectedHRDetails } = this.state;
      selectedHR = value;
      this.state.hearingRoomsList.map((item) => 
      {
        if(item.Room === value.split(' - ')[0] && item.OfficeAbreviation === value.split(' - ')[1]){
          selectedHRDetails = item;
        }
        return "";
      });
      this.setState({ selectedHR, selectedHRDetails });    
    }
  
  }
  handleSearch(searchText) {
    if (searchText) {
    this.props.history.push(
      { pathname: `/search/searchText/${searchText}`});
   }
  }
  handleDayClick(day, { selected }) {
    const { selectedDays } = this.state;
    if(this.state.modalTitle=== "Select Employee(s) & Date(s)"){
      if (selected) {
        const selectedIndex = selectedDays.findIndex(selectedDay =>
          DateUtils.isSameDay(selectedDay, day)
        );
        selectedDays.splice(selectedIndex, 1);
      } else {
        selectedDays.push(day);
      }
      this.setState({ selectedDays });
    } 
    else
    {
      this.setState({
        selectedDays: selected ? undefined : day,
      });
    }
  }
  render() {
    let userInfo = "";
    if(sessionStorage.getItem('userInfo')){
     userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
    }
const userMenu = (
  <Menu id="UserMenuDD" overflowedIndicator={false} selectedKeys={this.state.selectedKeys} 
  tabIndex="-1">
    <Menu.Item key="1"><NavLink id='UserMenu1' to={{ }} className='nav-text'>DS Training</NavLink></Menu.Item>
    <Menu.Item key="2"><NavLink id='UserMenu2' to={{ }} className='nav-text'>Lorem</NavLink></Menu.Item>
    <Menu.Divider />
    <Menu.Item key="3"><NavLink id='UserMenu3' to={{ }} className='nav-text'>LogOut</NavLink></Menu.Item>
  </Menu>
);

const caseMenu = (
  <Menu role="menu" id="CaseMenuDD" selectedKeys={this.state.selectedKeys}
    tabIndex="-1">
    { this.state.onCustomerPage &&
    <Menu.Item role="menuitem" key={(this.state.caseMenuFirst).toString()} tabIndex="-1" ><NavLink id={'CaseMenu'+(this.state.caseMenuFirst).toString()} to="/newcase"className='nav-text'> 
    New Case
                  </NavLink></Menu.Item>
    }

    <Menu.Item role="menuitem" key={(this.state.caseMenuFirst+1).toString()} tabIndex="-1" >  <NavLink id={'CaseMenu'+(this.state.caseMenuFirst+1).toString()} to="/ScheduledCases" className='nav-text'> 
                   Scheduled Cases 
                  </NavLink> </Menu.Item>

    <Menu.Item role="menuitem" key={(this.state.caseMenuFirst+2).toString()} tabIndex="-1" ><NavLink id={'CaseMenu'+(this.state.caseMenuFirst+2).toString()} to="/UnScheduledCases" className='nav-text'> 
                     Unscheduled Cases 
                   </NavLink> 
</Menu.Item>
  </Menu>
);

const inquiryMenu = (
  <Menu id="InquiryMenuDD" selectedKeys={this.state.selectedKeys} 
   tabIndex="-1">
    <Menu.Item key="1"><NavLink id='InquiryMenu1' to="/dlInquiries" className='nav-text'>DL Inquiries </NavLink></Menu.Item>
    <Menu.Item key="2"><NavLink id='InquiryMenu2' to={{ pathname: `/dlUpdates`, query: {
  comments: JSON.stringify("new")
} }} className='nav-text'>DL Updates</NavLink></Menu.Item>
    <Menu.Item key="3"><NavLink id='InquiryMenu3' to={{ }} className='nav-text'>Batch DL Print</NavLink></Menu.Item>
    <Menu.Item key="4"><NavLink id='InquiryMenu4' to={{ }} className='nav-text'>Option 8</NavLink></Menu.Item>
  </Menu>
);

const profileMenu = (
  <Menu id="ProfileMenuDD" selectedKeys={this.state.selectedKeys}
    tabIndex="-1">
     <Menu.Item key="1">
     <NavLink id='ProfileMenu1' to="/EmployeeProfiles" className="nav-text">
     Employee Profiles
      </NavLink></Menu.Item>
      <Menu.Item key="2"> 
             <NavLink id='ProfileMenu2' to="/HearingRoomProfiles" className="nav-text"> 
              Hearing Room Profiles 
              </NavLink></Menu.Item> 
              <Menu.Item key="3"> 
             <NavLink id='ProfileMenu3' to="/EmployeeTimeOff" className="nav-text"> 
              Employee Time-Off 
              </NavLink></Menu.Item> 
              <Menu.Item key="4"> 
             <NavLink id='ProfileMenu4' to="/HearingRoomUnavailability" className="nav-text"> 
              Hearing Room Unavailability 
              </NavLink></Menu.Item> 
      
  </Menu>
);

const OSMenu = (
  <Menu id="OfficeSchedulesDD" selectedKeys={this.state.selectedKeys} 
   tabIndex="-1">
     <Menu.Item key="1" id='OfficeSchedules1' onClick={(e) => {this.props.getHearingRooms();
                this.setState({openModal: true, selectedDays: null, selectedHR: "", modalTitle: 'Select Hearing Room & Date'})}}>
     Hearing Room Calendar
      </Menu.Item>
      <Menu.Item key="2" id='OfficeSchedules2' onClick={(e) => {this.props.getCalendarOffices();
                this.setState({openModal: true, selectedDays: null, selectedOffice: "", modalTitle: 'Select Office & Date'})}}> 
              Office Calendar
              </Menu.Item>  
              <Menu.Item key="3" id='OfficeSchedules3' onClick={(e) => {this.props.getCalendarEmployees();
                this.setState({openModal: true, selectedDays: [], selectedEmployees: [], modalTitle: 'Select Employee(s) & Date(s)'})}}> 
              Select Employee Schedule 
            </Menu.Item> 
  </Menu>
);

const adminMenu = (
  <Menu id="AdminMenuDD" selectedKeys={this.state.selectedKeys} 
 // onFocus={(e) =>  document.getElementById('AdminMenu').click()}
   tabIndex="-1"> 
   {(userInfo.EmpType === "R" || userInfo.EmpType === "D" || userInfo.EmpType === "O") && <Menu.Item key="1"> 
      <NavLink id='AdminMenu1' to="/News" className="nav-text">
      News Items
      </NavLink>
</Menu.Item>} 
    <Menu.Item key="2" >
    <NavLink id='AdminMenu2' to="/DataManager" className="nav-text"> 
    Data Manager
              </NavLink></Menu.Item>
    <Menu.Item key="3"><NavLink id='AdminMenu3' to={{ }} className="nav-text">Admin Tools</NavLink></Menu.Item>
  </Menu>
);

const extAppsMenu = (
  <Menu id="ExtAppsMenuDD" selectedKeys={this.state.selectedKeys} 
  //onFocus={(e) =>  document.getElementById('ExitAppsMenu').click()} 
  tabIndex="-1">
    <Menu.Item key="16"><NavLink id='ExtAppsMenu1' to={{ }} className="nav-text">FOD Appointments</NavLink></Menu.Item>
    <Menu.Item key="17"><NavLink id='ExtAppsMenu2' to={{ }} className="nav-text">QuickWeb</NavLink></Menu.Item>
  </Menu>
);

  return (
  <div className="headerlayout" >
     {/* <Menu
            //  onClick={this.handleClick}
              defaultSelectedKeys={["2"]}
             // selectedKeys={this.state.mainHeaderSelectedKeys}
              mode="horizontal"
              //overflowedIndicator={true}
            // overflowedIndicator={false}
            //  onKeyDown={(e) => {this.keypress(e, 'MainHeader')}}
            >  */}
              <Row style={{backgroundColor: "whitesmoke"}} gutter={16}>
                 {/* <Menu.Item key="1" tabIndex="-1">             */}
                 <Col style={{height: "50px", width: "225px", paddingTop: "5px"}} span={4} tabIndex="-1">
   <h1 >DRIVER SAFETY</h1>
   </Col>
      {/* </Menu.Item> */}
             {/* <Menu.Item id="Home1" key="2" autoFocus={true} tabIndex={0} >  */}
           <Row gutter={16} style={{height: "50px", marginLeft: "225px"}}> <Col onClick={(e) =>{ document.getElementById("Home").click() ;}} style={{height: "50px", width: "100px", paddingTop: "20px"}} span={4} id="Home1" autoFocus tabIndex={0}>
              <NavLink style={{color: "black"}} tabIndex={-1} to="/" className="nav-text">
              <b id="Home">Home</b>
              </NavLink>
              </Col>
               {/* </Menu.Item>        */}
               <Col id= "CaseMenu1" onClick={(e) => { this.state.keypress === false ? (document.getElementById("CaseMenu") && document.getElementById("CaseMenu").click()) : this.setState({keypress: false})}} style={{height: "50px", width: "100px", paddingTop: "20px"}} span={4} tabIndex={0}  onKeyDown ={(event) => { event.stopPropagation(); let length = 2; if(this.state.onCustomerPage){length = 3} 
                this.keypress(event, 'CaseMenu', length);
                this.setState({keypress: true});
                       }
                      }>
               {/* <Menu.Item key="3"  tabIndex={0} 
               onKeyDown ={(event) => { event.stopPropagation(); let length = 2; if(this.state.onCustomerPage){length = 3} 
                this.keypress(event, 'CaseMenu', length);
                       }
                      }
                      // onBlur={(e) =>  {
                      //   //if(document.getElementById("CaseMenu2")){
                 
                      // }
                      //}
                       >  */}
               <Dropdown overlay={caseMenu} trigger={["click"]}>      
                <a style={{color: "black"}} className="ant-dropdown-link">
                <b id="CaseMenu">Cases</b> <Icon type="down" />
                </a>
              </Dropdown>     
              </Col>       
               {/* </Menu.Item> */}
               <Col id="InqAndUpd1" onClick={(e) => { this.state.keypress === false ? (document.getElementById("InquiryMenu") && document.getElementById("InquiryMenu").click()) : this.setState({keypress: false})}} style={{height: "50px", width: "200px", paddingTop: "20px"}} span={4} tabIndex={0}
                onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'InquiryMenu', 4);   this.setState({keypress: true});
                       }
                      } >
               {/* <Menu.Item key="4" tabIndex={0}
                onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'InquiryMenu', 4);
                       }
                      } 
                       >  */}
               <Dropdown overlay={inquiryMenu} trigger={["click"]}>      
                <a style={{color: "black"}} className="ant-dropdown-link">
                <b id="InquiryMenu">Inquiry and Updates</b> <Icon type="down" />
                </a>
              </Dropdown>   
              {/* </Menu.Item> */}</Col>
              <Col id="OffSched1" onClick={(e) => { this.state.keypress === false ? (document.getElementById("OfficeSchedules") && document.getElementById("OfficeSchedules").click()) : this.setState({keypress: false})}} style={{height: "50px", width: "200px", paddingTop: "20px"}} span={4} tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();     this.keypress(event, 'OfficeSchedules', 3);   this.setState({keypress: true});
                       }
                      }>
              {/* <Menu.Item key="5" tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();     this.keypress(event, 'OfficeSchedules', 3);
                       }
                      } > */}
                      <Dropdown overlay={OSMenu} trigger={["click"]}>      
                <a style={{color: "black"}} className="ant-dropdown-link"><b id="OfficeSchedules">Office Schedules</b><Icon type="down" />
                </a>
              </Dropdown>
              {/* </Menu.Item> */}
              </Col >
              {/* <Menu.Item key="6" tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'ProfileMenu', 4);
                       }
                      } >  */}
            <Col id="Profiles1" style={{height: "50px", width: "150px", paddingTop: "20px"}} onClick={(e) => { this.state.keypress === false ? (document.getElementById("ProfileMenu") && document.getElementById("ProfileMenu").click()) : this.setState({keypress: false})}} span={4} tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'ProfileMenu', 4); this.setState({keypress: true});
                       }
                      }>  <Dropdown overlay={profileMenu} trigger={["click"]}>      
                <a style={{color: "black"}} className="ant-dropdown-link">
                <b id="ProfileMenu"> Profiles</b> <Icon type="down" />
                </a>
              </Dropdown>   
              {/* </Menu.Item> */}
              </Col>
             <Col id="Admin1" style={{height: "50px", width: "150px", paddingTop: "20px"}} onClick={(e) => { this.state.keypress === false ? (document.getElementById("AdminMenu") && document.getElementById("AdminMenu").click()) : this.setState({keypress: false})}} span={4}  tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'AdminMenu', 3); this.setState({keypress: true});
                       }
                      }> {/* <Menu.Item key="7" tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'AdminMenu', 3);
                       }
                      } >  */}
              <Dropdown overlay={adminMenu} trigger={["click"]}>      
              <a style={{color: "black"}} className="ant-dropdown-link">
              <b id="AdminMenu">Admin</b> <Icon type="down" />
              </a>
            </Dropdown>   
              {/* </Menu.Item> */}
              </Col>
          <Col  id="ExtApps1" style={{height: "50px", width: "150px", paddingTop: "20px"}} span={4} tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'ExtAppsMenu', 2);
                       }
                       }> {/* <Menu.Item key="8" tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'ExtAppsMenu', 2);
                       }
                       } >  */}
              <Dropdown overlay={extAppsMenu} trigger={["click"]}>      
              <a style={{color: "black"}} className="ant-dropdown-link">
              <b id="ExtAppsMenu">External Apps</b> <Icon type="down" />
              </a>
            </Dropdown>   
              {/* </Menu.Item> */}
              </Col>
             <Col id="About1" style={{height: "50px", width: "150px", paddingTop: "20px"}} span={4} tabIndex={0}>
              {/* <Menu.Item key="9" tabIndex={0}> */}
              <b style={{color: "black"}}>About</b>
              {/* </Menu.Item> */}
              </Col>
               {/* <Menu.Item key="i1"><b></b></Menu.Item>
              // <Menu.Item key="i2"><b></b></Menu.Item>
              // <Menu.Item key="i3"><b></b></Menu.Item> */}

              <Col id="SearchDL1" style={{height: "50px", width: "250px", paddingTop: "15px"}}  span={4} tabIndex={-1}>
{/* <Menu.Item style= {{paddingLeft: "12%"}} key="10" tabIndex={-1}> */}
      <Search  tabIndex={0}
          placeholder="Search Case..."
          onSearch={value => { this.handleSearch(value); }}
          enterButton
        />
{/* </Menu.Item> */}
</Col>
<Col id="Accnt1" style={{height: "50px", width: "150px", paddingTop: "20px"}} span={4} tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'UserMenu', 3);
                       }
                      } >
                      {/* <MenuItem key = "11" tabIndex={0} onKeyDown ={(event) => { event.stopPropagation();             this.keypress(event, 'UserMenu', 3);
                       }
                      } > */}
        <Dropdown overlay={userMenu} trigger={["click"]}>
       
          <a style={{color: "black"}} className="ant-dropdown-link">
            <Icon type="user" /> <b id="UserMenu">{userInfo.LoginId}</b> <Icon type="down" />
          </a>
        </Dropdown>
{/* </MenuItem> */}
</Col>
    {/* </Menu> */}</Row> 
    </Row> 
    <Modal visible={this.state.openModal}
title={this.state.modalTitle} maskClosable={false}
onCancel={(e) => {this.setState({openModal: false})}}
footer={[
<div key={`${Math.random()}`}>
<Button type="primary" key="Ok" onClick={(e) => 
{
 if(this.state.modalTitle === "Select Employee(s) & Date(s)")
 {
  var SE, SD = "";
  if(this.state.selectedEmployees.length === 0 || this.state.selectedDays.length === 0)
  {
  if(this.state.selectedEmployees.length === 0 )
  { 
SE = "Please select employee(s)!";
  }
  if(this.state.selectedDays.length === 0 )
  {
   SD = "Please select date(s)!";
  }
  this.setState({ ErrorObj: {SelectedEmployees: SE, SelectedDays: SD} });
}
  else { 
    this.props.getCalendarEmployeesCalendars(userInfo.OfficeId, this.state.selectedEmployees, this.state.selectedDays);
this.setState({ OfficeId: userInfo.OfficeId, isLoading: true});
  }
 }
 else if(this.state.modalTitle === "Select Office & Date")
 {
  var SO = "";
  if(this.state.selectedOffice === "" || !this.state.selectedDays)
  {
    if(this.state.selectedOffice === "")
    {
      SO = "Please select an office!";
    }
    if(!this.state.selectedDays)
  {
   SD = "Please select a date!";
  }
  this.setState({ ErrorObj: {SelectedOffice: SO, SelectedDays: SD} });
 }
 else
 {
  this.props.getOfficeCalendar(this.state.selectedOffice, this.state.selectedDays);
  this.setState({ isLoading: true});
 }
}
else
{
  var SH = "";
  if(this.state.selectedHR === "" || !this.state.selectedDays)
  {
    if(this.state.selectedHR === "")
    {
      SH = "Please select a Hearing Room!";
    }
    if(!this.state.selectedDays)
  {
   SD = "Please select a date!";
  }
  this.setState({ ErrorObj: {SelectedHR: SH, SelectedDays: SD} });
 }
 else
 {
  this.props.getHearingRoomCalendar(this.state.selectedHR.split(" - ")[1].replace(" ",""), this.state.selectedHR.split(" - ")[0].replace(" ",""), userInfo.OfficeId, this.state.selectedDays);
  this.setState({ isLoading: true});
 }
}
}}>OK</Button>
</div>
]}
>
{this.state.isLoading ? <React.Fragment><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading Data...</font></span></React.Fragment>:
this.state.modalTitle === 'Select Employee(s) & Date(s)' ? <Form>
  <FormItem
                     validateStatus = {this.state.selectedEmployees.length === 0 && this.state.ErrorObj && this.state.ErrorObj["SelectedEmployees"] !== "" ? 'error' : ""}
                     help = {this.state.selectedEmployees.length === 0 && this.state.ErrorObj && this.state.ErrorObj["SelectedEmployees"] !== "" ? this.state.ErrorObj["SelectedEmployees"] : ""}
                         label={<b>Select Employee(s):  <font color="red">*</font></b>}
                ><Select   id = "SelEmp" onFocus={(e) => {
                  document.getElementById("SelEmp").click();
                                                         }} showSearch optionFilterProp= "children" filterOption = {true}
     mode="multiple"   
     style={{ width: '100%' }}   
     placeholder="Please select"   
     value={this.state.selectedEmployees}   
     onChange={this.handleChange}   
   >   
    {this.state.calendarEmployeesList && this.state.calendarEmployeesList.map(emp => <Option key={emp.Value} value={emp.Value}>{emp.Value} - {emp.Text}</Option>)} 
   </Select> </FormItem>  <FormItem
                         label={<b>Select Day(s)  <font color="red">*</font></b>}
                >
<div style={this.state.selectedDays.length === 0 && this.state.ErrorObj && this.state.ErrorObj["SelectedDays"] !== "" ? {border:"1px solid red"} : {border:"1px solid black"}}><DayPicker
          selectedDays={this.state.selectedDays}
          onDayClick={this.handleDayClick}
/></div>
{this.state.selectedDays.length === 0 && this.state.ErrorObj && this.state.ErrorObj["SelectedDays"] !== "" && <font color="red">{this.state.ErrorObj["SelectedDays"]}</font>}
</FormItem></Form> : this.state.modalTitle === 'Select Office & Date' ? <Form><FormItem
                     validateStatus = {this.state.selectedOffice === "" && this.state.ErrorObj && this.state.ErrorObj["SelectedOffice"] !== "" ? 'error' : ""}
                     help = {this.state.selectedOffice === "" && this.state.ErrorObj && this.state.ErrorObj["SelectedOffice"] !== "" ? this.state.ErrorObj["SelectedOffice"] : ""}
                         label={<b>Select Office:  <font color="red">*</font></b>}
                ><Select    id = "SelOff" onFocus={(e) => {
                  document.getElementById("SelOff").click();
                                                         }} showSearch optionFilterProp= "children" filterOption = {true}
     style={{ width: '100%' }}   
     placeholder="Please select"   
     value={this.state.selectedOffice}   
     onChange={this.handleChange}   
   >   
    {this.state.calendarOfficesList && this.state.calendarOfficesList.map(off => <Option key={off.Value} value={off.Value}>{off.Text}</Option>)} 
   </Select> </FormItem><FormItem
                         label={<b>Select Day  <font color="red">*</font></b>}
                >
<div style={!this.state.selectedDays && this.state.ErrorObj && this.state.ErrorObj["SelectedDays"] !== "" ? {border:"1px solid red"} : {border:"1px solid black"}}><DayPicker
          selectedDays={this.state.selectedDays}
          onDayClick={this.handleDayClick}
/></div>
{!this.state.selectedDays && this.state.ErrorObj && this.state.ErrorObj["SelectedDays"] !== "" && <font color="red">{this.state.ErrorObj["SelectedDays"]}</font>}
</FormItem></Form>: <Form><FormItem
                     validateStatus = {this.state.selectedHR=== "" && this.state.ErrorObj && this.state.ErrorObj["SelectedHR"] !== "" ? 'error' : ""}
                     help = {this.state.selectedHR === "" && this.state.ErrorObj && this.state.ErrorObj["SelectedHR"] !== "" ? this.state.ErrorObj["SelectedHR"] : ""}
                         label={<b>Select Hearing Room:  <font color="red">*</font></b>}
                ><Select  id = "SelHR" onFocus={(e) => {
                  document.getElementById("SelHR").click();
                                                         }} showSearch optionFilterProp= "children" filterOption = {true}   
     style={{ width: '100%' }}   
     placeholder="Please select"   
     value={this.state.selectedHR}   
     onChange={this.handleChange}   
   >   
    {this.state.hearingRoomsList && this.state.hearingRoomsList.map(hr => <Option key={`${hr.Room} - ${hr.OfficeAbreviation}`} value={`${hr.Room} - ${hr.OfficeAbreviation}`}>{hr.Room} - {hr.OfficeAbreviation}</Option>)} 
   </Select> </FormItem><FormItem
                         label={<b>Select Day  <font color="red">*</font></b>}
                >
<div style={!this.state.selectedDays && this.state.ErrorObj && this.state.ErrorObj["SelectedDays"] !== "" ? {border:"1px solid red"} : {border:"1px solid black"}}><DayPicker
          selectedDays={this.state.selectedDays}
          onDayClick={this.handleDayClick}
/></div>
{!this.state.selectedDays && this.state.ErrorObj && this.state.ErrorObj["SelectedDays"] !== "" && <font color="red">{this.state.ErrorObj["SelectedDays"]}</font>}
</FormItem></Form>}
</Modal>
   {/* <Drawer
          title="Enter a DL Number for DAP/DAS Update:"
          placement="top"
          //style={{paddingLeft: "40%"}}
          //closable={false}
          maskClosable={false}
          onClose={this.onClose}
          visible={this.state.openDLModel}
        >
          <Input placeholder="Enter DL Number" value={this.state.DLNumber} onChange={(e) => {
            const value = e.target.value;
            this.setState({DLNumber: value})}}/>
          <div><Button type="Primary" onClick={(e) =>  this.props.history.push(`/dapUpdate/DLNumber/${this.state.DLNumber}`)} >OK</Button>
          <Button type="Default">Cancel</Button></div>
        </Drawer> */}
  </div>
);
  }
}
const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      initHomePage,
      searchCases,
      getCalendarEmployees,
      getCalendarEmployeesCalendars,
      getCalendarOffices,
      getOfficeCalendar,
      getHearingRooms,
      getHearingRoomCalendar
    },
    dispatch
  );
};
const mapStateToProps = state => {
  return {
    homePage: state.homePage,
    cases: state.cases,
    ui: state.ui,
    calendar: state.calendar
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(header));
