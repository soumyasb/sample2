import React from "react";

import MdCopyright from "react-icons/lib/md/copyright";

const footer = () => (
  <div className="footerlayout">
    <p style={{ textAlign: "center" }}>
      copyright <MdCopyright /> DMV 2018
    </p>
  </div>
);

export default footer;
