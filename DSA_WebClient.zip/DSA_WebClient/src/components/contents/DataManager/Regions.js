import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import { getFormattedDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import { Form, Input, notification } from 'antd';
import { 
    getRegions, getEditRegion, initCreateRegionObj, initDeleteRegionObj, deleteConfirmedRegion, updateRegion, createRegion } from "../../../store/actions/dataManagerActions";
    import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';
    
    const FormItem = Form.Item;
    
    const formItemLayout = {
        labelCol: { span: 9 },
        wrapperCol: { span: 15 },
    };
    const defaultObj = {
        RegionID: "",
        DistrictID: "",
        RegionName: "",
        EndDate: "",
        Districts: null,
        DistrictName: "",
        Message: null
    }

class Regions extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: this.props.allRegionsList,
            errorObj: {},
            showModal: false,
            EndDate: null,
            obj: {},
        };

        this.columns = [
            {
                title: <b>District ID</b>,
                dataIndex: 'DistrictID',
                key: 'DistrictID',
                render: (c, obj) =>
                <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                    style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                    {c}
                </a>
            },
            {
                title: <b>Region ID</b>,
                dataIndex: 'RegionID',
                key: 'RegionID'              
            },
            {
                title: <b>Region Name</b>,
                dataIndex: 'RegionName',
                key: 'RegionName'
            },
            {
                title: <b>End Effective Date</b>,
                dataIndex: 'EndDate',
                key: 'EndDate',
                render: (item) =>
                {
                 return getFormattedDate(item);
                }
            },
            {
                title: <b>District Name</b>,
                dataIndex: 'DistrictName',
                key: 'DistrictName'
            },
        ];

        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.handleFieldChange =  this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }



    componentDidMount(){
        
        this.props.getRegions();
                }
                componentDidUpdate(prevProps){
                    
                            if ( prevProps.dataManager.allRegionsList !== this.props.dataManager.allRegionsList && this.props.dataManager.allRegionsList !== undefined) {
                                 this.setState({data: this.props.dataManager.allRegionsList});
                            }
                            if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                 this.setState({errorObj: this.props.dataManager.DMErrorData});
                            }
                            if ( prevProps.dataManager.createRegionData !== this.props.dataManager.createRegionData ) {
                                 this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                 this.props.getRegions();
                                 this.openNotification("Region created successfully!");                              
                        }
                        if ( prevProps.dataManager.dleteConfirmedRegionData !== this.props.dataManager.dleteConfirmedRegionData ) {
                                this.setState({showDeleteModal: false});
                                this.props.getRegions();
                                this.openNotification("Region deleted successfully!");                              
                    }
                            if ( prevProps.dataManager.updateRegionData !== this.props.dataManager.updateRegionData ) {
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.props.getRegions();
                                this.openNotification("Region updated successfully!");                              
                    }                           
                        }

    static getDerivedStateFromProps(props, prevState) {
        const { allRegionsList, DMErrorData } = props.dataManager;
        if (allRegionsList && allRegionsList !== prevState.data) return { data: allRegionsList };
        if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
        return null;
    }

    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    handleFieldChange(e, field) {
        const { obj } = this.state;

        switch (field) {
            case 'RegionID':
            case 'DistrictID':
            case 'RegionName':
            case 'DistrictName':
            case 'Message':
                obj[field] = e.target.value;
                break;
            default:
                break
        }

        this.setState({ obj });
    }

    onDateChange(d, type) {
        const { obj } = this.state;
        obj[type] = d || '';

        this.setState({ obj });
    }
    handleShowModal(e, actype, obj) {
        if (actype !== DM_ADD_ACTION_TYPE) {
            if (obj) {
                const modalObj = cloneDeep(this.state.data[this.state.data.findIndex(d => d.DistrictID === obj.DistrictID && d.RegionID === obj.RegionID)]);
                this.setState({ obj: modalObj });
                if (actype === DM_EDIT_ACTION_TYPE) {

                }
                if (actype === DM_DETAILS_ACTION_TYPE) {

                }
                if (actype === DM_DELETE_ACTION_TYPE) {
                    this.setState({deleteObjId: modalObj.DistrictID+" District from "+modalObj.RegionID+" Region"});
                }
            }
        }
        else {
            this.setState({ obj: cloneDeep(defaultObj) });
        }

        this.setState({
            actionType: actype,
            showModal: actype !== DM_DELETE_ACTION_TYPE,
            showDeleteModal: actype === DM_DELETE_ACTION_TYPE
        });
    }

    handleCancel() {
        this.setState({ showModal: false, showDeleteModal: false });
    }

    handleOk(actionType) {
        switch (actionType) {
            case DM_ADD_ACTION_TYPE:
                this.props.createRegion(this.state.obj);
                break;
            case DM_EDIT_ACTION_TYPE:
            this.props.updateRegion(this.state.obj);
                break;
            case DM_DELETE_ACTION_TYPE:
            this.props.deleteConfirmedRegion(this.state.obj.RegionID, this.state.obj.DistrictID);
                break;
            default: break;
        }
    }

    renderModalFields() {
        const { actionType, obj } = this.state;
        const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;
        return (
            <Form layout={'horizontal'}>
                <FormItem
                      validateStatus = {obj.RegionID === "" && this.state.errorObj["RegionID"] ? 'error' : ""}
                      help = {obj.RegionID === "" && this.state.errorObj["RegionID"]}
                          label={<b>Region ID <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.RegionID} placeholder="RegionID" onChange={e => this.handleFieldChange(e, 'RegionID')} />
                        :
                        <div>{obj.RegionID}</div>
                    }
                </FormItem>
                <FormItem
                     validateStatus = {obj.DistrictID === "" && this.state.errorObj["DistrictID"] ? 'error' : ""}
                     help = {obj.DistrictID === "" && this.state.errorObj["DistrictID"]}
                         label={<b>District ID <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.DistrictID} placeholder="DistrictID" onChange={e => this.handleFieldChange(e, 'DistrictID')} />
                        :
                        <div>{obj.DistrictID}</div>
                    }
                </FormItem>
                <FormItem
                     validateStatus = {obj.RegionName === "" && this.state.errorObj["RegionName"] ? 'error' : ""}
                     help = {obj.RegionName === "" && this.state.errorObj["RegionName"]}
                         label={<b>Region Name <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.RegionName} placeholder="RegionName" onChange={e => this.handleFieldChange(e, 'RegionName')} />
                        :
                        <div>{obj.RegionName}</div>
                    }
                </FormItem>
                <FormItem
                    validateStatus = {obj.EndDate === "" && this.state.errorObj["EndDate"] ? 'error' : ""}
                    help = {obj.EndDate === "" && this.state.errorObj["EndDate"]}
                        label={<b>End Effective Date </b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                       <DatePicker
                       className = "CalClass"
                       selected={obj.EndDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EndDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                       :
                    <div>{getFormattedDate(obj.EndDate)}</div>
                    }
                </FormItem>
                <FormItem
                     validateStatus = {obj.DistrictName === "" && this.state.errorObj["DistrictName"] ? 'error' : ""}
                     help = {obj.DistrictName === "" && this.state.errorObj["DistrictName"]}
                         label={<b>District Name </b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.DistrictName} placeholder="District Name" onChange={e => this.handleFieldChange(e, 'DistrictName')} />
                        :
                        <div>{obj.DistrictName}</div>
                    }
                </FormItem>
            </Form>
        );
    }

    render() {
        const { title, footer } =
            getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Region');
            return (
                <div>
                   {this.state.data && <DMTable title={<b>Regions Maintenance</b>}
                        tableData={this.state.data}
                        columns={this.columns}
                        handleShowModal={this.handleShowModal}
                        deleteObjId={this.state.deleteObjId}
                        uniqueColumnName='DistrictID'
                        searchField={['DistrictName', 'RegionName']}
                        showModal={this.state.showModal}
                        showDeleteModal={this.state.showDeleteModal}
                        handleOk={this.handleOk}
                        handleCancel={this.handleCancel}
                        modalTitle={title}
                        footer={footer}
                        width={'600px'}
                        renderModalFields={this.renderModalFields}                       
                    >
                    </DMTable>}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getRegions, getEditRegion, initCreateRegionObj, initDeleteRegionObj, deleteConfirmedRegion, updateRegion, createRegion
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(Regions);