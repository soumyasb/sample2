import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import { getFormattedDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { Form, Input, Row, Col, Checkbox, Select, notification, Modal } from 'antd';

import { initHomePage } from "../../../store/actions/homePageActions";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import { 
    getAllEmployees, getEmployeeById, getEditEmployee, initCreateEmployeeObj, deleteEmployee, updateEmployee, createEmployee } from "../../../store/actions/dataManagerActions";

    import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';
    
    const FormItem = Form.Item;
    const { Option } = Select;
    const dateFormat = 'MM-dd-yyyy';
    
    const defaultObj = {
        Empid: -1,
        UserID: '',
        LastName: '',
        FirstName: '',
        ShortID: '',
        MiddleName: '',
        NameSuffix: '',
        OfficeID: '',
        DateUpdated: null,
        LastUpdBy: null,
        Classification: '',
        EmployeeClass: '123',
        DateTerminated: null,
        LoanFlag: false,
        TransferFlag: false,
        TransferOffice: null,
        TransferDate: null,
        LoanOffice: null,
        LoanStart: null,
        LoanEnd: null,
        OfficeList: null,
        ClassificationList: null,
        ClassList: null
    }
    
class Employees extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: this.props.AllEmployeesList,
            showModal: false,
            errorObj: {},
            obj: {},
            cETemplate: this.props.createEmpObj
        };

        this.columns = [
            {
                title: <b>User ID</b>,
                dataIndex: 'UserID',
                width: '15%',
                key: 'UserID',
                render: (u, obj) =>
                    <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                        style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                        {u}
                    </a>
            },
            {
                title: <b>Last Name</b>,
                dataIndex: 'LastName',
                key: 'LastName'

            },
            {
                title: <b>First Name</b>,
                dataIndex: 'FirstName',
                key: 'FirstName'
            },
            {
                title: <b>Date Terminated</b>,
                dataIndex: 'DateTerminated',
                key: 'DateTerminated',
                render: (item) =>
                {
              return getFormattedDate(item);
                }
            }
        ];


        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }
    componentDidMount(){
        
        this.props.getAllEmployees();
        this.props.initCreateEmployeeObj();
                }
    componentDidUpdate(prevProps){
        if(prevProps.homePage && prevProps.homePage !== this.props.homePage)
        {
          sessionStorage.setItem('userInfo', JSON.stringify(this.props.homePage)); 
          return {homePage: this.props.homePage}
        }
                            if ( prevProps.dataManager.allEmployeesList !== this.props.dataManager.allEmployeesList && this.props.dataManager.allEmployeesList !== undefined) {
                                this.setState({data: this.props.dataManager.allEmployeesList});
                            }
                            if ( prevProps.dataManager.createEmpObj !== this.props.dataManager.createEmpObj && this.props.dataManager.createEmpObj !== undefined) {
                                this.setState({cETemplate: this.props.dataManager.createEmpObj});
                            }
                            if ( (prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData || prevProps.dataManager.errMod !== this.props.dataManager.errMod) && this.props.dataManager.DMErrorData !== undefined) {
                              if(typeof(this.props.dataManager.DMErrorData) === "string"){
                                  this.openNotification("ERROR",this.props.dataManager.DMErrorData,"red");
                                this.setState({showDeleteModal: false, showModal: false});
                              }
                              else
                              {
                                  if(this.props.dataManager.DMErrorData["EmployeeDTO"] && this.props.dataManager.DMErrorData["EmployeeDTO"][0] && typeof(this.props.dataManager.DMErrorData["EmployeeDTO"][0]) === "string" )
                                  {
                                      Modal.error(
                                        {
                                            title: "Error"
                                            ,
                                            content: (
                                              <div>
                                          {this.props.dataManager.DMErrorData.EmployeeDTO[0]}
                                              </div>
                                            ),
                                            onOk() {},
                                          });
                                  }
                                this.setState({errorObj: this.props.dataManager.DMErrorData});
                              } 
                            }
                            if ( prevProps.dataManager.deleteEmpObj !== this.props.dataManager.deleteEmpObj ) {
                                this.setState({showDeleteModal: false});
                                this.props.getAllEmployees();
                                this.props.initHomePage();
                                this.openNotification("SUCCESS","Employee terminated successfully!","#9cd864");                              
                        }
                            if ( prevProps.dataManager.createEmpData !== this.props.dataManager.createEmpData ) {
                                this.props.getAllEmployees();
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE, obj: this.props.dataManager.createEmpData.employee});
                                this.props.initHomePage();
                                this.openNotification("SUCCESS","Employee created successfully!","#9cd864");                              
                        }
                            if ( prevProps.dataManager.updateEmpData !== this.props.dataManager.updateEmpData ) {
                                this.props.getAllEmployees();
                            this.setState({actionType: DM_DETAILS_ACTION_TYPE, data: this.props.dataManager.updateEmpData});
                            this.props.initHomePage();
                            this.openNotification("SUCCESS","Employee updated successfully!","#9cd864");                              
                    }                           
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { allEmployeesList, createEmpObj, DMErrorData, createEmpData, updateEmpData } = props.dataManager;
                if (allEmployeesList && allEmployeesList !== prevState.data) return {
                     data: allEmployeesList };
                if (createEmpObj && createEmpObj !== prevState.cETemplate) return { cETemplate: createEmpObj };
                if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
                if (createEmpData && createEmpData !== prevState.obj) return { obj: createEmpData.employee };
                if (updateEmpData && updateEmpData !== prevState.data) return { 
                    data: updateEmpData };
                return null;
            }

            openNotification = (type, msg, color) => {
                notification.open({
                  message: type,
                  description: msg,
                  style: {
                    width: 600,
                    marginLeft: 335 - 600,
                    backgroundColor: color,
                    fontWeight: 'bold'
                  },
                });
              }
            
                handleShowModal(e, actype, obj) {
                    
                    if (actype !== DM_ADD_ACTION_TYPE) {
                        if (obj) { 
                            const modalObj = cloneDeep(this.state.data.find(d => d.UserID.toLowerCase() === obj.UserID.toLowerCase()));
                            this.setState({ obj: modalObj });
                            if (actype === DM_DELETE_ACTION_TYPE) {
                                let name = '';
                                if(modalObj.FirstName !== null && modalObj.FirstName !=='')
                                {
                                    name = name+modalObj.FirstName+" ";
                                }
                                if(modalObj.MiddleName !== null && modalObj.MiddleName !=='')
                                {
                                    name = name+modalObj.MiddleName+" ";
                                }
                                if(modalObj.LastName !== null && modalObj.LastName !=='')
                                {
                                    name = name+modalObj.LastName;
                                }
                                this.setState({deleteObjId: name});
                            }
                        }
                    }
                    else {
                        this.setState({ obj: cloneDeep(defaultObj) });
                    }
            
                    this.setState({
                        actionType: actype,
                        showModal: actype !== DM_DELETE_ACTION_TYPE,
                        showDeleteModal: actype === DM_DELETE_ACTION_TYPE
                    });
                }
            
                handleCancel() {
                    this.setState({ showModal: false, showDeleteModal: false });
                }
            
                handleOk(actionType) {
                    switch (actionType) {
                        case DM_ADD_ACTION_TYPE:
                        const empObj = {
                            employee: this.state.obj
                        }
                            this.props.createEmployee(empObj);
                            break;
                        case DM_EDIT_ACTION_TYPE:
                        this.props.updateEmployee(this.state.obj);
                            break;
                        case DM_DELETE_ACTION_TYPE:
                        this.props.deleteEmployee(this.state.obj.Empid);
                            break;
                        default: break;
                    }
                }
            
                handleFieldChange(e, field) {
                    const { obj } = this.state;
            
                    switch (field) {
                        case 'UserID':
                        case 'Empid':
                        case 'LastName':
                        case 'FirstName':
                        case 'MiddleName':
                        case 'ShortID':
                        case 'NameSuffix':
                            obj[field] = e.target.value;
                            break;
            
                        case 'TransferFlag':
                        case 'LoanFlag':
                            obj[field] = e.target.checked;
                            break;
            
                        case 'OfficeID':
                        case 'Classification':
                        case 'TransferOffice':
                        case 'LoanOffice':
                            obj[field] = e;
                            break;
            
                        default:
                            break
                    }
            
                    this.setState({ obj });
                }
            
                onDateChange(d, type) {
                    
                    const { obj } = this.state;
                    obj[type] = d || '';
            
                    this.setState({ obj });
                }
            
                renderModalFields() {
                    const { actionType, obj } = this.state;
                    const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;
                    return (
                        <Form layout={'vertical'}>
                            <Row>
                                <Col span={11}>
                                    <FormItem
                                validateStatus = {(this.state.errorObj !== {} && obj.UserID === '' && this.state.errorObj["employee.UserID"]) ? 'error' : ""}
                                    help = {this.state.errorObj !== {} && obj.UserID === '' && this.state.errorObj["employee.UserID"]}
                                        label={<b>User ID <font color="red">*</font></b>}
                                    >
                                      {isEditable ?
                                              <Input value={obj.UserID} placeholder="User ID" onChange={e => this.handleFieldChange(e, 'UserID')} />     
                                            :
                                            <div>{obj.UserID}</div>
                                        }
                               
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                      validateStatus = {(this.state.errorObj !== {} && obj.Empid === '' && this.state.errorObj["employee.Empid"]) ? 'error' : ""}
                                      help = {this.state.errorObj !== {} && obj.Empid === '' && this.state.errorObj["employee.Empid"]}
                                        label={<b>Employee ID <font color="red">*</font></b>}
                                    >
                                        {isEditable ?
                                            <Input value={obj.Empid} placeholder="Employee ID" onChange={e => this.handleFieldChange(e, 'Empid')} />
                                            :
                                            <div>{obj.Empid}</div>
                                        }
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={11}>
                                    <FormItem
                                     validateStatus = {this.state.errorObj !== {} && obj.FirstName === '' && this.state.errorObj["employee.FirstName"] ? 'error' : ""}
                                     help = {this.state.errorObj !== {} && obj.FirstName === '' && this.state.errorObj["employee.FirstName"]}
                                        label={<b>First Name <font color="red">*</font></b>}
                                    >
                                        {isEditable ?
                                            <Input value={obj.FirstName} placeholder="First Name" onChange={e => this.handleFieldChange(e, 'FirstName')} />
                                            :
                                            <div>{obj.FirstName}</div>
                                        }
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Middle Initial </b>}
                                    >
                                        {isEditable ?
                                            <Input value={obj.MiddleName} placeholder="Middle Initial" onChange={e => this.handleFieldChange(e, 'MiddleName')} />
                                            :
                                            <div>{obj.MiddleName}</div>
                                        }
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={11}>
                                    <FormItem
                                     validateStatus = {this.state.errorObj !== {} && obj.LastName === ''  && this.state.errorObj["employee.LastName"] ? 'error' : ""}
                                     help = {this.state.errorObj !== {} && obj.LastName === ''  && this.state.errorObj["employee.LastName"]}
                                        label={<b>Last Name <font color="red">*</font></b>}
                                    >
                                        {isEditable ?
                                            <Input value={obj.LastName} placeholder="Last Name" onChange={e => this.handleFieldChange(e, 'LastName')} />
                                            :
                                            <div>{obj.LastName}</div>
                                        }
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Suffix </b>}
                                    >
                                        {isEditable ?
                                            <Input value={obj.NameSuffix} placeholder="Suffix" onChange={e => this.handleFieldChange(e, 'NameSuffix')} />
                                            :
                                            <div>{obj.NameSuffix}</div>
                                        }
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                            <Col span={11}>
                                    <FormItem
                                     validateStatus = {this.state.errorObj !== {} && obj.ShortID === ''  && this.state.errorObj["employee.ShortID"] ? 'error' : ""}
                                     help = {this.state.errorObj !== {} && obj.ShortID === '' && this.state.errorObj["employee.ShortID"]}
                                        label={<b>Short ID <font color="red">*</font></b>}
                                    >
                                         {isEditable ?
                                            <Input value={obj.ShortID} maxLength={3} placeholder="Short ID" onChange={e => this.handleFieldChange(e, 'ShortID')} />
                                            :
                                            <div>{obj.ShortID}</div>
                                        }
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                     validateStatus = {this.state.errorObj !== {} && obj.OfficeID === ''  && this.state.errorObj["employee.OfficeID"] ? 'error' : ""}
                                     help = {this.state.errorObj !== {} && obj.OfficeID === '' && this.state.errorObj["employee.OfficeID"]}
                                        label={<b>Office ID <font color="red">*</font></b>}
                                    >
                                        {isEditable ?
                                            <Select id = "SOffI" onFocus={(e) => {
                                document.getElementById("SOffI").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OfficeID')} value={obj.OfficeID || 'Please Select'}
                                                showArrow={true} size={"default"}>
                                                {this.state.cETemplate.OfficeList.map(off => <Option key={off.Value} value={off.Value}>{off.Text}</Option>)}
                                            </Select>
                                            :
                                            <div>{obj.OfficeID && this.state.cETemplate.OfficeList.find(off => off.Value === obj.OfficeID).Text}</div>
                                        }
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                            <Col span={11}>
                                    <FormItem
                                      validateStatus = {this.state.errorObj !== {} && obj.Classification === ''  && this.state.errorObj["employee.Classification"] ? 'error' : ""}
                                      help = {this.state.errorObj !== {} && obj.Classification === ''  && this.state.errorObj["employee.Classification"]}
                                        label={<b>Classification <font color="red">*</font></b>}
                                    >
                                        {isEditable ?
                                            <Select id = "SClass" onFocus={(e) => {
                                document.getElementById("SClass").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Classification')} value={obj.Classification || 'Please Select'}
                                                showArrow={true} size={"default"}>
                                                {this.state.cETemplate.ClassificationList.map(off => <Option key={off.Value} value={off.Value}>{off.Text}</Option>)}
                                            </Select>
                                            :
                                            <div>{obj.Classification && this.state.cETemplate.ClassificationList.find(off => off.Value === obj.Classification).Text}</div>
                                        }
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                        validateStatus = {this.state.errorObj !== {} && obj.DateTerminated === null  && this.state.errorObj["employee.DateTerminated"] ? 'error' : ""}
                                        help = {this.state.errorObj !== {} && obj.DateTerminated === null && this.state.errorObj["employee.DateTerminated"]}
                                          label={<b>End Access Effective Date </b>}
                                    >
                                        {isEditable ?
                                    <DatePicker
                                    className = "CalClass"
                                    style={{lineHeight : "20px"}}
                                    selected={obj.DateTerminated ? new Date(obj.DateTerminated) : null}
                                    dateFormat={dateFormat}
                                    onChange={(d) => this.onDateChange(d, 'DateTerminated')}
                                    isClearable={true}
                                    placeholderText="Select Date"
                                  /> :
                                            <div>{getFormattedDate(obj.DateTerminated)}</div>
                                        }
                                    </FormItem>
                                </Col>   
                            </Row>
                            <hr />
                            <Row>
                                <Col span={12}>
                                    <Checkbox checked={obj.TransferFlag}
                                        onChange={e => this.handleFieldChange(e, 'TransferFlag')}
                                        disabled={!isEditable}
                                    >
                                        <b>Transfer</b>
                                    </Checkbox>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Transfer Office </b>}
                                    >
                                        {isEditable && obj.TransferFlag ?
                                            <Select id = "STOff" onFocus={(e) => {
                                document.getElementById("STOff").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'TransferOffice')} value={obj.TransferOffice || 'Please Select'}
                                                showArrow={true} size={"default"}>
                                                {this.state.cETemplate.OfficeList.map(off => <Option key={off.Value} value={off.Value}>{off.Text}</Option>)}
                                            </Select>
                                            :
                                            <div>{obj.TransferOffice && obj.TransferOffice !== "   " && this.state.cETemplate.OfficeList.find(off => off.Value === obj.TransferOffice).Text}</div>
                                        }
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Transfer Date </b>}
                                    >
                                        {isEditable && obj.TransferFlag ?
            
                                        <DatePicker
                                        className = "CalClass"
                                        style={{lineHeight : "20px"}}
                                        selected={obj.TransferDate ? new Date(obj.TransferDate) : null}
                                        dateFormat={dateFormat}
                                        onChange={(d) => this.onDateChange(d, 'TransferDate')}
                                        isClearable={true}
                                        placeholderText="Select Date"
                                      />  :
                                      <div>{getFormattedDate(obj.TransferDate)}</div>
                                        }
                                    </FormItem>
                                </Col>
                            </Row>
                            <hr />
                            <Row>
                                <Col span={12}>
                                    <Checkbox checked={obj.LoanFlag}
                                        onChange={e => this.handleFieldChange(e, 'LoanFlag')}
                                        disabled={!isEditable}
                                    >
                                        <b>Loan</b>
                                    </Checkbox>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Loan Office </b>}
                                    >
                                        {isEditable && obj.LoanFlag  ?
                                            <Select id = "SLOff" onFocus={(e) => {
                                document.getElementById("SLOff").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'LoanOffice')} value={obj.LoanOffice || 'Please Select'}
                                                showArrow={true} size={"default"}>
                                                {this.state.cETemplate.OfficeList.map(off => <Option key={off.Value} value={off.Value}>{off.Text}</Option>)}
                                            </Select>
                                            :
                                            <div>{obj.LoanOffice && obj.LoanOffice !== "   "  && this.state.cETemplate.OfficeList.find(off => off.Value === obj.LoanOffice).Text}</div>
                                        }
                                    </FormItem>
                                </Col>
                                <Col span={1}></Col>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Loan Start Date </b>}
                                    >
                                        {isEditable && obj.LoanFlag ?
                                            <DatePicker
                                            className = "CalClass"
                                            style={{lineHeight : "20px"}}
                                            selected={obj.LoanStart ? new Date(obj.LoanStart) : null}
                                            dateFormat={dateFormat}
                                            onChange={(d) => this.onDateChange(d, 'LoanStart')}
                                            isClearable={true}
                                            placeholderText="Select Date"
                                          />  :
                                          <div>{getFormattedDate(obj.LoanStart)}</div>
                                            }
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={11}>
                                    <FormItem
                                        label={<b>Loan End Date </b>}
                                    >
                                        {isEditable && obj.LoanFlag ?
                                            <DatePicker
                                            className = "CalClass"
                                            style={{lineHeight : "20px"}}
                                            selected={obj.LoanEnd ? new Date(obj.LoanEnd) : null}
                                            dateFormat={dateFormat}
                                            onChange={(d) => this.onDateChange(d, 'LoanEnd')}
                                            isClearable={true}
                                            placeholderText="Select Date"
                                          />  :
                                          <div>{getFormattedDate(obj.LoanEnd)}</div>
                                        }
                                    </FormItem>
                                </Col>
                            </Row>
                        </Form >
                    );
                }
            
                render() {
                    const { title, footer } =
                        getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Employee');
                        
                    return (
                        <div>
                            {this.state.data && <DMTable title={<b>Employees</b>}
                                tableData={this.state.data}
                                columns={this.columns}
                                handleShowModal={this.handleShowModal}
                                uniqueColumnName='UserID'
                                searchField={['LastName', 'FirstName']}
                                showModal={this.state.showModal}
                                showDeleteModal={this.state.showDeleteModal}
                                deleteObjId={this.state.deleteObjId}
                                handleOk={this.handleOk}
                                handleCancel={this.handleCancel}
                                modalTitle={title}
                                footer={footer}
                                width={'600px'}
                                renderModalFields={this.renderModalFields}
                            />}
                        </div>
                    )
                }
            }

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager,
      homePage: state.homePage
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            initHomePage, getAllEmployees, getEmployeeById, getEditEmployee, initCreateEmployeeObj, deleteEmployee, updateEmployee, createEmployee
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(Employees);