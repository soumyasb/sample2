import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import { Form, Input, notification } from 'antd';
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import { 
    getLanguages, getLanguageDetailsById, getEditLanguage, initCreateLanguageObj, initDeleteLanguageObj, deleteConfirmedLanguage, updateLanguage, createLanguage } from "../../../store/actions/dataManagerActions";
import {
    getModalSettings,
    DM_ADD_ACTION_TYPE,
    DM_DELETE_ACTION_TYPE,
    DM_EDIT_ACTION_TYPE,
    DM_DETAILS_ACTION_TYPE
} from './DMTableFns';

const FormItem = Form.Item;
const formItemLayout = {
    labelCol: { span: 9 },
    wrapperCol: { span: 15 },
};

const defaultObj = {
    CdLanguage: '',
    DescLanguage: '',
    DtTerm: null
}

class Languages extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: this.props.allLanguagesList,
            showModal: false,
            errorObj: {},
            obj: {},
        };

        this.columns = [
            {
                title: <b>Code</b>,
                dataIndex: 'CdLanguage',
                key: 'CdLanguage',
                render: (c, obj) =>
                    <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                        style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                        {c}
                    </a>
            },
            {
                title: <b>Language</b>,
                dataIndex: 'DescLanguage',
                key: 'DescLanguage'
            }
        ];

        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount(){
        
        this.props.getLanguages();
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dataManager.allLanguagesList !== this.props.dataManager.allLanguagesList && this.props.dataManager.allLanguagesList !== undefined) {
                                this.setState({data: this.props.dataManager.allLanguagesList});
                            }
                            if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                this.setState({errorObj: this.props.dataManager.DMErrorData});
                            }
                            if ( prevProps.dataManager.createLanguageData !== this.props.dataManager.createLanguageData ) {
                                this.props.getLanguages();
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.openNotification("Language created successfully!");                              
                        }
                        if ( prevProps.dataManager.dleteConfirmedLanguageData !== this.props.dataManager.dleteConfirmedLanguageData ) {
                            this.setState({showDeleteModal: false});
                            this.props.getLanguages();
                            this.openNotification("Language removed successfully!");                              
                    }
                        if ( prevProps.dataManager.updateLanguageData !== this.props.dataManager.updateLanguageData ) {
                            this.props.getLanguages();
                            this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                            this.openNotification("Language updated successfully!");                              
                    }                        
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { allLanguagesList, DMErrorData } = props.dataManager;
                if (allLanguagesList && allLanguagesList !== prevState.data) return {
                     data: allLanguagesList };
                if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
                return null;
            }

            openNotification = (msg) => {
                notification.open({
                  message: 'SUCCESS',
                  description: msg,
                  style: {
                    width: 600,
                    marginLeft: 335 - 600,
                    backgroundColor: "#9cd864",
                    fontWeight: 'bold'
                  },
                });
              }

    handleShowModal(e, actype, obj) {
        if (actype !== DM_ADD_ACTION_TYPE) {
            if (obj) {
                const modalObj = cloneDeep(this.state.data.find(d => d.CdLanguage.toLowerCase() === obj.CdLanguage.toLowerCase()));
                this.setState({ obj: modalObj });
                if (actype === DM_DELETE_ACTION_TYPE) {
                    this.setState({deleteObjId: modalObj.DescLanguage})
                }
            }
        }
        else {
            this.setState({ obj: cloneDeep(defaultObj) });
        }

        this.setState({
            actionType: actype,
            showModal: actype !== DM_DELETE_ACTION_TYPE,
            showDeleteModal: actype === DM_DELETE_ACTION_TYPE
        });
    }

    handleCancel() {
        this.setState({ showModal: false, showDeleteModal: false });
    }

    handleOk(actionType) {
        switch (actionType) {
            case DM_ADD_ACTION_TYPE:
            this.props.createLanguage(this.state.obj);
                break;
            case DM_EDIT_ACTION_TYPE:
            this.props.updateLanguage(this.state.obj);
                break;
            case DM_DELETE_ACTION_TYPE:
            this.props.deleteConfirmedLanguage(this.state.obj.CdLanguage);
                break;
            default: break;
        }
    }

    handleFieldChange(e, field) {
        const { obj } = this.state;

        switch (field) {
            case 'CdLanguage':
            case 'DescLanguage':
                obj[field] = e.target.value;
                break;
            default:
                break
        }

        this.setState({ obj });
    }
    
    renderModalFields() {
        const { actionType, obj } = this.state;
        const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;

        return (
            <Form layout={'horizontal'}>
                <FormItem
                     validateStatus = {obj.CdLanguage === "" && this.state.errorObj["language.CdLanguage"] ? 'error' : ""}
                     help = {obj.UserID === "" && this.state.errorObj["language.CdLanguage"]}
                         label={<b>Code <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?

                        <Input value={obj.CdLanguage} placeholder="Code"
                            disabled={actionType !== DM_ADD_ACTION_TYPE}
                            onChange={e => this.handleFieldChange(e, 'CdLanguage')} />
                        :
                        <div>{obj.CdLanguage}</div>
                    }
                </FormItem>
                <FormItem
                    validateStatus = {obj.DescLanguage === "" && this.state.errorObj["language.DescLanguage"] ? 'error' : ""}
                    help = {obj.DescLanguage === "" && this.state.errorObj["language.DescLanguage"]}
                        label={<b>Language <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.DescLanguage} placeholder="Language" onChange={e => this.handleFieldChange(e, 'DescLanguage')} />
                        :
                        <div>{obj.DescLanguage}</div>
                    }
                </FormItem>
            </Form>
        );
    }

    render() {
        const { title, footer } =
            getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Language');

        return (
            <div>
               {this.state.data && <DMTable title={<b>Languages</b>}
                    tableData={this.state.data}
                    columns={this.columns}
                    handleShowModal={this.handleShowModal}
                    uniqueColumnName='CdLanguage'

                    searchField='DescLanguage'

                    showModal={this.state.showModal}
                    showDeleteModal={this.state.showDeleteModal}
                    handleOk={this.handleOk}
                    handleCancel={this.handleCancel}
                    modalTitle={title}
                    footer={footer}
                    width={'600px'}
                    deleteObjId={this.state.deleteObjId}
                    renderModalFields={this.renderModalFields}
                >

                </DMTable>}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getLanguages, getLanguageDetailsById, getEditLanguage, initCreateLanguageObj, initDeleteLanguageObj, deleteConfirmedLanguage, updateLanguage, createLanguage
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(Languages);