import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import { Form, Input, InputNumber, Modal, Button, notification } from 'antd';
import moment from 'moment';
import { 
    getHearingTimes, getHearingTimeDetailsById, getEditHT, initCreateHTObj, initDeleteHTObj, deleteConfirmedHT, updateHT, createHT } from "../../../store/actions/dataManagerActions";
import {
    getModalSettings,
    DM_ADD_ACTION_TYPE,
    DM_DELETE_ACTION_TYPE,
    DM_EDIT_ACTION_TYPE,
    DM_DETAILS_ACTION_TYPE
} from './DMTableFns';

const FormItem = Form.Item;

const formItemLayout = {
    labelCol: { span: 9 },
    wrapperCol: { span: 15 },
};

const defaultObj = {
    ID: -1,
    Category: '',
    HearingTime: 1,
    InterviewTime: 1,
    ReExamTime: 1,
    LastUpdatedBy: null,
    LastUpdatedDate: null,
    message: null
}

class DefaultHearingTime extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data:  this.props.allHearingTimesList,
            showErrorModal: false,
            TermDate: null,
            errorObj: {},
            showModal: false,
            obj: {},
        };

        this.columns = [
            {
                title: <b>Category</b>,
                dataIndex: 'Category',
                key: 'Category',
                render: (c,obj) =>
                    <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                        style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                        {c}
                    </a>
            },
            {
                title: <b>Hearing Time (mins)</b>,
                dataIndex: 'HearingTime',
                key: 'HearingTime'
            },
            {
                title: <b>Interview Time (mins)</b>,
                dataIndex: 'InterviewTime',
                key: 'InterviewTime'
            },
            {
                title: <b>ReExamination Time (mins)</b>,
                dataIndex: 'ReExamTime',
                key: 'ReExamTime',
            }
        ];

        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount(){
        
        this.props.getHearingTimes();
                }
                componentDidUpdate(prevProps){
                    
                            if ( prevProps.dataManager.allHearingTimesList !== this.props.dataManager.allHearingTimesList ) {
                                this.setState({data: this.props.dataManager.allHearingTimesList});
                            }
                            if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                if(typeof(this.props.dataManager.DMErrorData) === "string"){
                                  this.setState({ errorObj: this.props.dataManager.DMErrorData, showErrorModal: true, showModal: false});
                                }
                                else
                                {
                                  this.setState({errorObj: this.props.dataManager.DMErrorData});
                                } 
                            }
                            if ( prevProps.dataManager.createHTData !== this.props.dataManager.createHTData ) {
                                this.props.getHearingTimes();
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.openNotification("Hearing Time created successfully!");                              
                        }
                            if ( prevProps.dataManager.updateHTData !== this.props.dataManager.updateHTData ) {
                                this.props.getHearingTimes();
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.openNotification("Hearing Time updated successfully!");                              
                    }       
                    if ( prevProps.dataManager.dleteConfirmedHTData !== this.props.dataManager.dleteConfirmedHTData ) {
                        this.props.getHearingTimes();
                        this.setState({showDeleteModal: false});
                        if(this.props.dataManager.dleteConfirmedHTData.message === "")
                        {
                            this.openNotification("Hearing Time deleted successfully!");   
                        }
                        else
                        {
                            this.setState({ errorObj: this.props.dataManager.dleteConfirmedHTData.message, showErrorModal: true});
                        }
                           
            } 
                        }

    static getDerivedStateFromProps(props, prevState, DMErrorData) {
        
        const { allHearingTimesList } = props.dataManager;
        if (allHearingTimesList && allHearingTimesList !== prevState.data) return { data: allHearingTimesList };
        if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
        return null;
    }
    
    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    handleShowModal(e, actype, obj) {
        
        if (actype !== DM_ADD_ACTION_TYPE) {
            if (obj) {
                const modalObj = cloneDeep(this.state.data.find(d => d.Category.toLowerCase() === obj.Category.toLowerCase()));
                this.setState({ obj: modalObj });
                if (actype === DM_EDIT_ACTION_TYPE) {

                }
                if (actype === DM_DETAILS_ACTION_TYPE) {

                }
                if (actype === DM_DELETE_ACTION_TYPE) {
                    this.setState({deleteObjId: modalObj.Category+" hearing time"})
                }
            }
        }
        else {
            this.setState({ obj: cloneDeep(defaultObj) });
        }

        this.setState({
            actionType: actype,
            showModal: actype !== DM_DELETE_ACTION_TYPE,
            showDeleteModal: actype === DM_DELETE_ACTION_TYPE
        });
    }

    handleCancel() {
        this.setState({ showModal: false, showDeleteModal: false });
    }

    handleOk(actionType) {
        switch (actionType) {
            case DM_ADD_ACTION_TYPE:
            
            this.props.createHT(this.state.obj);
                break;
            case DM_EDIT_ACTION_TYPE: 
            this.props.updateHT(this.state.obj);
                break;
            case DM_DELETE_ACTION_TYPE:
            this.props.deleteConfirmedHT(this.state.obj.ID);
                break;
            default: break;
        }
    }

    handleFieldChange(e, field) {
        const { obj } = this.state;

        switch (field) {
            case 'Category':
                obj[field] = e.target.value;
                break;
            case 'HearingTime':
            case 'InterviewTime':
            case 'ReExamTime':
                obj[field] = e;
                break;
            default:
                break
        }

        this.setState({ obj });
    }

    onDateChange(d, ds, type) {
        const { obj } = this.state;
        obj[type] = ds || '';

        this.setState({ obj });
    }

    renderModalFields() {
        const { actionType, obj } = this.state;
        const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;

        return (
            
            <Form layout={'horizontal'}>
                <FormItem
                     validateStatus = {obj.Category === "" && this.state.errorObj["hearingTime.Category"] ? 'error' : ""}
                     help = {obj.Category === "" && this.state.errorObj["hearingTime.Category"]}
                         label={<b>Category <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.Category} placeholder="Category" onChange={e => this.handleFieldChange(e, 'Category')} />
                        :
                        <div>{obj.Category}</div>
                    }
                </FormItem>
                <FormItem
                      validateStatus = {obj.HearingTime === "" && this.state.errorObj["hearingTime.HearingTime"] ? 'error' : ""}
                      help = {obj.HearingTime === "" && this.state.errorObj["hearingTime.HearingTime"]}
                          label={<b>Hearing Time <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <div><InputNumber min={1} max={100} value={obj.HearingTime}
                            placeholder="Hearing Time"
                            onChange={e => this.handleFieldChange(e, 'HearingTime')} /> mins</div>
                        :
                        <div>{obj.HearingTime} mins</div>
                    }
                </FormItem>
                <FormItem
                      validateStatus = {obj.InterviewTime === "" && this.state.errorObj["hearingTime.InterviewTime"] ? 'error' : ""}
                      help = {obj.InterviewTime === "" && this.state.errorObj["hearingTime.InterviewTime"]}
                          label={<b>Interview Time <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <div><InputNumber min={1} max={100} value={obj.InterviewTime}
                            placeholder="Interview Time"
                            onChange={e => this.handleFieldChange(e, 'InterviewTime')} /> mins</div>
                        :
                        <div>{obj.InterviewTime} mins</div>
                    }
                </FormItem>
                <FormItem
                      validateStatus = {obj.ReExamTime === "" && this.state.errorObj["hearingTime.ReExamTime"] ? 'error' : ""}
                      help = {obj.ReExamTime === "" && this.state.errorObj["hearingTime.ReExamTime"]}
                          label={<b>Re-Exam Time <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <div><InputNumber min={1} max={100} value={obj.ReExamTime}
                            placeholder="Re-examination Time"
                            onChange={e => this.handleFieldChange(e, 'ReExamTime')} /> mins</div>
                        :
                        <div>{obj.ReExamTime} mins</div>
                    }
                </FormItem>
                {
                    !isEditable &&
                    <div>
                        <FormItem
                            label={<b>Last Updated By</b>}
                            {...formItemLayout}
                        >
                            <div>{obj.LastUpdatedBy}</div>
                        </FormItem>
                        <FormItem
                            label={<b>Last Updated Date</b>}
                            {...formItemLayout}
                        >
                            <div><div>{moment(obj.LastUpdatedDate).isValid() ? moment(obj.LastUpdatedDate).format('MM-DD-YYYY') : "-"}</div></div>
                        </FormItem>
                    </div>
                }
            </Form>
        );
    }

    render() {
        const { title, footer } =
            getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Default Hearing Time');

        return (
            <div>
                  <Modal maskClosable={false} visible={this.state.showErrorModal}   title="ERROR"
          footer={<Button onClick={(e) => {this.setState({showErrorModal: false})}}>OK</Button>}><div><font color="red">{this.state.errorObj}</font></div></Modal>   
                {this.state.data && <DMTable title={<b>Default Hearing Time Maintenance</b>}
                    tableData={this.state.data}
                    columns={this.columns}
                    handleShowModal={this.handleShowModal}
                    uniqueColumnName='Category'
                    searchField='Category'
                    showModal={this.state.showModal}
                    showDeleteModal={this.state.showDeleteModal}
                    handleOk={this.handleOk}
                    handleCancel={this.handleCancel}
                    modalTitle={title}
                    footer={footer}
                    width={'600px'}
                    deleteObjId={this.state.deleteObjId}
                    renderModalFields={this.renderModalFields}
                    
        /> }
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getHearingTimes, getHearingTimeDetailsById, getEditHT, initCreateHTObj, initDeleteHTObj, deleteConfirmedHT, updateHT, createHT
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DefaultHearingTime);