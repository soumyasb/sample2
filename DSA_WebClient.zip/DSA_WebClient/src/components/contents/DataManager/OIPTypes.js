import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { getFormattedDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { connect } from "react-redux";
import { Form, Input, notification } from 'antd';
import { 
    getOIPTypes, getOIPTypeDetailsByType, getEditOIPType, initCreateOIPTypeObj, initDeleteOIPTypeObj, deleteConfirmedOIPType, updateOIPType, createOIPType } from "../../../store/actions/dataManagerActions";
    import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';
    
    const FormItem = Form.Item;
    
    const formItemLayout = {
        labelCol: { span: 9 },
        wrapperCol: { span: 15 },
    };
    
    const defaultObj = {
        Type: '',
        TermDate: null,
        Description: ''
    }

    class OIPTypes extends Component {
        constructor(props) {
            super(props);
    
            this.state = {
                data: this.props.allOIPTypesList,
                errorObj: {},
                showModal: false,
                obj: {},
            };
            this.columns = [
                {
                    title: <b>Type</b>,
                    dataIndex: 'Type',
                    key: 'Type',
                    render: (c, obj) =>
                        <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                            style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                            {c}
                        </a>
                },
                {
                    title: <b>Description</b>,
                    dataIndex: 'Description',
                    key: 'Description'
                },
                {
                    title: <b>End Effective Date</b>,
                    dataIndex: 'TermDate',
                    key: 'TermDate',
                    render: (item) =>
                    {
                   return getFormattedDate(item);
                    }
                }
            ];
            this.handleShowModal = this.handleShowModal.bind(this);
            this.handleCancel = this.handleCancel.bind(this);
            this.handleOk = this.handleOk.bind(this);
            this.renderModalFields = this.renderModalFields.bind(this);
            this.handleFieldChange =  this.handleFieldChange.bind(this);
            this.onDateChange = this.onDateChange.bind(this);
            this.openNotification = this.openNotification.bind(this);
        }

        componentDidMount(){
            
            this.props.getOIPTypes();
                    }
                    componentDidUpdate(prevProps){
                        
                                if ( prevProps.dataManager.allOIPTypesList !== this.props.dataManager.allOIPTypesList && this.props.dataManager.allOIPTypesList !== undefined) {
                                    this.setState({data: this.props.dataManager.allOIPTypesList});
                                }
                                if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                    this.setState({errorObj: this.props.dataManager.DMErrorData});
                                }
                                if ( prevProps.dataManager.createOIPTypeData !== this.props.dataManager.createOIPTypeData ) {
                                    this.setState({actionType: DM_DETAILS_ACTION_TYPE, obj: this.props.dataManager.createOIPTypeData.employee});
                                    this.openNotification("OIP Type created successfully!");                              
                            }
                            if ( prevProps.dataManager.dleteConfirmedOIPTypeData !== this.props.dataManager.dleteConfirmedOIPTypeData ) {
                                this.setState({showDeleteModal: false});
                                this.props.getOIPTypes();
                                this.openNotification("OIP Type deleted successfully!");                              
                        }
                                if ( prevProps.dataManager.updateOIPTypeData !== this.props.dataManager.updateOIPTypeData ) {
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE, data: this.props.dataManager.updateOIPTypeData});
                                this.openNotification("OIP Type updated successfully!");                              
                        }                       
                            }
    
        static getDerivedStateFromProps(props, prevState) {
            const { allOIPTypesList, DMErrorData, updateOIPTypeData, createOIPTypeData } = props.dataManager;
            if (allOIPTypesList && allOIPTypesList !== prevState.data) return { data: allOIPTypesList };
            if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
            if (createOIPTypeData && createOIPTypeData !== prevState.obj) return { obj: createOIPTypeData };
            if (updateOIPTypeData && updateOIPTypeData !== prevState.data) return { 
                data: updateOIPTypeData };
            return null;
        }
        handleFieldChange(e, field) {
            const { obj } = this.state;
    
            switch (field) {
                case 'Type':
                obj[field] = e.target.value;
                    break;
                case 'Description':
                    obj[field] = e.target.value;
                    break;
                default:
                    break
            }
    
            this.setState({ obj });
        }
    
        onDateChange(d, type) {
            const { obj } = this.state;
            obj[type] = d || '';
    
            this.setState({ obj });
        }
        openNotification = (msg) => {
            notification.open({
              message: 'SUCCESS',
              description: msg,
              style: {
                width: 600,
                marginLeft: 335 - 600,
                backgroundColor: "#9cd864",
                fontWeight: 'bold'
              },
            });
          }
        
        handleShowModal(e, actype, obj) {
            if (actype !== DM_ADD_ACTION_TYPE) {
                if (obj) {
                    const modalObj = cloneDeep(this.state.data.find(d => d.Type.toLowerCase() === obj.Type.toLowerCase()));
                    this.setState({ obj: modalObj });

                    if (actype === DM_EDIT_ACTION_TYPE) {
    
                    }
                    if (actype === DM_DETAILS_ACTION_TYPE) {
    
                    }
                    if (actype === DM_DELETE_ACTION_TYPE) {
                        this.setState({deleteObjId: modalObj.Type+" OIP Type"});
                    }
                }
            }
            else {  
                this.setState({ obj: cloneDeep(defaultObj) });
            }
    
            this.setState({
                actionType: actype,
                showModal: actype !== DM_DELETE_ACTION_TYPE,
                showDeleteModal: actype === DM_DELETE_ACTION_TYPE
            });
        }
    
        handleCancel() {
            this.setState({ showModal: false, showDeleteModal: false });
        }
    
        handleOk(actionType) {
            switch (actionType) {
                case DM_ADD_ACTION_TYPE:
                this.props.createOIPType(this.state.obj);
                    break;
                case DM_EDIT_ACTION_TYPE:
                this.props.updateOIPType(this.state.obj);
                    break;
                case DM_DELETE_ACTION_TYPE:
                this.props.deleteConfirmedOIPType(this.state.obj.Type);
                    break;
                default: break;
            }
        }
    
        renderModalFields() {
            const { actionType, obj } = this.state;
            const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;
    
            return (
                <Form layout={'horizontal'}>
                    <FormItem
                          validateStatus = {obj.Type === "" && this.state.errorObj["oipType.Type"] ? 'error' : ""}
                          help = {obj.Type === "" && this.state.errorObj["oipType.Type"]}
                          label={<b>Type </b>}
                        {...formItemLayout}
                    >
                        {isEditable ?
                            <Input value={obj.Type} placeholder="Type" onChange={e => this.handleFieldChange(e, 'Type')} />
                            :
                            <div>{obj.Type}</div>
                        }
                    </FormItem>
                    <FormItem
                          validateStatus = {obj.Description === "" && this.state.errorObj["oipType.Description"] ? 'error' : ""}
                          help = {obj.Description === "" && this.state.errorObj["oipType.Description"]}
                          label={<b>Description </b>}
                          {...formItemLayout}
                    >
                        {isEditable ?
                            <Input value={obj.Description} placeholder="Description" onChange={e => this.handleFieldChange(e, 'Description')} />
                            :
                            <div>{obj.Description}</div>
                        }
                    </FormItem>
                    <FormItem
                         validateStatus = {obj.TermDate === "" && this.state.errorObj["oipType.TermDate"] ? 'error' : ""}
                         help = {obj.TermDate === "" && this.state.errorObj["oipType.TermDate"]}
                         label={<b>End Effective Date </b>}
                         {...formItemLayout}
                    >
                        {isEditable ?
                            <DatePicker
                                className = "CalClass"
                                selected={obj.TermDate}
                                dateFormat={"MM-dd-yyyy"}
                                onChange={(d) => this.onDateChange(d, 'TermDate')}
                                isClearable={true}
                                placeholderText="Select a date"
                              />
                            :
                            <div>{getFormattedDate(obj.TermDate)}</div>
                        }
                    </FormItem>
                </Form>
            );
        }
    
        render() {
            const { title, footer } =
                getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'OIP Type');
                return (
                    <div>
                        {this.state.data && <DMTable title={<b>OIP Type Maintenance</b>}
                            tableData={this.state.data}
                            searchField='Description'
                            columns={this.columns}
                            handleShowModal={this.handleShowModal}
                            uniqueColumnName='Type'
                            showModal={this.state.showModal}
                            deleteObjId={this.state.deleteObjId}
                            showDeleteModal={this.state.showDeleteModal}
                            handleOk={this.handleOk}
                            handleCancel={this.handleCancel}
                            modalTitle={title}
                            footer={footer}
                            width={'600px'}
                            renderModalFields={this.renderModalFields}
                        >
                        </DMTable>}
                </div>
            )
        }
    }
    
    const mapStateToProps = state => {
        return {
          dataManager: state.dataManager
        };
    };
    
    const mapDispatchToProps = dispatch => {
        return bindActionCreators(
            {
                getOIPTypes, getOIPTypeDetailsByType, getEditOIPType, initCreateOIPTypeObj, initDeleteOIPTypeObj, deleteConfirmedOIPType, updateOIPType, createOIPType
            },
            dispatch
        );
    };
    
    export default connect(mapStateToProps, mapDispatchToProps)(OIPTypes);