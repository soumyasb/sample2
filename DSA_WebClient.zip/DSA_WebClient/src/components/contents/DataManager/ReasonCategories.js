import React, { Component } from 'react';
import DMTable from './DMTable';
import { getFormattedDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Icon, Form, Input, notification } from 'antd';
import cloneDeep from 'lodash/cloneDeep';
import { 
    getReasonCategories, getRCDetailsById, getEditRC, initCreateRCObj, initDeleteRCObj, deleteConfirmedRC, updateRC, createRC } from "../../../store/actions/dataManagerActions";
import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';
    
    const FormItem = Form.Item;
    
    const formItemLayout = {
        labelCol: { span: 9 },
        wrapperCol: { span: 15 },
    };
    
    const defaultObj = {
    ID: 0,
    FromCategory: "",
    ToCategory: "",
    Description: "",
    SpecialCert: false,
    UpdatedBy: null,
    UpdateDay: null,
    TermDate: null
    }

class ReasonCategories extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: this.props.allReasonCategoriesList,
            errorObj: {},
            TermDate: null,
            showModal: false,
            obj: {},
        };

        this.columns = [
            {
                title: <b>ID</b>,
                dataIndex: 'ID',
                key: 'ID',
                render: (c,obj) =>
                    <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                        style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                        {c}
                    </a>
            },
            {
                title: <b>From Category</b>,
                dataIndex: 'FromCategory',
                key: 'FromCategory'
            },
            {
                title: <b>To Category</b>,
                dataIndex: 'ToCategory',
                key: 'ToCategory'
            },
            {
                title: <b>Description</b>,
                dataIndex: 'Description',
                key: 'Description'
            },
            {
                title: <b>Special Cert</b>,
                dataIndex: 'SpecialCert',
                key: 'SpecialCert',
                render: c => c ? <Icon type="check" /> : <Icon type="close" />
            },
            {
                title: <b>Updated By</b>,
                dataIndex: 'UpdatedBy',
                key: 'UpdatedBy'
            },
            {
                title: <b>Update On</b>,
                dataIndex: 'UpdateDay',
                key: 'UpdateDay'
            },
            {
                title: <b>End Effective Date</b>,
                dataIndex: 'TermDate',
                key: 'TermDate',
                render: (item) =>
                {
               return getFormattedDate(item);
                }
            }
        ];

        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.handleFieldChange =  this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount(){
        
        this.props.getReasonCategories();
                }
                componentDidUpdate(prevProps){
                    
                            if ( prevProps.dataManager.allReasonCategoriesList !== this.props.dataManager.allReasonCategoriesList && this.props.dataManager.allReasonCategoriesList !== undefined) {
                                this.setState({data: this.props.dataManager.allReasonCategoriesList});
                            }
                            if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                this.setState({errorObj: this.props.dataManager.DMErrorData});
                            }
                            if ( prevProps.dataManager.createRCData !== this.props.dataManager.createRCData ) {
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE, obj: this.props.dataManager.createRCData.employee});
                                this.openNotification("Reason Category created successfully!");                              
                        }
                        if ( prevProps.dataManager.dleteConfirmedRCData !== this.props.dataManager.dleteConfirmedRCData ) {
                            this.setState({showDeleteModal: false});
                            this.props.getReasonCategories();
                            this.openNotification("Reason Category deleted successfully!");                              
                    }
                            if ( prevProps.dataManager.updateRCData !== this.props.dataManager.updateRCData ) {
                            this.setState({actionType: DM_DETAILS_ACTION_TYPE, data: this.props.dataManager.updateRCData});
                            this.openNotification("Reason Category updated successfully!");                              
                    }                    
                        }

    static getDerivedStateFromProps(props, prevState) {
        const { allReasonCategoriesList, DMErrorData, createRCData, updateRCData } = props.dataManager;
        if (allReasonCategoriesList && allReasonCategoriesList !== prevState.data) return { data: allReasonCategoriesList };
        if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
        if (createRCData && createRCData !== prevState.obj) return { obj: createRCData };
        if (updateRCData && updateRCData !== prevState.data) return { 
            data: updateRCData };
        return null;
    }

    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    handleShowModal(e, actype, obj) {
        if (actype !== DM_ADD_ACTION_TYPE) {
            if (obj) {
                const modalObj = cloneDeep(this.state.data.find(d => d.ID === obj.ID));
                this.setState({ obj: modalObj });
                if (actype === DM_DELETE_ACTION_TYPE) {
                    this.setState({deleteObjId: modalObj.ID+" Reason Category"});
                }
            }
        }
        else {
            this.setState({ obj: cloneDeep(defaultObj) });
        }

        this.setState({
            actionType: actype,
            showModal: actype !== DM_DELETE_ACTION_TYPE,
            showDeleteModal: actype === DM_DELETE_ACTION_TYPE
        });
    }
    handleFieldChange(e, field) {
        const { obj } = this.state;

        switch (field) {
            case 'ID':
            case 'FromCategory':
            case 'ToCategory':
            case 'Description':
                obj[field] = e.target.value;
                break;
            case 'SpecialCert':
                obj[field] = e.target.checked;
                break;
            default:
                break
        }

        this.setState({ obj });
    }

    onDateChange(d, type) {
        const { obj } = this.state;
        obj[type] = d || '';

        this.setState({ obj });
    }
    handleCancel() {
        this.setState({ showModal: false, showDeleteModal: false });
    }

    handleOk(actionType) {
        switch (actionType) {
            case DM_ADD_ACTION_TYPE:
            this.props.createRC(this.state.obj);
                break;
            case DM_EDIT_ACTION_TYPE:
            this.props.updateRC(this.state.obj);
                break;
            case DM_DELETE_ACTION_TYPE:
            this.props.deleteConfirmedRC(this.state.obj.ID);
                break;
            default: break;
        }
    }

    renderModalFields() {
        const { actionType, obj } = this.state;
        const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;

        return (
            <Form layout={'horizontal'}>
                <FormItem
                     validateStatus = {obj.ID === "" && this.state.errorObj["reasonCategory.ID"] ? 'error' : ""}
                     help = {obj.ID === "" && this.state.errorObj["reasonCategory.ID"]}
                         label={<b>ID <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.ID} placeholder="ID" onChange={e => this.handleFieldChange(e, 'ID')} />
                        :
                        <div>{obj.ID}</div>
                    }
                </FormItem>
                <FormItem
                  validateStatus = {obj.FromCategory === "" && this.state.errorObj["reasonCategory.FromCategory"] ? 'error' : ""}
                  help = {obj.FromCategory === "" && this.state.errorObj["reasonCategory.FromCategory"]}
                      label={<b>From Category <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.FromCategory} placeholder="FromCategory" onChange={e => this.handleFieldChange(e, 'FromCategory')} />
                        :
                        <div>{obj.FromCategory}</div>
                    }
                </FormItem>
                <FormItem
                    validateStatus = {obj.ToCategory === "" && this.state.errorObj["reasonCategory.ToCategory"] ? 'error' : ""}
                    help = {obj.ToCategory === "" && this.state.errorObj["reasonCategory.ToCategory"]}
                        label={<b>To Category <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.ToCategory} placeholder="ToCategory" onChange={e => this.handleFieldChange(e, 'ToCategory')} />
                        :
                        <div>{obj.ToCategory}</div>
                    }
                </FormItem>
                <FormItem
                   validateStatus = {obj.TermDate === "" && this.state.errorObj["reasonCategory.TermDate"] ? 'error' : ""}
                   help = {obj.TermDate === "" && this.state.errorObj["reasonCategory.TermDate"]}
                       label={<b>End Effective Date <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                         <DatePicker
                                className = "CalClass"
                                selected={obj.TermDate}
                                dateFormat={"MM-dd-yyyy"}
                                onChange={(d) => this.onDateChange(d, 'TermDate')}
                                isClearable={true}
                                placeholderText="Select a date"
                              />
                         :
                        <div>{getFormattedDate(obj.TermDate)}</div>
                    }
                </FormItem>
            </Form>
        );
    }

    render() {
        const { title, footer } =
            getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Reason Category');
            return (
                <div>
                   {this.state.data && <DMTable title={<b>Reason Categories Maintenance</b>}
                        tableData={this.state.data}
                        columns={this.columns}
                        handleShowModal={this.handleShowModal}
                        uniqueColumnName='ID'
                        searchField='Description'
                        showModal={this.state.showModal}
                        showDeleteModal={this.state.showDeleteModal}
                        deleteObjId={this.state.deleteObjId}
                        handleOk={this.handleOk}
                        handleCancel={this.handleCancel}
                        modalTitle={title}
                        footer={footer}
                        width={'600px'}
                        renderModalFields={this.renderModalFields}
                    >
                        
                    </DMTable>}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getReasonCategories, getRCDetailsById, getEditRC, initCreateRCObj, initDeleteRCObj, deleteConfirmedRC, updateRC, createRC
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ReasonCategories);