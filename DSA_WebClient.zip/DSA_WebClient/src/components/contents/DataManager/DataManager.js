import React, { Component } from 'react';
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Layout, Menu, Row, Col } from 'antd';

import Employees from './Employees';
import ActivityType from './ActivityType';
import HearingRooms from './HearingRooms';
import DefaultHearingTime from './DefaultHearingTime';
import Holidays from './Holidays';
import Languages from './Languages';
import Offices from './Offices';
import OIPTypes from './OIPTypes';
import ReasonCategories from './ReasonCategories';
import Referrals from './Referrals';
import Regions from './Regions';
import SuspenseCaseReasons from './SuspenseReasons';

const { Content, Sider } = Layout;

const RENDER_BY_TYPE = {
    ActivityType: <ActivityType />,
    DefaultHearingTime: <DefaultHearingTime />,
    Employees: < Employees />,
    HearingRooms: <HearingRooms />,
    Holidays: <Holidays />,
    Languages: <Languages />,
    Offices: <Offices />,
    OIPTypes: <OIPTypes />,
    ReasonCategories: <ReasonCategories />,
    Referrals: <Referrals />,
    Regions: <Regions />,
    SuspenseCaseReasons: <SuspenseCaseReasons /> 
};

class DataManager extends Component {
    constructor(props) {
        super(props);

        this.state = {
            tabValue: 'Employees'
        };

        this.handleLeftNavClick = this.handleLeftNavClick.bind(this);
    }

    handleLeftNavClick(e) {
        this.setState({
            tabValue: e.key
        });
    }

    render() {
        return (
           
        // <ScrollPanel style={{ width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0)" }}>
        <React-Fragment>
                <Layout style={{ height: '100%' }}>
                    <Content>
                 
                        <Layout style={{ height: '100%', background: '#fff' }}>
                         <Sider width={200} style={{ background: '#fff' }}>
                                <Menu
                                    mode="inline"
                                    defaultSelectedKeys={[this.state.tabValue]}
                                    defaultOpenKeys={['1']}
                                    style={{ height: '100%' }}
                                    onClick={this.handleLeftNavClick}
                                >
                                    <Menu.Item key="Employees">
                                        <span>Employees</span>
                                    </Menu.Item>
                                    <Menu.Item key="ActivityType">
                                        <span>Activity Types</span>
                                    </Menu.Item>
                                    <Menu.Item key="HearingRooms">
                                        <span>Hearing Rooms</span>
                                    </Menu.Item>
                                    <Menu.Item key="DefaultHearingTime">
                                        <span>Default Hearing Times</span>
                                    </Menu.Item>
                                    <Menu.Item key="Holidays">
                                        <span>Holidays</span>
                                    </Menu.Item>
                                    <Menu.Item key="Languages">
                                        <span>Languages</span>
                                    </Menu.Item>
                                    <Menu.Item key="Offices">
                                        <span>Offices</span>
                                    </Menu.Item>
                                    <Menu.Item key="OIPTypes">
                                        <span>OIPTypes</span>
                                    </Menu.Item>
                                    <Menu.Item key="ReasonCategories">
                                        <span>Reason Categories</span>
                                    </Menu.Item>
                                    <Menu.Item key="Referrals">
                                        <span>Referrals</span>
                                    </Menu.Item>
                                    <Menu.Item key="Regions">
                                        <span>Regions</span>
                                    </Menu.Item>
                                    <Menu.Item key="SuspenseCaseReasons">
                                        <span>Suspense Case Reasons</span>
                                    </Menu.Item>
                                </Menu>
                            </Sider>
                            <Content style={{ height: "800px" }}>
                                <Row>
                                    <Col span={24}>
                                        {RENDER_BY_TYPE[this.state.tabValue]}
                                    </Col>
                                </Row>
                            </Content>
                        </Layout>
                    </Content>
                </Layout>
                {/* </ScrollPanel> */}
                </React-Fragment>
                );
    }
}

export default DataManager;