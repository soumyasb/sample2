import React, { Component } from 'react';
import { Form, Input, Select, Row, Col, notification } from 'antd';
import { getFormattedDate, dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import DMTable from './DMTable';
import { 
    getOffices, getOfficeDetailsById, getEditOffice, initCreateOfficeObj, initDeleteOfficeObj, deleteConfirmedOffice, updateOffice, createOffice } from "../../../store/actions/dataManagerActions";

import {
    getModalSettings,
    DM_ADD_ACTION_TYPE,
    DM_DELETE_ACTION_TYPE,
    DM_EDIT_ACTION_TYPE,
    DM_DETAILS_ACTION_TYPE
} from './DMTableFns';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    OfficeID: "",
    Name: "",
    AddressLineOne: "",
    City: "",
    Zip: "",
    Zip4: "",
    PhoneNumber: "",
    DistrictID: "",
    EffectiveDate: "",
    NameAbbriv: "",
    FieldFileDsg: "",
    RequestorCode: "",
    FaxNumber: "",
    TerminationDate: ""
}

class Offices extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: this.props.allOfficesList,
            showModal: false,
            errorObj: {},
            obj: {},
        };

        this.columns = [
            {
                title: <b>Name</b>,
                dataIndex: 'Name',
                key: 'Name',
                width: '25%',
                render: (n, obj) => {
                    
                    return <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                        style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                        {n}
                    </a>
                }
            },
            {
                title: <b>Office RU</b>,
                dataIndex: 'OfficeID',
                key: 'OfficeID'
            },
            {
                title: <b>Address</b>,
                dataIndex: 'AddressLineOne',
                key: 'AddressLineOne'
            },
            {
                title: <b>City</b>,
                dataIndex: 'City',
                key: 'City'
            },
            {
                title: <b>Date Terminated</b>,
                dataIndex: 'TerminationDate',
                key: 'TerminationDate',
                render: (item) =>
                {
               return getFormattedDate(item);
                }
            }
        ];

        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }
    componentDidMount(){
        
        this.props.getOffices();
        this.props.initCreateOfficeObj();
                }
                componentDidUpdate(prevProps){
                    
                            if ( prevProps.dataManager.allOfficesList !== this.props.dataManager.allOfficesList && this.props.dataManager.allOfficesList !== undefined) {
                                this.setState({data: this.props.dataManager.allOfficesList});
                            }
                            if ( prevProps.dataManager.createOfficeObj !== this.props.dataManager.createOfficeObj && this.props.dataManager.createOfficeObj !== undefined) {
                                this.setState({cOTemplate: this.props.dataManager.createOfficeObj});
                            }
                            if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                this.setState({errorObj: this.props.dataManager.DMErrorData});
                            }
                            if ( prevProps.dataManager.createOfficeData !== this.props.dataManager.createOfficeData ) {
                                this.props.getOffices();
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.openNotification("Office created successfully!");                              
                        }
                        if ( prevProps.dataManager.dleteConfirmedOfficeData !== this.props.dataManager.dleteConfirmedOfficeData ) {
                            this.setState({showDeleteModal: false});
                            this.props.getOffices();
                            this.openNotification("Office deleted successfully!");                              
                    }
                            if ( prevProps.dataManager.updateOfficeData !== this.props.dataManager.updateOfficeData ) {
                            this.props.getOffices();
                            this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                            this.openNotification("Office updated successfully!");                              
                    }    
                        }

    static getDerivedStateFromProps(props, prevState) {
        const { allOfficesList, DMErrorData } = props.dataManager;
        if (allOfficesList && allOfficesList !== prevState.data) return { data: allOfficesList };
    if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
        return null;
    }
   
    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    handleShowModal(e, actype, obj) {
        if (actype !== DM_ADD_ACTION_TYPE) {
            if (obj) {
                
                const modalObj = cloneDeep(this.state.data.find(d => d.OfficeID === obj.OfficeID));
                this.setState({ obj: modalObj });

                if (actype === DM_EDIT_ACTION_TYPE) {

                }
                if (actype === DM_DETAILS_ACTION_TYPE) {

                }
                if (actype === DM_DELETE_ACTION_TYPE) {
 this.setState({deleteObjId: "Office - "+modalObj.OfficeID})
                }
            }
        }
        else {

            this.setState({ obj: cloneDeep(defaultObj) });
        }

        this.setState({
            actionType: actype,
            showModal: actype !== DM_DELETE_ACTION_TYPE,
            showDeleteModal: actype === DM_DELETE_ACTION_TYPE
        });
    }

    handleCancel() {
        this.setState({ showModal: false, showDeleteModal: false });
    }

    handleOk(actionType) {
        const  obj  = cloneDeep(this.state.obj);
        obj.EffectiveDate = dateFormatFunc(obj.EffectiveDate);
        obj.TerminationDate = dateFormatFunc(obj.TerminationDate);
        switch (actionType) {
            case DM_ADD_ACTION_TYPE:
            this.props.createOffice(obj);
                break;
            case DM_EDIT_ACTION_TYPE:
            this.props.updateOffice(obj);
                break;
            case DM_DELETE_ACTION_TYPE:
            this.props.deleteConfirmedOffice(obj.OfficeID);
                break;
            default: break;
        }
    }

    handleFieldChange(e, field) {
        const { obj } = this.state;

        switch (field) {
            case 'OfficeID':
            case 'Name':
            case 'AddressLineOne':
            case 'City':
            case 'Zip':
            case 'Zip4':
            case 'NameAbbriv':
            case 'FieldFileDsg':
            case 'PhoneNumber':
            case 'FaxNumber':
            case 'RequestorCode':
                obj[field] = e.target.value;
                break;
            case 'DistrictID':
            if(!e)
            {
                obj[field] = '';
            }
            else
            {
                obj[field] = e;
            }
                break;
            default:
                break
        }

        this.setState({ obj });
    }

    onDateChange(d, type) {
        const { obj } = this.state;
        obj[type] = d || '';

        this.setState({ obj });
    }

    renderModalFields() {
        const { actionType, obj, cOTemplate } = this.state;
        const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;

        return (
            <Form layout={'horizontal'}>
                <Row>
                    <Col span={4}>
                        <FormItem
                           validateStatus = {obj.OfficeID === "" && this.state.errorObj["office.OfficeID"] ? 'error' : ""}
                           help = {obj.OfficeID === "" && this.state.errorObj["office.OfficeID"] ? this.state.errorObj["office.OfficeID"] : ""}
                               label={<b>Office RU <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.OfficeID} placeholder="Office RU" onChange={e => this.handleFieldChange(e, 'OfficeID')} />
                                :
                                <div>{obj.OfficeID}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={8}></Col>
                    <Col span={11}>
                        <FormItem
                          validateStatus = {obj.Name === "" && this.state.errorObj["office.Name"] ? 'error' : ""}
                          help = {obj.Name === "" && this.state.errorObj["office.Name"]}
                              label={<b>Office Name <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.Name} placeholder="Office Name" onChange={e => this.handleFieldChange(e, 'Name')} />
                                :
                                <div>{obj.Name}</div>
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={11}>
                        <FormItem
                           validateStatus = {obj.AddressLineOne === "" && this.state.errorObj["office.AddressLineOne"] ? 'error' : ""}
                           help = {obj.AddressLineOne === "" && this.state.errorObj["office.AddressLineOne"]}
                               label={<b>Address <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.AddressLineOne} placeholder="Address" onChange={e => this.handleFieldChange(e, 'AddressLineOne')} />
                                :
                                <div>{obj.AddressLineOne}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={11}>
                        <FormItem
                           validateStatus = {obj.City === "" && this.state.errorObj["office.City"] ? 'error' : ""}
                           help = {obj.City === "" && this.state.errorObj["office.City"]}
                               label={<b>City <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.City} placeholder="City" onChange={e => this.handleFieldChange(e, 'City')} />
                                :
                                <div>{obj.City}</div>
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={5}>
                        <FormItem
                           validateStatus = {obj.Zip === "" && this.state.errorObj["office.Zip"] ? 'error' : ""}
                           help = {obj.Zip === "" && this.state.errorObj["office.Zip"]}
                               label={<b>Zip<font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.Zip} placeholder="Zip" onChange={e => this.handleFieldChange(e, 'Zip')} />
                                :
                                <div>{obj.Zip}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={5}>
                        <FormItem
                           validateStatus = {obj.Zip4 === "" && this.state.errorObj["office.Zip4"] ? 'error' : ""}
                           help = {obj.Zip4 === "" && this.state.errorObj["office.Zip4"]}
                               label={<b>Zip 4 <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.Zip4} placeholder="Zip 4" onChange={e => this.handleFieldChange(e, 'Zip4')} />
                                :
                                <div>{obj.Zip4}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={11}>
                        <FormItem
                            validateStatus = {obj.DistrictID === "" && this.state.errorObj["office.DistrictID"] ? 'error' : ""}
                            help = {obj.DistrictID === "" && this.state.errorObj["office.DistrictID"]}
                                label={<b>District ID <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Select allowClear={true} id = "SDI" onFocus={(e) => {
                                    document.getElementById("SDI").click();
                                                                           }} showSearch optionFilterProp= "children" filterOption = {true}  value={obj.DistrictID} placeholder="DistrictID" onChange={e => this.handleFieldChange(e, 'DistrictID')} >
                                    {cOTemplate.districtOfficeList.map(off => <Option key={off.Value} value={off.Value}>{off.Text}</Option>)}
                                </Select>
                                :
                                <div>{obj.DistrictID && cOTemplate.districtOfficeList.find(off => off.Value === obj.OfficeID).Text}</div>
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={5}>
                        <FormItem
                           validateStatus = {obj.NameAbbriv === "" && this.state.errorObj["office.NameAbbriv"] ? 'error' : ""}
                           help = {obj.NameAbbriv === "" && this.state.errorObj["office.NameAbbriv"]}
                               label={<b>Office ID <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.NameAbbriv} placeholder="Office ID" onChange={e => this.handleFieldChange(e, 'NameAbbriv')} />
                                :
                                <div>{obj.NameAbbriv}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={5}>
                        <FormItem
                           validateStatus = {obj.FieldFileDsg === "" && this.state.errorObj["office.FieldFileDsg"] ? 'error' : ""}
                           help = {obj.FieldFileDsg === "" && this.state.errorObj["office.FieldFileDsg"]}
                               label={<b>Field File Abbr <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.FieldFileDsg} placeholder="Field File Abbr" onChange={e => this.handleFieldChange(e, 'FieldFileDsg')} />
                                :
                                <div>{obj.FieldFileDsg}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={11}>
                        <FormItem
                            validateStatus = {obj.EffectiveDate === "" && this.state.errorObj["office.EffectiveDate"] ? 'error' : ""}
                            help = {obj.EffectiveDate === "" && this.state.errorObj["office.EffectiveDate"]}
                                label={<b>Effective Date <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <DatePicker
                                className = "CalClass"
                                selected={new Date(obj.EffectiveDate)}
                                dateFormat={"MM-dd-yyyy"}
                                onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                                isClearable={true}
                                placeholderText="Select a date"
                              />
                                :
                                <div>{getFormattedDate(obj.EffectiveDate)}</div>
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={11}>
                        <FormItem
                            validateStatus = {obj.PhoneNumber === "" && this.state.errorObj["office.PhoneNumber"] ? 'error' : ""}
                            help = {obj.PhoneNumber === "" && this.state.errorObj["office.PhoneNumber"]}
                                label={<b>Phone Number <font color="red">*</font></b>}
                        >
                            {isEditable ?
                                <Input value={obj.PhoneNumber} placeholder="Phone Number" onChange={e => this.handleFieldChange(e, 'PhoneNumber')} />
                                :
                                <div>{obj.PhoneNumber}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={11}>
                        <FormItem
                           validateStatus = {obj.TerminationDate === "" && this.state.errorObj["office.TerminationDate"] ? 'error' : ""}
                           help = {obj.TerminationDate === "" && this.state.errorObj["office.TerminationDate"]}
                               label={<b>Termination Date <font color="red">*</font></b>}
                        >
                            {isEditable ?
                              <DatePicker
                              className = "CalClass"
                              selected={new Date(obj.TerminationDate)}
                              dateFormat={"MM-dd-yyyy"}
                              onChange={(d) => this.onDateChange(d, 'TerminationDate')}
                              isClearable={true}
                              placeholderText="Select a date"
                            />
                                :
                                <div>{getFormattedDate(obj.TerminationDate)}</div>
                            }
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={11}>
                        <FormItem
                           validateStatus = {obj.FaxNumber === "" && this.state.errorObj["office.FaxNumber"] ? 'error' : ""}
                           help = {obj.FaxNumber === "" && this.state.errorObj["office.FaxNumber"]}
                               label={<b>Fax Number</b>}
                        >
                            {isEditable ?
                                <Input value={obj.FaxNumber} placeholder="Fax Number" onChange={e => this.handleFieldChange(e, 'FaxNumber')} />
                                :
                                <div>{obj.FaxNumber}</div>
                            }
                        </FormItem>
                    </Col>
                    <Col span={1}></Col>
                    <Col span={11}>
                        <FormItem
                            validateStatus = {obj.RequestorCode === "" && this.state.errorObj["office.RequestorCode"] ? 'error' : ""}
                            help = {obj.RequestorCode === "" && this.state.errorObj["office.RequestorCode"]}
                                label={<b>Requestor Code</b>}
                        >
                            {isEditable ?
                                <Input value={obj.RequestorCode} placeholder="Requestor Code" onChange={e => this.handleFieldChange(e, 'RequestorCode')} />
                                :
                                <div>{obj.RequestorCode}</div>
                            }
                        </FormItem>
                    </Col>
                </Row>
            </Form>
        );
    }

    render() {
        const { title, footer } =
            getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Office');

        return (
            <div>
                 {this.state.data &&    <DMTable title={<b>Offices</b>}
                    tableData={this.state.data}
                    columns={this.columns}
                    handleShowModal={this.handleShowModal}
                    uniqueColumnName='OfficeID'
                    searchField={['Name', 'OfficeID', 'AddressLineOne', 'City']}
                    showModal={this.state.showModal}
                    showDeleteModal={this.state.showDeleteModal}
                    deleteObjId={this.state.deleteObjId}
                    handleOk={this.handleOk}
                    handleCancel={this.handleCancel}
                    modalTitle={title}
                    footer={footer}
                    width={'600px'}
                    renderModalFields={this.renderModalFields}
                >
                </DMTable>}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getOffices, getOfficeDetailsById, getEditOffice, initCreateOfficeObj, initDeleteOfficeObj, deleteConfirmedOffice, updateOffice, createOffice
        },
        dispatch
    );
};


export default connect(mapStateToProps, mapDispatchToProps)(Offices);