import React, { Component } from 'react';
import DMTable from './DMTable';
import { dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import { Form, Input, Select, notification, Modal, Button } from 'antd';
import { 
    getInitHearingRoom, getHearingRoomsByOfficeId, getEditHR, initCreateHRObj, initDeleteHRObj, deleteConfirmedHR, updateHR, createHR } from "../../../store/actions/dataManagerActions";
    import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';    

    const FormItem = Form.Item;
    const dateFormat = 'MM-dd-yyyy';
    const { Option } = Select;
    const formItemLayout = {
        labelCol: { span: 9 },
        wrapperCol: { span: 15 },
    };

    const hearingRoom = {
        HearingLocationId: 0,
        OfficeID: '',
        RoomNumber: '',
        Description: '',
        DateClosed: null,
        message: '',
        OfficeList: []
    }

    class HearingRooms extends Component {
        constructor(props) {
            super(props);
    
            this.state = {
                data: this.props.hRsByOfficeIdData,
                showModal: false,
                showErrorModal: false,
                errorObj: {},
                DateClosed: null,
                obj: {},
            };

            this.columns = [
                {
                    title: <b>Hearing Location Id</b>,
                    dataIndex: 'HearingLocationId',
                    key: 'HearingLocationId',
                    render: (c, obj) =>
                        <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                            style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                            {c}
                        </a>
                },
                {
                    title: <b>Office</b>,
                    dataIndex: 'OfficeID',
                    key: 'OfficeID'
                },
                {
                    title: <b>Room Number</b>,
                    dataIndex: 'RoomNumber',
                    key: 'RoomNumber'
                },
                {
                    title: <b>Description</b>,
                    dataIndex: 'Description',
                    key: 'Description',
                },
                {
                    title: <b>Date Closed</b>,
                    dataIndex: 'DateClosed',
                    key: 'DateClosed',
                    render: (item) =>
                    {
                  return dateFormatFunc(item);
                }}
            ];
    
            this.handleShowModal = this.handleShowModal.bind(this);
            this.handleCancel = this.handleCancel.bind(this);
            this.handleOk = this.handleOk.bind(this);
            this.renderModalFields = this.renderModalFields.bind(this);
            this.handleOfficeChange = this.handleOfficeChange.bind(this);
            this.handleFieldChange =  this.handleFieldChange.bind(this);
            this.openNotification = this.openNotification.bind(this);
            this.onDateChange = this.onDateChange.bind(this);
        }
        handleFieldChange(e, type) {
            
        const {obj} = this.state;
        
        if(type === 'DateClosed')
        {
            obj[type] = e;
        }
        else
        {
            obj[type] = e.target.value;
        }
        this.setState({obj});
        }
     
        componentDidMount(){
            
            this.props.getInitHearingRoom();
                    }
                    componentDidUpdate(prevProps){
                        
                                if ( prevProps.dataManager.initHRData !== this.props.dataManager.initHRData && this.props.dataManager.initHRData !== undefined) {
                                    this.setState({initHRData: this.props.dataManager.initHRData});
                                }
                                if ( prevProps.dataManager.hRsByOfficeIdData !== this.props.dataManager.hRsByOfficeIdData && this.props.dataManager.hRsByOfficeIdData !== undefined )
                                {
                                        this.setState({data: this.props.dataManager.hRsByOfficeIdData});
                                }
                                if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                    if(typeof(this.props.dataManager.DMErrorData) === "string"){
                                      this.setState({ errorObj: this.props.dataManager.DMErrorData, showErrorModal: true, showModal: false});
                                    }
                                    else
                                    {
                                      this.setState({errorObj: this.props.dataManager.DMErrorData});
                                    } 
                                }
                                if ( prevProps.dataManager.dleteConfirmedHRData !== this.props.dataManager.dleteConfirmedHRData ) {
                                    this.setState({showDeleteModal: false, data: this.props.dataManager.dleteConfirmedHRData});
                                    this.props.getHearingRoomsByOfficeId(this.props.dataManager.dleteConfirmedHRData[0].OfficeID);
                                    this.openNotification("Hearing Room closed successfully!");                              
                            }
                                if ( prevProps.dataManager.createHRData !== this.props.dataManager.createHRData ) {
                                    this.props.getHearingRoomsByOfficeId(this.props.dataManager.createHRData[0].OfficeID);
                                    this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                    this.openNotification("Hearing Room created successfully!");                              
                            }
                                if ( prevProps.dataManager.updateHRData !== this.props.dataManager.updateHRData ) {
                                    this.props.getHearingRoomsByOfficeId(this.props.dataManager.updateHRData[0].OfficeID);
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.openNotification("Hearing Room updated successfully!");                              
                        }      
                            }
    
        static getDerivedStateFromProps(props, prevState) {
            const { initHRData, hRsByOfficeIdData, DMErrorData } = props.dataManager;
            if (initHRData && initHRData !== prevState.initHRData) return { initHRData: initHRData };
            if (hRsByOfficeIdData && hRsByOfficeIdData !== prevState.data) return { data: hRsByOfficeIdData };
            if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
            return null;
        }
        handleOfficeChange(e) {
            this.props.getHearingRoomsByOfficeId(e);
        }
        openNotification = (msg) => {
            notification.open({
              message: 'SUCCESS',
              description: msg,
              style: {
                width: 600,
                marginLeft: 335 - 600,
                backgroundColor: "#9cd864",
                fontWeight: 'bold'
              },
            });
          }
        
        handleShowModal(e, actype, obj) {
            
            if (actype !== DM_ADD_ACTION_TYPE) {
                if (obj) {
                    const modalObj = cloneDeep(this.state.data.find(d => d.HearingLocationId === obj.HearingLocationId));
                    this.setState({ obj: modalObj });
                    if (actype === DM_DELETE_ACTION_TYPE) {
                        this.setState({deleteObjId: "Hearing Room - "+modalObj.HearingLocationId})
                    }
                }
            }
            else {    
                this.setState({ obj: cloneDeep(hearingRoom) });
            }
    
            this.setState({
                actionType: actype,
                showModal: actype !== DM_DELETE_ACTION_TYPE,
                showDeleteModal: actype === DM_DELETE_ACTION_TYPE
            });
        }
        handleCancel() {
            this.setState({ showModal: false, showDeleteModal: false });
        }
    
        handleOk(actionType) {
            switch (actionType) {
                case DM_ADD_ACTION_TYPE:
                let createObj = { HearingRoom: {
                    HearingLocationId: this.state.obj.HearingLocationId,
                    OfficeID: this.state.obj.OfficeID,
                    RoomNumber: this.state.obj.RoomNumber,
                    Description: this.state.obj.Description,
                    DateClosed: this.state.obj.DateClosed},
                    OfficeList: this.state.obj.OfficeList,
                    message: this.state.obj.message
                } 
                this.props.createHR(createObj);
                    break;
                case DM_EDIT_ACTION_TYPE:
                this.props.updateHR(this.state.obj);
                    break;
                case DM_DELETE_ACTION_TYPE:
                this.props.deleteConfirmedHR(this.state.obj.HearingLocationId);
                    break;
                default: break;
            }
        }
    
        renderModalFields() {
            const { actionType, obj } = this.state;
            const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;
            return (
                <Form layout={'horizontal'}>
                    <FormItem
                         validateStatus = {this.state.errorObj !== {}  && obj.HearingLocationId === "" && this.state.errorObj["hearingRoom.HearingLocationId"] ? 'error' : ""}
                         help = {this.state.errorObj !== {}  && obj.HearingLocationId === "" && this.state.errorObj["hearingRoom.HearingLocationId"]}
                         label={<b>Hearing Location ID </b>}
                         {...formItemLayout}
                    >
                        {isEditable ?
                            <Input value={obj.HearingLocationId} placeholder="Hearing Location Id" onChange={e => this.handleFieldChange(e, 'HearingLocationId')} />
                            :
                            <div>{obj.HearingLocationId}</div>
                        }
                    </FormItem>
                    <FormItem
                         validateStatus = {this.state.errorObj !== {}  && obj.OfficeID === "" && this.state.errorObj["hearingRoom.OfficeID"] ? 'error' : ""}
                         help = {this.state.errorObj !== {}  && obj.OfficeID === "" && this.state.errorObj["hearingRoom.OfficeID"]}
                         label={<b>Office ID <font color="red">*</font></b>}
                         {...formItemLayout}
                    >
                        {isEditable ?
                            <Input value={obj.OfficeID} placeholder="Office" onChange={e => this.handleFieldChange(e, 'OfficeID')} />
                            :
                            <div>{obj.OfficeID}</div>
                        }
                    </FormItem>
                    <FormItem
                        validateStatus = {this.state.errorObj !== {}  && obj.RoomNumber === "" && this.state.errorObj["hearingRoom.RoomNumber"] ? 'error' : ""}
                        help = {this.state.errorObj !== {}  && obj.RoomNumber === "" && this.state.errorObj["hearingRoom.RoomNumber"]}
                        label={<b>Room Number <font color="red">*</font></b>}
                        {...formItemLayout}
                    >
                        {isEditable ?
                            <Input value={obj.RoomNumber} placeholder="Room Number" onChange={e => this.handleFieldChange(e, 'RoomNumber')} />
                            :
                            <div>{obj.RoomNumber}</div>
                        }
                    </FormItem>
                    <FormItem
                         validateStatus = {this.state.errorObj !== {}  && obj.Description === "" && this.state.errorObj["hearingRoom.Description"] ? 'error' : ""}
                         help = {this.state.errorObj !== {}  && obj.Description === "" && this.state.errorObj["hearingRoom.Description"]}
                         label={<b>Description <font color="red">*</font></b>}
                         {...formItemLayout}
                    >
                        {isEditable ?
                            <Input value={obj.Description} placeholder="Description" onChange={e => this.handleFieldChange(e, 'Description')} />
                            :
                            <div>{obj.Description}</div>
                        }
                    </FormItem>
                    <FormItem
                         validateStatus = {this.state.errorObj !== {}  && obj.DateClosed === "" && this.state.errorObj["hearingRoom.DateClosed"] ? 'error' : ""}
                         help = {this.state.errorObj !== {}  && obj.DateClosed === "" && this.state.errorObj["hearingRoom.DateClosed"]}
                         label={<b>Date Closed </b>}
                         {...formItemLayout}
                    >
                        {isEditable ?
                        // <DatePicker value={moment(obj.DateClosed).isValid() ? moment(obj.DateClosed) : null} format={dateFormat} onChange={(d, ds) => { this.onDateChange(d, ds, 'DateClosed') }}/>
                        <DatePicker
                        className = "CalClass"
                        selected={obj.DateClosed}
                        dateFormat={dateFormat}
                        onChange={(d) => this.onDateChange(d, 'DateClosed')}
                        isClearable={true}
                        placeholderText="Select a date"
                      />
                        :
                     <div>{dateFormatFunc(obj.DateClosed)}</div>
                        }
                    </FormItem>
                </Form>
            );
        }
        onDateChange(d, type) {
            
            const { obj } = this.state;
            obj[type] = d || '';
    
            this.setState({ obj });
        }
        render() {
            const { title, footer } =
                getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Hearing Room');
                return (
                    <div>
                       <Modal maskClosable={false} visible={this.state.showErrorModal}   title="ERROR"
          footer={<Button onClick={(e) => {this.setState({showErrorModal: false})}}>OK</Button>}><div>{this.state.errorObj}</div></Modal>    
                        {this.state.initHRData && <div style={{marginLeft: '2%', marginTop: '2%'}}><b>Select an Office</b>: <Select id = "SOff2" onFocus={(e) => {
                                document.getElementById("SOff2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleOfficeChange(e)}
                                        showArrow={true} size={"small"} style={{ marginLeft: '2%', width: '30%' }}>
                                        {this.state.initHRData.OfficeList.map(item =>
                                            <Option key={item.Value} value={item.Value}>{item.Text}</Option>
                                        )}
                                    </Select></div>}
                                    <br/>
                       {this.state.data && <DMTable title={<b>Hearing Room Maintenance</b>}
                            tableData={this.state.data}
                            columns={this.columns}
                            handleShowModal={this.handleShowModal}
                            uniqueColumnName='HearingLocationId'
                            searchField='Description'
                            showModal={this.state.showModal}
                            showDeleteModal={this.state.showDeleteModal}
                            handleOk={this.handleOk}
                            handleCancel={this.handleCancel}
                            modalTitle={title}
                            footer={footer}
                            deleteObjId={this.state.deleteObjId}
                            width={'600px'}
                            renderModalFields={this.renderModalFields}
                        >
                </DMTable>}
                </div>
            )
        }
    }
    
    const mapStateToProps = state => {
        return {
          dataManager: state.dataManager
        };
    };
    
    const mapDispatchToProps = dispatch => {
        return bindActionCreators(
            {
                getInitHearingRoom, getHearingRoomsByOfficeId, getEditHR, initCreateHRObj, initDeleteHRObj, deleteConfirmedHR, updateHR, createHR
            },
            dispatch
        );
    };
    
    export default connect(mapStateToProps, mapDispatchToProps)(HearingRooms);