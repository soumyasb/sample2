import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { Icon, Form, Input, Checkbox, notification } from 'antd';
import { getFormattedDate } from './../commonFuncs.js';
import { 
    getAllActivityTypes, getActTypeDetailsById, getEditActType, initCreateActTypeObj, initDeleteActTypeObj, deleteConfirmedActType, updateActType, createActType } from "../../../store/actions/dataManagerActions";
import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';
    
    const FormItem = Form.Item;
    
    const formItemLayout = {
        labelCol: { span: 9 },
        wrapperCol: { span: 15 },
    };
    
    const defaultObj = {
        ID: 0,
        Code: null,
        Description: null,
        Abbr: null,
        HearingTypes: null,
        Confidential: false,
        TermDate: null,
        lastUpdatedBy: null,
        lastUpdetedDate: null
    }

class ActivityType extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: this.props.allActTypesList,
            TermDate: null,
            errorObj: {},
            showModal: false,
            obj: {},
        };

        this.columns = [
            {
                title: <b>Code</b>,
                dataIndex: 'Code',
                key: 'Code',
                render: (c, obj) =>
                    <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                        style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                        {c}
                    </a>
            },
            {
                title: <b>Abbreviation</b>,
                dataIndex: 'Abbr',
                key: 'Abbr'
            },
            {
                title: <b>Description</b>,
                dataIndex: 'Description',
                key: 'Description'
            },
            {
                title: <b>End Effective Date</b>,
                dataIndex: 'TermDate',
                key: 'TermDate',
                render: (item) =>
                {
               return getFormattedDate(item);
                }
            },
            {
                title: <b>Confidential</b>,
                dataIndex: 'Confidential',
                key: 'Confidential',
                render: c => c ? <Icon type="check" /> : <Icon type="close" />
            },
        ];

        this.handleShowModal = this.handleShowModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.renderModalFields = this.renderModalFields.bind(this);
        this.handleFieldChange =  this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount(){
        
        this.props.getAllActivityTypes();
                }
                componentDidUpdate(prevProps){
                    
                            if ( prevProps.dataManager.allActTypesList !== this.props.dataManager.allActTypesList && this.props.dataManager.allActTypesList !== undefined) {
                                this.setState({data: this.props.dataManager.allActTypesList});
                            }
                            if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                                this.setState({errorObj: this.props.dataManager.DMErrorData});
                            }
                            if ( prevProps.dataManager.createActType !== this.props.dataManager.createActType ) {
                                this.props.getAllActivityTypes();
                                this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                                this.openNotification("Activity created successfully!");                              
                        }
                        if ( prevProps.dataManager.dleteConfirmedActTypeData !== this.props.dataManager.dleteConfirmedActTypeData ) {
                            this.props.getAllActivityTypes();
                            this.setState({showDeleteModal: false});
                            this.openNotification("Activity Type deleted successfully!");                              
                    }
                            if ( prevProps.dataManager.updateActTypeData !== this.props.dataManager.updateActTypeData ) {
                                this.props.getAllActivityTypes();
                            this.setState({actionType: DM_DETAILS_ACTION_TYPE});
                            this.openNotification("Activity updated successfully!");                              
                    }    
                        }

    static getDerivedStateFromProps(props, prevState) {
        const { allActTypesList, DMErrorData } = props.dataManager;
        if (allActTypesList && allActTypesList !== prevState.data) return { data: allActTypesList };
    if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
        return null;
    }
   
    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    handleFieldChange(e, field) {
        const { obj } = this.state;

        switch (field) {
            case 'Code':
            case 'Abbr':
            case 'Description':
                obj[field] = e.target.value;
                break;
            case 'Confidential':
                obj[field] = e.target.checked;
                break;
            default:
                break
        }

        this.setState({ obj });
    }

    onDateChange(d, type) {
        const { obj } = this.state;
        obj[type] = d;

        this.setState({ obj });
    }

    handleShowModal(e, actype, obj) {
        
        if (actype !== DM_ADD_ACTION_TYPE) {
            if (obj) {
                const modalObj = cloneDeep(this.state.data.find(d => d.ID === obj.ID));
                this.setState({ obj: modalObj });

                if (actype === DM_EDIT_ACTION_TYPE) {

                }
                if (actype === DM_DETAILS_ACTION_TYPE) {

                }
                if (actype === DM_DELETE_ACTION_TYPE) {
                    this.setState({deleteObjId: modalObj.Description+" activity"})
                }
            }
        }
        else {

            this.setState({ obj: cloneDeep(defaultObj) });
        }

        this.setState({
            actionType: actype,
            showModal: actype !== DM_DELETE_ACTION_TYPE,
            showDeleteModal: actype === DM_DELETE_ACTION_TYPE
        });
    }

    handleCancel() {
        this.setState({ showModal: false, showDeleteModal: false });
    }

    handleOk(actionType) {
        switch (actionType) {
            case DM_ADD_ACTION_TYPE:
            this.props.createActType(this.state.obj);
                break;
            case DM_EDIT_ACTION_TYPE:
            let {obj} = this.state;
            obj.HearingTypes = "";
            this.props.updateActType(obj);
                break;
            case DM_DELETE_ACTION_TYPE:
            this.props.deleteConfirmedActType(this.state.obj.ID);
                break;
            default: break;
        }
    }

    renderModalFields() {
        const { actionType, obj } = this.state;
        const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;

        return (
            <Form layout={'horizontal'}>
                <FormItem
                     validateStatus = {this.state.errorObj !== {} && (this.state.errorObj["Code"] || this.state.errorObj["Activity Code"]) ? 'error' : ""}
                     help = {this.state.errorObj !== {}  && (this.state.errorObj["Code"] || this.state.errorObj["Activity Code"])}
                         label={<b>Code <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.Code} placeholder="Code" onChange={e => this.handleFieldChange(e, 'Code')} />
                        :
                        <div>{obj.Code}</div>
                    }
                </FormItem>
                <FormItem
                    validateStatus = {this.state.errorObj !== {}  && this.state.errorObj["Abbr"] ? 'error' : ""}
                    help = {this.state.errorObj !== {}  && this.state.errorObj["Abbr"]}
                        label={<b>Abbreviation <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.Abbr} placeholder="Abbreviation" onChange={e => this.handleFieldChange(e, 'Abbr')} />
                        :
                        <div>{obj.Abbr}</div>
                    }
                </FormItem>
                <FormItem
                 validateStatus = {this.state.errorObj !== {}  && this.state.errorObj["Description"] ? 'error' : ""}
                 help = {this.state.errorObj !== {}  && this.state.errorObj["Description"]}
                     label={<b>Description <font color="red">*</font></b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Input value={obj.Description} placeholder="Description" onChange={e => this.handleFieldChange(e, 'Description')} />
                        :
                        <div>{obj.Description}</div>
                    }
                </FormItem>
                <FormItem style = {{lineHeight: "20px"}}
                     validateStatus = {this.state.errorObj !== {}  && this.state.errorObj[".TermDate"] ? 'error' : ""}
                     help = {this.state.errorObj !== {}  && this.state.errorObj["TermDate"]}
                         label={<b>End Effective Date </b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                    <DatePicker
                    className = "CalClass"
                    selected={obj.TermDate}
                    dateFormat={"MM-dd-yyyy"}
                    onChange={(d) => this.onDateChange(d, 'TermDate')}
                    isClearable={true}
                    placeholderText="Select a date"
                  />
                        :
                        <React-Fragment>{getFormattedDate(obj.TermDate)}</React-Fragment>
                    }
                </FormItem>
                <FormItem
                     validateStatus = {this.state.errorObj !== {}  && this.state.errorObj["Confidential"] ? 'error' : ""}
                     help = {this.state.errorObj !== {}  && this.state.errorObj["Confidential"]}
                         label={<b>Confidential     </b>}
                    {...formItemLayout}
                >
                    {isEditable ?
                        <Checkbox checked={obj.Confidential}  onChange={e => this.handleFieldChange(e, 'Confidential')} placeholder="input placeholder" />
                        :
                        <div>{obj.Confidential ?  <Icon type="check"/> : <Icon type="close"/>}</div>
                    }
                </FormItem>
            </Form>
        );
    }

    render() {
        const { title, footer } =
            getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Activity Type');
            return (
              <div>
                   {this.state.data &&  <DMTable title={<b>Activity Type Maintenance</b>}
                        tableData={this.state.data}
                        columns={this.columns}
                        handleShowModal={this.handleShowModal}
                        uniqueColumnName='Code'
                        searchField='Description'
                        showModal={this.state.showModal}
                        showDeleteModal={this.state.showDeleteModal}
                        deleteObjId={this.state.deleteObjId}
                        handleOk={this.handleOk}
                        handleCancel={this.handleCancel}
                        modalTitle={title}
                        footer={footer}
                        width={'600px'}
                        renderModalFields={this.renderModalFields}
                    >
                    </DMTable>}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
      dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getAllActivityTypes, getActTypeDetailsById, getEditActType, initCreateActTypeObj, initDeleteActTypeObj, deleteConfirmedActType, updateActType, createActType
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ActivityType);