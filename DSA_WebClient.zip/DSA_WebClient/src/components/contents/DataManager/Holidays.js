import React, { Component } from 'react';
import DMTable from './DMTable';
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import { getMonthDay, getFormattedDate, dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { Form, notification, Modal } from 'antd';
import { 
    getHolidays, getHolidayDetailsById, getEditHoliday, initCreateHolidayObj, initDeleteHolidayObj, deleteConfirmedHoliday, updateHoliday, createHoliday } from "../../../store/actions/dataManagerActions";
import {
        getModalSettings,
        DM_ADD_ACTION_TYPE,
        DM_DELETE_ACTION_TYPE,
        DM_EDIT_ACTION_TYPE,
        DM_DETAILS_ACTION_TYPE
    } from './DMTableFns';
    
    const FormItem = Form.Item;
    
    const formItemLayout = {
        labelCol: { span: 9 },
        wrapperCol: { span: 15 },
    };
    
    const defaultObj = {
        ID: -1,
        HolidayDate: null,
        TermDate: null,
        LastUpdatedBy: null,
        LastUpdatedDate: null,
        CCYY: ''
    }
    
    class Holidays extends Component {
        constructor(props) {
            super(props);
    
            this.state = {
                data: this.props.allHolidaysList,
                errorObj: {},
                showModal: false,
                obj: {},
            };
    
            this.columns = [
                {
                    title: <b>Holiday</b>,
                    dataIndex: 'HolidayDate',
                    key: 'HolidayDate',
                    render: (c, obj) =>
                        <a onClick={e => this.handleShowModal(e, DM_DETAILS_ACTION_TYPE, obj)}
                            style={{ textDecoration: 'underline', color: '#40a9ff' }}>
                            {getMonthDay(c)}
                        </a>
                },
                {
                    title: <b>Year</b>,
                    dataIndex: 'CCYY',
                    key: 'CCYY',
                    filters: this.state.yearFilters,
                    onFilter: (value, record) => record.CCYY === value
                }
            ];
    
            this.handleShowModal = this.handleShowModal.bind(this);
            this.handleCancel = this.handleCancel.bind(this);
            this.handleOk = this.handleOk.bind(this);
            this.onDateChange = this.onDateChange.bind(this);
            this.renderModalFields = this.renderModalFields.bind(this);
            this.openNotification = this.openNotification.bind(this);
        }
    
        componentDidMount() {
            this.props.getHolidays();
        }
        componentDidUpdate(prevProps){
            
                    if ( prevProps.dataManager.allHolidaysList !== this.props.dataManager.allHolidaysList && this.props.dataManager.allHolidaysList !== undefined) {
                        this.setState({data: this.props.dataManager.allHolidaysList, yearFilters: [...new Set(this.props.dataManager.allHolidaysList.map(y => y.CCYY))].map(y => {
                            return {
                                text: y,
                                value: y
                            };
                        })});
                    }
                    if ( prevProps.dataManager.DMErrorData !== this.props.dataManager.DMErrorData && this.props.dataManager.DMErrorData !== undefined) {
                        this.setState({errorObj: this.props.dataManager.DMErrorData});
                        if(typeof this.props.dataManager.DMErrorData === 'string')
                        {
                            Modal.error(       {
                                title: "Error"
                                ,
                                content: (
                                  <div>
                              {this.props.dataManager.DMErrorData}
                                  </div>
                                ),
                                onOk() {this.setState({showModal: false})},
                              });
                        } 
                    }
                    if ( prevProps.dataManager.createHolidayData !== this.props.dataManager.createHolidayData ) {
                        this.setState({actionType: DM_DETAILS_ACTION_TYPE, obj: this.props.dataManager.createHolidayData.employee});
                        this.openNotification("Holiday created successfully!");                              
                }
                if ( prevProps.dataManager.dleteConfirmedHolidayData !== this.props.dataManager.dleteConfirmedHolidayData ) {
                    this.setState({showDeleteModal: false, data: this.props.dataManager.dleteConfirmedHolidayData});
                    this.props.getHolidays();
                    this.openNotification("Holiday terminated successfully!");                              
            }
                if ( prevProps.dataManager.updateHolidayData !== this.props.dataManager.updateHolidayData ) {
                    this.setState({actionType: DM_DETAILS_ACTION_TYPE, data: this.props.dataManager.updateHolidayData});
                    this.openNotification("Holiday updated successfully!");                              
            }
                }
        static getDerivedStateFromProps(props, prevState) {
            const { allHolidaysList, createHolidayData, DMErrorData, updateHolidayData } = props.dataManager;
            if (allHolidaysList && allHolidaysList !== prevState.data) return { data: allHolidaysList, yearFilters: [...new Set(allHolidaysList.map(y => y.CCYY))].map(y => {
                return {
                    text: y,
                    value: y
                };
            }) };
            if (DMErrorData && DMErrorData !== prevState.errorObj) return { errorObj: DMErrorData };
                if (createHolidayData && createHolidayData !== prevState.obj) return { obj: createHolidayData };
                if (updateHolidayData && updateHolidayData !== prevState.data) return { 
                    data: updateHolidayData };
                    return null;
        }
        openNotification = (msg) => {
            notification.open({
              message: 'SUCCESS',
              description: msg,
              style: {
                width: 600,
                marginLeft: 335 - 600,
                backgroundColor: "#9cd864",
                fontWeight: 'bold'
              },
            });
          }
        handleShowModal(e, actype, obj) {
            if (actype !== DM_ADD_ACTION_TYPE) {
                if (obj) {
                    const modalObj = cloneDeep(this.state.data.find(d => d.HolidayDate === obj.HolidayDate));
                this.setState({ obj: modalObj });

                    if (actype === DM_EDIT_ACTION_TYPE) {
    
                    }
                    if (actype === DM_DETAILS_ACTION_TYPE) {
    
                    }
                    if (actype === DM_DELETE_ACTION_TYPE) {
                        this.setState({deleteObjId: modalObj.HolidayDate+" Holiday"});
                    }
                }
            }
            else {
                this.setState({ obj: cloneDeep(defaultObj) });
            }
    
            this.setState({
                actionType: actype,
                showModal: actype !== DM_DELETE_ACTION_TYPE,
                showDeleteModal: actype === DM_DELETE_ACTION_TYPE
            });
        }
    
        handleCancel() {
            this.setState({ showModal: false, showDeleteModal: false });
        }
    
        handleOk(actionType) {
            const  obj  = cloneDeep(this.state.obj);
            obj.HolidayDate = dateFormatFunc(obj.HolidayDate);
            obj.TermDate = dateFormatFunc(obj.TermDate);
            switch (actionType) {
                case DM_ADD_ACTION_TYPE:
                this.props.createHoliday(obj);
                    break;
                case DM_EDIT_ACTION_TYPE:
                this.props.updateHoliday(obj);
                    break;
                case DM_DELETE_ACTION_TYPE:
                this.props.deleteConfirmedHoliday(obj.ID);
                    break;
                default: break;
            }
        }
    
        onDateChange(d, type) {
            const { obj } = this.state;
            obj[type] = d || new Date();
    
            if (type === 'HolidayDate') {
                obj.CCYY = d.getFullYear();
            }
    
            this.setState({ obj });
        }
    
        renderModalFields() {
            const { actionType, obj } = this.state;
            const isEditable = actionType === DM_ADD_ACTION_TYPE || actionType === DM_EDIT_ACTION_TYPE;
            return (
                <Form layout={'horizontal'}>
                    <FormItem
                         validateStatus = {obj.HolidayDate === "" && this.state.errorObj["holiday.HolidayDate"] ? 'error' : ""}
                         help = {obj.HolidayDate === "" && this.state.errorObj["holiday.HolidayDate"]}
                         label={<b>Holiday Date </b>}
                        {...formItemLayout}
                    >
                        {isEditable ?
                            <DatePicker
                            className = "CalClass"
                            selected={obj.HolidayDate}
                            dateFormat={"MM-dd-yyyy"}
                            onChange={(d) => this.onDateChange(d, 'HolidayDate')}
                            isClearable={true}
                            placeholderText="Select a date"
                          />
                            :
                            <div>{getFormattedDate(obj.HolidayDate)}</div>
                        }
                    </FormItem>
                    <FormItem
                        validateStatus = {obj.TermDate === "" && this.state.errorObj["holiday.TermDate"] ? 'error' : ""}
                        help = {obj.TermDate === "" && this.state.errorObj["holiday.TermDate"]}
                        label={<b>Terminated Date </b>}
                        {...formItemLayout}
                    >
                        {isEditable ?
                            <DatePicker
                            className = "CalClass"
                            selected={obj.TermDate}
                            dateFormat={"MM-dd-yyyy"}
                            onChange={(d) => this.onDateChange(d, 'TermDate')}
                            isClearable={true}
                            placeholderText="Select a date"
                          />
                            :
                            <div>{getFormattedDate(obj.TermDate)}</div>
                        }
                    </FormItem>
                </Form>
            );
        }
    
        render() {
            const { title, footer } =
                getModalSettings(this.state.actionType, this.handleOk, this.handleCancel, 'Holiday');
    
            return (
                <div>
                   {this.state.data && <DMTable title={<b>Holidays</b>}
                        tableData={this.state.data}
                        columns={this.columns}
                        handleShowModal={this.handleShowModal}
                        uniqueColumnName='HolidayDate'
                        searchField={['HolidayDate', 'CCYY']}
                        showModal={this.state.showModal}
                        showDeleteModal={this.state.showDeleteModal}
                        handleOk={this.handleOk}
                        handleCancel={this.handleCancel}
                        modalTitle={title}
                        footer={footer}
                        width={'600px'}
                        renderModalFields={this.renderModalFields}
                        deleteObjId={this.state.deleteObjId}
                    />}
                </div>
            )
        }
    }

    const mapStateToProps = state => {
        return {
          dataManager: state.dataManager
        };
    };
    
    const mapDispatchToProps = dispatch => {
        return bindActionCreators(
            {
                getHolidays, getHolidayDetailsById, getEditHoliday, initCreateHolidayObj, initDeleteHolidayObj, deleteConfirmedHoliday, updateHoliday, createHoliday
            },
            dispatch
        );
    };
    
    export default connect(mapStateToProps, mapDispatchToProps)(Holidays);    