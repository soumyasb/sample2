import React, { Component } from 'react';
import { Table, Row, Col, Button, Icon, Divider, Modal, Select, Input } from 'antd';
import moment from "moment";
import {
    DM_ADD_ACTION_TYPE,
    DM_DELETE_ACTION_TYPE,
    DM_EDIT_ACTION_TYPE
} from './DMTableFns';

const { Option } = Select;

class DMTable extends Component {
    constructor(props) {
        super(props);

        this.state = {
            pageSize: 10,
            searchText: '',
            tableData: props.tableData
        }

        this.handlePageSizeChange = this.handlePageSizeChange.bind(this);
        this.handleSearchText = this.handleSearchText.bind(this);
    }

    handlePageSizeChange(pageSize) {
        this.setState({ pageSize });
    }
    static getDerivedStateFromProps(props, prevState) 
{
    
const { tableData } = props;
if (tableData && tableData !== prevState.tableData && prevState.searchText === '') return { tableData: tableData };
return null;
}
    handleSearchText(e) {
        
        let { searchField } = this.props;
        let { tableData } = this.state;
        const searchText = e.target.value.toLowerCase();

        if (searchText && searchField) {
            // If only one field is sent..
            if (!Array.isArray(searchField)) {
                searchField = [searchField];
            }

            tableData = tableData.filter(t => {
                let ret = false;

                // multiple fields can be searched with the same searchText
                searchField.forEach(s => {
                    if (!ret) {
                        if(s === "HolidayDate")
                        {
                            ret =  moment(t[s]).format('MMMM DD').toLowerCase().includes(searchText)
                        }
                        else
                        {
                            ret = t[s].toLowerCase().includes(searchText)
                        }
                    }
                });

                return ret;
            });
        }

        this.setState({ searchText, tableData });
    }

    render() {

        const {
            title,
            handleShowModal,
            columns,
            showModal,
            showDeleteModal,
            handleOk,
            handleCancel,
            modalTitle,
            footer,
            width,
            renderModalFields,
            deleteObjId
        } = this.props;

        const {
            pageSize,
            searchText,
            tableData
        } = this.state;

        if (!columns.find(c => c.title.props.children === "Options")) {
            
            columns.push(
                {
                    title: <b>Options</b>,
                    width: '6%',
                    render: (item) => {
                        return (
                            <div style={{ textAlign: "center" }}>
                                <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => handleShowModal(e, DM_EDIT_ACTION_TYPE, item)} />
                                <Divider type="vertical" />
                                <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => handleShowModal(e, DM_DELETE_ACTION_TYPE, item)} />
                                {/* 
                                 Uncomment the below tags to display the details icon....
                            */}
                                {/* <Divider type="vertical" />
                            <Icon type="profile" style={{ cursor: 'pointer' }} onClick={e => handleShowModal(e, DM_DETAILS_ACTION_TYPE, item)} /> */}
                            </div>
                        );
                    },
                }
            );
        }

        const modalProps = {
            onOk: handleOk,
            destroyOnClose: true,
            onCancel: handleCancel,
            title: modalTitle,
            footer,
            width,
        };

        return (
            <div>
                <Table
                    size={"small"}
                    rowKey={record => record+Math.random().toString()}
                    title={() => <div>
                        <div>
                            <span style={{ fontSize: "x-large" }}>{title}</span>
                            <span style={{ float: 'right' }}>
                                <Button type="primary" onClick={e => handleShowModal(e, DM_ADD_ACTION_TYPE)}>Create New</Button>
                            </span>
                        </div>
                        <br />
                        <Row>
                            <Col span={10}>
                                Show <Select id = "SEnt" onFocus={(e) => {
                                document.getElementById("SEnt").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={this.handlePageSizeChange} value={pageSize}
                                    showArrow={true} size={"default"}>
                                    <Option value={5}>{5}</Option>
                                    <Option value={10}>{10}</Option>
                                    <Option value={20}>{20}</Option>
                                    <Option value={30}>{30}</Option>
                                </Select>  entries
                            </Col>
                            <Col span={4} offset={10}>
                                <Input value={searchText} placeholder={'Search'} onChange={this.handleSearchText} />
                            </Col>
                        </Row>
                    </div>}
                    showHeader={true}
                    bordered
                    dataSource={tableData}
                    columns={columns}
                    pagination={{ pageSize }}
                />
                <Modal
                maskClosable={false}
                    visible={showModal}
                    {...modalProps}
                >
                    {renderModalFields()}
                </Modal>
                <Modal
                maskClosable={false}
                    visible={showDeleteModal}
                    {...modalProps}
                >
                    Are you sure you want to delete <b>{deleteObjId}</b> ?
            </Modal>
            </div >
        );
    }
}

export default DMTable;