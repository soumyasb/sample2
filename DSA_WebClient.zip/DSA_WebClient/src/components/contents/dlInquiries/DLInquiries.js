import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { getDLINQData, resetDlInqState } from "../../../store/actions/dlInquiriesActions";
import { bindActionCreators } from "redux";
import { getNowDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import { Form, Row, Col, Spin, Input, Select, Button, Modal, Icon } from 'antd'; 

const { Option } = Select;
const FormItem = Form.Item;
const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 8 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 },
    },
  };

  const defaultDLInqObj = {
    TCode: '',
    InfoCode: '',
    FileCode: '',
    ParameterObj: {
    DLNumber: '',
    VLNumber: '',
    Name: '',
    BirthDate: '',
    Address: '',
    City: '',
    Zone: '',
    CourtNumber1: '',
    CourtNumber2: '',
    CourtNumber3: '',
    DocumentDate: '',
    DocumentOffice: '',
    ReasonCode: '',
    ThreeCharacterLastName: '',
    TACode: '',
    EffectiveDate: '',
    AuthSec1: '',
    AuthSec2: '',
    AuthSec3: ''}
}


const tCodesList = [  
    // { 
    //     "Text": "A01 - Name Inquiry",
    //     "Value": "A01"
    // },
    { 
        "Text": "A04 - Name Inquiry",
        "Value": "A04"
    },
    { 
        "Text": "ANI - Name Inquiry",
        "Value": "ANI"
    },
    { 
        "Text": "DA2 - Driving Record",
        "Value": "DA2"
    },
    { 
        "Text": "DAD - Driving Record",
        "Value": "DAD"
    },
    { 
        "Text": "DAK - Public Record",
        "Value": "DAK"
    },
    { 
        "Text": "DCI - Court Ind(08Q)",
        "Value": "DCI"
    },
    { 
        "Text": "DF1 - Driving Record",
        "Value": "DF1"
    },
    { 
        "Text": "DLD - Conselor Inq(07Q)",
        "Value": "DLD"
    },
    // { 
    //     "Text": "DM1 - Micrographics Inquiry",
    //     "Value": "DM1"
    // },
    { 
        "Text": "DM3 - Micrographics Inquiry",
        "Value": "DM3"
    },
    { 
        "Text": "HRP - Link Database Inquiry",
        "Value": "HRP"
    },
    // { 
    //     "Text": "LTR - DataBase Status",
    //     "Value": "LTR"
    // },
    { 
        "Text": "ME1 - Medical Certificate Information Inquiry",
        "Value": "ME1"
    },
    { 
        "Text": "R60 - Vehicle Record",
        "Value": "R60"
    },
    { 
        "Text": "R67 - Vehicle Record",
        "Value": "R67"
    }
];

const selectedInfoCodesList1 = [{ 
    "Text": "DL - Driving Record",
    "Value": "DL"
},
{ 
    "Text": "VR - Vehicle Record",
    "Value": "VR"
}];

const selectedInfoCodesList2 = [{ 
    "Text": "C1 - Identifying Info",
    "Value": "C1"
},
{ 
    "Text": "C2 - Endorse and Cert",
    "Value": "C2"
},
{ 
    "Text": "D1 - Miscellaneous",
    "Value": "D1"
},
{ 
    "Text": "D2 - P/N, Susp, Comm.",
    "Value": "D2"
}];

const selectedInfoCodesList3 = [{ 
    "Text": "G0 - Basic Record",
    "Value": "G0"
},
{ 
    "Text": "G1 - Record Status",
    "Value": "G1"
},
{ 
    "Text": "G2 - Legal History",
    "Value": "G2"
},
{ 
    "Text": "G3 - Abstracts",
    "Value": "G3"
}, 
{ 
    "Text": "G4 - FTA",
    "Value": "G4"
},
{ 
    "Text": "G5 - Accidents",
    "Value": "G5"
},
{ 
    "Text": "H2 - G0 - G2",
    "Value": "H2"
},
{ 
    "Text": "H3 - G0 - G3",
    "Value": "H3"
},
{ 
    "Text": "H4 - G0 - G4",
    "Value": "H4"
},
{ 
    "Text": "H5 - G0 - G5",
    "Value": "H5"
},
{ 
    "Text": "H6 - H5 + P/N, Susp, Comm.",
    "Value": "H6"
},
{ 
    "Text": "H8 - H6 + Microgr Xref",
    "Value": "H8"
}];

const selectedInfoCodesList4 = [{ 
    "Text": "J0 - Administrative Msg",
    "Value": "J0"
},
{ 
    "Text": "J1 - Basic DL/ID Info",
    "Value": "J1"
},
{ 
    "Text": "J2 - Record Status",
    "Value": "J2"
},
{ 
    "Text": "J3 - Relicense Requirements",
    "Value": "J3"
},
{ 
    "Text": "J4 - DL Actions",
    "Value": "J4"
},
{ 
    "Text": "J5 - Convictions",
    "Value": "J5"
},
{ 
    "Text": "J6 - FTA/FTP Info",
    "Value": "J6"
},
{ 
    "Text": "J7 - Accident Info",
    "Value": "J7"
},
{ 
    "Text": "J8 - App/Issuance Info",
    "Value": "J8"
},
{ 
    "Text": "J9 - Commercial Driver Info",
    "Value": "J9"
},
{ 
    "Text": "JA - All DL/ID Info",
    "Value": "JA"
},
{ 
    "Text": "JB - Micrographic Info",
    "Value": "JB"
},
{ 
    "Text": "JD - J1,J2,J4",
    "Value": "JD"
},
{ 
    "Text": "JE - J1,J2,J4,J5",
    "Value": "JE"
},
{ 
    "Text": "JF - J1,J2,J4,J5,J6",
    "Value": "JF"
},
{ 
    "Text": "JG - J1,J5-J7",
    "Value": "JG"
},
{ 
    "Text": "JH - J1,J2,J6",
    "Value": "JH"
}];

const selectedInfoCodesList5 = [{ 
    "Text": "M1 - All Documents",
    "Value": "M1"
},
{ 
    "Text": "M2 - Specific Doc Code",
    "Value": "M2"
},
{ 
    "Text": "M3 - Document / Date",
    "Value": "M3"
}
];

const selectedInfoCodesList6 = [{ 
    "Text": "1 - Brief Vehicle Desc",
    "Value": "1"
},
{ 
    "Text": "2 - 1 + L/O Info",
    "Value": "2"
},
{ 
    "Text": "3 - 2 + More Desc + Fee",
    "Value": "3"
},
{ 
    "Text": "4 - 3 + Phase II Info",
    "Value": "4"
},
{ 
    "Text": "8 - All Info",
    "Value": "8"
}];

const selectedInfoCodesList7 =  [{ 
    "Text": "A - All VR Info",
    "Value": "A"
},
{ 
    "Text": "E - Record Condition",
    "Value": "E"
},
{ 
    "Text": "F - Plate w/ Owner",
    "Value": "F"
},
{ 
    "Text": "G - Parking Citation",
    "Value": "G"
},
{ 
    "Text": "H - Rls of Liability",
    "Value": "H"
},
{ 
    "Text": "J - Rls of Liability",
    "Value": "J"
},
{ 
    "Text": "K - Situs Info",
    "Value": "K"
},
{ 
    "Text": "L - Pot Renewal Info",
    "Value": "L"
},
{ 
    "Text": "M - Clearance Info",
    "Value": "M"
},
{ 
    "Text": "N - Vehicle Info",
    "Value": "N"
},
{ 
    "Text": "P - Lessee Name Info",
    "Value": "P"
},
{ 
    "Text": "R - Prior R/O Info",
    "Value": "R"
},
{ 
    "Text": "S - Micrographics",
    "Value": "S"
}];

const selectedInfoCodesList8 = [{ 
    "Text": "K3 - General Info",
    "Value": "K3"
},
{ 
    "Text": "K4 - No Fee Due (Free)",
    "Value": "K4"
},
{ 
    "Text": "K5 - General Info",
    "Value": "K5"
}];

const selectedFileCodesList1 = [
    {
        "Text": "A - Auto",
    "Value": "A"
    },
    {
        "Text": "B - Vessel",
    "Value": "B"
    },
    {
        "Text": "C - Commercial",
    "Value": "C"
    },
    {
        "Text": "E - Exempt",
    "Value": "E"
    },
    {
        "Text": "F - Off Highway",
    "Value": "F"
    },
    {
        "Text": "I - IRP",
    "Value": "I"
    },
    {
        "Text": "L - ELP",
    "Value": "L"
    },
    {
        "Text": "M - Motorcycle",
    "Value": "M"
    },
    {
        "Text": "P - Prorate",
    "Value": "P"
    },
    {
        "Text": "S - Special",
    "Value": "S"
    },
    {
        "Text": "T - Trailer",
    "Value": "T"
    }
];

class DLInquiries extends Component {
    constructor(props) {
        super(props);
var dlInqObj = cloneDeep(defaultDLInqObj);
dlInqObj.TCode = 'DAD';
dlInqObj.InfoCode = 'H6';
        this.state={
            dlInqObj: dlInqObj,
            selectedInfoCodesList: selectedInfoCodesList3,
            BirthDate: "",
            isloading: false,
            EffectiveDate: "",
            showDLInqModal: false,
            ErrorObj: {}
        };
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleEnter = this.handleEnter.bind(this);    
        this.validate = this.validate.bind(this);   
        this.print = this.print.bind(this);       
    }  

    componentWillUnmount() {
        this.props.resetDlInqState();
    }
            static getDerivedStateFromProps(props, prevState) {
                
                const { DLInqData, DLInqDataModified, dlInquriesErrorData, deModified } = props.dlInquiries;
                if (DLInqData !== undefined && (DLInqData !== prevState.DLInqData || DLInqDataModified !== prevState.DLInqDataModified)) 
                {
                    return { DLInqData: DLInqData, showDLInqModal: true, DLInqDataModified: DLInqDataModified, isloading: false };
                }
                if (dlInquriesErrorData !== undefined && (dlInquriesErrorData !== prevState.dlInquriesErrorData || deModified !== prevState.deModified)) 
                {
                    return { dlInquriesErrorData: dlInquriesErrorData, showDLInqErrorModal: true, deModified: deModified, isloading: false };
                }
                return "";
            }
            onDateChange(d, type) {
                const {dlInqObj} = this.state;
                dlInqObj.ParameterObj[type] = d || new Date();
                switch(type) {
                    case 'BirthDate':
                    this.setState({ dlInqObj: dlInqObj, BirthDate: d });
                    break;
                    case 'EffectiveDate':
                    this.setState({ dlInqObj: dlInqObj, EffectiveDate: d });
                    break;
                    default:
                    break;
                }
            }
     
    print() {
        var content = document.getElementById('printarea');
        var pri = document.getElementById('ifmcontentstoprint').contentWindow;
        pri.document.open();
        pri.document.write(content.innerHTML);
        pri.document.close();
        pri.focus();
        pri.print();
      }

            validate() {
                
                const {dlInqObj} = this.state;
                var ErrorObj = {};
                var count = 0;
              switch(dlInqObj.TCode)
              {
                  
                  case 'A04':
                  case 'ANI':
                  if(dlInqObj.ParameterObj.Name === "")
                  {
                      this.setState({ErrorObj: {'Name': 'Name is required.'}});
                      return false;
                  }
                  else
                  {
                    return true;
                  }
                  case 'DA2':
                  case 'DAD':
                  case 'DAK':
                  case 'DF1':
                  case 'DM3':
                  case 'ME1':
                  if(dlInqObj.ParameterObj.DLNumber === "")
                  {
                      this.setState({ErrorObj: {'DLNumber': 'Driver License Number is required.'}});
                      return false;
                  }
                  else
                  {
                    return true;
                  }
                  case 'DCI':
                  if(dlInqObj.ParameterObj.CourtNumber1 === "")
                  {
                      this.setState({ErrorObj: {'CourtNumber1': 'Court Number 1 is required.'}});
                      return false;
                  }
                  else
                  {
                    return true;
                  }
                  case 'HRP':
                  if(dlInqObj.ParameterObj.DLNumber === "")
                  {
                    ErrorObj['DLNumber'] = 'Driver License Number is required.';
                      count ++;
                  }
                  if(dlInqObj.ParameterObj.ThreeCharacterLastName === "")
                  {
                    ErrorObj['ThreeCharacterLastName'] = 'Three Character Last Name is required.';
                      count ++;
                  }
                  if(dlInqObj.ParameterObj.EffectiveDate === "")
                  {
                    ErrorObj['EffectiveDate'] = 'Effective Date is required.';
                      count ++;
                  }
                  if(dlInqObj.ParameterObj.TACode === "")
                  {
                    ErrorObj['TACode'] = 'TA Code is required.';
                      count ++;
                  }
                  if(dlInqObj.ParameterObj.ReasonCode === "")
                  {
                    ErrorObj['ReasonCode'] = 'Reason Code is required.';
                      count ++;
                  }
                  if(dlInqObj.ParameterObj.AuthSec1 === "")
                  {
                    ErrorObj['AuthSec1'] = 'Authority Section 1 is required.';
                      count ++;
                  }
                  if (count > 0)
                  {
                    this.setState({ErrorObj});
                      return false;
                  }
                  else
                  {
                    return true;
                  }
                  case 'DLD':
                  if(dlInqObj.ParameterObj.DLNumber === "")
                  {
                    ErrorObj['DLNumber'] = 'Driver License Number is required.';
                      count++;
                  }
                  if(dlInqObj.ParameterObj.ThreeCharacterLastName === "")
                  {
                    ErrorObj['ThreeCharacterLastName'] = 'Three Character Last Name is required.';
                      count++;
                  }
                  if (count > 0)
                  {
                    this.setState({ErrorObj});
                      return false;
                  }
                  else
                  {
                    return true;
                  }
                  case 'R60':
                  case 'R67':
                  if(dlInqObj.ParameterObj.VLNumber === "")
                  {
                      this.setState({ErrorObj: {'VLNumber': 'Vehicle License Number is required.'}});
                      return false;
                  }
                  else
                  {
                    return true;
                  }
                  default:
                  break;

              } 
            }

            handleEnter(e)
            {
                
               if(this.validate())
               {
                   this.setState({isloading: true});
                this.props.getDLINQData(this.state.dlInqObj); 
               }
            }
            handleFieldChange(e, field) {
                let {dlInqObj} = this.state;
                switch (field) {
                    case 'TCode':
                 //   dlInqObj = cloneDeep(defaultDLInqObj);
                    dlInqObj[field] = e;
                    switch(e) {
                       // case 'A01':
                        case 'A04':
                        case 'ANI':
                        dlInqObj['InfoCode'] = "DL";
                        this.setState({dlInqObj: dlInqObj, BirthDate: "", showDLInqModal: false,
                        selectedInfoCodesList: selectedInfoCodesList1,
                        selectedFileCodesList: "", ErrorObj: {}});
                        break;
                        case 'DA2':
                        dlInqObj['InfoCode'] = "C1";
                        this.setState({dlInqObj: dlInqObj,
                            selectedInfoCodesList: selectedInfoCodesList2, showDLInqModal: false,
                            selectedFileCodesList: "", ErrorObj: {}  
                            });
                            break;
                            case 'DAD':
                            dlInqObj['InfoCode'] = "H6";
                            this.setState({dlInqObj: dlInqObj, 
                                selectedInfoCodesList: selectedInfoCodesList3, showDLInqModal: false,
                                selectedFileCodesList: "", ErrorObj: {}  
                                });
                                break;
                                case 'DAK':
                                dlInqObj['InfoCode'] = "K3";
                                this.setState({dlInqObj: dlInqObj,
                                    selectedInfoCodesList: selectedInfoCodesList8, showDLInqModal: false,
                                    selectedFileCodesList: "", ErrorObj: {}  
                                });
                                break;
                                case 'DF1':
                                dlInqObj['InfoCode'] = "JA";
                                this.setState({dlInqObj: dlInqObj, 
                                    selectedInfoCodesList: selectedInfoCodesList4, showDLInqModal: false,
                                    selectedFileCodesList: "", ErrorObj: {}  
                                });
                                break;
                                case 'DM3':
                                dlInqObj['InfoCode'] = "M1";
                                this.setState({dlInqObj: dlInqObj,
                                    selectedInfoCodesList: selectedInfoCodesList5, showDLInqModal: false,
                                    selectedFileCodesList: "", ErrorObj: {}  
                                });
                                break;
                                case 'R60':
                                dlInqObj['InfoCode'] = "8";
                                dlInqObj['FileCode'] = "A";
                                this.setState({dlInqObj: dlInqObj, showDLInqModal: false,
                                    selectedInfoCodesList: selectedInfoCodesList6,
                                    selectedFileCodesList: selectedFileCodesList1, ErrorObj: {}
                                });
                                break;
                                case 'R67':
                                dlInqObj['InfoCode'] = "A";
                                dlInqObj['FileCode'] = "A";
                                this.setState({dlInqObj: dlInqObj, showDLInqModal: false,
                                    selectedInfoCodesList: selectedInfoCodesList7,
                                    selectedFileCodesList: selectedFileCodesList1, ErrorObj: {}
                                });
                                break;
                                case 'DLD':
                                case 'ME1':
                                case 'DCI':
                                case 'HRP':
                                case 'DM1':
                                case 'LTR':
                                
                                this.setState({dlInqObj: dlInqObj, EffectiveDate: "", selectedInfoCodesList: "", selectedFileCodesList: "", showDLInqModal: false, ErrorObj: {}});
                                break;
                        default:
                        break;
                    }
                   break;
                   case 'InfoCode':
                   case 'FileCode':
                   dlInqObj[field] = e;
                   this.setState({dlInqObj: dlInqObj});
                   break;
                   case 'DLNumber':
                   case 'VLNumber':
                   case 'Address':
                   case 'City':
                   case 'Zone':
                   case 'ThreeCharacterLastName':
                   case 'AuthSec1':
                   case 'ReasonCode':
                   case 'AuthSec2':
                   case 'AuthSec3':
                   if(e.target.value === "" || /^[a-zA-Z0-9]+$/.test(e.target.value))
                   {
                    dlInqObj.ParameterObj[field] = e.target.value.toUpperCase();
                   }
                   this.setState({dlInqObj: dlInqObj});
                   break;
                   case 'CourtNumber1':
                   case 'CourtNumber2':
                   case 'CourtNumber3':
                   case 'TACode':
                   if (!isNaN(e.target.value) && /^[0-9]*$/.test(e.target.value)) {
                   dlInqObj.ParameterObj[field] = e.target.value;
                   }
                   this.setState({dlInqObj: dlInqObj});
                   break;
                   case 'Name':
                   if ((e.target.value === "" || /^[a-zA-Z,]+$/.test(e.target.value)) && (e.target.value.match(/,/g) || []).length < 2) {
                        dlInqObj.ParameterObj[field] = e.target.value;
                    }
                    this.setState({dlInqObj: dlInqObj});
                    break;
                    default:
                        break;
                }
            }
            render() {
                const { DLInqData, dlInqObj } = this.state;
                let EmpInitial = "", printheader = "";
if(DLInqData !== undefined && dlInqObj.DLNumber !== "")
{
  if(sessionStorage.getItem('userInfo')){
    EmpInitial = JSON.parse(sessionStorage.getItem('userInfo')).EmpInitial;
} 
 if(dlInqObj.ParameterObj.DLNumber !== ""){ 
     
    printheader = "LIC #: "+dlInqObj.ParameterObj.DLNumber;
 }
 if(dlInqObj.ParameterObj.VLNumber !== ""){ 
     printheader = "Vehicle LIC #: "+dlInqObj.ParameterObj.VLNumber;
}
printheader = printheader+"            UID: "+EmpInitial+"  Trans: "+dlInqObj.TCode; 
if(dlInqObj.InfoCode !== "")
{
    printheader = printheader+"-"+dlInqObj.InfoCode;
}
if(dlInqObj.FileCode !== "")
{
    printheader = printheader+"-"+dlInqObj.FileCode;
}
printheader = printheader+"  Date: "+ getNowDate();
}
                return (                 
              <div>
                    <div style={{ border: "1px solid black", height: "800px", width: "95%", marginLeft: '2%'}}>
                    <div style={{
border: '1px solid black',
paddingLeft: "1%",
textAlign: 'center',
backgroundColor: 'white',
fontSize: '32px'
}} >DMV Inquiry {tCodesList.map(item => {
    if(item.Value === dlInqObj.ParameterObj.TCode) 
    {return "- " +item.Text;}
    return "";})}</div> 
                    <Row style={{marginLeft: "2%"}}>
                    < br/>
                        <Col span={6}><FormItem
        formItemLayout = 'inline'
            label={<b>Trans Code </b>}
        ><Select id = "STC" onFocus={(e) => {
            document.getElementById("STC").click();
                                                   }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'TCode')}
                                                value={dlInqObj.TCode} showArrow={true} size={"default"}
                                            >
                                              {tCodesList.map((item) =>
                                        {
                                            return <Option title={`${item.Text}`} key={item.Value} value={item.Value}>{item.Text}</Option>
                                    })}
                                            </Select>        </FormItem></Col>
                                          { this.state.selectedInfoCodesList &&  <Col span={6} offset={0.5}><FormItem
        formItemLayout = 'inline'
            label={<b>Info Code </b>}
        ><Select id = "SIC" onFocus={(e) => {
            document.getElementById("SIC").click();
                                                   }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'InfoCode')}
                                                value={dlInqObj.InfoCode} showArrow={true} size={"default"}
                                            >
                                              {this.state.selectedInfoCodesList.map((item) =>
                                        {
                                            return <Option title={`${item.Text}`} key={item.Value} value={item.Value}>{item.Text}</Option>
                                    })}
                                            </Select>       </FormItem> </Col>}
                                           {this.state.selectedFileCodesList && <Col span={6} offset={0.5}><FormItem
        formItemLayout = 'inline'
            label={<b>File Code</b>}
        ><Select id = "SFC" onFocus={(e) => {
            document.getElementById("SFC").click();
                                                   }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'FileCode')}
                                                value={dlInqObj.FileCode} showArrow={true} size={"default"}
                                            >
                                              {this.state.selectedFileCodesList.map((item) =>
                                        {
                                            return <Option title={`${item.Text}`} key={`FC - ${item.Value}`} value={item.Value}>{item.Text}</Option>
                                    })}
                                           </Select>       </FormItem> </Col>}
                                           {['DA2', 'DAD', 'DAK', 'DF1', 'DM3', 'HRP', 'ME1', 'DLD'].includes(dlInqObj.TCode) && <Col span={4} offset={0.5}> 
                                            
                                           <FormItem
        formItemLayout = 'inline'
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.DLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DLNumber"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.DLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DLNumber"]}
            label={<b>Driver License # <font color="red">*</font></b>}
        >
                                           <Input onKeyDown={(e) => { 
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={8} value={dlInqObj.ParameterObj.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')}/>
                               
                                             </FormItem>
                                </Col>}
                                {['R60', 'R67'].includes(dlInqObj.TCode) && <Col span={4} offset={0.5}>
                                <FormItem
             formItemLayout = 'inline'
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.VLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VLNumber"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.VLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VLNumber"]}
            label={<b>Vehicle License # <font color="red">*</font></b>}
        >   <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={7} value={dlInqObj.ParameterObj.VLNumber} placeholder="Vehicle License #" onChange={e => this.handleFieldChange(e, 'VLNumber')}/>            </FormItem>
                                </Col>}</Row>
                             { [ 
                                 //'A01',
                                 'A04', 'ANI', 'DLD', 'DCI', 'DM1', 'HRP'].includes(dlInqObj.TCode) &&  <Row>
                                <Form>
                              {  (dlInqObj.TCode === 'DLD' || dlInqObj.TCode === 'HRP') && <Row><br/>< br/><br/><Col offset={3} span={8}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.ThreeCharacterLastName === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ThreeCharacterLastName"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.ThreeCharacterLastName === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ThreeCharacterLastName"]}
            label={<b>3 Pos Last Name <font color="red">*</font></b>}
        >
           <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength ={3} value={dlInqObj.ParameterObj.ThreeCharacterLastName} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterLastName')} />
        </FormItem>
    </Col></Row> }
                              { dlInqObj.TCode !== 'DCI' && dlInqObj.TCode !== 'DM1' && dlInqObj.TCode !== 'DLD' ?  <div>{dlInqObj.TCode !== "HRP" && <Row><br/>< br/><br/><Col offset={3} span={8}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.Name === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Name"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.Name === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Name"]}
            label={<b>Name <font color="red">*</font></b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={35} value={dlInqObj.ParameterObj.Name} placeholder="First Name,Last Name" onChange={e => this.handleFieldChange(e, 'Name')} />
        </FormItem>
    </Col> { dlInqObj.TCode !== 'HRP' && <Col offset={0.5} span={4}><FormItem
        {...formItemLayout}
                              validateStatus = {this.state.BirthDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["BirthDate"] ? 'error' : ""}
                              help = {this.state.BirthDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["BirthDate"]}
                                label={<b>Birth Date </b>}
                            >
                                    <DatePicker
                         className = "CalClass"
                         selected={this.state.BirthDate}
                         dateFormat={"MM-dd-yyyy"}
                         onChange={(d) => this.onDateChange(d, 'BirthDate')}
                         isClearable={true}
                         placeholderText="Select a date"
                       />
                                </FormItem></Col>}</Row>}
    <br/><br/>
    { dlInqObj.TCode !== 'HRP' && <Row>
    <Col offset={3} span={8}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.Address === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Address"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.Address === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Address"]}
            label={<b>Address </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={3} value={dlInqObj.ParameterObj.Address} placeholder="Address" onChange={e => this.handleFieldChange(e, 'Address')} />
        </FormItem>
    </Col><Col offset={0.5} span={4}> <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.City === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["City"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.City === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["City"]}
            label={<b>City </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={13} value={dlInqObj.ParameterObj.City} placeholder="City" onChange={e => this.handleFieldChange(e, 'City')} />
        </FormItem></Col><Col offset={0.5} span={4}><FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.Zone === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Zone"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.Zone === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Zone"]}
            label={<b>Zone </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={2} value={dlInqObj.ParameterObj.Zone} placeholder="Zone" onChange={e => this.handleFieldChange(e, 'Zone')} />
        </FormItem></Col>
        </Row>}
        {dlInqObj.TCode === 'HRP' && 
   <div> <Row>
    <Col offset={3} span={6}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.TACode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TACode"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.TACode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TACode"]}
            label={<b>T/A Code <font color="red">*</font></b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={2} value={dlInqObj.ParameterObj.TACode} placeholder="T/A Code" onChange={e => this.handleFieldChange(e, 'TACode')} />
        </FormItem>
    </Col><Col offset={0.5} span={6}> <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.ReasonCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ReasonCode"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.ReasonCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ReasonCode"]}
            label={<b>Reason Code <font color="red">*</font></b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={3} value={dlInqObj.ParameterObj.ReasonCode} placeholder="ReasonCode" onChange={e => this.handleFieldChange(e, 'ReasonCode')} />
        </FormItem></Col><Col offset={0.5} span={6}><FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={this.state.EffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EffectiveDate"] ? 'error' : ""}
          help={this.state.EffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EffectiveDate"]}
            label={<b>Effective Date <font color="red">*</font></b>}
        >
                  <DatePicker
                         className = "CalClass"
                         selected={this.state.EffectiveDate}
                         dateFormat={"MM-dd-yyyy"}
                         onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                         isClearable={true}
                         placeholderText="Select a date"
                       />
        </FormItem></Col>
        </Row>
        <Row><br/><br/>
    <Col offset={3} span={6}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.AuthSec1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSec1"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.AuthSec1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSec1"]}
            label={<b>Authority Sect1 <font color="red">*</font></b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={7} value={dlInqObj.ParameterObj.AuthSec1} placeholder="Authority Section 1" onChange={e => this.handleFieldChange(e, 'AuthSec1')} />
        </FormItem>
    </Col><Col offset={0.5} span={6}> <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.AuthSec2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSec2"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.AuthSec2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSec2"]}
            label={<b>Authority Sect2 </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={7} value={dlInqObj.ParameterObj.AuthSec2} placeholder="Authority Section 2" onChange={e => this.handleFieldChange(e, 'AuthSec2')} />
        </FormItem></Col><Col offset={0.5} span={6}><FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.AuthSec3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSec3"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.AuthSec3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSec3"]}
            label={<b>Authority Sect3 </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={7} value={dlInqObj.ParameterObj.AuthSec3} placeholder="Authority Section 3" onChange={e => this.handleFieldChange(e, 'AuthSec3')} />
        </FormItem></Col>
        </Row> </div>
    }
        
        </div>: dlInqObj.TCode === 'DCI' ? <div><Row><br/> <br/>
    <Col offset={3} span={4}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.CourtNumber1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtNumber1"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.CourtNumber1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtNumber1"]}
            label={<b>Court #1 <font color="red">*</font></b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={5} value={dlInqObj.ParameterObj.CourtNumber1} placeholder="Court #1" onChange={e => this.handleFieldChange(e, 'CourtNumber1')} />
        </FormItem>
    </Col><Col offset={0.5} span={4}> <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.CourtNumber2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtNumber2"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.CourtNumber2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtNumber2"]}
            label={<b>Court #2 </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={5} value={dlInqObj.ParameterObj.CourtNumber2} placeholder="Court #2" onChange={e => this.handleFieldChange(e, 'CourtNumber2')} />
        </FormItem></Col><Col offset={0.5} span={4}><FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.CourtNumber3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtNumber3"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.CourtNumber3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtNumber3"]}
            label={<b>Court #3 </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} maxLength={5} value={dlInqObj.ParameterObj.CourtNumber3} placeholder="Court #3" onChange={e => this.handleFieldChange(e, 'CourtNumber3')} />
        </FormItem></Col>
        </Row></div> : dlInqObj.TCode !== 'DLD' && <div><Row><br/><br/>
    <Col offset={3} span={8}>
        <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.DocumentDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DocumentDate"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.DocumentDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DocumentDate"]}
            label={<b>Document Date </b>}
        >
             <DatePicker
                              className = "CalClass"
                              selected={this.UNSAFE_componentWillMount.state.DocumentDate}
                              dateFormat={"MM-dd-yyyy"}
                              onChange={(d) => this.onDateChange(d, 'DocumentDate')}
                              isClearable={true}
                              placeholderText="Select a date"
                            />
        </FormItem>
    </Col><Col span={6}> <FormItem
        {...formItemLayout}
          hasFeedback
          validateStatus={dlInqObj.ParameterObj.DocumentOffice === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DocumentOffice"] ? 'error' : ""}
          help={dlInqObj.ParameterObj.DocumentOffice === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DocumentOffice"]}
            label={<b>Document Office </b>}
        >
            <Input onKeyDown={(e) => {
            if(e.keyCode === 13)
            {
                if(this.validate())
                {
                    this.setState({isloading: true});
                 this.props.getDLINQData(this.state.dlInqObj); 
                }
            }
        }} value={dlInqObj.ParameterObj.DocumentOffice} placeholder="Document Office" onChange={e => this.handleFieldChange(e, 'DocumentOffice')} />
        </FormItem></Col>
        </Row></div>}
                                </Form>
                                </Row>
                             }
            
                   {/* ME1 - Medical Certificate Information Inquiry
                <br/> */}
                {/* <h4>Enter new DL Number:</h4> */}
                  {/* <Search
          placeholder="Enter DL Number"
          size= "small"
          style={{width: "20%"}}
          onSearch={value => { 
              this.props.getDLInqData(value); 
            }}
          enterButton/>         */}
          <Modal maskClosable={false} visible={this.state.showDLInqModal}
          onOk = {(e) =>
            {
            this.setState({showDLInqModal: false})}}
          onCancel = {(e) => this.setState({showDLInqModal: false})}
          width = '1000px'
          title={dlInqObj.TCode}> 
       <div>
        <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
{DLInqData !== undefined ? <div>{(DLInqData.length > 0) ?
        
       ( ["DAD","DA2","DAK", "DF1", "DM3"].includes(dlInqObj.TCode) ? <div>
           {/* <ReactToPrint 
trigger={(e) => <Button style={{ marginLeft:'40%'}} type="primary"><Icon type="printer" theme="outlined" />Print this page</Button>}
content={() => this.componentRef}
/>  */}
<Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print()}><Icon type="printer" theme="outlined" />Print this page</Button> <ScrollPanel  style={{
              height: "500px"
          }}>      <div id='printarea'> 
                   <iframe title="ifmcontentstoprint" id="ifmcontentstoprint" style={{
                        height: '0px',
                        width: '0px',
                        position: 'absolute'
                    }}></iframe>   
<table><thead>
<tr>
<th><pre id="printheaderpage">{printheader}</pre></th>
</tr>
</thead>
                <tbody>
<tr>
<td><pre></pre>
<pre>{DLInqData.toString().includes("DLInq") && <div dangerouslySetInnerHTML={{ __html: Object.entries(JSON.parse(DLInqData)).map(([key,value])=>{
return (value.toString());}).toString()}}/>}</pre> 
 </td></tr></tbody></table> 
         </div></ScrollPanel></div>
:
        <div>
            {/* <ReactToPrint 
          trigger={(e) => <Button style={{ marginLeft:'43%'}} type="primary"><Icon type="printer" theme="outlined" />Print this page</Button>}
          content={() => this.componentRef}
          />  */}
        <Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print()}><Icon type="printer" theme="outlined" />Print this page</Button> <ScrollPanel  style={{
              height: "500px"
          }}>      <div id='printarea'> 
                   <iframe title="ifmcontentstoprint" id="ifmcontentstoprint" style={{
                        height: '0px',
                        width: '0px',
                        position: 'absolute'
                    }}></iframe>  
                    
                {(DLInqData.toString().includes("Result") || DLInqData.toString().includes("DLInq"))  && JSON.parse(DLInqData) ? JSON.parse(DLInqData).Result && JSON.parse(DLInqData).Result !== null ?  <table><thead>
<tr>
<th><pre id="printheaderpage">{printheader}</pre></th>
</tr>
</thead>
                <tbody>
<tr>
<td> <pre><div dangerouslySetInnerHTML={{ __html: JSON.parse(DLInqData).Result.toString()}}/></pre> </td></tr></tbody></table> : <pre><div dangerouslySetInnerHTML={{ __html: JSON.parse(DLInqData).ErrorMessage}}/></pre>:  <table><thead>
<tr>
<th><pre id="printheaderpage">{printheader}</pre></th>
</tr>
</thead>
                <tbody>
<tr>
<td><pre><div dangerouslySetInnerHTML={{ __html: DLInqData.toString()}}/></pre></td></tr></tbody></table>}</div></ScrollPanel></div>):
          <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data... Please wait.</font></span></div>
          }</div>:<div>No {dlInqObj.TCode} - {dlInqObj.InfoCode} info found.</div>}</div></div></Modal>
         {typeof this.state.dlInquriesErrorData && <Modal title={'ERROR'} maskClosable={false} visible={this.state.showDLInqErrorModal}
                 onCancel={(e) => this.setState({showDLInqErrorModal: false})}
              
                 footer = { [
                  <div>
                    <Button type="default" key="Cancel" onClick={(e) =>
                      {
                        this.setState({ showDLInqErrorModal: false });
                      }}
                     > OK </Button> 
                </div>
               ]}
><font color='red'>{this.state.dlInquriesErrorData}</font></Modal>}
          <Row><br/><br/> {this.state.isloading  ?  <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div> :   <Button style={{ color: "white", backgroundColor: "green", marginLeft: "50%" }}
          type="default" key="Enter" onClick={(e) => this.handleEnter('Enter')}>Enter</Button>}</Row>
               </div></div>);
            }
            } 
        
            const mapStateToProps = state => {
                return {
                  dlInquiries: state.dlInquiries
                };
            };   
            
            const mapDispatchToProps = dispatch => {
                return bindActionCreators(
                    {
                        getDLINQData, resetDlInqState
                    },
                    dispatch
                );
            };
            
           export default connect(mapStateToProps, mapDispatchToProps)(DLInquiries);
