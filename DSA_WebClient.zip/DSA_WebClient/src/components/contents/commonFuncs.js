import moment from 'moment';

export function getFormattedDate(date) {
    return moment(date).isValid() ? moment(date).format('MM-DD-YYYY') : moment(date, "MM-DD-YYYY").isValid() ? date : '-';
}

export function dateFormatFunc(date) {
    const fdate = moment(date).format("MM-DD-YYYY");
    if (fdate.includes('Invalid')) {
        return "";
    }
    else
        return fdate;
};

export function getMonthDay(date) {
return moment(date).format('MMMM DD');
}

export function getNowDate() {
    return moment(Date.now()).format('MM-DD-YYYY hh:mm');
}

export function checkIfFutureDate(date) {
    return moment(moment(date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD'), 'day');
}

export function dateFormatFuncDLUpdates(date) {
const fdate = moment(date).format('MMDDYY');
if(fdate.includes('Invalid'))
{
    return "";
}
else
return fdate;
}

export function checkYearOfDate(date) {
    return moment(date).diff(moment(new Date()).format('YYYY-MM-DD'), 'years');
}

export function checkIfBeforeGivenDate(date) {
    return moment(moment(date).format('YYYY-MM-DD')).isSameOrBefore(moment('1996-03-31'),'day');
}