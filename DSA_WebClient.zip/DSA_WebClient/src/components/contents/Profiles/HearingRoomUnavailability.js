import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import {
    getHearingLocation, getListOfEmployeesForOffice, getMyDistrictOffices, getHearingRoomTimeOff, getHearingRoomTimeOffDefaultData, getHearingRoomTimeOffEditData, createHearingRoomTimeOff, editHRTimeOff, deleteHearingRoomTimeOff  
} from "../../../store/actions/profilesActions";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import moment from "moment";
import {
    Table, Tabs, DatePicker, Divider, Modal, Input, Button, TimePicker,
    Select, Menu, Icon, Checkbox, Form, Radio, InputNumber, notification
} from 'antd';


const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;
const { TabPane } = Tabs;
const RadioGroup = Radio.Group;
const { MonthPicker } = DatePicker;
const monthFormat = 'MMM-YYYY';
const timeFormat = 'HH:mm';
const dateFormat = 'MM-DD-YYYY';

const formItemLayout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
};

const OccuranceType = {
    D: 'Daily',
    W: 'Weekly',
    B: 'Bi-Weekly',
    M: 'Monthly',
    Y: 'Yearly'
}

class HearingRoomUnavailability extends Component {
    constructor(props) {
        super(props);
        this.appointmentColumns = [
            {
                title: <b>Date</b>,
                dataIndex: 'StartTime',
                width: "25%",
                key: 'StartDate',
                render: item => {
                    return moment(item).format("MM-DD-YYYY");
                }
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: "25%",
                key: 'time'
            },
            {
                title: <b>Updated By</b>,
                dataIndex: 'UpdatedByName',
                width: "20%",
                key: 'UpdatedByName'
            },
            {
                title: <b>Updated On</b>,
                dataIndex: 'DateUpdated',
                width: "20%",
                key: 'DateUpdated',
                render: (item) =>
                {                   
           if( moment(item).format("MM-DD-YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM-DD-YYYY");
           }
                }
            },
            {
                title: 'Options',
                width: '10%',
                render: (item) => {
                
                    return (
                        <div>
                            <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.ReacurrenceNumber, item.AppointmentNumber, false)} />
                            <Divider type="vertical" />
                            <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.ReacurrenceNumber, item.AppointmentNumber, false)} />
                        </div>
                    );
                },
            }
        ];

        this.recurringColumns = [
            {
                title: <b>Occurs</b>,
                dataIndex: 'OccuranceType',
                width: '10%',
                key: 'OccuranceType',
                render: item => OccuranceType[item]
            },
            {
                title: <b>Start Date</b>,
                dataIndex: 'StartTime',
                key: 'StartDate',
                width: '15%',
                render: item => moment(item).format("MM-DD-YYYY")
            },
            {
                title: <b>End Date</b>,
                dataIndex: 'EndTime',
                width: '15%',
                key: 'EndDate',
                render: item => moment(item).format("MM-DD-YYYY").includes("9999") ? "NO END DATE" : moment(item).format("MM-DD-YYYY")
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: '15%',
                key: 'time'
            },
            {
                title: <b>Updated By</b>,
                dataIndex: 'UpdatedByName',
                width: "20%",
                key: 'UpdatedByName'
            },
            {
                title: <b>Updated On</b>,
                dataIndex: 'DateUpdated',
                width: "15%",
                key: 'DateUpdated',
                render: (item) =>
                {                   
           if( moment(item).format("MM-DD-YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM-DD-YYYY");
           }
                }
            },
            {
                title: 'Options',
                width: '10%',
                render: (item) => {
                    return (
                        <div>
                            <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.ReacurrenceNumber, item.AppointmentNumber, true)} />
                            <Divider type="vertical" />
                            <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.ReacurrenceNumber, item.AppointmentNumber, true)} />
                        </div>
                    );
                },
            }
        ];
      
        this.state = {
            districtOffices: props.profiles.districtOfficesData,
            hearingLocationsData: [],
            selectedHearingLocation: {},
            timeOffSelectedMonth: moment().format("MMM-YYYY"),
            selectedMonth: moment(),
            hearingRoomObj: null,
            recurringRoomObj: {},
            deleteModalVisible: false,
            editmode: false,
            createMode: false,
            activePaneKey: "1",
            disablefield: true,
            formMode: ""
        };

        this.onOfficeListRowClick = this.onOfficeListRowClick.bind(this);
        this.handleLocationChanged = this.handleLocationChanged.bind(this);
        this.handleTimeOffFieldChange = this.handleTimeOffFieldChange.bind(this);
        this.handleRecurringFieldChange = this.handleRecurringFieldChange.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount() {
        this.props.getMyDistrictOffices();
        this.props.getListOfEmployeesForOffice();
    }
    componentDidUpdate(prevProps){
        if ( prevProps.profiles.hearingRoomTOData !== this.props.profiles.hearingRoomTOData ) {
            let errorsList = [];
          if(this.props.profiles.hearingRoomTOData.length > 0)
          {
            if(this.props.profiles.employeeList !== undefined)
            { 
                const {hearingRoomTOData} = this.state;
        
                this.props.profiles.employeeList.map((eitem) =>
                {
                    hearingRoomTOData.map((hitem,index) => {
                        if( hitem.UpdatedBy === eitem.Empid)
                        {
                            hearingRoomTOData[index].UpdatedByName = eitem.FirstName+" "+eitem.MiddleName+" "+eitem.LastName;
                        }
                        return "";
                    });      
                    return "";             
                }
               );  
            this.setState({hearingRoomTOData});
            }
          }
            if(this.props.profiles.hearingRoomTOData && this.props.profiles.hearingRoomTOData.HearingRoomId !== undefined)
            {
            if(this.props.profiles.hearingRoomTOData.updateStatus !== undefined) 
            { 
                this.openNotification(this.props.profiles.hearingRoomTOData.updateStatus);           
             const month = this.state.selectedMonth.month()+1;
             const year = this.state.selectedMonth.year();
             this.props.getHearingRoomTimeOff(this.state.selectedHearingLocation.HearingLocationId, month, year);
             this.setState({createMode: false, editmode: false, disablefield: true, formMode: "", isRecurringObj: false, isNonRecurringObj: false});
            } 
            }
            if(this.props.profiles.hearingRoomTOData && this.props.profiles.hearingRoomTOData.isError)
            {
                Object.keys(this.props.profiles.hearingRoomTOData.data).map((keyName) =>
                {
                    errorsList.push(this.props.profiles.hearingRoomTOData.data[keyName][0]);
                    return "";
                });

                this.setState({errorsList});
            }
            if(this.props.profiles.hearingRoomTOData && this.props.profiles.hearingRoomTOData.HearingRoomId === 0)
            {
             this.setState({createMode: true, disablefield: false});
            }
            if(this.props.profiles.hearingRoomTOData && this.props.profiles.hearingRoomTOData.HearingRoomId === undefined && this.props.profiles.hearingRoomTOData.updateStatus !== undefined)
            {
                this.openNotification(this.props.profiles.hearingRoomTOData.updateStatus);
                const month = this.state.selectedMonth.month()+1;
                const year = this.state.selectedMonth.year();
                this.props.getHearingRoomTimeOff(this.state.selectedHearingLocation.HearingLocationId, month, year);
                this.setState({ isRecurringObj: false, isNonRecurringObj: false, formMode: ""});
            }            
        }
      }
    static getDerivedStateFromProps(props, prevState) {
        const { districtOfficesData, hearingLocationsData, hearingRoomTOData, hearingRoomEditData, employeeList } = props.profiles;

        if (districtOfficesData && districtOfficesData !== prevState.districtOffices) return { districtOffices: districtOfficesData };

        if (hearingLocationsData !== prevState.hearingLocationsData) return { hearingLocationsData: hearingLocationsData, hearingRoomObj: null, recurringObj: null, newOfficeSelected: false };

        if (employeeList !== prevState.employeeList) return { employeeList: employeeList };

        if(hearingRoomEditData !== prevState.hearingRoomEditData) 
        {
            switch(hearingRoomEditData.OccuranceType)
            {
             
                case 'M':
                {
                    if(hearingRoomEditData.DayType !== null && hearingRoomEditData.DayOfTheWeek !== null)
                    {
                        hearingRoomEditData.selectedRadio = "1";
                    }
                    else
                    {
                        hearingRoomEditData.selectedRadio = "2";
                    }
                    break;
                }
                case 'Y':
                {
                    if(hearingRoomEditData.DayOfTheMonth !== null && hearingRoomEditData.MonthOfTheYear !== null)
                    {
                        hearingRoomEditData.selectedRadio = "1";
                    }
                    else
                    {
                        hearingRoomEditData.selectedRadio = "2";
                    }
                    break;
                    
                }
                default:
                hearingRoomEditData.selectedRadio = "1";
                break;
            }
            if((moment(hearingRoomEditData.EndTime).format("MM-DD-YYYY")).includes("9999"))
            {
                hearingRoomEditData.EndDateOption = "N";
            }
            else
            {
                hearingRoomEditData.EndDateOption = "Y";
            }
            hearingRoomEditData.StartDate = hearingRoomEditData.StartTime;
            hearingRoomEditData.EndDate = hearingRoomEditData.EndTime;
            return {hearingRoomEditData: hearingRoomEditData, recurringObj: cloneDeep(hearingRoomEditData), hearingRoomObj: cloneDeep(hearingRoomEditData), createMode: false};
        }
        if (hearingRoomTOData !== prevState.hearingRoomTOData)
        {
            if(hearingRoomTOData !== undefined && (prevState.formMode !== 'dirty'))
            {
                
            if(hearingRoomTOData.hasOwnProperty('HearingRoomId') === false && hearingRoomTOData.length > 0)
            {
                let nonrecurringappmnts = [], recurringappmnts = [];
                hearingRoomTOData.map((item, index) => {
                    hearingRoomTOData[index].StartDate = hearingRoomTOData[index].StartTime;
                    hearingRoomTOData[index].EndDate = hearingRoomTOData[index].EndTime;
                    
                if(item.isAllDay)
                {
                    item.time = 'ALL DAY';
                }
                else
                {
                    item.time = moment(item.StartTime).format("h:mm A") +"-"+ moment(item.EndTime).format("h:mm A");
                }
        if(item.OccuranceType !== null)
        {
           recurringappmnts.push(item);
        }
        else
        {
            nonrecurringappmnts.push(item);
        } 
        return ""; 
            });
            return {recurringappmnts: recurringappmnts, nonrecurringappmnts: nonrecurringappmnts, hearingRoomTOData: hearingRoomTOData};     
        }
            else
            {
                hearingRoomTOData.StartDate = hearingRoomTOData.StartTime;
                hearingRoomTOData.EndDate = hearingRoomTOData.EndTime;
                return { hearingRoomObj: cloneDeep(hearingRoomTOData), recurringObj: cloneDeep(hearingRoomTOData), hearingRoomTOData: hearingRoomTOData};
            }
        }

        }
        return null;
    }

    showModal(e, actype, reacNo, apptNo, isRecurring = false) {

        if(isRecurring)
        {
            switch (actype) {
                case 'edit':
                {
                    this.setState({modalmode: 'edit', disablefield: false, recurringtitle: 'Update Recurring Time-Off', isRecurringObj: true});
                    this.props.getHearingRoomTimeOffEditData(reacNo, apptNo);
                    break;
        }
                case 'delete':
                this.setState({modalmode: 'delete', disablefield: true, recurringtitle: 'Delete Recurring Time-Off', isRecurringObj: true});
                this.props.getHearingRoomTimeOffEditData(reacNo, apptNo);
                    break;
                default:
                    break;
            }
        }
        else
        {
            switch (actype) {
                case 'edit':
                {
                    this.setState({modalmode: 'edit', disablefield: false, nonrecurringtitle: 'Update Non-Recurring Time-Off', isNonRecurringObj: true});
                    this.props.getHearingRoomTimeOffEditData(reacNo, apptNo);
                    break;
        }
                case 'delete':
                this.setState({modalmode: 'delete', disablefield: true, nonrecurringtitle: 'Delete Non-Recurring Time-Off', isNonRecurringObj: true});
                this.props.getHearingRoomTimeOffEditData(reacNo, apptNo);
                    break;
                default:
                    break;
            }
        }
    }
  
    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    handleOk(type, mode) {
if(type === 'rec')
{
    const {recurringObj} = this.state;
    recurringObj.StartTime = recurringObj.StartDate.split("T")[0]+"T"+recurringObj.StartTime.split("T")[1];
    recurringObj.EndTime = recurringObj.EndDate.split("T")[0]+"T"+recurringObj.EndDate.split("T")[1];
    this.setState({recurringObj});
}
if(mode === 'create')
{
    if(type=== 'rec')
    {
    const {recurringObj} = this.state;
    recurringObj.HearingRoomId = this.state.selectedHearingLocation.HearingLocationId;
    this.setState({recurringObj});
    this.props.createHearingRoomTimeOff(this.state.recurringObj);
    }
    if(type === 'nonrec')
    {
        const {hearingRoomObj} = this.state;
        hearingRoomObj.HearingRoomId = this.state.selectedHearingLocation.HearingLocationId;
        this.setState({hearingRoomObj});
    this.props.createHearingRoomTimeOff(this.state.hearingRoomObj);
    }
}
if(mode === 'edit')
{
    if(type === 'rec')
    this.props.editHRTimeOff(this.state.recurringObj);
    if(type === 'nonrec')
    this.props.editHRTimeOff(this.state.hearingRoomObj);
}
    }

    onOfficeListRowClick = (value) => {
        this.props.getHearingLocation(parseInt(value, 10));
        const selectedOffice = this.state.districtOffices.find(item => item.OfficeID === value);
        this.setState({ selectedOffice, selectedHearingLocation: {}, hearingRoomObj: null, newOfficeSelected: true });
    }

    handleLocationChanged = (e) => {
        const selectedHearingLocation = this.state.hearingLocationsData.find(i => i.HearingLocationId === parseInt(e, 10));
         this.setState({ selectedHearingLocation: selectedHearingLocation, nonrecurringappmnts: [], recurringappmnts: [] });
        if (selectedHearingLocation) {
            const month = this.state.selectedMonth.month()+1;
            const year = this.state.selectedMonth.year();
            this.props.getHearingRoomTimeOff(selectedHearingLocation.HearingLocationId, month, year);
            }
        }
    

    handleMonthChange(date, dateString) {
        
        if (dateString) {
                        
            this.setState({ timeOffSelectedMonth: dateString, selectedMonth: date , nonrecurringappmnts: [], recurringappmnts: [] });

            if (this.state.selectedHearingLocation) {
                const month = date.month()+1;
                const year = date.year();
                this.props.getHearingRoomTimeOff(this.state.selectedHearingLocation.HearingLocationId, month, year);   
            }
        }
    }

    handleTimeOffFieldChange(e, type) {
        const { hearingRoomObj } = this.state;

        switch (type) {
            case 'date':
                const date = e.startOf('date');
                hearingRoomObj.date = date.format();
                hearingRoomObj.StartTime = date.format();
                hearingRoomObj.EndTime = date.format();
                break;
            case 'isAllDay':
                hearingRoomObj.isAllDay = e.target.checked;
                break;
            case 'StartTime':
                hearingRoomObj.StartTime = e.format();
                break;
            case 'EndTime':
                hearingRoomObj.EndTime = e.format();
                break;
            case 'Comment':
                hearingRoomObj.Comment = e.target.value;
                break;
            case 'isDispayComment':
                hearingRoomObj.isDispayComment = e.target.checked;
                break;
            default:
                break;
        }

        this.setState({ hearingRoomObj: hearingRoomObj, formMode: 'dirty' });
    }

    handleRecurringFieldChange(e, type) {
        const { recurringObj } = this.state;
        switch (type) {
            case 'activityType':
                recurringObj.activityType = e;
                break;
            case 'StartDate':
                recurringObj.StartDate = e.format();
                break;
            case 'EndDate':
                recurringObj.EndDate = e.format();
                break;
            case 'OccuranceType':
                {
                    recurringObj.OccuranceType = e.target.value;
                    const crecurringObj = this.state.recurringObj;
                    crecurringObj.DayType = "";
                    crecurringObj.DayOfTheMonth = "";
                    crecurringObj.DayOfTheWeek = "";
                    crecurringObj.MonthOfTheYear = "";
                    this.setState({ recurringObj: crecurringObj });
                }
                break;
            case 'isAllDay':
                recurringObj.isAllDay = e.target.checked;
                break;
            case 'StartTime':
                recurringObj.StartTime = e.format();
                break;
            case 'EndTime':
                recurringObj.EndTime = e.format();
                break;
            case 'Comment':
                recurringObj.Comment = e.target.value;
                break;
            case 'isDispayComment':
                recurringObj.isDispayComment = e.target.checked;
                break;
            case 'DayType':
                recurringObj.DayType = e.target.value;
                break;
            case 'DayOfTheWeek':
                recurringObj.DayOfTheWeek = e.target.value;
                break;
            case 'DayOfTheMonth':
                recurringObj.DayOfTheMonth = e;
                break;
            case 'selectedRadio':
                recurringObj.selectedRadio = e.target.value;
                break;
            case 'EndDateOption':
                recurringObj.EndDateOption = e.target.value;
                if (e.target.value === 'Y') {
                    recurringObj.EndDate = moment().format();
                }
                else {
                    recurringObj.EndDate = "9999-12-27T12:00:00";
                }
                break;
            default:
                break;
        }
        this.setState({ recurringObj: recurringObj, formMode: 'dirty' });
    }

    handleDelete() {
        this.setState({ deleteModalVisible: true });
    }

    setActivePaneKey(key)
    {
           this.setState({activePaneKey: key});
    }
    getMenuList(districtOffices) {
        let officesList = [];
        districtOffices.map((item) => {
            officesList.push(<Menu.Item key={item.OfficeID}>{<div style={{ textAlign: "center" }}><div style={{ height: "35px", fontSize: 16, fontWeight: "bold" }}>{item.OfficeID}-{item.Name}</div>
                <div style={{ height: "35px", marginTop: "-18px", fontSize: 11 }}>{item.AddressLineOne}</div>
                <div style={{ height: "35px", marginTop: "-18px", fontSize: 11 }}>{item.City}-{item.Zip}.  <b>Ph:</b>{item.PhoneNumber}</div></div>}</Menu.Item>)
        return "";
    })
        return officesList;
    }

    render() {
        const {
            selectedOffice,
            districtOffices,
            hearingLocationsData,
            selectedHearingLocation,
            timeOffSelectedMonth
        } = this.state;
        let hearingRoomObj, recurringObj = null;

if(this.state.newOfficeSelected !== true)
{
    hearingRoomObj = this.state.hearingRoomObj;
    recurringObj = this.state.recurringObj;
}
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
        };

        let officesList = [];

        if (districtOffices !== undefined) { officesList = this.getMenuList(districtOffices); }

        return (
        // <ScrollPanel
        //     style={{
        //         width: "100%",
        //         height: "100%",
        //         backgroundColor: "rgba(0,0,0,0)"
        //     }}>
            <Row style={{
                marginLeft: "2.5%",
                width: "95%",
                height: "800px",
                border: "2px solid white"
            }}>
                <div style={{ height: "7%", border: "1px solid white" }} >
                    <span style={{ paddingLeft: "1%", fontSize: "xx-large" }}>Hearing Room Unavailability</span>
                </div>
                <Col span={5} style={{ height: "93%", border: "1px solid white" }}>
                    <div style={{ height: "5%", paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white" }}>
                        Select An Office
                    </div>
                    <ScrollPanel style={{ height: "95%", backgroundColor: "#c9e3fa" }}>
                        <Menu onClick={(e) => this.onOfficeListRowClick(e.key)} mode="vertical">
                            {officesList}
                        </Menu>
                    </ScrollPanel>
                </Col>
                <Col style={{
                    width: "78%",
                    float: "right",
                    height: "93%",
                    border: "1px solid white"
                }}>
                    <div style={{
                        height: "5%", paddingTop: "7px", backgroundColor: "#d5d5d5",  textAlign: "center", border: "1px solid white"
                    }}>Hearing Room Unavailability Menu</div>
                    <div style={{ height: "100%", border: "1px solid white", paddingLeft: "15px"}}>
                    {this.state.selectedOffice === undefined && <h3>Please select an office from the menu on the left side to continue.</h3>}
                  {hearingLocationsData && this.state.selectedOffice && <div> <div style={{ height: "10%", marginTop: "2%"}}>
                  <Row style={{ width: "100%" }}>
                  <Col span={11}>
                                            Office - {' '} <span style={{ fontWeight: "bold" }}>
                                            {selectedOffice && selectedOffice.Name}
                                        </span>
                                        </Col>
                                        <Col>
                                            Location : {' '}
                                            <Select id = "LOC" onFocus={(e) => {
                  document.getElementById("LOC").click();
                                                         }} showSearch optionFilterProp= "children" filterOption = {true}
                                                style={{ width: '40%' }}
                                                placeholder="Please select a hearing room"
                                                value={selectedHearingLocation.HearingLocationId}
                                                onChange={e => this.handleLocationChanged(e)}
                                            >
                                                {hearingLocationsData.map(item => <Option key={`${item.HearingLocationId}`}
                                                    value={item.HearingLocationId}>
                                                    {`${item.RoomNumber} - ${item.RoomDescription}`}</Option>)}
                                            </Select>
                                        </Col>
                                    </Row>
                                </div>
                                   <hr style={{marginLeft: "-15px"}}/></div>}
                        {hearingLocationsData && this.state.selectedOffice && <Tabs activeKey={this.state.activePaneKey} onChange={(key) => {this.setActivePaneKey(key)}}>
                            <TabPane style={{ height: "100%" }} tab={<b>Single Unavailability</b>} key="1">
                            <Row style={{ width: "100%" }}>
                                        <Col span={11}>
                                            Pick Month-Year : {' '}
                                            <MonthPicker
                                                format={monthFormat}
                                                value={moment(timeOffSelectedMonth, monthFormat)}
                                                onChange={(date, dateString) => this.handleMonthChange(date, dateString)} />
                                        </Col>
                                       <Col  span={11}> {this.state.selectedHearingLocation.HearingLocationId !== undefined && <Button size="small" style={{float: "right"}} type="primary" onClick={e => {this.setState({isNonRecurringObj: true, nonrecurringtitle: 'Add new unavailability', modalmode: 'new', createMode: true, disablefield: false});
this.props.getHearingRoomTimeOffDefaultData()}}>
                                            <Icon type="plus" theme="outlined" />Add unavailability
                                        </Button>}
                                        </Col>
                                    </Row>
                                    <br/>
                          {this.state.selectedHearingLocation.HearingLocationId !== undefined ? <div>  {this.state.nonrecurringappmnts && this.state.nonrecurringappmnts.length > 0 ? <Table
                                        scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "98%", height: "50%", marginLeft: "1%" }}
                                        pagination={false}
                                        columns={this.appointmentColumns}
                                        dataSource={this.state.nonrecurringappmnts}
                                        rowKey={record => record.AppointmentId}
                                        showHeader
                                    /> : <div>No time-off appointments at this location.</div>} </div> : <div>Please select a hearing location from the dropdown menu.</div>}
                             <Modal maskClosable={false} title={this.state.nonrecurringtitle} visible={this.state.isNonRecurringObj}  onCancel={(e) => this.setState({isNonRecurringObj: false})}
                                        footer={[
                                            <span>
                                                {this.state.createMode &&
                                                    <span>
                                                        <Button key="cancel" onClick={(e) => this.setState({isNonRecurringObj: false})}>Cancel</Button>
                                                        <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec','create')}>
                                                            Create
                                                </Button>
                                                    </span>
                                                    } 
                                            </span>,
                                            <span>
                                                {this.state.modalmode === "edit" &&
                                                      <span>
                                                      <Button key="cancel" onClick={(e) => this.setState({isNonRecurringObj: false})}>Cancel</Button>
                                                      <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec','edit')}>
                                                          Update
                                              </Button>
                                                  </span>}
                                            </span>,
                                            <span>
                                            {this.state.modalmode === "delete" &&
                                                  <span>
                                                  <Button key="cancel" onClick={(e) => this.setState({isNonRecurringObj: false})}>Cancel</Button>
                                                  <Button key="ok" type="primary" onClick={(e) => {this.props.deleteHearingRoomTimeOff(hearingRoomObj.AppointmentId);
                            }}>
                                                      Delete
                                          </Button>
                                              </span>}
                                        </span>

                                                  ]}>     { this.state.errorsList && this.state.errorsList.length > 0 &&<div style={{color: "red"}}>This time-off couldn't be updated because: <ul>{this.state.errorsList.map((item, index) => {
                                                  return <li key = {index}>{item}</li>})}</ul> </div>}
                                                     <div style={{ height: "90%" }}>                      
                              {hearingRoomObj !== undefined && hearingRoomObj !== null && <Row style={{ width: "100%" }}>
                                        <section style={{ border: "1px solid white", marginRight: "20px"}}>
                                           {hearingRoomObj.HearingRoomId !== undefined && <div>
                                                <Form layout={'horizontal'}>
                                                    <FormItem
                                                        label="Date"
                                                        {...formItemLayout}
                                                    >
                                                        <DatePicker disabled={this.state.disablefield} value={moment(hearingRoomObj.StartTime)} format={dateFormat} onChange={e => this.handleTimeOffFieldChange(e, 'date')} />
                                                    </FormItem>
                                                    <FormItem
                                                        label="Is All Day"
                                                        {...formItemLayout}
                                                    >
                                                        <Checkbox disabled={this.state.disablefield} checked={hearingRoomObj.isAllDay} onChange={e => this.handleTimeOffFieldChange(e, 'isAllDay')} />
                                                    </FormItem>
                                                    <FormItem
                                                        label="Start Time"
                                                        {...formItemLayout}
                                                    >
                                                        {this.state.disablefield ? <TimePicker disabled value={moment(hearingRoomObj.StartTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'StartTime')} />
                                                            : <TimePicker disabled={hearingRoomObj.isAllDay} value={moment(hearingRoomObj.StartTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'StartTime')} />} </FormItem>
                                                    <FormItem
                                                        label="End Time"
                                                        {...formItemLayout}
                                                    >
                                                        {this.state.disablefield ? <TimePicker disabled value={moment(hearingRoomObj.EndTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'EndTime')} />
                                                            : <TimePicker disabled={hearingRoomObj.isAllDay} value={moment(hearingRoomObj.EndTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'EndTime')} />} </FormItem>
                                                    <FormItem
                                                        label="Comments"
                                                        {...formItemLayout}
                                                    >
                                                        <TextArea disabled={this.state.disablefield} rows="3" value={hearingRoomObj.Comment} onChange={e => this.handleTimeOffFieldChange(e, 'Comment')} />
                                                    </FormItem>
                                                    <FormItem
                                                        label="Display on Schedule"
                                                        {...formItemLayout}
                                                    >
                                                        <Checkbox disabled={this.state.disablefield} checked={hearingRoomObj.isDispayComment} onChange={e => this.handleTimeOffFieldChange(e, 'isDispayComment')} />
                                                    </FormItem>
                                                </Form>
                                            </div>}
                                        </section>
                                    </Row>}
                    
                                </div>
                                </Modal>
                            </TabPane>
                            <TabPane style={{ height: "100%" }} tab={<b>Recurring Unavailability</b>} key="2">
                            <Row style={{ width: "100%" }}>
                                <Col span={11}>
                                            Pick Month-Year : {' '}
                                            <MonthPicker
                                                format={monthFormat}
                                                value={moment(timeOffSelectedMonth, monthFormat)}
                                                onChange={(date, dateString) => this.handleMonthChange(date, dateString)} />
                                        </Col>
                                <Col span={11}>{this.state.selectedHearingLocation.HearingLocationId && <Button style={{float: "right", marginRight: "3%"}} size="small" type="primary" onClick={e => {this.setState({isRecurringObj: true, recurringtitle: 'Add new unavailability', modalmode: 'new', createMode: true, disablefield: false});
this.props.getHearingRoomTimeOffDefaultData()}}>
                                            <Icon type="plus" theme="outlined" />Add Recurring unavailability
                                        </Button>}
                                        </Col></Row>
                                        <br/>
                                        <br/>
                                {this.state.selectedHearingLocation.HearingLocationId !== undefined ? <div> {this.state.recurringappmnts && this.state.recurringappmnts.length > 0 ? <Table
                                        scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "98%", height: "50%", marginLeft: "1%" }}
                                        pagination={false}
                                        columns={this.recurringColumns}
                                        dataSource={this.state.recurringappmnts}
                                        rowKey={record => record.AppointmentId}
                                        showHeader
                                    /> : <div>No time-off appointments at this location.</div>} </div> : <div>Please select a hearing location from the dropdown menu.</div>}
                             <Modal maskClosable={false} title={this.state.recurringtitle} visible={this.state.isRecurringObj}  onCancel={(e) => this.setState({isRecurringObj: false})}
                                        footer={[
                                            <span>
                                                {this.state.createMode &&
                                                    <span>
                                                        <Button key="cancel" onClick={(e) => this.setState({isRecurringObj: false})}>Cancel</Button>
                                                        <Button key="ok" type="primary" onClick={(e) => this.handleOk('rec','create')}>
                                                            Create
                                                </Button>
                                                    </span>
                                                    } 
                                            </span>,
                                            <span>
                                                {this.state.modalmode === "edit" &&
                                                      <span>
                                                      <Button key="cancel" onClick={(e) => this.setState({isRecurringObj: false, errorsList: []})}>Cancel</Button>
                                                      <Button key="ok" type="primary" onClick={(e) => this.handleOk('rec','edit')}>
                                                          Update
                                              </Button>
                                                  </span>}
                                            </span>,
                                            <span>
                                            {this.state.modalmode === "delete" &&
                                                  <span>
                                                  <Button key="cancel" onClick={(e) => this.setState({isRecurringObj: false})}>Cancel</Button>
                                                  <Button key="ok" type="primary" onClick={(e) => {this.props.deleteHearingRoomTimeOff(recurringObj.AppointmentId);
                            this.setState({ isRecurringObj: false }); }}>
                                                      Delete
                                          </Button>
                                              </span>}
                                        </span>]}>   
                                        {this.state.errorsList && this.state.errorsList.length > 0 &&<div style={{color: "red"}}>ERROR! Please correct the following: <ul>{this.state.errorsList.map((item, index) =>
                                        {
                                            return <li key={index}>{item}</li>
                                        })}</ul> </div>}
                                            {recurringObj &&  <Row style={{ width: "100%" }}>
                                        <section style={{ border: "1px solid white", marginRight: "20px"}}>
                                       {recurringObj.HearingRoomId !== undefined && <div>
                                                <Form layout={'horizontal'}>
                                                    <FormItem
                                                        label="Occurs"
                                                        {...formItemLayout}
                                                    >
                                                        <div><RadioGroup name="Recurrance" disabled={this.state.disablefield} onChange={e => this.handleRecurringFieldChange(e, 'OccuranceType')} value={recurringObj.OccuranceType}>
                                                            <Radio value={'D'}>Daily</Radio>
                                                            <Radio value={'W'}>Weekly</Radio>
                                                            <Radio value={'M'}>Monthly</Radio>
                                                            <Radio value={'Y'}>Yearly</Radio>
                                                        </RadioGroup>
                                                            {recurringObj.OccuranceType &&
                                                                <div style={{ fontSize: "12px" }}> {recurringObj.OccuranceType === 'D' && <RadioGroup name="RecurranceType" disabled={this.state.disablefield} size="small" onChange={e => this.handleRecurringFieldChange(e, 'DayType')} value={recurringObj.DayType}>
                                                                    <Radio style={{ fontSize: "12px" }} value={'1'}>Every Day</Radio>
                                                                    <Radio style={{ fontSize: "12px" }} value={'2'}>Every Week Day</Radio>
                                                                </RadioGroup>}
                                                                    {recurringObj.OccuranceType === 'W' && <span>Every week on:<RadioGroup name="Weekday" disabled={this.state.disablefield} size="small" onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheWeek')} value={recurringObj.DayOfTheWeek}>
                                                                        <Radio style={{ fontSize: "12px" }} value={'1'}>Mon</Radio>
                                                                        <Radio style={{ fontSize: "12px" }} value={'2'}>Tue</Radio>
                                                                        <Radio style={{ fontSize: "12px" }} value={'3'}>Wed</Radio>
                                                                        <Radio style={{ fontSize: "12px" }} value={'4'}>Thu</Radio>
                                                                        <Radio style={{ fontSize: "12px" }} value={'5'}>Fri</Radio>
                                                                        <Radio style={{ fontSize: "12px" }} value={'6'}>Sat</Radio>
                                                                        <Radio style={{ fontSize: "12px" }} value={'7'}>Sun</Radio>
                                                                    </RadioGroup></span>}
                                                                    {recurringObj.OccuranceType === 'M' && <span>Every month on: <RadioGroup name= "DayNumber" disabled={this.state.disablefield} value={recurringObj.selectedRadio} onChange={e =>

                                                                        this.handleRecurringFieldChange(e, 'selectedRadio')
                                                                    } >
                                                                        <Radio value={'1'}>The <select  id="dn3"  
                             onFocus={(e) => document.getElementById("dn3").click()}                disabled={recurringObj.selectedRadio === "2"} onChange={e => this.handleRecurringFieldChange(e, 'DayType')} value={recurringObj.DayType}>
                                                                            <option key="1" value="1">First</option>
                                                                            <option key="2" value="2">Second</option>
                                                                            <option key="3" value="3">Third</option>
                                                                            <option key="4" value="4">Fourth</option>
                                                                            <option key="L" value="L">Last</option>
                                                                        </select>
                                                                            <select  id="dow3"  
                             onFocus={(e) => document.getElementById("dow3").click()}                disabled={recurringObj.selectedRadio === "2"} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheWeek')} value={recurringObj.DayOfTheWeek}>
                                                                                <option key="1" value="1">Sunday</option>
                                                                                <option key="2" value="2">Monday</option>
                                                                                <option key="3" value="3">Tuesday</option>
                                                                                <option key="4" value="4">Wednesday</option>
                                                                                <option key="5" value="5">Thursday</option>
                                                                                <option key="6" value="6">Friday</option>
                                                                                <option key="7" value="7">Saturday</option>
                                                                                <option key="W" value="W">Weekday</option>
                                                                                <option key="E" value="E">Weekend</option></select>
                                                                        </Radio>of every month.
                                                                            <Radio value={'2'}>Day<InputNumber disabled={recurringObj.selectedRadio === "1"} min={1} max={31}
                                                                            onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheMonth')} value={recurringObj.DayOfTheMonth} /> of every month.</Radio>
                                                                    </RadioGroup>
                                                                    </span>}
                                                                    {recurringObj.OccuranceType === 'Y' && <span>Every year on: <RadioGroup name="Month" disabled={this.state.disablefield} value={recurringObj.selectedRadio} onChange={e =>

                                                                        this.handleRecurringFieldChange(e, 'selectedRadio')}>
                                                                        <Radio value={'1'}><select  id="moy3"  
                             onFocus={(e) => document.getElementById("moy3").click()}                disabled={recurringObj.selectedRadio === "2"} onChange={e => this.handleRecurringFieldChange(e, 'MonthOfTheYear')} value={recurringObj.MonthOfTheYear}> <option key="1" value="1">January</option>
                                                                            <option key="2" value="2">February</option>
                                                                            <option key="3" value="3">March</option>
                                                                            <option key="4" value="4">April</option>
                                                                            <option key="5" value="5">May</option>
                                                                            <option key="6" value="6">June</option>
                                                                            <option key="7" value="7">July</option>
                                                                            <option key="8" value="8">August</option>
                                                                            <option key="9" value="9">September</option>
                                                                            <option key="10" value="10">October</option>
                                                                            <option key="11" value="11">November</option>
                                                                            <option key="12" value="12">December</option>
                                                                        </select> on the day <InputNumber disabled={recurringObj.selectedRadio === "2"} min={1} max={31} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheMonth')} value={recurringObj.DayOfTheMonth} /></Radio>
                                                                        <Radio value={'2'}>The <select  id="dn4"  
                             onFocus={(e) => document.getElementById("dn4").click()}                disabled={recurringObj.selectedRadio === "1"} onChange={e => this.handleRecurringFieldChange(e, 'DayType')} value={recurringObj.DayType}>
                                                                            <option key="1" value="1">First</option>
                                                                            <option key="2" value="2">Second</option>
                                                                            <option key="3" value="3">Third</option>
                                                                            <option key="4" value="4">Fourth</option>
                                                                            <option key="L" value="L">Last</option>
                                                                        </select><select  id="dow4"  
                             onFocus={(e) => document.getElementById("dow4").click()}                disabled={recurringObj.selectedRadio === "1"} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheWeek')} value={recurringObj.DayOfTheWeek}> <option key="1" value="1">Sunday</option>
                                                                                <option key="2" value="2">Monday</option>
                                                                                <option key="3" value="3">Tuesday</option>
                                                                                <option key="4" value="4">Wednesday</option>
                                                                                <option key="5" value="5">Thursday</option>
                                                                                <option key="6" value="6">Friday</option>
                                                                                <option key="7" value="7">Saturday</option>
                                                                            </select> of <select  id="moy4"  
                             onFocus={(e) => document.getElementById("moy4").click()}                disabled={recurringObj.selectedRadio === "1"} onChange={e => this.handleRecurringFieldChange(e, 'MonthOfTheYear')} value={recurringObj.MonthOfTheYear}> <option key="1" value="1">January</option>
                                                                                <option key="2" value="2">February</option>
                                                                                <option key="3" value="3">March</option>
                                                                                <option key="4" value="4">April</option>
                                                                                <option key="5" value="5">May</option>
                                                                                <option key="6" value="6">June</option>
                                                                                <option key="7" value="7">July</option>
                                                                                <option key="8" value="8">August</option>
                                                                                <option key="9" value="9">September</option>
                                                                                <option key="10" value="10">October</option>
                                                                                <option key="11" value="11">November</option>
                                                                                <option key="12" value="12">December</option>
                                                                            </select> </Radio>
                                                                    </RadioGroup></span>}
                                                                </div>}
                                                        </div>
                                                    </FormItem>

                                                    <FormItem
                                                        label="Duration"
                                                        {...formItemLayout}
                                                    >
                                                        <div><div><div style={{ width: "50%", float: "left" }}>Start Date: <DatePicker disabled={this.state.disablefield} placeholder="Start Date" value={moment(recurringObj.StartDate)} format={dateFormat} onChange={(e) => this.handleRecurringFieldChange(e, 'StartDate')} /></div>
                                                            <RadioGroup name="endDate" disabled={this.state.disablefield} onChange={e => this.handleRecurringFieldChange(e, 'EndDateOption')} value={recurringObj.EndDateOption}>
                                                                <Radio style={radioStyle} value={'Y'}>End Date: {recurringObj.EndDateOption !== 'N' ? <DatePicker placeholder="End Date" value={moment(recurringObj.EndDate)} format={dateFormat} onChange={e => this.handleRecurringFieldChange(e, 'EndDate')} /> :
                                                                    <DatePicker disabled placeholder="Start Date" value={moment(recurringObj.EndDate)} format={dateFormat} />}
                                                                </Radio>
                                                                <Radio style={radioStyle} value={'N'}>No End Date</Radio>
                                                            </RadioGroup></div>
                                                            <div><span> <Checkbox disabled={this.state.disablefield} checked={recurringObj.isAllDay} onChange={e => this.handleRecurringFieldChange(e, 'isAllDay')}>Is All Day</Checkbox></span>
                                                                <span>  Start Time: {this.state.disablefield ? <TimePicker disabled value={moment(recurringObj.StartTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'StartTime')} />
                                                                    : <TimePicker disabled={recurringObj.isAllDay} value={moment(recurringObj.StartTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'StartTime')} />}
</span><span>
                                                                    End Time: {this.state.disablefield ? <TimePicker disabled value={moment(recurringObj.EndTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'EndTime')} />
                                                                        : <TimePicker disabled={recurringObj.isAllDay} value={moment(recurringObj.EndTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'EndTime')} />}</span></div></div> </FormItem>
                                                    <FormItem
                                                        label="Comments"
                                                        {...formItemLayout}
                                                    >
                                                        <TextArea disabled={this.state.disablefield} rows="3" value={recurringObj.Comment} onChange={e => this.handleRecurringFieldChange(e, 'Comment')} />
                                                    </FormItem>
                                                    <FormItem
                                                        label="Display on Schedule"
                                                        {...formItemLayout}
                                                    >
                                                        <Checkbox disabled={this.state.disablefield} checked={recurringObj.isDispayComment} onChange={e => this.handleRecurringFieldChange(e, 'isDispayComment')} />
                                                    </FormItem>
                                                </Form>
                                                {/* {this.state.editmode === false && this.state.createMode === false && <div style={{width: "100%"}}>
                                            <Button size="small" type="primary" style={{float: "right", color: "white", backgroundColor: "red", marginLeft: "10px"}} onClick={this.handleDelete}>
                        Delete
                    </Button>           
                    <Modal visible={this.state.deleteModalVisible}
                        width="20%"
                        title={'Delete'}
                        onCancel={(e) => this.setState({ deleteModalVisible: false })}
                        onOk={(e) => {this.props.deleteHearingRoomTimeOff(recurringObj.AppointmentId);
                            this.setState({ deleteModalVisible: false }); }}
                    >
                        Are you sure to delete ?
                    </Modal> 
                                            </div>} */}
                                            </div>}
                                        </section>
                                    </Row> }
                                    </Modal>
                            </TabPane>
                        </Tabs>}
                    </div>
                </Col>
            </Row>
        // </ScrollPanel>
        );
    }
}

const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getHearingLocation, 
            getMyDistrictOffices, 
            getHearingRoomTimeOff, 
            getHearingRoomTimeOffDefaultData, 
            getHearingRoomTimeOffEditData, 
            createHearingRoomTimeOff, 
            editHRTimeOff, 
            deleteHearingRoomTimeOff,
            getListOfEmployeesForOffice
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(HearingRoomUnavailability);

