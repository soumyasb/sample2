import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import {  getHearingLocation, getListOfEmployeesForOffice, getMyDistrictOffices, getDefaultRoomProfile, getHearingRoomProfileByLocation, updateHearingRoomProfile } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import moment from "moment";
import { Table, Modal, notification, Button, Menu, Icon, TimePicker, Checkbox } from 'antd';
import "../../../emp.css";
import cloneDeep from 'lodash/cloneDeep';

const format = 'HH:mm';

const hearingLocationcolumns = [
    {
        title: <b>Location Id</b>,
        dataIndex: 'HearingLocationId',
        width: "15%",
        key: 'HearingLocationId'
    },
    {
        title: <b>Room Number</b>,
        dataIndex: 'RoomNumber',
        width: "15%",
        key: 'RoomNumber'
    },
    {
        title: <b>Room Description</b>,
        dataIndex: 'RoomDescription',
        width: "35%",
        key: 'RoomDescription'
    },
    {
        title: <b>Closed Date</b>,
        dataIndex: 'ClosedDate',
        key: 'ClosedDate',
        render: (item) =>
        {
           if(moment(item).format("MM-DD-YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM-DD-YYYY");
           }
        }}
    ];

 
class HearingRoomProfiles extends Component {
    constructor(props) {
        super(props);
        this.state={
            districtOffices: props.profiles.districtOfficesData,
            hearingLocationsData: props.profiles.hearingLocationsData,
            editmode: false,
            newprofModalVisible: false
        };    
        this.onTimeChange = this.onTimeChange.bind(this);
        this.onValueChange =  this.onValueChange.bind(this);
        this.onOfficeListRowClick = this.onOfficeListRowClick.bind(this);
        this.openNotification = this.openNotification.bind(this);
        this.onButtonClick = this.onButtonClick.bind(this);
        this.changeSelection = this.changeSelection.bind(this);
        this.onToggle = this.onToggle.bind(this);
    }
    componentDidMount()
    {
        this.props.getMyDistrictOffices();
    }
  
componentWillReceiveProps(nextProps) {
    if(this.props.profiles.districtOfficesData !== nextProps.profiles.districtOfficesData && nextProps.profiles.districtOfficesData !== undefined )
    {
        this.setState({districtOffices: nextProps.profiles.districtOfficesData});
        if(nextProps.profiles.districtOfficesData.length > 0){this.setState({selectedOffice: nextProps.profiles.districtOfficesData[0]});
        this.props.getHearingLocation(parseInt(nextProps.profiles.districtOfficesData[0].OfficeID, 10));}
    }
    if(this.props.profiles.defaultRoomProfileData !== nextProps.profiles.defaultRoomProfileData)
    {
        this.setState({newRoomProfile: nextProps.profiles.defaultRoomProfileData.HearingRoomProfile});
    }
    if(this.props.profiles.employeeList !== nextProps.profiles.employeeList && nextProps.profiles.employeeList)
    { 
        const {selectedRoomProfile} = this.state;

       if(selectedRoomProfile)
       {
        nextProps.profiles.employeeList.map((eitem) =>
        {
            if( selectedRoomProfile.UpdatedBy === eitem.Empid)
            {
                selectedRoomProfile.UpdatedByName = eitem.FirstName+" "+eitem.MiddleName+" "+eitem.LastName;
            }
            return "";
        });  
       } 
    this.setState({selectedRoomProfile});
    }

    if(this.props.profiles.updatedRoomProfile !== nextProps.profiles.updatedRoomProfile)
    {
        this.openNotification("The hearing room's profile has been updated successfully!");
        this.props.getHearingRoomProfileByLocation(this.state.selectedRoomId);
    }
    if(this.props.profiles.profilesErrorData && this.props.profiles.profilesErrorData !== nextProps.profiles.profilesErrorData)
    {
        let errors = [];
        if(nextProps.profiles.profilesErrorData.status === 422)
        {
    
           Object.keys(nextProps.profiles.profilesErrorData.data).map((keyName, keyIndex) =>
        {
            errors.push(nextProps.profiles.profilesErrorData.data[keyName][0]);
            return "";
        })
        }
        this.setState({updateErrors: errors});
    }
    if(this.props.profiles.hearingLocationsData !== nextProps.profiles.hearingLocationsData)
    {
        if(nextProps.profiles.hearingLocationsData.length >0)
        {
            this.setState({hearingLocationsData: nextProps.profiles.hearingLocationsData, selectedHearingRoom: nextProps.profiles.hearingLocationsData[0]});
            if(nextProps.profiles.hearingLocationsData[0].HearingLocationId !== undefined || nextProps.profiles.hearingLocationsData[0].HearingLocationId !== null)
            {
             this.props.getHearingRoomProfileByLocation(nextProps.profiles.hearingLocationsData[0].HearingLocationId);
             this.setState({selectedRoomId: nextProps.profiles.hearingLocationsData[0].HearingLocationId});
            }
        }
        else
        {
            this.setState({hearingLocationsData: []});
        }
    }   
    if(this.props.profiles.hearingRoomProfilebyLocation !== nextProps.profiles.hearingRoomProfilebyLocation)
    {
        this.props.getListOfEmployeesForOffice();
        if(nextProps.profiles.hearingRoomProfilebyLocation.Id !== undefined)
  {
  this.setState({selectedRoomProfile: nextProps.profiles.hearingRoomProfilebyLocation, modifiedRoomProfile: cloneDeep(nextProps.profiles.hearingRoomProfilebyLocation), newprofModalVisible: false, updateErrors: []});
      this.openNotification('updated');
  }
  else
  {
    //   if(nextProps.profiles.hearingRoomProfilebyLocation.HearingRoomProfile)
    //   {
        this.setState({selectedRoomProfile: nextProps.profiles.hearingRoomProfilebyLocation.HearingRoomProfile, modifiedRoomProfile: cloneDeep(nextProps.profiles.hearingRoomProfilebyLocation.HearingRoomProfile)});
//       }
// else
// {
//     this.setState({selectedRoomProfile: null, modifiedRoomProfile: cloneDeep(nextProps.profiles.hearingRoomProfilebyLocation.HearingRoomProfile)});
// }
  }
    }   
}
changeSelection = (selection) =>
{
    this.setState({selectedRoomId: selection});
}

onOfficeListRowClick = (value) =>
{
    const selectedHearingRoom = this.state.hearingLocationsData.find((item) => {
        return item.HearingLocationId.toString() === value;
    });
this.setState({selectedHearingRoom: selectedHearingRoom, editmode: false});
this.props.getHearingLocation(parseInt(value,10));
}

onValueChange = (e, idx, field) =>
{
    const { newHearingAuthData } = this.state;
    if(field === 'Active')
{
    newHearingAuthData[idx].Active = e.target.checked;
    if(e.target.checked === false)
    {
    newHearingAuthData[idx].HearingTime = 0;
    newHearingAuthData[idx].InterviewTime = 0;
    newHearingAuthData[idx].ReExamTime = 0;
    }
}
else if(field === 'CategoryName')
{
    newHearingAuthData[idx].CategoryName = e.target.value;
}
else{
    newHearingAuthData[idx][field] = e;
}
    this.setState({newHearingAuthData});
}

getMenuList(districtOffices)
{
    let officesList = [];
    districtOffices.map((item) =>
{
    officesList.push(<Menu.Item key={item.OfficeID}>{<div style={{textAlign: "center"}}><div style={{height: "35px",fontSize:16, fontWeight: "bold"}}>{item.OfficeID}-{item.Name}</div> 
    <div style={{height: "35px",marginTop: "-18px", fontSize:11}}>{item.AddressLineOne}</div>
    <div  style={{height: "35px",marginTop: "-18px", fontSize:11}}>{item.city}-{item.Zip}.  <b>Ph:</b>{item.PhoneNumber}</div></div>}</Menu.Item>)
    return "";
})
return officesList;

}

onTimeChange = (t,ts,v,type) =>
{
    if(type !== 'new')
    {
const { modifiedRoomProfile } = this.state;
if(t !== null)
{
    modifiedRoomProfile[v] = ts;
}

this.setState({modifiedRoomProfile});
    }
    else{
        const { newRoomProfile } = this.state;
if(t !== null)
{
    newRoomProfile[v] = ts;
}

this.setState({newRoomProfile});
    }
}

openNotification = (msg) => {
    notification.open({
      message: 'SUCCESS',
      description: msg,
      style: {
        width: 600,
        marginLeft: 335 - 600,
        backgroundColor: "#9cd864",
        fontWeight: 'bold'
      },
    });
  }

  onButtonClick = (type) => 
  {
if(type === 'edit')
{
    this.setState({editmode: true});
}
if(type === 'save')
{
    this.setState({editmode: false});
    this.props.updateHearingRoomProfile(this.state.modifiedRoomProfile);
}
if(type === 'cancel')
{
    const modifiedRoomProfile = cloneDeep(this.state.selectedRoomProfile);
    this.setState({editmode: false, modifiedRoomProfile: modifiedRoomProfile, updateErrors: []}); 
}
if(type === 'add')
{
    this.props.updateHearingRoomProfile(this.state.newRoomProfile);
}
if(type === 'new')
{
    this.props.getDefaultRoomProfile(this.state.selectedRoomId);
    this.setState({newprofModalVisible: true});
}
  }

  onToggle = () =>
  {
      const {modifiedRoomProfile} = this.state;
      modifiedRoomProfile.isActive = !modifiedRoomProfile.isActive;
      this.setState({modifiedRoomProfile});
  }

    render() {
const {hearingLocationsData} = this.state;
const {modifiedRoomProfile} = this.state;
const {newRoomProfile} = this.state;

let selectedRowKeys =[];
        let officesList = [];
        if(this.state.districtOffices !== undefined ) {  officesList=  this.getMenuList(this.state.districtOffices); }
 
        if(this.state.hearingLocationsData !== undefined && this.state.hearingLocationsData !== [])
            {                   
                this.state.hearingLocationsData.map((item, idx) => 
              {
                        if(item.HearingLocationId === this.state.selectedRoomId)
                        {
                            selectedRowKeys[0] = item.HearingLocationId;
                            return selectedRowKeys;
                        }
                        return "";
              })
          
            }
            const rowSelection = {
                selectedRowKeys: selectedRowKeys,
                  onChange: (selectedRowKeys, selectedRows) => {
                      this.props.getHearingRoomProfileByLocation( selectedRows[0].HearingLocationId);
                 this.changeSelection(selectedRows[0].HearingLocationId);
                  },
                  type: "radio"            
                };
        return (  
    //   <ScrollPanel
    //         style={{
    //             width: "100%",
    //             height: "100%",
    //             backgroundColor: "rgba(0,0,0,0)"
    //         }}>
            <Row style={{
            marginLeft: "2.5%",
            width: "95%",
            height: "800px",
            border: "2px solid white"}}>
          <div style={{height: "7%", border: "1px solid white"}} >
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>Hearing Room Profiles</span></div>
            <Col span={5} style={{
             height: "93%",
            border: "1px solid white"}}>
           <div style={{
             height: "5%",  paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"}}>Select An Office</div>
              <ScrollPanel
            style={{
                height: "95%",
                backgroundColor: "#c9e3fa"
            }}>

{this.state.selectedOffice && <Menu onClick={(e) => this.onOfficeListRowClick(e.key)}
mode = "vertical"
      defaultSelectedKeys={[this.state.selectedOffice.OfficeID.toString()]}
>
{officesList}

</Menu>
}

 </ScrollPanel></Col>
             <Col style={{
             height: "93%",
            border: "1px solid white"}}>
            
            <div style={{height: "50%", border: "1px solid white", backgroundColor: "#d5d5d5"}}>
           <div style={{
                height: "10%",  paddingTop: "7px", backgroundColor: "#d5d5d5", border: "1px solid white"}}><span style={{paddingLeft: "1%", width: "60%", float: "left"}}>Hearing Rooms at the office: {this.state.selectedOffice &&  <span style={{fontWeight: "bold"}}><b>{this.state.selectedOffice.OfficeID}-{this.state.selectedOffice.Name}</b></span>}</span> <div>
                </div></div>          <div style={{ height: "100%", overflow: "hidden"}}>                 
                {this.state.hearingLocationsData ? <div>{this.state.hearingLocationsData.length > 0 ? <Table
                    scroll = {{ y: 250}}
                    bordered={false}
                    size='small'
                    style={{ width: "98%", marginLeft: "1%"}}
                    pagination={false}
                    columns={hearingLocationcolumns}
                    dataSource={hearingLocationsData}
                    rowKey={record => record.HearingLocationId}
                    showHeader
                    rowSelection={rowSelection}
                    onRow={(record) => ({
                        onClick: (e) => {
                            this.props.getHearingRoomProfileByLocation(record.HearingLocationId);
                            this.setState({selectedRoomId: record.HearingLocationId});
                        },
                      })}
                    /> : <div style={{textAlign:"center", marginTop: "10%"}}>No hearing rooms at this location.</div>}</div> : <div></div> }
                </div>
                </div>
                <div style={{height: "50%", border: "1px solid #d5d5d5",backgroundColor: "#d5d5d5"}}>
                
                <div style={{
    height: "10%", paddingTop: "7px", backgroundColor: "#d5d5d5", border: "2px solid white"}}> <span style={{paddingLeft: "1%", width: "60%", float: "left"}}>Hearing Room profile for  {this.state.selectedHearingRoom && <span style={{fontWeight: "bold"}}><b>Location Id: </b>{this.state.selectedRoomId}</span>}</span>
                  { this.state.hearingLocationsData && this.state.hearingLocationsData.length >0 ? this.state.modifiedRoomProfile !== undefined && (this.state.modifiedRoomProfile !== null && this.state.modifiedRoomProfile.Id !== undefined) ?
                  <div>  {this.state.editmode === false ? <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}} onClick={(e) => {
                      this.onButtonClick('edit');  
                    }}>
                  <Icon type="edit"></Icon> Edit Profile
                    </Button> : <span style={{float: "right", marginRight: "10px"}}><Button size="small" type="default" style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} onClick={(e) => {
                            this.onButtonClick('cancel');  
                    }}>
                  <Icon type="close"></Icon> Cancel
                    </Button><Button size="small" type="default" style={{ color:  "white", backgroundColor: "green"}} onClick={(e) => {
                    this.onButtonClick('save');
                    }}>
                  <Icon type="check"></Icon> Save
                </Button>
                   {/* */}</span>}</div> : <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}} onClick={(e) => {
                    this.onButtonClick('new');
                }}>
                <Icon type="plus-square"></Icon> New Profile
                </Button>:<span></span> }</div>
                <Modal maskClosable={false} visible={this.state.newprofModalVisible}
             width= "60%"
          title= "Create New Room Profile"
          onCancel={(e) => this.setState({newprofModalVisible: false})}
          footer={[
              <div>{this.props.profiles.profilesErrorData === undefined ?
           <span><Button key="cancel" onClick={(e) => this.setState({newprofModalVisible: false})}>Cancel</Button>
           <Button key="ok" type="primary" onClick={(e) => {this.onButtonClick('add')}}>
              Create
          </Button></span> : <span> <Button key="ok" type="primary" onClick={(e) => {this.onButtonClick('new')}}>
              OK
              </Button></span>}</div>]}><div> {this.state.newRoomProfile !== undefined && (this.state.newRoomProfile !== null && this.state.newRoomProfile.Id !== undefined) && <div style={{ height: "100%", overflow: "hidden"}}>                
                      <div style={{marginLeft: "10px", marginTop: "1%", width: "98%"}}><div style={{height: "5%", backgroundColor: "white"}}>Connections:</div><Row gutter={16} style={{marginTop: "2%"}}><Col span= {8}><Checkbox style={{marginRight: "2%"}} checked={newRoomProfile.isActive} onChange={this.onToggle}></Checkbox>Is Active?</Col></Row><div style={{height: "5%", backgroundColor: "white", marginBottom: "1%", marginTop: "2%"}}>Availability:</div><Row><Col span={3}><b>Day of Week</b></Col><Col span={3}><b>Sunday</b></Col><Col span={3}><b>Monday</b></Col><Col span={3}><b>Tuesday</b></Col><Col span={3}><b>Wednesday</b></Col><Col span={3}><b>Thursday</b></Col>
          <Col span={3}><b>Friday</b></Col><Col span={3}><b>Saturday</b></Col>    
            {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
          <div><Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Col><Col span={3}><TimePicker value={moment(newRoomProfile.SunStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SunStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.MonStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'MonStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.TueStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'TueStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.WedStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'WedStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.ThuStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'ThuStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.FriStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'FriStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.SatStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SatStartTime', 'new')} /></Col>

            <Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Col><Col span={3}><TimePicker value={moment(newRoomProfile.SunEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SunEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.MonEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'MonEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.TueEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'TueEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.WedEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'WedEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.ThuEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'ThuEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.FriEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'FriEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.SatEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SatEndTime', 'new')} /></Col>
 </div>
                {this.state.updateErrors && this.state.updateErrors.length > 0 && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><div> {this.state.updateErrors}</div></div>} </Row>
                    
              </div> </div>}</div></Modal>
                    {this.state.hearingLocationsData && this.state.hearingLocationsData.length >0 ? <div> {this.state.modifiedRoomProfile ? this.state.modifiedRoomProfile.Id && <div style={{ height: "100%", overflow: "hidden"}}>                
                     <div style={{marginLeft: "10px", marginTop: "1%", width: "98%"}}><div>{this.state.selectedRoomProfile && <span><span><b>Updated By: </b>{"  "}{this.state.selectedRoomProfile.UpdatedByName}</span><span style={{marginLeft: "20%"}}><b>Updated On:</b>{"  "}{moment(this.state.selectedRoomProfile.UpdatedDate).format("MM-DD-YYYY").includes("Invalid") ?  "-": moment(this.state.selectedRoomProfile.UpdatedDate).format("MM-DD-YYYY")}</span></span>}</div><div style={{marginTop: "10px", height: "5%", backgroundColor: "white"}}>Connections:</div><Row gutter={16} style={{marginTop: "2%"}}><Col span= {8}><Checkbox style={{marginRight: "2%"}} checked={modifiedRoomProfile.isActive} onChange={this.onToggle} disabled= {!this.state.editmode}></Checkbox>Is Active?</Col></Row><div style={{height: "5%", backgroundColor: "white", marginBottom: "1%", marginTop: "2%"}}>Availability:</div><Row><Col span={3}><b>Day of Week</b></Col><Col span={3}><b>Sunday</b></Col><Col span={3}><b>Monday</b></Col><Col span={3}><b>Tuesday</b></Col><Col span={3}><b>Wednesday</b></Col><Col span={3}><b>Thursday</b></Col>
          <Col span={3}><b>Friday</b></Col><Col span={3}><b>Saturday</b></Col>    
            {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
          <div><Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Col><Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.SunStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SunStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.MonStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'MonStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.TueStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'TueStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.WedStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'WedStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.ThuStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'ThuStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.FriStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'FriStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.SatStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SatStartTime')} /></Col>

            <Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Col><Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.SunEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SunEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.MonEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'MonEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.TueEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'TueEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.WedEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'WedEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.ThuEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'ThuEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.FriEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'FriEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.SatEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'SatEndTime')} /></Col>
 </div>
                {this.state.updateErrors && this.state.updateErrors.length > 0  && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><div> {this.state.updateErrors}</div></div>} </Row>
                    
                    </div> } </div>: <div>No profile data exists for the selection.</div>}</div> : <div style={{textAlign:"center", marginTop: "10%"}}>No Profiles.</div>}
              
               </div></Col>
        </Row>
        // </ScrollPanel>
        );
}
}
const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getHearingLocation,
            getMyDistrictOffices,
            getHearingRoomProfileByLocation,
            updateHearingRoomProfile,
            getDefaultRoomProfile,
            getListOfEmployeesForOffice
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(HearingRoomProfiles);
