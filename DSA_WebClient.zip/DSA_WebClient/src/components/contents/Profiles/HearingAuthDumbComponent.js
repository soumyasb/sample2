import React, {Component} from 'react';
import { Row, Col, InputNumber, Checkbox, Button, Icon, Table, Input } from 'antd';
import moment from 'moment';
const hearingAuthColumns = [  {
    title: <b>Category ID</b>,
    dataIndex: 'CategoryID',
   width: "15%",
    key: 'CategoryID'
  }, {
    title: <b>Category</b>,
    dataIndex: 'CategoryName',
   width: "20%",
    key: 'CategoryName'
  },
  {
    title: <b>Hearing</b>,
    dataIndex: 'HearingTime',
   width: "15%",
    key: 'HearingTime',
    render: (item) =>
    {
       if( item === 0)
       {
           return "-";
       }
       else
       {
           return item;
       }
    }
  },
  {
    title: <b>Interview</b>,
    dataIndex: 'InterviewTime',
   width: "15%",
    key: 'InterviewTime',
    render: (item) =>
    {
       if( item === 0)
       {
           return "-";
       }
       else
       {
           return item;
       }
    }
  },
  {
    title: <b>Re-Examination</b>,
    dataIndex: 'ReExamTime',
   width: "15%",
    key: 'ReExamTime',
    render: (item) =>
    {
       if( item === 0)
       {
           return "-";
       }
       else
       {
           return item;
       }
    }
  },
  {
    title: <b>Last Updated</b>,
    dataIndex: 'lastUpdated',
   width: "20%",
    key: 'lastUpdated',
    render: (item) =>
    {
       if( moment(item).format("MM-DD-YYYY").includes("Invalid"))
       {
           return "-";
       }
       else
       {
           return moment(item).format("MM-DD-YYYY");
       }
    }
  }];

class HearingAuthDumbComponent extends Component {
constructor (props)
{
    super(props);
    this.state = {
        selectedEmployeeInChildComponent: this.props.selectedEmployeeFromParent
    }
}
    render()
    {
        return (
<div>
   {this.props.selectedEmpNameFromParent && <div><span style={{marginLeft: "1%"}}>Employee:  {this.props.selectedEmpNameFromParent.split("-")[0]}</span><span style={{marginLeft: "3%"}}>User ID: {this.props.selectedEmployeeFromParent.UserID}</span></div>}
   
   <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} >{this.props.autheditmodeFromParent === true ? (<div style={{marginTop: "1%"}}><span style={{fontSize: '15px', paddingLeft: '0.5%'}}>Schedule Authorization Update</span><span style={{float: "right", marginRight: "3%"}}> <Button style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} type="default" size={"small"} onClick={(e) => this.props.onButtonClickFromParent(e,'Cancel')}>Cancel</Button> 
   <Button  style={{ color:  "white", backgroundColor: "green"}} type="default" size={"small"} onClick={(e) => this.props.onButtonClickFromParent(e,'Save')}>Save</Button></span></div>) :
   <div style={{marginTop: "1%"}}><span style={{fontSize: '15px', paddingLeft: '0.5%'}}>Existing Schedule Authorization </span>{this.props.hearingAuthDataFromParent && this.props.hearingAuthDataFromParent.length === 0 ?<Button style={{float: "right", marginRight:"2%"}}type="primary" size={"small"} onClick={(e) => this.props.onButtonClickFromParent(e,'Add')}> <Icon type="plus-square"/>Create Hearing Authorization</Button>:<Button style={{float: "right", marginRight:"2%"}}type="primary" size={"small"} onClick={(e) => this.props.onButtonClickFromParent(e,'Edit')}> <Icon type="edit"/>Edit</Button>}</div>}</div>
   
   {this.props.autheditmodeFromParent === true ? this.props.newHearingAuthDataFromParent && <div> <Row style={{marginTop: "1%"}}><Col span={2}><b>Active</b></Col><Col span={2}><b>Category ID</b></Col><Col span={5}><b>Category</b></Col><Col span={5}><b>Hearing</b></Col><Col span={5}><b>Interview</b></Col><Col span={5}><b>Re-Examinatiion</b></Col></Row>
   
   {     
       this.props.newHearingAuthDataFromParent.map((item,idx) => {
           return( 
            <Row style={{marginTop: "1%"}} key={item.id}><Col  span={2} ><Checkbox checked={item.Active} key={item.ID+idx} onChange={(e) => this.props.onValueChangeFromParent(e,idx,'Active')}></Checkbox></Col>
            <Col span={2} >{item.CategoryID}</Col>
            <Col span={5} ><Input defaultValue={item.CategoryName} style={{width: "80%", height: "100%"}} disabled={!item.Active} key={item.ID+"-cn"} onChange={(e) => this.props.onValueChangeFromParent(e,idx,'categoryName')} /></Col>
            <Col span={5} ><InputNumber step={15} min={0} max={180} defaultValue={item.HearingTime} style={{width: "80%", height: "100%"}} disabled={!item.Active} key={item.ID+"-ht"} onChange={(e) => this.props.onValueChangeFromParent(e,idx,'HearingTime')} /></Col>
            <Col span={5} ><InputNumber step={15} min={0} max={180} defaultValue={item.InterviewTime} style={{width: "80%", height: "100%"}} disabled={!item.Active} key={item.ID+"-int"} onChange={(e) => this.props.onValueChangeFromParent(e,idx,'InterviewTime')}  /></Col>
   <Col  span={5} ><InputNumber step={15} min={0} max={180} defaultValue={item.ReExamTime} style={{width: "80%", height: "100%"}} disabled={!item.Active}  key={item.ID+"-reex"} onChange={(e) => this.props.onValueChangeFromParent(e,idx,'ReExamTime')} /></Col></Row>);
   })
   }
           </div>  
            : this.props.newHearingAuthDataFromParent && this.props.newHearingAuthDataFromParent.length !== 0 ? <Table
                                 bordered = {false} 
                                 size = 'small'                           
                                 pagination = {false}
                                 columns={hearingAuthColumns} 
                                 dataSource={this.props.newHearingAuthDataFromParent}
                                 showHeader
                                />: <div style={{marginLeft: "20px", fontSize: "20px"}}><b>No existing Hearing Authorization schedule found for this employee. Please create one.</b></div>}
    </div>
        )
    }
}

export default HearingAuthDumbComponent;



