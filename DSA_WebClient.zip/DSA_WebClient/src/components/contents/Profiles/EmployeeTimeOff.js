import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { getListOfEmployeesForOffice, getTimeOffDetailsforEmployee, getTimeOffCreateScreen, getEmployeeAppointment, createEmployeeTimeOff
, editEmployeeTimeOff, deleteEmployeeTimeOff } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import "../../../Prof.css";
import moment from "moment";
import cloneDeep from 'lodash/cloneDeep';
import {
    Table, Tabs, DatePicker, InputNumber, Divider, Modal, Input, Button, TimePicker,
    Select, Menu, Icon, Checkbox, Form, Radio, notification
} from 'antd';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;
const { TabPane } = Tabs;
const RadioGroup = Radio.Group;
const { MonthPicker } = DatePicker;
const monthFormat = 'MM-YYYY';
const timeFormat = 'HH:mm';
const dateFormat = 'MM-DD-YYYY';

const formItemLayout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
};

const OccuranceType = {
    D: 'Daily',
    W: 'Weekly',
    B: 'Bi-Weekly',
    M: 'Monthly',
    Y: 'Yearly'
}

class EmployeeTimeOff extends Component {
    constructor(props) {
        super(props);

        this.appointmentColumns = [
            {
                title: <b>Date</b>,
                dataIndex: 'StartTime',
                width: "15%",
                key: 'StartDate',
                render: item => {
                    return moment(item).format("MM-DD-YYYY");
                }
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: "20%",
                key: 'time'
            },
            {
                title: <b>Description</b>,
                dataIndex: 'ActivityType',
                key: 'Description',
                width: "15%"
            },
            {
                title: <b>Updated By</b>,
                dataIndex: 'UpdatedByName',
                width: "20%",
                key: 'UpdatedByName'
            },
            {
                title: <b>Updated On</b>,
                dataIndex: 'DateUpdated',
                width: "20%",
                key: 'DateUpdated',
                render: (item) =>
                {                   
           if( moment(item).format("MM-DD-YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM-DD-YYYY");
           }
                }
            },
            {
                title: <b>Options</b>,
                width: '10%',
                render: (item) => {
                
                    return (
                        <div>
                            <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.ReacurrenceNumber, item.AppointmentNumber, false)} />
                            <Divider type="vertical" />
                            <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.ReacurrenceNumber, item.AppointmentNumber, false)} />
                        </div>
                    );
                },
            }
        ];

        this.conflictsColumns = [
            {
                title: <b>Case Number</b>,
                dataIndex: 'CaseNumber',
                width: "25%",
                key: 'CaseNumber'
            },
            {
                title: <b>Start Date</b>,
                dataIndex: 'conflictDateTimeStart',
                width: "20%",
                key: 'conflictDateTimeStart',
                render: (item) => {
                    return moment(item).format("MM-DD-YYYY")
                }
            }, 
            {
                title: <b>End Date</b>,
                dataIndex: 'confilctDateTimeEnd',
                width: "20%",
                key: 'confilctDateTimeEnd',
                render: (item) => {
                    return moment(item).format("MM-DD-YYYY")
                }
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: "35%",
                key: 'time'
            }
        ];

        this.recurringColumns = [
            {
                title: <b>Occurs</b>,
                dataIndex: 'OccuranceType',
                width: '10%',
                key: 'OccuranceType',
                render: item => OccuranceType[item]
            },
            {
                title: <b>Start Date</b>,
                dataIndex: 'StartTime',
                key: 'StartDate',
                width: '10%',
                render: item => moment(item).format("MM-DD-YYYY")
            },
            {
                title: <b>End Date</b>,
                dataIndex: 'EndTime',
                width: '10%',
                key: 'EndDate',
                render: item => moment(item).format("MM-DD-YYYY").includes("9999") ? "NO END DATE" : moment(item).format("MM-DD-YYYY")
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: '15%',
                key: 'time'
            },
            {
                title: <b>Description</b>,
                dataIndex: 'ActivityType',
                width: '20%',
                key: 'Description'
            },
            {
                title: <b>Updated By</b>,
                dataIndex: 'UpdatedByName',
                width: "15%",
                key: 'UpdatedByName'
            },
            {
                title: <b>Updated On</b>,
                dataIndex: 'DateUpdated',
                width: "10%",
                key: 'DateUpdated',
                render: (item) =>
                {                   
           if( moment(item).format("MM-DD-YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM-DD-YYYY");
           }
                }
            },
            {
                title: <b>Options</b>,
                width: '10%',
                render: (item) => {
                    return (
                        <div>
                            <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.ReacurrenceNumber, item.AppointmentNumber, true)} />
                            <Divider type="vertical" />
                            <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.ReacurrenceNumber, item.AppointmentNumber, true)} />
                        </div>
                    );
                },
            }
        ];

        this.state = {
            selectedEmp: null,
            employeeList: props.profiles.employeeList,
            employeeappmnt: props.profiles.employeeappmnt,
            isNewModalVisible: false,
            isRecurringModalVisible: false,
            modalTitle: 'New Appointment',
            newAppointmentObj: {},
            recurringObj: {},
            timeOffSelectedMonth: moment(),
            recurringSelectedMonth: moment(),
            isDirty: false,
            disablefield: false,
            value:[]
        };

        this.handleMonthChange = this.handleMonthChange.bind(this);
        this.showModal = this.showModal.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.onEmpListRowClick = this.onEmpListRowClick.bind(this);
        this.handleTimeOffFieldChange = this.handleTimeOffFieldChange.bind(this);
        this.handleRecurringFieldChange = this.handleRecurringFieldChange.bind(this);
        this.checkStateChange = this.checkStateChange.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount() {
        this.props.getListOfEmployeesForOffice();
        this.props.getTimeOffCreateScreen();
    }

 componentDidUpdate(prevProps) {
        if ( prevProps.profiles.editedTimeOffData !== this.props.profiles.editedTimeOffData ) {
                this.openNotification("The employee time-off is updated successfully!");
                this.setState({isRecurringModalVisible: false, isNewModalVisible: false});
        }
        if ( prevProps.profiles.deletedTimeOffData !== this.props.profiles.deletedTimeOffData ) {
            this.openNotification("The employee time-off is deleted successfully!");
            this.setState({isRecurringModalVisible: false, isNewModalVisible: false});
    }
    if ( prevProps.profiles.employeeApptCreateData !== this.props.profiles.employeeApptCreateData ) {
        this.openNotification("The employee time-off is created successfully!");
        this.setState({isRecurringModalVisible: false, isNewModalVisible: false});
}
    }
   

    static getDerivedStateFromProps(props, prevState) {
    
        const { employeeList, employeeappmnt, editTimeOffData, createTimeOffData, editedTimeOffData, profilesErrorData, deletedTimeOffData, employeeApptCreateData} = props.profiles;

        if (employeeList !== prevState.employeeList) return { employeeList };

        if (employeeappmnt !== prevState.employeeappmnt) return { employeeappmnt };

        if (deletedTimeOffData !== prevState.deletedTimeOffData && prevState.selectedEmp !== null)
        {
            const [month, year] = prevState.timeOffSelectedMonth.format("MM-YYYY").split('-');
            props.getTimeOffDetailsforEmployee(prevState.selectedEmp.Empid, month, year);
            return {deletedTimeOffData};
        } 
        if (profilesErrorData && profilesErrorData !== prevState.profilesErrorData) 
        {      
            return {profilesErrorData, errorModalVisible: true};
        }

        if(editedTimeOffData !== prevState.editedTimeOffData && prevState.selectedEmp !== null)
        {
         const [month, year] = prevState.timeOffSelectedMonth.format("MM-YYYY").split('-');
         props.getTimeOffDetailsforEmployee(prevState.selectedEmp.Empid, month, year);
        return {editedTimeOffData};
        }

        if(employeeApptCreateData !== prevState.employeeApptCreateData && prevState.selectedEmp !== null)
        {
         const [month, year] = prevState.timeOffSelectedMonth.format("MM-YYYY").split('-');
         props.getTimeOffDetailsforEmployee(prevState.selectedEmp.Empid, month, year);
        return {employeeApptCreateData};
        }

        if (editTimeOffData !== prevState.editTimeOffData) 
        {
            if(editTimeOffData !== undefined && editTimeOffData.EmployeeProfileList.length > 0)
            {
                let emplist = [];
                editTimeOffData.EmployeeProfileList.map((item) => {emplist.push(item.EmpId)
                    return "";});
            
                switch(editTimeOffData.EmployeeProfileList[0].OccuranceType)
                {
                 
                    case 'M':
                    {
                        if(editTimeOffData.EmployeeProfileList[0].DayType !== null && editTimeOffData.EmployeeProfileList[0].DayOfTheWeek !== null)
                        {
                            editTimeOffData.EmployeeProfileList[0].selectedRadio = "1";
                        }
                        else
                        {
                            editTimeOffData.EmployeeProfileList[0].selectedRadio = "2";
                        }
                        break;
                    }
                    case 'Y':
                    {
                        if(editTimeOffData.EmployeeProfileList[0].DayOfTheMonth !== null && editTimeOffData.EmployeeProfileList[0].MonthOfTheYear !== null)
                        {
                            editTimeOffData.EmployeeProfileList[0].selectedRadio = "1";
                        }
                        else
                        {
                            editTimeOffData.EmployeeProfileList[0].selectedRadio = "2";
                        }
                        break;
                        
                    }
                    default:
                    editTimeOffData.EmployeeProfileList[0].selectedRadio = "1";
                    break;
                }
                if((moment(editTimeOffData.EmployeeProfileList[0].EndTime).format("MM-DD-YYYY")).includes("9999"))
                {
                      editTimeOffData.EmployeeProfileList[0].EndDateOption = "N";
                }
                else
                {
                    editTimeOffData.EmployeeProfileList[0].EndDateOption = "Y";
                }
                editTimeOffData.EmployeeProfileList[0].StartDate = cloneDeep(editTimeOffData.EmployeeProfileList[0].StartTime);
                editTimeOffData.EmployeeProfileList[0].EndDate = cloneDeep(editTimeOffData.EmployeeProfileList[0].EndTime);
                return {editTimeOffData: editTimeOffData , value: emplist, newAppointmentObj: cloneDeep(editTimeOffData.EmployeeProfileList[0]), recurringObj: cloneDeep(editTimeOffData.EmployeeProfileList[0])};
            }
            else
            {
                return {editTimeOffData: editTimeOffData, value: []}
            }
    }

        if (createTimeOffData !== prevState.createTimeOffData)
        {
            if(prevState.modalmode === 'new')
            {
                createTimeOffData.DefultAppointment.StartDate = cloneDeep(createTimeOffData.DefultAppointment.StartTime);            
                createTimeOffData.DefultAppointment.EndDate = cloneDeep(createTimeOffData.DefultAppointment.EndTime);
                return { newAppointmentObj: cloneDeep(createTimeOffData.DefultAppointment), recurringObj: cloneDeep(createTimeOffData.DefultAppointment), modalmode: "enew"};
            }
        } 
        return null;
    }

    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    onEmpListRowClick(value) {
        const selectedEmp = this.state.employeeList.find(emp => emp.Empid === parseInt(value,10));

        const selectvalue = [];
        selectvalue.push(selectedEmp.Empid);
        this.setState({ selectedEmp: selectedEmp, value: selectvalue});

        const dateString = moment().format(monthFormat);
        const [month, year] = dateString.split('-');

        this.props.getTimeOffDetailsforEmployee(value, month, year);
    }

    handleMonthChange(date, dateString, isRecurring = false) {
        if (dateString) {
            const [month, year] = dateString.split('-');
            this.props.getTimeOffDetailsforEmployee(this.state.selectedEmp.Empid, month, year);

            if (isRecurring) this.setState({ recurringSelectedMonth: date });
            else this.setState({ timeOffSelectedMonth: date });
        }
    }


    showModal(e, actype, reacNo, apptNo, isRecurring = false) {
        let modalTitle = 'New Appointment';

        switch (actype) {
            case 'new':
            const selectvalue = [];
            selectvalue.push(this.state.selectedEmp.Empid);
            this.setState({value: selectvalue, modalmode: 'new', allSelected: false , disablefield: false});
                if (isRecurring) modalTitle = 'New Recurring Appointment';
                else modalTitle = 'New Appointment';
                this.props.getTimeOffCreateScreen();
                break;
            case 'edit':
            {
                this.setState({modalmode: 'edit', disablefield: false});
                this.props.getEmployeeAppointment(reacNo, apptNo);
                if (isRecurring)
                {
                     modalTitle = 'Update Recurring Appointment';                 
        }
                else modalTitle = 'Update Appointment';
                break;
    }
            case 'delete':
            this.setState({modalmode: 'delete', disablefield: true});
            this.props.getEmployeeAppointment(reacNo, apptNo);
                if (isRecurring) modalTitle = 'Delete Recurring Appointment';
                else modalTitle = 'Delete Appointment';
                break;
            default:
                break;
        }
        if(isRecurring)
        {
            this.setState({isRecurringModalVisible: true});
        }
        else
        {
            this.setState({isNewModalVisible: true});
        }
        this.setState({ modalTitle});
    }
   checkStateChange =(e, type) => {
    
  if(type === 'checkall')
  { 
      if(e.target.checked === true)
   {
    const value = [];
    if(this.state.modalmode === 'edit' || this.state.modalmode === 'delete')
    {
       if(this.state.editTimeOffData) { this.state.editTimeOffData.EmployeeProfileList.map((item) => {
            value.push(item.EmpId);
            return "";
        });
    }
    }
    else {   this.state.employeeList.map((item) => {
           value.push(item.Empid);
           return "";
       });
    }
       this.setState({value: value, allSelected: true});
   }
   else{
    const value = [];
    value.push(this.state.selectedEmp.Empid);
    this.setState({value: value, allSelected: false});
   }
}
else
{
    let {value} = this.state;
    value = e;
this.setState({value: value}); 
}
    }
    handleOk(type, mode) {
    
       if(mode === 'delete')
{
    this.props.deleteEmployeeTimeOff(this.state.newAppointmentObj.ReacurrenceNumber, this.state.newAppointmentObj.AppointmentNumber);
}
   
       const appointmentsArray = [];
       if(type === 'nonrec')
       {
        this.state.value.map((item) =>
    {
        const timeoffItem = cloneDeep(this.state.newAppointmentObj);
        timeoffItem.EmpId = item;
        appointmentsArray.push(timeoffItem);
        return "";
    })
}
if(type === 'rec')
{
    const {recurringObj} = this.state;
    recurringObj.StartTime = recurringObj.StartDate.split("T")[0]+"T"+recurringObj.StartTime.split("T")[1];
    recurringObj.EndTime = recurringObj.EndDate.split("T")[0]+"T"+recurringObj.EndTime.split("T")[1];
    this.setState({recurringObj});
    this.state.value.map((item) =>
    {
        const timeoffItem = cloneDeep(this.state.recurringObj);
        timeoffItem.EmpId = item;
        appointmentsArray.push(timeoffItem);
        return "";
    })
}
if(mode === 'enew')
{
    this.props.createEmployeeTimeOff(appointmentsArray);
    this.setState({isNewModalVisible: false, isRecurringModalVisible: false})
}
if(mode === 'edit')
{
    appointmentsArray.map((item, idx) => {
        this.state.editTimeOffData.EmployeeProfileList.map((toitem) => {
            if(item.EmpId === toitem.EmpId)
            {
            appointmentsArray[idx].AppointmentId = toitem.AppointmentId;
            }
            return "";
        })
        return "";
    });

    this.props.editEmployeeTimeOff(appointmentsArray);
}
    }

    handleTimeOffFieldChange(e, type) {
    
        const { newAppointmentObj } = this.state;

        switch (type) {
            case 'ActivityType':
                newAppointmentObj.ActivityType = e;
                break;
            case 'date':
                const date = e.startOf('date');
                newAppointmentObj.date = date.format();
                newAppointmentObj.StartTime = date.format();
                newAppointmentObj.EndTime = date.format();
                break;
            case 'isAllDay':
                newAppointmentObj.isAllDay = e.target.checked;
                break;
            case 'StartTime':
            if(e !== null)
            {
                newAppointmentObj.StartTime = e.format();
            }
                break;
            case 'EndTime':
            if(e !== null)
            {
                newAppointmentObj.EndTime = e.format();
            }
                break;
            case 'Comment':
                newAppointmentObj.Comment = e.target.value;
                break;
            case 'isDispayComment':
                newAppointmentObj.isDispayComment = e.target.checked;
                break;
            default:
                break;
        }

        this.setState({ newAppointmentObj });
    }
  
    handleRecurringFieldChange(e, type) {
        const { recurringObj } = this.state;
    
        switch (type) {
            case 'ActivityType':
                recurringObj.ActivityType = e;
                break;
            case 'StartDate':
                recurringObj.StartDate = e.format();
                break;
            case 'EndDate':
                recurringObj.EndDate = e.format();
                break;
            case 'OccuranceType':
               { recurringObj.OccuranceType = e.target.value;
                const crecurringObj = this.state.recurringObj;
                crecurringObj.DayType ="";
                crecurringObj.DayOfTheMonth = "";
                crecurringObj.DayOfTheWeek = "";
                crecurringObj.MonthOfTheYear = "";
                this.setState({recurringObj: crecurringObj});
               }
                break;
            case 'isAllDay':
                recurringObj.isAllDay = e.target.checked;
                break;
            case 'StartTime':
            if(e !== null)
            {
                recurringObj.StartTime = e.format();
            }
                break;
            case 'EndTime':
            if(e !== null)
            {
                recurringObj.EndTime = e.format();
            }
                break;
            case 'Comment':
                recurringObj.Comment = e.target.value;
                break;
            case 'isDispayComment':
                recurringObj.isDispayComment = e.target.checked;
                break;
            case 'DayType':
                recurringObj.DayType = e.target.value;
                break;
            case 'DayOfTheWeek':
                recurringObj.DayOfTheWeek = e.target.value;
                break;
            case 'DayOfTheMonth':
        
                recurringObj.DayOfTheMonth = e;
                break;
                case 'MonthOfTheYear':
        
                recurringObj.MonthOfTheYear = e.target.value;
                break;
            case 'selectedRadio':
            
                recurringObj.selectedRadio = e.target.value;
                break;
            case 'EndDateOption':
            
                recurringObj.EndDateOption = e.target.value;
                if(e.target.value === 'Y')
                {
                    recurringObj.EndDate = moment().format();
                }
                else
                {
                    recurringObj.EndDate = "9999-12-27T12:00:00";
                }
                break;
            default:
                break;
        }
            this.setState({ recurringObj });
    }

    render() {
    
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
          };
        const { selectedEmp, newAppointmentObj, recurringObj, timeOffSelectedMonth } = this.state;
        const { createTimeOffData } = this.props.profiles;
    
        const employeeSelectList = [];
        if(this.state.employeeList){
            if(this.state.modalmode === 'enew')
            {
        this.state.employeeList.map((item) =>{
            employeeSelectList.push(<Option key={item.Empid} value={item.Empid}>{`${item.ShortID}- ${item.LastName}, ${(item.FirstName).substring(0,1)}.`}</Option>);
            return "";}) 
            }
    
           if(this.state.editTimeOffData) { if(this.state.modalmode === 'delete' || this.state.modalmode === 'edit')
            {
                this.state.employeeList.map((item) =>{ this.state.editTimeOffData.EmployeeProfileList.map((empitem)=> {
                  if(item.Empid === empitem.EmpId) { employeeSelectList.push(<Option key={item.Empid} value={item.Empid}>{`${item.ShortID}- ${item.LastName}, ${(item.FirstName).substring(0,1)}.`}</Option>)
               }
               return "";
                });        
                return "";   
                } );
            }
        }
        }
            
        let nonrecurringappmnts = [], recurringappmnts = [], conflictsList = [];

        if(this.state.profilesErrorData) {
            this.state.profilesErrorData.map((item) => 
        {
                item.time = moment(item.conflictDateTimeStart).format("h:mm A") +"-"+ moment(item.confilctDateTimeEnd).format("h:mm A");
                conflictsList.push(item);
                return "";
            })
        }
   
        const ActivityTypeList = createTimeOffData ?
            createTimeOffData.ActivityTypeList
                .filter(act => act.Types === 'H')
                .sort((a, b) => {
                    const actA = a.Description.toLowerCase(), actB = b.Description.toLowerCase();
                    if (actA < actB) return -1;
                    else if (actA > actB) return 1;
                    else return 0;
                })
            : [];
            if(this.state.employeeappmnt) {
                this.state.employeeappmnt.map((item) => 
            {
               this.state.employeeList.map((eitem) =>
            {
                if(item.UpdatedBy === eitem.Empid)
                {
                    item.UpdatedByName = eitem.FirstName+" "+eitem.MiddleName+" "+eitem.LastName;
                }
                return "";
            }); 
            
                if(item.isAllDay)
                {
                    item.time = 'ALL DAY';
                }
                else
                {
                    item.time = moment(item.StartTime).format("h:mm A") +"-"+ moment(item.EndTime).format("h:mm A");
                }
                if(ActivityTypeList !== [])
                {
                    ActivityTypeList.map((actitem) =>{
                        if(actitem.Code === item.ActivityType)
                        {
                          return  item.ActivityType = actitem.Description;
                          
                        }
                        return "";
                    }  );
                    
                }
                if(item.OccuranceType === null || item.OccuranceType === "")
                {  
                    nonrecurringappmnts.push(item);
                }
                else
                {
                    recurringappmnts.push(item);
                }
                return "";
            })
                        }
        return (
        // <ScrollPanel
        //     style={{
        //         width: "100%",
        //         height: "100%",
        //         backgroundColor: "rgba(0,0,0,0)"
        //     }}>
            <Row style={{
                marginLeft: "2.5%",
                width: "95%",
                height: "800px",
                border: "2px solid white"            
            }}>
                <div style={{ height: "7%", border: "1px solid white" }} >
                    <span style={{ paddingLeft: "1%", fontSize: "xx-large" }}>Employee Time-Off</span>
                </div>
                <Col style={{
                    width: "22%",
                    float: "left",
                    height: "93%",
                    border: "1px solid white"
                }}>
                    <div style={{
                        height: "5%", paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"
                    }}>
                        Select An Employee
                    </div>
                    <ScrollPanel
                        style={{
                            height: "95%",
                            backgroundColor: "#c9e3fa"                            
                        }}>
                        <Menu mode="vertical" onClick={(e) => this.onEmpListRowClick(e.key)}>
                            {
                                this.state.employeeList && this.state.employeeList.map(item => <Menu.Item key={item.Empid}>
                                    <div style={{ textAlign: "center" }}>
                                        <div style={{ fontSize: 16, fontWeight: "bold" }}>
                                            {`${item.FirstName} ${item.middleName || ''} ${item.LastName}`}
                                        </div>
                                    </div>
                                </Menu.Item>)
                            }
                        </Menu>
                    </ScrollPanel>
                </Col>
                <Col style={{
                    width: "78%",
                    float: "right",
                    height: "93%",
                    border: "1px solid white"
                }}>
                <div style={{
                        height: "5%", paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"
                    }}>Time Off Details</div>
                    <div style={{ border: "1px solid white", paddingLeft: "15px" }}>
                   
                     {this.state.profilesErrorData && <Modal maskClosable={false} title="Conflicts" visible={this.state.errorModalVisible}
                       onCancel={(e) => this.setState({errorModalVisible: false})}
                       onOk={(e) => this.setState({errorModalVisible: false})}> 
                     <div><b> The employee time-off couldn't be created due to the following conflicts:</b></div>
                      <Table
                                        bordered={false}
                                        size='small'
                                        style={{ width: "100%", height: "50%"}}
                                        pagination={false}
                                        columns={this.conflictsColumns}
                                        dataSource={conflictsList}
                                        showHeader
                                    />
                     </Modal>}
                        {selectedEmp ? <Tabs defaultActiveKey="1" onChange={() => { }}>
                            <TabPane style={{height: "100%"}} tab={<b>Single Appointment</b>} key="1">
                                <div style={{ height: "10%"}}>
                                    <span style={{ float: "left" }}>
                                        Time Off for - <span style={{ fontWeight: "bold" }}>
                                            {selectedEmp && `${selectedEmp.FirstName} ${selectedEmp.LastName}`}
                                        </span>
                                    </span>
                                    <span style={{ float: "right" }}>
                                        <Button size="small" type="primary" onClick={e => this.showModal(e, 'new', null, null, false)}>
                                            <Icon type="plus" theme="outlined" />New Appointment
                                        </Button>
                                        <Modal maskClosable={false} visible={this.state.isNewModalVisible}
                                            title={this.state.modalTitle}
                                            onCancel={(e) => this.setState({isNewModalVisible: false, modalmode: 'new'})}
                                        footer={[
                                            <span>
                                                {(this.state.modalmode === "new" || this.state.modalmode === 'enew') &&
                                                    <span>
                                                        <Button key="cancel" onClick={(e) => this.setState({isNewModalVisible: false})}>Cancel</Button>
                                                        <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec',this.state.modalmode)}>
                                                            Create
                                                </Button>
                                                    </span>}
                                            </span>,
                                            <span>
                                                {this.state.modalmode === "edit" &&
                                                      <span>
                                                      <Button key="cancel" onClick={(e) => this.setState({isNewModalVisible: false})}>Cancel</Button>
                                                      <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec',this.state.modalmode)}>
                                                          Update
                                              </Button>
                                                  </span>}
                                            </span>,
                                            <span>
                                            {this.state.modalmode === "delete" &&
                                                  <span>
                                                  <Button key="cancel" onClick={(e) => this.setState({isNewModalVisible: false})}>Cancel</Button>
                                                  <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec',this.state.modalmode)}>
                                                      Delete
                                          </Button>
                                              </span>}
                                        </span>

                                        ]}
                                        >
                                          {this.state.newAppointmentObj &&  <Form layout={'horizontal'}>
                                            <FormItem
                                                    label="Time Off For"
                                                    {...formItemLayout}
                                                >
                                                              <span><Select id = "SelEmpT" onFocus={(e) => {
                  document.getElementById("SelEmpT").click();
                                                         }} showSearch optionFilterProp= "children" filterOption = {true} disabled={this.state.disablefield} style={{ width: '70%' }}
                                                        placeholder="Please select"
                                                        value={this.state.value}
                                                        mode="multiple"
                                                        onChange={e => this.checkStateChange(e, 'checkbox')}>
                                                        {employeeSelectList}
                                                    </Select></span><span><Checkbox disabled={this.state.disablefield} onChange={e => this.checkStateChange(e, 'checkall')}></Checkbox>{this.state.allSelected ? "DeSelect All" : "Select All"}</span>
                                            </FormItem>
                                                <FormItem
                                                    label="Activity Type"
                                                    {...formItemLayout}
                                                >
                                                    <Select
                                                    id = "SelATT" onFocus={(e) => {
                                                        document.getElementById("SelATT").click();
                                                                                               }} showSearch optionFilterProp= "children" filterOption = {true}
                                                    disabled={this.state.disablefield}
                                                        style={{ width: '100%' }}
                                                        placeholder="Please select"
                                                        value={newAppointmentObj.ActivityType}
                                                        onChange={e => this.handleTimeOffFieldChange(e, 'ActivityType')}
                                                    >
                                                        {ActivityTypeList.map(item => <Option key={`${item.Code}`}>{item.Description}</Option>)}
                                                    </Select>
                                                </FormItem>
                                                <FormItem
                                                    label="Date"
                                                    {...formItemLayout}
                                                >
                                                    <DatePicker disabled={this.state.disablefield} value={moment(newAppointmentObj.StartTime)} format={dateFormat} onChange={e => this.handleTimeOffFieldChange(e, 'date')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Is All Day"
                                                    {...formItemLayout}
                                                >
                                                    <Checkbox disabled={this.state.disablefield} checked={newAppointmentObj.isAllDay} onChange={e => this.handleTimeOffFieldChange(e, 'isAllDay')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Start Time"
                                                    {...formItemLayout}
                                                >
                                                {/* <DatePicker
                                                disabled={this.state.disablefield ? true : newAppointmentObj.isAllDay ? true : false}
  selected={newAppointmentObj.StartTime}
  onChange={e => this.handleTimeOffFieldChange(e, 'StartTime')}
  showTimeSelect
  minTime={setHours(setMinutes(new Date(), 0), 5)}
  maxTime={setHours(setMinutes(new Date(), 30), 20)}
  dateFormat="MMMM d, yyyy"
/> */}
                                                 <TimePicker allowClear disabledHours={() => [0,1,2,3,4,21,22,23,24]} hideDisabledOptions disabled={this.state.disablefield ? true : newAppointmentObj.isAllDay ? true : false} value={moment(newAppointmentObj.StartTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'StartTime')} /> </FormItem>
                                                <FormItem
                                                    label="End Time"
                                                    {...formItemLayout}
                                                >
                                                  <TimePicker allowClear disabledHours={() => [0,1,2,3,4,21,22,23,24]} hideDisabledOptions disabled={this.state.disablefield ? true : newAppointmentObj.isAllDay ? true : false} value={moment(newAppointmentObj.EndTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'EndTime')} /> </FormItem>
                                                <FormItem
                                                    label="Comments"
                                                    {...formItemLayout}
                                                >
                                                    <TextArea disabled={this.state.disablefield} rows="3" value={newAppointmentObj.Comment} onChange={e => this.handleTimeOffFieldChange(e, 'Comment')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Display Comments"
                                                    {...formItemLayout}
                                                >
                                                    <Checkbox disabled={this.state.disablefield} checked={newAppointmentObj.isDispayComment} onChange={e => this.handleTimeOffFieldChange(e, 'isDispayComment')} />
                                                </FormItem>
                                            </Form>}

                                        </Modal>
                                    </span>
                                </div>
                                <br /><br />
                                <div>
                                    <div>
                                        Pick Month-Year:
                                        <MonthPicker format={monthFormat} value={timeOffSelectedMonth} onChange={(date, dateString) => this.handleMonthChange(date, dateString)} />
                                        <br /><br />
                                    </div>
                                    {this.state.employeeappmnt ? <Table
                                        scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "98%", height: "50%", marginLeft: "1%", minHeight: "200px", padding: "40px" }}  // NOU - 8/15/2019 - added minHeight
                                        pagination={false}
                                        columns={this.appointmentColumns}
                                        dataSource={nonrecurringappmnts}
                                        rowKey={record => record.AppointmentId}
                                        showHeader               
                                    /> : <div />}
                                </div>
                            </TabPane>
                                    <TabPane style={{height: "100%"}} tab={<b>Recurring Appointment</b>} key="2">
                                <div style={{ height: "10%" }}>
                                    <span style={{ float: "left" }}>
                                        Recurring Appointments for - <span style={{ fontWeight: "bold" }}>
                                            {selectedEmp && `${selectedEmp.FirstName} ${selectedEmp.LastName}`}
                                        </span>
                                    </span>
                                    <span style={{ float: "right" }}>
                                        <Button size="small" type="primary" onClick={e => this.showModal(e, 'new', null, null, true)}>
                                            <Icon type="plus" theme="outlined" />New Recurring Appointment
                                        </Button>
                                        <Modal maskClosable={false} visible={this.state.isRecurringModalVisible}
                                        width= "50%"
                                            title={this.state.modalTitle}
                                            onCancel={(e) => this.setState({isRecurringModalVisible: false, errors: []})}
                                          footer={[
                                            <span>
                                                {(this.state.modalmode === "new" || this.state.modalmode === 'enew') &&
                                                    <span>
                                                        <Button key="cancel" onClick={(e) => this.setState({isRecurringModalVisible: false})}>Cancel</Button>
                                                        <Button key="ok" type="primary" onClick={(e) => this.handleOk('rec',this.state.modalmode)}>
                                                            Create
                                                </Button>
                                                    </span>}
                                            </span>,
                                            <span>
                                                {this.state.modalmode === "edit" &&
                                                      <span>
                                                      <Button key="cancel" onClick={(e) => this.setState({isRecurringModalVisible: false})}>Cancel</Button>
                                                      <Button key="ok" type="primary" onClick={(e) => this.handleOk('rec',this.state.modalmode)}>
                                                          Update
                                              </Button>
                                                  </span>}
                                            </span>,
                                            <span>
                                            {this.state.modalmode === "delete" &&
                                                  <span>
                                                  <Button key="cancel" onClick={(e) => this.setState({isRecurringModalVisible: false})}>Cancel</Button>
                                                  <Button key="ok" type="primary" onClick={(e) => this.handleOk('rec',this.state.modalmode)}>
                                                      Delete
                                          </Button>
                                              </span>}
                                        </span>
                                        ]}
                                        >
                                          {this.state.errors && this.state.errors.length > 0 && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><ul> {this.state.errors}</ul></div>}
                                       {this.state.recurringObj &&     <Form layout={'horizontal'}>
                                       <FormItem
                                                    label="Recurring Time Off For"
                                                    {...formItemLayout}
                                                >
                                                              <span><Select id = "SEmpR" onFocus={(e) => {
                                document.getElementById("SEmpR").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{ width: '70%' }}
                                                              disabled={this.state.disablefield}
                                                        placeholder="Please select"
                                                        value={this.state.value}
                                                        mode="multiple"
                                                        onChange={e => this.checkStateChange(e, 'checkbox')}>
                                                        {employeeSelectList}
                                                    </Select></span><span><Checkbox disabled={this.state.disablefield} onChange={e => this.checkStateChange(e, 'checkall')}></Checkbox>{this.state.allSelected ? "DeSelect All" : "Select All"}</span>
                                            </FormItem>
                                                <FormItem
                                                    label="Occurs"
                                                    {...formItemLayout}
                                                >
                                                    <div><RadioGroup name="Occurs" disabled={this.state.disablefield} onChange={e => this.handleRecurringFieldChange(e, 'OccuranceType')} value={recurringObj.OccuranceType}>
                                                        <Radio value={'D'}>Daily</Radio>
                                                        <Radio value={'W'}>Weekly</Radio>
                                                        <Radio value={'M'}>Monthly</Radio>
                                                        <Radio value={'Y'}>Yearly</Radio>
                                                    </RadioGroup>
                                                    {recurringObj.OccuranceType &&   
                                                   <div style={{ fontSize: "12px"}}> {recurringObj.OccuranceType === 'D' && <RadioGroup name="OccuranceType" disabled={this.state.disablefield} size="small" onChange={e => this.handleRecurringFieldChange(e, 'DayType')} value={recurringObj.DayType}>
                                                        <Radio style={{fontSize: "12px"}}  value={'1'}>Every Day</Radio>
                                                        <Radio style={{fontSize: "12px"}}  value={'2'}>Every Week Day</Radio>
                                                    </RadioGroup>}
                                                    {recurringObj.OccuranceType === 'W' && <span>Every week on:<RadioGroup name="WeekDay" disabled={this.state.disablefield} size="small" onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheWeek')} value={recurringObj.DayOfTheWeek}>
                                                        <Radio style={{fontSize: "12px"}} value={'1'}>Sun</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'2'}>Mon</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'3'}>Tue</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'4'}>Wed</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'5'}>Thu</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'6'}>Fri</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'7'}>Sat</Radio>
                                                    </RadioGroup></span> }
                                                    {recurringObj.OccuranceType === 'M' && <span>Every month on: <RadioGroup name="DayNumber" disabled={this.state.disablefield} value={recurringObj.selectedRadio} onChange={e => 
                            this.handleRecurringFieldChange(e, 'selectedRadio')
                                                    } >
                                                        <Radio  value={'1'}>The <select  id="dn"  
                             onFocus={(e) => document.getElementById("dn").click()}                disabled={recurringObj.selectedRadio ===  "2"} onChange={e => this.handleRecurringFieldChange(e, 'DayType')}  value={recurringObj.DayType}>
                                                        <option key="1" value="1">First</option>
                                                        <option key="2" value="2">Second</option>
                                                        <option key="3" value="3">Third</option>
                                                        <option key="4" value="4">Fourth</option>
                                                        <option key="L" value="L">Last</option>
                                                        </select>
                                                        <select  id="dow"  
                             onFocus={(e) => document.getElementById("dow").click()}                disabled={recurringObj.selectedRadio ===  "2"} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheWeek')}  value={recurringObj.DayOfTheWeek}> 
                                                        <option key="1" value="1">Sunday</option>
                                                        <option key="2" value="2">Monday</option>
                                                        <option key="3" value="3">Tuesday</option>
                                                        <option key="4" value="4">Wednesday</option>
                                                        <option key="5" value="5">Thursday</option>
                                                        <option key="6" value="6">Friday</option>
                                                        <option key="7" value="7">Saturday</option>
                                                        <option key="W" value="W">Weekday</option>
                                                        <option key="E" value="E">Weekend</option></select> </Radio>of every month.
                                                        <Radio value={'2'}>Day<InputNumber disabled={recurringObj.selectedRadio ===  "1"} min={1} max={31} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheMonth')} value={recurringObj.DayOfTheMonth}/> of every month.</Radio>
                                                    </RadioGroup></span>}
                                                    {recurringObj.OccuranceType === 'Y' && <span>Every year on: <RadioGroup name={"OccuringMonth"} disabled={this.state.disablefield} value={recurringObj.selectedRadio} onChange={e =>
                                                   
                                                   this.handleRecurringFieldChange(e, 'selectedRadio')}>
                                                    <Radio name="Month" value={'1'}><select  id="moy"  
                             onFocus={(e) => document.getElementById("moy").click()}                disabled={recurringObj.selectedRadio ===  "2"} onChange={e => this.handleRecurringFieldChange(e, 'MonthOfTheYear')} value={recurringObj.MonthOfTheYear}> <option key="1" value="1">January</option>
                                                    <option key="2" value="2">February</option>
                                                    <option key="3" value="3">March</option>
                                                    <option key="4" value="4">April</option>
                                                    <option key="5" value="5">May</option>
                                                    <option key="6" value="6">June</option>
                                                    <option key="7" value="7">July</option>
                                                    <option key="8" value="8">August</option>
                                                    <option key="9" value="9">September</option>
                                                    <option key="10" value="10">October</option>
                                                    <option key="11" value="11">November</option>
                                                    <option key="12" value="12">December</option>
                                                   </select> on the day <InputNumber disabled={recurringObj.selectedRadio ===  "2"}min={1} max={31} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheMonth')} value={recurringObj.DayOfTheMonth}/></Radio>
                                                    <Radio value={'2'}>The <select  id="dn2"  
                             onFocus={(e) => document.getElementById("dn2").click()}                disabled={recurringObj.selectedRadio ===  "1"} onChange={e => this.handleRecurringFieldChange(e, 'DayType')} value={recurringObj.DayType}>
                                                    <option key="1" value="1">First</option>
                                                    <option key="2" value="2">Second</option>
                                                    <option key="3" value="3">Third</option>
                                                    <option key="4" value="4">Fourth</option>
                                                    <option key="L" value="L">Last</option>
                                                    </select><select  id="dow2"  
                             onFocus={(e) => document.getElementById("dow2").click()}                disabled={recurringObj.selectedRadio ===  "1"} onChange={e => this.handleRecurringFieldChange(e, 'DayOfTheWeek')} value={recurringObj.DayOfTheWeek}> <option key="1" value="1">Sunday</option>
                                                    <option key="2" value="2">Monday</option>
                                                    <option key="3" value="3">Tuesday</option>
                                                    <option key="4" value="4">Wednesday</option>
                                                    <option key="5" value="5">Thursday</option>
                                                    <option key="6" value="6">Friday</option>
                                                    <option key="7" value="7">Saturday</option>
                                                   </select> of <select  id="moy2"  
                             onFocus={(e) => document.getElementById("moy2").click()}                disabled={recurringObj.selectedRadio ===  "1"} onChange={e => this.handleRecurringFieldChange(e, 'MonthOfTheYear')} value={recurringObj.MonthOfTheYear}> <option key="1" value="1">January</option>
                                                    <option key="2" value="2">February</option>
                                                    <option key="3" value="3">March</option>
                                                    <option key="4" value="4">April</option>
                                                    <option key="5" value="5">May</option>
                                                    <option key="6" value="6">June</option>
                                                    <option key="7" value="7">July</option>
                                                    <option key="8" value="8">August</option>
                                                    <option key="9" value="9">September</option>
                                                    <option key="10" value="10">October</option>
                                                    <option key="11" value="11">November</option>
                                                    <option key="12" value="12">December</option>
                                                   </select> </Radio>
                                                    </RadioGroup></span>}
                                                    </div>}
                                                    </div>
                                                </FormItem>
                                                <FormItem
                                                    label="Activity Type"
                                                    {...formItemLayout}
                                                >
                                                    <Select id = "SAT" onFocus={(e) => {
                                document.getElementById("SAT").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}
                                                        style={{ width: '100%' }}
                                                        placeholder="Please select"
                                                        value={recurringObj.ActivityType}
                                                        onChange={e => this.handleRecurringFieldChange(e, 'ActivityType')}
                                                        disabled={this.state.disablefield}
                                                    >
                                                        {ActivityTypeList.map(item => <Option key={`${item.Code}`}>{item.Description}</Option>)}
                                                    </Select>
                                                </FormItem>
                                                <FormItem
                                                    label="Duration"
                                                    {...formItemLayout}
                                                >
                                                  <div><div><div style={{width: "50%", float: "left"}}>Start Date: <DatePicker disabled={this.state.disablefield} placeholder="Start Date" value={moment(recurringObj.StartDate)} format={dateFormat} onChange={(e) => this.handleRecurringFieldChange(e, 'StartDate')} /></div>
                                                  <RadioGroup name="endDate" disabled={this.state.disablefield} onChange={e => this.handleRecurringFieldChange(e, 'EndDateOption')} value={recurringObj.EndDateOption}>
                                                        <Radio style={radioStyle} value={'Y'}>End Date: {recurringObj.EndDateOption !== 'N' ? <DatePicker placeholder="End Date" value={moment(recurringObj.EndDate)} format={dateFormat} onChange={e => this.handleRecurringFieldChange(e, 'EndDate')} /> : 
                                                        <DatePicker disabled placeholder="Start Date" value={moment(recurringObj.EndDate)} format={dateFormat}  /> }
                                                        </Radio>
                                                        <Radio style={radioStyle}  value={'N'}>No End Date</Radio>
                                                        </RadioGroup></div>
                                                   <div><span> <Checkbox disabled={this.state.disablefield} checked={recurringObj.isAllDay} onChange={e => this.handleRecurringFieldChange(e, 'isAllDay')}>Is All Day</Checkbox></span>
                                                <span>  Start Time:  <TimePicker allowClear disabledHours={() => [0,1,2,3,4,21,22,23,24]} hideDisabledOptions disabled={ this.state.disablefield ? true: recurringObj.isAllDay ? true : false } value={moment(recurringObj.StartTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'StartTime')} /> </span><span>
                                                   End Time:  <TimePicker allowClear disabledHours={() => [0,1,2,3,4,21,22,23,24]} hideDisabledOptions disabled={ this.state.disablefield ? true: recurringObj.isAllDay ? true : false } value={moment(recurringObj.EndTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'EndTime')} /></span></div></div> </FormItem>
                                                <FormItem
                                                    label="Comments"
                                                    {...formItemLayout}
                                                >
                                                     <TextArea disabled={this.state.disablefield} rows="3" value={recurringObj.Comment} onChange={e => this.handleRecurringFieldChange(e, 'Comment')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Display on Schedule"
                                                    {...formItemLayout}
                                                >
                                                     <Checkbox disabled={this.state.disablefield} checked={recurringObj.isDispayComment} onChange={e => this.handleRecurringFieldChange(e, 'isDispayComment')} />
                                                </FormItem>
                                            </Form>
                                       }
                                        </Modal>
                                    </span>
                                </div>
                                <br /><br />
                                <div>
                                    {this.state.employeeappmnt ? <Table
                                        scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "98%", height: "50%", marginLeft: "1%", minHeight: "200px", padding: "40px" }} // NOU - 8/15/2019 - added minHeight 
                                        pagination={false}
                                        columns={this.recurringColumns}
                                        dataSource={recurringappmnts}
                                        rowKey={record => record.AppointmentId}
                                        showHeader
                                    /> : <div />}
                                </div>
                            </TabPane>
                        </Tabs>: <h3>Please select an employee from the menu on the left side to continue.</h3>}
                    </div>
                </Col>
            </Row>
        // </ScrollPanel>
        );
    }
}

const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getListOfEmployeesForOffice,
            getTimeOffDetailsforEmployee,
            getTimeOffCreateScreen,
            getEmployeeAppointment,
            createEmployeeTimeOff,
            editEmployeeTimeOff,
            deleteEmployeeTimeOff
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeTimeOff);

