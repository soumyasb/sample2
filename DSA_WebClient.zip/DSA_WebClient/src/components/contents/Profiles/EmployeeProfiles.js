import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { getEmployeeProfilesInitialPage, getEmployeeProfilesbyId, getCreateProfile, saveEmployeeProfile, getHearingAuthorization, saveHearingAuth, deleteEmployeeProfile } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import moment from "moment";
import { Table, Dropdown, Modal, Radio, Button, Menu, Icon, DatePicker, notification, TimePicker, Checkbox } from 'antd';
import "../../../emp.css";
import cloneDeep from 'lodash/cloneDeep';
import HearingAuthDumbComponent from './HearingAuthDumbComponent';

const RadioGroup = Radio.Group;
const dateFormat = "MM-DD-YYYY";
const format = 'HH:mm';
const empProfcolumns = [
    {
        title: <b>Office</b>,
        dataIndex: 'office',
        width: "20%",
        key: 'office'
    },
    {
        title: <b>Effective Start Date</b>,
        dataIndex: 'effectiveStartDate',
        width: "20%",
        key: 'effectiveStartDate',
        render: (item) =>
        {
           if(item.includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
    },
    {
        title: <b>Effective End Date</b>,
        dataIndex: 'effectiveEndDate',
        width: "20%",
        key: 'effectiveEndDate',
        render: (item) =>
        {
           if(item.includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
    },
    {
        title: <b>Updated By</b>,
        dataIndex: 'employee',
        width: "20%",
        key: 'employee'
    },
    {
        title: <b>Updated On</b>,
        dataIndex: 'updatedDate',
        width: "20%",
        key: 'updatedDate',
        render: (item) =>
        {
           if(item.includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
    }];

 
    const empProfDetailcolumns = [
        {
            title: <b>Day</b>,
            dataIndex: 'day',
            width: "7%",
            key: 'day'
        },
        {
            title: <b>Day Start</b>,
            dataIndex: 'DayStart',
            width: "9%",
            key: 'DayStart',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>AM Break</b>,
            dataIndex: 'amBreak',
            width: "15%",
            key: 'amBreak',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Lunch</b>,
            dataIndex: 'lunch',
            width: "15%",
            key: 'lunch',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>PM Break</b>,
            dataIndex: 'pmBreak',
            width: "15%",
            key: 'pmBreak',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Day End</b>,
            dataIndex: 'DayEnd',
            width: "9%",
            key: 'DayEnd',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Travel Time To Office</b>,
            dataIndex: 'travelTimeToOffice',
            width: "15%",
            key: 'travelTimeToOffice',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Travel Time From Office</b>,
            dataIndex: 'travelTimeFromOffice',
            width: "15%",
            key: 'travelTimeFromOffice',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        }];

class EmployeeProfiles extends Component {
    constructor(props) {
        super(props);
        this.conflictsColumns = [
            {
                title: <b>Case Number</b>,
                dataIndex: 'CaseNumber',
                width: "25%",
                key: 'CaseNumber'
            },
            {
                title: <b>Start Date</b>,
                dataIndex: 'conflictDateTimeStart',
                width: "20%",
                key: 'conflictDateTimeStart',
                render: (item) => {
                    return moment(item).format("MM-DD-YYYY")
                }
            }, 
            {
                title: <b>End Date</b>,
                dataIndex: 'confilctDateTimeEnd',
                width: "20%",
                key: 'confilctDateTimeEnd',
                render: (item) => {
                    return moment(item).format("MM-DD-YYYY")
                }
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: "35%",
                key: 'time'
            }
        ];
        this.state={
            employeeProfilesInitialData: props.profiles.employeeProfilesInitialData,
            modalVisible: false,
            sameSched: false,
            daySelected: true,
            autheditmode: false,
            delModal1Visible: false,
            deleteDateValue: "1"      
        };    
        this.onEmpListRowClick = this.onEmpListRowClick.bind(this);
        this.getMenuList = this.getMenuList.bind(this);
        this.getEmpProfiles = this.getEmpProfiles.bind(this);
        this.getEmpProfDetail = this.getEmpProfDetail.bind(this);
        this.openModal = this.openModal.bind(this);      
        this.handleOk = this.handleOk.bind(this);     
        this.handleCancel = this.handleCancel.bind(this);   
        this.officesList = this.officesList.bind(this);  
        this.handleChange = this.handleChange.bind(this);
        this.onChange = this.onChange.bind(this);
        this.onTimeChange = this.onTimeChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.isChecked = this.isChecked.bind(this);
        this.onButtonClick = this.onButtonClick.bind(this);
        this.onValueChange =  this.onValueChange.bind(this);
        this.disabledDate = this.disabledDate.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }
    componentDidMount()
    {
       this.props.getEmployeeProfilesInitialPage();
    }
  
componentWillReceiveProps(nextProps) {
    if(this.props.profiles.employeeProfilesInitialData !== nextProps.profiles.employeeProfilesInitialData)
    {
        let selectedEmp = {};
       if(nextProps.profiles.employeeProfilesInitialData !== undefined)
       { selectedEmp =  nextProps.profiles.employeeProfilesInitialData.EmployeeListForRegion.find((item) => {
            return item.Empid === nextProps.profiles.employeeProfilesInitialData.SelectedEmployeeId;
        });
    }
        let name = "";
        if(selectedEmp.FirstName != null)
        {
            name = name+selectedEmp.FirstName;
        }
        if(selectedEmp.MiddleName != null)
        {
            name = name+" "+selectedEmp.MiddleName;
        }
        if(selectedEmp.LastName != null)
        {
            name = name+" "+selectedEmp.LastName;
        }
        let classification = "";
        nextProps.profiles.employeeProfilesInitialData.ClassificationList.map((citem) => {
            if(citem.Value === selectedEmp.Classification)
            {
               classification = citem.Text.substring(4);  
               return classification;    
            }
            return "";
        } )
        name = name+" - "+classification;
        this.setState({selectedEmployeeName: name, selectedEmployee: selectedEmp,
             selectedProfId: nextProps.profiles.employeeProfilesInitialData.EmpProfiles[0].ProfileId,
             employeeProfilesData: nextProps.profiles.employeeProfilesInitialData.EmpProfiles,
             officeListForRegionData: nextProps.profiles.employeeProfilesInitialData.OfficeListForRegion,
             classificationList: nextProps.profiles.employeeProfilesInitialData.ClassificationList,
             employeeListForRegionData: nextProps.profiles.employeeProfilesInitialData.EmployeeListForRegion,
            });
    }

    if(this.props.profiles.hearingAuthData !== nextProps.profiles.hearingAuthData)
    {
        this.setState({hearingAuthData: nextProps.profiles.hearingAuthData});
        const newHearingAuthData = cloneDeep(nextProps.profiles.hearingAuthData);
        this.setState({ newHearingAuthData: newHearingAuthData});
    }

    if(this.props.profiles.hearingAuthEditedData !== nextProps.profiles.hearingAuthEditedData)
    {

        this.openNotification("Hearing Authorization updated successfulyy!");
        this.props.getHearingAuthorization(nextProps.profiles.hearingAuthEditedData[0].EmpID);
    }

    if(nextProps.profiles.profilesErrorData && this.props.profiles.profErrRandom !== nextProps.profiles.profErrRandom)
    {
       if(nextProps.profiles.profilesErrorData.length > 0)
      { this.setState({profilesErrorData: nextProps.profiles.profilesErrorData, errorModalVisible: true}); }   
      if(Object.keys(nextProps.profiles.profilesErrorData).length > 0)
      {
        if(nextProps.profiles.profilesErrorData[""] && nextProps.profiles.profilesErrorData[""].length > 0)
        {
          this.setState({profilesErrorData: nextProps.profiles.profilesErrorData[""], regErrorModalVisible: true});
        }
        else
        {
            
            this.setState({profilesErrorData: nextProps.profiles.profilesErrorData, regErrorModalVisible: true}); 
        }
      }
    }

    if(this.props.profiles.employeeProfilesData !== nextProps.profiles.employeeProfilesData)
    {
        if(nextProps.profiles.employeeProfilesData.ProfileId !== undefined)
        {
            this.openNotification(nextProps.profiles.employeeProfilesData.actionStatus);
            this.props.getEmployeeProfilesbyId(this.state.selectedEmployee.Empid);
        }
        else
        {
            if(nextProps.profiles.employeeProfilesData.length !== 0)
            {
                this.setState({employeeProfilesData: nextProps.profiles.employeeProfilesData,
                    selectedProfId: nextProps.profiles.employeeProfilesData[0].ProfileId
                });
            }
            else
            {
                this.setState({employeeProfilesData: nextProps.profiles.employeeProfilesData, selectedProfId: undefined});
            }

    }
    }
    
    if(this.props.profiles.profileCreatedData !== nextProps.profiles.profileCreatedData)
    {
        this.openNotification("The Employee Profile has been created successfully!");
        this.props.getEmployeeProfilesbyId(this.state.selectedEmployee.Empid);
    }

    if(this.props.profiles.createProfileData !== nextProps.profiles.createProfileData)
    {
        this.setState({createProfileData: nextProps.profiles.createProfileData, value: nextProps.profiles.createProfileData.OfficeID});
        const newCreateProfileObj = cloneDeep(nextProps.profiles.createProfileData);
        this.setState({ newCreateProfileObj: newCreateProfileObj});
    }
}
getMenuList(employeeListForRegionData, classificationList)
{
let EmployeeList = [];
employeeListForRegionData.map((item) =>
{
    let classification = classificationList.map((citem) => {
            if(citem.Value.toString() === item.Classification)
            {
               return citem.Text.substring(4);      
            }
            return "";
        } )
    EmployeeList.push(<Menu.Item key={item.Empid}>{<div style={{ textAlign: "center" }}><div style={{ fontSize:16, fontWeight: "bold"}}>{item.FirstName} {item.MiddleName} {item.LastName}</div> 
    <div style={{marginTop: "-18px"}}>{item.UserID}  |  {classification}</div></div>}</Menu.Item>)
    return "";
})
return EmployeeList;
}

openNotification = (msg) => {
    notification.open({
      message: 'SUCCESS',
      description: msg,
      style: {
        width: 600,
        marginLeft: 335 - 600,
        backgroundColor: "#9cd864",
        fontWeight: 'bold'
      },
    });
  }

onValueChange = (e, idx, field) =>
{
    const { newHearingAuthData } = this.state;
    if(field === 'Active')
{
    newHearingAuthData[idx].Active = e.target.checked;
    if(e.target.checked === false)
    {
    newHearingAuthData[idx].HearingTime = 0;
    newHearingAuthData[idx].InterviewTime = 0;
    newHearingAuthData[idx].ReExamTime = 0;
    }
}
else if(field === 'categoryName')
{
    newHearingAuthData[idx].categoryName = e.target.value;
}
else{
    newHearingAuthData[idx][field] = e;
}
    this.setState({newHearingAuthData});
}

onDateChange = (date, type) =>
{
    
    let { newCreateProfileObj } = this.state;
    if(type === 'ESS' && date !== null)
    {
        newCreateProfileObj.effectiveStartDate = date.format();
    }
    if(type === 'EES' && date !== null)
    {
        newCreateProfileObj.effectiveEndDate = date.format();
    }
    if(type === 'EED' && date !== null)
    {
        this.setState({effectiveEndDate: date.format()});
    }
    this.setState({newCreateProfileObj})
}

onButtonClick= (e,value) => 
{
if(value === 'Edit')
{
    const newHearingAuthData =cloneDeep(this.state.hearingAuthData);
    this.setState({newHearingAuthData});
    this.setState({autheditmode: true});
}
if(value === 'Add')
{
    const newHearingAuthData =[{
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 1,
        CategoryName: "Fraud                         ",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      },
      {
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 2,
        CategoryName: "Financial Responsibility      ",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      },{
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 3,
        CategoryName: "Special Certificates          ",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      },{
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 4,
        CategoryName: "Admin Per Se                  ",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      },{
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 5,
        CategoryName: "Physical and Mental           ",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      },{
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 6,
        CategoryName: "Negligent Operator            ",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      },{
        ID: 0,
        EmpID: this.state.selectedEmployee.Empid,
        CategoryID: 7,
        CategoryName: "Commercial Physical and Mental",
        HearingTime: 60,
        InterviewTime: 60,
        ReExamTime: 60,
        LastUpdated: moment(Date.now()),
        Active: true
      }];
    this.setState({newHearingAuthData});
    this.setState({autheditmode: true});  
}
if(value === 'Save')
{
    this.props.saveHearingAuth(this.state.newHearingAuthData);
    this.setState({autheditmode : false});
}
if(value === 'Cancel')
{
    this.setState({autheditmode: false});
}
}

isChecked = (e, idx) =>
{
    let { newCreateProfileObj } = this.state;
    let DayActive = newCreateProfileObj.ProfileDays[idx].DayActive;
    newCreateProfileObj.ProfileDays[idx].DayActive = !DayActive;
    this.setState({newCreateProfileObj})
}

officesList(officeListForRegionData)
{
let officesList = [];
officeListForRegionData.map((item) => {
        officesList.push(<option key={item.Value} value={item.Value}>{item.Text}</option>)
        return "";
});
return officesList;
}

handleChange = (e) =>
{
    this.setState({value: e.target.value});
    const { newCreateProfileObj } = this.state;
newCreateProfileObj.OfficeID = e.target.value;
this.setState({newCreateProfileObj});
}

onTimeChange = (t,ts,v,idx) =>
{
const { newCreateProfileObj } = this.state;
if(t !== null)
{
if(idx !== 'same')
{
    newCreateProfileObj.ProfileDays[idx][v] = t.format();
}
else{
    newCreateProfileObj.ProfileDays.map((item,index) =>
{
    if(item.DayCount !== 1 && item.DayCount !== 7)
    {
    newCreateProfileObj.ProfileDays[index][v] = t.format();
    }
    return "";
})
}
}
this.setState({newCreateProfileObj});
}

openModal = (value, type) =>
{
   if( type === 'new' && this.state.selectedEmployee !== undefined)
   {value.key ==="1" ? this.props.getCreateProfile(this.state.selectedEmployee.Empid) : this.props.getCreateProfile(this.state.selectedEmployee.Empid, this.state.selectedProfId);
   this.setState({modalVisible: true, empProfType: type, modalTitle: "Create New Employee Profile"});
   if(value.key === "1")
   {
       this.setState({sameSched: false});
   }
}
if(type === 'hear' && this.state.selectedEmployee !== undefined) 
 {
     this.props.getHearingAuthorization(this.state.selectedEmployee.Empid);
     this.setState({modalVisible: true, empProfType: type, modalTitle: "Hearing Authorization"});
}
if(type === 'delete' )
{
    this.setState({delModal1Visible: true});
}
}

handleCancel = (e) =>
{
     const newCreateProfileObj = cloneDeep(this.state.createProfileData);
    this.setState({newCreateProfileObj: newCreateProfileObj, modalVisible: false, autheditmode: false, sameSched: false})
}

handleOk = (e) =>
{
    this.props.saveEmployeeProfile(this.state.newCreateProfileObj);
    this.setState({modalVisible: false});
}

onChange = (e) =>
{
    let { sameSched, newCreateProfileObj } = this.state;
    sameSched = !sameSched; 
    this.setState({ sameSched });
    if(sameSched === true)
    {
        newCreateProfileObj.ProfileDays.map((item) => 
        {
            if(item.DayCount !== 1 && item.DayCount !== 7)
            {
            item.DayActive = true;
            }
            return "";
        });
    }
    else{
        const newCreateProfileObj = cloneDeep(this.state.createProfileData);
        this.setState({ newCreateProfileObj: newCreateProfileObj});
    }
}

getEmpProfiles(employeeProfilesData, officeListForRegionData, employeeListForRegionData)
{
let EmployeeProfilesList = [];
employeeProfilesData.map((item) =>
{
    let office ="";
     officeListForRegionData.map((oitem) => {
            if(oitem.Value === item.OfficeID)
            {
               office = oitem.Text;     
               return office; 
            }   
            return "";   
        } )
        let employee = "";
        employeeListForRegionData.map((eitem) => {
            if(eitem.Empid === item.UpdatedByID)
            {
               employee = eitem.FirstName+" "+eitem.MiddleName+" "+ eitem.LastName;     
               return employee; 
            }  
            return "";
        })
        EmployeeProfilesList.push({ProfileID: item.ProfileId, office: office, effectiveStartDate: moment(item.EffectiveStartDate).format("MM-DD-YYYY") , effectiveEndDate:  moment(item.EffectiveEndDate).format("MM-DD-YYYY"), employee: employee, updatedDate: moment(item.UpdatedDay).format("MM-DD-YYYY")});
        return "";
    })
return EmployeeProfilesList;
}

getEmpProfDetail(empProfDetailData)
{
    let EmployeeProfileDetail = [];
    empProfDetailData.map((item) =>
{
    let day = "";
      switch(item.DayCount)
            {
               case 1:
               day = "Sunday";
               break;
               case 2:
               day = "Monday";
               break;
               case 3:
               day = "Tuesday";
               break;
               case 4:
               day = "Wednesday";
               break;
               case 5:
               day = "Thursday";
               break;
               case 6:
               day = "Friday";
               break;
               case 7:
               day = "Saturday";
               break;
               default:
               day = "";
               break;     
            }
 const ttto = moment(item.TravelToStart).format("HH:mm A")+"-"+moment(item.TravelToEnd).format("HH:mm A");
 const ttfo =   moment(item.TravelFromStart).format("HH:mm A")+"-"+moment(item.TravelFromEnd).format("HH:mm A")
 const ds = moment(item.DayStart).format("HH:mm A");
 const amb = moment(item.AMBreakStart).format("HH:mm A")+"-"+moment(item.AMBreakEnd).format("HH:mm A");
 const lb = moment(item.LunchBreakStart).format("HH:mm A")+"-"+moment(item.LunchBreakEnd).format("HH:mm A");
 const pmb = moment(item.PMBreakStart).format("HH:mm A")+"-"+moment(item.PMBreakEnd).format("HH:mm A");
 const de = moment(item.DayEnd).format("HH:mm A");

     if(item.DayActive=== true){   EmployeeProfileDetail.push({day: day, DayStart: ds , amBreak: amb , lunch: lb, pmBreak: pmb, DayEnd: de, travelTimeToOffice: ttto,travelTimeFromOffice: ttfo});
 } 
 return "";
})
return EmployeeProfileDetail;
}
disabledDate(current) {
    return current && current.valueOf() !== Date.now() && current.valueOf() < Date.now();
  }
  
onEmpListRowClick(value)
{
    this.props.getEmployeeProfilesbyId(value);
    const selectedEmp = this.state.employeeListForRegionData.find((item) => {
        return item.Empid.toString() === value;
    });
    let name = "";
    if(selectedEmp.FirstName != null)
    {
        name = name+selectedEmp.FirstName;
    }
    if(selectedEmp.MiddleName != null)
    {
        name = name+" "+selectedEmp.MiddleName;
    }
    if(selectedEmp.LastName != null)
    {
        name = name+" "+selectedEmp.LastName;
    }
    let classification = "";
    this.state.classificationList.map((citem) => {
        if(citem.Value === selectedEmp.Classification)
        {
           classification = citem.Text.substring(4);  
           return classification;    
        }
        return "";
    } )
    name = name+" - "+classification;
    this.setState({selectedEmployee: selectedEmp, selectedEmployeeName: name});
}


    render() {
        const menu = (
            <Menu onClick={(e) => this.openModal(e, 'new')}>
              <Menu.Item key="1">Add New Profile</Menu.Item>
              <Menu.Item key="2">Create New Profile from Selected Profile</Menu.Item>
            </Menu>
          );       
         let officesList = [];
        let EmployeeList, EmployeeProfilesList, EmployeeProfileDetail = [];
        let selectedRowKeys=[], conflictsList = [];
        if(this.state.profilesErrorData && this.state.profilesErrorData.length > 0 && this.state.errorModalVisible) {
            this.state.profilesErrorData.map((item) => 
        {
                item.time = moment(item.ConflictDateTimeStart).format("h:mm A") +"-"+ moment(item.ConfilctDateTimeEnd).format("h:mm A");
                conflictsList.push(item);
                return "";
            })
        }
       if(this.state.newCreateProfileObj !== undefined ) {  officesList=  this.officesList(this.state.officeListForRegionData); }
        if(this.state.employeeProfilesData !== undefined && this.state.officeListForRegionData !== undefined && this.state.employeeListForRegionData !== undefined && this.state.classificationList !== undefined)
       {        
            EmployeeList = this.getMenuList(this.state.employeeListForRegionData, this.state.classificationList);
            EmployeeProfilesList = this.getEmpProfiles(this.state.employeeProfilesData, this.state.officeListForRegionData, this.state.employeeListForRegionData);
          if(this.state.selectedProfId !== undefined && this.state.employeeProfilesData !== undefined) { EmployeeProfileDetail = this.getEmpProfDetail((this.state.employeeProfilesData.find((item) =>
             {return item.ProfileId === this.state.selectedProfId})).ProfileDays);
          }  }
          if(EmployeeProfilesList !== undefined && EmployeeProfilesList !== [])
          {
            EmployeeProfilesList.map((item, idx) => 
            {
                      if(item.ProfileID === this.state.selectedProfId)
                      {
                          selectedRowKeys[0] = item.ProfileID;
                          return selectedRowKeys;
                      }
                      return "";
            })
          }
          const dayOfWeek = ['Sunday','Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          const rowSelection = {
              selectedRowKeys: selectedRowKeys,
                onChange: (selectedRowKeys, selectedRows) => {
                  this.setState({selectedProfId: selectedRows[0].ProfileID});
                },
                type: "radio"            
              };
        return (    
            <Row style={{
            marginLeft: "2.5%",
            width: "95%",
            height: "800px",
            border: "2px solid white"}}>
          <div style={{height: "7%", border: "1px solid white"}} >
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>Employee Profiles</span></div>
         <Col style={{width:"22%",
         float: "left",
             height: "93%",
            border: "1px solid white"}}>
           <div style={{
             height: "5%",  paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"}}>Select An Employee</div>
              <ScrollPanel
            style={{
                height: "95%",
                backgroundColor: "#c9e3fa"
            }}>

{this.state.selectedEmployee &&<Menu  onClick={(e) => this.onEmpListRowClick(e.key)}
style ={{}}
mode = "vertical"
        defaultSelectedKeys={[this.state.selectedEmployee.Empid.toString()]}
>
{EmployeeList}

</Menu>
}

 </ScrollPanel></Col>
             <Col style={{
                 width: "78%",
                 float: "right",
             height: "93%",
            border: "1px solid white"}}><div style={{height: "50%", border: "1px solid white", backgroundColor: "#d5d5d5"}}><div style={{
                height: "10%",  paddingTop: "7px", backgroundColor: "#d5d5d5", border: "1px solid white"}}><span style={{paddingLeft: "1%", float: "left"}}>Employee Profiles for <span style={{fontWeight: "bold"}}>{this.state.selectedEmployeeName}</span></span>
              <span  style={{float: "right"}}> <Dropdown overlay={menu}>
                <Button size="small" type="primary">
                <Icon type="plus-square"></Icon> New Profile <Icon type="down" />
                </Button>
              </Dropdown>
              {this.state.profilesErrorData && <Modal maskClosable={false} title="Conflicts" visible={this.state.errorModalVisible}
                       onCancel={(e) => this.setState({errorModalVisible: false})}
                       onOk={(e) => this.setState({errorModalVisible: false})}> 
                     {conflictsList && <React-Fragment><div><b> The employee profile couldn't be ended due to the following conflicts:</b></div>
                      <Table
                                        bordered={false}
                                        size='small'
                                        style={{ width: "100%", height: "50%"}}
                                        pagination={false}
                                        columns={this.conflictsColumns}
                                        dataSource={conflictsList}
                                        showHeader
                                    /></React-Fragment>}

                     </Modal>}
             <Modal maskClosable={false}  visible={this.state.modalVisible}
             width= "80%"
          title={this.state.modalTitle}
          onCancel={this.handleCancel}
          footer={[
            <span> {this.state.empProfType === "new" && 
            <span> <Button key="cancel" onClick={this.handleCancel}>Cancel</Button>
           <Button key="ok" type="primary" onClick={this.handleOk}>
              Create
          </Button></span>}</span>,
          <span>{this.state.empProfType === "hear" && 
          <Button disabled={this.state.autheditmode} key="cancel" type="primary" onClick={this.handleCancel}>OK</Button>}</span>
          ]}>
       {this.state.empProfType === "new" &&
        <div> {this.state.selectedEmployeeName && <div><span style={{marginLeft: "1%"}}>Employee:  {this.state.selectedEmployeeName.split("-")[0]}</span><span style={{marginLeft: "3%"}}>User ID: {this.state.selectedEmployee.userID}</span></div>}
         {this.state.newCreateProfileObj && <div style={{marginTop: "2%"}}><span style={{marginLeft: "1%"}}>Office:</span><span style={{marginLeft: "1%"}}>
         
         <select id="offList"  
          onFocus={(e) => document.getElementById("offList").click()}               
     style={{ width: '20%' }}   
     value={this.state.value}   
     onChange={this.handleChange} >{officesList}</select>
     
     </span><span style={{marginLeft: "2%"}}>Effective Start Date:</span><span style={{marginLeft: "1%"}}><DatePicker defaultValue={moment(this.state.newCreateProfileObj.effectiveStartDate)} format={dateFormat} onChange={(date, dateString) => this.onDateChange(date,'ESS')}></DatePicker></span><span style={{marginLeft: "2%"}}>Effective End Date:</span><span style={{marginLeft: "1%"}}><DatePicker placeholder="Select End Date" format={dateFormat} onChange={(date, dateString) => this.onDateChange(date,'EES')}></DatePicker></span></div>}
         <div style={{marginTop: "2%", marginLeft: "1%"}}><Checkbox checked={this.state.sameSched} onChange={this.onChange}></Checkbox><span style={{marginLeft: "1%"}}>Apply same schedule from Monday through Friday</span></div> 
         <Row gutter ={8}> <Col span={3} style={{marginTop: "2%"}}><Row style={{height: "32px"}}><b>Day of Week</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>AM Break Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>AM Break End</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Lunch Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Lunch End</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>PM Break Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>PM Break End</b></Row></Col>
        <div>{this.state.newCreateProfileObj &&<div> {this.state.sameSched === false ?  this.state.newCreateProfileObj.ProfileDays.map((item,idx) => {
            return <Col span={3} style={{marginTop: "2%"}} key={item.DayCount}><Row  style={{height: "32px"}}><Checkbox checked={item.DayActive} key={item.DayCount+idx} onChange={(e) => this.isChecked(e,idx)}><b>{dayOfWeek[idx]}</b></Checkbox></Row>
            {/* If default time needs to be shown <TimePicker format={format} key={item.DayCount+"-ds"} defaultValue={moment(this.state.createProfileData.ProfileDays[idx].DayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'DayStart', idx)} /> */}
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.DayStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-ds"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'DayStart', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.DayEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-de"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'DayEnd', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.AMBreakStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-abs"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'AMBreakStart', idx)}  /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.AMBreakEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-abe"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'AMBreakEnd', idx)}  /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.LunchBreakStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-ls"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'LunchBreakStart', idx)}  /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.LunchBreakEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-le"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'LunchBreakEnd', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.PMBreakStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-pbs"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'PMBreakStart', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.PMBreakEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.DayActive} format={format} key={item.DayCount+"-pbe"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'PMBreakEnd', idx)} /></Row></Col>
        }) : <Col span={3} style={{marginTop: "2%"}}><Row  style={{height: "32px"}}><b>Monday-Friday</b></Row>
        {/* If default time needs to be shown <TimePicker format={format} key={item.DayCount+"-ds"} defaultValue={moment(this.state.createProfileData.ProfileDays[idx].DayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'DayStart', idx)} /> */}
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].DayStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'DayStart', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].DayEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'DayEnd', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].AMBreakStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'AMBreakStart', 'same')}  /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].AMBreakEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'AMBreakEnd', 'same')}  /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].LunchBreakStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'LunchBreakStart', 'same')}  /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].LunchBreakEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'LunchBreakEnd', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].PMBreakStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'PMBreakStart', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.ProfileDays[1].PMBreakEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'PMBreakEnd', 'same')} /></Row></Col>}</div>}</div> </Row>
    </div> }

    {/* <ComponentName></ComponentName> */}
    
    {this.state.empProfType === "hear" && <HearingAuthDumbComponent onValueChangeFromParent={(e, index, type) => {this.onValueChange(e,index,type)}} onButtonClickFromParent={(e, type) => {this.onButtonClick(e,type)}} selectedEmployeeFromParent ={this.state.selectedEmployee} selectedEmpNameFromParent = {this.state.selectedEmployeeName} autheditmodeFromParent = {this.state.autheditmode} newHearingAuthDataFromParent = {this.state.newHearingAuthData} hearingAuthData = {this.state.hearingAuthData} />
}

    {this.state.empProfType === "delete" && <div>
              
        </div>
    }

         </Modal> 
              <Button type="primary"size="small" style={{marginLeft: "20px", marginRight:"10px"}} onClick={(e) => this.openModal(e, 'hear')}>
                Hearing Authorization
                </Button></span></div>
                <div style={{ height: "100%", overflow: "hidden"}}>                 
                {EmployeeProfilesList && EmployeeProfilesList.length !== 0 ?  <Table
                    scroll = {{ y: 250}}
                    bordered={false}
                    size='small'
                    style={{ width: "98%", marginLeft: "1%"}}
                    pagination={false}
                    columns={empProfcolumns}
                    dataSource={EmployeeProfilesList}
                    rowKey={record => record.ProfileID}
                    showHeader
                    rowSelection={rowSelection}
                    onRow={(record) => ({
                        onClick: () => {
                          this.setState({selectedProfId: record.ProfileID});
                        },
                      })}
                    /> : <h3>No profiles for this employee. Please add a new one.</h3>}
                </div>
                </div>
                <div style={{height: "50%", border: "1px solid #d5d5d5",backgroundColor: "#d5d5d5"}}><div style={{
                    height: "10%", paddingTop: "7px", backgroundColor: "#d5d5d5", border: "2px solid white"}}><span style={{paddingLeft: "1%"}}>Employee Profile Detail</span>
                    
                    <Modal
                     maskClosable={false}
          title="Delete the profile"
          style={{ bottom: 20 }}
          visible={this.state.delModal1Visible}
          footer={[
            <div>
               {(this.state.deleteDateValue === "1" || this.state.effectiveEndDate) ? <Button type="primary" key="Ok" onClick={(e) =>   {if(this.state.deleteDateValue === "1")
              {
                this.props.deleteEmployeeProfile(this.state.selectedProfId, moment().format()); 
              }
              if(this.state.deleteDateValue === "2" && this.state.effectiveEndDate)
              {
                this.props.deleteEmployeeProfile(this.state.selectedProfId, this.state.effectiveEndDate);
              }
            this.setState({delModal1Visible: false, deleteDateValue: "1"});}}>OK</Button>: <Button disabled>OK</Button>}
            </div>
        ]}
          onCancel={() => this.setState({delModal1Visible: false, deleteDateValue: "1"})}
        >
                        <div>Please select an effective end date for this profile.
                            <div>
                            <RadioGroup name="EndDate" onChange={e =>
                              
                              { 
                                 this.setState({deleteDateValue: e.target.value, effectiveEndDate: undefined})}} defaultValue={"1"} value={this.state.deleteDateValue}>
                                                        <Radio value={'1'}>Today</Radio>
    <Radio value={'2'}>Select a date: {this.state.deleteDateValue === '2' && <DatePicker disabledDate={this.disabledDate} format={dateFormat} onChange={(date, dateString) => this.onDateChange(date,'EED')}></DatePicker>}</Radio>
                                                    </RadioGroup>                          
                            </div>
                        
                        </div>
                        </Modal>

                    <Button type="primary" size="small" style={{ float: 'right' , marginRight: "10px"}} onClick={(e) => this.openModal(e,'delete')} >       
                    Add End Date
                     </Button>
                 </div>
                        <div style={{ height: "100%", overflow: "hidden"}}>         
                      {this.state.profilesErrorData &&  <Modal  maskClosable={false} visible={this.state.regErrorModalVisible}   title="ERROR"
          onCancel={(e) => {this.setState({regErrorModalVisible: false})}}  onOk={(e) => {this.setState({regErrorModalVisible: false})}}><div style={{color:"red"}}>{Object.keys(this.state.profilesErrorData).map((item) => {if(item !== ""){
              return "Error in the "+item+" field:\n"+this.state.profilesErrorData[item][0];
          }
          else
          {
              return this.state.profilesErrorData[""][0];
          }
            })}</div></Modal>       }
                 <Table
                   scroll = {{ y: 250}}
                   bordered={false}
                   size='small'
                   style={{ width: "98%", marginLeft: "1%"}}
                   pagination={false}
                   columns={empProfDetailcolumns}
                   dataSource={EmployeeProfileDetail}
                   rowKey={record => record.EmpID}
                   showHeader /> 
               </div>
               </div></Col>
             
        </Row>
        );
}
}
const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getEmployeeProfilesInitialPage,
            getEmployeeProfilesbyId,
            getCreateProfile,
            saveEmployeeProfile,
            getHearingAuthorization,
            saveHearingAuth,
            deleteEmployeeProfile
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeProfiles);
