import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates, dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { 
    getDUEData, 
    saveDUEData, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    BirthDate: '',
    AuthSect1: '',
    AuthSect2: '',
    Reason: '',
    EffectiveDate: '',
    MailDate: '',
    CoFo: '',
    OrigAuthSect: '',
    OrigEffectiveDate: '',
    UpdateCopies: '',
    ViolationDate: '',
    FieldFile: '',
    CountyCode: '',
    OutOfStateDLNo: '',
    OutOfStateCd: '',
    CommercialStatusIndicator: '',
    HearingType: '',
    HearingDate: '',
    DSFieldOffice: '',
    HearingResult: '',
    ModifiedHearingDate: '',
    DUEResponse: '',
    NextDLNumber: '',
    Error: true
};

class DUEUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            EffectiveDate: "",
            OrigEffectiveDate: "",
            MailDate: '',
            ViolationDate: "",
            HearingDate:"",
            ModifiedHearingDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }
    componentDidMount(){     
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getDUEData(DLInitData.DLNumber);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.DUEInitData !== this.props.dlUpdates.DUEInitData && this.props.dlUpdates.DUEInitData !== undefined) {
                                const Obj = cloneDeep(defaultObj);                           
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.DUEInitData.ThreeCharacterName;
                                Obj['BirthDate'] = this.props.dlUpdates.DUEInitData.BirthDate;
                                this.setState({DUEInitData: this.props.dlUpdates.DUEInitData, Obj: Obj});
                            }
                            if ( prevProps.dlUpdates.saveDUEData !== this.props.dlUpdates.saveDUEData && this.props.dlUpdates.saveDUEData !== undefined) {
                                this.setState({saveDUEData: this.props.dlUpdates.saveDUEData, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                               Obj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { DUEInitData, saveDUEData, dlUpdatesErrorData } = props.dlUpdates;
                if (DUEInitData && DUEInitData !== prevState.DUEInitData)
                {
                    return { DUEInitData: DUEInitData, isloading: false };
                } 
                if (saveDUEData && saveDUEData !== prevState.saveDUEData) return { saveDUEData: saveDUEData, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false };
                return null;
            }
    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
                case 'ThreeCharacterName':
                    Obj[field] = e.target.value;
                break;
                case 'DLNumber':
                this.setState({DLNumber: e.target.value});
                Obj[field] = e.target.value;
                    if ((Obj['DLNumber'].length === 8)) {
                          this.props.getDLInitialData(Obj['DLNumber']);
                          this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                    }
                    break;
            case 'OutOfStateDLNo':
                if (e.target.value.length <= 25) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'NextDLNumber':
            case 'DSFieldOffice':
                if (e.target.value.length <= 3) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'CountyCode':
                const val = e.target.value;
                if (val === '' || (val > 0 && val <= 58) || val === 60) {
                    Obj[field] = val;
                }
                break;
            case 'AuthSect1':
            case 'AuthSect2':
            case 'Reason':
            case 'CoFo':
            case 'UpdateCopies':
            case 'OrigAuthSect':
            case 'CommercialStatusIndicator':
            case 'HearingResult':
            case 'HearingType':
            case 'FieldFile':
            case 'OutOfStateCd':
            if(!e)
            {
                Obj[field] = '';
            }
            else
            {
                Obj[field] = e;
            }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {
        switch(type) {
            case 'EffectiveDate':
            this.setState({ EffectiveDate: d });
            break;
            case 'OrigEffectiveDate':
            this.setState({ OrigEffectiveDate: d });
            break;
            case 'ViolationDate':
            this.setState({ ViolationDate: d });
            break;
            case 'MailDate':
            this.setState({ MailDate: d });
            break;
            case 'BirthDate':
            this.setState({  BirthDate: d });
            break;
            case 'HearingDate':
            this.setState({ HearingDate: d });
            break;
            case 'ModifiedHearingDate':
            this.setState({ ModifiedHearingDate: d });
            break;
            default:
            break;
        }
    }
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
        const { Obj } = this.state;

        Obj['RequestorCode'] = this.state.DUEInitData.RequestorCode;
        Obj['Operator'] = this.state.DUEInitData.Operator;
        Obj['NetName'] = this.state.DUEInitData.NetName;
        Obj['LoginId'] = this.state.DUEInitData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['ModifiedHearingDate'] = dateFormatFuncDLUpdates(this.state.ModifiedHearingDate);
        Obj['EffectiveDate'] = dateFormatFuncDLUpdates(this.state.EffectiveDate);
        Obj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
        Obj['ViolationDate'] = dateFormatFuncDLUpdates(this.state.ViolationDate);
        Obj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
        Obj['BirthDate'] = dateFormatFuncDLUpdates(this.state.BirthDate);  
        Obj['HearingDate'] = dateFormatFuncDLUpdates(this.state.HearingDate);
        if(typeof this.state.BirthDate === 'string')
        {
            Obj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
        }
      else
      {
        Obj['BirthDate'] = this.dateFormatFunc(this.state.BirthDate);
      }
        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
        this.props.saveDUEData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUEInitData, saveDUEData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
                 {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
               {saveDUEData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false}); 
               if(saveDUEData.Error === false)
               {if(Obj.NextDLNumber !== '')
               {
                   this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                   state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
               }
               else if(isNewDL !== true ) {
                   this.props.history.push({ pathname: `/dlUpdates`,
            state: {dlNumber: saveDUEData.DLNumber}})}
           else
            {
                this.setState({Obj: cloneDeep(defaultObj),
                    EffectiveDate: "",
                    OrigEffectiveDate: "",
                    ViolationDate: "",
                    HearingDate:"",
                    DLNumber: '',
                    BirthDate: '',
                    MailDate: '',
                    ModifiedHearingDate: "",
                    ErrorObj: {},
                    ErrorMessage: '',
                    ErrorModalShow: false
                });
            }
        }
}}>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: saveDUEData.DUEResponse.toString()}}/>
          </div></Modal>}
            {DUEInitData ?   
             <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >CDL Disqualification (DUE)</div>
                <Form className="ant-advanced-search-form">
                {isNewDL ? <Row>
                        <Col span={6} style={{ display: 'block' }}>
                            <FormItem
                           hasFeedback
                           validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                           help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                label={<b>DL # </b>}
                            >
                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                label={<b>3 Pos Last Name </b>}
                            >
                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1} style={{ height: '39px' }} >
                            <FormItem
                                label={<b>Birth Date </b>}
                            >
                                 <DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>:
               <Row>
                               <Col span={5}>
                                   <b>DL Number</b>:{" "}{this.state.DLNumber}
                               </Col>
                               <Col span={1} />
                               <Col span={5}>
                                   <b>3 Pos Last Name</b>:{" "}{this.state.ThreeCharacterName}
                               </Col>
                               <Col span={1} />
                               <Col span={5}>
                                   <b>Birth Date</b>:{" "}{this.state.BirthDate}
                               </Col>
                           </Row>
               }
                    <Row>
                        <Col span={10}>
                            <FormItem
                              validateStatus = {Obj.AuthSect1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSect1"] ? 'error' : ""}
                              help = {Obj.AuthSect1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSect1"]}
                                label={<b>Authority Section </b>}
                            >
                                <Select allowClear={true} id = "SAus1" onFocus={(e) => {
                                document.getElementById("SAus1").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthSect1')}
                                    value={Obj.AuthSect1} showArrow={true} size={"default"}
                                >
                                    {DUEInitData.FirstAuthoritySection.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={10} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.AuthSect2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSect2"] ? 'error' : ""}
                                 help = {Obj.AuthSect2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthSect2"]}
                                label={<b>Second Authority Section </b>}
                            >
                                <Select allowClear={true} id = "SAus2" onFocus={(e) => {
                                document.getElementById("SAus2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthSect2')}
                                    value={Obj.AuthSect2} showArrow={true} size={"default"}
                                >
                                       {DUEInitData.SecondAuthoritySection.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8}>
                            <FormItem
                                 validateStatus = {Obj.Reason === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Reason"] ? 'error' : ""}
                                 help = {Obj.Reason === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Reason"]}
                                label={<b>Reason </b>}
                            >
                                <Select allowClear={true} id = "SRea3" onFocus={(e) => {
                                document.getElementById("SRea3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Reason')}
                                    value={Obj.Reason} showArrow={true} size={"default"}
                                >
                                  {DUEInitData.Reasons.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={9} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.CoFo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CoFo"] ? 'error' : ""}
                                 help = {Obj.CoFo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CoFo"]}
                                label={<b>Co / Fo </b>}
                            >
                                <Select allowClear={true} id = "SCoFo3" onFocus={(e) => {
                                document.getElementById("SCoFo3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CoFo')}
                                    value={Obj.CoFo} showArrow={true} size={"default"}
                                >
                                  {DUEInitData.CoFo.map((cf) =>
                                        {
                                            return <Option title={`${cf.Value} - ${cf.Text}`} key={cf.Value} value={cf.Value}>{cf.Value} - {cf.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={6}>
                            <FormItem
                                 validateStatus = {this.state.EffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EffectiveDate"] ? 'error' : ""}
                                 help = {this.state.EffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EffectiveDate"]}
                                label={<b>Effective Date </b>}
                            >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.EffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.MailDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailDate"] ? 'error' : ""}
                                 help = {this.state.MailDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailDate"]}
                                label={<b>Mail Date </b>}
                            >
                                   <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigEffectiveDate"] ? 'error' : ""}
                                 help = {this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigEffectiveDate"]}
                                label={<b>Orig Effec Date </b>}
                            >
                                    <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8}>
                            <FormItem
                                 validateStatus = {Obj.OrigAuthSect === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigAuthSect"] ? 'error' : ""}
                                 help = {Obj.OrigAuthSect === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigAuthSect"]}
                                label={<b>Orig Auth Section </b>}
                            >
                                <Select allowClear={true} id = "SOrAs" onFocus={(e) => {
                                document.getElementById("SOrAs").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OrigAuthSect')}
                                    value={Obj.OrigAuthSect} showArrow={true} size={"default"}
                                >
                                      {DUEInitData.OriginalAuthoritySection.map((oas) =>
                                        {
                                            return <Option title={`${oas.Value} - ${oas.Text}`} key={oas.Value} value={oas.value}>{oas.Value} - {oas.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={8} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                                 help = {Obj.UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"]}
                                label={<b>Update Copies </b>}
                            >
                                <Select allowClear={true} id = "SUC2" onFocus={(e) => {
                                document.getElementById("SUC2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'UpdateCopies')}
                                    value={Obj.UpdateCopies} showArrow={true} size={"default"}
                                >
                                    {DUEInitData.UpdateCopies.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={6}>
                            <FormItem
                                 validateStatus = {this.state.ViolationDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ViolationDate"] ? 'error' : ""}
                                 help = {this.state.ViolationDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ViolationDate"]}
                                label={<b>Violation Date </b>}
                            >
                       <DatePicker
                       className = "CalClass"
                       selected={this.state.ViolationDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ViolationDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.FieldFile === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["FieldFile"] ? 'error' : ""}
                                 help = {Obj.FieldFile === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["FieldFile"]}
                                label={<b>Field File </b>}
                            >
                                <Select allowClear={true} id = "SFF" onFocus={(e) => {
                                document.getElementById("SFF").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'FieldFile')}
                                    value={Obj.FieldFile} showArrow={true} size={"default"}
                                >
                                 {DUEInitData.FieldFile.map((ff) => {
                                   return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                               })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.CountyCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CountyCode"] ? 'error' : ""}
                                 help = {Obj.CountyCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CountyCode"]}
                                label={<b>County Code </b>}
                            >
                                <Input value={Obj.CountyCode} placeholder="County Code" onChange={e => this.handleFieldChange(e, 'CountyCode')} />
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={12}>
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Out-of-State-Data</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={11}>
                                        <FormItem
                                             validateStatus = {Obj.OutOfStateDLNo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateDLNo"] ? 'error' : ""}
                                             help = {Obj.OutOfStateDLNo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateDLNo"]}
                                              label={<b>O / S DL # </b>}>
                                            <Input placeholder="O / S DL #" value={Obj.OutOfStateDLNo}
                                                onChange={e => this.handleFieldChange(e, 'OutOfStateDLNo')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={12} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.OutOfStateCd === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateCd"] ? 'error' : ""}
                                             help = {Obj.OutOfStateCd === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateCd"]}
                                             label={<b>O / S Code </b>}>
                                            <Select allowClear={true} id = "SOSC" onFocus={(e) => {
                                document.getElementById("SOSC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OutOfStateCd')}
                                                value={Obj.OutOfStateCd} showArrow={true} size={"default"}
                                            >
                                               {DUEInitData.OSCode.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                            </div>
                        </Col>
                        <Col span={8} offset={1}>
                            <FormItem 
                                 validateStatus = {Obj.CommercialStatusIndicator === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"] ? 'error' : ""}
                                 help = {Obj.CommercialStatusIndicator === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"]}
                                 label={<b>Commercial Status Ind </b>}>
                                <Select allowClear={true} id = "SCSI2" onFocus={(e) => {
                                document.getElementById("SCSI2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CommercialStatusIndicator')}
                                    value={Obj.CommercialStatusIndicator} showArrow={true} size={"default"}
                                >
                                    {DUEInitData.CommStatusIndicator.map((csi) => {
                                   return <Option title={`${csi.Value} - ${csi.Text}`} key={csi.Value} value={csi.Value}>{csi.Value} - {csi.Text}</Option>
                               })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <br />
                    <div style={{ width: '80%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                        <Row>
                            <Col>
                                <h4>Hearing Information</h4>
                                <hr />
                            </Col>
                        </Row>
                        <Row>
                            <Col span={7}>
                                <FormItem 
                                     validateStatus = {Obj.HearingType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingType"] ? 'error' : ""}
                                     help = {Obj.HearingType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingType"]}
                                     label={<b>Type </b>}>
                                    <Select allowClear={true} id = "SHType2" onFocus={(e) => {
                                document.getElementById("SHType2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingType')}
                                        value={Obj.HearingType} showArrow={true} size={"default"}
                                    >
                                      {DUEInitData.ChgHearingType.map((ht) => {
                                   return <Option title={`${ht.Value} - ${ht.Text}`} key={ht.Value} value={ht.Value}>{ht.Value} - {ht.Text}</Option>
                               })}
                                    </Select>
                                </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                     validateStatus = {this.state.HearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingDate"] ? 'error' : ""}
                                     help = {this.state.HearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingDate"]}
                                    label={<b>Date </b>}
                                >
                                      <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem      
                                validateStatus = {Obj.DSFieldOffice === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DSFieldOffice"] ? 'error' : ""}
                              help = {Obj.DSFieldOffice === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DSFieldOffice"]}
                                label={<b>Location </b>}>
                                    <Input placeholder="Location" value={Obj.DSFieldOffice}
                                        onChange={e => this.handleFieldChange(e, 'DSFieldOffice')} />
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={12}>
                                <FormItem 
                                     validateStatus = {Obj.HearingResult === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingResult"] ? 'error' : ""}
                                     help = {Obj.HearingResult === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingResult"]}
                                label={<b>Result </b>}>
                                    <Select allowClear={true} id = "SRes2" onFocus={(e) => {
                                document.getElementById("SRes2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingResult')}
                                        value={Obj.HearingResult} showArrow={true} size={"default"}
                                    >
                                        {DUEInitData.HearingResults.map((hr) => {
                                   return <Option title={`${hr.Value} - ${hr.Text}`} key={hr.Value} value={hr.Value}>{hr.Value} - {hr.Text}</Option>
                               })}
                                    </Select>
                                </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                     validateStatus = {this.state.ModifiedHearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ModifiedHearingDate"] ? 'error' : ""}
                                     help = {this.state.ModifiedHearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ModifiedHearingDate"]}
                                    label={<b>Mod Date </b>}
                                >
                                      <DatePicker
                       className = "CalClass"
                       selected={this.state.ModifiedHearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ModifiedHearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                </FormItem>
                            </Col>
                        </Row>
                    </div>

                    <br />
                    <Row>
                        <Col span={8}>
                            <FormItem
                                 validateStatus = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                 help = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"]}
                                label={<b>Next Trans </b>}
                            >
                                <Input value={Obj.NextDLNumber} maxLength = {3} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={13} style={{ float: 'right' }}>
                        {Obj.NextDLNumber !== '' ? <Button disabled
                           type="default">New DL</Button>: <Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                            <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                            <Button style={{ color: "white", backgroundColor: "red" }}
                                type="default" key="Cancel" onClick={(e) => {
                                                
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: this.state.DLNumber }
                                    })
                                }}>Cancel</Button>
                        </Col>
                    </Row>
                </Form></div>  : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                            {
                                this.setState({ErrorModalShow: false});
                                if( !this.state.ErrorObj )
                                { if(isNewDL === true)
                                {
                                    this.setState({Obj: cloneDeep(defaultObj),
                                        EffectiveDate: "",
                                        OrigEffectiveDate: "",
                                       DLNumber: "",
                                        BirthDate: "", 
                                        ViolationDate: "",
                                        MailDate: '',
                                        HearingDate:"",
                                        ModifiedHearingDate: "",
                                        ErrorObj: {},
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                }
                                else if(Obj.NextDLNumber !== '')
                                {
                                    this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                    state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                }  
                               else {
                                    this.props.history.push({ pathname: `/dlUpdates`,
                                    state: {dlNumber: this.state.DLNumber}});
                                }
                            }   
                        }}>Ok</Button>
                        </div>
                    ]}
                >
                  {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            </React-Fragment>
            );
    }
}
    
const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUEData, saveDUEData, getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUEUpdate); 