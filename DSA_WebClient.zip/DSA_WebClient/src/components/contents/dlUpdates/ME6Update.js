import React, { Component } from 'react';
import { dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { Form, Input, Row, Button, Col, Select, Checkbox, Modal, Spin } from 'antd';
import { 
    getME6Data, 
    saveME6Data, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
    import cloneDeep from 'lodash/cloneDeep';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    DLNumber: '',
    isNewDL: false,
    SelfCertCode: '',
    ThreeCharacterLastName: '',
    MedCertReceiptDate: '',
    Purge: false,
    ExaminerLicense: '',
    NextTran: '',
};

class ME6Update extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            Obj: cloneDeep(defaultObj),
            MedCertReceiptDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        }

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getME6Data(DLInitData.DLNumber, DLInitData.ThreeCharacterName);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.ME6InitData !== this.props.dlUpdates.ME6InitData && this.props.dlUpdates.ME6InitData !== undefined) {
                                const Obj = cloneDeep(defaultObj);
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.ME6InitData.ThreeCharacterName;
                                const ME6InitData = cloneDeep(this.props.dlUpdates.ME6InitData);     
                                ME6InitData.SelfCertCode[0].Text = "Non-excepted Intrastate";
                                ME6InitData.SelfCertCode[1].Text = "Non-excepted Interstate";   
                                this.setState({ME6InitData: this.props.dlUpdates.ME6InitData, Obj: Obj});
                            }
                            if ( prevProps.dlUpdates.saveME6Data !== this.props.dlUpdates.saveME6Data && this.props.dlUpdates.saveME6Data !== undefined) {
                                this.setState({saveME6Data: this.props.dlUpdates.saveME6Data, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                             
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { ME6InitData, saveME6Data, dlUpdatesErrorData } = props.dlUpdates;
                if (ME6InitData && ME6InitData !== prevState.ME6InitData) return { ME6InitData: ME6InitData, DLNumber: ME6InitData.DLNumber, ThreeCharacterName: ME6InitData.ThreeCharacterName, isloading: false };
                if (saveME6Data && saveME6Data !== prevState.saveME6Data) return { saveME6Data: saveME6Data, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return { dlUpdatesErrorData, isloading: false};
                return null;
            }

    handleFieldChange(e, field) {
        const { Obj } = this.state;

        switch (field) {
            case 'ThreeCharacterName':
            case 'NextTran':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
            case 'Purge':
                Obj[field] = e.target.checked;
                break;
            case 'SelfCertCode':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    onDateChange(d, type) {
        this.setState({ MedCertReceiptDate: d });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
        const { Obj } = this.state;
        Obj['RequestorCode'] = this.state.ME6InitData.RequestorCode;
        Obj['Operator'] = this.state.ME6InitData.Operator;
        Obj['NetName'] = this.state.ME6InitData.NetName;
        Obj['LoginId'] = this.state.ME6InitData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['MedCertReceiptDate'] = dateFormatFunc(this.state.MedCertReceiptDate);
        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
        this.props.saveME6Data(Obj);
    }

    render() {
        const { Obj, ME6InitData, isloading, isNewDL, saveME6Data } = this.state;

        return (
            <React-Fragment>
            {isloading !== true ?   <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
            {saveME6Data && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false});  
            
            if(saveME6Data.Error === false)
            { if(Obj.NextTran !== null && Obj.NextTran !== '')
            {
                this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
            } else if(isNewDL !== true ) {
            this.props.history.push({ pathname: `/dlUpdates`,
     state: {dlNumber: saveME6Data.DLNumber}})}
     else
     {
         this.setState({ Obj: cloneDeep(defaultObj),
            MedCertReceiptDate: "",            
            ErrorObj: {},
            DLNumber: '',
            ErrorMessage: '',
            ErrorModalShow: false
         });
        }
    }
     }}>OK</Button>]}><div>
         <div dangerouslySetInnerHTML={{ __html: saveME6Data.ME6Response.toString()}}/></div></Modal>}
         {ME6InitData ?   
         ME6InitData.Message !== null ? <Modal maskClosable={false} title={"ME6 Message"} visible={true} onCancel={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
         state: {dlNumber: ME6InitData.DLNumber}})}} footer={[<Button type="primary" key="Ok" onClick={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
         state: {dlNumber: ME6InitData.DLNumber}})}}>OK</Button>]}><div>{ME6InitData.Message}</div></Modal> :
         <div><div style={{
            border: '1px solid black',
            paddingLeft: "1%",
            textAlign: 'center',
            backgroundColor: '#c9e3fa',
            fontSize: '32px'
            }} >Self-Certification Update (ME6)</div>  <Form className="ant-advanced-search-form">
           {isNewDL ? <Row>
                    <Col span={6}>
                        <FormItem
                           hasFeedback
                           validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                           help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                            label={<b>DL # </b>}
                        >
                            <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                        </FormItem>
                    </Col>
                    <Col span={6} offset={1}>
                        <FormItem
                            label={<b>3 Pos Last Name </b>}
                        >
                            <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                        </FormItem>
                    </Col>
                </Row>:
                 <Row>
                               <Col span={5}>
                                   <b>DL Number</b>:{" "}{this.state.DLNumber}
                               </Col>
                               <Col span={1} />
                               <Col span={5}>
                                   <b>3 Pos Last Name</b>:{" "}{this.state.ThreeCharacterName}
                               </Col>
                           </Row>}
                <Row>
                    <Col span={6}>
                        <FormItem
                            label={<b>Self-Cert Code </b>}
                        >
                            <Select allowClear = {true} id = "SSC" onFocus={(e) => {
                                document.getElementById("SSC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'SelfCertCode')}
                                value={Obj.SelfCertCode} showArrow={true} size={"default"}
                            >
                                {ME6InitData.SelfCertCode.map(item => <Option key={item.Value} value={item.Value}>{item.Text}</Option>)}
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span={8} offset={1}>
                        <FormItem
                        validateStatus = {Obj['MedCertReceiptDate'] === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertReceiptDate"] ? 'error' : ""}
                        help = {Obj['MedCertReceiptDate'] === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertReceiptDate"]}
                            label={<b>Med Cert Receipt Date </b>}
                        >
                              <DatePicker
                       className = "CalClass"
                       selected={this.state.MedCertReceiptDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MedCertReceiptDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />     </FormItem>
                    </Col>
                </Row>
                <div style={{ width: '50%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px', textAlign: 'center' }}>
                    <Checkbox checked={Obj.Purge}
                        onChange={e => this.handleFieldChange(e, 'Purge')}
                        placeholder="input placeholder">
                        PURGE THIS RECORD
                        </Checkbox>
                </div>
                <br />
                <br />
                <Row>
                    <Col span={4}>
                        <FormItem
                            label={<b>Next Trans </b>}
                        >
                            <Input value={Obj.NextTran} maxLength = {3} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextTran')} />
                        </FormItem>
                    </Col>
                    <Col span={15} style={{ float: 'right' }}>
                    {Obj.NextTran !== '' ? <Button disabled
                           type="default">New DL</Button>:  <Button style={{ color: "white", backgroundColor: "green" }}
                        type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                        <Button style={{ color: "white", backgroundColor: "red" }}
                            type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                            state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                    </Col>
                </Row>
            </Form></div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                                {
                                    this.setState({ErrorModalShow: false});
                                    if( !this.state.ErrorObj )
                                    { if(Obj.NextTran !== null && Obj.NextTran !== '')
                                    {
                                        this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                        state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                    }
                                  else if(isNewDL === true)
                                    {
                                        this.setState({ Obj: cloneDeep(defaultObj),
                                           MedCertReceiptDate: "",                                           
                                           ErrorObj: {},
                                           DLNumber: "",
                                           ErrorMessage: '',
                                           ErrorModalShow: false
                                        });
                                    }
                                    else
                                    {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }
                                }                                   
                                }>Ok</Button>
                        </div>
                    ]}
                >
                                    {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            </React-Fragment>
        );
    }
}

const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getME6Data, saveME6Data, getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ME6Update); 