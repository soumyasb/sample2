import React, { Component } from 'react';
import { 
    getDAPInitialPage, 
    saveDAPUpdate, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { checkIfFutureDate, dateFormatFunc, dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { connect } from "react-redux";
import { InputNumber, Form, Row, Col, Spin, Input, Radio, Select, Button, Modal } from 'antd';                                     
import cloneDeep from 'lodash/cloneDeep';

const RadioGroup = Radio.Group;
const { Option } = Select;
const FormItem = Form.Item;

const defaultDAPObj = {
    RequestorCode: '',
    Operator: '',
    NetName: '',
    LoginId: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    BirthDate: '',
    DSFieldOffice: '',
    APSType: '',
    ArrestDate: '',
    APSTestType: '',
    UpdateCopies: '9',
    VOPType: '',
    VOPTestType: '',
    LawEnforcementAgency: '',
    CourtCode: '',
    BAC1: '0.00',
    BAC2: '0.00',
    LawEnforcementCaseNo: '',
    VOPBAC1: '0.00',
    VOPBAC2: '0.00',
    OutOfStateDLNo: '',
    OutOfStateCd: '',
    CommercialStatusIndicator: '',
    EffectiveDate: '',
    MailDate: '',
    PASOrigAuthSect: '',
    OrigEffectiveDate: '',
    EndStay: '',
    VOPOrigAuthSect: '',
    HearingDate: '',
    HearingResult: '',
    HearingType: '',
    ModifiedHearingDate: '',
    CorrArrestDate: '',
    CoFo: '',
    DiffServDate: '',
    LicenseLocation: '',
    CreditDays: '',
    DAPResponse: '',
    DARResponse: '',
    DASResponse: '',
    NextDLNumber: '',
    Error: true
}

const getDropdownList = (listObj, selectedValue, type) => {
    let list = [];
if(type === 'location')
{
    listObj.map(item => {
        if (item.Value !== "") {
            if (item.Value === selectedValue) {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value} selected>{item.Text}</Option>)
            }
            else {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Text}</Option>)
            }
        }
        return "";
    });
}
else
{
    listObj.map(item => {
        if (item.Value !== "") {
            if (item.Value === selectedValue) {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value} selected> {item.Value} - {item.Text}</Option>)
            }
            else {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>)
            }
        }
        return "";
    });
}
    return list;

}
class DAPUpdate extends Component {
    constructor(props) {
        super(props);

        this.state={
            dapObj: cloneDeep(defaultDAPObj),
            DLNumber: this.props.match.params.dlNumber,
            ArrestDate: "",
            isNewDL: false,
            EffectiveDate: "",
            MailDate: "",
            OrigEffectiveDate: "",
            HearingDate: "",
            ModifiedHearingDate: "",
            CorrArrestDate: "",
            DiffServDate: "",
            ErrorMessage: '',
            ErrorObj: {},
            ErrorModalShow: false
        };
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }  
    componentDidMount()
    {
        
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getDAPInitialPage(DLInitData.DLNumber);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
    }
    componentDidUpdate(prevProps){

        if ( prevProps.dlUpdates.dapInitPageData !== this.props.dlUpdates.dapInitPageData && this.props.dlUpdates.dapInitPageData !== undefined) {
            const dapObj = cloneDeep(defaultDAPObj);
            dapObj['ThreeCharacterName'] = this.props.dlUpdates.dapInitPageData.ThreeCharacterName;
            dapObj['BirthDate'] = this.props.dlUpdates.dapInitPageData.BirthDate;
            this.setState({DAPInitData: this.props.dlUpdates.dapInitPageData, dapObj: dapObj});
        }
        if ( prevProps.dlUpdates.dapUpdateSaveData !== this.props.dlUpdates.dapUpdateSaveData && this.props.dlUpdates.dapUpdateSaveData !== undefined) {
            this.setState({DAPSaveData: this.props.dlUpdates.dapUpdateSaveData, openSuccessModal: true});
        }
        if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
            }
            else{
                let Errors = [];
                Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                    Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const dapObj = cloneDeep(defaultDAPObj);
           dapObj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
           dapObj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
            this.setState({ dapObj: dapObj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
        } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
        const { dapInitPageData, dapUpdateSaveData, dlUpdatesErrorData } = props.dlUpdates;
        if (dapInitPageData && dapInitPageData !== prevState.DAPInitData) return { DAPInitData: dapInitPageData, isloading: false };
        if (dapUpdateSaveData && dapUpdateSaveData !== prevState.DAPSaveData) return { DAPSaveData: dapUpdateSaveData, isloading: false };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false };
        return null;
    }

    handleFieldChange(e, type) {
        const { dapObj } = this.state;       
        switch (type) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
            if (e.target.value.length <= 3) {
            dapObj[type] = e.target.value;
            }
        break;
        case 'DLNumber':
        this.setState({DLNumber: e.target.value});
        dapObj[type] = e.target.value;
            if ((dapObj['DLNumber'].length === 8)) {
                  this.props.getDLInitialData(dapObj['DLNumber']);
                this.props.getDAPInitialPage(dapObj['DLNumber']);
            }
            break;
            case 'APSType':
            if(e.target.value === 'A' && dapObj['VOPType'] === 'R')
                    {
                      Modal.error({
                        title: "Error"
                        ,
                        content: (
                          <div>
                       VOP Type - Refusal not allowed with APS Type - BAC.
                          </div>
                        ),
                        onOk() {},
                      });
                    }
                    else
                    {
                        dapObj[type] = e.target.value;
                        if (e.target.value === 'R') dapObj['APSTestType'] = 'RE';
                        else dapObj['APSTestType'] = '';
                    }
                break;
            case 'VOPType':
                if (e.target.value === 'R')
                {
                    if(dapObj['APSType'] === 'A')
                    {
                       Modal.error({
                        title: "Error"
                        ,
                        content: (
                          <div>
                       VOP Type - Refusal not allowed with APS Type - BAC.
                          </div>
                        ),
                        onOk() {},
                      });
                    }
                   else{
                    dapObj[type] = e.target.value;
                    dapObj['VOPTestType'] = 'RE';
                   }                 
                } 
                else
                {
                    dapObj[type] = e.target.value;
                    dapObj['VOPTestType'] = '';
                }
                break;
                case 'BAC1':
                case 'BAC2':
                case 'VOPBAC1':
                case 'VOPBAC2':
               if (e.toString().match(/[a-z]/i)) {
                Modal.error({
                    title: "Error"
                    ,
                    content: (
                      <div>
                        Only numerics allowed.
                      </div>
                    ),
                    onOk() {},
                  });
                 }
                 else
                 { 
                      if(e.toString().includes('.'))
                 { if(e.toString().length < 5) {
                        if(e < 0 || e > 0.6){
                             Modal.error({
                                title: "Error"
                                ,
                                content: (
                                  <div>
                               Invalid BAC Value. Value should be between 0.00 to 0.60.
                                  </div>
                                ),
                                onOk() {},
                              });
                            }
                            else
                            {
                                 dapObj[type] = e.toString();
                            }
                        }
                        else
                        {
                           var es = e.toString();
                            dapObj[type] = (parseInt(es.substring(es.length -2),10)/100).toString();
                        }   
                    }
                    else
                    {
                            if((e/100) < 0 || (e/100) > 0.6){
                                    Modal.error({
                                        title: "Error"
                                        ,
                                        content: (
                                          <div>
                                       Invalid BAC Value. Value should be between 0.00 to 0.60.
                                          </div>
                                        ),
                                        onOk() {},
                                      });
                                }
                                else
                                {
                                     dapObj[type] = (e/100).toString();
                                }
                    }    
                }
        break;
            case 'APSTestType':
            case 'UpdateCopies':
            case 'VOPTestType':
            case 'CommercialStatusIndicator':
            case 'PASOrigAuthSect':
            case 'VOPOrigAuthSect':
            case 'EndStay':
            case 'HearingResult':
            case 'HearingType':
            case 'CoFo':
            case 'OutOfStateCd':
            case 'LicenseLocation':
            case 'DSFieldOffice':
            case 'OutOfStateDLNo':
            if(!e)
            {
            dapObj[type] = '';
            }
            else
            {
            dapObj[type] = e;
            }
            break;
            case 'CreditDays':
            { const { value } = e.target;
  const reg = /^[0-9]*$/;
  if ((!isNaN(value) && reg.test(value))) {
    dapObj[type] = e.target.value;
  }   }      break;
            case 'CourtCode':
           { const { value } = e.target;
  const reg = /^[0-9]*$/;
  if ((!isNaN(value) && reg.test(value))) {
    dapObj[type] = e.target.value;
  }   }           
                break;
            case 'LawEnforcementAgency':
                if (e.target.value.length <= 25) {
                    dapObj[type] = e.target.value;
                }
                break;
            case 'LawEnforcementCaseNo':
                if (e.target.value.length <= 13) {
                    dapObj[type] = e.target.value;
                }
                break;
            default:
                break;
        }
        this.setState({ dapObj });
    }

    onDateChange(d, type) {
        if (type === 'ArrestDate') {
            if(this.state.dapObj.APSType === '')
            {
               Modal.error({
                title: "Error"
                ,
                content: (
                  <div>
               APS Type must be selected.
                  </div>
                ),
                onOk() {},
              });
                return;
            }
            else
            {
            if (d && !checkIfFutureDate(d)) {
              Modal.error({
                title: "Error"
                ,
                content: (
                  <div>
              Arrest Date cannot be in the future.
                  </div>
                ),
                onOk() {},
              });
                return;
            }
            else
            {
                const { dapObj } = this.state;
    dapObj[type] = d || new Date();
        this.setState({ dapObj: dapObj, ArrestDate: d });
            }
        }
        }
else
{
    const { dapObj } = this.state;
    dapObj[type] = d || new Date();
    switch(type) {
        case 'EffectiveDate':
        this.setState({ dapObj: dapObj, EffectiveDate: d });
        break;
        case 'MailDate':
        this.setState({ dapObj: dapObj, MailDate: d });
        break;
        case 'OrigEffectiveDate':
        this.setState({ dapObj: dapObj, OrigEffectiveDate: d });
        break;
        case 'HearingDate':
        this.setState({ dapObj: dapObj, HearingDate: d });
        break;
        case 'BirthDate':
        this.setState({ dapObj: dapObj, BirthDate: d });
        break;
        case 'ModifiedHearingDate':
        this.setState({ dapObj: dapObj, ModifiedHearingDate: d });
        break;
        case 'CorrArrestDate':
        this.setState({ dapObj: dapObj, CorrArrestDate: d });
        break;
        case 'DiffServDate':
        this.setState({ dapObj: dapObj, DiffServDate: d });
        break;
        default:
        break;
    }
}
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }


    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
            const { dapObj } = this.state;
          
            dapObj['RequestorCode'] = this.state.DAPInitData.RequestorCode;
            dapObj['Operator'] = this.state.DAPInitData.Operator;
            dapObj['NetName'] = this.state.DAPInitData.NetName;
            dapObj['LoginId'] = this.state.DAPInitData.LoginId;
            if(dapObj['DSFieldOffice'] === '')
            {
                
                dapObj['DSFieldOffice'] = this.state.DAPInitData.DSUserFieldOffice;
            }
            if(dapObj['BAC1'].includes('.')){   dapObj['BAC1'] = (parseFloat(dapObj['BAC1'])*100).toString();}
                    if(dapObj['BAC2'].includes('.')){  dapObj['BAC2'] = (parseFloat(dapObj['BAC2'])*100).toString();}
                    if(dapObj['VOPBAC1'].includes('.')){  dapObj['VOPBAC1'] = (parseFloat(dapObj['VOPBAC1'])*100).toString();}
                    if(dapObj['VOPBAC2'].includes('.')){  dapObj['VOPBAC2'] = (parseFloat(dapObj['VOPBAC2'])*100).toString();}
            dapObj['DLNumber'] = this.state.DLNumber;
            dapObj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
            if(typeof this.state.BirthDate === 'string')
            {
                dapObj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
            }
          else
          {
            dapObj['BirthDate'] = dateFormatFuncDLUpdates(this.state.BirthDate);
          }
          dapObj['ArrestDate'] = dateFormatFuncDLUpdates(this.state.ArrestDate);
          dapObj['EffectiveDate'] = dateFormatFuncDLUpdates(this.state.EffectiveDate);
          dapObj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
          dapObj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
          dapObj['HearingDate'] = dateFormatFuncDLUpdates(this.state.HearingDate);
          dapObj['ModifiedHearingDate'] = dateFormatFuncDLUpdates(this.state.ModifiedHearingDate);
          dapObj['CorrArrestDate'] = dateFormatFuncDLUpdates(this.state.CorrArrestDate);
          dapObj['DiffServDate'] = dateFormatFuncDLUpdates(this.state.DiffServDate);

            this.setState({isloading: true, DLNumber: dapObj['DLNumber'], isNewDL: isNewDL});
           this.props.saveDAPUpdate(dapObj);
    
    }

    render() {
    
        const {
           ThreeCharacterName, DSFieldOffice,
            APSType, APSTestType, UpdateCopies, VOPType, VOPTestType,
            LawEnforcementAgency, CourtCode, BAC1, BAC2, LawEnforcementCaseNo, VOPBAC1, VOPBAC2, OutOfStateDLNo, OutOfStateCd,
            CommercialStatusIndicator, PASOrigAuthSect, EndStay, VOPOrigAuthSect, HearingResult, HearingType, CoFo, LicenseLocation,
            CreditDays, NextDLNumber } = this.state.dapObj;
        const { DAPInitData, DAPSaveData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
           {isloading !== true ?    <div style={{backgroundColor: "white", marginTop: '1%', width: "95%", marginLeft: '2%'}}> 
           {DAPSaveData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {
               this.setState({openSuccessModal: false}); 
               
               if(DAPSaveData.Error === false)
               {  
                if(NextDLNumber !== '')
                {
                    this.props.history.push({ pathname: `/${NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                    state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                }   
                else if(isNewDL !== true ) {  this.props.history.push({ pathname: `/dlUpdates`,
               state: {dlNumber: DAPSaveData.DLNumber}})}
               else
               {
                   this.setState({  dapObj: cloneDeep(defaultDAPObj),
                    ArrestDate: "",
                    EffectiveDate: "",
                    MailDate: "",
                    DLNumber: '',
                    BirthDate: '',
                    OrigEffectiveDate: "",
                    HearingDate: "",
                    ModifiedHearingDate: "",
                    CorrArrestDate: "",
                    DiffServDate: "",
                    ErrorMessage: '',
                    ErrorObj: {},
                    ErrorModalShow: false
                   });
               }
            }}
            }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: DAPSaveData.DAPResponse.toString()}}/>
            <div dangerouslySetInnerHTML={{ __html: DAPSaveData.DARResponse.toString()}}/>
            <div dangerouslySetInnerHTML={{ __html: DAPSaveData.DASResponse.toString()}}/></div></Modal>}
           
           {DAPInitData ?  <Row>
                    <Col span={24}>
                    <div style={{
border: '1px solid black',
paddingLeft: "1%",
textAlign: 'center',
backgroundColor: '#c9e3fa',
fontSize: '32px'
}} >DAP/DAS - APS Update or Dual APS and VOP Update</div>
                    <div style= {{margin: '1%'}}>
                    <Form className="ant-advanced-search-form">
                    {isNewDL ?    <Row>
                        <Col span={6} style={{ display: 'block' }}>
                            <FormItem
                               hasFeedback
                               validateStatus={ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                               help={ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                label={<b>DL # </b>}
                            >
                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                label={<b>3 Pos Last Name </b>}
                            >
                                <Input value={ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1} style={{ height: '39px' }} >
                            <FormItem
                                label={<b>Birth Date </b>}
                            >
                                  <DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>:   <Row>
                    <Col span={5}>
                    <FormItem
                     label={<b>DL #</b>}
                    >
                        {this.state.DLNumber}
                        </FormItem>
                    </Col>
                    <Col span={5} offset={1}>
                    <FormItem
                     label={<b>3 Pos Last Name</b>}
                    >
                     {this.state.ThreeCharacterName}
                     </FormItem>
                    </Col>
                    <Col span={6} offset={1} >
                    <FormItem
                     label={<b>Birth Date </b>}
                    >
                    {this.state.BirthDate}
                        </FormItem>
                    </Col>
                                                </Row>}
                            <Row>
                                <Col span={5} >
                                <FormItem
                              validateStatus = {APSType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["APSType"] ? 'error' : ""}
                              help = {APSType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["APSType"]}
                                label={<b>APS Type <font color="red">*</font></b>}
                            ><RadioGroup name="ApsType"  value={APSType} onChange={(e) => this.handleFieldChange(e, 'APSType')}>
                                        {DAPInitData.APSType.map((item) => <Radio key={`apsType-${item.Value}`} value={item.Value}>{item.Text}</Radio>)}
                                    </RadioGroup>
                                    </FormItem>
                                </Col>
                                <Col span={6}>
                                <FormItem
                              validateStatus = {this.state.ArrestDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ArrestDate"] ? 'error' : ""}
                              help = {this.state.ArrestDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ArrestDate"]}
                                label={<b>Arrest / Detain Date <font color="red">*</font></b>}
                            >
                          <DatePicker
                       className = "CalClass"
                       selected={this.state.ArrestDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ArrestDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                </FormItem></Col>
                                <Col span={1} />
                                <Col span={5}>
                                <FormItem
                              validateStatus = {APSTestType=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["APSTestType"] ? 'error' : ""}
                              help = {APSTestType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["APSTestType"]}
                                label={ <b>APS Type of Test <font color="red">*</font></b>}
                            > <Select allowClear= {true} id = "SATTD" onFocus={(e) => {
                                document.getElementById("SATTD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'APSTestType')} value={APSTestType}
                                        showArrow={true} size={"small"} style={{ width: '100%' }} disabled={APSType === 'R'}>
                                        {getDropdownList(DAPInitData.APSTestType)}
                                    </Select>
                               </FormItem> </Col>
                                <Col span={1} />
                                <Col span={5}>
                                <FormItem
                              validateStatus = {UpdateCopies=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                              help = {UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"]}
                                label={  <b>Update Copies</b>}
                            > <Select allowClear= {true} id = "SUCD" onFocus={(e) => {
                                document.getElementById("SUCD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'UpdateCopies')} value={UpdateCopies || '9'}
                                        showArrow={true} size={"small"} style={{ width: '100%' }}>
                                        {DAPInitData.UpdateCopies.map(item =>
                                            <Option key={item.Value} value={item.Value}>{item.Value.trim() ? `${item.Value} - ` : ''}{item.Text}</Option>
                                        )}
                                    </Select></FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={5}>
                                <FormItem
                              validateStatus = {VOPType=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPType"] ? 'error' : ""}
                              help = {VOPType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPType"]}
                                label={ <b>VOP Type <font color="red">*</font></b>}
                            ><RadioGroup name="VOPType" value={VOPType} onChange={e => this.handleFieldChange(e, 'VOPType')}>
                                    <Radio value="N">N/A</Radio>{DAPInitData.VOPType.map((item) => <Radio value={item.Value}>{item.Text}</Radio>)}
                                    </RadioGroup>
                                </FormItem></Col>
                                <Col span={7} />
                                <Col span={5}>
                                    {VOPType !== 'N' && <div>
                                    <FormItem
                              validateStatus = {VOPTestType=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPTestType"] ? 'error' : ""}
                              help = {VOPTestType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPTestType"]}
                                label={ <b>VOP Type of Test <font color="red">*</font></b>}
                            > <Select allowClear= {true} id = "SVTTD" onFocus={(e) => {
                                document.getElementById("SVTTD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'VOPTestType')} value={VOPTestType}
                                            showArrow={true} size={"small"} style={{ width: '100%' }} disabled={VOPType === 'R'}>
                                            {getDropdownList(DAPInitData.VOPTestType)}
                                        </Select>
                                   </FormItem> </div>}
                                </Col>
                            </Row>
                                     <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
<div style={{
backgroundColor: "#c9e3fa",
paddingLeft: "1%"
}} ><h3>Arrest Data</h3></div>
<Row>
                                    <Col span={8}>
                                    <FormItem
                              validateStatus = {LawEnforcementAgency=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LawEnforcementAgency"] ? 'error' : ""}
                              help = {LawEnforcementAgency === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LawEnforcementAgency"]}
                                label={ <b>LE Agency </b>}
                            > <Input placeholder="LE Agency" size={"small"} value={LawEnforcementAgency}
                                            onChange={e => this.handleFieldChange(e, 'LawEnforcementAgency')} />
                                    </FormItem></Col>
                                    <Col span={1} />
                                    <Col span={5}>
                                    <FormItem
                              validateStatus = {(CourtCode=== '' || CourtCode.length < 5) && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtCode"] ? 'error' : ""}
                              help = {(CourtCode=== '' || CourtCode.length < 5) && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtCode"]}
                                label={ <b>Court # <font color="red">*</font></b>}
                            > <Input maxLength={5} placeholder="Enter 5 digit Court #" onBlur={(e) => {if(CourtCode.length < 5){
                                this.setState({ErrorObj: {CourtCode: "Court Code must be 5 digits."}});
                                Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                              Court Code must be 5 digits.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                            }}} value={CourtCode} size={"small"}
                                            onChange={e => this.handleFieldChange(e, 'CourtCode')} />
                                    </FormItem></Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                        {APSType !== 'R' &&
                                            <div>
                                               <FormItem
                                label={ <b>BAC </b>}
                            > 
                                                <Row>
                                                    <Col span={12}>
                                                        <InputNumber id="BAC1"  size={"small"} step={0.01} onFocus={(e) => {document.getElementById('BAC1').focus(); document.getElementById('BAC1').select()}} maxLength={4} value={BAC1.includes('.') ? BAC1 : (parseInt(BAC1,10)/100).toString()} style={{ width: '100%' }}
                                                            onChange={e => this.handleFieldChange(e, 'BAC1')} />
                                                    </Col>
                                                    <Col span={12}>
                                                        <InputNumber id="BAC2"  size={"small"} step={0.01} onFocus={(e) => {document.getElementById('BAC2').focus(); document.getElementById('BAC2').select()}} maxLength={4} value={BAC2.includes('.') ? BAC2 : (parseInt(BAC2,10)/100).toString()} style={{ width: '100%' }}
                                                            onChange={e => this.handleFieldChange(e, 'BAC2')} />
                                                    </Col>
                                                    </Row>
                                         </FormItem>
                                            </div>
                                        }
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={5}>
                                    <FormItem
                                label={ <b>LE Case # </b>}
                            >  <Input size={"small"} placeholder="LE Case #" value={LawEnforcementCaseNo}
                                            onChange={e => this.handleFieldChange(e, 'LawEnforcementCaseNo')} />
                                    </FormItem> </Col>
                                    <Col span={4} />
                                    <Col span={5}>
                                    <FormItem
                                label={ <b>Location </b>}
                            >  <Select allowClear= {true} id = "SLocDAP" onFocus={(e) => {
                                document.getElementById("SLocDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'DSFieldOffice')} value={DSFieldOffice || DAPInitData.DSUserFieldOffice}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DAPInitData.DSFieldOffices, DAPInitData.DSUserFieldOffice, 'location')}
                                        </Select>
                                        </FormItem> </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                        {VOPType !== 'R' && VOPType !== 'N'  &&
                                       
                                              <FormItem
                                label={ <b>VOP BAC </b>}
                            >
                                                <Row>
                                                    <Col span={12}>
                                                        <InputNumber id="VOPBAC1" maxLength={4} onFocus={(e) => {document.getElementById('VOPBAC1').focus(); document.getElementById('VOPBAC1').select()}} size={"small"} step={0.01} value={VOPBAC1.includes('.') ? VOPBAC1 : (parseInt(VOPBAC1,10)/100).toString()} style={{ width: '100%' }}
                                                            onChange={e => this.handleFieldChange(e, 'VOPBAC1')} />
                                                    </Col>
                                                    <Col span={12}>
                                                        <InputNumber id="VOPBAC2" onFocus={(e) => {document.getElementById('VOPBAC2').focus(); document.getElementById('VOPBAC2').select()}} size={"small"} step={0.01} maxLength={4} value={VOPBAC2.includes('.') ? VOPBAC2 : (parseInt(VOPBAC2,10)/100).toString()} style={{ width: '100%' }}
                                                            onChange={e => this.handleFieldChange(e, 'VOPBAC2')} />
                                                    </Col>
                                                </Row>
                                                </FormItem> }
                                    </Col>
                                </Row>

                                <div>
                                    <Row>
                                        <Col span={14} style={{padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                <div style={{
backgroundColor: "#c9e3fa",
paddingLeft: "1%"
}} > <h4>Out-of-State-Data</h4>
                                                  </div>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={16}>
                                                <FormItem
                                label={ <b>O / S DL # </b>}
                            > <Input size={"small"} maxLength={25} placeholder="O / S DL #" value={OutOfStateDLNo}
                                                        onChange={e => this.handleFieldChange(e, 'OutOfStateDLNo')} />
                                               </FormItem>  </Col>
                                                <Col span={1} />
                                                <Col span={7}>
                                                <FormItem
                                label={ <b>O / S Code </b>}
                            > <Select allowClear= {true} id = "SOSDAP" onFocus={(e) => {
                                document.getElementById("SOSDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  size={"small"} placeholder="O / S Code" value={OutOfStateCd}
                                                        onChange={e => this.handleFieldChange(e, 'OutOfStateCd')} showArrow={true} style={{ width: '100%' }}>
                                                        {getDropdownList(DAPInitData.OSCode)}
                                                    </Select>
                                                    </FormItem> </Col>
                                            </Row>
                                        </Col>
                                        <Col span={1} />
                                        <Col span={8}>                   
                                                <FormItem
                                              validateStatus = {CommercialStatusIndicator=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"] ? 'error' : ""}
                                              help = {CommercialStatusIndicator === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"]}
                                label={ <b>Commercial Status Indicator <font color="red">*</font></b>}
                            > <Select allowClear= {true} id = "SCSIDAP" onFocus={(e) => {
                                document.getElementById("SCSIDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  size={"small"} onChange={e => this.handleFieldChange(e, 'CommercialStatusIndicator')}
                                                        value={CommercialStatusIndicator} showArrow={true} style={{ width: '100%' }}>
                                                        {getDropdownList(DAPInitData.CommStatusIndicator)}
                                                    </Select></FormItem>        
                                        </Col>
                                    </Row>
                                </div>
                            </div>
                            <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
                            <div style={{
                            backgroundColor: "#c9e3fa",
                            paddingLeft: "1%"
                            }} > <h3>End Stay / Re-impose</h3></div>
                                <Row>
                                    <Col span={6}>
                                    <FormItem
                                label={<b>Effective Date </b>}
                            > 
                             <DatePicker
                       className = "CalClass"
                       selected={this.state.EffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                     </FormItem> </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                    <FormItem
                                label={<b>Mail Date </b>}
                            >                 
         <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
</FormItem> </Col>
                                    <Col span={1} />
                                    <Col span={10}>
                                    <FormItem
                                label={<b>APS Original Authority Section </b>}
                            > <Select allowClear= {true} id = "SAOADAP" onFocus={(e) => {
                                document.getElementById("SAOADAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'PASOrigAuthSect')}
                                            value={PASOrigAuthSect} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DAPInitData.APSOriginalAuthoritySection)}
                                        </Select>
                                        </FormItem>  </Col>
                                    <Col span={1} />
                                    <Col span={8}>
                                    <FormItem
                                label={<b>Original Effective Date </b>}
                            > 
                          <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                    </FormItem>  </Col>
                                </Row>

                                <Row>
                                    <Col span={5}>
                                    <FormItem
                                label={<b>End Stay </b>}
                            > <Select allowClear= {true} id = "SESDAP" onFocus={(e) => {
                                document.getElementById("SESDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'EndStay')} value={EndStay}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DAPInitData.EndStay)}
                                        </Select>
                                        </FormItem>  </Col>
                                    <Col span={5} />
                                    <Col span={8}>
                                    {VOPType !== 'R' && VOPType !== 'N'  &&  <FormItem
                                label={<b>VOP Original Authority Section </b>}
                            > <Select allowClear= {true} id = "SVODAP" onFocus={(e) => {
                                document.getElementById("SVODAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'VOPOrigAuthSect')}
                                            value={VOPOrigAuthSect} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DAPInitData.VOPOriginalAuthoritySection)}
                                        </Select>
                                                                    </FormItem>  } </Col>
                                </Row>
                            </div>
                            <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
                            <div style={{
                            backgroundColor: "#c9e3fa",
                            paddingLeft: "1%"
                            }} ><h3>Hearing Information</h3>
                                        </div>
                                <Row>
                                    <Col span={4}>
                                    <FormItem
                                 label={<b>Date </b>}
                             > 
                              <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                         </FormItem>    </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                    <FormItem
                                 label={<b>Result </b>}
                             > <Select allowClear= {true} id = "SResDAP" onFocus={(e) => {
                                document.getElementById("SResDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled ={VOPType === 'A'} onChange={e => this.handleFieldChange(e, 'HearingResult')} value={HearingResult} 
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DAPInitData.HearingResults)}
                                        </Select>
                                        </FormItem>    </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                    <FormItem
                                 label={<b>Chg Hearing Type </b>}
                             > <Select allowClear= {true} id = "SCHTDAP" onFocus={(e) => {
                                document.getElementById("SCHTDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled ={VOPType === 'A'} onChange={e => this.handleFieldChange(e, 'HearingType')} value={HearingType}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DAPInitData.ChgHearingType)}
                                        </Select>
                                        </FormItem>  </Col>
                                    <Col span={1} />
                                    <Col span={10}>
                                    <FormItem
                                 label={<b>Modified Hearing Date </b>}
                             > 
                             <DatePicker
                       className = "CalClass"
                       selected={this.state.ModifiedHearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ModifiedHearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                          </FormItem>    </Col>
                                </Row>
                                <Row>
                                    <Col span={14}>
                                        {VOPType === 'A' && <span style={{ color: 'red', fontWeight: 'bold', verticalAlign: 'middle' }}> Please use DUW transaction to update Hearing Information. </span>}
                                    </Col>
                                </Row>
                            </div>
 <br/> <Row>
                                <Col span={10}>
                                <FormItem
                                 label={<b>Correct Arr/ Det Date </b>}
                             >
                               <DatePicker
                       className = "CalClass"
                       selected={this.state.CorrArrestDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'CorrArrestDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                       </FormItem>   </Col>
                                <Col span={1} />
                                <Col span={9}>
                                <FormItem
                                 label={<b>Co / Fo </b>}
                             > <Select allowClear= {true} id = "SCoFoDAP" onFocus={(e) => {
                                document.getElementById("SCoFoDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CoFo')} value={CoFo} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                        {getDropdownList(DAPInitData.CoFo)}
                                    </Select>
                                    </FormItem>  </Col>
                                <Col span={1} />
                                <Col span={10}>
                                <FormItem
                                 label={<b>Different Serv Date </b>}
                             > 
                             <DatePicker
                       className = "CalClass"
                       selected={this.state.DiffServDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'DiffServDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                       </FormItem>   </Col>
                            </Row>
                            <Row>
                                <Col span={2} />
                                <Col span={5}>
                                <FormItem
                                 label={<b>License Location </b>}
                             > <Select allowClear= {true} id = "SLLDAP" onFocus={(e) => {
                                document.getElementById("SLLDAP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'LicenseLocation')}
                                        value={LicenseLocation} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                        {getDropdownList(DAPInitData.LicenseLocation)}
                                    </Select>
                                    </FormItem>   </Col>
                                <Col span={1} />
                                <Col span={5}>
                                <FormItem
                                 label={<b>Credit Days </b>}
                             > <Input size={"small"} maxLength={3} placeholder="Credit Days" value={CreditDays} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'CreditDays')} />
                                       </FormItem>   </Col>
                                </Row>
                                <Row>
                                <Col span={10}>
                                    <FormItem
                                        label={<b>Next Trans  </b>}
                                    >
                                        <Input style={{width: '30%'}} maxLength = {3} value={NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                    </FormItem>
                                </Col>
                                <Col span={6} offset = {1} style={{ float: 'right' }}>
                                    {NextDLNumber !== '' ? <Button disabled
                                        type="default">New DL</Button>:<Button style={{ color: "white", backgroundColor: "green" }}
                                         type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                    <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                    <Button style={{ color: "white", backgroundColor: "red" }}
                                        type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                                </Col>
                            </Row>
                            </Form>
                            </div>
                    </Col>
                </Row>:<div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => {
                                
                                this.setState({ErrorModalShow: false})
                                if( !this.state.ErrorObj )
                                {
                                    if(isNewDL === true)
                                    {
                                        this.setState({     dapObj: cloneDeep(defaultDAPObj),
                                            ArrestDate: "",
                                            EffectiveDate: "",
                                            MailDate: "",
                                            DLNumber: "",
                                            BirthDate: "",
                                            OrigEffectiveDate: "",
                                            HearingDate: "",
                                            ModifiedHearingDate: "",
                                            CorrArrestDate: "",
                                            DiffServDate: "",
                                            ErrorMessage: '',
                                            ErrorObj: {},
                                            ErrorModalShow: false
                                        });
                                    }
                                   else if(NextDLNumber !== '')
                                {
                                    this.props.history.push({ pathname: `/${NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                    state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                }  
                                else {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: this.state.DLNumber }
                                    })
                                }                           
                        }
                    }
                                }>Ok</Button>
                        </div>
                    ]}
                >
                   {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal> 
                            </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}          
            </React-Fragment>
        );
}
}

const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
           getDAPInitialPage, 
            saveDAPUpdate, getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DAPUpdate);



