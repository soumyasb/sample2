import React, { Component } from 'react';
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { InputNumber, Form, Row, Col, Spin, Input, Radio, Select, Button, Modal } from 'antd';
import { getDASInitialPage, 
    saveDASUpdate, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { checkIfFutureDate, dateFormatFunc, dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';

const RadioGroup = Radio.Group;
const { Option } = Select;
const FormItem = Form.Item;

const smallDASObj = {
    RequestorCode: '',
    Operator: '',
    NetName: '',
    LoginId: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    BirthDate: '',
    DSUserFieldOffice: '',
    DetainDate: '',
    UpdateCopies: '9',
    VOPType: '',
    VOPTestType: '',
    LawEnforcementAgency: '',
    CourtCode: '',
    LawEnforcementCaseNo: '',
    DSFieldOffice: '',
    VOPBAC1: '0.00',
    VOPBAC2: '0.00',
    OutOfStateDLNo: '',
    OutOfStateCd: '',
    CommercialStatusIndicator: '',
    EffectiveDate: '',
    MailDate: '',
    OrigEffectiveDate: '',
    EndStay: '',
    OrigAuthSect: '',
    HearingDate: '',
    HearingResult: '',
    HearingType: '',
    ModifiedHearingDate: '',
    CorrDetDate: '',
    CoFo: '',
    DiffServDate: '',
    LicenseLocation: '',
    CreditDays: '',
    DARResponse: '',
    DASResponse: '',
    NextDLNumber: '',
    Error: true
}

const getDropdownList = (listObj, selectedValue, type) => {
    let list = [];

    if(type === 'location')
    {
        listObj.map(item => {
            if (item.Value !== "") {
                if (item.Value === selectedValue) {
                    list.push(<Option title={`${item.Value} - ${item.Text}`} key={type+item.Value} value={item.Value} selected>{item.Text}</Option>)
                }
                else {
                    list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Text}</Option>)
                }
            }
            return "";
        });
    }
    else
    {
        listObj.map(item => {
            if (item.Value !== "") {
                if (item.Value === selectedValue) {
                    list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value} selected> {item.Value} - {item.Text}</Option>)
                }
                else {
                    list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>)
                }
            }
            return "";
        });
    }
    return list;
}

class DASUpdate extends Component {
    constructor(props) {
        super(props);
        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            dasObj: cloneDeep(smallDASObj),
            isNewDL: false,
            ErrorMessage: '',
            DetainDate: "",
            EffectiveDate: "",
            MailDate: "",
            OrigEffectiveDate: "",
            HearingDate: "",
            ModifiedHearingDate: "",
            CorrDetDate: "",
            DiffServDate: "",
            ErrorObj: {},
            ErrorModalShow: false
        };
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    componentDidMount(){
        
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getDASInitialPage(DLInitData.DLNumber);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
    }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.dasInitPageData !== this.props.dlUpdates.dasInitPageData && this.props.dlUpdates.dasInitPageData !== undefined) {
                                const dasObj = cloneDeep(smallDASObj);
                                dasObj['ThreeCharacterName'] = this.props.dlUpdates.dasInitPageData.ThreeCharacterName;
                                dasObj['BirthDate'] = this.props.dlUpdates.dasInitPageData.BirthDate;
                                this.setState({DASInitData: this.props.dlUpdates.dasInitPageData, dasObj: dasObj});
                            }
                            if ( prevProps.dlUpdates.dasUpdateSaveData !== this.props.dlUpdates.dasUpdateSaveData && this.props.dlUpdates.dasUpdateSaveData !== undefined) {
                                this.setState({DASSaveData: this.props.dlUpdates.dasUpdateSaveData, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const dasObj = cloneDeep(smallDASObj);
                               dasObj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                               dasObj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
                                this.setState({ dasObj: dasObj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { dasInitPageData, dasUpdateSaveData, dlUpdatesErrorData } = props.dlUpdates;
                if (dasInitPageData && dasInitPageData !== prevState.dasInitPageData) return { DASInitData: dasInitPageData, isloading: false };
                if (dasUpdateSaveData && dasUpdateSaveData !== prevState.DASSaveData) return { DASSaveData: dasUpdateSaveData, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false};
                return null;
            }

    handleFieldChange(e, type) {
        const { dasObj } = this.state;
                switch (type) {
                    case 'ThreeCharacterName':
                    case 'NextDLNumber':
                        dasObj[type] = e.target.value;
                    break;
                    case 'DLNumber':
                    this.setState({DLNumber: e.target.value});
                    dasObj[type] = e.target.value;
                        if ((dasObj['DLNumber'].length === 8)) {
                              this.props.getDLInitialData(dasObj['DLNumber']);
                            this.props.getDASInitialPage(dasObj['DLNumber']);
                        }
                        break;
            case 'VOPType':
                dasObj[type] = e.target.value;
                if (e.target.value === 'R') dasObj['VOPTestType'] = 'RE';
                else dasObj['VOPTestType'] = '';
                break;
                case 'VOPBAC1':
                case 'VOPBAC2':
                if(e.toString().includes('.'))
                { if(e.toString().length < 5) {
                       if(e < 0 || e > 0.6){
                             //  this.setState({WarningMessage: 'Invalid BAC Value. Value should be between 0.00 to 0.60.', WarningModalShow: true});
                               Modal.error({
                                title: "Error"
                                ,
                                content: (
                                  <div>
                               Invalid BAC Value. Value should be between 0.00 to 0.60.
                                  </div>
                                ),
                                onOk() {},
                              });
                           }
                           else
                           {
                                dasObj[type] = e.toString();
                           }
                       }
                       else
                       {
                          var es = e.toString();
                           dasObj[type] = (parseInt(es.substring(es.length -2),10)/100).toString();
                       }   
                   }
                   else
                   {
                           if((e/100) < 0 || (e/100) > 0.6){
                                  // this.setState({WarningMessage: 'Invalid BAC Value. Value should be between 0.00 to 0.60.', WarningModalShow: true});
                                  Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                                Invalid BAC Value. Value should be between 0.00 to 0.60.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                               }
                               else
                               {
                                    dasObj[type] = (e/100).toString();
                               }
                   }   
        break;
            case 'UpdateCopies':
            case 'VOPTestType':
            case 'CommercialStatusIndicator':
            case 'OSCode':
            case 'OrigAuthSect':
            case 'EndStay':
            case 'HearingResult':
            case 'HearingType':
            case 'CoFo':
            case 'LicenseLocation':
            case 'OutOfStateCd':
            case 'OutOfStateDLNo':
            case 'DSFieldOffice':
            if(!e)
            {
            dasObj[type] = '';
            }
            else
            {
            dasObj[type] = e;
            }
            break;
            case 'CreditDays':
            { const { value } = e.target;
            const reg = /^[0-9]*$/;
            if ((!isNaN(value) && reg.test(value))) {
              dasObj[type] = e.target.value;
            }   }      break;
            case 'CourtCode':
            { const { value } = e.target;
            const reg = /^[0-9]*$/;
            if ((!isNaN(value) && reg.test(value))) {
              dasObj[type] = e.target.value;
            }   }      
                break;
            case 'LawEnforcementAgency':
                if (e.target.value.length <= 25) {
                    dasObj[type] = e.target.value;
                }
                break;
            case 'LawEnforcementCaseNo':
                if (e.target.value.length <= 13) {
                    dasObj[type] = e.target.value;
                }
                break;
            default:
                break;
        }

        this.setState({ dasObj });
    }

    onDateChange(d, type) {
        if (type === 'DetainDate') {
            if(this.state.dasObj.VOPType === '')
            {
               // this.setState({ WarningMessage: 'VOP Type must be selected.', WarningModalShow: true });
               Modal.error({
                title: "Error"
                ,
                content: (
                  <div>
               VOP Type must be selected.
                  </div>
                ),
                onOk() {},
              });
                return;
            }
            else {
            if (d && !checkIfFutureDate(d)) {
               // this.setState({ WarningMessage: 'Detain Date cannot be in the future', WarningModalShow: true });
               Modal.error({
                title: "Error"
                ,
                content: (
                  <div>
               Detain Date cannot be in the future.
                  </div>
                ),
                onOk() {},
              });
                return;
            }
            else
            {
                this.setState({ DetainDate: d });
            }
        }
        }
        else
        {
            switch(type) {
                case 'EffectiveDate':
                this.setState({ EffectiveDate: d });
                break;
                case 'MailDate':
                this.setState({ MailDate: d });
                break;
                case 'OrigEffectiveDate':
                this.setState({ OrigEffectiveDate: d });
                break;
                case 'HearingDate':
                this.setState({ HearingDate: d });
                break;
                case 'ModifiedHearingDate':
                this.setState({ ModifiedHearingDate: d });
                break;
                case 'BirthDate':
                this.setState({ BirthDate: d });
                break;
                case 'CorrDetDate':
                this.setState({ CorrDetDate: d });
                break;
                case 'DiffServDate':
                this.setState({ DiffServDate: d });
                break;
                default:
                break;
            }
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }


    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
                    
            const { dasObj } = this.state;
            dasObj['RequestorCode'] = this.state.DASInitData.RequestorCode;
            dasObj['Operator'] = this.state.DASInitData.Operator;
            dasObj['NetName'] = this.state.DASInitData.NetName;
            if(typeof this.state.BirthDate === 'string')
            {
                dasObj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
            }
          else
          {
            dasObj['BirthDate'] = dateFormatFunc(this.state.BirthDate);
          }
            dasObj['LoginId'] = this.state.DASInitData.LoginId;
            if(dasObj['DSFieldOffice'] === '')
            {
                
                dasObj['DSFieldOffice'] = this.state.DASInitData.DSUserFieldOffice;
            }
           if(dasObj['VOPBAC1'].includes('.')){
            dasObj['VOPBAC1'] = (parseFloat(dasObj['VOPBAC1'])*100).toString();
           } 
           if(dasObj['VOPBAC2'].includes('.')){ dasObj['VOPBAC2'] = (parseFloat(dasObj['VOPBAC2'])*100).toString();
        } 
            dasObj['DLNumber'] = this.state.DLNumber;
            dasObj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
            if(dasObj['BirthDate'] === undefined)
            {
                dasObj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
            }
            else
            {
                dasObj['BirthDate'] = dasObj['BirthDate'].substring(0,2)+dasObj['BirthDate'].substring(3,5)+dasObj['BirthDate'].substring(8,10);
            }
            dasObj['DetainDate'] = dateFormatFuncDLUpdates(this.state.DetainDate);
            dasObj['EffectiveDate'] = dateFormatFuncDLUpdates(this.state.EffectiveDate);
            dasObj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
            dasObj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
            dasObj['ModifiedHearingDate'] = dateFormatFuncDLUpdates(this.state.ModifiedHearingDate);
            dasObj['CorrDetDate'] = dateFormatFuncDLUpdates(this.state.CorrDetDate);
            dasObj['DiffServDate'] = dateFormatFuncDLUpdates(this.state.DiffServDate);
            this.setState({isloading: true, DLNumber: dasObj['DLNumber'], isNewDL: isNewDL});
           this.props.saveDASUpdate(dasObj);
    }

    render() {
        const {
           ThreeCharacterName, UpdateCopies, VOPType, VOPTestType,
            LawEnforcementAgency, CourtCode, LawEnforcementCaseNo, DSFieldOffice, VOPBAC1, VOPBAC2, OutOfStateDLNo, OutOfStateCd,
            CommercialStatusIndicator, EndStay, OrigAuthSect,
            HearingResult, HearingType, CoFo, LicenseLocation,
            CreditDays, NextDLNumber
        } = this.state.dasObj;
        const { DASInitData, DASSaveData, isNewDL, isloading } = this.state;

        return (
            // <ScrollPanel style={{ width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0)" }}>
            <React-Fragment>
           {isloading !== true ? <div style={{backgroundColor: "white", marginTop: '1%', width: "95%", marginLeft: '2%'}}> 
           {DASSaveData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => { 
                   this.setState({openSuccessModal: false}); 
                   if(DASSaveData.Error === false)
                   {
                    if (NextDLNumber !== '') {
                        this.props.history.push({
                            pathname: `/${NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                        });
                    }
                  else if (isNewDL !== true) {
                    this.props.history.push({
                        pathname: `/dlUpdates`,
                        state: { dlNumber: DASSaveData.DLNumber }
                    })
                }
              else {
                    this.setState({
                        dasObj: cloneDeep(smallDASObj),
                                                    ErrorMessage: '',
                                                    DetainDate: "",
                                                    DLNumber:'',
                                                    EffectiveDate: "",
                                                    MailDate: "",
                                                    OrigEffectiveDate: "",
                                                    HearingDate: "",
                                                    BirthDate: "",
                                                    ModifiedHearingDate: "",
                                                    CorrDetDate: "",
                                                    DiffServDate: "",
                                                    ErrorObj: {},
                                                    ErrorModalShow: false
                    });
                }
              
            }}}>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: DASSaveData.DARResponse.toString()}}/>
            <div dangerouslySetInnerHTML={{ __html: DASSaveData.DASResponse.toString()}}/></div></Modal>}
           
           {DASInitData ? 
                <Row>
                    <Col span={24}>
                    <div style={{
border: '1px solid black',
paddingLeft: "1%",
textAlign: 'center',
backgroundColor: '#c9e3fa',
fontSize: '32px'
}} >DAS - VOP Update</div>
                    <div style= {{margin: '1%'}}>
                    <Form className="ant-advanced-search-form">
                    {isNewDL ? <Row>
                        <Col span={6} style={{ display: 'block' }}>
                        <FormItem
                          hasFeedback
                          validateStatus={ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                          help={ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
            label={<b>DL # </b>}
        >                      
                                <Input size={"small"} style={{width: 'auto'}} value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                        <FormItem
            label={<b>3 Pos Last Name </b>}
        >
                                <Input size={"small"} maxLength={3} style={{width: 'auto'}} value={ThreeCharacterName} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                        <FormItem
            label={<b>Birth Date </b>}
        >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                         </FormItem>
                        </Col>
                    </Row>:  <Row>
                    <Col span={5}>
                    <FormItem
                     label={<b>DL #</b>}
                    >
                        {this.state.DLNumber}
                        </FormItem>
                    </Col>
                    <Col span={5} offset={1}>
                    <FormItem
                     label={<b>3 Pos Last Name</b>}
                    >
                     {this.state.ThreeCharacterName}
                     </FormItem>
                    </Col>
                    <Col span={6} offset={1} >
                    <FormItem
                     label={<b>Birth Date </b>}
                    >
                    {this.state.BirthDate}
                        </FormItem>
                    </Col>
                                                </Row>}
                            <Row>
                                <Col span={5} >
                                <FormItem
                              validateStatus = {VOPType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPType"] ? 'error' : ""}
                              help = {VOPType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPType"]}
                                label={<b>VOP Type <font color="red">*</font></b>}
                            >
                                    <RadioGroup name="VOPType" size={"small"} value={VOPType} onChange={e => this.handleFieldChange(e, 'VOPType')}>
                                        {DASInitData.VOPType.map((item) => <Radio key={item.value} value={item.Value}>{item.Text}</Radio>)}
                                    </RadioGroup>
                                    </FormItem>
                                </Col>
                                <Col span={1} />
                                <Col span={5}>
                                <FormItem
                              validateStatus = {this.state.DetainDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DetainDate"] ? 'error' : ""}
                              help = {this.state.DetainDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DetainDate"]}
                                label={<b>Detain Date <font color="red">*</font></b>}
                            >
          <DatePicker
                       className = "CalClass"
                       selected={this.state.DetainDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'DetainDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                               </FormItem>
                                </Col>
                                <Col span={1} />
                                <Col span={5}>
                                    {VOPType !== 'N' && <div>
                                    <FormItem
                                validateStatus = {VOPTestType=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPTestType"] ? 'error' : ""}
                                help = {VOPTestType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["VOPTestType"]}
                                  label={ <b>VOP Type of Test <font color="red">*</font></b>}
                              >
                                        <Select allowClear = {true} id = "SVTD" onFocus={(e) => {
                                document.getElementById("SVTD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'VOPTestType')} value={VOPTestType}
                                            showArrow={true} size={"small"} style={{ width: '100%' }} disabled={VOPType === 'R'}>
                                            {getDropdownList(DASInitData.VOPTestType)}
                                        </Select>
                                        </FormItem>
                                    </div>}
                                </Col>
                                <Col span={1} />
                                <Col span={5}>
                                <FormItem
                              validateStatus = {UpdateCopies=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                              help = {UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"]}
                                label={  <b>Update Copies</b>}
                            >
                                     <Select allowClear = {true} id = "SUCDAS" onFocus={(e) => {
                                document.getElementById("SUCDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'UpdateCopies')} value={UpdateCopies}
                                        showArrow={true} size={"small"} style={{ width: '100%' }}>
                                        {DASInitData.UpdateCopies.map(item =>
                                            <Option key={item.Value} value={item.Value}>{item.Value.trim() ? `${item.Value} - ` : ''}{item.Text}</Option>
                                        )}
                                    </Select>
                                    </FormItem>
                                </Col>
                            </Row>
                            <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
                            <div style={{
                                backgroundColor: "#c9e3fa",
                                paddingLeft: "1%"
                                }} ><h3>VOP Detain Data</h3></div>
                                <Row>
                                    <Col span={8}>
                                        <FormItem
                              validateStatus = {LawEnforcementAgency=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LawEnforcementAgency"] ? 'error' : ""}
                              help = {LawEnforcementAgency === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LawEnforcementAgency"]}
                                label={  <b>LE Agency <font color="red">*</font></b>}
                            >
                                         <Input size={"small"} placeholder="LE Agency" value={LawEnforcementAgency}
                                            onChange={e => this.handleFieldChange(e, 'LawEnforcementAgency')} />
                                   </FormItem>
                                    </Col>
                                    <Col span={1} />
                                    <Col span={5}>
                                    <FormItem
                              validateStatus = {(CourtCode=== '' || CourtCode.length < 5) && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtCode"] ? 'error' : ""}
                              help = {(CourtCode=== '' || CourtCode.length < 5) && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtCode"]}
                                label={  <b>Court # <font color="red">*</font></b>}
                            >
                                       <Input  maxLength={5} placeholder="Enter 5 digit Court #" onBlur={(e) => {if(CourtCode.length < 5){
                                           this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits."} });
                                           Modal.error({
                                            title: "Error"
                                            ,
                                            content: (
                                              <div>
                                        Court Code must be 5 digits.
                                              </div>
                                            ),
                                            onOk() {},
                                          });
                                        }}} size={"small"} value={CourtCode}
                                            onChange={e => this.handleFieldChange(e, 'CourtCode')} />
                                    </FormItem>
                                    </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                        {VOPType === 'A' &&
                                            <div>
                                                <Row>
                                                    <b>BAC </b>: </Row>
                                                <Row>
                                                    <Col span={12}>
                                                    <InputNumber id="VOPBAC1" maxLength={4} onFocus={(e) => {document.getElementById('VOPBAC1').focus(); document.getElementById('VOPBAC1').select()}} size={"small"} step={0.01} value={VOPBAC1.includes('.') ? VOPBAC1 : (parseInt(VOPBAC1,10)/100).toString()} style={{ width: '100%' }}
                                                            onChange={e => this.handleFieldChange(e, 'VOPBAC1')} />
                                                    </Col>
                                                    <Col span={12}>
                                                    <InputNumber id="VOPBAC2" onFocus={(e) => {document.getElementById('VOPBAC2').focus(); document.getElementById('VOPBAC2').select()}} size={"small"} step={0.01} maxLength={4} value={VOPBAC2.includes('.') ? VOPBAC2 : (parseInt(VOPBAC2,10)/100).toString()} style={{ width: '100%' }}
                                                            onChange={e => this.handleFieldChange(e, 'VOPBAC2')} />
                                                    </Col>
                                                </Row>
                                            </div>}
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={5}>
                                    <FormItem
                                label={ <b>LE Case # </b>}
                            >  <Input size={"small"} placeholder="LE Case #" value={LawEnforcementCaseNo}
                                            onChange={e => this.handleFieldChange(e, 'LawEnforcementCaseNo')} />
                                        </FormItem>  </Col>
                                    <Col span={4} />
                                    <Col span={5}>
                                    <FormItem
                                label={ <b>Location </b>}
                            ><Select allowClear = {true} id = "SLDAS" onFocus={(e) => {
                                document.getElementById("SLDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'DSFieldOffice')}  value={DSFieldOffice || DASInitData.DSUserFieldOffice}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DASInitData.DSFieldOffices, DASInitData.DSUserFieldOffice, 'location')}
                                        </Select>  </FormItem>
                                    </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                    </Col>
                                </Row>
                                <div>
                                    <Row>
                                        <Col span={14} style={{padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                <div style={{
backgroundColor: "#c9e3fa",
paddingLeft: "1%"
}} > <h4>Out-of-State-Data</h4></div>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={16}>
                                                <FormItem
                                label={ <b>O / S DL # </b>}
                            ><Input size={"small"} placeholder="O / S DL #" value={OutOfStateDLNo}
                                                        onChange={e => this.handleFieldChange(e, 'OutOfStateDLNo')} />
                                            </FormItem>    </Col>
                                                <Col span={1} />
                                                <Col span={7}>
                                                <FormItem
                                label={ <b>O / S Code </b>}
                            ><Input size={"small"} placeholder="O / S Code" value={OutOfStateCd}
                                                        onChange={e => this.handleFieldChange(e, 'OutOfStateCd')} />
                                               </FormItem> </Col>
                                            </Row>
                                        </Col>
                                        <Col span={1} />
                                        <Col span={10}>
                                                <FormItem
                                              validateStatus = {CommercialStatusIndicator=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"] ? 'error' : ""}
                                              help = {CommercialStatusIndicator === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"]}
                                label={ <b>Commercial Status Indicator <font color="red">*</font></b>}
                            > <Select allowClear = {true} id = "SCSIDAS" onFocus={(e) => {
                                document.getElementById("SCSIDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  size={"small"} onChange={e => this.handleFieldChange(e, 'CommercialStatusIndicator')}
                                                        value={CommercialStatusIndicator} showArrow={true} style={{ width: '100%' }}>
                                                        {getDropdownList(DASInitData.CommStatusIndicator)}
                                                    </Select></FormItem>
                                                </Col>                       
                                    </Row>
                                </div>
                            </div>

                            <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
                            <div style={{
                            backgroundColor: "#c9e3fa",
                            paddingLeft: "1%"
                            }} > <h3>End Stay / Re-impose</h3></div>
                                <Row>
                                    <Col span={6}>
                                    <FormItem
                                label={<b>Effective Date </b>}
                            >
                                   <DatePicker
                       className = "CalClass"
                       selected={this.state.EffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /></FormItem>  </Col>
                                    <Col span={6}>
                                    <FormItem
                                     validateStatus = {EndStay=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EndStay"] ? 'error' : ""}
                                     help = {EndStay === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EndStay"]}
                                label={<b>Mail Date <font color="red">*</font></b>}
                            >
          <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
</FormItem>
                                    </Col>
                                    <Col span={1} />
                                    <Col span={8}>
                                        <FormItem
                                label={<b>Original Effective Date </b>}
                            >
                                      <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>  </Col>
                                </Row>
                                <Row>
                                    <Col span={5}>
                                    <FormItem
                                     validateStatus = {EndStay=== '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EndStay"] ? 'error' : ""}
                                     help = {EndStay === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EndStay"]}
                           label={<b>End Stay  <font color="red">*</font></b>}
                       > <Select allowClear = {true} id = "SESDAS" onFocus={(e) => {
                                document.getElementById("SESDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'EndStay')} value={EndStay}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DASInitData.EndStay)}
                                        </Select>
                                        </FormItem>  </Col>
                                    <Col span={5} />
                                    <Col span={6}>
                                    <FormItem
                           label={<b>Original Authority Section  </b>}
                       ><Select allowClear = {true} id = "SRea2" onFocus={(e) => {
                                document.getElementById("SRea2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OrigAuthSect')}
                                            value={OrigAuthSect} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DASInitData.OriginalAuthoritySection)}
                                        </Select>
                                        </FormItem> </Col>
                                </Row>
                            </div>
                            <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
                            <div style={{
                            backgroundColor: "#c9e3fa",
                            paddingLeft: "1%"
                            }} ><h3>Hearing Information</h3></div>
                                <Row>
                                    <Col span={4}>
                                    <FormItem
                           label={<b>Date </b>}
                       > 
                            <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>  </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                    <FormItem
                           label={<b>Result  </b>}
                       ><Select allowClear = {true} id = "SResDAS" onFocus={(e) => {
                                document.getElementById("SResDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled onChange={e => this.handleFieldChange(e, 'HearingResult')} value={HearingResult}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                            {getDropdownList(DASInitData.HearingResults)}
                                        </Select>
                                        </FormItem>  </Col>
                                    <Col span={1} />
                                    <Col span={6}>
                                    <FormItem
                           label={<b>Chg Hearing Type  </b>}
                       > <Select allowClear = {true} id = "SCHTD" onFocus={(e) => {
                                document.getElementById("SCHTD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled onChange={e => this.handleFieldChange(e, 'HearingType')} value={HearingType}
                                            showArrow={true} size={"small"} style={{ width: '100%' }}>
                                        </Select>
                                        </FormItem>   </Col>
                                <Col span={1} />
                                    <Col span={10}>
                                    <FormItem
                           label={<b>Modified Hearing Date </b>}
                       >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.ModifiedHearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ModifiedHearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /></FormItem>   </Col>
                                    <Col span={2} />
                                    <Col span={14}>
                                       <span style={{ color: 'red', fontWeight: 'bold', verticalAlign: 'middle' }}> Please use DUW transaction to update Hearing Information. </span>
                                    </Col>
                                </Row>
                            </div>
                            <br/>
                            <Row>
                                <Col span={8}>
                                <FormItem
                           label={<b>Correct Det Date  </b>}
                       > 
                               <DatePicker
                       className = "CalClass"
                       selected={this.state.CorrDetDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'CorrDetDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>   </Col>
                                <Col span={1} />
                                <Col span={9}>
                                <FormItem
                           label={<b>Co/Fo  </b>}
                       ><Select allowClear = {true} id = "SCoFoDAS" onFocus={(e) => {
                                document.getElementById("SCoFoDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CoFo')} value={CoFo} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                    {getDropdownList(DASInitData.CoFo)}
                                    </Select>
                                    </FormItem>  </Col>
                                <Col span={1} />
                                <Col span={8}>
                                <FormItem
                           label={<b>Different Serve Date </b>}
                       > 
                                 <DatePicker
                       className = "CalClass"
                       selected={this.state.DiffServDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'DiffServDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem> </Col>
                            </Row>
                            <Row>
                            <Col span={2} />
                                <Col span={5}>
                                <FormItem
                           label={<b>License Location  </b>}
                       ><Select allowClear = {true} id = "SLLDAS" onFocus={(e) => {
                                document.getElementById("SLLDAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'LicenseLocation')}
                                        valye={LicenseLocation} showArrow={true} size={"small"} style={{ width: '100%' }}>
                                        {getDropdownList(DASInitData.LicenseLocation)}
                                    </Select>
                                    </FormItem> </Col>
                                <Col span={1} />
                                <Col span={4}>
                                <FormItem
                           label={<b>Credit Days  </b>}
                       ><Input size={"small"} maxLength={3} placeholder="Credit Days"
                                        value={CreditDays} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'CreditDays')} />
                                </FormItem>  </Col>
                            </Row>
                            <Row>
                            <Col  span={10}>
                            <FormItem
                                label={<b>Next Trans  </b>}
                            >
                                <Input style={{width: '30%'}} maxLength = {3} value={NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                            </FormItem>
                        </Col>
                                <Col span={6} offset = {1} style={{ float: 'right' }}>
                                {NextDLNumber !== '' ? <Button disabled
                           type="default">New DL</Button>:<Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                       <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                       <Button style={{ color: "white", backgroundColor: "red" }}
                           type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                           state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                                </Col>
                            </Row>
                            </Form>
                            </div>
                    </Col>
                </Row>:<div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) =>  {
                                            this.setState({ErrorModalShow: false});
                                            if( !this.state.ErrorObj )
                                            {
                                    if(isNewDL === true)
                                    {
                                                this.setState({ dasObj: cloneDeep(smallDASObj),
                                                    ErrorMessage: '',                   
                                                    DLNumber: '',
                                                    DetainDate: "",
                                                    EffectiveDate: "",
                                                    MailDate: "",
                                                    BirthDate: "",
                                                    OrigEffectiveDate: "",
                                                    HearingDate: "",
                                                    ModifiedHearingDate: "",
                                                    CorrDetDate: "",
                                                    ErrorObj: {},
                                                    DiffServDate: "",
                                                    ErrorModalShow: false
                                                });
                                            }
                                            else if(NextDLNumber !== '')
                                            {
                                                this.props.history.push({ pathname: `/${NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                                state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                            }  
                                  else  {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }
                                                 
                                    }}>Ok</Button>
                        </div>
                    ]}
                >
       {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
     </Modal>
     {/* <Modal visible={this.state.WarningModalShow}
                            onCancel={(e) => this.setState({WarningModalShow: false})}
                                title={'Warning message'} maskClosable={false}
                                footer={[
                                    <div>
                                      
                                        <Button type="default" key="Ok" onClick={(e) => this.setState({ WarningModalShow: false})}>OK</Button>
                                    </div>
                                ]}
                            >
                              <font color='red'> {this.state.WarningMessage} </font>
                            </Modal> */}
     </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            {/* </ScrollPanel > */}
            </React-Fragment>
        );
    }

}

const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
           getDASInitialPage, 
            saveDASUpdate,
            getDLInitialData
        },
        dispatch
    );
};
export default connect(mapStateToProps, mapDispatchToProps)(DASUpdate);