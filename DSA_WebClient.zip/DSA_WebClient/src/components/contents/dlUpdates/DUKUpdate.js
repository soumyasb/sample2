import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates, dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { getDUKData, saveDUKData, getDropDownData, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {

        LoginId: "",
        NetName: "",
        RequestorCode: "",
        Operator: "",
        DLNumber: "",
        ThreeCharacterLastName: "",
        Process1: "",
        Code1: "",
        Info1: "",
        Process2: "",
        Code2: "",
        Info2: "",
        Process3: "",
        Code3: "",
        Info3: "",
        CommentNumber: "",
        CommentPurgeDate: "",
        Comment: "",
        PullNoticePurgeDate: "",
        PurgeCode: "",
        Condition: "",
        Reason: "",
        Info: "",
        Destination: "",
        MiscInfo: "",
        DUKResponse: "",
        NextDLNumber: "",
        Error: true
}

class DUKUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            CommentPurgeDate: "",
            PullNoticePurgeDate: "",
            MedExpDate1: "",
            CommentLength: 0,
            MedExpDate2: "",
            MedExpDate3: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }
    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
         const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDUKData(DLInitData.DLNumber);
        }
        else 
        {
            this.props.history.push(`/dlUpdates`);
        }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.DUKInitData !== this.props.dlUpdates.DUKInitData && this.props.dlUpdates.DUKInitData !== undefined) {
                                const Obj = cloneDeep(defaultObj);
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.DUKInitData.ThreeCharacterName;                        
                                this.setState({DUKInitData: this.props.dlUpdates.DUKInitData, Obj: Obj});
                            }
                            
                            if ( prevProps.dlUpdates.saveDUKData !== this.props.dlUpdates.saveDUKData && this.props.dlUpdates.saveDUKData !== undefined) {
                                this.setState({saveDUKData: this.props.dlUpdates.saveDUKData, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                                if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                                {
                                    
                                 sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                    const Obj = cloneDeep(defaultObj);
                                   Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                                    this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                                } 
                            }
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { DUKInitData, saveDUKData, dlUpdatesErrorData, DUKDropDownData } = props.dlUpdates;
                if (DUKInitData && DUKInitData !== prevState.DUKInitData)
                {
                    return { DUKInitData: DUKInitData, isloading: false };
                } 
                if (DUKDropDownData && prevState.Process !== undefined)
{
    const name = 'DUKDropDownData'+prevState.Process;
    
                if( DUKDropDownData !== prevState[name])
                {
                    return { [name]: DUKDropDownData };
                } 
            }
                if (saveDUKData && saveDUKData !== prevState.saveDUKData) return { saveDUKData: saveDUKData, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false };
                return null;
            }
    handleFieldChange(e, field) {
        
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
            case 'CommentNumber':
            case 'Comment':
            case 'Destination':
            case 'MiscInfo':
                Obj[field] = e.target.value;
                if( ['S1','S2','S3','S4','S5','S6','S7','S8','S9'].includes(Obj['CommentNumber'].toUpperCase()) ) {
                    this.setState({CommentLength: 40});
                }
                else
                {
                    this.setState({CommentLength: 85});
                }
                break;
            case 'Reason':
            case 'Process1':
            case 'Process2':
            case 'Process3':
            case 'Info':
            case 'PurgeCode':
            case 'Condition':
            case 'OutOfStateCd':
            case 'Code1':
            case 'Code2':
            case 'Code3':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                if(field === 'Code1')
                {
                    Obj['Info1'] = "";
                    if( e === 'C')
                {
                    Obj['Process1'] = "D";
                }
                if( e === 'N' && Obj['Process1'] === 'D')
                {
                    this.setState({ErrorMessage: 'A - Add & C - Change are the only valid options for this code.', ErrorModalShow: true, stayOnPage: true});
                    Obj['Process1'] = "";
                }
                if(['D', 'F', 'I', 'J', 'K', 'L', 'M', 'P'].includes(e))
                {
                    this.setState({Process: 'Process1'});
                    this.props.getDropDownData(e);
                }
                }
                if(field === 'Code2')
                { 
                    Obj['Info2'] = "";
                     if( e === 'C' || e === 'G')
                {
                    Obj['Process2'] = "D";
                }
                if( e === 'N' && Obj['Process2'] === 'D')
                {
                    this.setState({ErrorMessage: 'A - Add & C - Change are the only valid options for this code.', ErrorModalShow: true, stayOnPage: true});
                    Obj['Process2'] = "";
                }
                if(['D', 'F', 'I', 'J', 'K', 'L', 'M', 'P'].includes(e))
                {
                    this.setState({Process: 'Process2'});
                    this.props.getDropDownData(e);
                }
                }
                if(field === 'Code3')
                {
                    Obj['Info3'] = "";
                    if( e === 'C' || e === 'G')
                    {
                        Obj['Process3'] = "D";
                    }
                    if( e === 'N' && Obj['Process3'] === 'D')
                    {
                        this.setState({ErrorMessage: 'A - Add & C - Change are the only valid options for this code.', ErrorModalShow: true, stayOnPage: true});
                        Obj['Process3'] = "";
                    }
                    if(['D', 'F', 'I', 'J', 'K', 'L', 'M', 'P'].includes(e))
                    {
                        this.setState({Process: 'Process3'});
                        this.props.getDropDownData(e);
                    }
                }
                if(field === 'Process1')
                {
                    if( e === 'D' && Obj['Code1'] === 'N')
                    {
                        this.setState({ErrorMessage: 'A - Add & C - Change are the only valid options for this code.', ErrorModalShow: true, stayOnPage: true});
                        Obj['Process1'] = "";
                    }
                }
                if(field === 'Process2')
                {
                    if( e === 'D' && Obj['Code2'] === 'N')
                    {
                        this.setState({ErrorMessage: 'A - Add & C - Change are the only valid options for this code.', ErrorModalShow: true, stayOnPage: true});
                        Obj['Process2'] = "";
                    }
                }
                if(field === 'Process3')
                {
                    if( e === 'D' && Obj['Code3'] === 'N')
                    {
                        this.setState({ErrorMessage: 'A - Add & C - Change are the only valid options for this code.', ErrorModalShow: true, stayOnPage: true});
                        Obj['Process3'] = "";
                    }
                }
            }
                break;
            case 'Info1':
            case 'Info2':
            case 'Info3':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
            if(e.target !== undefined)
         {  
             if( field === 'Info1' && Obj['Code1'] === 'C' && e.target.value.length <= 2)
             {
                Obj[field] = e.target.value;
             }
             if( field === 'Info2' && Obj['Code2'] === 'C' && e.target.value.length <= 2)
             {
                Obj[field] = e.target.value;
             }
             if( field === 'Info3' && Obj['Code3'] === 'C' && e.target.value.length <= 2)
             {
                Obj[field] = e.target.value;
             }
             if( field === 'Info1' && Obj['Code1'] === 'G' && e.target.value.length <= 7)
             {
                Obj[field] = e.target.value;
             }
             if( field === 'Info2' && Obj['Code2'] === 'G' && e.target.value.length <= 7)
             {
                Obj[field] = e.target.value;
             }
             if( field === 'Info3' && Obj['Code3'] === 'G' && e.target.value.length <= 7)
             {
                Obj[field] = e.target.value;
             }
         }
         else
         {
            Obj[field] = e;
         }
        }
         break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {
        switch(type) {
            case 'CommentPurgeDate':
            this.setState({ CommentPurgeDate: d });
            break;
            case 'PullNoticePurgeDate':
            this.setState({ PullNoticePurgeDate: d });
            break;
            case 'MedExpDate1':
            this.setState({ MedExpDate1: d });
            break;
            case 'MedExpDate2':
            this.setState({ MedExpDate2: d });
            break;
            case 'MedExpDate3':
            this.setState({ MedExpDate3: d });
            break;
            default:
            break;
        }
    }
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
     
        const { Obj, MedExpDate1, MedExpDate2, MedExpDate3 } = this.state;

       if(this.state.MedExpDate1 !== "" && Obj['Code1'] === 'N')
       { 
           Obj['Info1'] = dateFormatFuncDLUpdates(MedExpDate1);
       }
       if(this.state.MedExpDate2 !== "" && Obj['Code2'] === 'N')
       { 
           Obj['Info2'] = dateFormatFuncDLUpdates(MedExpDate2);
       }
       if(this.state.MedExpDate3 !== "" && Obj['Code3'] === 'N')
       { 
           Obj['Info3'] = dateFormatFuncDLUpdates(MedExpDate3);
       }    
        Obj['RequestorCode'] = this.state.DUKInitData.RequestorCode;
        Obj['Operator'] = this.state.DUKInitData.Operator;
        Obj['NetName'] = this.state.DUKInitData.NetName;
        Obj['LoginId'] = this.state.DUKInitData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['CommentPurgeDate'] = dateFormatFuncDLUpdates(this.state.CommentPurgeDate);
        Obj['PullNoticePurgeDate'] =  dateFormatFuncDLUpdates(this.state.PullNoticePurgeDate);       
        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
        this.props.saveDUKData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUKInitData, saveDUKData, isNewDL, isloading } = this.state;

        return (
          
            <React-Fragment>
                 {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
               {saveDUKData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {
                   
                   this.setState({openSuccessModal: false}); 

                   if(saveDUKData.Error === false)
               { 
                if (Obj.NextDLNumber !== '') {
                    this.props.history.push({
                        pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                        state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                    });
                }
                else if (isNewDL !== true) {
                    this.props.history.push({
                        pathname: `/dlUpdates`,
                        state: { dlNumber: saveDUKData.DLNumber }
                    })
                }
                else {
                    this.setState({
                        Obj: cloneDeep(defaultObj),                        
                        CommentPurgeDate: "",
            PullNoticePurgeDate: "",
            MedExpDate1: "",
            CommentLength: 0,
            MedExpDate2: "",
            DLNumber: '',
            MedExpDate3: "",
                        ErrorObj: {},
                        ErrorMessage: '',
                        ErrorModalShow: false
                    });
                }        
}}
               }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: saveDUKData.DUKResponse.toString()}}/>
          </div></Modal>}
            {DUKInitData ?   
             <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Miscellaneous Driver Record Update (DUK)</div>
                <Form className="ant-advanced-search-form">
                {isNewDL ? <Row>
                        <Col span={6} style={{ display: 'block' }}>
                            <FormItem
                              hasFeedback
                              validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                              help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                label={<b>DL # </b>}
                            >
                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                label={<b>3 Pos Last Name </b>}
                            >
                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                            </FormItem>
                        </Col>
                    </Row>:
               <Row>
                               <Col span={5}>
                               <FormItem
                                label={<b>DL #</b>}
                            >
                                   {this.state.DLNumber}
                                   </FormItem>
                               </Col>
                               <Col span={5} offset={1}>
                               <FormItem
                                label={<b>3 Pos Last Name</b>}
                            >
                                {this.state.ThreeCharacterName}
                                </FormItem>
                               </Col>
                           </Row>
               }
                  <Row>
                        <Col>
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Process 1</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                <Col span={4} > 
                                        <FormItem 
                                             validateStatus = {Obj.Process1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Process1"] ? 'error' : ""}
                                             help = {Obj.Process1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Process1"]}
                                             label={<b>A/C/D </b>}>
                                            <Select allowClear = {true} id = "SPro1" onFocus={(e) => {
                                document.getElementById("SPro1").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Process1')}
                                                value={Obj.Process1} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Process1.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Code1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Code1"] ? 'error' : ""}
                                             help = {Obj.Code1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Code1"]}
                                             label={<b>Code </b>}>
                                            <Select allowClear = {true} id = "SC1" onFocus={(e) => {
                                document.getElementById("SC1").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Code1')}
                                                value={Obj.Code1} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Code1.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Info1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info1"] ? 'error' : ""}
                                             help = {Obj.Info1 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info1"]}
                                             label={<b>Info </b>}>
                                         {Obj.Code1 !== '' && <div> {( Obj.Code1 !== 'C' && Obj.Code1 !== 'G' && Obj.Code1 !== 'N') ? <Select allowClear = {true} id = "SLoc" onFocus={(e) => {
                                document.getElementById("SLoc").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Info1')}
                                                value={Obj.Info1} showArrow={true} size={"default"}
                                            >
                                               { this.state.DUKDropDownDataProcess1 && this.state.DUKDropDownDataProcess1.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>: Obj.Code1 !== 'N' ?  <Input value={Obj.Info1} placeholder="Enter Info" onChange={e => this.handleFieldChange(e, 'Info1')} />:
                                           <DatePicker
                                           className = "CalClass"
                                           selected={this.state.MedExpDate1}
                                           dateFormat={"MM-dd-yyyy"}
                                           onChange={(d) => this.onDateChange(d, 'MedExpDate1')}
                                           isClearable={true}
                                           placeholderText="Select a date"
                                         />
         } </div>}
                                        </FormItem>
                                    </Col>
                                </Row>
                                </div>
                                </Col>
                                </Row>
                                <Row>
                        <Col >
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Process 2</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                <Col span={4} >
                                        <FormItem
                                             validateStatus = {Obj.Process2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Process2"] ? 'error' : ""}
                                             help = {Obj.Process2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Process2"]}
                                             label={<b>A/C/D </b>}>
                                            <Select allowClear = {true} id = "SPro2" onFocus={(e) => {
                                document.getElementById("SPro2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Process2')}
                                                value={Obj.Process2} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Process2.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Code2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Code2"] ? 'error' : ""}
                                             help = {Obj.Code2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Code2"]}
                                             label={<b>Code </b>}>
 <Select allowClear = {true} id = "SC2" onFocus={(e) => {
                                document.getElementById("SC2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Code2')}
                                                value={Obj.Code2} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Code2.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Info2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info2"] ? 'error' : ""}
                                             help = {Obj.Info2 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info2"]}
                                             label={<b>Info </b>}>
                                                      {Obj.Code2 !== '' && <div> {( Obj.Code2 !== 'C' && Obj.Code2 !== 'G' && Obj.Code2 !== 'N') ?    <Select allowClear = {true} id = "SInf" onFocus={(e) => {
                                document.getElementById("SInf").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Info2')}
                                                value={Obj.Info2} showArrow={true} size={"default"}
                                            >
                                               {
                                                   this.state.DUKDropDownDataProcess2 && this.state.DUKDropDownDataProcess2.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>: Obj.Code2 !== 'N' ?  <Input value={Obj.Info2} placeholder="Enter Info" onChange={e => this.handleFieldChange(e, 'Info2')} />:
                                 <DatePicker
                                 className = "CalClass"
                                 selected={this.state.MedExpDate2}
                                 dateFormat={"MM-dd-yyyy"}
                                 onChange={(d) => this.onDateChange(d, 'MedExpDate2')}
                                 isClearable={true}
                                 placeholderText="Select a date"
                               />
        } </div>}
                                        </FormItem>
                                    </Col>
                                </Row>
                                </div>
                                </Col>
                                </Row>
                                <Row>
                        <Col >
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Process 3</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                <Col span={4} >
                                        <FormItem 
                                             validateStatus = {Obj.Process3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Process3"] ? 'error' : ""}
                                             help = {Obj.Process3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Process3"]}
                                             label={<b>A/C/D </b>}>
                                            <Select allowClear = {true} id = "SPro3" onFocus={(e) => {
                                document.getElementById("SPro3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Process3')}
                                                value={Obj.Process3} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Process3.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Code3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Code3"] ? 'error' : ""}
                                             help = {Obj.Code3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Code3"]}
                                             label={<b>Code </b>}>
                                            <Select allowClear = {true} id = "SLoc" onFocus={(e) => {
                                document.getElementById("SLoc").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Code3')}
                                                value={Obj.Code3} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Code3.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Info3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info3"] ? 'error' : ""}
                                             help = {Obj.Info3 === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info3"]}
                                             label={<b>Info </b>}>
                                             {Obj.Code3 !== '' && <div> {( Obj.Code3 !== 'C' && Obj.Code3 !== 'G' && Obj.Code3 !== 'N') ?  <Select allowClear = {true} id = "SInf3" onFocus={(e) => {
                                document.getElementById("SInf3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Info3')}
                                                value={Obj.Info3} showArrow={true} size={"default"}
                                            >
                                               {
                                                   this.state.DUKDropDownDataProcess3 && this.state.DUKDropDownDataProcess3.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>: Obj.Code3 !== 'N' ?  <Input value={Obj.Info2} placeholder="Enter Info" onChange={e => this.handleFieldChange(e, 'Info3')} />:
                               <DatePicker
                               className = "CalClass"
                               selected={this.state.MedExpDate3}
                               dateFormat={"MM-dd-yyyy"}
                               onChange={(d) => this.onDateChange(d, 'MedExpDate3')}
                               isClearable={true}
                               placeholderText="Select a date"
                             />
        } </div>}
                                        </FormItem>
                                    </Col>
                                </Row>
                                </div>
                                </Col>
                                </Row>
                                <Row>
                        <Col>
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Add Comment</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                <Col span={4} >
                                        <FormItem 
                                             validateStatus = {Obj.CommentNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommentNumber"] ? 'error' : ""}
                                             help = {Obj.CommentNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommentNumber"]}
                                             label={<b>Comment # </b>}>
                                            <Input placeholder="Comment #" maxLength = {this.state.CommentLength !== 0 ? this.state.CommentLength : null} value={Obj.CommentNumber}
                                                onChange={e => this.handleFieldChange(e, 'CommentNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.CommentPurgeDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommentPurgeDate"] ? 'error' : ""}
                                             help = {Obj.CommentPurgeDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommentPurgeDate"]}
                                             label={<b>Purge Date (MM-YY) </b>}>
 <DatePicker
                       className = "CalClass"
                       selected={this.state.CommentPurgeDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'CommentPurgeDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /></FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem 
                                             label=""> {this.state.CommentLength - Obj.Comment.length} of {this.state.CommentLength} Characters left
                                        </FormItem>
                                    </Col>
                                    </Row>
                                    <Row>
                                    <Col>
                                        <FormItem 
                                             validateStatus = {Obj.Comment === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Comment"] ? 'error' : ""}
                                             help = {Obj.Comment === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Comment"]}
                                             label={<b>Comment </b>}>
 <Input placeholder="Comment " value={Obj.Comment}
                                                onChange={e => this.handleFieldChange(e, 'Comment')} />
                                        </FormItem>
                                    </Col>
                                </Row>
                                </div>
                                </Col>
                                </Row>
                                <Row>
                        <Col >
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Add Pull Notice</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                <Col span={4} >
                                        <FormItem style={{display: 'block'}}
                                             validateStatus = {Obj.PullNoticePurgeDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["PullNoticePurgeDate"] ? 'error' : ""}
                                             help = {Obj.PullNoticePurgeDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["PullNoticePurgeDate"]}
                                             label={<b>Purge Date (MM-YY) </b>}>
 <DatePicker
                       className = "CalClass"
                       selected={this.state.PullNoticePurgeDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'PullNoticePurgeDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                                    </Col>
                                <Col span={6} >
                                        <FormItem style={{display: 'block'}}
                                             validateStatus = {Obj.PurgeCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["PurgeCode"] ? 'error' : ""}
                                             help = {Obj.PurgeCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["PurgeCode"]}
                                             label={<b>Purge Code </b>}>
                                            <Select allowClear = {true} id = "SPC" onFocus={(e) => {
                                document.getElementById("SPC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'PurgeCode')}
                                                value={Obj.PurgeCode} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.PurgeCode.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6}>
                                        <FormItem style={{display: 'block'}}
                                             validateStatus = {Obj.Condition === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Condition"] ? 'error' : ""}
                                             help = {Obj.Condition === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Condition"]}
                                             label={<b>Condition </b>}>
                                            <Select allowClear = {true} id = "SCon" onFocus={(e) => {
                                document.getElementById("SCon").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Condition')}
                                                value={Obj.Condition} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Condition.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6}>
                                        <FormItem style={{display: 'block'}}
                                             validateStatus = {Obj.Reason === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Reason"] ? 'error' : ""}
                                             help = {Obj.Reason === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Reason"]}
                                             label={<b>Reason </b>}>
                                            <Select allowClear = {true} id = "SReas1" onFocus={(e) => {
                                document.getElementById("SReas1").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'Reason')}
                                                value={Obj.Reason} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Reason.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                <Col span={4}>
                                        <FormItem
                                             validateStatus = {Obj.Info === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info"] ? 'error' : ""}
                                             help = {Obj.Info === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Info"]}
                                             label={<b>Info </b>}>
                                            <Select allowClear = {true} id = "SInfor" onFocus={(e) => {
                                document.getElementById("SInfor").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'Info')}
                                                value={Obj.Info} showArrow={true} size={"default"}
                                            >
                                               {DUKInitData.Info.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.Destination === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Destination"] ? 'error' : ""}
                                             help = {Obj.Destination === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Destination"]}
                                             label={<b>Destination </b>}>
                             <Input placeholder="" value={Obj.Destination}
                                                onChange={e => this.handleFieldChange(e, 'Destination')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem 
                                             label={""}>
                                        {69 - Obj.MiscInfo.length} of 69 Characters left
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                <Col >
                                        <FormItem 
                                             validateStatus = {Obj.MiscInfo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MiscInfo"] ? 'error' : ""}
                                             help = {Obj.MiscInfo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MiscInfo"]}
                                             label={<b>Misc Info </b>}>
 <Input maxLength={69} placeholder="Misc Info " value={Obj.MiscInfo}
                                                onChange={e => this.handleFieldChange(e, 'MiscInfo')} />
                                        </FormItem>
                                    </Col>
                                    </Row>
                                    </div>
                                    </Col>
                                    </Row>
                                    <Row>
                                        <br/>
                                    <Col span={18}>
                                        <FormItem
                                             validateStatus = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                             help = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{width: '20%'}} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                    {Obj.NextDLNumber !== '' ? <Button disabled
                                       type="default">New DL</Button>: <Button style={{ color: "white", backgroundColor: "green" }}
                                        type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) =>
                                                {
                                                this.props.history.push({ pathname: `/dlUpdates`,
                                            state: {dlNumber: this.state.DLNumber}})
                                                }
                                        }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form></div>  : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                            <Modal visible={this.state.ErrorModalShow}
                                title={'Error message'} maskClosable={false}
                                footer={[
                                    <div>
                                        <Button type="primary" key="Ok" onClick={(e) => 
                                        {
                                            this.setState({ErrorModalShow: false});
                                            if( !this.state.ErrorObj )
                                            {  if(isNewDL === true)
                                            {
                                                this.setState({Obj: cloneDeep(defaultObj),
                                                    CommentPurgeDate: "",
            PullNoticePurgeDate: "",
            MedExpDate1: "",
            CommentLength: 0,
            MedExpDate2: "",
            MedExpDate3: "",
            DLNumber: "",
                                                    ErrorObj: {},
                                                    ErrorMessage: '',
                                                    ErrorModalShow: false
                                                });
                                            }
                                            else if(Obj.NextDLNumber !== '')
                                            {
                                                this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                                state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                            }  
                                             else
                                    {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                } }}>Ok</Button>
                                    </div>
                                ]}
                            >
                                {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                            </Modal>
                            </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                        </React-Fragment>
                        );
                }
            }
                
            const mapStateToProps = state => {
                return {
                  dlUpdates: state.dlUpdates
                };
            };
            
            const mapDispatchToProps = dispatch => {
                return bindActionCreators(
                    {
                        getDUKData, saveDUKData, getDropDownData, getDLInitialData
                    },
                    dispatch
                );
            };
            
            export default connect(mapStateToProps, mapDispatchToProps)(DUKUpdate); 
