import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Modal, Spin } from 'antd';
import { dateFormatFunc, checkIfBeforeGivenDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { 
    getME3Data, 
    saveME3Data, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import cloneDeep from 'lodash/cloneDeep';
import { connect } from "react-redux";
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    Status: '',
    StatusMessage: '',
    MedCertIssueDate: '',
    MedCertExpireDate: '',
    ExaminerLicense: '',
    ExaminerState: '',
    WaiverType: '',
    WaiverEffectiveDate: '',
    WaiverExpirationDate: '',
    WaiverRescindDate: '',
    SPEEffectiveDate: '',
    SPEExpirationDate: '',
    SPECancelDate: '',
    ME3Response: '',
    NextTran: '',
    Error: true
}

class ME3Update extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            WaiverEffectiveDate: "", 
            WaiverExpirationDate: "", 
            WaiverRescindDate: "", 
            SPEEffectiveDate: "", 
            SPEExpirationDate: "", 
            ErrorObj: {},
            SPECancelDate: "",
            ExistingExemption: false,
            WEDateEarlier: false,
            ErrorMessage: '',
            ErrorModalShow: false
        }

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this); 
    }   

        componentDidMount(){
            if(sessionStorage.getItem('dlInitData')){
                const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
                   this.setState({
                       DLNumber: DLInitData.DLNumber,
                       ThreeCharacterName: DLInitData.ThreeCharacterName,
                       BirthDate: DLInitData.Birthdate
                   });
                   this.props.getME3Data(DLInitData.DLNumber, DLInitData.ThreeCharacterName);
               }
                    }
                
        componentDidUpdate(prevProps){
            
                    if ( prevProps.dlUpdates.ME3InitData !== this.props.dlUpdates.ME3InitData && this.props.dlUpdates.ME3InitData !== undefined) {
                        const Obj =  cloneDeep(this.props.dlUpdates.ME3InitData);
                        Obj['NextTran'] = '';
                        Obj['ThreeCharacterName'] = this.props.dlUpdates.ME3InitData.ThreeCharacterName;
                        Obj['BirthDate'] = this.props.dlUpdates.ME3InitData.BirthDate;
                        if(this.props.dlUpdates.ME3InitData.WaiverType !== '' && this.props.dlUpdates.ME3InitData.WaiverType !== null && this.props.dlUpdates.ME3InitData.WaiverEffectiveDate !== '' && this.props.dlUpdates.ME3InitData.WaiverEffectiveDate !== null)
                        {
                            if (checkIfBeforeGivenDate(this.props.dlUpdates.ME3InitData.WaiverEffectiveDate)) {
                                this.setState({ WEDateEarlier: true});
                            }    
      
                                this.setState({ ExistingExemption: true});
                        }
                        if(this.props.dlUpdates.ME3InitData.SPEEffectiveDate !== '' && this.props.dlUpdates.ME3InitData.SPEEffectiveDate !== null && this.props.dlUpdates.ME3InitData.SPEExpirationDate !== '' && this.props.dlUpdates.ME3InitData.SPEExpirationDate !== null)
                        {
                            this.setState({ ExistingSPE: true});
                        }
                        this.setState({ME3InitData: this.props.dlUpdates.ME3InitData, Obj: Obj, MedCertExpireDate: this.props.dlUpdates.ME3InitData.MedCertExpireDate, MedCertIssueDate: this.props.dlUpdates.ME3InitData.MedCertIssueDate,
                        ExaminerLicense: this.props.dlUpdates.ME3InitData.ExaminerLicense, ExaminerState: this.props.dlUpdates.ME3InitData.ExaminerState});
                    }
                    if ( prevProps.dlUpdates.saveME3Data !== this.props.dlUpdates.saveME3Data && this.props.dlUpdates.saveME3Data !== undefined) {
                        this.setState({saveME3Data: this.props.dlUpdates.saveME3Data, openSuccessModal: true});
                    }
                    if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                        if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                        {
                            this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                        }
                        else{
                            let Errors = [];
                            Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                                Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                return "";
                            })
                            this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                        }
                       
                    }
                    if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                    {
                        
                     sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                        const Obj = cloneDeep(defaultObj);
                       Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                       Obj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
                        this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                    } 
}

        static getDerivedStateFromProps(props, prevState) {
            const { ME3InitData, saveME3Data, dlUpdatesErrorData } = props.dlUpdates;
            if (ME3InitData && ME3InitData !== prevState.ME3InitData)
            {
                const Obj =  cloneDeep(ME3InitData);
                Obj['NextTran'] = '';
                if(ME3InitData.WaiverType !== '' && ME3InitData.WaiverType !== null && ME3InitData.WaiverEffectiveDate !== '' && ME3InitData.WaiverEffectiveDate !== null)
                {
                    if (checkIfBeforeGivenDate(ME3InitData.WaiverEffectiveDate)) {
                        return { WEDateEarlier: true, ExistingExemption: true, ME3InitData: ME3InitData, MedCertExpireDate: ME3InitData.MedCertExpireDate, MedCertIssueDate: ME3InitData.MedCertIssueDate, ExaminerLicense: ME3InitData.ExaminerLicense, ExaminerState: ME3InitData.ExaminerState, Obj: Obj, isloading: false };
                    }    
                    else
                    {
                        return { ExistingExemption: true, ME3InitData: ME3InitData, Obj: Obj, isloading: false };
                    }
                }
                if(ME3InitData.SPEEffectiveDate !== '' && ME3InitData.SPEEffectiveDate !== null && ME3InitData.SPEExpirationDate !== '' && ME3InitData.SPEExpirationDate !== null)
                {
                    return { ExistingSPE: true, ME3InitData: ME3InitData, Obj: Obj, isloading: false };
                    
                }
                return { ME3InitData: ME3InitData, Obj: Obj, isloading: false };
        }
            if (saveME3Data && saveME3Data !== prevState.saveME3Data) return { saveME3Data: saveME3Data, isloading: false };
            if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false};
            return null;
        }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'ExaminerLicense':
                if (e.target.value.length <= 14) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'ExaminerState':
            case 'WaiverType':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
                case 'ThreeCharacterName':
                case 'NextTran':
                    Obj[field] = e.target.value;
                break;
                case 'DLNumber':
                this.setState({DLNumber: e.target.value});
                Obj[field] = e.target.value;
                    if ((Obj['DLNumber'].length === 8)) {
                          this.props.getDLInitialData(Obj['DLNumber']);
                          this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                    }
                    break;
            default:
                break;
        }

        this.setState({ Obj });
    }
  
    onDateChange(d, type) {

        switch(type) {
            case 'WaiverEffectiveDate':
            this.setState({ WaiverEffectiveDate: d });
            
            if(checkIfBeforeGivenDate(d))
            {
                this.setState({WEDateEarlier: true});
            }
            break;
            case 'WaiverExpirationDate':
            this.setState({ WaiverExpirationDate: d });
            break;
            case 'BirthDate':
            this.setState({ BirthDate: d });
            break;
            case 'WaiverRescindDate':
            this.setState({ WaiverRescindDate: d });
            break;
            case 'SPEEffectiveDate':
            this.setState({ SPEEffectiveDate: d });
            break;
            case 'SPEExpirationDate':
            this.setState({ SPEExpirationDate: d });
            break;
            case 'SPECancelDate':
            this.setState({ SPECancelDate: d });
            break;
            default:
            break;
        }
        }
   
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }


    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
            const {Obj} = this.state;
            Obj['ThreeCharacterLastName'] = Obj['ThreeCharacterName'];
            if(typeof this.state.BirthDate === 'string')
            {
                Obj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
            }
          else
          {
            Obj['BirthDate'] = dateFormatFunc(this.state.BirthDate);
          }
          Obj['WaiverEffectiveDate'] = dateFormatFunc(this.state.WaiverEffectiveDate);
          Obj['WaiverExpirationDate'] = dateFormatFunc(this.state.WaiverExpirationDate);
          Obj['WaiverRescindDate'] = dateFormatFunc(this.state.WaiverRescindDate);
          Obj['SPEEffectiveDate'] = dateFormatFunc(this.state.SPEEffectiveDate);
          Obj['SPEExpirationDate'] = dateFormatFunc(this.state.SPEExpirationDate);
          Obj['SPECancelDate'] = dateFormatFunc(this.state.SPECancelDate);

            this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
  this.props.saveME3Data(Obj);
    }
    
    render() {
        const { Obj, ME3InitData, saveME3Data, isloading, isNewDL, MedCertIssueDate, MedCertExpireDate, ExaminerLicense, ExaminerState } = this.state;
        return (
            // <ScrollPanel style={{ width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0)" }}>
            <React-Fragment>
              {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
            {saveME3Data && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false}); 
           if(saveME3Data.Error === false)
           { if(Obj.NextTran !== null && Obj.NextTran !== '')
           {
               this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
               state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
           } else if(isNewDL !== true ) {
            this.props.history.push({ pathname: `/dlUpdates`,
     state: {dlNumber: saveME3Data.DLNumber}})}
   else
     {
         this.setState({ Obj: cloneDeep(defaultObj),    
            DLNumber: '',      
            BirthDate: '',  
            MedCertIssueDate: "",
            MedCertExpireDate: "",
            ExaminerLicense: "",
            ExaminerState: "",
            WaiverEffectiveDate: "", 
            WaiverExpirationDate: "", 
            WaiverRescindDate: "", 
            SPEEffectiveDate: "", 
            SPEExpirationDate: "", 
            SPECancelDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
         });
     }
        }}
    }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: saveME3Data.ME3Response.toString()}}/>
         
         </div></Modal>}
         {ME3InitData ?   
           ME3InitData.Message !== null ? <Modal title={"ME3 Message"} visible={true} onCancel={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
           state: {dlNumber: ME3InitData.DLNumber}})}} footer={[<Button type="primary" key="Ok" onClick={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
           state: {dlNumber: ME3InitData.DLNumber}})}}>OK</Button>]}><div>{ME3InitData.Message}</div></Modal> :
           <div><div style={{
            border: '1px solid black',
            paddingLeft: "1%",
            textAlign: 'center',
            backgroundColor: '#c9e3fa',
            fontSize: '32px'
            }} >Waiver/Exemption or SPE (ME3)</div><Form className="ant-advanced-search-form">
              {isNewDL ? <Row>
                    <Col span={5} style={{ display: 'block' }}>
                        <FormItem
                          hasFeedback
                          validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                          help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                            label={<b>DL # </b>}

                        >
                            <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                        </FormItem>
                    </Col>
                    <Col span={5} offset={1}>
                        <FormItem
                            label={<b>3 Pos Last Name </b>}
                        >
                            <Input value={Obj.ThreeCharacterName} maxLength={3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                        </FormItem>
                    </Col>
                    <Col span={5} offset={1} style={{ height: '39px' }} >
                        <span style={{ color: 'blue', fontWeight: 'bold', verticalAlign: 'middle' }}>
                            {ME3InitData.StatusMessage}
                        </span>
                    </Col>
                </Row> :
                <Row>
                                <Col span={5}>
                                    <b>DL Number</b>:{" "}{this.state.DLNumber}
                                </Col>
                                <Col span={1} />
                                <Col span={5}>
                                    <b>3 Pos Last Name</b>:{" "}{this.state.ThreeCharacterName}
                                </Col>
                                <Col span={5} offset={1} style={{ height: '39px' }} >
                        <span style={{ color: 'blue', fontWeight: 'bold', verticalAlign: 'middle' }}>
                            {ME3InitData.StatusMessage}
                        </span>
                    </Col>
                            </Row>}
                <br />
                <Row>
                    <Col span={9}>
                        <FormItem
                           validateStatus = {MedCertIssueDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertIssueDate"] ? 'error' : ""}
                           help = {MedCertIssueDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertIssueDate"]}
                            label={<b>Date of Exam/Med Cert Issue Date  </b>}
                        >
                                                    <Input size={"small"} value={MedCertIssueDate !== "" ? MedCertIssueDate : null}
                                onChange={e => this.handleFieldChange(e, 'MedCertIssueDate')}
                                disabled
                            />
                        </FormItem>
                    </Col>
                    <Col span={7} offset={1}>
                        <FormItem
                         validateStatus = {MedCertExpireDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertExpireDate"] ? 'error' : ""}
                         help = {MedCertExpireDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertExpireDate"]}
                            label={<b>Med Cert Exp Date  </b>}
                        >
                                                        <Input size={"small"}  value={MedCertExpireDate !== "" ? MedCertExpireDate : null}
                                onChange={e => this.handleFieldChange(e, 'MedCertExpireDate')}
                                disabled
                            />
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={7}>
                        <FormItem
                         validateStatus = {ExaminerLicense === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLicense"] ? 'error' : ""}
                         help = {ExaminerLicense === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLicense"]}
                            label={<b>Examiner License #  </b>}
                        >
                            <Input size={"small"}  value={ExaminerLicense} placeholder="Examiner License #"
                                onChange={e => this.handleFieldChange(e, 'ExaminerLicense')}
                                disabled
                            />
                        </FormItem>
                    </Col>
                    <Col span={7} offset={1}>
                        <FormItem
                            label={<b>State of Issue  </b>}
                        >
                             <Input size={"small"}  value={ExaminerState} placeholder="Examiner State"
                                onChange={e => this.handleFieldChange(e, 'ExaminerState')}
                                disabled
                            />
                        </FormItem>
                    </Col>
                </Row>
                <span style={{ color: 'blue', fontWeight: 'bold', verticalAlign: 'middle', fontSize: '1.2em' }}>
                    ENTER WAIVER / EXEMPTION OR SPE DATA
                </span>
                <Row>
                <Col style={{width: '75%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                    <Row>
                        <Col>
                            <h3>Waiver / Exemption</h3>
                            <hr />
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8}>
                            <FormItem
                                label={<b>Type </b>}
                            >
                                <Select allowClear = {true} id = "STYP" onFocus={(e) => {
                                document.getElementById("STYP").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} disabled={this.state.ExistingExemption && this.state.WEDateEarlier} size={"small"} onChange={e => this.handleFieldChange(e, 'WaiverType')}
                                    value={Obj.WaiverType} showArrow={true}
                                >
                                    {ME3InitData.WaiverTypeSelect.map(item => <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>)}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8}>
                            <FormItem
                             validateStatus = {this.state.WaiverEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverEffectiveDate"] ? 'error' : ""}
                             help = {this.state.WaiverEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverEffectiveDate"]}
                                label={<b>Effective Date </b>}
                            >
                                <DatePicker
                                disabled={this.state.ExistingExemption && this.state.WEDateEarlier}
                       className = "CalClass"
                       selected={this.state.WaiverEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'WaiverEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                             validateStatus = {this.state.WaiverExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverExpirationDate"] ? 'error' : ""}
                             help = {this.state.WaiverExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverExpirationDate"]}
                                label={<b>Expiration Date </b>}
                            >
                                <DatePicker
                                disabled={this.state.ExistingExemption || this.state.WEDateEarlier}
                       className = "CalClass"
                       selected={this.state.WaiverExpirationDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'WaiverExpirationDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                             validateStatus = {this.state.WaiverRescindDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverRescindDate"] ? 'error' : ""}
                             help = {this.state.WaiverRescindDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverRescindDate"]}
                                label={<b>Rescind Date </b>}
                            >
                                 <DatePicker
                                  disabled = {!this.state.ExistingExemption || this.state.WEDateEarlier}
                       className = "CalClass"
                       selected={this.state.WaiverRescindDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'WaiverRescindDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>
                </Col>
                {this.state.ExistingExemption && <Col span = {4} style={{marginTop: '5%'}}><b>Can only enter a rescind date on existing exemption.</b></Col>}
                </Row>
              <Row>  <Col span={14} style={{width: '75%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                    <Row>
                        <Col>
                            <h3>Skill Performance Evaluation (SPE)</h3>
                            <hr/>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8} offset={3}>
                            <FormItem
                             validateStatus = {this.state.SPEEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEEffectiveDate"] ? 'error' : ""}
                             help = {this.state.SPEEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEEffectiveDate"]}
                                label={<b>SPE Effective Date </b>}
                            >
                                <DatePicker
                                 disabled={this.state.ExistingExemption || this.state.WEDateEarlier}
                       className = "CalClass"
                       selected={this.state.SPEEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'SPEEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8} offset={3}>
                            <FormItem
                             validateStatus = {this.state.SPEExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEExpirationDate"] ? 'error' : ""}
                             help = {this.state.SPEExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEExpirationDate"]}
                                label={<b>SPE Expiration Date </b>}
                            >
                               <DatePicker
                                 disabled={this.state.ExistingExemption || this.state.WEDateEarlier}
                       className = "CalClass"
                       selected={this.state.SPEExpirationDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'SPEExpirationDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={8} offset={3}>
                            <FormItem
                             validateStatus = {this.state.SPECancelDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPECancelDate"] ? 'error' : ""}
                             help = {this.state.SPECancelDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPECancelDate"]}
                                label={<b>SPE Cancel Date </b>}
                            >
                              <DatePicker
                                 disabled={this.state.WEDateEarlier ? this.state.WEDateEarlier : true}
                       className = "CalClass"
                       selected={this.state.SPECancelDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'SPECancelDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>
                </Col>{this.state.ExistingSPE && <Col span = {4} style={{marginTop: '5%'}}><b>Can only enter a cancel date on an existing SPE.</b></Col>}
                {this.state.WEDateEarlier && <Col span = {4} style={{marginTop: '5%'}}><b>SPE not allowed when adding a 49 CFR 391.64 waiver.</b></Col>}
                </Row>
                <br/>
                <Row>
                    <Col span={8}>
                        <FormItem
                            label={<b>Next Trans </b>}
                        >
                            <Input value={Obj.NextTran} maxLength = {3} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextTran')} />
                        </FormItem>
                    </Col>
                    <Col span={13} style={{ float: 'right' }}>
                    {Obj.NextTran !== '' ? <Button disabled
                           type="default">New DL</Button>:  <Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                        <Button style={{ color: "white", backgroundColor: "red" }}
                            type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                            state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                    </Col>
                </Row>
            </Form></div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                                {
                                    this.setState({ErrorModalShow: false});
                                    if( !this.state.ErrorObj )
                                    {
                                    if(isNewDL === true)
                                    {
                                        this.setState({ Obj: cloneDeep(defaultObj),                                            
                                           MedCertIssueDate: "",
                                           DLNumber: '',
                                           BirthDate: "",
                                           MedCertExpireDate: "",
                                           ExaminerLicense: "",
                                           ExaminerState: "",
                                           WaiverEffectiveDate: "", 
                                           WaiverExpirationDate: "", 
                                           WaiverRescindDate: "", 
                                           SPEEffectiveDate: "", 
                                           SPEExpirationDate: "", 
                                           SPECancelDate: "",
                                           ErrorObj: {},
                                           ErrorMessage: '',
                                           ErrorModalShow: false
                                        });
                                    }
                                    else if(Obj.NextTran !== null && Obj.NextTran !== '')
                                    {
                                        this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                        state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                    }     
                                    else {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }
                                }}>Ok</Button>
                        </div>
                    ]}
                >
                   {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            {/* </ScrollPanel> */}
            </React-Fragment>
        );
    }

}

const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getME3Data, 
    saveME3Data, getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ME3Update); 