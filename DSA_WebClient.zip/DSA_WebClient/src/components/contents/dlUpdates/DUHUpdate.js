import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDUHData, saveDUHData
    , getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    ServiceDate: '',
    ServiceCode: '',
    OriginalEffectiveDate: '',
    LicenseLocation: '',
    TypeInput: '',
    ViolationDate: '',
    TestDate: '',
    DUHResponse: '',
    NextDLNumber: '',
    Error: true,
};

class DUHUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.DLNumber,
            Obj: cloneDeep(defaultObj),
            isNewDL: false,
            OriginalEffectiveDate: "",
            ServiceDate: "",
            ViolationDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }

    componentDidMount() {
        if (sessionStorage.getItem('dlInitData')) {
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            
            this.props.getDUHData(DLInitData.DLNumber);
        }
        else {
            this.props.history.push(`/dlUpdates`);
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DUHInitData !== this.props.dlUpdates.DUHInitData && this.props.dlUpdates.DUHInitData !== undefined) {
            const Obj = cloneDeep(defaultObj);
            Obj['ThreeCharacterName'] = this.props.dlUpdates.DUHInitData.ThreeCharacterName;
            this.setState({DUHInitData: this.props.dlUpdates.DUHInitData, Obj: Obj});
        }
        if (prevProps.dlUpdates.saveDUHData !== this.props.dlUpdates.saveDUHData && this.props.dlUpdates.saveDUHData !== undefined) {
            this.setState({ saveDUHData: this.props.dlUpdates.saveDUHData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
           
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
            }
            else{
                let Errors = [];
                Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                    Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }
           
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isloading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DUHInitData, saveDUHData, dlUpdatesErrorData } = props.dlUpdates;
        if (DUHInitData && DUHInitData !== prevState.DUHInitData) {
            return { DUHInitData: DUHInitData, isloading: false };
        }
        if (saveDUHData && saveDUHData !== prevState.saveDUHData)
            return {
                saveDUHData: saveDUHData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
            case 'TypeInput':
            case 'ServiceCode':
            case 'LicenseLocation':
            if(!e)
            {
                Obj[field] = '';
            }
            else
            {
                Obj[field] = e;
            }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {
        
        switch (type) {
            case 'ServiceDate':
                this.setState({ ServiceDate: d });
                break;
            case 'OriginalEffectiveDate':
                this.setState({ OriginalEffectiveDate: d });
                break;
            case 'ViolationDate':
                this.setState({ ViolationDate: d });
                break;
            default:
                break;
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
        const { Obj } = this.state;

        Obj['Operator'] = this.state.DUHInitData.Operator;
        Obj['NetName'] = this.state.DUHInitData.NetName;
        Obj['RequestorCode'] = this.state.DUHInitData.RequestorCode;
        Obj['LoginId'] = this.state.DUHInitData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
Obj['ServiceDate'] = dateFormatFuncDLUpdates(this.state.ServiceDate);
Obj['OriginalEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OriginalEffectiveDate);
Obj['ViolationDate'] = dateFormatFuncDLUpdates(this.state.ViolationDate);
        this.setState({ isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL });
       this.props.saveDUHData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUHInitData, saveDUHData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {saveDUHData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDUHData.Error === false)
               {  if(Obj.NextDLNumber !== '')
               {
                   this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                   state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
               }   
               else if (isNewDL !== true) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDUHData.DLNumber }
                                    })
                                }
                               else {
                                  
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                        ServiceDate: "",
                                        DLNumber: '',
                                        OriginalEffectiveDate: "",
                                        ViolationDate: "",
                                        ErrorObj: {},
                                        PhoneNumber: "",
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                }
                            }}
                        }>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDUHData.DUHResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DUHInitData ?
                          <div><div style={{
                            border: '1px solid black',
                            paddingLeft: "1%",
                            textAlign: 'center',
                           // fontSize: '20px',
                            backgroundColor: '#c9e3fa',
                            fontSize: '32px'
                            }} >Service Code / License Location (DUH)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={6} style={{ display: 'block' }}>
                                            <FormItem
                                             hasFeedback
                                             validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                             help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={6} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={6}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={6} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }
                                <Row>
                                    <Col span={6}>
                                        <FormItem
                                            validateStatus={this.state.ServiceDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ServiceDate"] ? 'error' : ""}
                                            help={this.state.ServiceDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ServiceDate"]}
                                            label={<b>Service Date </b>}
                                        >
                                        
                                    <DatePicker
                       className = "CalClass"
                       selected={this.state.ServiceDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ServiceDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={12} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.ServiceCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection"] ? 'error' : ""}
                                            help={Obj.ServiceCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ServiceCode"]}
                                            label={<b>Service Code </b>}
                                        >
                                            <Select allowClear = {true} id = "SSerC" onFocus={(e) => {
                                document.getElementById("SSerC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'ServiceCode')}
                                                value={Obj.ServiceCode} showArrow={true} size={"default"}
                                            >
                                                {DUHInitData.ServiceCodes.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={6}>
                                        <FormItem
                                            validateStatus={this.state.OriginalEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalEffectiveDate"] ? 'error' : ""}
                                            help={this.state.OriginalEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalEffectiveDate"]}
                                            label={<b>Orig Effec Date </b>}
                                        >
                                          
                                    <DatePicker
                       className = "CalClass"
                       selected={this.state.OriginalEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OriginalEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={12} offset={1}>
                                        <FormItem validateStatus={Obj.LicenseLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["LicenseLocation"] ? 'error' : ""}
                                            help={Obj.LicenseLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["LicenseLocation"]}
                                            label={<b>License Location </b>}
                                        >
                                            <Select allowClear = {true} id = "SelLL" onFocus={(e) => {
                                document.getElementById("SelLL").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  style={{ width: '80%' }} onChange={e => this.handleFieldChange(e, 'LicenseLocation')}
                                                value={Obj.LicenseLocation} showArrow={true} size={"default"}
                                            >
                                                {DUHInitData.LicenseLocation.map((ff) => {
                                                    return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={6}>
                                        <FormItem
                                            validateStatus={this.state.ViolationDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ViolationDate"] ? 'error' : ""}
                                            help={this.state.ViolationDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ViolationDate"]}
                                            label={<b>Violation Date </b>}
                                        >
                                          
                                    <DatePicker
                       className = "CalClass"
                       selected={this.state.ViolationDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ViolationDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem validateStatus={Obj.TypeInput === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["TypeInput"] ? 'error' : ""}
                                            help={Obj.TypeInput === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["TypeInput"]}
                                            label={<b>Type Input </b>}
                                        >
                                            <Select allowClear = {true} id = "STI" onFocus={(e) => {
                                document.getElementById("STI").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  style={{ width: '80%' }} onChange={e => this.handleFieldChange(e, 'TypeInput')}
                                                value={Obj.TypeInput} showArrow={true} size={"default"}
                                            >
                                                {DUHInitData.TypeInput.map((ff) => {
                                                    return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col span={18}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{ width: '20%' }} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                                
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                    { if (isNewDL === true) {
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            ServiceDate: "",
                                            OriginalEffectiveDate: "",
                                            ViolationDate: "",
                                            DLNumber: "",
                                            ErrorObj: {},
                                            PhoneNumber: "",
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
 else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                          else
                                    {
                                        this.props.history.push({
                                            pathname: `/dlUpdates`,
                                            state: { dlNumber: this.state.DLNumber }
                                        })
                                    }
                                 } }}>Ok</Button>
                            </div>
                        ]}
                    >
                         {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            {/* </ScrollPanel > */}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUHData, saveDUHData,
           getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUHUpdate); 