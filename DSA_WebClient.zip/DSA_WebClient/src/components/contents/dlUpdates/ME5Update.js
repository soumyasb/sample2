import React, { Component } from 'react';
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Form, Input, Row, Button, Col, Spin, Modal } from 'antd';
import { 
    getME5Data, 
    saveME5Data, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
    import { bindActionCreators } from "redux";
    import { connect } from "react-redux";
    import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;

const defaultObj = {
    LoginId: "",
    NetName: "",
    RequestorCode: "",
    Operator: "",
    DLNumber: "",
    ThreeCharacterName: "",
    Status: '',
    StatusMessage: '',
    MedCertIssueDate: "",
    MedCertExpireDate: "",
    ExaminerLicense: "",
    ExaminerState: "",
    ME5Response: '',
    NextTran: '',
    Error: true
};

class ME5Update extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            ErrorMessage: '',
            isNewDL: false,
            ErrorModalShow: false
        }

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }

    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getME5Data(DLInitData.DLNumber, DLInitData.ThreeCharacterName);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.ME5InitData !== this.props.dlUpdates.ME5InitData && this.props.dlUpdates.ME5InitData !== undefined) {
                                const Obj =  cloneDeep(this.props.dlUpdates.ME5InitData);
                                Obj['NextTran'] = '';
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.ME5InitData.ThreeCharacterName;
                                this.setState({ME5InitData: this.props.dlUpdates.ME5InitData, Obj: Obj, DLNumber: this.props.dlUpdates.ME5InitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.ME5InitData.ThreeCharacterName});
                            }
                            if ( prevProps.dlUpdates.saveME5Data !== this.props.dlUpdates.saveME5Data && this.props.dlUpdates.saveME5Data !== undefined) {
                                this.setState({saveME5Data: this.props.dlUpdates.saveME5Data, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                            
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { ME5InitData, saveME5Data, dlUpdatesErrorData } = props.dlUpdates;
                if (ME5InitData && ME5InitData !== prevState.ME5InitData)
                {
                    const Obj =  cloneDeep(ME5InitData);
                    Obj['NextTran'] = '';
                    return {ME5InitData: ME5InitData, Obj: Obj, DLNumber: ME5InitData.DLNumber, ThreeCharacterName: ME5InitData.ThreeCharacterName, isloading: false };
                }
                if (saveME5Data && saveME5Data !== prevState.saveME5Data) return { saveME5Data: saveME5Data, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return { dlUpdatesErrorData, isloading: false};
                return null;
            }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextTran':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
        const { Obj } = this.state;
        Obj.Status = 'I';
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
        this.props.saveME5Data(Obj);
    }

    render() {
        const {  Obj, isloading, isNewDL
             } = this.state;
             const { ME5InitData, saveME5Data } = this.state;

        return (
            // <ScrollPanel style={{ width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0)" }}>
            <React-Fragment>
           {isloading !== true ? <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
            {saveME5Data && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false});    if(isNewDL !== true ) {
            this.props.history.push({ pathname: `/dlUpdates`,
     state: {dlNumber: saveME5Data.DLNumber}})}
     if(saveME5Data.Error === false)
     {  if(Obj.NextTran !== null && Obj.NextTran !== '')
     {
         this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
         state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
     }
     else if(isNewDL !== true)
     {
         this.props.history.push({
             pathname: `/dlUpdates`,
             state: { dlNumber: this.state.DLNumber }
         })
     }
     else
     {
         this.setState({ Obj: cloneDeep(defaultObj),
            ErrorMessage: '',
            DLNumber: '',
            ErrorModalShow: false
         });
     }
}}
    }>OK</Button>]}><div>
         <div dangerouslySetInnerHTML={{ __html: saveME5Data.ME5Response.toString()}}/>
         </div></Modal>}
         {ME5InitData ?   
           ME5InitData.Message !== null ? <Modal maskClosable={false} title={"ME5 Message"} visible={true} onCancel={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
           state: {dlNumber: ME5InitData.DLNumber}})}} footer={[<Button type="primary" key="Ok" onClick={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
           state: {dlNumber: ME5InitData.DLNumber}})}}>OK</Button>]}><div>{ME5InitData.Message}</div></Modal> :
           <div><div style={{
            border: '1px solid black',
            paddingLeft: "1%",
            textAlign: 'center',
            backgroundColor: '#c9e3fa',
            fontSize: '32px'
            }} >Medical Certificate Invalid (ME5)</div> <Form className="ant-advanced-search-form">
               {isNewDL ? <Row>
                    <Col span={5}>
                        <FormItem
                         hasFeedback
                         validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                         help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                            label={<b>DL # </b>}
                        >
                            <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                        </FormItem>
                    </Col>
                    <Col span={5} offset={1}>
                        <FormItem
                            label={<b>3 Pos Last Name </b>}
                        >
                            <Input maxLength={3} value={Obj.ThreeCharacterName} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                        </FormItem>
                    </Col>
                    <Col span={1} />
                    <Col span={5} offset={1} style={{ height: '39px' }} >
                        <span style={{ color: 'blue', fontWeight: 'bold', verticalAlign: 'middle' }}>
                            {Obj.StatusMessage}
                        </span>
                    </Col>
                </Row>:
                  <Row>
                               <Col span={5}>
                                   <b>DL Number</b>:{" "}{this.state.DLNumber}
                               </Col>
                               <Col span={1} />
                               <Col span={5}>
                                   <b>3 Pos Last Name</b>:{" "}{this.state.ThreeCharacterName}
                               </Col>
                               <Col span={1} />
                               <Col span={5}>
                                  <div style={{color: 'blue', fontWeight: 'bold', verticalAlign: 'middle', fontSize: '1.2em'}}>{Obj.StatusMessage}</div>
                               </Col>
               </Row> }
                <br />
                <br />
                <Row>
                <Col span={9}>
                <FormItem
                    label={<b>Date of Exam/Med Cert Issue Date  </b>}
                >
                <Input size={"small"} value={Obj.MedCertIssueDate}
                                onChange={e => this.handleFieldChange(e, 'MedCertIssueDate')}
                                disabled
                            />
                </FormItem>
            </Col>
            <Col span={7}>
                <FormItem
                    label={<b>Med Cert Exp Date  </b>}
                >
               <Input size={"small"}  value={Obj.MedCertExpireDate}
                                onChange={e => this.handleFieldChange(e, 'MedCertExpireDate')}
                                disabled
                            />
                </FormItem>
            </Col>
                </Row>
                <Row>
                <Col span={8}>
                <FormItem
                    label={<b>Examiner License #  </b>}
                >
                     <Input size={"small"}  value={Obj.ExaminerLicense} placeholder="Examiner License #"
                                onChange={e => this.handleFieldChange(e, 'ExaminerLicense')}
                                disabled
                            />
                </FormItem>
            </Col>
            <Col span={8}>
            <FormItem
                label={<b>State of Issue  </b>}
            >               
                 <Input size={"small"}  value={Obj.ExaminerState} placeholder="Examiner State"
                                onChange={e => this.handleFieldChange(e, 'ExaminerState')}
                                disabled
                            />
            </FormItem>
        </Col>
                </Row>
                <br />
                <br />
                <Row>
                <Col span={8}>
                       <FormItem
                           label={<b>Next Trans  </b>}
                       >
                           <Input value={Obj.NextTran} maxLength = {3} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextTran')} />
                       </FormItem>
                   </Col>
                    <Col span={15} style={{ float: 'right' }}>
                    {Obj.NextTran !== '' ? <Button disabled
                           type="default">New DL</Button>: <Button style={{ color: "white", backgroundColor: "green" }}
            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button> }{' '}
                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                        <Button style={{ color: "white", backgroundColor: "red" }}
                            type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                            state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                    </Col>
                </Row>
            </Form></div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                                {
                                    this.setState({ErrorModalShow: false});
                                    if( !this.state.ErrorObj )
                                {  if(Obj.NextTran !== null && Obj.NextTran !== '')
                                {
                                    this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                    state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                }
                                else if(isNewDL === true)
                                    {
                                        this.setState({ Obj: cloneDeep(defaultObj),
                                           ErrorMessage: '',
                                           DLNumber: "",
                                           ErrorModalShow: false
                                        });
                                    }
                                    else
                                    {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }         
                                }}>Ok</Button>
                        </div>
                    ]}
                >
                                   {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            {/* </ScrollPanel> */}
            </React-Fragment>
        );
    }
}
const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getME5Data, saveME5Data, getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ME5Update); 