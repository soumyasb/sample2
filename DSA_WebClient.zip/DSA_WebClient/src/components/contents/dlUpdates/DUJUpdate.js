import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Radio, Select, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDUJData, saveDUJData, getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;
const RadioGroup = Radio.Group;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    TypeInput: 'A',
    DueDate: '',
    Reason: '',
    Destination: '',
    ChangeToDate: '',
    TestDate: '',
    DUJResponse: '',
    NextDLNumber: '',
    Error: true
};


class DUJUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            DueDate: "",
            ChangeToDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }

    componentDidMount() {
        if (sessionStorage.getItem('dlInitData')) {
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                dlNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDUJData(DLInitData.DLNumber);
        }
        else {
            this.props.history.push(`/dlUpdates`);
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DUJInitData !== this.props.dlUpdates.DUJInitData && this.props.dlUpdates.DUJInitData !== undefined) {
            const Obj = cloneDeep(defaultObj);
            Obj['ThreeCharacterName'] = this.props.dlUpdates.DUJInitData.ThreeCharacterName;
            this.setState({DUJInitData: this.props.dlUpdates.DUJInitData, Obj: Obj});
        }
        if (prevProps.dlUpdates.saveDUJData !== this.props.dlUpdates.saveDUJData && this.props.dlUpdates.saveDUJData !== undefined) {
            this.setState({ saveDUJData: this.props.dlUpdates.saveDUJData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isloading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DUJInitData, saveDUJData, dlUpdatesErrorData } = props.dlUpdates;
        if (DUJInitData && DUJInitData !== prevState.DUJInitData) {
            return { DUJInitData: DUJInitData, isloading: false };
        }
        if (saveDUJData && saveDUJData !== prevState.saveDUJData)
            return {
                saveDUJData: saveDUJData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
                Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                    this.props.getDUJData(Obj['DLNumber']);
                }
                break;
            case 'NextDLNumber':
            case 'ThreeCharacterName':
                if (e.target.value.length <= 3) {
                    Obj[field] = e.target.value;
                }
                break;
                case 'TypeInput':
                Obj[field] = e.target.value;
                break;
            case 'Destination':
            const { value } = e.target;
  const reg = /^[0-9]*$/;
  if ((!isNaN(value) && reg.test(value))) {
    Obj[field] = value;
  }
            break;
            case 'Reason':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {

        switch (type) {
            case 'DueDate':
                this.setState({ DueDate: d });
                break;
            case 'ChangeToDate':
                this.setState({ ChangeToDate: d });
                break;
            default:
                break;
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }

        const { Obj } = this.state;

        Obj['LoginId'] = this.state.DUJInitData.LoginId;
        Obj['Operator'] = this.state.DUJInitData.Operator;
        Obj['RequestorCode'] = this.state.DUJInitData.RequestorCode;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['ChangeToDate'] = dateFormatFuncDLUpdates(this.state.ChangeToDate);
        Obj['DueDate'] = dateFormatFuncDLUpdates(this.state.DueDate);

        this.setState({ isloading: true, dlNumber: Obj['DLNumber'], isNewDL: isNewDL });
         this.props.saveDUJData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUJInitData, saveDUJData, isNewDL, isloading } = this.state;

        return (

            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {saveDUJData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDUJData.Error === false)
               { if (Obj.NextDLNumber !== '') {
                this.props.history.push({
                    pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                    state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName }
                });
            }
            else if (isNewDL !== true) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDUJData.DLNumber }
                                    })
                                }
                                else {
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                        HearingDate: "",
                                        OriginalDate: "",
                                        DLNumber: '',
                                        ErrorObj: {},
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                } 
                            }}
                        }>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDUJData.DUJResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DUJInitData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Suspense (DUJ)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={8} style={{ display: 'block' }}>
                                            <FormItem
                                            hasFeedback
                                            validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                            help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={8}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }

                                <Row>
                                    <Col span={17}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Type Input</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.TypeInput === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["TypeInput"] ? 'error' : ""}
                                                        help={Obj.TypeInput === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["TypeInput"]}
                                                        label={<b> Type </b>}
                                                    >
                                                         <Row>
                                                        <Col offset={2}>
                                                            <RadioGroup name="Type Input" value={Obj.TypeInput} onChange={e => this.handleFieldChange(e, 'TypeInput')}>
                                                                <Radio value={'A'}>Add</Radio>
                                                                <Radio value={'C'}>Change</Radio>
                                                                <Radio value={'D'}>Delete</Radio>
                                                            </RadioGroup>
                                                        </Col>
                                                    </Row>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                   <Row> <Col span={8}>
                                        <FormItem
                                            validateStatus={this.state.DueDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["DueDate"] ? 'error' : ""}
                                            help={this.state.DueDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["DueDate"]}
                                            label={<b> Due Date </b>}
                                        >
                                           
                                    <DatePicker
                       className = "CalClass"
                       selected={this.state.DueDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'DueDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.Reason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Reason"] ? 'error' : ""}
                                            help={Obj.Reason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Reason"]}
                                            label={<b>Reason </b>}
                                        >
                                            <Select allowClear = {true} id = "SRea2" onFocus={(e) => {
                                document.getElementById("SRea2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'Reason')}
                                                value={Obj.Reason} showArrow={true} size={"default"}
                                            >
                                                {DUJInitData.Reasons ? DUJInitData.Reasons.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                }) : <Option title={``} key={0} value={'-0-'}>No Reasons available</Option>}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    </Row>
                                    <Row>
                                        <Col span={8}>
                                                    <FormItem
                                                        validateStatus={Obj.Destination === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Destination"] ? 'error' : ""}
                                                        help={Obj.Destination === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Destination"]}
                                                        label={<b> Destination <font color="red">*</font></b>}
                                                    >
                                                        <Input onChange={e => this.handleFieldChange(e, 'Destination')}
                                                            value={Obj.Destination} maxLength={4} placeholder="Destination"
                                                        />
                                                    </FormItem>
                                                </Col>
                                            {Obj.TypeInput === 'C' &&   <Col span={8} offset={1}>
                                                    <FormItem
                                                        validateStatus={Obj.ChangeToDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ChangeToDate"] ? 'error' : ""}
                                                        help={Obj.ChangeToDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ChangeToDate"]}
                                                        label={<b> Change To Date </b>}
                                                    >
                                                      
                                    <DatePicker
                       className = "CalClass"
                       selected={this.state.ChangeToDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ChangeToDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                                    </FormItem>
                                                </Col>}
                                    </Row>
                                </Row>

                                <Row>
                                    <Col span={18}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{ width: '20%' }} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                                
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                    {
                                    if (isNewDL === true) {
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            DueDate: "",
                                            ChangeToDate: "",
                                            ErrorObj: {},
                                            DLNumber: "",
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                   else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                   else
                                            {
                                                this.props.history.push({ pathname: `/dlUpdates`,
                                                state: {dlNumber: this.state.DLNumber}})
                                            }
                                }}}>Ok</Button>
                            </div>
                        ]}
                    >
                          {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUJData, saveDUJData,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUJUpdate); 