import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Radio, Select, Modal, Spin } from 'antd';import { dateFormatFuncDLUpdates, dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { getDUZData, saveDUZData, getDLInitialData
 } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    BirthDate: '',
    AuthoritySection: '',
    TypeAction: '',
    Reason: '',
    NewEffectiveDate: '',
    ThroughDate: '',
    MailDate: '',
    OrigAuthoritySection: '',
    OrigEffectiveDate: '',
    UpdateCopies: '',
    OutOfStateDLNo: '',
    OutOfStateCd: '',
    CommercialStatusIndicator:'',
    HearingType: '',
    HearingDate: '',
    HearingLocation: '',
    HearingResult: '',
    ModifiedHearingDate: '',
    EndStay: '',
    PMOption: false,
    PMCode: '',
    RestrictionsOptions: 'N',
    Restriction1: '',
    Restriction2: '',
    Restriction3: '',
    CoFo: '',
    LicenseLocation: '',
    FieldFile: '',
    RouteCode: '',
    MedicalSuspense: '',
    DUZResponse: '',
    NextDLNumber: '',
    Error: true
};

class DUZUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            NewEffectiveDate: "",
            MailDate: "",
            OrigEffectiveDate: "",
            ThroughDate:"",
            HearingDate: '',
            ModifiedHearingDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }
    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
         const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDUZData(DLInitData.DLNumber);
        }
        else 
        {
            this.props.history.push(`/dlUpdates`);
        }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.DUZInitData !== this.props.dlUpdates.DUZInitData && this.props.dlUpdates.DUZInitData !== undefined) {
                                const Obj = cloneDeep(defaultObj);
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.DUZInitData.ThreeCharacterName;
                                Obj['BirthDate'] = this.props.dlUpdates.DUZInitData.BirthDate;
                                this.setState({DUZInitData: this.props.dlUpdates.DUZInitData, Obj: Obj});
                            }
                            if ( prevProps.dlUpdates.saveDUZData !== this.props.dlUpdates.saveDUZData && this.props.dlUpdates.saveDUZData !== undefined) {
                                this.setState({saveDUZData: this.props.dlUpdates.saveDUZData, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                               Obj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { DUZInitData, saveDUZData, dlUpdatesErrorData, dlInitData } = props.dlUpdates;
                if (DUZInitData && DUZInitData !== prevState.DUZInitData)
                {
                    return { DUZInitData: DUZInitData, isloading: false };
                } 
                if (dlInitData && dlInitData !== prevState.dlInitData)
                {
                    
                    sessionStorage.getItem('dlInitData') !== undefined && sessionStorage.setItem('dlInitData', JSON.stringify(dlInitData)); 
                    return { dlInitData: dlInitData, DLNumber: dlInitData.DLNumber, ThreeCharacterName: dlInitData.ThreeCharacterName, BirthDate: dlInitData.Birthdate, isloading: false };
                } 
                if (saveDUZData && saveDUZData !== prevState.saveDUZData) return { saveDUZData: saveDUZData, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false };
                return null;
            }
    handleFieldChange(e, field) {
   
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                    this.props.getDUZInitialPage(Obj['DLNumber']);
                }
                break;
            case 'PMOption':
            case 'RestrictionsOptions':
            
                Obj[field] = e.target.value;
                if( field === 'PMOption' && e.target.value === false)
                {
                    Obj.PMCode = '';
                }
                if( field === 'RestrictionsOptions' && e.target.value === 'N')
                {
                    Obj.Restriction1 = '';
                    Obj.Restriction2 = '';
                    Obj.Restriction3 = '';
                }
                if( (Obj['DLNumber'].length === 8) ) {
               this.props.getDLInitialData(Obj['DLNumber']);
                    this.props.getDUZData(Obj['DLNumber'] );
                }
                break;
            case 'OutOfStateDLNo':
                if (e.target.value.length <= 25) {
                    Obj[field] = e.target.value;
                }
                break;
                case 'RouteCode':
                let res2 = /^[a-zA-Z]+$/.test(e.target.value);
                   if(res2 || e.target.value === '')
                   {
                        if (e.target.value.length <= 4) {
                            Obj[field] = e.target.value;
                            }     
                }
                    break;
                case 'MedicalSuspense':
                    if ((!isNaN(e.target.value) && /^[0-9]*$/.test(e.target.value))) {
                    if (e.target.value.length <= 2) {
                        Obj[field] = e.target.value;
                        }
                    }
                        break;
            case 'AuthoritySection':
            case 'TypeAction':
            case 'Reason':
            case 'CoFo':
            case 'UpdateCopies':
            case 'OrigAuthoritySection':
            case 'CommercialStatusIndicator':
            case 'HearingResult':
            case 'HearingType':
            case 'PMCode':
            case 'Restriction1':
            case 'Restriction2':
            case 'Restriction3':
            case 'HearingLocation':
            case 'EndStay':
            case 'LicenseLocation':
            case 'FieldFile':
            case 'OutOfStateCd':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {
        switch(type) {
            case 'NewEffectiveDate':
            this.setState({ NewEffectiveDate: d });
            break;
            case 'BirthDate':
            this.setState({  BirthDate: d });
            break;
            case 'OrigEffectiveDate':
            this.setState({ OrigEffectiveDate: d });
            break;
            case 'ThroughDate':
            this.setState({ ThroughDate: d });
            break;
            case 'MailDate':
            this.setState({ MailDate: d });
            break;
            case 'HearingDate':
            this.setState({ HearingDate: d });
            break;
            case 'ModifiedHearingDate':
            this.setState({ ModifiedHearingDate: d });
            break;
            default:
            break;
        }
    }
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
     
        const { Obj } = this.state;

        Obj['RequestorCode'] = this.state.DUZInitData.RequestorCode;
        Obj['Operator'] = this.state.DUZInitData.Operator;
        Obj['NetName'] = this.state.DUZInitData.NetName;
        Obj['LoginId'] = this.state.DUZInitData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        if(typeof this.state.BirthDate === 'string')
        {
            Obj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
        }
      else
      {
        Obj['BirthDate'] = dateFormatFuncDLUpdates(this.state.BirthDate);
      }
      Obj['NewEffectiveDate'] = dateFormatFuncDLUpdates(this.state.NewEffectiveDate);
      Obj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
      Obj['ThroughDate'] = dateFormatFuncDLUpdates(this.state.ThroughDate);
      Obj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
      Obj['HearingDate'] = dateFormatFuncDLUpdates(this.state.HearingDate);
      Obj['ModifiedHearingDate'] = dateFormatFuncDLUpdates(this.state.ModifiedHearingDate);
        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
        this.props.saveDUZData(Obj);
    }
  
    render() {
        const { Obj } = this.state;
        const { DUZInitData, saveDUZData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
                 {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
               {saveDUZData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false}); 
               if(saveDUZData.Error === false)
               { if(Obj.NextDLNumber !== '')
               {
                   this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                   state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
               } else if(isNewDL !== true ) {
                   this.props.history.push({ pathname: `/dlUpdates`,
            state: {dlNumber: saveDUZData.DLNumber}})}
            else
            {
                this.setState({Obj: cloneDeep(defaultObj),
                    NewEffectiveDate: "",
                    OrigEffectiveDate: "",
                    DLNumber: '',
                    BirthDate: '',
                    ThroughDate: "",
                    HearingDate:"",
                    ModifiedHearingDate: "",
                    ErrorObj: {},
                    ErrorMessage: '',
                    ErrorModalShow: false
                });
            }
}}
               }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: saveDUZData.DUZResponse.toString()}}/>
          </div></Modal>}
            {DUZInitData ?   
              <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Discretionary Action (DUZ)</div>
                <Form className="ant-advanced-search-form">
                {isNewDL ? <Row>
                        <Col span={6} style={{ display: 'block' }}>
                            <FormItem
                              hasFeedback
                              validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                              help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                label={<b>DL # </b>}
                            >
                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                label={<b>3 Pos Last Name </b>}
                            >
                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1} style={{ height: '39px' }} >
                            <FormItem
                                label={<b>Birth Date </b>}
                            >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>:
               <Row>
                               <Col span={5}>
                               <FormItem
                                label={<b>DL #</b>}
                            >
                                   {this.state.DLNumber}
                                   </FormItem>
                               </Col>
                               <Col span={5} offset={1}>
                               <FormItem
                                label={<b>3 Pos Last Name</b>}
                            >
                                {this.state.ThreeCharacterName}
                                </FormItem>
                               </Col>
                               <Col span={6} offset={1} >
                            <FormItem
                                label={<b>Birth Date </b>}
                            >
                             {this.state.BirthDate}
                                   </FormItem>
                               </Col>
                           </Row>
               }
                    <Row>
                        <Col span={6}>
                            <FormItem
                              validateStatus = {Obj.AuthoritySection === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthoritySection"] ? 'error' : ""}
                              help = {Obj.AuthoritySection === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["AuthoritySection"]}
                                label={<b>Authority Section </b>}
                            >
                                <Select allowClear = {true} id = "SASDUZ" onFocus={(e) => {
                                document.getElementById("SASDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthoritySection')}
                                    value={Obj.AuthoritySection} showArrow={true} size={"default"}
                                >
                                    {DUZInitData.AuthoritySection.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.TypeAction === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TypeAction"] ? 'error' : ""}
                                 help = {Obj.TypeAction === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TypeAction"]}
                                label={<b>Type Action </b>}
                            >
                                <Select allowClear = {true} id = "STADUZ" onFocus={(e) => {
                                document.getElementById("STADUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'TypeAction')}
                                    value={Obj.TypeAction} showArrow={true} size={"default"}
                                >
                                       {DUZInitData.TypeAction.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.Reason === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Reason"] ? 'error' : ""}
                                 help = {Obj.Reason === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Reason"]}
                                label={<b>Reason </b>}
                            >
                                <Select allowClear = {true} id = "SReaDUZ" onFocus={(e) => {
                                document.getElementById("SReaDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Reason')}
                                    value={Obj.Reason} showArrow={true} size={"default"}
                                >
                                  {DUZInitData.Reasons.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={6}>
                            <FormItem
                                 validateStatus = {this.state.NewEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NewEffectiveDate"] ? 'error' : ""}
                                 help = {this.state.NewEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NewEffectiveDate"]}
                                label={<b>New Effective Date </b>}
                            >
                               <DatePicker
                       className = "CalClass"
                       selected={this.state.NewEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'NewEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.ThroughDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ThroughDate"] ? 'error' : ""}
                                 help = {this.state.ThroughDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ThroughDate"]}
                                label={<b>Through Date </b>}
                            >
                                  <DatePicker
                       className = "CalClass"
                       selected={this.state.ThroughDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ThroughDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />  </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.MailDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailDate"] ? 'error' : ""}
                                 help = {this.state.MailDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailDate"]}
                                label={<b>Mail Date </b>}
                            >
                                 <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                        </Col>                     
                    </Row>
                    <Row>
                        <Col span={6}>
                            <FormItem
                                 validateStatus = {Obj.OrigAuthSect === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigAuthSect"] ? 'error' : ""}
                                 help = {Obj.OrigAuthSect === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigAuthSect"]}
                                label={<b>Orig Auth Section </b>}
                            >
                                <Select allowClear = {true} id = "SOASDUZ" onFocus={(e) => {
                                document.getElementById("SOASDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}   onChange={e => this.handleFieldChange(e, 'OrigAuthSect')}
                                    value={Obj.OrigAuthSect} showArrow={true} size={"default"}
                                >
                                      {DUZInitData.OriginalAuthoritySection.map((oas) =>
                                        {
                                            return <Option title={`${oas.Value} - ${oas.Text}`} key={oas.Value} value={oas.Value}>{oas.Value} - {oas.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigEffectiveDate"] ? 'error' : ""}
                                 help = {this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigEffectiveDate"]}
                                label={<b>Orig Effec Date </b>}
                            >
                                     <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /></FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {Obj.UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                                 help = {Obj.UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"]}
                                label={<b>Update Copies </b>}
                            >
                                <Select allowClear = {true} id = "SUCDUZ" onFocus={(e) => {
                                document.getElementById("SUCDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}   onChange={e => this.handleFieldChange(e, 'UpdateCopies')}
                                    value={Obj.UpdateCopies} showArrow={true} size={"default"}
                                >
                                    {DUZInitData.UpdateCopies.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={12}>
                            <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                <Row>
                                    <Col>
                                        <h4>Out-of-State-Data</h4>
                                        <hr />
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={11}>
                                        <FormItem
                                             validateStatus = {Obj.OutOfStateDLNo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateDLNo"] ? 'error' : ""}
                                             help = {Obj.OutOfStateDLNo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateDLNo"]}
                                              label={<b>O / S DL # </b>}>
                                            <Input placeholder="O / S DL #" value={Obj.OutOfStateDLNo}
                                                onChange={e => this.handleFieldChange(e, 'OutOfStateDLNo')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={12} offset={1}>
                                        <FormItem 
                                             validateStatus = {Obj.OutOfStateCd === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateCd"] ? 'error' : ""}
                                             help = {Obj.OutOfStateCd === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OutOfStateCd"]}
                                             label={<b>O / S Code </b>}>
                                            <Select allowClear = {true} id = "SOSDUZ" onFocus={(e) => {
                                document.getElementById("SOSDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OutOfStateCd')}
                                                value={Obj.OutOfStateCd} showArrow={true} size={"default"}
                                            >
                                               {DUZInitData.OSCode.map((oc) => {
                                   return <Option title={`${oc.Value} - ${oc.Text}`} key={oc.Value} value={oc.Value}>{oc.Value} - {oc.Text}</Option>
                               })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                            </div>
                        </Col>
                        <Col span={8} offset={1}>
                            <FormItem 
                                 validateStatus = {Obj.CommercialStatusIndicator === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"] ? 'error' : ""}
                                 help = {Obj.CommercialStatusIndicator === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CommercialStatusIndicator"]}
                                 label={<b>Commercial Status Ind </b>}>
                                <Select allowClear = {true} id = "SCSIDUZ" onFocus={(e) => {
                                document.getElementById("SCSIDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CommercialStatusIndicator')}
                                    value={Obj.CommercialStatusIndicator} showArrow={true} size={"default"}
                                >
                                    {DUZInitData.CommStatusIndicator.map((csi) => {
                                   return <Option title={`${csi.Value} - ${csi.Text}`} key={csi.Value} value={csi.Value}>{csi.Value} - {csi.Text}</Option>
                               })}
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                    <br />
                    <div style={{ width: '80%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                        <Row>
                            <Col>
                                <h4>Hearing Information</h4>
                                <hr />
                            </Col>
                        </Row>
                        <Row>
                            <Col span={7}>
                                <FormItem 
                                     validateStatus = {Obj.HearingType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingType"] ? 'error' : ""}
                                     help = {Obj.HearingType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingType"]}
                                     label={<b>Type </b>}>
                                    <Select allowClear = {true} id = "STyDUZ" onFocus={(e) => {
                                document.getElementById("STyDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingType')}
                                        value={Obj.HearingType} showArrow={true} size={"default"}
                                    >
                                      {DUZInitData.ChgHearingType.map((ht) => {
                                   return <Option title={`${ht.Value} - ${ht.Text}`} key={ht.Value} value={ht.Value}>{ht.Value} - {ht.Text}</Option>
                               })}
                                    </Select>
                                </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                     validateStatus = {this.state.HearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingDate"] ? 'error' : ""}
                                     help = {this.state.HearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingDate"]}
                                    label={<b>Date </b>}
                                >
                                     <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem      
                                validateStatus = {Obj.DSFieldOffice === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DSFieldOffice"] ? 'error' : ""}
                              help = {Obj.DSFieldOffice === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["DSFieldOffice"]}
                                label={<b>Location </b>}>
                                    <Input placeholder="Location" value={Obj.DSFieldOffice}
                                        onChange={e => this.handleFieldChange(e, 'DSFieldOffice')} />
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={12}>
                                <FormItem 
                                     validateStatus = {Obj.HearingResult === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingResult"] ? 'error' : ""}
                                     help = {Obj.HearingResult === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["HearingResult"]}
                                label={<b>Result </b>}>
                                    <Select allowClear = {true} id = "SResDUZ" onFocus={(e) => {
                                document.getElementById("SResDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingResult')}
                                        value={Obj.HearingResult} showArrow={true} size={"default"}
                                    >
                                        {DUZInitData.HearingResults.map((hr) => {
                                   return <Option title={`${hr.Value} - ${hr.Text}`} key={hr.Value} value={hr.Value}>{hr.Value} - {hr.Text}</Option>
                               })}
                                    </Select>
                                </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                     validateStatus = {this.state.ModifiedHearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ModifiedHearingDate"] ? 'error' : ""}
                                     help = {this.state.ModifiedHearingDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ModifiedHearingDate"]}
                                    label={<b>Mod Date </b>}
                                >
                                      <DatePicker
                       className = "CalClass"
                       selected={this.state.ModifiedHearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ModifiedHearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /></FormItem>
                            </Col>
                        </Row>
                    </div>
                    <br/>
                    <Row>
                    <div style={{width: '20%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px', float: 'left' }}>
                    <Row>
                            <Col>
                                <h4>P/M Code</h4>
                                <hr />
                            </Col>
                        </Row> <Row><RadioGroup name="PMOption" value={Obj.PMOption} onChange={(e) => this.handleFieldChange(e, 'PMOption')}>
                                        <Radio key={`N`} value={false}>N/A</Radio>
                                        <Radio key={`A`} value={true}>Add</Radio>

                                    </RadioGroup></Row><br /><Row>
                               <Select allowClear = {true} id = "SPMODUZ" onFocus={(e) => {
                                document.getElementById("SPMODUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled={Obj.PMOption === false ? true: false}  onChange={e => this.handleFieldChange(e, 'PMCode')}
                            value={Obj.PMCode} showArrow={true} size={"default"}
                        >
                         {DUZInitData.PMCode.map((ff) => {
                           return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                       })}
                        </Select>  </Row>
                </div>
                <div style={{width: '30%', marginLeft: '20px', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px', float: 'left' }}>
                <Row>
                            <Row>
                                <h4>Restriction</h4>
                                <hr />
                            </Row>
                           <Row> <RadioGroup name="RestrictionsOptions" value={Obj.RestrictionsOptions} onChange={(e) => this.handleFieldChange(e, 'RestrictionsOptions')}>
                                        <Radio  key={`N`} value={'N'}>N/A</Radio>
                                        <Radio  key={`A`} value={'A'}>Add</Radio>
                                        <Radio  key={`D`} value={'D'}>Delete</Radio>
                                    </RadioGroup>
                               </Row>
                               <br />
                               <Row>
                                   <Col span={7}>
                               <Select allowClear = {true} id = "SRODUZ" onFocus={(e) => {
                                document.getElementById("SRODUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled={Obj.RestrictionsOptions === 'N' ? true: false} onChange={e => this.handleFieldChange(e, 'Restriction1')}
                            value={Obj.Restriction1} showArrow={true} size={"default"}
                        >
                         {DUZInitData.Rest1.map((ff) => {
                           return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                       })}
                        </Select>
                        </Col>
                        <Col style={{marginLeft: '10px'}} span={7}>
                        <Select allowClear = {true} id = "SRO2DUZ" onFocus={(e) => {
                                document.getElementById("SRO2DUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled={Obj.RestrictionsOptions === 'N' ? true: false} onChange={e => this.handleFieldChange(e, 'Restriction2')}
                            value={Obj.Restriction2} showArrow={true} size={"default"}
                        >
                         {DUZInitData.Rest2.map((ff) => {
                           return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                       })}
                        </Select>
                        </Col> <Col style={{marginLeft: '10px'}} span={7}>
                        <Select allowClear = {true} id = "SRO3DUZ" onFocus={(e) => {
                                document.getElementById("SRO3DUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  disabled={Obj.RestrictionsOptions === 'N' ? true: false} onChange={e => this.handleFieldChange(e, 'Restriction3')}
                            value={Obj.Restriction3} showArrow={true} size={"default"}
                        >
                         {DUZInitData.Rest2.map((ff) => {
                           return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                       })}
                        </Select> </Col>
                               </Row>     
                        </Row>
                </div>
                    <div style={{ marginLeft: '20px', width: '40%', padding: '10px', float: 'left' }}>
                    <Row><Col span= {20}>
                            <FormItem
                                 validateStatus = {Obj.CoFo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CoFo"] ? 'error' : ""}
                                 help = {Obj.CoFo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CoFo"]}
                                label={<b>Co / Fo </b>}
                            >
                                <Select allowClear = {true} id = "SCoFoDUZ" onFocus={(e) => {
                                document.getElementById("SCoFoDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'CoFo')}
                                    value={Obj.CoFo} showArrow={true} size={"default"}
                                >
                                  {DUZInitData.CoFo.map((cf) =>
                                        {
                                            return <Option title={`${cf.Value} - ${cf.Text}`} key={cf.Value} value={cf.Value}>{cf.Value} - {cf.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                            </Col>
                        </Row>
                        <Row>
                        <Col span={10}>
                    <FormItem style={{display: 'block'}}
                         validateStatus = {Obj.LicenseLocation === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LicenseLocation"] ? 'error' : ""}
                         help = {Obj.LicenseLocation === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LicenseLocation"]}
                        label={<b>License Location </b>}
                    >
                        <Select allowClear = {true} id = "SLLDUZ" onFocus={(e) => {
                                document.getElementById("SLLDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'LicenseLocation')}
                            value={Obj.LicenseLocation} showArrow={true} size={"default"}
                        >
                         {DUZInitData.LicenseLocation.map((ff) => {
                           return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                       })}
                        </Select>
                    </FormItem>
                </Col>
                    <Col span={10}>
                    <FormItem style={{display: 'block'}}
                         validateStatus = {Obj.FieldFile === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["FieldFile"] ? 'error' : ""}
                         help = {Obj.FieldFile === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["FieldFile"]}
                        label={<b>Field File </b>}
                    >
                        <Select allowClear = {true} id = "SFFDUZ" onFocus={(e) => {
                                document.getElementById("SFFDUZ").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'FieldFile')}
                            value={Obj.FieldFile} showArrow={true} size={"default"}
                        >
                         {DUZInitData.FieldFile.map((ff) => {
                           return <Option title={`${ff.Value} - ${ff.Text}`} key={ff.Value} value={ff.Value}>{ff.Value} - {ff.Text}</Option>
                       })}
                        </Select>
                    </FormItem>
                </Col>
                </Row>
                <Row>
                        <Col span={10}>
                    <FormItem
                         validateStatus = {Obj.RouteCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["RouteCode"] ? 'error' : ""}
                         help = {Obj.RouteCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["RouteCode"]}
                        label={<b>Route Code </b>}
                    >
                      <Input style={{width: "85%"}} value={Obj.RouteCode} placeholder="Route Code" onChange={e => this.handleFieldChange(e, 'RouteCode')} />
                    </FormItem>
                </Col>
                    <Col style={{marginLeft: "20px"}} span={10}>
                    <FormItem
                         validateStatus = {Obj.MedicalSuspense === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedicalSuspense"] ? 'error' : ""}
                         help = {Obj.MedicalSuspense === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedicalSuspense"]}
                        label={<b>Medical Suspense </b>}
                    >
                    <Input style={{width: "100%"}}  value={Obj.MedicalSuspense} placeholder="Medical Suspense" onChange={e => this.handleFieldChange(e, 'MedicalSuspense')} />
                    </FormItem>
                </Col>
                </Row>
                </div>
                </Row>
                    <Row>
                        <Col span={20}>
                            <FormItem
                                 validateStatus = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                 help = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"]}
                                label={<b>Next Trans </b>}
                            >
                                <Input style={{width: '20%'}} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={4} style={{ float: 'right' }}>
                        {Obj.NextDLNumber !== '' ? <Button disabled
                           type="default">New DL</Button>: <Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                            <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                            <Button style={{ color: "white", backgroundColor: "red" }}
                                type="default" key="Cancel" onClick={(e) =>
                                    {
                                    this.props.history.push({ pathname: `/dlUpdates`,
                                state: {dlNumber: this.state.DLNumber}})
                                    }
                            }>Cancel</Button>
                        </Col>
                    </Row>
                </Form></div>  : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                            {
                                this.setState({ErrorModalShow: false});
                                if( !this.state.ErrorObj )
                                {
                                    if(isNewDL === true)
                                    {
                                        this.setState({Obj: cloneDeep(defaultObj),                                        
                                            NewEffectiveDate: "",
                                            DLNumber: "",
                                            BirthDate: "", 
                                            OrigEffectiveDate: "",
                                            ThroughDate: "",
                                            HearingDate:"",
                                            ModifiedHearingDate: "",
                                            ErrorObj: {},
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                    else if(Obj.NextDLNumber !== '')
                                    {
                                        this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                        state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                    }  
                                  else  {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }  
                        }}>Ok</Button>
                        </div>
                    ]}
                >
                  {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            </React-Fragment>
            );
    }
}
    
const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUZData, saveDUZData,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUZUpdate); 