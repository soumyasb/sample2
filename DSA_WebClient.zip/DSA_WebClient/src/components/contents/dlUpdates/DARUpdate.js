import React, { Component } from 'react';
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { 
    getDARInitialPage, 
    saveDARUpdate, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { checkYearOfDate, dateFormatFunc, dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { connect } from "react-redux";
import { InputNumber, Form, Row, Col, Spin, Input, Select, Button, Modal } from 'antd';                                     
import cloneDeep from 'lodash/cloneDeep';

const { Option } = Select;
const FormItem = Form.Item;

const defaultDARObj = {
    RequestorCode: '',
    Operator: '',
    BirthDate: '',
    NetName: '',
    LoginId: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    TypeInput: '',
    LawEnforcementAgency: '',
    CourtCode: '',
    BAC1: '0.00',
    BAC2: '0.00',
    LawEnforcementCaseNo: '',
    APSArrestDate: '',
    PASDetainDate: '',
    ProbDetainDate: '',
    TestType: '',
    OrigArrestDetainDate: '',
    DSFieldOffice: '',
    DARResponse: '',
    NextDLNumber: '',
    Error: true
}

const getDropdownList = (listObj, selectedValue, type, date) => {
    
    let list = [];
if(type === 'location')
{
    listObj.map(item => {
        if (item.Value !== "") {
            if (item.Value === selectedValue) {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Text} value={item.Text} selected>{item.Value} - {item.Text}</Option>)
            }
            else {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Text} value={item.Text}>{item.Value} - {item.Text}</Option>)
            }
        }
        return "";
    });
}
else
{
    if(type === 'TestType')
    {
        listObj.map(item => {
            if (item.Value !== "") {
                if (item.Value === 'PA')
                {
                    if(date !== '') {
                    list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}> {item.Value} - {item.Text}</Option>)
                }
            }
                else {
                    list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>)
                }
            }
            return "";
        });
    }
    else
    {
    listObj.map(item => {
        if (item.Value !== "") {
            if (item.Value === selectedValue) {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value} selected> {item.Value} - {item.Text}</Option>)
            }
            else {
                list.push(<Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>)
            }
        }
        return "";
    });
}
}
    return list;
}

class DARUpdate extends Component {
    constructor(props) {
        super(props);

        this.state={
            darObj: cloneDeep(defaultDARObj),
            courtcodeOk: true,
            isNewDL: false,
            APSArrestDate: '',
            PASDetainDate: '',
            ProbDetainDate: '',
            OrigArrestDetainDate: '',
            ErrorMessage: '',
            ErrorObj: {},
            ErrorModalShow: false,
            DLNumber: this.props.match.params.dlNumber
        };
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }  
    componentDidMount()
    {
        
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getDARInitialPage(DLInitData.DLNumber);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
    }
    componentDidUpdate(prevProps){
        
                if ( prevProps.dlUpdates.darInitPageData !== this.props.dlUpdates.darInitPageData && this.props.dlUpdates.darInitPageData !== undefined) {
                    const darObj = cloneDeep(defaultDARObj);
                    darObj['ThreeCharacterName'] = this.props.dlUpdates.darInitPageData.ThreeCharacterName;
                    darObj['BirthDate'] = this.props.dlUpdates.darInitPageData.BirthDate;
                    this.setState({DARInitData: this.props.dlUpdates.darInitPageData, darObj: darObj});
                }
                if ( prevProps.dlUpdates.darUpdateSaveData !== this.props.dlUpdates.darUpdateSaveData && this.props.dlUpdates.darUpdateSaveData !== undefined) {
                    this.setState({DARSaveData: this.props.dlUpdates.darUpdateSaveData, openSuccessModal: true});
                }
                if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                    if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                    {
                        this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                    }
                    else{
                        let Errors = [];
                        Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                            Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                            return "";
                        })
                        this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                    }
                   
                }
                if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                {
                    
                 sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                    const darObj = cloneDeep(defaultDARObj);
                   darObj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                   darObj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
                    this.setState({ darObj: darObj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                } 
            }
            static getDerivedStateFromProps(props, prevState) {
                
                const { darInitPageData, darUpdateSaveData, dlUpdatesErrorData } = props.dlUpdates;
                if (darInitPageData && darInitPageData !== prevState.DARInitData) return { DARInitData: darInitPageData, isloading: false };
                if (darUpdateSaveData && darUpdateSaveData !== prevState.DARSaveData) return { DARSaveData: darUpdateSaveData, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false};
                return null;
            }

            handleFieldChange(e, type) {
                
                const { darObj } = this.state;
                                switch (type) {
                                    case 'ThreeCharacterName':
                                    case 'NextDLNumber':
                                    if (e.target.value.length <= 3) {
                                        darObj[type] = e.target.value;
                                    }
                                    break;
                                    case 'DLNumber':
                                    this.setState({DLNumber: e.target.value});
                                    darObj[type] = e.target.value;
                                        if ((darObj['DLNumber'].length === 8)) {
                                              this.props.getDLInitialData(darObj['DLNumber']);
                                            this.props.getDARInitialPage(darObj['DLNumber']);
                                        }
                                        break;
                    case 'TypeInput':
                    case 'TestType':
                    case 'DSFieldOffice':
                    if(!e)
                    {
                    darObj[type] = '';
                    }
                    else
                    {
                    darObj[type] = e;
                    }
                                break;
                    case 'BAC1':
                    case 'BAC2':
                    if (e.toString().match(/[a-z]/i)) {
                        Modal.error({
                            title: "Error"
                            ,
                            content: (
                              <div>
                                Only numerics allowed.
                              </div>
                            ),
                            onOk() {},
                          });
                         }
                         else
                         {  if(e.toString().includes('.'))
                    { if(e.toString().length < 5) {
                           if(e < 0 || e > 0.6){
                                  // this.setState({WarningMessage: 'Invalid BAC Value. Value should be between 0.00 to 0.60.', WarningModalShow: true});
                                   Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                                   Invalid BAC Value. Value should be between 0.00 to 0.60.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                               }
                               else
                               {
                                    darObj[type] = e.toString();
                               }
                           }
                           else
                           {
                              var es = e.toString();
                               darObj[type] = (parseInt(es.substring(es.length -2),10)/100).toString();
                           }   
                       }
                       else
                       {
                               if((e/100) < 0 || (e/100) > 0.6){
                                     //  this.setState({WarningMessage: 'Invalid BAC Value. Value should be between 0.00 to 0.60.', WarningModalShow: true});
                                       Modal.error({
                                        title: "Error"
                                        ,
                                        content: (
                                          <div>
                                       Invalid BAC Value. Value should be between 0.00 to 0.60.
                                          </div>
                                        ),
                                        onOk() {},
                                      });
                                   }
                                   else
                                   {
                                        darObj[type] = (e/100).toString();
                                   }
                       }   
                    }
            break;
                    case 'CourtCode':
                   { const { value } = e.target;
          const reg = /^[0-9]*$/;
          if ((!isNaN(value) && reg.test(value))) {
            darObj[type] = e.target.value;
          }   }           
                        break;
                    case 'LawEnforcementAgency':
                        if (e.target.value.length <= 25) {
                            darObj[type] = e.target.value;
                        }
                        break;
                    case 'LawEnforcementCaseNo':
                        if (e.target.value.length <= 13) {
                            darObj[type] = e.target.value;
                        }
                        break;
                    default:
                        break;
                }
                this.setState({ darObj });
            }

            onDateChange(d, type) {
                if (type === 'APSArrestDate') {
                    const num = checkYearOfDate(d);
                    if (num >= 1) {
                        this.setState({ APSArrestDate: d });
                        Modal.warning({
                            title: "Warning"
                            ,
                            content: (
                              <div>
                           The keyed in arrest date is more than 1 year from today’s date. Do you wish to continue?
                              </div>
                            ),
                            onOk() {},
                          });
                        return;
                    }
                    else
                    {
                        if(d)
                        {
                            this.setState({ APSArrestDate: d });
                        }
                        else
                        {
                            this.setState({  APSArrestDate: '' });
                        }
                     
                    }
                }
                    else
                    {
            var date = '';  
         if(d)
         {
             d = date;
         }
            switch(type) {
                case 'APSArrestDate':
                this.setState({ APSArrestDate: date });
                break;
                case 'PASDetainDate':
                this.setState({ PASDetainDate: date });
                break;
                case 'ProbDetainDate':
                this.setState({ ProbDetainDate: date });
                break;
                case 'OrigArrestDetainDate':
                this.setState({ OrigArrestDetainDate: date });
                break;
                default:
                break;
            }
        }
        }

            handleModalClose() {
                this.setState({ ErrorModalShow: false, ErrorMessage: '' });
            }
        
            handleUpdate(type) {
                let isNewDL = false;
                if(type === 'new')
                {
          isNewDL = true;
                      sessionStorage.removeItem('dlInitData');   
                    }
                    else
                    {
            isNewDL = false;
                    }
  
                    const { darObj } = this.state;
                  
                    darObj['RequestorCode'] = this.state.DARInitData.RequestorCode;
                    darObj['Operator'] = this.state.DARInitData.Operator;
                    darObj['NetName'] = this.state.DARInitData.NetName;
                    darObj['LoginId'] = this.state.DARInitData.LoginId;
                    if(darObj['DSFieldOffice'] === '')
                    {
                        
                        darObj['DSFieldOffice'] = this.state.DARInitData.DSUserFieldOffice;
                    }
                  if(darObj['BAC1'].includes('.')){  darObj['BAC1'] = (parseFloat(darObj['BAC1'])*100).toString();}
                  if(darObj['BAC2'].includes('.')){   darObj['BAC2'] = (parseFloat(darObj['BAC2'])*100).toString();}
                    darObj['DLNumber'] = this.state.DLNumber;
                    darObj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;

                    darObj['APSArrestDate'] = dateFormatFuncDLUpdates(this.state.APSArrestDate);
                    darObj['PASDetainDate'] = dateFormatFuncDLUpdates(this.state.PASDetainDate);
                    darObj['ProbDetainDate'] = dateFormatFuncDLUpdates(this.state.ProbDetainDate);
                    darObj['OrigArrestDetainDate'] = dateFormatFuncDLUpdates(this.state.OrigArrestDetainDate);
                  
                    this.setState({isloading: true, DLNumber: darObj['DLNumber'], isNewDL: isNewDL});
                   this.props.saveDARUpdate(darObj);
       
            }

            render() {
                
                    const {
                        ThreeCharacterName, DSFieldOffice,
                        TestType, TypeInput, LawEnforcementAgency, CourtCode, BAC1, BAC2, LawEnforcementCaseNo,
                        NextDLNumber
                    } = this.state.darObj;
                    const { DARInitData, DARSaveData, isNewDL, isloading } = this.state;                
            
                    return (
                        // <ScrollPanel style={{ width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0)" }}>
                        <React-Fragment>
                       {isloading !== true ?  <div style={{backgroundColor: "white", marginTop: '1%', width: "95%", marginLeft: '2%'}}> 
                       {DARSaveData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {
                           this.setState({openSuccessModal: false}); 
                           if(DARSaveData.Error === false)
               { if (NextDLNumber !== '') {
                this.props.history.push({
                    pathname: `/${NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                    state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                });
            } 
            else if (isNewDL !== true) {
                            this.props.history.push({
                                pathname: `/dlUpdates`,
                                state: { dlNumber: DARSaveData.DLNumber }
                            })
                        }
                        else {
                            this.setState({
                                darObj: cloneDeep(defaultDARObj),
                                courtcodeOk: true,
                                DLNumber: '',
                                isNewDL: false,
                                APSArrestDate: '',
                                PASDetainDate: '',
                                ProbDetainDate: '',
                                OrigArrestDetainDate: '',
                                ErrorMessage: '',
                                ErrorObj: {},
                                ErrorModalShow: false,                                                    
                            });
                        }
                      
                    }
                        
                        }
                    }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: DARSaveData.DARResponse.toString()}}/></div></Modal>}
                       
                       {DARInitData ?  <Row>
                                <Col span={24}>
                                <div style={{
            border: '1px solid black',
            paddingLeft: "1%",
            textAlign: 'center',
            backgroundColor: '#c9e3fa',
            fontSize: '32px'
            }} >DAR - DUI Audit Tracking</div>
                                <div style= {{margin: '1%'}}>
                                <Form className="ant-advanced-search-form">
                    {isNewDL ? <Row>
                        <Col span={6} style={{ display: 'block' }}>
                        <FormItem
                         hasFeedback
                         validateStatus={ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                         help={ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
            label={<b>DL # </b>}
        >                      
                                <Input size={"small"} style={{width: 'auto'}} value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                        <FormItem
            label={<b>3 Pos Last Name </b>}
        >
                                <Input size={"small"} maxLength={3} style={{width: 'auto'}} value={ThreeCharacterName} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                </FormItem>
                        </Col>
                    </Row>:  <Row>
                    <Col span={5}>
                    <FormItem
                     label={<b>DL #</b>}
                    >
                        {this.state.DLNumber}
                        </FormItem>
                    </Col>
                    <Col span={5} offset={1}>
                    <FormItem
                     label={<b>3 Pos Last Name</b>}
                    >
                     {this.state.ThreeCharacterName}
                     </FormItem>
                    </Col>
                    </Row>}
                                        <Row>
                                            <Col span={5} style={{ padding: '10px' }}>
                                            <FormItem
                              validateStatus = {TypeInput === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TypeInput"] ? 'error' : ""}
                              help = {TypeInput === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TypeInput"]}
                                label={<b>A/C/D  <font color="red">*</font></b>}
                            >
                                       <Select allowClear = {true} id = "AC" onFocus={(e) => {
document.getElementById("AC").click();
                                       }} showSearch optionFilterProp= "children" filterOption = {true} onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                           this.setState({ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                           Modal.error({
                                            title: "Error"
                                            ,
                                            content: (
                                              <div>
                                           Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                              </div>
                                            ),
                                            onOk() {},
                                          });
                                        }}} onChange={e => this.handleFieldChange(e, 'TypeInput')} value={TypeInput}
                                                        showArrow={true} size={"small"} style={{ width: '100%' }}>
                                                        {getDropdownList(DARInitData.TypeInput)}
                                                    </Select></FormItem>
                                            </Col>
                                            <Col span={1} />
                                            <Col span={8} style={{ padding: '10px' }}>
                                            <FormItem
                              validateStatus = {LawEnforcementAgency === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LawEnforcementAgency"] ? 'error' : ""}
                              help = {LawEnforcementAgency === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LawEnforcementAgency"]}
                                label={<b>LE Agency  <font color="red">*</font></b>}
                            >
                                         <Input onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                             this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                             Modal.error({
                                                title: "Error"
                                                ,
                                                content: (
                                                  <div>
                                               Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                                  </div>
                                                ),
                                                onOk() {},
                                              });
                                            }}} placeholder="LE Agency" size={"small"} value={LawEnforcementAgency}
                                                onChange={e => this.handleFieldChange(e, 'LawEnforcementAgency')} />
                                        </FormItem></Col>
                                        </Row>
                                        <Row>
                                        <Col span={5} style={{ padding: '10px' }}>
                                        <FormItem
                              validateStatus = {(CourtCode=== '' || CourtCode.length < 5) && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtCode"] ? 'error' : ""}
                              help = {(CourtCode=== '' || CourtCode.length < 5) && this.state.ErrorObj !== {}  && this.state.ErrorObj["CourtCode"]}
                                label={<b>Court Code  <font color="red">*</font></b>}
                            > <Input maxLength={5} placeholder="Enter 5 digit Court #" onBlur={(e) => {if(CourtCode.length < 5){
                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                            }}} value={CourtCode} size={"small"}
                                                        onChange={e => this.handleFieldChange(e, 'CourtCode')} />
                                                </FormItem></Col><Col span={1}/>
                                                <Col span={8} style={{ padding: '10px' }}>
                                               <FormItem 
                                               label = {<b>BAC </b>}>
                                                                <Col span={8}>
                                                                <InputNumber id="BAC1"  size={"small"} step={0.01} onFocus={(e) => {document.getElementById('BAC1').focus(); document.getElementById('BAC1').select()}} maxLength={4} value={BAC1.includes('.') ? BAC1 : (parseInt(BAC1,10)/100).toString()} style={{ width: '100%' }}
                                                                        onChange={e => this.handleFieldChange(e, 'BAC1')} />
                                                                </Col>
                                                                <Col span={8}>
                                                                <InputNumber id="BAC2"  size={"small"} step={0.01} onFocus={(e) => {document.getElementById('BAC2').focus(); document.getElementById('BAC2').select()}} maxLength={4} value={BAC2.includes('.') ? BAC2 : (parseInt(BAC2,10)/100).toString()} style={{ width: '100%' }}
                                                                        onChange={e => this.handleFieldChange(e, 'BAC2')} />
                                                                </Col>
                                                                </FormItem>
                                                            </Col>
                                                            <Col span={5} style={{ padding: '10px' }}>
                                                            <FormItem
                                label={ <b>LE Case # </b>}
                            > <Input onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                            }}} size={"small"} placeholder="LE Case #" value={LawEnforcementCaseNo}
                                                        onChange={e => this.handleFieldChange(e, 'LawEnforcementCaseNo')} />
                                                </FormItem></Col>
                                        </Row><br />
                                        <Row>   <Col span={6} style={{ padding: '10px' }}>
                                        <FormItem
                                label={ <b>APS Arrest Date </b>}
                            > 

                              <DatePicker
                                                              disabled={this.state.PASDetainDate !== '' || this.state.ProbDetainDate !== ''} 
                                                              onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                                                Modal.error({
                                                                    title: "Error"
                                                                    ,
                                                                    content: (
                                                                      <div>
                                                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                                                      </div>
                                                                    ),
                                                                    onOk() {},
                                                                  });
                                                            }}}
                       className = "CalClass"
                       selected={this.state.APSArrestDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'APSArrestDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                               </FormItem> </Col>
                                                <Col span={1} />
                                                <Col span={6} style={{ padding: '10px' }}>
                                                <FormItem
                                label={ <b>PAS Detain Date </b>}
                            >
                                                    <DatePicker
                                                              disabled={this.state.APSArrestDate !== '' || this.state.ProbDetainDate !== ''} 
                                                              onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                                                Modal.error({
                                                                    title: "Error"
                                                                    ,
                                                                    content: (
                                                                      <div>
                                                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                                                      </div>
                                                                    ),
                                                                    onOk() {},
                                                                  });
                                                            }}}
                       className = "CalClass"
                       selected={this.state.PASDetainDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'PASDetainDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                                </FormItem></Col>
                                                <Col span={1} />
                                                <Col span={6} style={{ padding: '10px' }}>
                                                <FormItem
                                label={ <b>Prob Detain Date </b>}
                            > 
                                                             <DatePicker
                                                              disabled={this.state.PASDetainDate !== '' || this.state.APSArrestDate !== ''} 
                                                              onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                                                Modal.error({
                                                                    title: "Error"
                                                                    ,
                                                                    content: (
                                                                      <div>
                                                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                                                      </div>
                                                                    ),
                                                                    onOk() {},
                                                                  });
                                                            }}}
                       className = "CalClass"
                       selected={this.state.ProbDetainDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ProbDetainDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                     </FormItem> </Col>
                                                <Col span={1} />
                                                <Col span={6} style={{ padding: '10px' }}>
                                                <FormItem
                                                  validateStatus = {TestType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TestType"] ? 'error' : ""}
                                                  help = {TestType === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TestType"]}
                                label={ <b>Type of Test <font color="red">*</font></b>}
                            > <Select allowClear = {true} id = "TT" onFocus={(e) => {
                                document.getElementById("TT").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                            }}} onChange={e => this.handleFieldChange(e, 'TestType')} value={TestType}
                                                        showArrow={true} size={"small"} style={{ width: '100%' }}>
                                                        {getDropdownList(DARInitData.TestType,'','TestType', this.state.PASDetainDate)}
                                                    </Select>
                                             </FormItem>   </Col>
                                                </Row><br />
                                        <Row>
                                        <Col span={8} style={{ padding: '10px' }}>
                                        <FormItem
                                label={ <b>Original Arrest/Detain Date </b>}
                            >
                                                                <DatePicker
                                                              onClick={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                                                Modal.error({
                                                                    title: "Error"
                                                                    ,
                                                                    content: (
                                                                      <div>
                                                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                                                      </div>
                                                                    ),
                                                                    onOk() {},
                                                                  });
                                                            }}}
                       className = "CalClass"
                       selected={this.state.OrigArrestDetainDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigArrestDetainDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                             </FormItem> </Col><Col span={4}/><Col span={5} style={{ padding: '10px' }}>
                                               <FormItem
                                label={ <b>DS Field Office </b>}
                            ><Select allowClear = {true} id = "DFO" onFocus={(e) => {
                                document.getElementById("DFO").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onClick ={(e) => {if(CourtCode.length < 5 && !this.state.courtcodeOk ){
                                this.setState({ ErrorObj: {CourtCode: "Court Code must be 5 digits. If there is no Court Code, please cancel the transaction."}, courtcodeOk: false});
                                Modal.error({
                                    title: "Error"
                                    ,
                                    content: (
                                      <div>
                                   Court Code must be 5 digits. If there is no Court Code, please cancel the transaction.
                                      </div>
                                    ),
                                    onOk() {},
                                  });
                            }}} onChange={e => this.handleFieldChange(e, 'DSFieldOffice')} value={DSFieldOffice || DARInitData.DSUserFieldOffice}
                                                        showArrow={true} size={"small"} style={{ width: '100%' }}>
                                                        {getDropdownList(DARInitData.DSFieldOffices, DARInitData.DSUserFieldOffice, 'location')}
                                                    </Select>
                                                    </FormItem></Col>
                                              </Row>       <br />                            
                                        <Row>
                            <Col  span={10}>
                            <FormItem
                                label={<b>Next Trans  </b>}
                            >
                                <Input style={{width: '30%'}} maxLength = {3} value={NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                            </FormItem>
                        </Col>
                                <Col span={6} offset = {1} style={{ float: 'right' }}>
                                {NextDLNumber !== '' ? <Button disabled
                           type="default">New DL</Button>:<Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                       <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                       <Button style={{ color: "white", backgroundColor: "red" }}
                           type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                           state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                                </Col>
                            </Row>
                            </Form>
                                        </div>
                                </Col>
                            </Row>:<div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                            <Modal visible={this.state.ErrorModalShow}
                            onCancel={(e) => this.setState({ErrorModalShow: false})}
                                title={'Error message'} maskClosable={false}
                                footer={[
                                    <div>
                                        <Button type="primary" key="Ok" onClick={(e) => 
                                        {
                                            this.setState({ErrorModalShow: false});
                                            if( !this.state.ErrorObj )
                                            {
                                                if(isNewDL === true)
                                                {
                                                this.setState({ dasObj: cloneDeep(defaultDARObj),
                                                    darObj: cloneDeep(defaultDARObj),
                                                    courtcodeOk: true,
                                                    isNewDL: false,
                                                    DLNumber: "",
                                                    APSArrestDate: '',
                                                    PASDetainDate: '',
                                                    ProbDetainDate: '',
                                                    OrigArrestDetainDate: '',
                                                    ErrorMessage: '',
                                                    ErrorObj: {},
                                                    ErrorModalShow: false,
                                                });
                                            }
                                            else if(NextDLNumber !== '')
                                            {
                                                this.props.history.push({ pathname: `/${NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                                state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                            } 
                                            else{
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }  
                                    }
                                }     
                                            }>Ok</Button>
                                    </div>
                                ]}
                            >
                               {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                            </Modal> 
                            {/* <Modal visible={this.state.WarningModalShow}
                            onCancel={(e) => this.setState({WarningModalShow: false})}
                                title={'Warning message'} maskClosable={false}
                                footer={[
                                    <div>
                                               <Button type="default" key="Ok" onClick={(e) => this.setState({ WarningModalShow: false})}>OK</Button>
                                    </div>
                                ]}
                            >
                               {this.state.WarningMessage}
                            </Modal> */}
                            </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                        {/* </ScrollPanel > */}
                        </React-Fragment>
                    );
            }
            }
            
            const mapStateToProps = state => {
                return {
                  dlUpdates: state.dlUpdates
                };
            };
            
            const mapDispatchToProps = dispatch => {
                return bindActionCreators(
                    {
                       getDARInitialPage, 
                        saveDARUpdate, getDLInitialData
                    },
                    dispatch
                );
            };
            
            export default connect(mapStateToProps, mapDispatchToProps)(DARUpdate);
            