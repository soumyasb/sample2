import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Modal, Spin } from 'antd';
import { getDANInitialPage, saveDANUpdate, getDLInitialData
 } from "../../../store/actions/dlUpdatesActions";
import { dateFormatFunc, dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    BirthDate: '',
    TypeAction: '10',
    EffectiveDate: '',
    MailDate: '',
    OrigAuthoritySection: '',
    OrigEffectiveDate: '',
    UpdateCopies: '',
    CoFo: '',
    DANResponse: '',
    NextDLNumber: '',
    Error: true
};

class DANUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            EffectiveDate: "",
            MailDate: "",
            OrigEffectiveDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }
    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
         const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDANInitialPage(DLInitData.DLNumber);
        }
        else 
        {
            this.props.history.push(`/dlUpdates`);
        }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.danInitPageData !== this.props.dlUpdates.danInitPageData && this.props.dlUpdates.danInitPageData !== undefined) {
                                const Obj = cloneDeep(defaultObj);
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.danInitPageData.ThreeCharacterName;
                                Obj['BirthDate'] = this.props.dlUpdates.danInitPageData.BirthDate;
                                this.setState({danInitPageData: this.props.dlUpdates.danInitPageData, Obj: Obj});
                            }
                            if ( prevProps.dlUpdates.danUpdateSaveData !== this.props.dlUpdates.danUpdateSaveData && this.props.dlUpdates.danUpdateSaveData !== undefined) {
                                this.setState({danUpdateSaveData: this.props.dlUpdates.danUpdateSaveData, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                               Obj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { danInitPageData, danUpdateSaveData, dlUpdatesErrorData, dlInitData } = props.dlUpdates;
                if (danInitPageData && danInitPageData !== prevState.danInitPageData)
                {
                    return { danInitPageData: danInitPageData, isloading: false };
                } 
                if (dlInitData && dlInitData !== prevState.dlInitData)
                {
                    
                    sessionStorage.getItem('dlInitData') !== undefined && sessionStorage.setItem('dlInitData', JSON.stringify(dlInitData)); 
                    return { dlInitData: dlInitData, DLNumber: dlInitData.DLNumber, ThreeCharacterName: dlInitData.ThreeCharacterName, BirthDate: dlInitData.Birthdate, isloading: false };
                } 
                if (danUpdateSaveData && danUpdateSaveData !== prevState.danUpdateSaveData) return { danUpdateSaveData: danUpdateSaveData, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false };
                return null;
            }
    handleFieldChange(e, field) {
   
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                    this.props.getDANInitialPage(Obj['DLNumber']);
                }
                break;
            case 'TypeAction':
            case 'CoFo':
            case 'UpdateCopies':
            case 'OrigAuthSect':
            if(!e)
            {
            Obj[field] = '';
            }
            else
            {
            Obj[field] = e;
            }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {
        const { Obj } = this.state;
        Obj[type] = d || '';
        switch(type) {
            case 'EffectiveDate':
            this.setState({ Obj: Obj, EffectiveDate: d });
            break;
            case 'MailDate':
            this.setState({ Obj: Obj, MailDate: d });
            break;
            case 'OrigEffectiveDate':
            this.setState({ Obj: Obj, OrigEffectiveDate: d });
            break;
            default:
            break;
        }
    }
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
     
        const { Obj } = this.state;

        Obj['RequestorCode'] = this.state.danInitPageData.RequestorCode;
        Obj['Operator'] = this.state.danInitPageData.Operator;
        Obj['NetName'] = this.state.danInitPageData.NetName;
        Obj['LoginId'] = this.state.danInitPageData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        if(typeof this.state.BirthDate === 'string')
        {
            Obj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
        }
      else
      {
        Obj['BirthDate'] = dateFormatFuncDLUpdates(this.state.BirthDate);
      }
 Obj['EffectiveDate'] = dateFormatFuncDLUpdates(this.state.EffectiveDate);
   Obj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
     Obj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
        this.props.saveDANUpdate(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { danInitPageData, danUpdateSaveData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
                 {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
               {danUpdateSaveData && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false}); 
               if(danUpdateSaveData.Error === false)
               {  if(Obj.NextDLNumber !== '')
               {
                   this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                   state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
               }
               else if(isNewDL !== true ) {
                   this.props.history.push({ pathname: `/dlUpdates`,
            state: {dlNumber: danUpdateSaveData.DLNumber}})}
            else
            {
                this.setState({Obj: cloneDeep(defaultObj),
                    EffectiveDate: "",
                    OrigEffectiveDate: "",
                    DLNumber: '',
                    BirthDate: '',
                    ErrorObj: {},
                    ErrorMessage: '',
                    ErrorModalShow: false
                });
            }
        }
}
               }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: danUpdateSaveData.DANResponse.toString()}}/>
          </div></Modal>}
            {danInitPageData ?   
              <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >DL/ID Cancellation (DAN)</div>
                <Form className="ant-advanced-search-form">
                {isNewDL ? <Row>
                        <Col span={6} style={{ display: 'block' }}>
                            <FormItem
                              hasFeedback
                              validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                              help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                label={<b>DL # </b>}
                            >
                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                label={<b>3 Pos Last Name </b>}
                            >
                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1} style={{ height: '39px' }} >
                            <FormItem
                                label={<b>Birth Date </b>}
                            >
                              
<DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>:
               <Row>
                               <Col span={5}>
                               <FormItem
                                label={<b>DL #</b>}
                            >
                                   {this.state.DLNumber}
                                   </FormItem>
                               </Col>
                               <Col span={5} offset={1}>
                               <FormItem
                                label={<b>3 Pos Last Name</b>}
                            >
                                {this.state.ThreeCharacterName}
                                </FormItem>
                               </Col>
                               <Col span={6} offset={1} >
                            <FormItem
                                label={<b>Birth Date </b>}
                            >
                             {this.state.BirthDate}
                                   </FormItem>
                               </Col>
                           </Row>
               }
                    <Row>
                        <Col span={6}>
                            <FormItem
                                 validateStatus = {Obj.TypeAction === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TypeAction"] ? 'error' : ""}
                                 help = {Obj.TypeAction === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["TypeAction"]}
                                label={<b>Type Action <font color="red">*</font></b>}
                            >
                                <Select allowClear= {true} id = "STAD" onFocus={(e) => {
                                document.getElementById("STAD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'TypeAction')}
                                    value={Obj.TypeAction} showArrow={true} size={"default"}
                                >
                                       {danInitPageData.TypeAction.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.EffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EffectiveDate"] ? 'error' : ""}
                                 help = {this.state.EffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["EffectiveDate"]}
                                label={<b>Effective Date </b>}
                            >
                               {/* <DatePicker placeholder="Select Date"
                                       value={this.state.EffectiveDate !== "" ? this.state.EffectiveDate : null} format={dateFormat} onChange={(d, ds) => { this.onDateChange(d, ds, 'EffectiveDate') }} /> */}
                            <DatePicker
                       className = "CalClass"
                       selected={this.state.EffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={6}>
                            <FormItem
                                 validateStatus = {Obj.OrigAuthSect === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigAuthSect"] ? 'error' : ""}
                                 help = {Obj.OrigAuthSect === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigAuthSect"]}
                                label={<b>Orig Auth Section </b>}
                            >
                                <Select allowClear= {true} id = "SOADA" onFocus={(e) => {
                                document.getElementById("SOADA").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}   onChange={e => this.handleFieldChange(e, 'OrigAuthSect')}
                                    value={Obj.OrigAuthSect} showArrow={true} size={"default"}
                                >
                                      {danInitPageData.OriginalAuthoritySection.map((oas) =>
                                        {
                                            return <Option title={`${oas.Value} - ${oas.Text}`} key={oas.Value} value={oas.Value}>{oas.Value} - {oas.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigEffectiveDate"] ? 'error' : ""}
                                 help = {this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OrigEffectiveDate"]}
                                label={<b>Orig Effec Date </b>}
                            >
                                     {/* <DatePicker placeholder="Select Date"
                                       value={this.state.OrigEffectiveDate !== "" ? this.state.OrigEffectiveDate : null} format={dateFormat} onChange={(d, ds) => { this.onDateChange(d, ds, 'OrigEffectiveDate') }} /> */}
                          <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1}>
                            <FormItem
                                 validateStatus = {this.state.MailDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailDate"] ? 'error' : ""}
                                 help = {this.state.MailDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailDate"]}
                                label={<b>Mail Date </b>}
                            >
                                  {/* <DatePicker placeholder="Select Date"
                                       value={this.state.MailDate !== "" ? this.state.MailDate : null} format={dateFormat} onChange={(d, ds) => { this.onDateChange(d, ds, 'MailDate') }} /> */}
                                       <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                            </FormItem>
                        </Col>                       
                    </Row>
                    <Row><Col span={6}>
                            <FormItem
                                 validateStatus = {Obj.UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                                 help = {Obj.UpdateCopies === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UpdateCopies"]}
                                label={<b>Update Copies </b>}
                            >
                                <Select allowClear= {true} id = "SUCDA" onFocus={(e) => {
                                document.getElementById("SUCDA").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}   onChange={e => this.handleFieldChange(e, 'UpdateCopies')}
                                    value={Obj.UpdateCopies} showArrow={true} size={"default"}
                                >
                                    {danInitPageData.UpdateCopies.map((item) =>
                                        {
                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={6} offset={1} >
                            <FormItem
                                 validateStatus = {Obj.CoFo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CoFo"] ? 'error' : ""}
                                 help = {Obj.CoFo === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CoFo"]}
                                label={<b>Co / Fo </b>}
                            >
                                <Select allowClear= {true} id = "SCoFoDA" onFocus={(e) => {
                                document.getElementById("SCoFoDA").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  style={{width: '80%'}} onChange={e => this.handleFieldChange(e, 'CoFo')}
                                    value={Obj.CoFo} showArrow={true} size={"default"}
                                >
                                  {danInitPageData.CoFo.map((cf) =>
                                        {
                                            return <Option title={`${cf.Value} - ${cf.Text}`} key={cf.Value} value={cf.Value}>{cf.Value} - {cf.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                            </Col></Row>
                    <Row>
                        <Col span={20}>
                            <FormItem
                                 validateStatus = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                 help = {Obj.NextDLNumber === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["NextDLNumber"]}
                                label={<b>Next Trans </b>}
                            >
                                <Input style={{width: '20%'}} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={4} style={{ float: 'right' }}>
                        {Obj.NextDLNumber !== '' ? <Button disabled
                           type="default">New DL</Button>: <Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                            <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                            <Button style={{ color: "white", backgroundColor: "red" }}
                                type="default" key="Cancel" onClick={(e) =>
                                    {
                                    this.props.history.push({ pathname: `/dlUpdates`,
                                state: {dlNumber: this.state.DLNumber}})
                                    }
                            }>Cancel</Button>
                        </Col>
                    </Row>
                </Form></div>  : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                            {
                                this.setState({ErrorModalShow: false});
                                if( !this.state.ErrorObj )
                                {
                                    if(isNewDL === true)
                                    {
                                        this.setState({Obj: cloneDeep(defaultObj),                                        
                                            EffectiveDate: "",
                                            DLNumber: "",
                                            BirthDate: "", 
                                            OrigEffectiveDate: "",
                                            ThroughDate: "",
                                            HearingDate:"",
                                            ModifiedHearingDate: "",
                                            ErrorObj: {},
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                    else  if(Obj.NextDLNumber !== '')
                                    {
                                        this.props.history.push({ pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                        state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                    }  
                                   else {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }
                        }}>Ok</Button>
                        </div>
                    ]}
                >
                  {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            </React-Fragment>
            );
    }
}
    
const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDANInitialPage, saveDANUpdate,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DANUpdate); 