import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDIXInitialPage, assignXNumber, getANITransactionData, getA04TransactionData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    LastName: '',
    FirstName: '',
    MiddleName: '',
    Suffix: '',
    FullName: '',
    BirthDate: '',
    Age: '',
    Address: '',
    City: '',
    State: '',
    Zip: '',
    CountyCode: '',
    MailAddressDate: '',
    DIXResponse: '',
    NextDLNumber: '',
    Error: true
};

class DIXUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            Obj: cloneDeep(defaultObj),
            ErrorObj: {},
            MailAddressDate: "",
            BirthDate: "",
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
    }

    componentDidMount() {
            this.props.getDIXInitialPage();
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.dixInitPageData !== this.props.dlUpdates.dixInitPageData && this.props.dlUpdates.dixInitPageData !== undefined) {
            const Obj = cloneDeep(defaultObj);
            this.setState({DIXInitPageData: this.props.dlUpdates.dixInitPageData, Obj: Obj});
        }
        if (prevProps.dlUpdates.assignXNumberData !== this.props.dlUpdates.assignXNumberData && this.props.dlUpdates.assignXNumberData !== undefined) {
            this.setState({ assignXNumberData: this.props.dlUpdates.assignXNumberData, openSuccessModal: true });
        }
        if (prevProps.dlUpdates.aniTransData !== this.props.dlUpdates.aniTransData && this.props.dlUpdates.aniTransData !== undefined) {
            this.setState({ aniTransData: this.props.dlUpdates.aniTransData, openSuccessModal: true });
        }
        if (prevProps.dlUpdates.a04TransData !== this.props.dlUpdates.a04TransData && this.props.dlUpdates.a04TransData !== undefined) {
            this.setState({ a04TransData: this.props.dlUpdates.a04TransData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
            }
            else{
                let Errors = [];
                Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                    Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }
        }
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DIXInitPageData, assignXNumberData, dlUpdatesErrorData, aniTransData, a04TransData } = props.dlUpdates;
        if (DIXInitPageData && DIXInitPageData !== prevState.DIXInitPageData) {
            return { DIXInitPageData: DIXInitPageData, isloading: false };
        }
        if (assignXNumberData && assignXNumberData !== prevState.assignXNumberData)
            return {
                assignXNumberData: assignXNumberData,
                isloading: false
            };
            if (aniTransData && aniTransData !== prevState.aniTransData)
            return {
                aniTransData: aniTransData,
                isloading: false
            };
            if (a04TransData && a04TransData !== prevState.a04TransData)
            return {
                a04TransData: a04TransData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'LastName':
            case 'FirstName':
            case 'MiddleName':
            case 'Suffix':
            case 'FullName':
            case 'Address':
            case 'City':
            case 'State':
            case 'Zip':
                Obj[field] = e.target.value;
            break;
            case 'CountyCode':
            case 'Age':
            { const { value } = e.target;
            const reg = /^[0-9]*$/;
            if ((!isNaN(value) && reg.test(value))) {
              Obj[field] = e.target.value;
            }   }      break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    
    onDateChange(d, type) {
        switch(type) {
            case 'MailAddressDate':
            this.setState({ MailAddressDate: d });
            break;
            case 'BirthDate':
            this.setState({ BirthDate: d });
            break;
            default:
            break;
        }
    }

    handleUpdate(type) {
        const { Obj } = this.state;
        Obj['LoginId'] = this.state.DIXInitPageData.LoginId;
        Obj['RequestorCode'] = this.state.DIXInitPageData.RequestorCode;
        Obj['Operator'] = this.state.DIXInitPageData.Operator;
        Obj['MailAddressDate'] = dateFormatFuncDLUpdates(this.state.MailAddressDate);
        Obj['BirthDate'] = dateFormatFuncDLUpdates(this.state.BirthDate);
        this.setState({ isloading: true });
        switch(type)
        {
        case "Assign":
        this.props.assignXNumber(Obj);
        break;
        case "ANI":
        this.props.getANITransactionData(Obj);
        break;
        case "A04":
        this.props.getA04TransactionData(Obj);
        break;
        default:
        break;
    }
    }

    render() {
        const { Obj } = this.state;
        const { DIXInitPageData, assignXNumberData, isloading } = this.state;
        return (
            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {assignXNumberData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: this.state.DLNumber }
                                    })
                                }
                            }
                            >OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: assignXNumberData.DIXResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DIXInitPageData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Assign X Number (DIX)</div>
                            <Form className="ant-advanced-search-form">
                                <Row>
<Col span={6} style={{height : "50px"}}>
<FormItem
 validateStatus = {Obj.LastName === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LastName"] ? 'error' : ""}
 help = {Obj.LastName === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["LastName"]}
                                 label={<b>Last Name <font color="red">*</font></b>}
                             >
                             <Input size={"small"} maxLength={35} placeholder="Last Name"
                                        value={Obj.LastName} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'LastName')} />                                 
                               </FormItem>
</Col>
<Col span={6} offset={1} style={{height : "50px"}}>
<FormItem
validateStatus = {Obj.FirstName === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["FirstName"] ? 'error' : ""}
help = {Obj.FirstName === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["FirstName"]}
                                 label={<b>First Name <font color="red">*</font></b>}
                             >
                             <Input size={"small"} maxLength={35} placeholder="First Name"
                                        value={Obj.FirstName} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'FirstName')} />                                 
                               </FormItem>
</Col>
<Col span={6} offset={1} style={{height : "50px"}}>
<FormItem
                                 label={<b>Middle Name</b>}
                             >
                             <Input size={"small"} maxLength={35} placeholder="Middle Name"
                                        value={Obj.MiddleName} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'MiddleName')} />                                 
                               </FormItem>
</Col>
</Row>
<Row>
<Col span={6} style={{height : "50px"}}>
<FormItem
                                 label={<b>Suffix</b>}
                             >
                             <Input size={"small"} maxLength={35} placeholder="Suffix"
                                        value={Obj.Suffix} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'Suffix')} />                                 
                               </FormItem>
</Col>
<Col span={6} offset={1} style={{height : "50px"}}>
<FormItem
 validateStatus = {Obj.BirthDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["BirthDate"] ? 'error' : ""}
 help = {Obj.BirthDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["BirthDate"]}
                                 label={<b>Birth Date <font color="red">*</font></b>}
                             >
  <DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />                               
                               </FormItem>
</Col>
<Col span={6} offset={1} style={{height : "50px"}}>
<FormItem
                                 label={<b>Age</b>}
                             >
                             <Input size={"small"} maxLength={3} placeholder="Age"
                                        value={Obj.Age} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'Age')} />                                 
                               </FormItem>
</Col>
</Row>
<Row>
<Col span={16} style={{height : "50px"}}>                        
                        <FormItem
                        validateStatus = {Obj.Address === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Address"] ? 'error' : ""}
                        help = {Obj.Address === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Address"]}
                           label={<b>Address <font color="red">*</font></b>}
                       ><Input size={"small"} maxLength={35} placeholder="Address"
                                        value={Obj.Address} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'Address')} />
                                </FormItem></Col>
    </Row>
<Row>                 <Col span={4} style={{height : "50px"}}>
                                <FormItem
                                  validateStatus = {Obj.City === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["City"] ? 'error' : ""}
                                  help = {Obj.City === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["City"]}
                                 label={<b>City <font color="red">*</font></b>}
                             >
                                 <Input size={"small"} maxLength={13} placeholder="Mail City" value={Obj.City} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'City')} />
                               </FormItem>
                                </Col>
                                <Col span={3} offset={1} style={{height : "50px"}}>
                                <FormItem
                                  validateStatus = {Obj.State === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["State"] ? 'error' : ""}
                                  help = {Obj.State === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["State"]}
                                 label={<b>State </b>}
                             >
                                 <Input size={"small"} maxLength={2} placeholder="State" value={Obj.State} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'State')} />
                               </FormItem>
                                </Col>
                                <Col span={3} style={{height : "50px"}} offset={1}>
                                <FormItem
                                 validateStatus = {Obj.Zip === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Zip"] ? 'error' : ""}
                                 help = {Obj.Zip === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Zip"]}
                                 label={<b>Zip </b>}
                             >
                                         <Input size={"small"} maxLength={5} placeholder="Zip" value={Obj.Zip} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'Zip')} />    
                               </FormItem>
                                </Col>
                                <Col style={{height : "50px"}} span={3} offset={1}>
                                <FormItem
                                 validateStatus = {Obj.CountyCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CountyCode"] ? 'error' : ""}
                                 help = {Obj.CountyCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CountyCode"]}
                                 label={<b>Country Cd </b>}
                             >
                                         <Input size={"small"} maxLength={2} placeholder="County Code" value={Obj.CountyCode} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'CountyCode')} />    
                               </FormItem>
                                </Col>
                                </Row><Row>
                                <Col style={{height : "50px"}} span={6}>
                                <FormItem
                                 validateStatus = {Obj.MailAddressDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailAddressDate"] ? 'error' : ""}
                                 help = {Obj.MailAddressDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailAddressDate"]}
                                 label={<b>Mail Addr Date <font color="red">*</font></b>}
                             >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.MailAddressDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailAddressDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                               </FormItem>
                                </Col>
                                </Row>   
                                <Row>
                                    <Col style={{height : "50px"}} span={14}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input maxLength={3} style={{ width: '20%' }} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={10} style={{ float: 'right', height : "50px" }}>  
                                    <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="ANI" onClick={(e) => this.handleUpdate('ANI')}>ANI</Button> {' '}                              
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="A04" onClick={(e) => this.handleUpdate('A04')}>A04</Button> {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('Assign')}>Assign X#</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                           
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if (typeof this.state.ErrorMessage === 'string' && this.state.ErrorMessage.includes(" RandomMathNumber"))
                                    { 
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});    
                                }     
                                }}>Ok</Button>
                            </div>
                        ]}
                    >
                         {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDIXInitialPage, assignXNumber, getANITransactionData, getA04TransactionData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DIXUpdate); 