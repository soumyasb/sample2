import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Radio, Select, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDUXData, saveDUXData, getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;
const RadioGroup = Radio.Group;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    HearingType: '',
    HearingDate: '',
    HearingLocation: '',
    HearingReason: '',
    HearingResult: '',
    ModifiedHearingDate: '',
    AuthoritySection: '',
    EffectiveDate: '',
    UpdateCopies: '',
    OrigAuthoritySection: '',
    OrigEffectiveDate: '',
    CoFo: '',
    PMOption: 'N',
    PMCode: '',
    RestrictionsOptions: 'N',
    Restriction1: '',
    Restriction2: '',
    Restriction3: '',
    InsertParagraph: '',
    RouteCode: '',
    CountyCode: '',
    duxResponse: '',
    DUXResponse: '',
    NextDLNumber: '',
    Error: true
};

class DUXUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            Obj: cloneDeep(defaultObj),
            isNewDL: false,
            ModifiedHearingDate: '',
            EffectiveDate: '',
            HearingDate: '',
            MailDate: '',
            OrigEffectiveDate: '',
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }

    componentDidMount() {
        if(this.props.match.params.dlNumber !== undefined)
        {
            this.props.getDLInitialData(this.props.match.params.dlNumber);
            this.props.getDUXData(this.props.match.params.dlNumber);
        }
        else
        {
            if (sessionStorage.getItem('dlInitData')) {
                const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
                this.setState({
                    DLNumber: DLInitData.DLNumber,
                    ThreeCharacterName: DLInitData.ThreeCharacterName,
                    BirthDate: DLInitData.Birthdate
                });
                this.props.getDUXData(DLInitData.DLNumber);
            }
            else {
                this.props.history.push(`/dlUpdates`);
            }
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DUXInitData !== this.props.dlUpdates.DUXInitData && this.props.dlUpdates.DUXInitData !== undefined) {
            const Obj = cloneDeep(defaultObj);
            Obj['ThreeCharacterName'] = this.props.dlUpdates.DUXInitData.ThreeCharacterName;
            this.setState({DUXInitData: this.props.dlUpdates.DUXInitData, Obj: Obj});
        }
        if (prevProps.dlUpdates.saveDUXData !== this.props.dlUpdates.saveDUXData && this.props.dlUpdates.saveDUXData !== undefined) {
            this.setState({ saveDUXData: this.props.dlUpdates.saveDUXData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
            }
            else{
                let Errors = [];
                Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                    Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isLoading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DUXInitData, saveDUXData, dlUpdatesErrorData } = props.dlUpdates;
        if (DUXInitData && DUXInitData !== prevState.DUXInitData) {
            return { DUXInitData: DUXInitData, isloading: false };
        }
        if (saveDUXData && saveDUXData !== prevState.saveDUXData)
            return {
                saveDUXData: saveDUXData,
                isloading: false
            };
            
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'DLNumber':
            case 'ThreeCharacterName':
                Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                    this.props.getDUXData(Obj['DLNumber']);
                }
                break;
            case 'RouteCode':
                if (e.target.value.match(/^[0-9]+$/)) {
                    if (e.target.value.length <= 4) {

                        Obj[field] = e.target.value;
                    }
                }
                break;
            case 'CountyCode':
                if (e.target.value.match(/^[0-9]+$/)) {
                    if (e.target.value.length <= 2) {

                        Obj[field] = e.target.value;
                    }
                }
                break;
            case 'NextDLNumber':
                if (e.target.value.length <= 3) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'HearingType':
            case 'HearingLocation':
            case 'HearingResult':
            case 'HearingReason':
            case 'AuthoritySection':
            case 'UpdateCopies':
            case 'Restriction1':
            case 'Restriction2':
            case 'Restriction3':
            case 'PMCode':
            case 'LicenseLocation':
            case 'OrigAuthoritySection':
            case 'InsertParagraph':
            case 'CoFo':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            case 'TypeInput':
            case 'PMOption':
            case 'RestrictionsOptions':
                Obj[field] = e.target.value;
                if( field === 'PMOption' && e.target.value === 'N')
                {
                    Obj.PMCode = '';
                }
                if( field === 'RestrictionsOptions' && e.target.value === 'N')
                {
                    Obj.Restriction1 = '';
                    Obj.Restriction2 = '';
                    Obj.Restriction3 = '';
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {

        switch (type) {
            case 'ModifiedHearingDate':
                this.setState({ ModifiedHearingDate: d });
                break;
            case 'EffectiveDate':
                this.setState({ EffectiveDate: d });
                break;
            case 'HearingDate':
                this.setState({ HearingDate: d });
                break;
            case 'MailDate':
                this.setState({ MailDate: d });
                break;
            case 'OrigEffectiveDate':
                this.setState({ OrigEffectiveDate: d });
                break;
            default:
                break;
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        var isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }

        const { Obj } = this.state;

        Obj['LoginId'] = this.state.DUXInitData.LoginId;
        Obj['RequestorCode'] = this.state.DUXInitData.RequestorCode;
        Obj['Operator'] = this.state.DUXInitData.Operator;
        Obj['NetName'] = this.state.DUXInitData.NetName;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['EffectiveDate'] = dateFormatFuncDLUpdates(this.state.EffectiveDate);
        Obj['HearingDate'] = dateFormatFuncDLUpdates(this.state.HearingDate);
        Obj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
        Obj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
        Obj['ModifiedHearingDate'] = dateFormatFuncDLUpdates(this.state.ModifiedHearingDate);

        this.setState({ isloading: true, DLNumber: Obj['DLNumber'], isNewDL });
         this.props.saveDUXData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUXInitData, saveDUXData, isNewDL, isloading } = this.state;

        return (
            // <ScrollPanel
            //     style={{
            //         width: "100%",
            //         height: "100%",
            //         backgroundColor: "rgba(0,0,0,0)"
            //     }}
            // >
            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {saveDUXData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDUXData.Error === false)
               {  if (Obj.NextDLNumber !== '') {
                this.props.history.push({
                    pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                    state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                });
            }
            else if (isNewDL !== true) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDUXData.DLNumber }
                                    })
                                }
                                else {
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                      
                                        DLNumber: "",
                                        ModifiedHearingDate: '',
                                        EffectiveDate: '',
                                        HearingDate: '',
                                        MailDate: '',
                                        OrigEffectiveDate: '',
                                        ErrorObj: {},
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                } 
                            }}
                        }>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDUXData.DUXResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DUXInitData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Set Aside/End Action (DUX)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={6} style={{ display: 'block' }}>
                                            <FormItem
                                             hasFeedback
                                             validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                             help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={6}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }
                                <Row>
                                    <Col span={20}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Hearing Information</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingType === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingType"] ? 'error' : ""}
                                                        help={Obj.HearingType === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingType"]}
                                                        label={<b> Type </b>}
                                                    >
                                                        <Select allowClear = {true} id = "STypDUX" onFocus={(e) => {
                                document.getElementById("STypDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingType')}
                                                            value={Obj.HearingType} showArrow={true} size={"default"}
                                                        >
                                                            {DUXInitData.ChgHearingType.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>
                                                    <Row>
                                                        <Col span={11}>
                                                            <FormItem
                                                                validateStatus={this.state.HearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingDate"] ? 'error' : ""}
                                                                help={this.state.HearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingDate"]}
                                                                label={<b> Date </b>}
                                                            >
                                                               <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                      </FormItem>
                                                        </Col>
                                                        <Col span={12} offset={1}>
                                                            <FormItem
                                                                validateStatus={this.state.ModifiedHearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ModifiedHearingDate"] ? 'error' : ""}
                                                                help={this.state.ModifiedHearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ModifiedHearingDate"]}
                                                                label={<b> Mod Date </b>}
                                                            >
                                                               <DatePicker
                       className = "CalClass"
                       selected={this.state.ModifiedHearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ModifiedHearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />  </FormItem>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingLocation"] ? 'error' : ""}
                                                        help={Obj.HearingLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingLocation"]}
                                                        label={<b> Location </b>}
                                                    >
                                                        <Select allowClear = {true} id = "SLocDUX" onFocus={(e) => {
                                document.getElementById("SLocDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingLocation')}
                                                            value={Obj.HearingLocation} showArrow={true} size={"default"}
                                                        >
                                                            {DUXInitData.Locations.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingReason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingReason"] ? 'error' : ""}
                                                        help={Obj.HearingReason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingReason"]}
                                                        label={<b> Reason </b>}
                                                    >
                                                        <Select allowClear = {true} id = "SReaDUX" onFocus={(e) => {
                                document.getElementById("SReaDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingReason')}
                                                            value={Obj.HearingReason} showArrow={true} size={"default"}
                                                        >
                                                            {DUXInitData.Reasons.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingResult === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingResult"] ? 'error' : ""}
                                                        help={Obj.HearingResult === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingResult"]}
                                                        label={<b> Result </b>}
                                                    >
                                                        <Select allowClear = {true} id = "SResDUX" onFocus={(e) => {
                                document.getElementById("SResDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingResult')}
                                                            value={Obj.HearingResult} showArrow={true} size={"default"}
                                                        >
                                                            {DUXInitData.HearingResults.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>

                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col span={9}>
                                        <FormItem
                                            validateStatus={Obj.AuthoritySection === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection"] ? 'error' : ""}
                                            help={Obj.AuthoritySection === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection"]}
                                            label={<b> Authority Section </b>}
                                        >
                                            <Select allowClear = {true} id = "SASDUX" onFocus={(e) => {
                                document.getElementById("SAUSDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthoritySection')}
                                                value={Obj.AuthoritySection} showArrow={true} size={"default"}
                                            >
                                                {DUXInitData.AuthoritySection.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.EffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["EffectiveDate"] ? 'error' : ""}
                                            help={this.state.EffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["EffectiveDate"]}
                                            label={<b> Effective Date </b>}
                                        >
                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.EffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /></FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.UpdateCopies === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                                            help={Obj.UpdateCopies === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["UpdateCopies"]}
                                            label={<b> Update Copies </b>}
                                        >
                                            <Select allowClear = {true} id = "SUCDUX" onFocus={(e) => {
                                document.getElementById("SUCDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'UpdateCopies')}
                                                value={Obj.UpdateCopies} showArrow={true} size={"default"}
                                            >
                                                {DUXInitData.UpdateCopies.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={9}>
                                        <FormItem
                                            validateStatus={Obj.OrigAuthoritySection === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigAuthoritySection"] ? 'error' : ""}
                                            help={Obj.OrigAuthoritySection === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigAuthoritySection"]}
                                            label={<b>Orig Authority Section</b>}
                                        >
                                            <Select allowClear = {true} id = "SOASDUX" onFocus={(e) => {
                                document.getElementById("SOASDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OrigAuthoritySection')}
                                                value={Obj.OrigAuthoritySection} showArrow={true} size={"default"}
                                            >
                                                {DUXInitData.OriginalAuthoritySection.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigEffectiveDate"] ? 'error' : ""}
                                            help={this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigEffectiveDate"]}
                                            label={<b> Orig Effec Date </b>}
                                        >
                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.CoFo === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CoFo"] ? 'error' : ""}
                                            help={Obj.CoFo === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CoFo"]}
                                            label={<b>Co /Fo</b>}
                                        >
                                            <Select allowClear = {true} id = "SCoFoDUX" onFocus={(e) => {
                                document.getElementById("SCoFoDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CoFo')}
                                                value={Obj.CoFo} showArrow={true} size={"default"}
                                            >
                                                {DUXInitData.CoFo.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={12}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Restriction</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col offset={2}>
                                                    <RadioGroup name="RestrictionsOptions" value={Obj.RestrictionsOptions} onChange={e => this.handleFieldChange(e, 'RestrictionsOptions')}>
                                                        <Radio value={'N'}>N/A</Radio>
                                                        <Radio value={'A'}>Add</Radio>
                                                        <Radio value={'D'}>Delete</Radio>
                                                    </RadioGroup>
                                                </Col>
                                            </Row>
                                            <br />
                                            <Row>
                                                <Col span={22} offset={1}>
                                                    <FormItem
                                                        validateStatus={Obj.Restriction1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction1"] ? 'error' : ""}
                                                        help={Obj.Restriction1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction1"]}
                                                        label={'1:'}
                                                    >
                                                        <Select allowClear = {true} id = "SRestDUX" onFocus={(e) => {
                                document.getElementById("SRestDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Restriction1')}
                                                            value={Obj.Restriction1} showArrow={true} size={"default"}
                                                            disabled={Obj.RestrictionsOptions === 'N'}
                                                        >
                                                            {DUXInitData.Restrictions1.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                    <FormItem
                                                        validateStatus={Obj.Restriction2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction2"] ? 'error' : ""}
                                                        help={Obj.Restriction2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction2"]}
                                                        label={'2:'}
                                                    >
                                                        <Select allowClear = {true} id = "SRest2DUX" onFocus={(e) => {
                                document.getElementById("SRest2DUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Restriction2')}
                                                            value={Obj.Restriction2} showArrow={true} size={"default"}
                                                            disabled={Obj.RestrictionsOptions === 'N'}
                                                        >
                                                            {DUXInitData.Restrictions2.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                    <FormItem
                                                        validateStatus={Obj.Restriction3 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction3"] ? 'error' : ""}
                                                        help={Obj.Restriction3 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction3"]}
                                                        label={'3:'}
                                                    >
                                                        <Select allowClear = {true} id = "SRest3DUX" onFocus={(e) => {
                                document.getElementById("SRest3DUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Restriction3')}
                                                            value={Obj.Restriction3} showArrow={true} size={"default"}
                                                            disabled={Obj.RestrictionsOptions === 'N'}
                                                        >
                                                            {DUXInitData.Restrictions3.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                    <Col span={10} offset={1}>
                                        <Row>
                                            <Col>
                                                <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                                    <Row>
                                                        <Col>
                                                            <h3>P/M Code</h3>
                                                            <hr />
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col offset={2}>
                                                            <RadioGroup name="PMOption" value={Obj.PMOption} onChange={e => this.handleFieldChange(e, 'PMOption')}>
                                                                <Radio value={'N'}>N/A</Radio>
                                                                <Radio value={'A'}>Add</Radio>
                                                                <Radio value={'D'}>Delete</Radio>
                                                            </RadioGroup>
                                                        </Col>
                                                    </Row>
                                                    <br />
                                                    <Row>
                                                        <Col span={20} offset={2}>
                                                            <FormItem
                                                                validateStatus={Obj.PMCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["PMCode"] ? 'error' : ""}
                                                                help={Obj.PMCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["PMCode"]}
                                                            >
                                                                <Select allowClear = {true} id = "SPMCDUX" onFocus={(e) => {
                                document.getElementById("SPMCDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'PMCode')}
                                                                    value={Obj.PMCode} showArrow={true} size={"default"}
                                                                    disabled={Obj.PMOption === 'N'}
                                                                >
                                                                    {DUXInitData.PMCode.map((item) => {
                                                                        return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                                    })}
                                                                </Select>
                                                            </FormItem>
                                                        </Col>
                                                    </Row>
                                                </div>
                                                <br />
                                            </Col>
                                            <Row>
                                                <Col span={10}>
                                                    <FormItem
                                                        validateStatus={this.state.CountyCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CountyCode"] ? 'error' : ""}
                                                        help={this.state.CountyCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CountyCode"]}
                                                        label={<b>County Code </b>}
                                                    >
                                                        <Input value={Obj.CountyCode} placeholder="County Code" onChange={e => this.handleFieldChange(e, 'CountyCode')} />
                                                    </FormItem>
                                                </Col>
                                                <Col span={10} offset={1}>
                                                    <FormItem
                                                        validateStatus={this.state.RouteCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["RouteCode"] ? 'error' : ""}
                                                        help={this.state.RouteCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["RouteCode"]}
                                                        label={<b>Route Code </b>}
                                                    >
                                                        <Input value={Obj.RouteCode} placeholder="Route Code" onChange={e => this.handleFieldChange(e, 'RouteCode')} />
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                            <Col>
                                                <FormItem
                                                    validateStatus={Obj.InsertParagraph === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["InsertParagraph"] ? 'error' : ""}
                                                    help={Obj.InsertParagraph === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["InsertParagraph"]}
                                                    label={<b>Insert Para</b>}
                                                >
                                                    <Select allowClear = {true} id = "SIPDUX" onFocus={(e) => {
                                document.getElementById("SIPDUX").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'InsertParagraph')}
                                                        value={Obj.InsertParagraph} showArrow={true} size={"default"}
                                                    >
                                                        {DUXInitData.ParaIns.map((item) => {
                                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                        })}
                                                    </Select>
                                                </FormItem>
                                            </Col>

                                        </Row>
                                    </Col>
                                </Row>
                                <br />

                                <Row>

                                </Row>

                                <Row>
                                    <Col span={18}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{ width: '20%' }} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                                
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                    {
                                    if (isNewDL === true) {
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            DLNumber: '',
                                            ModifiedHearingDate: '',
                                            EffectiveDate: '',
                                            HearingDate: '',
                                            MailDate: '',
                                            OrigEffectiveDate: '',
                                            ErrorObj: {},
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                  else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                  else
                                    {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}})
                                    }
                                }}}>Ok</Button>
                            </div>
                        ]}
                    >
                         {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            {/* </ScrollPanel > */}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUXData, saveDUXData,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUXUpdate); 