import React, { Component } from 'react';
import { getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Spin, Input, Modal, Button } from 'antd'; 
const Search = Input.Search;
class DLUpdates extends Component {
    constructor(props) {
        super(props);

        this.state={
            DLNumber: "",
            isloading: false,
            activate: false,
            openErrorModel: false,
            enteredDL: ""
        };
    }  

    componentDidMount(){
        
        if(this.props.location.state && this.props.location.state.dlNumber !== undefined && this.props.location.state.dlNumber !== '')
        {         
             this.setState({DLNumber: this.props.location.state.dlNumber, isloading: true})
             this.props.getDLInitialData(this.props.location.state.dlNumber);
        }
        if(this.props.history.action === "POP" && this.state.dlInitData === undefined && sessionStorage.getItem('dlInitData')){
            
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));     
            this.props.getDLInitialData(DLInitData.DLNumber); 
           } 
    }  

    componentDidUpdate(prevProps){

        if ( prevProps.dlUpdates.dlInitData !== this.props.dlUpdates.dlInitData ) {
            const dlInitData = this.props.dlUpdates.dlInitData;
            sessionStorage.getItem('dlInitData') !== undefined && sessionStorage.setItem('dlInitData', JSON.stringify(dlInitData)); 
            this.setState({ dlInitData: dlInitData, DLNumber: dlInitData.DLNumber, ThreeCharacterName: dlInitData.ThreeCharacterName, BirthDate: dlInitData.Birthdate, isloading: false, activate: true });
        }

        if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.duModified !== this.props.dlUpdates.duModified ) {
            if(this.props.dlUpdates.dlUpdatesErrorData === "The entered DL number was not found.")
            {
                
                this.setState({ dlUpdatesErrorData: "DL Number '"+this.state.enteredDL+"' was not found.", isloading: false});
            }
            else {
                this.setState({isloading: false});
            }
       //     message.error(this.props.dlUpdates.dlUpdatesErrorData);
          //  this.setState({ isloading: false});
        }
    }
            static getDerivedStateFromProps(props, prevState) {
                
                const { dlInitData, dlUpdatesErrorData, duModified } = props.dlUpdates;
                if (dlInitData && dlInitData !== prevState.dlInitData)
                {
                    
                    sessionStorage.getItem('dlInitData') !== undefined && sessionStorage.setItem('dlInitData', JSON.stringify(dlInitData)); 
                    return { dlInitData: dlInitData, DLNumber: dlInitData.DLNumber, ThreeCharacterName: dlInitData.ThreeCharacterName, BirthDate: dlInitData.Birthdate, isloading: false, activate: true };
                } 
                if (dlUpdatesErrorData && typeof dlUpdatesErrorData !== "object" && duModified !== prevState.duModified) 
                {
                        return {dlUpdatesErrorData, openErrorModel: true, duModified};
                }
                return null;
            }

            render() {
                return (                 
                 <React-Fragment> 
                     {typeof this.props.dlUpdates.dlUpdatesErrorData !== 'object' && <Modal title={'ERROR'} maskClosable={false} visible={this.state.openErrorModel}
                 onCancel={(e) => this.setState({showModal: false})}
              
                 footer = { [
                  <div key="Cancel">
                    <Button type="default" key="Cancel" onClick={(e) =>
                      {
                        this.setState({ openErrorModel: false });
                      }}
                     > OK </Button> 
                </div>
               ]}
><font color='red'>{this.state.dlUpdatesErrorData}</font></Modal>}
                {this.state.dlInitData && this.state.isloading !== true ?
                  <React-fragment>                     
                  <Row style={{marginTop: "2%", width: "90%"}} gutter={4}><Col style={{marginLeft: "40%"}} span={4}><h4>Enter new DL Number:</h4></Col><Col span={4}>
                  <Search
          placeholder="Enter DL Number"
          maxLength={8}
          onSearch={value => {
            if(value !== ""){
this.setState({isloading: true, enteredDL: value}); 
              this.props.getDLInitialData(value); }}}
          enterButton/>        
          </Col>
                  </Row> 
                      <Row style={{width: "90%", marginTop: "2%"}}><Col style={{marginLeft: "20%"}} span={4}><b>DL #:</b> {this.state.DLNumber}</Col><Col span={6}><b>Three Character Name:</b> {this.state.ThreeCharacterName}</Col><Col span={4}><b>Date Of Birth:</b> {this.state.BirthDate}</Col></Row>
                      
                    <Row style={{border: "1px solid black", marginLeft: "5%", height: "500px", width: "90%", marginTop: "3%"}}>
                 <h3 style={{textAlign: 'center', width: '100%', marginTop: "2%"}}>DL UPDATES:</h3>
                 <Col span={8} style= {{marginLeft: '5%', marginTop: '2%'}}> <div onKeyDown={(e) => { debugger; if(e.keyCode === 13)
                 { this.props.history.push(`/damUpdate/DLNumber/${this.state.DLNumber}`);} }} style={{backgroundColor: '#e6f7ff', cursor: 'pointer'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/damUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DAM/DAS - PAS Update or Dual PAS and VOP Update</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/danUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/danUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DAN - DL/ID Cancellation</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dapUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"onClick={(e) =>  {
                     this.props.history.push(`/dapUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DAP/DAS - APS Update or Dual APS and VOP Update</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/darUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}   tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/darUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DAR - DUI Audit Tracking</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dasUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}   tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dasUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DAS - VOP Update</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dcnUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dcnUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DCN - DL Withholding Reason</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dieUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}   tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dieUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DIE - DL Address Change</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dixUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}   tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dixUpdate`);
                    }}><h4><a><font color="blue"><font color="blue">DIX - X Number</font></font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dueUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dueUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUE - CDL Disqualification</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dufUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dufUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUF - DSR FR Update</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/duhUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/duhUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUH - Service Code</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dujUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dujUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUJ - Suspense</font></a></h4></div></Col>
                 <Col span={8} style={{marginLeft: '20%', marginTop: '2%'}}>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dukUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dukUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUK - Miscellaneous Driver Record Update</font></a></h4></div>
                <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/duaUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/duaUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUA - Route Code</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dunUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dunUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUN - N Code</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dupUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/dupUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUP - Miscellaneous Work Order</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/duvUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/duvUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUV - Hearing Notice</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/duwUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/duwUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUW - Hearing Report</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/duxUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/duxUpdate/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">DUX - Reinstatement, Termination, Set-Aside</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/duzUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/duzUpdate/DLNumber/${this.state.DLNumber}`
                 )}}><h4><a><font color="blue">DUZ - Discretionary Actions</font></a></h4></div>
                 {/* <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dapUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}><h4><a><font color="blue">HRJ - Report Withdrawals Manually to CDLIS</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dapUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}><h4><a><font color="blue">HRK - Report Negate Withdrawals Manually to CDLIS</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dapUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}><h4><a><font color="blue">HRL - O/S Withdrawal Link Database Update</font></a></h4></div> */}
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/me2Update/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/me2Update/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">ME2 - Medical Examination Report</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/me3Update/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/me3Update/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">ME3 - Waiver/Exemption or SPE</font></a></h4></div>
                             <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/me4Update/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/me4Update/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">ME4 - Medical Certification Correction</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/me5Update/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/me5Update/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">ME5 - Mark Medical Certificate Invalid Update</font></a></h4></div>
                 <div onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/me6Update/DLNumber/${this.state.DLNumber}`);
                 } }} style={{backgroundColor: '#e6f7ff'}}  tabIndex="0"  onClick={(e) =>  {
                     this.props.history.push(`/me6Update/DLNumber/${this.state.DLNumber}`);
                    }}><h4><a><font color="blue">ME6 - Self Certification Update</font></a></h4></div></Col></Row></React-fragment> : this.state.isloading ?  <React-Fragment> <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></React-Fragment>:
                    
        <React-Fragment> 
                  <Row style={{width: "90%", marginTop: "2%"}} gutter={4}><Col style={{marginLeft: "40%"}} span={4}><h4>Enter new DL Number:</h4></Col><Col span={4}>
                  <Search
          placeholder="Enter DL Number"
          maxLength={8}
          onSearch={value => {if(value !== ""){ this.setState({isloading: true, enteredDL: value}); this.props.getDLInitialData(value); }}}
          enterButton/>        
          </Col>
                  </Row> 
                  
                      <Row style={{width: "90%", marginTop: "2%"}}><Col style={{marginLeft: "20%"}} span={4}>DL #: {this.state.DLNumber}</Col><Col span={4}>Three Character Name: {this.state.ThreeCharacterName}</Col><Col span={4}>Date Of Birth: {this.state.BirthDate}</Col></Row>
                      
                    <Row style={{border: "1px solid black", marginLeft: "5%",  height: "500px", width: "90%", marginTop: "3%"}}>
                 <h3 style={{textAlign: 'center', width: '100%', marginTop: "2%"}}>DL UPDATES:</h3>

                 <h3 style={{textAlign: 'center', width: '100%', marginTop: "1%"}}> Enter the DL Number to enable the complete DL Updates menu. </h3>

<Row style={{width: "90%", marginTop: "2%"}}>
 <Col span={8} style= {{marginLeft: '5%'}}>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DAM/DAS - PAS Update or Dual PAS and VOP Update</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DAN - DL/ID Cancellation</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DAP/DAS - APS Update or Dual APS and VOP Update</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DAR - DUI Audit Tracking</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DAS - VOP Update</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DCN - DL Withholding Reason</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DIE - DL Address Change</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}  tabIndex="0" onKeyDown={(e) => { if(e.keyCode === 13)
                 {
                    this.props.history.push(`/dixUpdate/DLNumber/${this.state.DLNumber}`);
                 } }} onClick={(e) =>  {
                     this.props.history.push(`/dixUpdate`);
                    }}><h4><a><font color="blue">DIX - X Number</font></a></h4></div>
                
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUE - CDL Disqualification</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUF - DSR FR Update</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUH - Service Code</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUJ - Suspense</h4></div></Col>
                 <Col span={8} style={{marginLeft: '20%'}}>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUK - Miscellaneous Driver Record Update</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUN - N Code</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUP - Miscellaneous Work Order</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUV - Hearing Notice</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUW - Hearing Report</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUX - Reinstatement, Termination, Set-Aside</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>DUZ - Discretionary Actions</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>ME2 - Medical Examination Report</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>ME3 - Waiver/Exemption or SPE</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>ME4 - Medical Certification Correction</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>ME5 - Mark Medical Certificate Invalid Update</h4></div>
                 <div style={{backgroundColor: '#e6f7ff'}}><h4>ME6 - Self Certification Update</h4></div></Col></Row></Row> </React-Fragment> 
                }
                 </React-Fragment>
                 );
            }
            }
            const mapStateToProps = state => {
                return {
                  dlUpdates: state.dlUpdates
                };
            };
            
            const mapDispatchToProps = dispatch => {
                return bindActionCreators(
                    {
                        getDLInitialData
                    },
                    dispatch
                );
            };
            
            export default connect(mapStateToProps, mapDispatchToProps)(DLUpdates);