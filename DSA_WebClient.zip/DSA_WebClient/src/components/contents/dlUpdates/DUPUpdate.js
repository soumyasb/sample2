import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Radio, Select, Modal, Spin } from 'antd';
import { dateFormatFunc, dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDUPData, saveDUPData, getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;
const RadioGroup = Radio.Group;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    TypeAction: '',
    Reason: '',
    AuthoritySection1: '',
    AuthoritySection2: '',
    BirthDate: '',
    OriginalHearingDate: '',
    EffectiveDate: '',
    ActionTermDate: '',
    MailDate: '',
    OrigEffectiveDate: '',
    RouteCode: '',
    PMOption: 'N',
    PMCode: '',
    RestrictionsOptions: 'N',
    Restriction1: '',
    Restriction2: '',
    Restriction3: '',
    LicenseLocation: '',
    CountyCode: '',
    OrigAuthoritySection: '',
    CoFo: '',
    DUPResponse: '',
    NextDLNumber: '',
    Error: true
};


class DUPUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            BirthDate: '',
            OriginalHearingDate: '',
            EffectiveDate: '',
            ActionTermDate: '',
            MailDate: '',
            OrigEffectiveDate: '',
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }

    componentDidMount() {
        if (sessionStorage.getItem('dlInitData')) {
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDUPData(DLInitData.DLNumber);
        }
        else {
            this.props.history.push(`/dlUpdates`);
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DUPInitData !== this.props.dlUpdates.DUPInitData && this.props.dlUpdates.DUPInitData !== undefined) {
            const Obj = cloneDeep(defaultObj);
            Obj['ThreeCharacterName'] = this.props.dlUpdates.DUPInitData.ThreeCharacterName;
            Obj['BirthDate'] = this.props.dlUpdates.DUPInitData.BirthDate;
            this.setState({DUPInitData: this.props.dlUpdates.DUPInitData, Obj: Obj});
        }
        if (prevProps.dlUpdates.saveDUPData !== this.props.dlUpdates.saveDUPData && this.props.dlUpdates.saveDUPData !== undefined) {
            this.setState({ saveDUPData: this.props.dlUpdates.saveDUPData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
            }
            else{
                let Errors = [];
                Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                    Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
           Obj['BirthDate'] = this.props.dlUpdates.dlInitData.Birthdate;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DUPInitData, saveDUPData, dlUpdatesErrorData } = props.dlUpdates;
        if (DUPInitData && DUPInitData !== prevState.DUPInitData) {
            return { DUPInitData: DUPInitData, isloading: false };
        }
        if (saveDUPData && saveDUPData !== prevState.saveDUPData)
            return {
                saveDUPData: saveDUPData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
               dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
                case 'NextDLNumber':
                    Obj[field] = e.target.value;
                break;
                case 'DLNumber':
                this.setState({DLNumber: e.target.value});
                Obj[field] = e.target.value;
                    if ((Obj['DLNumber'].length === 8)) {
                          this.props.getDLInitialData(Obj['DLNumber']);
                          this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                    }
                    break;
            case 'RouteCode':
                if (e.target.value.match(/^[0-9]+$/)) {
                    if (e.target.value.length <= 4) {

                        Obj[field] = e.target.value;
                    }
                }
                break;
            case 'CountyCode':
                if (e.target.value.match(/^[0-9]+$/)) {
                    if (e.target.value.length <= 2) {

                        Obj[field] = e.target.value;
                    }
                }
                break;
            case 'Reason':
            case 'TypeAction':
            case 'AuthoritySection1':
            case 'AuthoritySection2':
            case 'Restriction1':
            case 'Restriction2':
            case 'Restriction3':
            case 'PMCode':
            case 'LicenseLocation':
            case 'OrigAuthoritySection':
            case 'CoFo':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            case 'PMOption':
            case 'RestrictionsOptions':
            Obj[field] = e.target.value;
            if( field === 'PMOption' && e.target.value === 'N')
            {
                Obj.PMCode = '';
            }
            if( field === 'RestrictionsOptions' && e.target.value === 'N')
            {
                Obj.Restriction1 = '';
                Obj.Restriction2 = '';
                Obj.Restriction3 = '';
            }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {
        switch (type) {
            case 'OriginalHearingDate':
                this.setState({ OriginalHearingDate: d });
                break;
            case 'BirthDate':
                this.setState({ BirthDate: d });
                break;
            case 'EffectiveDate':
                this.setState({ EffectiveDate: d });
                break;
            case 'ActionTermDate':
                this.setState({ ActionTermDate: d });
                break;
            case 'MailDate':
                this.setState({ MailDate: d });
                break;
            case 'OrigEffectiveDate':
                this.setState({ OrigEffectiveDate: d });
                break;
            default:
                break;
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }

        const { Obj } = this.state;

            if(typeof this.state.BirthDate === 'string')
            {
                Obj['BirthDate'] = this.state.BirthDate.substring(0,2)+this.state.BirthDate.substring(3,5)+this.state.BirthDate.substring(8,10);
            }
          else
          {
            Obj['BirthDate'] = dateFormatFuncDLUpdates(this.state.BirthDate);
          }

        Obj['LoginId'] = this.state.DUPInitData.LoginId;
        Obj['RequestorCode'] = this.state.DUPInitData.RequestorCode;
        Obj['Operator'] = this.state.DUPInitData.Operator;
        Obj['NetName'] = this.state.DUPInitData.NetName;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['OrigEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OrigEffectiveDate);
        Obj['EffectiveDate'] = dateFormatFuncDLUpdates(this.state.EffectiveDate);
        Obj['ActionTermDate'] = dateFormatFuncDLUpdates(this.state.ActionTermDate);
        Obj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);
        Obj['OriginalHearingDate'] = dateFormatFuncDLUpdates(this.state.OriginalHearingDate);

        this.setState({ isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL });
         this.props.saveDUPData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUPInitData, saveDUPData, isNewDL, isloading } = this.state;

        return (

            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {saveDUPData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDUPData.Error === false)
                                {  if (Obj.NextDLNumber !== '') {
                                    this.props.history.push({
                                        pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                        state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                    });
                                }
                                else if (isNewDL !== true) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDUPData.DLNumber }
                                    })
                                }
                             else {
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                        BirthDate: '',
                                        DLNumber: '',
                                        OriginalHearingDate: '',
                                        EffectiveDate: '',
                                        ActionTermDate: '',
                                        MailDate: '',
                                        OrigEffectiveDate: '',
                                        ErrorObj: {},
                                        PhoneNumber: "",
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                } 
                            }}
                        }>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDUPData.DUPResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DUPInitData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Miscellaneous Work Order (DUP)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={6} style={{ display: 'block' }}>
                                            <FormItem
                                             hasFeedback
                                             validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                             help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={6} offset={1}>
                                            <FormItem
                                                validateStatus={this.state.BirthDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["BirthDate"] ? 'error' : ""}
                                                help={this.state.BirthDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["BirthDate"]}
                                                label={<b> Birth Date </b>}
                                            >
                                               <DatePicker
                       className = "CalClass"
                       selected={this.state.BirthDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'BirthDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={6}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                        <Col span={6} offset={1}>
                                            <FormItem
                                                label={<b>Birth Date</b>}
                                            >
                                                {this.state.BirthDate}
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }
                                <Row>
                                    <Col span={6}>
                                        <FormItem
                                            validateStatus={Obj.TypeAction === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["TypeAction"] ? 'error' : ""}
                                            help={Obj.TypeAction === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["TypeAction"]}
                                            label={<b> Type Action <font color="red">*</font></b>}
                                        >
                                            <Select allowClear = {true} id = "STyA" onFocus={(e) => {
                                document.getElementById("STyA").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'TypeAction')}
                                                value={Obj.TypeAction} showArrow={true} size={"default"}
                                            >
                                                {DUPInitData.TypeAction.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.Reason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Reason"] ? 'error' : ""}
                                            help={Obj.Reason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Reason"]}
                                            label={<b> Reason </b>}
                                        >
                                            <Select allowClear = {true} id = "SReason" onFocus={(e) => {
                                document.getElementById("SReason").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'Reason')}
                                                value={Obj.Reason} showArrow={true} size={"default"}
                                            >
                                                {DUPInitData.Reasons.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.OriginalHearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalHearingDate"] ? 'error' : ""}
                                            help={this.state.OriginalHearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalHearingDate"]}
                                            label={<b> Orig Hiring Date </b>}
                                        >
                                           <DatePicker
                       className = "CalClass"
                       selected={this.state.OriginalHearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OriginalHearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={8}>
                                        <FormItem
                                            validateStatus={Obj.AuthoritySection1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection1"] ? 'error' : ""}
                                            help={Obj.AuthoritySection1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection1"]}
                                            label={<b> Authority Section </b>}
                                        >
                                            <Select allowClear = {true} id = "SASec" onFocus={(e) => {
                                document.getElementById("SASec").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onSelect={e => this.handleFieldChange(e, 'AuthoritySection1')}
                                                value={Obj.AuthoritySection1} showArrow={true} size={"default"}
                                            >
                                                {DUPInitData.AuthoritySection1.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.AuthoritySection2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection2"] ? 'error' : ""}
                                            help={Obj.AuthoritySection2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection2"]}
                                        >
                                            <Select allowClear = {true} id = "SASec2" onFocus={(e) => {
                                document.getElementById("SASec2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onSelect={e => this.handleFieldChange(e, 'AuthoritySection2')}
                                                value={Obj.AuthoritySection2} showArrow={true} size={"default"}
                                            >
                                                {DUPInitData.AuthoritySection2.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.EffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["EffectiveDate"] ? 'error' : ""}
                                            help={this.state.EffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["EffectiveDate"]}
                                            label={<b> Effective Date </b>}
                                        >
                                         <DatePicker
                       className = "CalClass"
                       selected={this.state.EffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'EffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={6}>
                                        <FormItem
                                            validateStatus={this.state.ActionTermDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ActionTermDate"] ? 'error' : ""}
                                            help={this.state.ActionTermDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ActionTermDate"]}
                                            label={<b> Action Term Date </b>}
                                        >
                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.ActionTermDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ActionTermDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.MailDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["MailDate"] ? 'error' : ""}
                                            help={this.state.MailDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["MailDate"]}
                                            label={<b> Mail Date </b>}
                                        >
                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.RouteCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["RouteCode"] ? 'error' : ""}
                                            help={this.state.RouteCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["RouteCode"]}
                                            label={<b>Route Code </b>}
                                        >
                                            <Input value={Obj.RouteCode} placeholder="Route Code" onChange={e => this.handleFieldChange(e, 'RouteCode')} />
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={10} >
                                        <Row>
                                            <Col>
                                                <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                                    <Row>
                                                        <Col>
                                                            <h3>P/M Code</h3>
                                                            <hr />
                                                        </Col>
                                                    </Row>
                                                    <Row>
                                                        <Col offset={2}>
                                                            <RadioGroup name="PM Options" value={Obj.PMOption} onChange={e => this.handleFieldChange(e, 'PMOption')}>
                                                                <Radio value={'N'}>N/A</Radio>
                                                                <Radio value={'A'}>Add</Radio>
                                                                <Radio value={'D'}>Delete</Radio>
                                                            </RadioGroup>
                                                        </Col>
                                                    </Row>
                                                    <br />
                                                    <Row>
                                                        <Col span={20} offset={2}>
                                                            <FormItem
                                                                validateStatus={Obj.PMCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["PMCode"] ? 'error' : ""}
                                                                help={Obj.PMCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["PMCode"]}
                                                            >
                                                                <Select allowClear = {true} id = "SPMC" onFocus={(e) => {
                                document.getElementById("SPMC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'PMCode')}
                                                                    value={Obj.PMCode} showArrow={true} size={"default"}
                                                                    disabled={Obj.PMOption === 'N'}
                                                                >
                                                                    {DUPInitData.PMCode.map((item) => {
                                                                        return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                                    })}
                                                                </Select>
                                                            </FormItem>
                                                        </Col>
                                                    </Row>
                                                </div>
                                                <br />
                                            </Col>
                                            <Col>
                                                <FormItem
                                                    validateStatus={Obj.LicenseLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["LicenseLocation"] ? 'error' : ""}
                                                    help={Obj.LicenseLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["LicenseLocation"]}
                                                    label={<b>License Location</b>}
                                                >
                                                    <Select allowClear = {true} id = "SLL" onFocus={(e) => {
                                document.getElementById("SLL").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'LicenseLocation')}
                                                        value={Obj.LicenseLocation} showArrow={true} size={"default"}
                                                    >
                                                        {DUPInitData.LicenseLocation.map((item) => {
                                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                        })}
                                                    </Select>
                                                </FormItem>
                                            </Col>
                                            <Col span={10}>
                                                <FormItem
                                                    validateStatus={this.state.CountyCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CountyCode"] ? 'error' : ""}
                                                    help={this.state.CountyCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CountyCode"]}
                                                    label={<b>County Code </b>}
                                                >
                                                    <Input value={Obj.CountyCode} placeholder="County Code" onChange={e => this.handleFieldChange(e, 'CountyCode')} />
                                                </FormItem>
                                            </Col>
                                        </Row>
                                    </Col>
                                    <Col span={12} offset={1}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Restriction</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col offset={2}>
                                                    <RadioGroup name ="Restriction Options" value={Obj.RestrictionsOptions} onChange={e => this.handleFieldChange(e, 'RestrictionsOptions')}>
                                                        <Radio value={'N'}>N/A</Radio>
                                                        <Radio value={'A'}>Add</Radio>
                                                        <Radio value={'D'}>Delete</Radio>
                                                    </RadioGroup>
                                                </Col>
                                            </Row>
                                            <br />
                                            <Row>
                                                <Col span={22} offset={1}>
                                                    <FormItem
                                                        validateStatus={Obj.Restriction1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction1"] ? 'error' : ""}
                                                        help={Obj.Restriction1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction1"]}
                                                        label={'1:'}
                                                    >
                                                        <Select allowClear = {true} id = "SRest" onFocus={(e) => {
                                document.getElementById("SRest").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'Restriction1')}
                                                            disabled={Obj.RestrictionsOptions === 'N'} value={Obj.Restriction1} showArrow={true} size={"default"}
                                                        >
                                                            {DUPInitData.Rest1.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                    <FormItem
                                                        validateStatus={Obj.Restriction2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction2"] ? 'error' : ""}
                                                        help={Obj.Restriction2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction2"]}
                                                        label={'2:'}
                                                    >
                                                        <Select allowClear = {true} id = "SRest2" onFocus={(e) => {
                                document.getElementById("SRest2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'Restriction2')}
                                                             disabled={Obj.RestrictionsOptions === 'N'} value={Obj.Restriction2} showArrow={true} size={"default"}
                                                        >
                                                            {DUPInitData.Rest2.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                    <FormItem
                                                        validateStatus={Obj.Restriction3 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction3"] ? 'error' : ""}
                                                        help={Obj.Restriction3 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Restriction3"]}
                                                        label={'3:'}
                                                    >
                                                        <Select allowClear = {true} id = "SRest3" onFocus={(e) => {
                                document.getElementById("SRest3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'Restriction3')}
                                                             disabled={Obj.RestrictionsOptions === 'N'} value={Obj.Restriction3} showArrow={true} size={"default"}
                                                        >
                                                            {DUPInitData.Rest3.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col span={9}>
                                        <FormItem
                                            validateStatus={Obj.OrigAuthoritySection === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigAuthoritySection"] ? 'error' : ""}
                                            help={Obj.OrigAuthoritySection === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigAuthoritySection"]}
                                            label={<b>Orig Authority Section</b>}
                                        >
                                            <Select allowClear = {true} id = "SOAS" onFocus={(e) => {
                                document.getElementById("SOAS").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'OrigAuthoritySection')}
                                                value={Obj.OrigAuthoritySection} showArrow={true} size={"default"}
                                            >
                                                {DUPInitData.OriginalAuthoritySection.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigEffectiveDate"] ? 'error' : ""}
                                            help={this.state.OrigEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OrigEffectiveDate"]}
                                            label={<b> Orig Effec Date </b>}
                                        >
                                           <DatePicker
                       className = "CalClass"
                       selected={this.state.OrigEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OrigEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.CoFo === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CoFo"] ? 'error' : ""}
                                            help={Obj.CoFo === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CoFo"]}
                                            label={<b>Co /Fo</b>}
                                        >
                                            <Select allowClear = {true} id = "SCoFo" onFocus={(e) => {
                                document.getElementById("SCoFo").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'CoFo')}
                                                value={Obj.CoFo} showArrow={true} size={"default"}
                                            >
                                                {DUPInitData.CoFo.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col span={18}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{ width: '20%' }} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                                
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                    { if(isNewDL === true)
                                        {
                                              
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            BirthDate: '',
                                            DLNumber: '',
                                            OriginalHearingDate: '',
                                            EffectiveDate: '',
                                            ActionTermDate: '',
                                            MailDate: '',
                                            OrigEffectiveDate: '',
                                            ErrorObj: {},
                                            PhoneNumber: "",
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                    else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                   else {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }                                          
                                }}>Ok</Button>
                            </div>
                        ]}
                    >
                         {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            {/* </ScrollPanel > */}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUPData, saveDUPData,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUPUpdate); 