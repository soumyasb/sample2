import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Radio, Select, Modal, Spin, Checkbox } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDUFData, saveDUFData, getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;
const RadioGroup = Radio.Group;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    FRNumber: '',
    Stay: '',
    StayOptions: 'NA',
    AuthoritySection1: '',
    AuthoritySection2: '',
    AuthoritySection3: '',
    NewEffectiveDate: '',
    OriginalEffectiveDate: '',
    OriginalHearingDate: '',
    UpdateCopies: '',
    OutOfStateDLNo: '',
    OutOfStateCd: '',
    CommercialStatusIndicator: '',
    HearingType: '',
    HearingDate: '',
    HearingLocation: '',
    HearingResult: '',
    ModDate: '',
    MailDate: '',
    CoFo: '',
    ProofBypass: false,
    AccidentDate: '',
    AccidentLocation: '',
    RouteCode: '',
    InsertParagraph: '',
    DUFResponse: '',
    NextDLNumber: '',
    Error: true
};

class DUFUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            Obj: cloneDeep(defaultObj),
            NewEffectiveDate: '',
            OriginalEffectiveDate: '',
            OriginalHearingDate: '',
            ModDate: '',
            MailDate: '',
            AccidentDate: '',
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }

    componentDidMount() {
        if (sessionStorage.getItem('dlInitData')) {
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                birthDate: DLInitData.Birthdate
            });
            this.props.getDUFData(DLInitData.DLNumber);
        }
        else {
            this.props.history.push(`/dlUpdates`);
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DUFInitData !== this.props.dlUpdates.DUFInitData && this.props.dlUpdates.DUFInitData !== undefined) {
            const Obj = cloneDeep(defaultObj);                           
            Obj['ThreeCharacterName'] = this.props.dlUpdates.DUFInitData.ThreeCharacterName;
            this.setState({DUFInitData: this.props.dlUpdates.DUFInitData, Obj: Obj});
        }
        if (prevProps.dlUpdates.saveDUFData !== this.props.dlUpdates.saveDUFData && this.props.dlUpdates.saveDUFData !== undefined) {
            this.setState({ saveDUFData: this.props.dlUpdates.saveDUFData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            let Errors = [];
            Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                return "";
            })
            this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isLoading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DUFInitData, saveDUFData, dlUpdatesErrorData } = props.dlUpdates;
        if (DUFInitData && DUFInitData !== prevState.DUFInitData) {
            return { DUFInitData: DUFInitData, isloading: false };
        }
        if (saveDUFData && saveDUFData !== prevState.saveDUFData)
            return {
                saveDUFData: saveDUFData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                ErrorObj: dlUpdatesErrorData,
                Error: dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
    
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
                case 'NextDLNumber':
                case 'FRNumber':
                    Obj[field] = e.target.value;
                break;
                case 'DLNumber':
                this.setState({DLNumber: e.target.value});
                Obj[field] = e.target.value;
                    if ((Obj['DLNumber'].length === 8)) {
                          this.props.getDLInitialData(Obj['DLNumber']);
                          this.props.getDUFData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                    }
                    break;
            case 'OutOfStateDLNo':
                if (e.target.value.length <= 25) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'RouteCode':
                if (e.target.value.match(/^[0-9]+$/)) {
                    if (e.target.value.length <= 4) {
                        Obj[field] = e.target.value;
                    }
                }
                break;
            case 'AccidentLocation':
                if (e.target.value.length <= 13) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'HearingType':
            case 'hearingLocation':
            case 'HearingResult':
            case 'hearingReason':
            case 'AuthoritySection1':
            case 'AuthoritySection2':
            case 'AuthoritySection3':
            case 'UpdateCopies':
            case 'InsertParagraph':
            case 'CoFo':
            case 'OutOfStateCd':
            case 'CommercialStatusIndicator':
                Obj[field] = e;
                break;
            case 'Stay':
            case 'StayOptions':
            if(!e)
            {
                Obj[field] = '';
            }
            else
            {
                if (field === 'StayOptions') {

                    Obj[field] = e.target.checked ? e.target.value : '';
                }
                else {
                    Obj[field] = e;
                }

                if (Obj.Stay && Obj.StayOptions !== 'NA') {
                    if (Obj.StayOptions === 'Set') {
                        Obj.AuthoritySection1 = Obj.Stay;
                        Obj.AuthoritySection2 = "";
                        Obj.AuthoritySection3 = "";
                    } else if (Obj.StayOptions === 'End') {
                        if (Obj.Stay === "5") {
                            Obj.AuthoritySection1 = "16070";
                            Obj.AuthoritySection2 = "5";
                            Obj.AuthoritySection3 = "";
                        } else if (Obj.Stay === "51") {
                            Obj.AuthoritySection1 = "16070";
                            Obj.AuthoritySection2 = "141055";
                            Obj.AuthoritySection3 = "5";
                        }
                    }
                } else {
                    Obj.Stay = "";
                    Obj.AuthoritySection1 = "";
                    Obj.AuthoritySection2 = "";
                    Obj.AuthoritySection3 = "";
                }

            }
             
                break;
            case 'ProofBypass':
                Obj[field] = e.target.checked;
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d, type) {

        switch (type) {
            case 'NewEffectiveDate':
                this.setState({ NewEffectiveDate: d });
                break;
            case 'OriginalEffectiveDate':
                this.setState({ OriginalEffectiveDate: d });
                break;
            case 'OriginalHearingDate':
                this.setState({ OriginalHearingDate: d });
                break;
            case 'HearingDate':
                this.setState({ HearingDate: d });
                break;
            case 'ModDate':
                this.setState({ ModDate: d });
                break;
            case 'MailDate':
                this.setState({ MailDate: d });
                break;
            case 'AccidentDate':
                this.setState({ AccidentDate: d });
                break;
            default:
                break;
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }

        const { Obj } = this.state;

        Obj['RequestorCode'] = this.state.DUFInitData.RequestorCode;
        Obj['Operator'] = this.state.DUFInitData.Operator;
        Obj['NetName'] = this.state.DUFInitData.NetName;
        Obj['LoginId'] = this.state.DUFInitData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['AccidentDate'] = dateFormatFuncDLUpdates(this.state.AccidentDate);
        Obj['NewEffectiveDate'] = dateFormatFuncDLUpdates(this.state.NewEffectiveDate);
        Obj['OriginalEffectiveDate'] = dateFormatFuncDLUpdates(this.state.OriginalEffectiveDate);
        Obj['OriginalHearingDate'] = dateFormatFuncDLUpdates(this.state.OriginalHearingDate);
        Obj['HearingDate'] = dateFormatFuncDLUpdates(this.state.HearingDate);
        Obj['ModDate'] = dateFormatFuncDLUpdates(this.state.ModDate);
        Obj['MailDate'] = dateFormatFuncDLUpdates(this.state.MailDate);

        this.setState({ isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL });
        this.props.saveDUFData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUFInitData, saveDUFData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", height: '800px', width: "95%", marginLeft: '2%' }}>
                    {saveDUFData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDUFData.Error === false)
               {  if (Obj.NextDLNumber !== '') {
                this.props.history.push({
                    pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                    state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                });
            }
            else if (isNewDL !== true) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDUFData.DLNumber }
                                    })
                                }
                                if (isNewDL === true) {
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                        NewEffectiveDate: '',
                                        OriginalEffectiveDate: '',
                                        OriginalHearingDate: '',
                                        ModDate: '',
                                        DLNumber: '',
                                        MailDate: '',
                                        AccidentDate: '',
                                        ErrorObj: {},
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                }   
                            }}
                        }>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDUFData.DUFResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DUFInitData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Financial Responsibility (DUF)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={6} style={{ display: 'block' }}>
                                            <FormItem
                                              hasFeedback
                                              validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                              help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input value={Obj.ThreeCharacterName} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={4} offset={1}>
                                            <FormItem
                                            validateStatus={Obj.FRNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["FRNumber"] ? 'error' : ""}
                                            help={Obj.FRNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["FRNumber"]}
                                                label={<b>FR # <font color="red">*</font></b>}
                                            >
                                                <Input maxLength = {9} value={Obj.FRNumber} placeholder="FR#" onChange={e => this.handleFieldChange(e, 'FRNumber')} />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={6}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                        <Col span={4} offset={1}>
                                            <FormItem
                                            validateStatus={Obj.FRNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["FRNumber"] ? 'error' : ""}
                                            help={Obj.FRNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["FRNumber"]}
                                                label={<b>FR # <font color="red">*</font></b>}
                                            >
                                            <Input maxLength = {9} value={Obj.FRNumber} placeholder="FR#" onChange={e => this.handleFieldChange(e, 'FRNumber')} />
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }


                                <Row>
                                    <Col span={6}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Stay <font color="red">*</font></h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col offset={1}>
                                                    <RadioGroup name={"StayOptions"} value={Obj.StayOptions} onChange={e => this.handleFieldChange(e, 'StayOptions')}>
                                                        <Radio value={'NA'}>N/A</Radio>
                                                        <Radio value={'Set'}>Set</Radio>
                                                        <Radio value={'End'}>End</Radio>
                                                    </RadioGroup>
                                                </Col>
                                            </Row>
                                            <br />
                                            <Row>
                                                <FormItem
                                                    validateStatus={Obj.Stay === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Stay"] ? 'error' : ""}
                                                    help={Obj.Stay === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["Stay"]}
                                                    label={''}
                                                >
                                                    <Select allowClear={true} id = "Sstay" onFocus={(e) => {
                                document.getElementById("Sstay").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'Stay')}
                                                        value={Obj.Stay} showArrow={true} size={"default"}
                                                        disabled={Obj.StayOptions === 'NA'}
                                                    >
                                                        {DUFInitData.Stay.map((item) => {
                                                            return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                        })}
                                                    </Select>
                                                </FormItem>
                                            </Row>
                                        </div>
                                    </Col>
                                    <Col span={16} offset={1}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>New Authority Section</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <br /> <br />
                                            <Row>
                                                <Col span={8}>
                                                    <FormItem
                                                        validateStatus={Obj.AuthoritySection1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection1"] ? 'error' : ""}
                                                        help={Obj.AuthoritySection1 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection1"]}
                                                        label={''}
                                                    >
                                                        <Select allowClear={true} id = "SAus1" onFocus={(e) => {
                                document.getElementById("SAus1").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthoritySection1')}
                                                            value={Obj.AuthoritySection1} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.FirstAuthoritySection.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={8}>
                                                    <FormItem
                                                        validateStatus={Obj.AuthoritySection2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection2"] ? 'error' : ""}
                                                        help={Obj.AuthoritySection2 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection2"]}
                                                        label={''}
                                                    >
                                                        <Select allowClear={true} id = "SAus2" onFocus={(e) => {
                                document.getElementById("SAus2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthoritySection2')}
                                                            value={Obj.AuthoritySection2} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.SecondAuthoritySection.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={8}>
                                                    <FormItem
                                                        validateStatus={Obj.AuthoritySection3 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection3"] ? 'error' : ""}
                                                        help={Obj.AuthoritySection3 === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AuthoritySection3"]}
                                                        label={''}
                                                    >
                                                        <Select allowClear={true} id = "SAus3" onFocus={(e) => {
                                document.getElementById("SAus3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'AuthoritySection3')}
                                                            value={Obj.AuthoritySection3} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.ThirdAuthoritySection.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col span={5}>
                                        <FormItem
                                            validateStatus={this.state.NewEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NewEffectiveDate"] ? 'error' : ""}
                                            help={this.state.NewEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NewEffectiveDate"]}
                                            label={<b>New Effec Date </b>}
                                        >
                                           <DatePicker
                       className = "CalClass"
                       selected={this.state.NewEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'NewEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={5} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.OriginalEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalEffectiveDate"] ? 'error' : ""}
                                            help={this.state.OriginalEffectiveDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalEffectiveDate"]}
                                            label={<b> Orig Effec Date </b>}
                                        >
                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.OriginalEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OriginalEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={11} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.UpdateCopies === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["UpdateCopies"] ? 'error' : ""}
                                            help={Obj.UpdateCopies === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["UpdateCopies"]}
                                            label={<b> Update Copies </b>}
                                        >
                                            <Select allowClear={true} id = "SUC" onFocus={(e) => {
                                document.getElementById("SUC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'UpdateCopies')}
                                                value={Obj.UpdateCopies} showArrow={true} size={"default"}
                                            >
                                                {DUFInitData.UpdateCopies.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={13}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Out-of-State-Data</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem label="O / S DL # : ">
                                                        <Input placeholder="O / S DL #" value={Obj.OutOfStateDLNo}
                                                            onChange={e => this.handleFieldChange(e, 'OutOfStateDLNo')} />
                                                    </FormItem>
                                                </Col>
                                                <Col span={12} offset={1}>
                                                    <FormItem label="O / S Code : ">
                                                        <Select allowClear={true} id = "SOSD" onFocus={(e) => {
                                document.getElementById("SOSD").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'OutOfStateCd')}
                                                            value={Obj.OutOfStateCd} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.OSCode.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                    <Col span={9} offset={1}>
                                        <FormItem label="Commercial Status Ind : ">
                                            <Select allowClear={true} id = "SCSI" onFocus={(e) => {
                                document.getElementById("SCSI").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CommercialStatusIndicator')}
                                                value={Obj.CommercialStatusIndicator} showArrow={true} size={"default"}
                                            >
                                                {DUFInitData.CommStatusIndicator.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col span={20}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Hearing Information</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingType === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingType"] ? 'error' : ""}
                                                        help={Obj.HearingType === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingType"]}
                                                        label={<b> Type </b>}
                                                    >
                                                        <Select allowClear={true} id = "SHtype" onFocus={(e) => {
                                document.getElementById("SHtype").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingType')}
                                                            value={Obj.HearingType} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.HearingType.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>
                                                    <Row>
                                                        <Col span={11}>
                                                            <FormItem
                                                                validateStatus={this.state.HearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingDate"] ? 'error' : ""}
                                                                help={this.state.HearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingDate"]}
                                                                label={<b> Date </b>}
                                                            >
                                                                <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                                            </FormItem>
                                                        </Col>
                                                        <Col span={12} offset={1}>
                                                            <FormItem
                                                                validateStatus={this.state.ModDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ModDate"] ? 'error' : ""}
                                                                help={this.state.ModDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["ModDate"]}
                                                                label={<b> Mod Date </b>}
                                                            >
                                                                 <DatePicker
                       className = "CalClass"
                       selected={this.state.ModDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'ModDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                                            </FormItem>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingResult === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingResult"] ? 'error' : ""}
                                                        help={Obj.HearingResult === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingResult"]}
                                                        label={<b> Result </b>}
                                                    >
                                                        <Select allowClear={true} id = "SHRes" onFocus={(e) => {
                                document.getElementById("SHRes").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'HearingResult')}
                                                            value={Obj.HearingResult} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.HearingResults.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>
                                                    <FormItem
                                                        validateStatus={Obj.hearingLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["hearingLocation"] ? 'error' : ""}
                                                        help={Obj.hearingLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["hearingLocation"]}
                                                        label={<b> Location </b>}
                                                    >
                                                        <Select allowClear={true} id = "SHLoc" onFocus={(e) => {
                                document.getElementById("SHLoc").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'hearingLocation')}
                                                            value={Obj.hearingLocation} showArrow={true} size={"default"}
                                                        >
                                                            {DUFInitData.DSFieldOffices.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>

                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col span={4}>
                                        <FormItem
                                            validateStatus={this.state.MailDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["MailDate"] ? 'error' : ""}
                                            help={this.state.MailDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["MailDate"]}
                                            label={<b> Mail Date </b>}
                                        >
                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.MailDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={9} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.CoFo === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CoFo"] ? 'error' : ""}
                                            help={Obj.CoFo === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["CoFo"]}
                                            label={<b>Co /Fo</b>}
                                        >
                                            <Select allowClear={true} id = "SCoFo2" onFocus={(e) => {
                                document.getElementById("SCoFo2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'CoFo')}
                                                value={Obj.CoFo} showArrow={true} size={"default"}
                                            >
                                                {DUFInitData.CoFo.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                    <Col span={2} offset={1}>
                                        <FormItem
                                            label="Proof Bypass"
                                        >
                                            <Checkbox checked={Obj.ProofBypass} onChange={e => this.handleFieldChange(e, 'ProofBypass')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={5} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.AccidentDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AccidentDate"] ? 'error' : ""}
                                            help={this.state.AccidentDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AccidentDate"]}
                                            label={<b> Accident Date </b>}
                                        >
                                           <DatePicker
                       className = "CalClass"
                       selected={this.state.AccidentDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'AccidentDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>

                                </Row>
                                <Row>
                                    <Col span={10}>
                                        <FormItem
                                            validateStatus={this.state.AccidentLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AccidentLocation"] ? 'error' : ""}
                                            help={this.state.AccidentLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["AccidentLocation"]}
                                            label={<b>Accident Location </b>}
                                        >
                                            <Input value={Obj.AccidentLocation} placeholder="Accident Location" onChange={e => this.handleFieldChange(e, 'AccidentLocation')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={4} offset={1}>
                                        <FormItem
                                            validateStatus={this.state.RouteCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["RouteCode"] ? 'error' : ""}
                                            help={this.state.RouteCode === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["RouteCode"]}
                                            label={<b>Route Code </b>}
                                        >
                                            <Input value={Obj.RouteCode} placeholder="Route Code" onChange={e => this.handleFieldChange(e, 'RouteCode')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={7} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.InsertParagraph === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["InsertParagraph"] ? 'error' : ""}
                                            help={Obj.InsertParagraph === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["InsertParagraph"]}
                                            label={<b>Insert Para</b>}
                                        >
                                            <Select allowClear={true} id = "SIP1" onFocus={(e) => {
                                document.getElementById("SIP1").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'InsertParagraph')}
                                                value={Obj.InsertParagraph} showArrow={true} size={"default"}
                                            >
                                                {DUFInitData.ParaIns.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                })}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>
                                <br />

                                <Row>
                                    <Col span={18}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{ width: '20%' }} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                               
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                    {
                                  if (isNewDL === true) {
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            NewEffectiveDate: '',
                                            OriginalEffectiveDate: '',
                                            OriginalHearingDate: '',
                                            DLNumber: '',
                                            ModDate: '',
                                            MailDate: '',
                                            AccidentDate: '',
                                            ErrorObj: {},
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                  
                                     else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                    else
                                    {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }}}>Ok</Button>
                            </div>
                        ]}
                    >
                       {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            {/* </ScrollPanel > */}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUFData, saveDUFData,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUFUpdate); 