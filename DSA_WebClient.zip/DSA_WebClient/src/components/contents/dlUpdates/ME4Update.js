import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Checkbox, Modal, Spin } from 'antd';
import { 
    getME4Data, 
    saveME4Data, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
    import { dateFormatFunc } from './../commonFuncs.js';
    import DatePicker from "react-datepicker";
    import "react-datepicker/dist/react-datepicker.css";
    import '../../../dp.css';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';

import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: "",
    NetName: "",
    RequestorCode: "",
    Operator: "",
    DLNumber: "",
    ThreeCharacterName: "",
    Status: '',
    StatusMessage: '',
    MedCertIssueDate: "",
    MedCertExpireDate: "",
    ExaminerLicense: '',
    ExaminerState: '',
    MedCertReceiptDate: '',
    Purge: true,
    Restr1: "",
    Restr2: "",
    Restr3: "",
    Restr4: "",
    Restr5: "",
    Restr6: "",
    Restr7: "",
    Restr8: "",
    Restr9: "",
    Restr10: "",
    WaiverType: '',
    WaiverEffectiveDate: '',
    WaiverExpirationDate: '',
    WaiverRescindDate: '',
    SPEEffectiveDate: '',
    SPEExpirationDate: '',
    SPECancelDate: '',
    ExaminerPhoneNumber: "",
    ExaminerLastName: "",
    ExaminerFirstName: "",
    ExaminerMiddleName: "",
    ExaminerSuffix: "",
    ExaminerTitle: "",
    NationalRegistry: "",
    ME4Response: '',
    NextTran: '',
    Error: true
};

class ME4Update extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            MedCertIssueDate: "",
            MedCertExpireDate: "",
            MedCertReceiptDate: "",
            WaiverEffectiveDate: '',
            WaiverExpirationDate: '',
            WaiverRescindDate: '',
            SPEEffectiveDate: '',
            SPEExpirationDate: '',
            SPECancelDate: '',
            ErrorObj: {},
            PhoneNumber: "",
            ErrorMessage: '',
            ErrorModalShow: false,
            restrCodes: []
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleClearType = this.handleClearType.bind(this);
    }

    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getME4Data(DLInitData.DLNumber, DLInitData.ThreeCharacterName);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.ME4InitData !== this.props.dlUpdates.ME4InitData && this.props.dlUpdates.ME4InitData !== undefined) {
                                let restrCodes = [];
                                for(let i=0; i<=9; i++)
                                {
                                   let type = 'Restr'+(i+1).toString();
                                  if( this.props.dlUpdates.ME4InitData[type] !== "")
                                  {
                                   restrCodes.push(this.props.dlUpdates.ME4InitData[type]);
                                  }
                                }      
                                const Obj =  cloneDeep(this.props.dlUpdates.ME4InitData);
                                Obj['NextTran'] = '';         
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.ME4InitData.ThreeCharacterName;               
                                this.setState({ME4InitData: this.props.dlUpdates.ME4InitData, PhoneNumber: this.props.dlUpdates.ME4InitData['ExaminerPhoneNumber'], ThreeCharacterName: this.props.dlUpdates.ME4InitData.ThreeCharacterName, Obj: Obj, restrCodes: restrCodes});
                            }
                            if ( prevProps.dlUpdates.saveME4Data !== this.props.dlUpdates.saveME4Data && this.props.dlUpdates.saveME4Data !== undefined) {
                                this.setState({saveME4Data: this.props.dlUpdates.saveME4Data, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                                if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, BirthDate:  dateFormatFunc(this.props.dlUpdates.dlInitData.Birthdate, 'MM-DD-YYYY'), isLoading: false });
                            } 
                            }
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { ME4InitData, saveME4Data, dlUpdatesErrorData } = props.dlUpdates;
                if (ME4InitData && ME4InitData !== prevState.ME4InitData) 
                {
                    let restrCodes = [];
                                 for(let i=0; i<=9; i++)
                                 {
                                     
                                    let type = 'Restr'+(i+1).toString();
                                   if( ME4InitData[type] !== "")
                                   {            
     restrCodes.push(ME4InitData[type]);
                                   }
                                 }
                                 const Obj =  cloneDeep(ME4InitData);
                                 Obj['NextTran'] = '';

                    return { ME4InitData: ME4InitData,ThreeCharacterName: ME4InitData.ThreeCharacterName, Obj: Obj, PhoneNumber: ME4InitData['ExaminerPhoneNumber'], restrCodes: restrCodes, isloading: false };
            }
                if (saveME4Data && saveME4Data !== prevState.saveME4Data) return { saveME4Data: saveME4Data, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false};
                return null;
            }

    handleFieldChange(e, field) {
        let { Obj, PhoneNumber } = this.state;
        switch (field) {
            case 'ExaminerPhoneNumber':
            let input = e.target.value.replace(/\D/g,'');
         
            if(input.length < 3 || input.length === 3) {
                PhoneNumber = input;
            } 
            if (input.length > 3) {
                PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3);
            }
            if (e.target.value.length > 6 && e.target.value.length < 10) {
                PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3);
            }
             if (e.target.value.length > 9) {
                PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3,6)+' -'+input.substring(6,10);
            }
            if (e.target.value.length === 11) {
                PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3,6);
            }
           if (e.target.value.length === 6) {
                PhoneNumber = '('+input.substring(0,3)+')';
            }
            this.setState({PhoneNumber});
            break;
            case 'RestrCodes':
            if(e.length < 11)
            {
            this.setState({ restrCodes: e });      
            }
            break;
            case 'Purge':
                Obj[field] = e.target.checked;
                break;
            case 'ThreeCharacterName':
            case 'NextTran':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
            case 'ExaminerFirstName':
            case 'ExaminerLastName':
            
                if ((/^[a-zA-Z-]*$/).test(e.target.value) && e.target.value.length <= 40) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'ExaminerMiddleName':
                if ((/^[a-zA-Z ]*$/).test(e.target.value) && e.target.value.length <= 35) {
                    Obj[field] = e.target.value;
                }
                break;
            case 'ExaminerLicense':
            case 'NationalRegistry':
                if (e.target.value.length <= 14) {
                    Obj[field] = e.target.value;
                }
                break;
    
            case 'ExaminerState':
            case 'WaiverType':
            case 'ExaminerSuffix':
            case 'ExaminerTitle':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d,type) {

        switch(type) {
            case 'MedCertIssueDate':
            this.setState({ MedCertIssueDate: d });
            break;
            case 'MedCertExpireDate':
            this.setState({ MedCertExpireDate: d });
            break;
            case 'MedCertReceiptDate':
            this.setState({ MedCertReceiptDate: d });
            break;
            case 'WaiverEffectiveDate':
            this.setState({ WaiverEffectiveDate: d });
            break;
            case 'WaiverExpirationDate':
            this.setState({ WaiverExpirationDate: d });
            break;
            case 'WaiverRescindDate':
            this.setState({ WaiverRescindDate: d });
            break;
            case 'SPEEffectiveDate':
            this.setState({ SPEEffectiveDate: d });
            break;
            case 'SPEExpirationDate':
            this.setState({ SPEExpirationDate: d });
            break;
            case 'SPECancelDate':
            this.setState({ SPECancelDate: d });
            break;
            default:
            break;
        }
    }
    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }
    
    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
        const { Obj } = this.state;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['ExaminerPhoneNumber'] = this.state.PhoneNumber.replace(/\D/g,'');
        // if(Obj['WaiverEffectiveDate'] === null)
        // {
        //     Obj['WaiverEffectiveDate'] = '';
        // } 
        this.state.restrCodes.map((rc,ind) => {
            
          let type = 'Restr'+(ind+1);
          Obj[type] = rc;
          return "";
        });
        Obj['MedCertIssueDate'] = dateFormatFunc(this.state.MedCertIssueDate);
        Obj['MedCertExpireDate'] = dateFormatFunc(this.state.MedCertExpireDate);
        Obj['MedCertReceiptDate'] = dateFormatFunc(this.state.MedCertReceiptDate);
        Obj['WaiverEffectiveDate'] = dateFormatFunc(this.state.WaiverEffectiveDate);
        Obj['WaiverExpirationDate'] = dateFormatFunc(this.state.WaiverExpirationDate);
        Obj['WaiverRescindDate'] = dateFormatFunc(this.state.WaiverRescindDate);
        Obj['SPEEffectiveDate'] = dateFormatFunc(this.state.SPEEffectiveDate);
        Obj['SPEExpirationDate'] = dateFormatFunc(this.state.SPEExpirationDate);
        Obj['SPECancelDate'] = dateFormatFunc(this.state.SPECancelDate);

        this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
       this.props.saveME4Data(Obj);
    }

    handleClearType(e) {
        const { Obj } = this.state;
        Obj.WaiverType = '';
        Obj.WaiverEffectiveDate = null;
        Obj.WaiverExpirationDate = null;
        Obj.WaiverRescindDate = null;

        this.setState({ Obj });
    }

    render() {
        const { Obj, ME4InitData, saveME4Data, isloading, isNewDL } = this.state;
        return (
            <React-Fragment>
                {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
                {saveME4Data && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {this.setState({openSuccessModal: false}); 
                      if(saveME4Data.Error === false)
                      {  if(Obj.NextTran !== null && Obj.NextTran !== '')
                      {
                          this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                          state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                      }
                      else if(isNewDL !== true ) {
                        this.props.history.push({ pathname: `/dlUpdates`,
                 state: {dlNumber: saveME4Data.DLNumber}})}
                else
                 {
                     this.setState({ Obj: cloneDeep(defaultObj),                        
                        MedCertIssueDate: "",
                        DLNumber: '',
                        MedCertExpireDate: "",
                        ExaminerLicense: "",
                        ExaminerState: "",
                        WaiverEffectiveDate: "", 
                        WaiverExpirationDate: "", 
                        WaiverRescindDate: "", 
                        SPEEffectiveDate: "", 
                        SPEExpirationDate: "", 
                        SPECancelDate: "",
                        ErrorObj: {},
                        ErrorMessage: '',
                        ErrorModalShow: false,
                        PhoneNumber: "",
                        restrCodes: []
                     });
                 }}}
                }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: saveME4Data.ME2Response.toString()}}/>
           </div></Modal>}
              {ME4InitData ?
                ME4InitData.Message !== null ? <Modal maskClosable={false} title={"ME4 Message"} visible={true} onCancel={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
                state: {dlNumber: ME4InitData.DLNumber}})}} footer={[<Button type="primary" key="Ok" onClick={(e) => { this.props.history.push({ pathname: `/dlUpdates`,
                state: {dlNumber: ME4InitData.DLNumber}})}}>OK</Button>]}><div>{ME4InitData.Message}</div></Modal> :
                <div><div style={{
                    border: '1px solid black',
                    paddingLeft: "1%",
                    textAlign: 'center',
                    backgroundColor: '#c9e3fa',
                    fontSize: '32px'
                    }} >Medical Certificate Correction (ME4)</div><Form style={{height: "70%"}} className="ant-advanced-search-form">
                   {isNewDL ? <Row>
                        <Col span={5} style={{ display: 'block' }}>
                            <FormItem
                               hasFeedback
                               validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                               help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                label={<b>DL # </b>}

                            >
                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                            </FormItem>
                        </Col>
                        <Col span={1} />
                        <Col span={5} offset={1}>
                            <FormItem
                                label={<b>3 Pos Last Name </b>}
                            >
                                <Input value={Obj.ThreeCharacterName} maxLength={3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                            </FormItem>
                        </Col>
                        <Col span={1} />
                        <Col span={5} offset={1} style={{ height: '39px' }} >
                            <span style={{ color: 'blue', fontWeight: 'bold', verticalAlign: 'middle' }}>
                                {Obj.StatusMessage}
                            </span>
                        </Col>
                    </Row> :
                                 <Row>
                                 <Col span={5}>
                                     <b>DL Number</b>:{" "}{this.state.DLNumber}
                                 </Col>
                                 <Col span={1} />
                                 <Col span={5}>
                                     <b>3 Pos Last Name</b>:{" "}{this.state.ThreeCharacterName}
                                 </Col>
                                 <Col span={1} />
                                 <Col span={5} offset={1} style={{ height: '39px' }} >
                            <span style={{ color: 'blue', fontWeight: 'bold', verticalAlign: 'middle' }}>
                                {Obj.StatusMessage}
                            </span>
                        </Col>
                             </Row>}
                 <Row>
                     <Col span={9}>
                         <FormItem
                             label={<b>Date of Exam/Med Cert Issue Date  </b>}
                         >
                                          <Input size={"small"} value={Obj.MedCertIssueDate}
                                disabled
                            />
                         </FormItem>
                     </Col>
                     <Col span={1} />
                     <Col span={7}>
                         <FormItem
                             label={<b>Med Cert Exp Date  </b>}
                         >                     
 <Input size={"small"}  value={Obj.MedCertExpireDate}
                                disabled
                            />
                         </FormItem>
                     </Col>
                     </Row>
                     <Row>
                    <Col span={7}>
                        <FormItem
                             validateStatus = {this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLicense"] ? 'error' : ""}
                             help = {this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLicense"]}
                            label={<b>Examiner License # </b>}
                        >
                            <Input size={"small"}  value={Obj.ExaminerLicense} placeholder="Examiner License #"
                                disabled
                            />
                        </FormItem>
                    </Col>
                    <Col span={1} />
                     <Col span={8}>
                     <FormItem
                         label={<b>State of Issue  </b>}
                     >
                          <Input size={"small"}  value={Obj.ExaminerState} placeholder="Examiner State"
                                disabled
                            />
                     </FormItem>
                 </Col>
                 <Col span={1} />
                 <Col span={7}>
                 <FormItem
                     label={<b>Med Cert Receipt Date  </b>}
                 >
                                   <Input size={"small"} value={Obj.MedCertReceiptDate}
                                disabled
                            />
                 </FormItem>
             </Col>
                    </Row>
                    <div style={{ width: '65%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px', textAlign: 'center' }}>
                        <Checkbox checked={Obj.Purge}
                            onChange={e => this.handleFieldChange(e, 'Purge')}
                            placeholder="input placeholder">
                            PURGE THIS RECORD
                        </Checkbox>
                    </div>
                    <br />
                    <div style={{ width: '75%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                        <Row>
                            <Col>
                                <h3>Only Qualified When (MED CERT RESTRICTION CODES)</h3>
                                <hr />
                            </Col>
                        </Row>
                        <Row>
                            <Col span={15}>
                                <FormItem
                                    label={<b>Restriction Codes </b>}
                                >
                                    <Select allowClear = {true} id = "SRC" onFocus={(e) => {
                                document.getElementById("SRC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} mode="multiple" placeholder="Please select upto 10 codes"   onChange={e => this.handleFieldChange(e, 'RestrCodes')}
                               value={this.state.restrCodes} showArrow={true} size={"default"}
                           >
                               {ME4InitData.RestrictionCodes.map((rc) => {
                                   return <Option key={rc.Value} value={rc.Value}>{rc.Value} - {rc.Text}</Option>
                               })}
                           </Select>
                                </FormItem>
                            </Col>
                        </Row>
                    </div>
                    <br />
                    <div style={{ width: '75%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                        <Row>
                            <Col>
                                <h3>Waiver / Exemption</h3>
                                <hr />
                            </Col>
                        </Row>
                        <Row>
                            <Col span={8}>
                                <FormItem
                                    label={<b>Type </b>}
                                >
                                    <Select allowClear = {true} id = "STY" onFocus={(e) => {
                                document.getElementById("STY").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'WaiverType')} disabled={Obj.WaiverType === null ? true: false}
                                        value={Obj.WaiverType} showArrow={true} size={"default"}
                                    >
                                        {ME4InitData.WaiverTypeSelect.map(item => <Option key={item.Value} value={item.Value}>{item.Text}</Option>)}
                                    </Select>
                                </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <Button type="primary" key="Clear Type"
                                    onClick={this.handleClearType}>
                                    Clear Type
                                </Button>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={6}>
                                <FormItem
                                  validateStatus = {this.state.WaiverEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverEffectiveDate"] ? 'error' : ""}
                                  help = {this.state.WaiverEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverEffectiveDate"]}
                                    label={<b>Effective Date </b>}
                                >
                                  
                                  <DatePicker
                       className = "CalClass"
                       selected={this.state.WaiverEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'WaiverEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                 validateStatus = {this.state.WaiverExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverExpirationDate"] ? 'error' : ""}
                                 help = {this.state.WaiverExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["WaiverExpirationDate"]}
                                    label={<b>Expiration Date </b>}
                                >
                                 <DatePicker
                       className = "CalClass"
                       selected={this.state.WaiverExpirationDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'WaiverExpirationDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                    label={<b>Rescind Date </b>}
                                >
                                   <DatePicker
                       className = "CalClass"
                       selected={this.state.WaiverRescindDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'WaiverRescindDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                        </Row>
                    </div>
                    <br />
                    <div style={{ width: '75%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                        <Row>
                            <Col>
                                <h3>Skill Performance Evaluation (SPE)</h3>
                                <hr />
                            </Col>
                        </Row>
                        <Row>
                            <Col span={6}>
                                <FormItem
                                validateStatus = {this.state.SPEEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEEffectiveDate"] ? 'error' : ""}
                                help = {this.state.SPEEffectiveDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEEffectiveDate"]}
                                    label={<b>SPE Effective Date </b>}
                                >
                                   <DatePicker
                       className = "CalClass"
                       selected={this.state.SPEEffectiveDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'SPEEffectiveDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                  validateStatus = {this.state.SPEExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEExpirationDate"] ? 'error' : ""}
                                  help = {this.state.SPEExpirationDate === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SPEExpirationDate"]}
                                    label={<b>SPE Expiration Date </b>}
                                >
                                   <DatePicker
                       className = "CalClass"
                       selected={this.state.SPEExpirationDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'SPEExpirationDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                            <Col span={6} offset={1}>
                                <FormItem
                                    label={<b>SPE Cancel Date </b>}
                                >
                                  <DatePicker
                       className = "CalClass"
                       selected={this.state.SPECancelDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'SPECancelDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                            </Col>
                        </Row>
                    </div>
                    <br />
                    <div style={{ width: '75%', border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                        <Row>
                            <Col>
                                <h3>Medical Examiner Information</h3>
                                <hr />
                            </Col>
                        </Row>
                        <Row>
                        <Col span={8} offset={1}>
                        <FormItem
                          validateStatus = {Obj.ExaminerLastName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLastName"] ? 'error' : ""}
                          help = {Obj.ExaminerLastName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLastName"]}
                            label={<b>Examiner Last Name  </b>} 
                        >
                            <Input value={Obj.ExaminerLastName} placeholder="Examiner Last Name"
                                onChange={e => this.handleFieldChange(e, 'ExaminerLastName')}
                            />
                        </FormItem>
                    </Col>
                    <Col span={8}>
                    <FormItem
                                              validateStatus = {Obj.NationalRegistry === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["NationalRegistry"] ? 'error' : ""}
                                              help = {Obj.NationalRegistry === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["NationalRegistry"]}
                        label={<b>National Registry #  </b>}
                    >
                        <Input value={Obj.NationalRegistry} placeholder="National Registry #"
                            onChange={e => this.handleFieldChange(e, 'NationalRegistry')}
                        />
                    </FormItem>
                </Col>
                        </Row>
                        <Row>
                        <Col span={8}>
                        <FormItem
                                                validateStatus = {Obj.ExaminerFirstName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerFirstName"] ? 'error' : ""}
                                                help = {Obj.ExaminerFirstName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerFirstName"]}
                            label={<b>Examiner First Name  </b>}
                        >
                            <Input value={Obj.ExaminerFirstName} placeholder="Examiner First Name"
                                onChange={e => this.handleFieldChange(e, 'ExaminerFirstName')}
                            />
                        </FormItem>
                    </Col>
                        </Row>
                        <Row>
                        <Col span={8}  offset={1}>
                        <FormItem
                                                                        validateStatus = {Obj.ExaminerMiddleName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerMiddleName"] ? 'error' : ""}
                                                                        help = {Obj.ExaminerMiddleName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerMiddleName"]}
                            label={<b>Examiner Middle Name  </b>}
                        >
                            <Input value={Obj.ExaminerMiddleName} placeholder="Examiner Middle Name"
                                onChange={e => this.handleFieldChange(e, 'ExaminerMiddleName')}
                            />
                        </FormItem>
                    </Col>
                        </Row>
                        <Row>
                        <Col span={8}>
                        <FormItem
                                                                        validateStatus = {Obj.ExaminerSuffix === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerSuffix"] ? 'error' : ""}
                                                                        help = {Obj.ExaminerSuffix === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerSuffix"]}
                            label={<b>Examiner Suffix  </b>}
                        ><Select allowClear = {true} id = "SES" onFocus={(e) => {
                            document.getElementById("SES").click();
                                                                   }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select"   onChange={e => this.handleFieldChange(e, 'ExaminerSuffix')}
                                value={Obj.ExaminerSuffix} showArrow={true} size={"default"}
                            >
                            </Select>
                        </FormItem>
                    </Col>
                            <Col span={8}  offset={1}>
                            <FormItem
                                                                            validateStatus = {Obj.ExaminerTitle === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerTitle"] ? 'error' : ""}
                                                                            help = {Obj.ExaminerTitle === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerTitle"]}
                                label={<b>Examiner Title  </b>}
                            ><Select allowClear = {true} id = "SET" onFocus={(e) => {
                                document.getElementById("SET").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select"   onChange={e => this.handleFieldChange(e, 'ExaminerTitle')}
                                    value={Obj.ExaminerTitle} showArrow={true} size={"default"}
                                >
                                    {ME4InitData.ExaminerTitleSelect.map((et) => {
                                        return <Option key={et.Value} value={et.Value}>{et.Value}-{et.Text}</Option>
                                    })}
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span={8}>
                        <FormItem
                                                                        validateStatus = {this.state.PhoneNumber === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerPhoneNumber"] ? 'error' : ""}
                                                                        help = {this.state.PhoneNumber === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerPhoneNumber"]}
                            label={<b>Examiner Phone # </b>} 
                        >
                            <Input value={this.state.PhoneNumber} placeholder="Examiner Phone #"
                                onChange={e => this.handleFieldChange(e, 'ExaminerPhoneNumber')}
                            />
                        </FormItem>
                    </Col>
                        </Row>
                    </div>
                    <br />
                    <Row>
                        <Col span={8}>
                            <FormItem
                                label={<b>Next Trans  </b>}
                            >
                                <Input value={Obj.NextTran} maxLength = {3} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextTran')} />
                            </FormItem>
                        </Col>
                        <Col span={13} style={{ float: 'right' }}>
                        {Obj.NextTran !== '' ? <Button disabled
                           type="default">New DL</Button>:   <Button style={{ color: "white", backgroundColor: "green" }}
                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                            <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                            <Button style={{ color: "white", backgroundColor: "red" }}
                                type="default" key="Cancel" onClick={(e) => this.props.history.push({ pathname: `/dlUpdates`,
                                state: {dlNumber: this.state.DLNumber}})}>Cancel</Button>
                        </Col>
                    </Row>
                </Form></div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                                {this.setState({ErrorModalShow: false});
                                if( !this.state.ErrorObj )
                                { if(isNewDL === true)
                                {
                                    this.setState({ Obj: cloneDeep(defaultObj),                                        
                                       MedCertIssueDate: "",
                                       DLNumber: '',
                                       MedCertExpireDate: "",
                                       ExaminerLicense: "",
                                       ExaminerState: "",
                                       WaiverEffectiveDate: "", 
                                       WaiverExpirationDate: "", 
                                       WaiverRescindDate: "", 
                                       SPEEffectiveDate: "", 
                                       SPEExpirationDate: "", 
                                       SPECancelDate: "",
                                       ErrorObj: {},
                                       ErrorMessage: '',
                                       ErrorModalShow: false,
                                       PhoneNumber: "",
                                       restrCodes: []
                                    });
                                }
                                else if(Obj.NextTran !== null && Obj.NextTran !== '')
                                {
                                    this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                    state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                }   
                                else {
                                    this.props.history.push({ pathname: `/dlUpdates`,
                                    state: {dlNumber: this.state.DLNumber}});
                                }
}}}>Ok</Button>
                        </div>
                    ]}
                >
                  {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
      dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getME4Data, saveME4Data, getDLInitialData
        },
        dispatch
    );
};
export default connect(mapStateToProps, mapDispatchToProps)(ME4Update); 