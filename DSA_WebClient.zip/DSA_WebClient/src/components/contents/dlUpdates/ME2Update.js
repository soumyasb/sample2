import React, { Component } from 'react';
import { dateFormatFunc } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { 
    getME2Data, 
    saveME2Data, getDLInitialData } from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Spin, Input, Select, Button, Modal, Form, Checkbox } from 'antd'; 
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const { Option } = Select;
const FormItem = Form.Item;
const defaultObj = {
  
        LoginId: "",
        NetName: "",
        RequestorCode: "",
        Operator: "",
        DLNumber: "",
        ThreeCharacterName: "",
        MedCertIssueDate: "",
        MedCertExpireDate: "",
        MedCertReceivedDate: "",
        Restr1: "",
        Restr2: "",
        Restr3: "",
        Restr4: "",
        Restr5: "",
        Restr6: "",
        Restr7: "",
        Restr8: "",
        Restr9: "",
        Restr10: "",
        ExaminerPhoneNumber: "",
        ExaminerLastName: "",
        ExaminerFirstName: "",
        ExaminerMiddleName: "",
        ExaminerSuffix: "",
        ExaminerTitle: "",
        ExaminerLicense: "",
        ExaminerState: "",
        NationalRegistry: "",
        SelfCertCode: "",
        PurgeFlag: "",
        Valid: false,
        InValid: false,
        ME2Response: "",
        ME5Response: "",
        ME6Response: "",
        NextTran: "",
        Error: true
      }

class ME2Update extends Component {
    constructor(props) {
        super(props);

        this.state={
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            MedCertIssueDate: "",
            MedCertExpireDate: "",
            CAState: true,
            restrCodes: [],
            MedCertReceivedDate: "",
            ErrorObj: {},
            PhoneNumber: "",
            ErrorMessage: '',
            ErrorModalShow: false
        }
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
    }
    componentDidMount(){
        if(sessionStorage.getItem('dlInitData')){
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
               this.setState({
                   DLNumber: DLInitData.DLNumber,
                   ThreeCharacterName: DLInitData.ThreeCharacterName,
                   BirthDate: DLInitData.Birthdate
               });
               this.props.getME2Data(DLInitData.DLNumber, DLInitData.ThreeCharacterName);
           }
           else 
           {
               this.props.history.push(`/dlUpdates`);
           }
                }
    componentDidUpdate(prevProps){
                    
                            if ( prevProps.dlUpdates.ME2InitData !== this.props.dlUpdates.ME2InitData && this.props.dlUpdates.ME2InitData !== undefined) {
                                const Obj = cloneDeep(defaultObj);
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.ME2InitData.ThreeCharacterName;   
                                const ME2InitData = cloneDeep(this.props.dlUpdates.ME2InitData);     
                                ME2InitData.SelfCertCode[0].Text = "Non-excepted Intrastate";
                                ME2InitData.SelfCertCode[1].Text = "Non-excepted Interstate";                      
                                this.setState({ME2InitData: ME2InitData, Obj: Obj});
                            }
                            if ( prevProps.dlUpdates.saveME2Data !== this.props.dlUpdates.saveME2Data && this.props.dlUpdates.saveME2Data !== undefined) {
                                this.setState({saveME2Data: this.props.dlUpdates.saveME2Data, openSuccessModal: true});
                            }
                            if ( this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData ) {
                                if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
                               
                            }
                            if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
                            {
                                
                             sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
                                const Obj = cloneDeep(defaultObj);
                               Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
                                this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isLoading: false });
                            } 
    }
    static getDerivedStateFromProps(props, prevState) {
        
                const { ME2InitData, saveME2Data, dlUpdatesErrorData } = props.dlUpdates;
                if (ME2InitData && ME2InitData !== prevState.ME2InitData)
                {
                    const ME2ID = cloneDeep(ME2InitData);     
                    ME2InitData.SelfCertCode[0].Text = "Non-excepted Intrastate";
                    ME2InitData.SelfCertCode[1].Text = "Non-excepted Interstate";  
                    return { ME2InitData: ME2ID, isloading: false };
                } 
                if (saveME2Data && saveME2Data !== prevState.saveME2Data) return { saveME2Data: saveME2Data, isloading: false };
                if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData) return {dlUpdatesErrorData, isloading: false };
                return null;
            }
            handleFieldChange(e, type) {
                
                let { Obj, PhoneNumber } = this.state;
                switch (type) {
                    case 'ExaminerPhoneNumber':
                    let input = e.target.value.replace(/\D/g,'');
                 
                    if(input.length < 3 || input.length === 3) {
                        PhoneNumber = input;
                    } 
                    if (input.length > 3) {
                        PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3);
                    }
                    if (e.target.value.length > 6 && e.target.value.length < 10) {
                        PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3);
                    }
                     if (e.target.value.length > 9) {
                        PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3,6)+' -'+input.substring(6,10);
                    }
                    if (e.target.value.length === 11) {
                        PhoneNumber = '('+input.substring(0,3)+') '+input.substring(3,6);
                    }
                   if (e.target.value.length === 6) {
                        PhoneNumber = '('+input.substring(0,3)+')';
                    }
                    this.setState({PhoneNumber});
                    break;
                    case 'RestrCodes':
                    if(e.length < 11)
                    {
                    this.setState({ restrCodes: e });      
                    }
                    break;
                    case 'Valid':
                    if(e.target.checked === true)
                    {
                        Obj['InValid'] = false;
                    }
                    Obj['Valid'] = e.target.checked;
                    break;
                    case 'InValid':
                    if(e.target.checked === true)
                    {
                        Obj['Valid'] = false;
                    }
                    Obj['InValid'] = e.target.checked;
                    break;
                    case 'ExaminerLastName':
                    case 'ExaminerFirstName':
                    if ((/^[a-zA-Z-]*$/).test(e.target.value) && e.target.value.length <= 40) {
                        Obj[type] = e.target.value;
                    }
                    break;
                    case 'ExaminerMiddleName':
                    if ((/^[a-zA-Z ]*$/).test(e.target.value) && e.target.value.length <= 35) {
                        Obj[type] = e.target.value;
                    }
                    break;
                    case 'ExaminerLicense':
                    case 'NationalRegistry':
                    if (e.target.value.length <= 14) {
                        Obj[type] = e.target.value;
                    }
                    break;
                   
                    case 'ExaminerSuffix':
                    case 'ExaminerTitle':
                    case 'SelfCertCode':
                    case 'ExaminerState':
                    if(!e)
                    {
                        Obj[type] = '';
                    }
                        else
                        {
                            Obj[type] = e;
                        }
                    break;
                    case 'CAState':
                    this.setState({CAState: e.target.checked});
                    break;
                    case 'PurgeFlag':
                    Obj[type] = e.target.checked;
                    break;
                    case 'ThreeCharacterName':
                case 'NextTran':
                    Obj[type] = e.target.value;
                break;
                case 'DLNumber':
                this.setState({DLNumber: e.target.value});
                Obj[type] = e.target.value;
                    if ((Obj['DLNumber'].length === 8)) {
                          this.props.getDLInitialData(Obj['DLNumber']);
                          this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                    }
                    break;
                    default:
                        break;
                }
        
                this.setState({ Obj });
            }
        
            onDateChange(d, type) {
                switch(type) {
                    case 'MedCertIssueDate':
                    this.setState({ MedCertIssueDate: d });
                    break;
                    case 'MedCertExpireDate':
                    this.setState({ MedCertExpireDate: d });
                    break;
                    case 'MedCertReceivedDate':
                    this.setState({ MedCertReceivedDate: d });
                    break;
                    default:
                    break;
                }
                }
        
            handleModalClose() {
                this.setState({ ErrorModalShow: false, ErrorMessage: '' });
            }
        
            handleUpdate(type) {
                let isNewDL = false;
                if(type === 'new')
                {
          isNewDL = true;
                      sessionStorage.removeItem('dlInitData');   
                    }
                    else
                    {
            isNewDL = false;
                    }
                    const { Obj } = this.state;
                   
                    Obj['RequestorCode'] = this.state.ME2InitData.RequestorCode;
                    Obj['Operator'] = this.state.ME2InitData.Operator;
                    Obj['NetName'] = this.state.ME2InitData.NetName;
                    Obj['LoginId'] = this.state.ME2InitData.LoginId;
                    Obj['DLNumber'] = this.state.DLNumber;
                    Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
                    Obj['ExaminerPhoneNumber'] = this.state.PhoneNumber.replace(/\D/g,'');
                    if(this.state.CAState === true)
                    {
                        Obj['ExaminerState'] = "CA";
                    }
                    this.state.restrCodes.map((rc,ind) => {
                        
                      let type = 'Restr'+(ind+1);
                      Obj[type] = rc;
                      return "";
                    });
                    Obj['MedCertIssueDate'] = dateFormatFunc(this.state.MedCertIssueDate);
                    Obj['MedCertExpireDate'] = dateFormatFunc(this.state.MedCertExpireDate);
                    Obj['MedCertReceivedDate'] = dateFormatFunc(this.state.MedCertReceivedDate);
                    this.setState({isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL});
                   this.props.saveME2Data(Obj);
                }

    render() {
        
        const { Obj } = this.state;
        const { ME2InitData, saveME2Data, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
             {isloading !== true ?  <div style={{backgroundColor: "white", width: "95%", marginLeft: '2%'}}> 
               {saveME2Data && <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({openSuccessModal: false})} footer={[<Button type="primary" key="Ok" onClick={(e) => {
                   this.setState({openSuccessModal: false}); 
                   if(saveME2Data.Error === false)
                   { if (Obj.NextTran !== '')
                   {
                       this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                       state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                   }
                   else if(isNewDL !== true ) {
                   this.props.history.push({ pathname: `/dlUpdates`,
            state: {dlNumber: saveME2Data.DLNumber}})}
          else
            {
                this.setState({Obj: cloneDeep(defaultObj),                    
                    MedCertIssueDate: "",
                    MedCertExpireDate: "",
                    DLNumber: '',
                    CAState: true,
                    restrCodes: [],
                    MedCertReceivedDate: "",
                    PhoneNumber: "",
                    ErrorMessage: '',
                    ErrorModalShow: false
                });
            }                     
}}
               }>OK</Button>]}><div><div dangerouslySetInnerHTML={{ __html: saveME2Data.ME2Response.toString()}}/>
            <div dangerouslySetInnerHTML={{ __html: saveME2Data.ME5Response.toString()}}/>
            <div dangerouslySetInnerHTML={{ __html: saveME2Data.ME6Response.toString()}}/></div></Modal>}
            {ME2InitData ?   
              <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Medical Examination Report (ME2)</div>
               <Form className="ant-advanced-search-form">
               {isNewDL ? <Row>
                   <Col span={5} style={{ display: 'block' }}>
                       <FormItem
                          hasFeedback
                          validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                          help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                           label={<b>DL # </b>}

                       >
                           <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                       </FormItem>
                   </Col>
                   <Col span={5} offset={1}>
                       <FormItem
                           label={<b>3 Pos Last Name </b>}
                       >
                           <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                       </FormItem>
                   </Col>
               </Row> :
               <Row>
                               <Col span={5}>
                                   <b>DL Number</b>:{" "}{this.state.DLNumber}
                               </Col>
                               <Col span={1} />
                               <Col span={5}>
                                   <b>3 Pos Last Name</b>:{" "}{this.state.ThreeCharacterName}
                               </Col>
                           </Row>
               }
         
               <Row>
                   <Col span={9}>
                       <FormItem
                         validateStatus = {this.state.MedCertIssueDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertIssueDate"] ? 'error' : ""}
                         help = {this.state.MedCertIssueDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertIssueDate"]}
                           label={<b>Date of Exam/Med Cert Issue Date <font color='red'>*</font></b>}
                       >
                              <DatePicker
                       className = "CalClass"
                       selected={this.state.MedCertIssueDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MedCertIssueDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                   </Col>
                   <Col span={7}>
                       <FormItem
                         validateStatus = {this.state.MedCertExpireDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertExpireDate"] ? 'error' : ""}
                         help = {this.state.MedCertExpireDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertExpireDate"]}
                           label={<b>Med Cert Exp Date <font color='red'>*</font></b>}
                       >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.MedCertExpireDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MedCertExpireDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                   </Col>
                   <Col span={7}>
                       <FormItem
                         validateStatus = {this.state.MedCertReceivedDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertReceivedDate"] ? 'error' : ""}
                         help = {this.state.MedCertReceivedDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MedCertReceivedDate"]}
                           label={<b>Med Cert Received Date <font color='red'>*</font></b>}
                       >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.MedCertReceivedDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MedCertReceivedDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     /> </FormItem>
                   </Col>
               </Row>
               <Row>
               <Col>
                       <FormItem
                           label={<b>Only Qualified When (MED CERT RESTRICTION CODES)  </b>}
                       >
                             <Select allowClear = {true} id = "SRC" onFocus={(e) => {
                                document.getElementById("SRC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} mode="multiple" placeholder="Please select upto 10 codes"   onChange={e => this.handleFieldChange(e, 'RestrCodes')}
                               value={this.state.restrCodes} showArrow={true} size={"default"}
                           >
                               {ME2InitData.RestrictionCodes.map((rc) => {
                                   return <Option title={`${rc.Value} - ${rc.Text}`} key={rc.Value} value={rc.Value}>{rc.Value} - {rc.Text}</Option>
                               })}
                           </Select>
        
                       </FormItem>
                       </Col>
               </Row>
               <b>Medical Examiner Information</b>
               <Row>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {this.state.PhoneNumber === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerPhoneNumber"] ? 'error' : ""}
                         help = {this.state.PhoneNumber === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerPhoneNumber"]}
                           label={<b>Examiner Phone # <font color='red'>*</font></b>} 
                       >
                           <Input value={this.state.PhoneNumber} placeholder="Examiner Phone #"
                               onChange={e => this.handleFieldChange(e, 'ExaminerPhoneNumber')}
                           />
                       </FormItem>
                   </Col>
                   <Col span={8} offset={1}>
                       <FormItem
                         validateStatus = {Obj.ExaminerLastName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLastName"] ? 'error' : ""}
                         help = {Obj.ExaminerLastName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLastName"]}
                           label={<b>Examiner Last Name <font color='red'>*</font></b>} 
                       >
                           <Input value={Obj.ExaminerLastName} placeholder="Examiner Last Name"
                               onChange={e => this.handleFieldChange(e, 'ExaminerLastName')}
                           />
                       </FormItem>
                   </Col>
                   </Row>
                   <Row>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {Obj.ExaminerFirstName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerFirstName"] ? 'error' : ""}
                         help = {Obj.ExaminerFirstName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerFirstName"]}
                           label={<b>Examiner First Name <font color='red'>*</font></b>}
                       >
                           <Input value={Obj.ExaminerFirstName} placeholder="Examiner First Name"
                               onChange={e => this.handleFieldChange(e, 'ExaminerFirstName')}
                           />
                       </FormItem>
                   </Col>
                   <Col span={8}  offset={1}>
                       <FormItem
                         validateStatus = {Obj.ExaminerMiddleName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerMiddleName"] ? 'error' : ""}
                         help = {Obj.ExaminerMiddleName === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerMiddleName"]}
                           label={<b>Examiner Middle Name  </b>}
                       >
                           <Input value={Obj.ExaminerMiddleName} placeholder="Examiner Middle Name"
                               onChange={e => this.handleFieldChange(e, 'ExaminerMiddleName')}
                           />
                       </FormItem>
                   </Col>
                   </Row>
                   <Row>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {Obj.ExaminerSuffix === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerSuffix"] ? 'error' : ""}
                         help = {Obj.ExaminerSuffix === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerSuffix"]}
                           label={<b>Examiner Suffix  </b>}
                       ><Select allowClear = {true} id = "SelES" onFocus={(e) => {
                        document.getElementById("SelES").click();
                                                               }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select"   onChange={e => this.handleFieldChange(e, 'ExaminerSuffix')}
                               value={Obj.ExaminerSuffix} showArrow={true} size={"default"}
                           >
                               {ME2InitData.ExaminerSuffix.map((es) => {
                                   return <Option title={`${es.Value} - ${es.Text}`} key={es.Value} value={es.Value}>{es.Value} - {es.Text}</Option>
                               })}
                           </Select>
                       </FormItem>
                   </Col>
                   <Col span={8}  offset={1}>
                       <FormItem
                         validateStatus = {Obj.ExaminerTitle === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerTitle"] ? 'error' : ""}
                         help = {Obj.ExaminerTitle === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerTitle"]}
                           label={<b>Examiner Title <font color='red'>*</font></b>}
                       ><Select allowClear = {true} id = "SelET" onFocus={(e) => {
                        document.getElementById("SelET").click();
                                                               }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select"   onChange={e => this.handleFieldChange(e, 'ExaminerTitle')}
                               value={Obj.ExaminerTitle} showArrow={true} size={"default"}
                           >
                               {ME2InitData.ExaminerTitle.map((et) => {
                                   return <Option title={`${et.Value} - ${et.Text}`} key={et.Value} value={et.Value}>{et.Value} - {et.Text}</Option>
                               })}
                           </Select>
                       </FormItem>
                   </Col>
                   </Row>
               <Row>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {Obj.ExaminerLicense === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLicense"] ? 'error' : ""}
                         help = {Obj.ExaminerLicense === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerLicense"]}
                           label={<b>Examiner License # <font color='red'>*</font></b>}
                       >
                           <Input value={Obj.ExaminerLicense} placeholder="Examiner License #"
                               onChange={e => this.handleFieldChange(e, 'ExaminerLicense')}
                           />
                       </FormItem>
                   </Col>
                   <Col span={5}>
                   <Checkbox style={{marginLeft: '20%', marginTop: '5%'}} checked={this.state.CAState}  onChange={e => this.handleFieldChange(e, 'CAState')}>
                               <b>Use CA for State</b>
                            </Checkbox>  
                   </Col>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {Obj.ExaminerState === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerState"] ? 'error' : ""}
                         help = {Obj.ExaminerState === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["ExaminerState"]}
                           label={<b>State of Issue  </b>}
                       >
                           <Select allowClear = {true} id = "SSI" onFocus={(e) => {
                                document.getElementById("SSI").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} disabled={this.state.CAState} onChange={e => this.handleFieldChange(e, 'ExaminerState')}
                               value={Obj.ExaminerState} showArrow={true} size={"default"}
                           >
                                {ME2InitData.States.map((st) => {
                                    return <Option title={`${st.Value} - ${st.Text}`} key={st.Value} value={st.Value}>{st.Value} - {st.Text}</Option>
                                })}
                           </Select>
                       </FormItem>
                   </Col>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {Obj.NationalRegistry === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["NationalRegistry"] ? 'error' : ""}
                         help = {Obj.NationalRegistry === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["NationalRegistry"]}
                           label={<b>National Registry #  </b>}
                       >
                           <Input value={Obj.NationalRegistry} placeholder="National Registry #"
                               onChange={e => this.handleFieldChange(e, 'NationalRegistry')}
                           />
                       </FormItem>
                   </Col>
               </Row>
               <b> Self Certification </b>
               <Row>
                   <Col span={8}>
                       <FormItem
                         validateStatus = {Obj.SelfCertCode === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SelfCertCode"] ? 'error' : ""}
                         help = {Obj.SelfCertCode === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["SelfCertCode"]}
                           label={<b>Self-Cert Code <font color='red'>*</font></b>}
                       >
                           <Select allowClear = {true} id = "SelSC" onFocus={(e) => {
                                document.getElementById("SelSC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'SelfCertCode')}
                               value={Obj.SelfCertCode} showArrow={true} size={"default"}
                           >
                                {ME2InitData.SelfCertCode.map((scc) => {
                                    return <Option title={`${scc.Value} - ${scc.Text}`} key={scc.Value} value={scc.Value}>{scc.Value} - {scc.Text}</Option>
                                })}
                           </Select>
                       </FormItem>
                   </Col>
               </Row>
               <Row>
               <Col span={8} offset={1}>
                       <FormItem
                         validateStatus = {Obj.Valid === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["Valid"] ? 'error' : ""}
                         help = {Obj.Valid === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["Valid"]}
                           label=""
                       >
                            <Checkbox checked={Obj.Valid}  onChange={e => this.handleFieldChange(e, 'Valid')}>
                               Valid?
                            </Checkbox>   
                       </FormItem>
                   </Col>
               <Col span={8} offset={1}>
                       <FormItem
                         validateStatus = {Obj.InValid === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["InValid"] ? 'error' : ""}
                         help = {Obj.InValid === "" && this.state.ErrorObj !== {}  && this.state.ErrorObj["InValid"]}
                           label=""
                       >
                            <Checkbox checked={Obj.InValid}  onChange={e => this.handleFieldChange(e, 'InValid')}>
                               InValid?
                            </Checkbox>   
                       </FormItem>
                   </Col>
               </Row>
               <Row>
                   <Col span={8}>
                       <FormItem
                           label={<b>Next Trans  </b>}
                       >
                           <Input value={Obj.NextTran} maxLength = {3} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextTran')} />
                       </FormItem>
                   </Col>
                   <Col span={13} style={{ float: 'right' }}>
                       {Obj.NextTran !== '' ? <Button disabled
                           type="default">New DL</Button>:<Button style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                       <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                       <Button style={{ color: "white", backgroundColor: "red" }}
                           type="default" key="Cancel" onClick={(e) => 
                            {  
                                this.props.history.push({ pathname: `/dlUpdates`,
                           state: {dlNumber: this.state.DLNumber}})}
                        }>Cancel</Button>
                   </Col>
               </Row>
           </Form></div>  : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
                <Modal visible={this.state.ErrorModalShow}
                    title={'Error message'} maskClosable={false}
                    footer={[
                        <div>
                            <Button type="primary" key="Ok" onClick={(e) => 
                            {
                                this.setState({ErrorModalShow: false});
                                if( !this.state.ErrorObj )
                                { if(isNewDL === true)
                                {
                                    this.setState({Obj: cloneDeep(defaultObj),
                                        MedCertIssueDate: "",
                                        MedCertExpireDate: "",
                                        DLNumber: '',
                                        CAState: true,
                                        restrCodes: [],
                                        MedCertReceivedDate: "",
                                        PhoneNumber: "",
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                }
                                else if(Obj.NextTran !== '')
                                {
                                    this.props.history.push({ pathname: `/${Obj.NextTran.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                    state: {DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate}});
                                }
                                  else  {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }
                        }}>Ok</Button>
                        </div>
                    ]}
                >
                 {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                </Modal>
                </div> : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
             </React-Fragment>
        );
            }
        }
            
            const mapStateToProps = state => {
                return {
                  dlUpdates: state.dlUpdates
                };
            };
            
            const mapDispatchToProps = dispatch => {
                return bindActionCreators(
                    {
                        getME2Data, saveME2Data, getDLInitialData
                    },
                    dispatch
                );
            };
            
            export default connect(mapStateToProps, mapDispatchToProps)(ME2Update);
