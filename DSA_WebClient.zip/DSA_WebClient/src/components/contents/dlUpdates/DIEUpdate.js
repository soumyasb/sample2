import React, { Component } from 'react';
import { Form, Input, Row, Select, Button, Col, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDIEInitialPage, saveDIEUpdate, getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    UCCode: '',
    MotorVoterCode: '',
    MailAddress: '',
    MailCity: '',
    MailState: '',
    MailZip: '',
    CountyCode: '',
    MailAddressDate: '',
    OtherAddress: '',
    OtherCity: '',
    OtherState: '',
    OtherAddressDate: '',
    ResidenceAddress: '',
    ResidenceCity: '',
    ResidenceState: '',
    DIEResponse: '',
    NextDLNumber: '',
    Error: true
};

class DIEUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            MotorVoterCode: false,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            ErrorObj: {},
            MailAddressDate: "",
            OtherAddressDate: "",
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
    }

    componentDidMount() {
       
        if (sessionStorage.getItem('dlInitData')) {
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDIEInitialPage(DLInitData.DLNumber);
        }
        else {
            this.props.history.push(`/dlUpdates`);
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DIEInitPageData !== this.props.dlUpdates.DIEInitPageData && this.props.dlUpdates.DIEInitPageData !== undefined) {
            const Obj = cloneDeep(defaultObj);
            Obj['ThreeCharacterName'] = this.props.dlUpdates.DIEInitPageData.ThreeCharacterName;
            this.setState({DIEInitPageData: this.props.dlUpdates.DIEInitPageData, Obj: Obj});
        }
        if (prevProps.dlUpdates.dieUpdateSaveData !== this.props.dlUpdates.dieUpdateSaveData && this.props.dlUpdates.dieUpdateSaveData !== undefined) {
            this.setState({ saveDIEUpdate: this.props.dlUpdates.dieUpdateSaveData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
            }
            else{
                let Errors = [];
                Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                    Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isLoading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { dieInitPageData, dieUpdateSaveData, dlUpdatesErrorData } = props.dlUpdates;
        if (dieInitPageData && dieInitPageData !== prevState.DIEInitPageData) {
            return { DIEInitPageData: dieInitPageData, isloading: false };
        }
        if (dieUpdateSaveData && dieUpdateSaveData !== prevState.saveDIEUpdate)
            return {
                saveDIEUpdate: dieUpdateSaveData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
            case 'MailAddress':
            case 'MailCity':
            case 'MailState':
            case 'OtherAddress':
            case 'OtherCity':
            case 'OtherState':
            case 'ResidenceAddress':
            case 'ResidenceCity':
            case 'ResidenceState':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
                case 'MailZip':
                case 'CountyCode':
                { const { value } = e.target;
            const reg = /^[0-9]*$/;
            if ((!isNaN(value) && reg.test(value))) {
              Obj[field] = e.target.value;
            }   }  
                break;
                case 'UCCode':
                case 'MotorVoterCode':
                if(!e)
                {
                    Obj[field] = '';
                }
                else
                {
                    Obj[field] = e;
                }
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    
    onDateChange(d, type) {
        switch(type) {
            case 'MailAddressDate':
            this.setState({ MailAddressDate: d });
            break;
            case 'OtherAddressDate':
            this.setState({  OtherAddressDate: d });
            break;
            default:
            break;
        }
    }

    handleUpdate(type) {
        
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }
        const { Obj } = this.state;
        Obj['LoginId'] = this.state.DIEInitPageData.LoginId;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['RequestorCode'] = this.state.DIEInitPageData.RequestorCode;
        Obj['Operator'] = this.state.DIEInitPageData.Operator;
        Obj['MailAddressDate'] = dateFormatFuncDLUpdates(this.state.MailAddressDate);
        Obj['OtherAddressDate'] = dateFormatFuncDLUpdates(this.state.OtherAddressDate);

        this.setState({ isloading: true, DLNumber: Obj['DLNumber'], isNewDL: isNewDL });
        this.props.saveDIEUpdate(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DIEInitPageData, saveDIEUpdate, isNewDL, isloading } = this.state;
        return (
            // <ScrollPanel
            //     style={{
            //         width: "100%",
            //         height: "100%",
            //         backgroundColor: "rgba(0,0,0,0)"
            //     }}
            // >
            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {saveDIEUpdate &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDIEUpdate.Error === false)
                                { 
                                    if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                else if (isNewDL !== true ) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDIEUpdate.DLNumber }
                                    })
                                }
                                else {
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                        DLNumber: '',
                                        ErrorObj: {},
                                        MailAddressDate: "",
                                        OtherAddressDate: "",
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                } 
                            }
                            }}>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDIEUpdate.DIEResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DIEInitPageData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >DL Address Change/Correction (DIE)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={6} style={{ display: 'block' }}>
                                            <FormItem
                                               hasFeedback
                                               validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                               help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={6} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input maxLength={3} value={Obj.ThreeCharacterName} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={6}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={6} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }
                        
                                <br />
                                <Row>
<Col span={6} style={{height : "50px"}}>
<FormItem
validateStatus = {Obj.UCCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UCCode"] ? 'error' : ""}
help = {Obj.UCCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["UCCode"]}
                                 label={<b>U/C <font color= 'red'>*</font></b>}
                             >
                             <Select allowClear = {true} id = "SUCCode" onFocus={(e) => {
                                document.getElementById("SUCCode").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'UCCode')}
                                       value={Obj.UCCode} showArrow={true} size={"small"} >
                                        {DIEInitPageData.UCCode.map(item =>
                                            <Option key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                        )}
                                    </Select>                                        
                               </FormItem>
</Col>
<Col span={6} style={{height : "50px"}} offset={1}>
<FormItem
validateStatus = {Obj.MotorVoterCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Moter Voter"] ? 'error' : ""}
help = {Obj.MotorVoterCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["Moter Voter"]}
                                 label={<b>Motor Voter (Y/N) <font color= 'red'>*</font></b>}
                             > 
                   {/* <Checkbox style={{marginLeft: '20%', marginTop: '5%'}} checked={this.state.MotorVoterCode}  onChange={e => this.handleFieldChange(e, 'MotorVoterCode')}>
                            </Checkbox>   */}
                            <Select allowClear = {true} id = "SMV" onFocus={(e) => {
                                document.getElementById("SMV").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  onChange={e => this.handleFieldChange(e, 'MotorVoterCode')}
                                       value={Obj.MotorVoterCode} showArrow={true} size={"small"} >
                                        {DIEInitPageData.MotorVoterCode.map(item =>
                                            <Option key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                        )}
                                    </Select>      </FormItem>
                   </Col>
</Row>
<Row>
<Col span={6} style={{height : "50px"}}>                        
                        <FormItem
                        validateStatus = {Obj.MailAddress === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailAddress"] ? 'error' : ""}
                        help = {Obj.MailAddress === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailAddress"]}
                           label={<b>Mail Address  </b>}
                       ><Input size={"small"} maxLength={35} placeholder="Mail Address"
                                        value={Obj.MailAddress} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'MailAddress')} />
                                </FormItem></Col>
    </Row>
<Row>                 <Col span={6} style={{height : "50px"}}>
                                <FormItem
                                  validateStatus = {Obj.MailCity === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailCity"] ? 'error' : ""}
                                  help = {Obj.MailCity === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailCity"]}
                                 label={<b>City </b>}
                             >
                                 <Input size={"small"} maxLength={13} placeholder="Mail City" value={Obj.MailCity} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'MailCity')} />
                               </FormItem>
                                </Col>
                                </Row><Row>
                                <Col span={3} style={{height : "50px"}}>
                                <FormItem
                                  validateStatus = {Obj.MailState === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailState"] ? 'error' : ""}
                                  help = {Obj.MailState === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailState"]}
                                 label={<b>State </b>}
                             >
                                 <Input size={"small"} maxLength={2} placeholder="State" value={Obj.MailState} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'MailState')} />
                               </FormItem>
                                </Col>
                                <Col span={3} style={{height : "50px"}} offset={1}>
                                <FormItem
                                 validateStatus = {Obj.MailZip === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailZip"] ? 'error' : ""}
                                 help = {Obj.MailZip === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailZip"]}
                                 label={<b>Zip <font color= 'red'>*</font></b>}
                             >
                                         <Input size={"small"} maxLength={5} placeholder="Zip" value={Obj.MailZip} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'MailZip')} />    
                               </FormItem>
                                </Col>
                                <Col style={{height : "50px"}} span={3} offset={1}>
                                <FormItem
                                 validateStatus = {Obj.CountyCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CountyCode"] ? 'error' : ""}
                                 help = {Obj.CountyCode === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["CountyCode"]}
                                 label={<b>Country Cd </b>}
                             >
                                         <Input size={"small"} maxLength={2} placeholder="County Code" value={Obj.CountyCode} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'CountyCode')} />    
                               </FormItem>
                                </Col>
                                <Col style={{height : "50px"}} span={6} offset={1}>
                                <FormItem
                                 validateStatus = {Obj.MailAddressDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailAddressDate"] ? 'error' : ""}
                                 help = {Obj.MailAddressDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["MailAddressDate"]}
                                 label={<b>Addr Date </b>}
                             >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.MailAddressDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'MailAddressDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                               </FormItem>
                                </Col>
                                </Row>
                                <Row>
<Col style={{height : "50px"}} span={6}>                        
                        <FormItem
                        validateStatus = {Obj.OtherAddress === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherAddress"] ? 'error' : ""}
                        help = {Obj.OtherAddress === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherAddress"]}
                           label={<b>Other Address  </b>}
                       ><Input size={"small"} maxLength={35} placeholder="Other Address"
                                        value={Obj.OtherAddress} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'OtherAddress')} />
                                </FormItem></Col>
    </Row>
<Row>                 <Col style={{height : "50px"}} span={6}>
                                <FormItem
                                  validateStatus = {Obj.OtherCity === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherCity"] ? 'error' : ""}
                                  help = {Obj.OtherCity === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherCity"]}
                                 label={<b>City </b>}
                             >
                                 <Input size={"small"} maxLength={13} placeholder="City" value={Obj.OtherCity} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'OtherCity')} />
                               </FormItem>
                                </Col>
                                </Row><Row>
                                <Col style={{height : "50px"}} span={3}>
                                <FormItem
                                  validateStatus = {Obj.OtherState === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherState"] ? 'error' : ""}
                                  help = {Obj.OtherState === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherState"]}
                                 label={<b>State </b>}
                             >
                                 <Input size={"small"} maxLength={2} placeholder="State" value={Obj.OtherState} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'OtherState')} />
                               </FormItem>
                                </Col>
                                <Col style={{height : "50px"}} span={6} offset={1}>
                                <FormItem
                                 validateStatus = {Obj.OtherAddressDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherAddressDate"] ? 'error' : ""}
                                 help = {Obj.OtherAddressDate === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["OtherAddressDate"]}
                                 label={<b>Addr Date </b>}
                             >
                                <DatePicker
                       className = "CalClass"
                       selected={this.state.OtherAddressDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OtherAddressDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                               </FormItem>
                                </Col>
                                </Row>
                                <Row>
<Col style={{height : "50px"}} span={6}>                        
                        <FormItem
                        validateStatus = {Obj.ResidenceAddress === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ResidenceAddress"] ? 'error' : ""}
                        help = {Obj.ResidenceAddress === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ResidenceAddress"]}
                           label={<b>Resid Address  </b>}
                       ><Input size={"small"} maxLength={35} placeholder="Other Address"
                                        value={Obj.ResidenceAddress} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'ResidenceAddress')} />
                                </FormItem></Col>
    </Row>
<Row>                 <Col style={{height : "50px"}} span={6}>
                                <FormItem
                                  validateStatus = {Obj.ResidenceCity === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ResidenceCity"] ? 'error' : ""}
                                  help = {Obj.ResidenceCity === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ResidenceCity"]}
                                 label={<b>City </b>}
                             >
                                 <Input size={"small"} maxLength={13} placeholder="City" value={Obj.ResidenceCity} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'ResidenceCity')} />
                               </FormItem>
                                </Col>
                                </Row><Row>
                                <Col style={{height : "50px"}} span={3}>
                                <FormItem
                                  validateStatus = {Obj.ResidenceState === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ResidenceState"] ? 'error' : ""}
                                  help = {Obj.ResidenceState === '' && this.state.ErrorObj !== {}  && this.state.ErrorObj["ResidenceState"]}
                                 label={<b>State </b>}
                             >
                                 <Input size={"small"} maxLength={2} placeholder="State" value={Obj.ResidenceState} style={{ width: '100%' }}
                                        onChange={e => this.handleFieldChange(e, 'ResidenceState')} />
                               </FormItem>
                                </Col>
                                </Row>
                                <Row>
                                    <Col style={{height : "50px"}} span={14}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input maxLength={3} style={{ width: '20%' }} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={10} style={{ float: 'right', height : "50px" }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                           
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                { if (isNewDL === true) {
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            ErrorObj: {},
                                            DLNumber: "",
                                            MailAddressDate: "",
                                            OtherAddressDate: "",
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                    else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                   else {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }              
                                }}>Ok</Button>
                            </div>
                        ]}
                    >
                         {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            {/* // </ScrollPanel > */}
</React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDIEInitialPage, saveDIEUpdate,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DIEUpdate); 