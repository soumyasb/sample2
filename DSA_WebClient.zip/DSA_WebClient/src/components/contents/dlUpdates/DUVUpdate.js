import React, { Component } from 'react';
import { Form, Input, Row, Button, Col, Select, Modal, Spin } from 'antd';
import { dateFormatFuncDLUpdates } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import {
    getDUVData, saveDUVData, getDLInitialData
} from "../../../store/actions/dlUpdatesActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import './me.css';

const FormItem = Form.Item;
const { Option } = Select;

const defaultObj = {
    LoginId: '',
    NetName: '',
    RequestorCode: '',
    Operator: '',
    DLNumber: '',
    ThreeCharacterLastName: '',
    HearingType: '',
    HearingDate: '',
    HearingLocation: '',
    HearingReason: '',
    OriginalDate: '',
    OriginalReason: '',
    DUVResponse: '',
    NextDLNumber: '',
    Error: true
};

class DUVUpdate extends Component {
    constructor(props) {
        super(props);

        this.state = {
            DLNumber: this.props.match.params.dlNumber,
            isNewDL: false,
            Obj: cloneDeep(defaultObj),
            HearingDate: "",
            OriginalDate: "",
            ErrorObj: {},
            ErrorMessage: '',
            ErrorModalShow: false
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleUpdate = this.handleUpdate.bind(this);
        this.handleModalClose = this.handleModalClose.bind(this);
    }

    componentDidMount() {
        if (sessionStorage.getItem('dlInitData')) {
            const DLInitData = JSON.parse(sessionStorage.getItem('dlInitData'));
            this.setState({
                DLNumber: DLInitData.DLNumber,
                ThreeCharacterName: DLInitData.ThreeCharacterName,
                BirthDate: DLInitData.Birthdate
            });
            this.props.getDUVData(DLInitData.DLNumber);
        }
        else {
            this.props.history.push(`/dlUpdates`);
        }
    }
    componentDidUpdate(prevProps) {

        if (prevProps.dlUpdates.DUVInitData !== this.props.dlUpdates.DUVInitData && this.props.dlUpdates.DUVInitData !== undefined) {
            const Obj = cloneDeep(defaultObj);
                                Obj['ThreeCharacterName'] = this.props.dlUpdates.DUVInitData.ThreeCharacterName;
                                this.setState({DUVInitData: this.props.dlUpdates.DUVInitData, Obj: Obj});
        }
        if (prevProps.dlUpdates.saveDUVData !== this.props.dlUpdates.saveDUVData && this.props.dlUpdates.saveDUVData !== undefined) {
            this.setState({ saveDUVData: this.props.dlUpdates.saveDUVData, openSuccessModal: true });
        }
        if (this.props.dlUpdates.dlUpdatesErrorData && prevProps.dlUpdates.dlUpdatesErrorData !== this.props.dlUpdates.dlUpdatesErrorData) {
            if(typeof this.props.dlUpdates.dlUpdatesErrorData === 'string')
                                {
                                    this.setState({ ErrorMessage:  this.props.dlUpdates.dlUpdatesErrorData, ErrorModalShow: true });
                                }
                                else{
                                    let Errors = [];
                                    Object.keys(this.props.dlUpdates.dlUpdatesErrorData).map((keyName, keyIndex) => {
                                        Errors.push(this.props.dlUpdates.dlUpdatesErrorData[keyName][0]);
                                        return "";
                                    })
                                    this.setState({ ErrorObj: this.props.dlUpdates.dlUpdatesErrorData, ErrorMessage: Errors, ErrorModalShow: true });
                                }
        }
        if ( prevProps.dlUpdates.modified !== this.props.dlUpdates.modified && this.props.dlUpdates.dlInitData !== undefined )
        {
            
         sessionStorage.setItem('dlInitData', JSON.stringify(this.props.dlUpdates.dlInitData)); 
            const Obj = cloneDeep(defaultObj);
           Obj['ThreeCharacterName'] = this.props.dlUpdates.dlInitData.ThreeCharacterName;
            this.setState({ Obj: Obj, DLNumber: this.props.dlUpdates.dlInitData.DLNumber, ThreeCharacterName: this.props.dlUpdates.dlInitData.ThreeCharacterName, isLoading: false });
        } 
    }

    static getDerivedStateFromProps(props, prevState) {

        const { DUVInitData, saveDUVData, dlUpdatesErrorData} = props.dlUpdates;
        if (DUVInitData && DUVInitData !== prevState.DUVInitData) {
            return { DUVInitData: DUVInitData, isloading: false };
        }
        if (saveDUVData && saveDUVData !== prevState.saveDUVData)
            return {
                saveDUVData: saveDUVData,
                isloading: false
            };
        if (dlUpdatesErrorData && dlUpdatesErrorData !== prevState.dlUpdatesErrorData)
            return {
                dlUpdatesErrorData,
                isloading: false
            };
        return null;
    }

    handleFieldChange(e, field) {
        const { Obj } = this.state;
        switch (field) {
            case 'ThreeCharacterName':
            case 'NextDLNumber':
                Obj[field] = e.target.value;
            break;
            case 'DLNumber':
            this.setState({DLNumber: e.target.value});
            Obj[field] = e.target.value;
                if ((Obj['DLNumber'].length === 8)) {
                      this.props.getDLInitialData(Obj['DLNumber']);
                      this.props.getDUEData(Obj['DLNumber'], Obj['ThreeCharacterName'] );
                }
                break;
            case 'HearingType':
            case 'HearingLocation':
            case 'HearingReason':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e;
                }
                break;
            case 'OriginalReason':
            if(!e)
            {
                Obj[field] = '';
            }
                else
                {
                    Obj[field] = e !== '-0-' ? e : '';
                } 
                break;
            default:
                break;
        }

        this.setState({ Obj });
    }

    onDateChange(d,type) {
        switch (type) {
            case 'HearingDate':
                this.setState({ HearingDate: d });
                break;
            case 'OriginalDate':
                this.setState({ OriginalDate: d });
                break;
            default:
                break;
        }
    }

    handleModalClose() {
        this.setState({ ErrorModalShow: false, ErrorMessage: '' });
    }

    handleUpdate(type) {
        let isNewDL = false;
        if(type === 'new')
        {
  isNewDL = true;
              sessionStorage.removeItem('dlInitData');   
            }
            else
            {
    isNewDL = false;
            }

        const { Obj } = this.state;

        Obj['LoginId'] = this.state.DUVInitData.LoginId;
        Obj['RequestorCode'] = this.state.DUVInitData.RequestorCode;
        Obj['Operator'] = this.state.DUVInitData.Operator;
        Obj['NetName'] = this.state.DUVInitData.NetName;
        Obj['DLNumber'] = this.state.DLNumber;
        Obj['ThreeCharacterLastName'] = this.state.ThreeCharacterName;
        Obj['HearingDate'] = dateFormatFuncDLUpdates(this.state.HearingDate);
        Obj['OriginalDate'] = dateFormatFuncDLUpdates(this.state.OriginalDate);

        this.setState({ isloading: true, dlNumber: Obj['DLNumber'], isNewDL: isNewDL });
         this.props.saveDUVData(Obj);
    }

    render() {
        const { Obj } = this.state;
        const { DUVInitData, saveDUVData, isNewDL, isloading } = this.state;

        return (
            <React-Fragment>
                {isloading !== true ? <div style={{ backgroundColor: "white", width: "95%", marginLeft: '2%' }}>
                    {saveDUVData &&
                        <Modal maskClosable={false} title={"Update Status"} visible={this.state.openSuccessModal} onCancel={(e) => this.setState({ openSuccessModal: false })}
                            footer={[<Button type="primary" key="Ok" onClick={(e) => {
                                this.setState({ openSuccessModal: false });
                                if(saveDUVData.Error === false)
               {  if (Obj.NextDLNumber !== '') {
                this.props.history.push({
                    pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                    state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName }
                });
            } else if (isNewDL !== true) {
                                    this.props.history.push({
                                        pathname: `/dlUpdates`,
                                        state: { dlNumber: saveDUVData.DLNumber }
                                    })
                                }
                               else {
                                    this.setState({
                                        Obj: cloneDeep(defaultObj),
                                        HearingDate: "",
                                        OriginalDate: "",
                                        DLNumber: "",
                                        ErrorObj: {},
                                        ErrorMessage: '',
                                        ErrorModalShow: false
                                    });
                                }
                          }}
                        }>OK</Button>]}
                        >
                            <div>
                                <div dangerouslySetInnerHTML={{ __html: saveDUVData.DUVResponse.toString() }} />
                            </div>
                        </Modal>}
                    {DUVInitData ?
                          <div><div style={{
                border: '1px solid black',
                paddingLeft: "1%",
                textAlign: 'center',
                backgroundColor: '#c9e3fa',
                fontSize: '32px'
                }} >Schedule Hearing (DUV)</div>
                            <Form className="ant-advanced-search-form">
                                {isNewDL ?
                                    <Row>
                                        <Col span={8} style={{ display: 'block' }}>
                                            <FormItem
                                              hasFeedback
                                              validateStatus={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "validating" : null}
                                              help={Obj.ThreeCharacterName === '' && this.state.DLNumber.length === 8 ? "Getting DL Information" : null}
                                                label={<b>DL # </b>}
                                            >
                                                <Input value={this.state.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name </b>}
                                            >
                                                <Input value={Obj.ThreeCharacterName} maxLength = {3} placeholder="3 Pos Last Name" onChange={e => this.handleFieldChange(e, 'ThreeCharacterName')} />
                                            </FormItem>
                                        </Col>
                                    </Row> :
                                    <Row>
                                        <Col span={8}>
                                            <FormItem
                                                label={<b>DL #</b>}
                                            >
                                                {this.state.DLNumber}
                                            </FormItem>
                                        </Col>
                                        <Col span={8} offset={1}>
                                            <FormItem
                                                label={<b>3 Pos Last Name</b>}
                                            >
                                                {this.state.ThreeCharacterName}
                                            </FormItem>
                                        </Col>
                                    </Row>
                                }

                                <Row>
                                    <Col span={17}>
                                        <div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px' }}>
                                            <Row>
                                                <Col>
                                                    <h3>Hearing Information</h3>
                                                    <hr />
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingType === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingType"] ? 'error' : ""}
                                                        help={Obj.HearingType === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingType"]}
                                                        label={<b> Type </b>}
                                                    >
                                                        <Select allowClear = {true} id = "SelTyp" onFocus={(e) => {
                                document.getElementById("SelTyp").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'HearingType')}
                                                            value={Obj.HearingType} showArrow={true} size={"default"}
                                                        >
                                                            {DUVInitData.HearingType.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>
                                                    <FormItem
                                                        validateStatus={this.state.HearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingDate"] ? 'error' : ""}
                                                        help={this.state.HearingDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingDate"]}
                                                        label={<b> Date </b>}
                                                    >
                                                            <DatePicker
                       className = "CalClass"
                       selected={this.state.HearingDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'HearingDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col span={11}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingLocation"] ? 'error' : ""}
                                                        help={Obj.HearingLocation === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingLocation"]}
                                                        label={<b> Location </b>}
                                                    >
                                                        <Select allowClear = {true} id = "SLoc" onFocus={(e) => {
                                document.getElementById("SLoc").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'HearingLocation')}
                                                            value={Obj.HearingLocation} showArrow={true} size={"default"}
                                                        >
                                                            {DUVInitData.HearingLocations.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                                <Col span={11} offset={1}>
                                                    <FormItem
                                                        validateStatus={Obj.HearingReason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingReason"] ? 'error' : ""}
                                                        help={Obj.HearingReason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["HearingReason"]}
                                                        label={<b> Reason </b>}
                                                    >
                                                        <Select allowClear = {true} id = "SReas" onFocus={(e) => {
                                document.getElementById("SReas").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'HearingReason')}
                                                            value={Obj.HearingReason} showArrow={true} size={"default"}
                                                        >
                                                            {DUVInitData.HearingReasons.map((item) => {
                                                                return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                            })}
                                                        </Select>
                                                    </FormItem>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col span={8}>
                                        <FormItem
                                            validateStatus={this.state.OriginalDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalDate"] ? 'error' : ""}
                                            help={this.state.OriginalDate === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalDate"]}
                                            label={<b> Original Date </b>}
                                        >
                                                <DatePicker
                       className = "CalClass"
                       selected={this.state.OriginalDate}
                       dateFormat={"MM-dd-yyyy"}
                       onChange={(d) => this.onDateChange(d, 'OriginalDate')}
                       isClearable={true}
                       placeholderText="Select a date"
                     />
                                        </FormItem>
                                    </Col>
                                    <Col span={8} offset={1}>
                                        <FormItem
                                            validateStatus={Obj.OriginalReason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalReason"] ? 'error' : ""}
                                            help={Obj.OriginalReason === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["OriginalReason"]}
                                            label={<b> Original Reason </b>}
                                        >
                                            <Select allowClear = {true} id = "SOR" onFocus={(e) => {
                                document.getElementById("SOR").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'OriginalReason')}
                                                value={Obj.OriginalReason} showArrow={true} size={"default"}
                                            >
                                                {DUVInitData.OriginalHearingReason ? DUVInitData.OriginalHearingReason.map((item) => {
                                                    return <Option title={`${item.Value} - ${item.Text}`} key={item.Value} value={item.Value}>{item.Value} - {item.Text}</Option>
                                                }) : <Option title={``} key={0} value={'-0-'}>No Reasons available</Option>}
                                            </Select>
                                        </FormItem>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col span={18}>
                                        <FormItem
                                            validateStatus={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"] ? 'error' : ""}
                                            help={Obj.NextDLNumber === '' && this.state.ErrorObj !== {} && this.state.ErrorObj["NextDLNumber"]}
                                            label={<b>Next Trans </b>}
                                        >
                                            <Input style={{ width: '20%' }} maxLength = {3} value={Obj.NextDLNumber} placeholder="Next Transaction" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} />
                                        </FormItem>
                                    </Col>
                                    <Col span={6} style={{ float: 'right' }}>
                                        {Obj.NextDLNumber !== '' ?
                                            <Button disabled type="default">New DL</Button> :
                                            <Button style={{ color: "white", backgroundColor: "green" }}
                                                type="default" key="New DL" onClick={(e) => this.handleUpdate('new')}>New DL</Button>} {' '}
                                        <Button type="primary" key="Update" onClick={(e) => this.handleUpdate('update')}>Update</Button> {' '}
                                        <Button style={{ color: "white", backgroundColor: "red" }}
                                            type="default" key="Cancel" onClick={(e) => {
                                                
                                                this.props.history.push({
                                                    pathname: `/dlUpdates`,
                                                    state: { dlNumber: this.state.DLNumber }
                                                })
                                            }
                                            }>Cancel</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </div> :
                        <div>
                            <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                            <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                        </div>}
                    <Modal visible={this.state.ErrorModalShow}
                        title={'Error message'} maskClosable={false}
                        footer={[
                            <div>
                                <Button type="primary" key="Ok" onClick={(e) => {
                                    this.setState({ ErrorModalShow: false });
                                    if( !this.state.ErrorObj )
                                    { if (isNewDL === true) {
                                        this.setState({
                                            Obj: cloneDeep(defaultObj),
                                            DLNumber: "",
                                            HearingDate: "",
                                            OriginalDate: "",
                                            ErrorObj: {},
                                            ErrorMessage: '',
                                            ErrorModalShow: false
                                        });
                                    }
                                    else if (Obj.NextDLNumber !== '') {
                                        this.props.history.push({
                                            pathname: `/${Obj.NextDLNumber.toLowerCase()}Update/DLNumber/${this.state.DLNumber}`,
                                            state: { DLNumber: this.state.DLNumber, ThreeCharacterName: this.state.ThreeCharacterName, BirthDate: this.state.BirthDate }
                                        });
                                    }
                                   else {
                                        this.props.history.push({ pathname: `/dlUpdates`,
                                        state: {dlNumber: this.state.DLNumber}});
                                    }
                                }               
                                }}>Ok</Button>
                            </div>
                        ]}
                    >
                         {this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
                            <ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
                            : this.state.ErrorMessage.includes(" RandomMathNumber") ? <div><font color= 'red'>{this.state.ErrorMessage.split(" RandomMathNumber")[0]}</font></div>: <div><font color= 'red'>{this.state.ErrorMessage}</font>
                            </div>}
                    </Modal>
                </div> :
                    <div>
                        <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span>
                        <span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span>
                    </div>}
            </React-Fragment>
            );
    }
}

const mapStateToProps = state => {
    return {
        dlUpdates: state.dlUpdates
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getDUVData, saveDUVData,
            getDLInitialData
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(DUVUpdate); 