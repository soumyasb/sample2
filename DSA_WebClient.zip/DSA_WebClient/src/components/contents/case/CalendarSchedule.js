import React from "react";
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction"; 
import moment from "moment";
import "./styles.css";
import "@fullcalendar/core/main.css";
import "@fullcalendar/timegrid/main.css";

export default class DemoApp extends React.Component {
  calendarComponentRef = React.createRef();
 
   state = {
  }
 
  render() {
    
    return (
      <div className="demo-app">
        <div className="demo-app-calendar">
          <FullCalendar
            defaultView="timeGridDay"
            customButtons= {{
              Today: {
                text: "Go to Today's Date",
                click: (e) => this.handleDateButtonClick('today')
              },
              Next: {
                text: 'Next Date',
                click: (e) =>
                  this.handleDateButtonClick('next')
              },
              Prev: {
                text: 'Previous Date',
                click: (e) =>
                  this.handleDateButtonClick('prev')
                
              }
            }
            }
            
            header={{
              left: "Prev, Next",
              center: "title",
              right: "Today"
            }}
           plugins={[ timeGridPlugin, interactionPlugin]}
           ref={this.calendarComponentRef}
            events={this.props.calendarEvents}
            height={650}
            titleFormat={{ year: 'numeric', month: 'long', day: 'numeric' }}
            defaultDate={this.props.Date}
            minTime={"07:00:00"}
            maxTime={"18:00:00"}
            timeGridEventMinHeight={20}
           slotDuration={"00:30:00"}
           scrollTime={"08:00:00"}
           eventColor= {"Green"}        
           selectMirror={true}   
           selectable={true}
           select={
            this.selectDate}
          />
        </div>
      </div>
    );
  }

  selectDate = info => 
  {
    if(this.props.selectedHO === undefined)
    {
      this.props.validateHO();
    }
    else
    {
      var mins = moment.duration(moment(info.end).diff(moment(info.start))).asMinutes();
      if(mins < 60)
      {
        info.end = moment(info.start).add(1,"hours")._d;
      }
    this.props.fromCalendar(info);
    }
  }

  handleDateButtonClick = arg => {
    if(this.props.selectedHO === undefined)
    {
      this.props.validateHO();
    }
    else
    {
      
      let calendarApi = this.calendarComponentRef.current.getApi();
      calendarApi[arg]();
      this.props.getDate(calendarApi.getDate());
    }
  };
}