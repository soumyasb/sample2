import React from 'react';
import moment from "moment";

class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
           coversheetJson: this.props.coversheetJson,
           caseNumber: this.props.caseNumber
        }
    }

    componentDidUpdate(prevProps) {
    
        if ( prevProps.coversheetJson !== this.props.coversheetJson ) {

            this.setState({coversheetJson: this.props.coversheetJson});           
    }
    }
    render() {
      if(this.state.coversheetJson !== undefined)
      {
        const { DLNumber, BirthDate, LastName, PhoneNumber, OIPPersons, OIPAgencies, Contacts, Comments } = this.state.coversheetJson;
 
        const caseNumber = this.state.caseNumber;

        let personsList = [], agenciesList = [], contactsList = [], commentsList = [];
        
        OIPPersons.results !== undefined && OIPPersons.results.length > 0 && OIPPersons.results.map((person, index) =>
        personsList.push(<tr>
                <td>{`${person.OIP_CD_PRTY_TYP || ''}`}</td>
                <td>{`${person.OIP_NME_FRST_PRSN || ''} ${person.OIP_NME_SURNME_PRSN || ''}`}</td>
                <td>{`${person.OIP_NBR_PHONE || ''}`}</td>
                <td>{`${person.OIP_ADDR_LN1 || ''} ${person.OIP_CITY || ''} ${person.OIP_STATE || ''} ${person.OIP_ZIP || ''}`}</td>
              </tr>
            ));

        OIPAgencies.results !== undefined && OIPAgencies.results.length > 0 && OIPAgencies.results.map((agency, index) =>
        agenciesList.push(<tr>
                <td>{`${agency.AGENCY_CD_PRTY_TYP || ''}`}</td>
                <td>{`${agency.AGENCY_NME_FRST_PRSN || ''} ${agency.AGENCY_NME_SURNME_PRSN || ''}`}</td>
                <td>{`${agency.AGENCY_NBR_PHONE || ''}`}</td>
                <td>{`${agency.AGENCY_ADDR_LN1 || ''} ${agency.AGENCY_CITY || ''} ${agency.AGENCY_STATE || ''} ${agency.AGENCY_ZIP || ''}`}</td>
              </tr>
            ));

        Contacts.results !== undefined && Contacts.results.length > 0 && Contacts.results.map((contact, index) =>
        contactsList.push(<tr>
                <td>{`${contact.CD_OFF_ABBR || ''}`}</td>
                <td>{`${contact.CD_RSN || ''}`}</td>
                <td>{`${contact.CD_HRNG_TYP || ''}`}</td>
                <td>{`${contact.NBR_ROOM || ''}`}</td>
                <td>{`${moment(contact.dt_cntct_strt_tim).format("MM-DD-YYYY hh:mm A") || ''}`}</td> {/* NOU - 08/20/2019*/}
                <td>{`${contact.CD_REFR_SRCE_TYP || ''}`}</td>
                <td>{`${contact.CD_AUTH_ID || ''}`}</td>
              </tr>
            ));

        Comments.results !== undefined && Comments.results.length > 0 && Comments.results.map((comment, index) =>
        commentsList.push(<tr>
                <td>{`${comment.TXT_COMMENT || ''}`}</td>
                <td>{`${comment.CD_UPDT_TECH_ID || ''}`}</td>
                <td>{`${comment.CD_FLD_DSO_ALPHA || ''}`}</td>
                <td>{`${moment(comment.DT_UPDT_TRANS).format("MM-DD-YYYY") || ''}`}</td>
              </tr>
            ));

        return (
            <div style={{width: '100%'}}>{this.state.coversheetJson !== undefined ?
      
            <div style={{display: 'table', width: "100%", tableLayout: 'fixed', height: "auto"}}>
                        <div style={{ float: 'right' }}>
                            <img alt="" src="../../../CASECVRSHT.jpg" height={50} width={450} />
                        </div>
                <br />
                <br />
                <br />
                        <div style={{ textAlign: 'center', fontSize: 'x-large' }}>
                            <strong>DO NOT REMOVE THIS SHEET FROM THE FILE!!!!!!</strong>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                       <strong>{`CASE #: ${caseNumber}`}</strong>
                        </div>
                <br />
                <div style={{width: "100%"}}>
                    <span style={{marginRight: "10%"}}><b>DL #:</b> {`${DLNumber}`}</span>
                    <span style={{marginRight: "10%"}}><b>D.O.B:</b> {`${moment(BirthDate).format("MM-DD-YYYY")}`}</span>
                    <span style={{marginRight: "10%"}}><b>LAST NAME:</b> {`${LastName}`}</span>
                    <span><b>PHONE #: </b>{`${PhoneNumber}`}</span>
                </div>
                <hr />
                {OIPPersons && OIPPersons.results && OIPPersons.results.length > 0 && <div style={{pageBreakInside: "auto"}}>
                    <br />
                    <div>
                        <span><b>PERSONS:</b></span>
                    </div>
                    <table style={{width:"100%"}}>
        <thead style={{display: "table-header-group"}}>
          <th>Priority Type</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Address</th>
        </thead>
        <tbody>
      {personsList}
        </tbody>
      </table>
                </div>}

                {OIPAgencies && OIPAgencies.results && OIPAgencies.results.length > 0 && <div  style={{pageBreakInside: "auto"}}>
                    <br />
                    <div>
                        <span><b>AGENCIES:</b></span>
                    </div>
                    <table style={{width:"100%"}}>
        <thead style={{display: "table-header-group"}}>
          <th>Priority Type</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Address</th>
        </thead>
        <tbody>
      {agenciesList}
        </tbody>
      </table>
                </div>}
                {Contacts && Contacts.results && Contacts.results.length > 0 && <div  style={{pageBreakInside: "auto"}}>
                    <br />
                    <div>
                        <span><b>CONTACTS:</b></span>
                    </div>
                    <table style={{width:"100%"}}>
        <thead style={{display: "table-header-group"}}>
          <th>Officer</th>
          <th>Reason</th>
          <th>Hearing</th>
          <th>Room</th>
          <th>Start Date</th>
          <th>Reference</th>
          <th>Auth Id</th>
        </thead>
        <tbody>
      {contactsList}
        </tbody>
      </table>
                </div>}
                {Comments && Comments.results && Comments.results.length > 0 && <div  style={{pageBreakInside: "auto"}}>
                    <br />
                    <div>
                        <span><b>COMMENTS:</b></span>
                    </div>
                    <table style={{width:"100%"}}>
        <thead style={{display: "table-header-group"}}>
          <th>Comment</th>
          <th>Author</th>
          <th>Office</th>
          <th>Date</th>
        </thead>
        <tbody>
      {commentsList}
        </tbody>
      </table>
                </div>}
            </div > : <div></div>} </div>
        );      } 
        else
        return <div></div>
    }
}

export default ComponentToPrint;