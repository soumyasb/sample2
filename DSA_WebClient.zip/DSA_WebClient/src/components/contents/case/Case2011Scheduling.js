import React, { Component } from 'react';
import { Input, Button, Select, Row, Col, Form, Checkbox, Spin } from 'antd'; 
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { dateFormatFunc } from './../commonFuncs.js';
import '../../../dp.css';

const FormItem = Form.Item;
const { Option } = Select;

 

class Case2011Scheduling extends Component {
    constructor(props) {
        super(props);
        this.state={
         }
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
    }

    handleFieldChange(e, field) {
      const { _2011SchedulingInitData } = this.props;
      switch (field) {
          case 'MedicalReceived':
                  _2011SchedulingInitData[field] = e.target.checked ? "1":"0";
                  break;
          case 'Comment':
          case 'NextDLNumber':
                  _2011SchedulingInitData[field] = e.target.value;
                  break;
          case 'CaseReason':
          case 'Referral':
          case 'HearingType':
                 _2011SchedulingInitData[field] = e;
                 break;
          default:
                 break;
      }

      this.setState({ _2011SchedulingInitData });
  }

  onDateChange(d, type) {
      const { _2011SchedulingInitData } = this.props;
      _2011SchedulingInitData[type] = dateFormatFunc(d);
      switch(type) {
          case 'MailDate':
          this.setState({ _2011SchedulingInitData: _2011SchedulingInitData, MailDate: d });
          break;
          case 'ModifiedHearingDate':
          this.setState({ _2011SchedulingInitData: _2011SchedulingInitData, ModifiedHearingDate: d });
          break;
          default:
          break;
      }
  }

    render() {
        const _2011SchedulingInitData = this.props._2011SchedulingInitData;
        return (
        <React-Fragment>
         {_2011SchedulingInitData ?   
             <React.Fragment>
                <Form style={{width:'99%'}} className="ant-advanced-search-form">
                <Row gutter={24} type="flex">
    <Col style={{width: '250px'}}>
        <FormItem
               
            label={<b>DL Number </b>}
        >
            <Input disabled value={_2011SchedulingInitData.DLNumber} placeholder="DL Number" onChange={e => this.handleFieldChange(e, 'DLNumber')} />
        </FormItem>
    </Col><Col style={{width: '250px'}}> <FormItem
           
            label={<b>Case Number </b>}>
            <Input disabled value={_2011SchedulingInitData.CaseNumber} placeholder="Case Number" onChange={e => this.handleFieldChange(e, 'CaseNumber')} />
            </FormItem>
                               </Col></Row><Row gutter={24} type="flex"><Col style={{width: '400px'}}>
                               <FormItem
                                      
            label={<b>Driver Name </b>}>
                                    <Input disabled value={_2011SchedulingInitData.DriverName} placeholder="Driver Name" onChange={e => this.handleFieldChange(e, 'DriverName')} />
                                    </FormItem>  </Col>
                                    <Col style={{width: '250px'}}>
                               <FormItem
                                      
            label={<b>Class</b>}>
                                  <Input disabled value={_2011SchedulingInitData.LicenseClass} placeholder="Class" onChange={e => this.handleFieldChange(e, 'Class')} />
                                    </FormItem> 
                               </Col>
                               <Col style={{width: '250px'}}>
                               <FormItem
                                      
            label={<b>DOB </b>}>
                                    <Input disabled value={_2011SchedulingInitData.BirthDate} placeholder="Birth Date" onChange={e => this.handleFieldChange(e, 'BirthDate')} />
                                    </FormItem>  </Col>
                           </Row>
                          <Row gutter={24} type="flex">   <Col style={{width: '250px'}}><div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px', textAlign: 'center' }}>
                        <Checkbox checked={_2011SchedulingInitData.MedicalReceived === "1" ? true: false }
                            onChange={e => this.handleFieldChange(e, 'MedicalReceived')}
                           >
                            Medical Received
                        </Checkbox>
                    </div></Col>
                    <Col style={{width: "75%"}}><Row gutter={24} type="flex"><Col style={{width: '400px'}}>
        <FormItem
        
            label={<b>Address </b>}
        >
            <Input maxLength={35} disabled value={_2011SchedulingInitData.Address} placeholder="Address" onChange={e => this.handleFieldChange(e, 'Address')} />
        </FormItem>
    </Col><Col style={{width: '250px'}}> <FormItem
        
            label={<b>City </b>}
        >
            <Input maxLength={13} disabled value={_2011SchedulingInitData.City} placeholder="City" onChange={e => this.handleFieldChange(e, 'City')} />
        </FormItem></Col></Row> 
        <Row gutter={24} type="flex"  style={{marginLeft: '20px'}}><Col style={{width: '250px'}}><FormItem
        
            label={<b>State </b>}
        >
            <Input maxLength={2} disabled value={_2011SchedulingInitData.State} placeholder="State" onChange={e => this.handleFieldChange(e, 'State')} />
        </FormItem></Col>
        <Col style={{width: '250px'}}><FormItem
        
            label={<b>Zip </b>}
        >
            <Input maxLength={5} disabled value={_2011SchedulingInitData.Zip} placeholder="Zip" onChange={e => this.handleFieldChange(e, 'Zip')} />
        </FormItem></Col>
        <Col style={{width: '350px'}}><FormItem
        
            label={<b>Phone Number </b>}
        >
            <Input value={_2011SchedulingInitData.PhoneNumber} disabled placeholder="PhoneNumber" onChange={e => this.handleFieldChange(e, 'PhoneNumber')} />
        </FormItem></Col>
        </Row></Col>
        </Row>
        <Row gutter={24} type="flex">
    <Col style={{width: '250px'}}>
        <FormItem
        
            label={<b>Mail Date </b>}
        >
            <DatePicker
                           className = "CalClass"
                           selected={_2011SchedulingInitData.MailDate ? new Date(_2011SchedulingInitData.MailDate.replace("-", "/")) : _2011SchedulingInitData.MailDate}
                           dateFormat={"MM-dd-yyyy"}
                           onChange={(d) => this.onDateChange(d, 'MailDate')}
                           isClearable={true}
                           placeholderText="Mail Date"
                         />
        </FormItem>
    </Col><Col style={{width: '250px'}}> <FormItem
        
            label={<b>Requested By </b>}>
            <Input value={_2011SchedulingInitData.TechId} disabled placeholder="Requested By" onChange={e => this.handleFieldChange(e, 'RequestedBy')} />
            </FormItem>
                               </Col><Col style={{width: '500px'}}>
                               <FormItem
       
          hasFeedback
           validateStatus={_2011SchedulingInitData.CaseReason === undefined && this.props.ErrorObj !== {}  && this.props.ErrorObj.CaseReason ? 'error' : ""}
           help={_2011SchedulingInitData.CaseReason === undefined && this.props.ErrorObj !== {}  && this.props.ErrorObj.CaseReason && this.props.ErrorObj.CaseReason[0]}
            label={<b>Reason </b>}>
                                     <Select id = "REAC" onFocus={(e) => {
                                document.getElementById("REAC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleFieldChange(e, 'CaseReason')} value={_2011SchedulingInitData.CaseReason} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                     {_2011SchedulingInitData.Reasons.map(rea => <Option key={rea.Value} value={rea.Value}>{rea.Value} - {rea.Text}</Option>)}
                              </Select>
                                    </FormItem>  </Col>
                                    <Col style={{width: '500px'}}>
                               <FormItem
          
          hasFeedback
          validateStatus={_2011SchedulingInitData.Referral === undefined && this.props.ErrorObj !== {}  && this.props.ErrorObj.Referral ? 'error' : ""}
          help={_2011SchedulingInitData.Referral === undefined && this.props.ErrorObj !== {}  && this.props.ErrorObj.Referral && this.props.ErrorObj.Referral[0]}
            label={<b>Referral </b>}>
                                    <Select id = "REFC" onFocus={(e) => {
                                document.getElementById("REFC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleFieldChange(e, 'Referral')} value={_2011SchedulingInitData.Referral} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                    {_2011SchedulingInitData.Referrals.map(ref => <Option key={ref.Value} value={ref.Value}>{ref.Text}</Option>)}
                              </Select>
                                    </FormItem> 
                               </Col></Row>
                               <Row gutter={24} type="flex">
    <Col style={{width: '300px'}}>
        <FormItem
            label={<b>Modified Date </b>}
        >
            <DatePicker
                           className = "CalClass"
                           selected={_2011SchedulingInitData.ModifiedHearingDate ? new Date(_2011SchedulingInitData.ModifiedHearingDate.replace('-', '/')) : _2011SchedulingInitData.ModifiedHearingDate}
                           dateFormat={"MM-dd-yyyy"}
                           onChange={(d) => this.onDateChange(d, 'ModifiedHearingDate')}
                           isClearable={true}
                           placeholderText="Modified Date"
                         />
        </FormItem>
    </Col><Col style={{width: '500px'}}> <FormItem
          
            label={<b>Hearing Type </b>}>
                <Select id = "HTC" onFocus={(e) => {
                                document.getElementById("HTC").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleFieldChange(e, 'HearingType')} value={_2011SchedulingInitData.HearingType} showArrow={true} size={"default"} style={{ width: '100%'}}>
                {_2011SchedulingInitData.HearingTypes.map(ht => <Option key={ht.Value} value={ht.Value}>{ht.Text}</Option>)}
                              </Select>
            </FormItem>
                               </Col></Row>
        <Row><Col> <FormItem
         validateStatus={_2011SchedulingInitData.Comment === "" && this.props.ErrorObj !== {}  && this.props.ErrorObj.Comment ? 'error' : ""}
         help={_2011SchedulingInitData.Comment === "" && this.props.ErrorObj !== {}  && this.props.ErrorObj.Comment && this.props.ErrorObj.Comment[0]}
            label={<b>DS Comment </b>}>
            <Input value={_2011SchedulingInitData.Comment} disabled={!_2011SchedulingInitData.EnableComment} placeholder="Enter Comment" onChange={e => this.handleFieldChange(e, 'Comment')} />
            </FormItem>
                               </Col></Row>
        <Row type="flex">
        <Col span={10}><div style={{ border: '0.5px dotted grey', borderRadius: '5px', padding: '10px', textAlign: 'center' }}>
       <Row gutter={8} type="flex"> <Col style={{width: '150px'}}>Go to New DL after updating:</Col><Col style={{width: '250px'}}><Input value={_2011SchedulingInitData.NextDLNumber} maxLength = {8} placeholder="Enter New DL#" onChange={e => this.handleFieldChange(e, 'NextDLNumber')} /></Col><Button disabled={_2011SchedulingInitData.NextDLNumber && _2011SchedulingInitData.NextDLNumber.length === 8 ? false: true} style={{ color: "white", backgroundColor: "green" }}
                            type="default" key="New DL" onClick={(e) => {
                                if(_2011SchedulingInitData['CaseReason'] !== this.props.ref2011SchedData['CaseReason'])
                                {
                                  _2011SchedulingInitData['NewCaseReason'] = _2011SchedulingInitData['CaseReason'] ;
                                if(_2011SchedulingInitData.CaseNumber !== "NewDsrCase") {  _2011SchedulingInitData['CaseReason'] = this.props.ref2011SchedData['CaseReason'];}
                                }
                                else
                                {
                                    _2011SchedulingInitData['NewCaseReason'] = _2011SchedulingInitData['CaseReason'];
                                }
                                if(_2011SchedulingInitData['HearingType'] !== this.props.ref2011SchedData['HearingType'])
                                {
                                  _2011SchedulingInitData['NewHearingType'] = _2011SchedulingInitData['HearingType'] ;
                                  _2011SchedulingInitData['HearingType'] = this.props.ref2011SchedData['HearingType']
                                }
                                else
                                {
                                    _2011SchedulingInitData['NewHearingType'] = _2011SchedulingInitData['HearingType'] ;
                                }
                                this.props.processCaseReExam(_2011SchedulingInitData)}}>New DL</Button>
                    </Row>    </div></Col>           
                        <Col span={4} style={{marginLeft: "40%"}}>
                            <Button type="primary" key="Update" disabled={_2011SchedulingInitData.NextDLNumber ? true: false} onClick={(e) => {
                                if(_2011SchedulingInitData['CaseReason'] !== this.props.ref2011SchedData['CaseReason'])
                                {
                                  _2011SchedulingInitData['NewCaseReason'] = _2011SchedulingInitData['CaseReason'] ;
                                  if(_2011SchedulingInitData.CaseNumber !== "NewDsrCase") {     _2011SchedulingInitData['CaseReason'] = this.props.ref2011SchedData['CaseReason'];}
                                }
                                else
                                {
                                  _2011SchedulingInitData['NewCaseReason'] = _2011SchedulingInitData['CaseReason'];
                                }
                                if(_2011SchedulingInitData['HearingType'] !== this.props.ref2011SchedData['HearingType'])
                                {
                                  _2011SchedulingInitData['NewHearingType'] = _2011SchedulingInitData['HearingType'] ;
                                  _2011SchedulingInitData['HearingType'] = this.props.ref2011SchedData['HearingType']
                                }
                                else
                                {
                                    _2011SchedulingInitData['NewHearingType'] = _2011SchedulingInitData['HearingType'];
                                }
                                this.props.processCaseReExam(_2011SchedulingInitData)}}>Update</Button>
                            <Button style={{ color: "white", marginLeft: "2%", backgroundColor: "red" }}
                                type="default" key="Cancel" onClick={(e) => {             
                                    this.props.closeReExam();
                                }}>Cancel</Button>
                        </Col>
                    </Row>
                    </Form>
                    </React.Fragment>:<React.Fragment><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></React.Fragment>}
        </React-Fragment>
        );
    }
}

export default Case2011Scheduling;