import React, { Component } from 'react';
import { Row, Col, Table, Card, Spin, Select, Button, Icon, Divider, Modal, Tooltip } from 'antd';
import cloneDeep from 'lodash/cloneDeep';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
const { Option } = Select;

const getDropdownList = (listObj, selectedValue) => {
    return listObj.map(item => {
        if(item.Value)
        {
            if (item.Value !== "") {
                if (item.Value === selectedValue) {
                    return <Option key={item.Value} selected>{item.Text}</Option>;
                }
                return <Option key={item.Value} >{item.Text}</Option>;
            }
        }
        else
        {
            return <Option key={item.ShortID} value={item.ShortID} >{item.ShortID} - {item.FirstName} {item.LastName}</Option>;
        }
        return "";
    });
}

const defaultCaseSuspenseObj = {
    SuspenseDate: new Date(),
    RequestedBy: '',
    SuspenseReason: '',
    SuspenseDescription: null,
};

class CaseSuspense extends Component {
    constructor(props) {
        super(props);

        this.state = {
            caseSuspenseObj: cloneDeep(defaultCaseSuspenseObj),
            getCaseSuspenseData: this.props.caseSuspenseDetails,
            caseSuspenseReasonsList: this.props.caseSuspenseReasonsList,
            employeesForOfficeList: this.props.employeesForOfficeList,
            editMode: false,
            deleteModalShow: false,
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.enableEdit = this.enableEdit.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.handleEditCancel = this.handleEditCancel.bind(this);
        this.handleSave = this.handleSave.bind(this);
        this.deleteModal = this.deleteModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
    }
    componentDidUpdate(prevProps) {
        if ( prevProps.caseSuspenseDetails !== this.props.caseSuspenseDetails ) {
            this.setState({getCaseSuspenseData: this.props.caseSuspenseDetails});
    }
    if ( prevProps.caseSuspenseReasonsList !== this.props.caseSuspenseReasonsList ) {
        this.setState({caseSuspenseReasonsList: this.props.caseSuspenseReasonsList});
}
if ( prevProps.employeesForOfficeList !== this.props.employeesForOfficeList ) {
    this.setState({employeesForOfficeList: this.props.employeesForOfficeList});
}
}
    handleFieldChange(e, type) {
        const { caseSuspenseObj } = this.state;
        if(!e)
        {
            caseSuspenseObj[type] = '';
        }
        else
        {
            switch (type) {
                case 'SuspenseReason':
                    caseSuspenseObj[type] = e;
                    caseSuspenseObj['SuspenseDescription'] = this.state.caseSuspenseReasonsList.find(c => c.Value === e).Text
                    break;
                case 'RequestedBy':
                    caseSuspenseObj[type] = e;
                    break;
                default:
                    break;
            }
        }
        this.setState({ caseSuspenseObj: caseSuspenseObj, isDirty: true });
    }

    handleCancel(type) {
        if(type === 'cancel')
        {
            this.setState({ newSuspense: false, caseSuspenseObj: cloneDeep(defaultCaseSuspenseObj), isDirty: false });
        }
        else
        {
            this.setState({ caseSuspenseObj: cloneDeep(defaultCaseSuspenseObj), isDirty: false });
        } 
    }

    onDateChange(d, type) {
        const { caseSuspenseObj } = this.state;
        caseSuspenseObj[type] = d|| new Date();

        this.setState({ caseSuspenseObj });
    }

    handleEditCancel() {
        this.setState({ deleteModalShow: false });
    }

    handleSave(type) {
        this.setState({newSuspense: false, editMode: false, caseSuspenseObj: cloneDeep(defaultCaseSuspenseObj)});
        this.props.handleSuspenseSave(type, this.state.caseSuspenseObj);
    }

    enableEdit(item) {
        this.setState({ editMode: true, caseSuspenseObj: { ...item }, newSuspense: true, modalTitle: "Modify Case Suspense" });
    }

    deleteModal(item) {
        this.setState({ selectedsuspenseId: item.Suspense_ID, deleteModalShow: true });
    }

    handleDelete(suspenseId) {
        this.setState({ caseSuspenseObj: cloneDeep(defaultCaseSuspenseObj), deleteModalShow: false });
        this.props.handleDeleteSuspense(suspenseId);
    }

    render() {
        const { caseSuspenseObj, editMode, getCaseSuspenseData, caseSuspenseReasonsList, employeesForOfficeList } = this.state;
        const { SuspenseDate, SuspenseReason, RequestedBy } = caseSuspenseObj;
        const caseSuspenseData = getCaseSuspenseData;
        let suspenses = [];
        let columns = [];
        if(this.state.getCaseSuspenseData !== undefined)
        {
          suspenses = getCaseSuspenseData.Suspense;
        }
        let reasonsList = [], employeesList = [];
        if(employeesForOfficeList && employeesForOfficeList.length > 0)
        {
            employeesList = getDropdownList(employeesForOfficeList);
        }
        if(caseSuspenseReasonsList !== undefined && caseSuspenseReasonsList.length > 0)
        {
            reasonsList = getDropdownList(caseSuspenseReasonsList);
            columns =  [{
                title: 'Suspense Date',
                dataIndex: 'SuspenseDate',
                key: `${Math.random()}`
            },
            {
                title: 'Requested By',
                dataIndex: 'RequestedBy',
               // key: 'RequestedBy'
            },
            // {
            //     title: 'Reason',
            //     dataIndex: 'SuspenseReason',
            //     key: 'SuspenseReason',                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
            // },
            {
                title: 'Reason - Description',
                dataIndex: 'SuspenseReason',
              //  key: 'SuspenseDescription',
                render: (SuspenseReason) =>
                { 
                    let desc= "";
                    caseSuspenseReasonsList.map(c => {
                        if(c.Value === SuspenseReason)
                    {
                        desc = c.Text;
                    }
                    return "";
                });
                if(desc === "")
                {
                    desc = SuspenseReason;
                }
                return desc;
                }
            },
            {
                title: 'Updated By',
                dataIndex: 'UpdatedBy',
              //  key: 'UpdatedBy'
            },
            {
                title: 'Updated Date',
                dataIndex: 'UpdateDate',
               // key: 'UpdateDate'
            },
            {
                title: 'Options',
                width: '8%',
                render: (item, index) => {
                    return (
                        <div key={index} style={{ textAlign: "center" }}>
                            <Tooltip
       title="Modify Suspense"
       placement="topLeft"
     ><Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.enableEdit(item)} /></Tooltip>
                            <Divider type="vertical" />
                            <Tooltip
       title="Delete Suspense"
       placement="topLeft"
     >   <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.deleteModal(item)} /></Tooltip>
                        </div>
                    );
                },
            },
            ];
    }

        const boxShadows = {
            boxShadow:
                "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
        };

        return (
            <div>
                <div>
                    <Row>
                        <Col span={24}>
                            <Card
                                style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    ...boxShadows
                                }}
                            >
                               <Modal width="70%" title={this.state.modalTitle} maskClosable={false} visible={this.state.newSuspense}
                               onCancel={(e) => this.handleCancel('cancel')}
                               footer = { [
                                editMode ?
                                <div>
                                    <Button type="primary" key="Save" style={{backgroundColor: "green", color: "white"}} onClick={(e) => this.handleSave('Edit')}> Save </Button> 
                                    <Button type="default" key="Cancel" style={{backgroundColor: "red", color: "white"}} onClick={(e) => this.handleCancel('cancel')}>Cancel</Button>
                                </div> :
                                <div>
                               {SuspenseReason !== "" && RequestedBy !== "" ? <Button type="primary" key="Ok" style={{backgroundColor: "green", color: "white"}} onClick={(e) => this.handleSave('New')}>Add</Button> : <Button type="primary" key="Ok" disabled>Add</Button> }
                                <Button type="default" key="Cancel" style={{backgroundColor: "red", color: "white"}} onClick={(e) => this.handleCancel('cancel')}>Cancel</Button>
                                </div>
                            ]}
                               >
                              <div> <Row>
                                    <Col span={4}>
                                        <b>Case Number</b>: {caseSuspenseData.CD_CASE}
                                    </Col>
                                    <Col span={1} />
                                    <Col span={5}>
                                        <b>DL Number</b>: {caseSuspenseData.DLNumber}
                                    </Col>
                                    <Col span={1} />
                                    <Col span={4}>
                                        <b>Subject Name</b>: {caseSuspenseData.SubjectName}
                                    </Col>
                                    <Col span={1} />
                                    <Col span={4}>
                                        <b>Employee Requestor</b>: {caseSuspenseData.EmployeeRequestor}
                                    </Col>
                                </Row>
                                <hr />
                                 <Row>
                                    <Col span={4}>
                                        <b>Suspense Date </b>: 
                                        {/* <DatePicker placeholder="Suspense Date"
                                            value={moment(SuspenseDate, dateFormat)} format={dateFormat} onChange={(d, ds) => { this.onDateChange(d, ds, 'SuspenseDate') }} /> */}
                                     <DatePicker
                            className = "CalClass"
                             selected={SuspenseDate}
                             dateFormat={"MM-dd-yyyy"}
                             onChange={(d) => {this.onDateChange(d, 'SuspenseDate')}}
                             isClearable={true}
                             placeholderText="Select Date"
                           />
                                    </Col>
                                    <Col span={1} />
                                    <Col span={4}>
                                        <b>Requested By </b>: <Select allowClear = {true} id = "RB" onFocus={(e) => {
                                document.getElementById("RB").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} value={RequestedBy !== "" ? RequestedBy : undefined} placeholder="Select Employee" showArrow={true} 
                                            size={"default"} style={{ width: '100%' }} onChange={(e) => this.handleFieldChange(e, 'RequestedBy')}>
                                            {employeesList}
                                        </Select> 
                                        {/* <Input placeholder="Requested By" value={RequestedBy}
                                            onChange={e => this.handleFieldChange(e, 'RequestedBy')} /> */}
                                    </Col>
                                    <Col span={1} />
                                    <Col span={5}>
                                        <b>Reason </b>: <Select allowClear = {true} id = "REA" onFocus={(e) => {
                                document.getElementById("REA").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} value={SuspenseReason !== "" ? SuspenseReason: undefined} placeholder="Select Reason" showArrow={true} 
                                            size={"default"} style={{ width: '100%' }} onChange={(e) => this.handleFieldChange(e, 'SuspenseReason')}>
                                            {reasonsList}
                                        </Select>
                                    </Col>
                                    <Col span={1} />
                                    <Col span={8}>
                                        <b>Description </b>: <div> {SuspenseReason ? caseSuspenseReasonsList.map(c => {  if(c.Value === SuspenseReason)
                    {
                        return c.Text;
                    }
                else
                {return ""}}) : ''} </div>
                                    </Col>
                                </Row>
                             {editMode ? <Button style={{ marginLeft: "40%", marginTop: "2%"}} onClick={(e) => this.handleCancel('clear')}><Icon type="rollback" theme="outlined" /> Clear Fields </Button> : <Button disabled={!this.state.isDirty} style={{ marginLeft: "40%", marginTop: "2%"}} onClick={(e) => this.handleCancel('clear')}><Icon type="rollback" theme="outlined" /> Clear Fields </Button>}
                                </div>
                                </Modal>
                                <br />
                                <Row>
                                    <div><span><h1>Case Suspense Details</h1></span></div>
                                       <div>
                                            <Button type="primary" style={{float: 'right'}} onClick={(e) => this.setState({newSuspense: true, modalTitle: "New Case Suspense"})}> + Add New Suspense </Button>
                                        </div>
                                </Row>
                                {
                                    suspenses ? suspenses.length > 0 ? <Table
                                        rowKey='Suspense_ID'
                                        footer={() => <p>{suspenses.length} suspense(s) </p>}
                                        showHeader
                                        columns={columns}
                                        dataSource={suspenses}
                                        pagination={{ pageSize: 8 }} /> : <div>No suspenses on this case.</div>
                                        : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>
                                }
                            </Card>
                        </Col>
                    </Row>
                    <Modal maskClosable={false} visible={this.state.deleteModalShow}
                        onCancel={this.handleEditCancel}
                        footer={[
                                  <div key="footer">
                                      <Button style={{ color: "white", backgroundColor: "green" }} type="default" key="Ok" onClick={(e) => this.handleDelete(this.state.selectedsuspenseId)}>Yes</Button>
                                <Button style={{ color: "white", backgroundColor: "red" }} type="default" key="Cancel" onClick={this.handleEditCancel}>No</Button>
                            </div>
                        ]}
                    >
                        Do you want to delete the suspense on {SuspenseDate}?
                    </Modal>
                </div>
            </div>
        );
    }
}

export default CaseSuspense;

