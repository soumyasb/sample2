import React, { Component } from 'react';
// import PropTypes from 'prop-types';  // NOU - 8/20/2019
import { getCaseDetails, getHearingTypes, getCaseReasons, getEmployeesForOffice, getCaseReferrals, getCaseCertifications, getCustomerD26Info, modifyCaseDetail
, getH6Info, getCaseComments, getCaseScheduleDetail, addCaseComment, deleteCaseComment, getAllOIPsforCase, getOIPTypesList, getOIPLanguages, getOIPLookUpResults
,deleteOIP, updateOIP, saveNewOIP, removeOIP, assignOIP, getCaseCoverSheet, getCaseSuspenseDetails, getCaseSuspenseReasons, addCaseSuspense, modifyCaseSuspense
, deleteCaseSuspense } from "../../../store/actions/caseActions";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { getCaseInfo, initRSRCCaseData, updateRSRCCase } from "../../../store/actions/caseSchedulingActions";
import { getOffices } from "../../../store/actions/dataManagerActions";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
//import ReactToPrint from 'react-to-print';
import moment from "moment";
import { connect } from "react-redux";
import { Table, List, notification, Spin, Modal, Radio, Input, Tooltip, Button, Select, Layout, Menu, Icon, Badge, DatePicker } from 'antd';
import "../../../Cases.css";
import cloneDeep from 'lodash/cloneDeep';
import CaseOIPDetails from './CaseOIPDetails';
import CaseSuspense from './CaseSuspense';
import ComponentToPrint from './CoverSheetPrintComponent';
//import PrintCoversheet from './PrintCoversheet';
import CaseSchedule from './CaseSchedule';
import CaseReSchedReConv from './CaseReschedReconvene';

const { MonthPicker } = DatePicker;
const monthFormat = 'MM-YY';

const {Option} = Select;
const {Content,Sider } = Layout;
const RadioGroup = Radio.Group;
const { TextArea } = Input;
const radioStyle = {
  display: 'block',
  height: '30px',
  lineHeight: '30px',
};
const getDropdownList = (listObj, selectedValue) =>   
{  
    let list = [];   

     listObj.map(item =>
{
  if(item.Value !== ""){
  if(item.Value === selectedValue)
  {
    list.push(<Option key={item.Value} value={item.Value} selected>{item.Text}</Option>)
  }
  else
  {
  list.push(<Option key={item.Value} value={item.Value}>{item.Text}</Option>)
  }
  }  
  return "";
});  
  return list;  
 
   }
   
const oipcolumns = [  {
  title: <b>OIP Name</b>,
  dataIndex: 'OIPName',
 width: "20%",
  key: `${Math.random()}`
},
{
  title: <b>Agency</b>,
  dataIndex: 'AgencyName',
 width: "20%",
 // key: 'AgencyName'
},
{
  title: <b>Phone No.</b>,
  dataIndex: 'PhoneNo',
 width: "20%",
 // key: 'PhoneNo'
},
{
  title: <b>Cell No.</b>,
  dataIndex: 'CellNo',
 width: "20%",
 // key: 'CellNo'
},
{
  title: <b>Fax</b>,
  dataIndex: 'FaxNo',
 width: "20%",
//  key: 'FaxNo'
}];

const reschedcolumns = [  {
  title: <b>Schedule Date</b>,
  dataIndex: 'ScheduleDate',
 // key: 'ScheduleDate'
},
{
  title: <b>Schedule Time</b>,
  dataIndex: 'ScheduleTime',
 // key: 'ScheduleTime'
},
{
  title: <b>Location</b>,
  dataIndex: 'Location',
 // key: 'Location'
},
{
  title: <b>Hearing Officer</b>,
  dataIndex: 'HearingOfficer',
 // key: 'HearingOfficer'
},
{
  title: <b>Scheduled By</b>,
  dataIndex: 'ScheduledBy',
 // key: 'ScheduledBy'
},
{
  title: <b>Authorized By</b>,
  dataIndex: 'AuthorizedBy',
 // key: 'AuthorizedBy'
}];
   const getAccidentsList = (accidentsObj) =>   
{  
    let list = [];   
    accidentsObj.Accidents.map(item =>
{
  list.push(<Radio style={radioStyle} value={item.CaseNumber}><span style={{paddingLeft:"5px"}}>{item.CaseNumber}</span><span style={{paddingLeft:"25px"}}>{item.Date}</span><span style={{paddingLeft:"25px"}}>{item.City}</span></Radio>)
  return "";  
}
);   return list; 
   }
const reqRsnCodesForCerts = ["871","875","880","881","882","883","884","885","887","888","889","891","892","894","897","898"];


class CaseDetails extends Component {
    constructor(props) {
        super(props);
        this.state={
          caseNumber: props.match.params.CaseNumber,
            editmode: false,
            caseDetailsObj: props.cases.caseDetailsObj,
            hearingTypes: props.cases.hearingTypesList,
            caseReasons: props.cases.caseReasonsList,
            caseReferrals: props.cases.caseReferralsList,
            caseCertifications: props.cases.caseCertificationsList,
            caseScheduleData: props.cases.caseScheduleData,
            customerD26Info: props.cases.customerD26Info,
            isRequired: false,
            open: false,
            htopen: false,
            tabValue: 'CaseDetail',
            caseSchedVisible: false,
            caseComments: props.cases.caseComments,
            newCommModal: false,
            openDelConf: false,
            openstatusModal: false,
            commentValue: "",
            commentType: "C",
            commentNumber: "",
            purgeDate: "",
            enableSaveButton: false,
            //PhoneNumber:props.cdObj.Customer.PhoneNumber  // NOU - 8/20/2019
        };
       this.handlePhoneChange = this.handlePhoneChange.bind(this);  // NOU - 8/20/2019
       this.onButtonClick = this.onButtonClick.bind(this);   
       this.handleClick = this.handleClick.bind(this);
       this.openCaseSchedule = this.openCaseSchedule.bind(this);
       this.onCommentTextChange = this.onCommentTextChange.bind(this);   
       this.onCommentTypeChange = this.onCommentTypeChange.bind(this);   
       this.onCommentNumberChange = this.onCommentNumberChange.bind(this);
       this.onPurgeDateChange = this.onPurgeDateChange.bind(this);
       this.openNotification = this.openNotification.bind(this);
       this.getOIPLookUpResults = this.getOIPLookUpResults.bind(this);
       this.deleteOIP = this.deleteOIP.bind(this);
       this.handleSave = this.handleSave.bind(this);
       this.assignOIP = this.assignOIP.bind(this);
       this.handleSuspenseSave = this.handleSuspenseSave.bind(this);
       this.handleDeleteSuspense = this.handleDeleteSuspense.bind(this);
       this.print = this.print.bind(this);
    }    
    componentDidMount() {
      if(this.props.location.state.selectedKeys && this.props.location.state.tabValue)
      {
        this.props.getCaseInfo(this.props.match.params.CaseNumber);
        this.props.getOffices();
        this.setState({selectedKeys: this.props.location.state.selectedKeys, tabValue: this.props.location.state.tabValue});
      }
      this.props.getCaseDetails(this.state.caseNumber);
      this.props.getAllOIPsforCase(this.state.caseNumber);
      this.props.getOIPTypesList();
      this.props.getOIPLanguages();    
      this.props.getHearingTypes();
      this.props.getCaseReasons();
      this.props.getCaseReferrals();
      this.props.getCaseCertifications();
      this.props.getCaseComments(this.state.caseNumber);
     if (this.props.location.state !== undefined){ 
      if(this.props.location.state.caseStatus === 'saved')
      {
        this.props.getCaseCoverSheet(this.state.caseNumber);
        this.setState({open: true, printModalMsg: "Case has been created. Do you wish to print the coversheet for this case?"});
      }
    else
  {
    this.props.getCustomerD26Info(this.props.location.state.dlNumber);
  } }
     
  }
  componentDidUpdate(prevProps)
  { 
    if (prevProps.cases.caseDetailsObj !== this.props.cases.caseDetailsObj) {
      if(this.props.cases.caseDetailsObj !== undefined)
      {
        const cdObj = this.props.cases.caseDetailsObj;
        if(this.props.cases.modified === true){ 
          this.openNotification('The case was modified successfully!');
          this.props.getCaseCoverSheet(this.state.caseNumber);
          this.setState({ caseDetailsObj: cdObj, newCaseDetailsObj: cloneDeep(cdObj), hearingType: cdObj.CD_HRNG_TYP, caseReason: cdObj.CD_RSN, caseReferral: cdObj.CD_REFR_SRCE_TYP,
        caseCertification: cdObj.CD_ENDR, hearingTypes: this.props.cases.hearingTypesList, caseReasons: this.props.cases.caseReasonsList, caseReferrals: this.props.cases.caseReferralsList, 
        caseCertifications: this.props.cases.caseCertificationsList, value: this.props.cases.caseDetailsObj.FRCaseNumber, open: true, printModalMsg: "Case has been modified. Do you wish to print a coversheet for this case?" });
          }
          else
          {
            this.setState({ caseDetailsObj: cdObj, newCaseDetailsObj: cloneDeep(cdObj), hearingType: cdObj.CD_HRNG_TYP, caseReason: cdObj.CD_RSN, caseReferral: cdObj.CD_REFR_SRCE_TYP,
              caseCertification: cdObj.CD_ENDR, hearingTypes: this.props.cases.hearingTypesList, caseReasons: this.props.cases.caseReasonsList, caseReferrals: this.props.cases.caseReferralsList, 
              caseCertifications: this.props.cases.caseCertificationsList, value: this.props.cases.caseDetailsObj.FRCaseNumber});
          }
      if (prevProps.location.state === undefined){ this.props.getCustomerD26Info(this.props.cases.caseDetailsObj.DLNumber); }
  
    };
      }
      if(prevProps.cases.caseReasonsList !== this.props.cases.caseReasonsList)
      {
        this.setState({caseReasons: this.props.cases.caseReasonsList});
      }
      if(prevProps.caseScheduling.rsrcdataObj !== this.props.caseScheduling.rsrcdataObj)
      {
        this.setState({rsrcdataObj: this.props.caseScheduling.rsrcdataObj});
      }
      if(prevProps.caseScheduling.rsrcUpdateData !== this.props.caseScheduling.rsrcUpdateData)
      {
        if(this.props.caseScheduling.rsrcUpdateData.Error === true)
        {
          var caseErrorData = [];
          caseErrorData.push(this.props.caseScheduling.rsrcUpdateData.Message);
          this.setState({caseErrorData: caseErrorData, rsrcUpdateData: this.props.caseScheduling.rsrcUpdateData, caseError: true});
        }
        else{
          this.setState({rsrcUpdateData: this.props.caseScheduling.rsrcUpdateData, openstatusModal: true});
        }
       
      }
      if(prevProps.cases.hearingTypesList !== this.props.cases.hearingTypesList)
      {
        this.setState({hearingTypes: this.props.cases.hearingTypesList});
      }
      if(prevProps.cases.caseReferralsList !== this.props.cases.caseReferralsList)
      {
        this.setState({caseReferrals: this.props.cases.caseReferralsList});
      }
      if(prevProps.cases.caseCertificationsList !== this.props.cases.caseCertificationsList)
      {
        this.setState({caseCertifications: this.props.cases.caseCertificationsList});
      }
  if(prevProps.cases.caseComments !== this.props.cases.caseComments)
  {
    this.setState({caseComments: this.props.cases.caseComments});
  }
  if (prevProps.cases.caseOIPsData !== this.props.cases.caseOIPsData) 
  {
   this.setState({allOIPsforaCaseNumber: this.props.cases.caseOIPsData, oipItemObj: this.props.cases.caseOIPsData[0], oipCount: this.props.cases.caseOIPsData.length});
  }
  if (prevProps.cases.OIPTypesListData !== this.props.cases.OIPTypesListData) 
  {
   this.setState({OIPTypesListData: this.props.cases.OIPTypesListData});
  }
  if (prevProps.cases.OIPlanguagesData !== this.props.cases.OIPlanguagesData) 
  {
   this.setState({OIPlanguagesData: this.props.cases.OIPlanguagesData});
  }
  
  if(prevProps.cases.addCaseCommentData !== this.props.cases.addCaseCommentData)
  {
  if(this.props.cases.addCaseCommentData.Error === false)
  {
  this.openNotification('The comment was added successfully!');
  this.props.getCaseComments(this.state.caseNumber);
  }
  }
  if(prevProps.cases.caseErrorData !== this.props.cases.caseErrorData)
  {
  this.setState({caseErrorData: this.props.cases.caseErrorData,  caseError: true})
  }
  if(prevProps.cases.OIPDeleteData !== this.props.cases.OIPDeleteData)
  {
      this.props.getAllOIPsforCase(this.state.caseNumber);
  this.openNotification('The OIP was deleted successfully!');
  }
  if(prevProps.cases.OIPRemoveData !== this.props.cases.OIPRemoveData)
  {
      this.props.getAllOIPsforCase(this.state.caseNumber);
  this.openNotification('The OIP was Removed from the case successfully!');
  }
  if(prevProps.cases.OIPUpdateData !== this.props.cases.OIPUpdateData)
  {
      this.props.getAllOIPsforCase(this.state.caseNumber);
  this.openNotification(this.props.cases.OIPUpdateData.StatusMessage);
  }
  if(prevProps.cases.OIPAssignData !== this.props.cases.OIPAssignData)
  {
      this.props.getAllOIPsforCase(this.state.caseNumber);
  this.openNotification(this.props.cases.OIPAssignData.StatusMessage);
  }
  if(prevProps.cases.OIPSaveData !== this.props.cases.OIPSaveData)
  {
      this.props.getAllOIPsforCase(this.state.caseNumber);
  this.openNotification('The OIP was saved successfully!');
  }
  if(prevProps.cases.caseSuspenseDetails !== this.props.cases.caseSuspenseDetails)
  {
  this.setState({ caseSuspenseDetails: this.props.cases.caseSuspenseDetails});
  }
  if(prevProps.caseScheduling.caseInfo !== this.props.caseScheduling.caseInfo)
  {
  this.setState({ caseInfo: this.props.caseScheduling.caseInfo, scheduleObj: cloneDeep(this.props.caseScheduling.caseInfo)});
  }
  if(prevProps.cases.caseSuspenseReasons !== this.props.cases.caseSuspenseReasons)
  {
  this.setState({ caseSuspenseReasons: this.props.cases.caseSuspenseReasons});
  }
  if(prevProps.cases.employeesForOffice !== this.props.cases.employeesForOffice)
  {
  this.setState({ employeesForOffice: this.props.cases.employeesForOffice});
  }
  
  if(prevProps.cases.addCaseSuspenseData !== this.props.cases.addCaseSuspenseData)
  {
      this.props.getCaseSuspenseDetails(this.state.caseNumber);
  this.openNotification(this.props.cases.addCaseSuspenseData.Message);
  }
  if(prevProps.cases.modifyCaseSuspenseData !== this.props.cases.modifyCaseSuspenseData)
  {
      this.props.getCaseSuspenseDetails(this.state.caseNumber);
  this.openNotification(this.props.cases.modifyCaseSuspenseData.Message);
  }
  if(prevProps.cases.deleteCaseSuspenseData !== this.props.cases.deleteCaseSuspenseData)
  {
      this.props.getCaseSuspenseDetails(this.state.caseNumber);
  this.openNotification("Case Suspense Deleted");
  }
  if(prevProps.cases.commentDelData !== this.props.cases.commentDelData)
  {
  if(this.props.cases.commentDelData.Error === false)
  {
  this.openNotification('The comment was deleted successfully!');
  this.props.getCaseComments(this.state.caseNumber);
  }
  }
  if (prevProps.cases.OIPLookupResults !== this.props.cases.OIPLookupResults) {
  this.setState({ OIPLookupResults: this.props.cases.OIPLookupResults});
  }
  if (prevProps.cases.caseCoverSheetObj !== this.props.cases.caseCoverSheetObj) {
  this.setState({ caseCoverSheetObj: this.props.cases.caseCoverSheetObj});
  }
  if (prevProps.cases.customerD26Info !== this.props.cases.customerD26Info) {
    this.setState({ customerD26Info: this.props.cases.customerD26Info});
  }
  if (prevProps.dataManager.allOfficesList !== this.props.dataManager.allOfficesList) {
    this.setState({ allOfficesList: this.props.dataManager.allOfficesList, instance: Math.random()});
  }
  if (prevProps.cases.h6Info !== this.props.cases.h6Info) {
  if(this.props.cases.h6Info !== undefined)
  {
  this.setState({ h6Info: Object.entries(this.props.cases.h6Info).map(([key,value])=>{
  return (value.toString());})});
  }
  }
  if (prevProps.cases.caseScheduleData !== this.props.cases.caseScheduleData) {
  if(this.props.cases.caseScheduleData !== undefined)
  {
  
  let odata = [], rdata = [];
  this.props.cases.caseScheduleData.OIPs !== undefined &&  this.props.cases.caseScheduleData.OIPs.map((item) => {
  const oipitem = {
  OIPName: item.NMEFRSTPRSN + " "+ item.NMESURNMEPRSN,
  AgencyName: item.NMEAGENCY,
  PhoneNo: item.NBRPHONE,
  CellNo: item.NBRCELLPHONE,
  FaxNo: item.NBRFAX
  }
  odata.push(oipitem);
  return "";
  }
  )
  
  this.props.cases.caseScheduleData.Reschedules.results !== undefined &&  this.props.cases.caseScheduleData.Reschedules.results.map((item) => {
  rdata.push(item);
  return "";
  })
  
  this.setState({ oipdata: odata, caseScheduleData: this.props.cases.caseScheduleData, scheddata: this.props.cases.caseScheduleData.Contacts.results[0], rescheddata: rdata });
  }
  }
  }

componentWillUnmount()
{
    this.setState({open: false});
}  

onButtonClick = (e,value) => 
{
if(value === 'Edit')
{
this.setState({editmode: true});
}
if(value === 'Back')
{
  this.props.getCaseDetails(this.state.caseNumber);
}
if(value === 'Cancel')
{
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_HRNG_TYP});
  this.setState({caseReason: this.props.cases.caseDetailsObj.CD_RSN});
  this.setState({caseReferral: this.props.cases.caseDetailsObj.CD_REFR_SRCE_TYP});
  this.setState({caseCertification: this.props.cases.caseDetailsObj.CD_ENDR}); 
  this.setState({editmode: false});
  this.setState({ value: this.props.cases.caseDetailsObj.FRCaseNumber});
}
if(value === 'Save')
{
  const {newCaseDetailsObj} = this.state;
  newCaseDetailsObj.FRCaseNumber = this.state.value;
   this.state.customerD26Info.Accidents.map(item =>
  {
    if(item.CaseNumber === newCaseDetailsObj.FRCaseNumber)
    {
      newCaseDetailsObj.AccidentDate = item.Date;
    }
    return "";
  })
 this.state.customerD26Info.Accidents.map(item =>
    {
      if(item.CaseNumber === newCaseDetailsObj.FRCaseNumber)
      {
        newCaseDetailsObj.AccidentCity =  item.City;
      }
      return "";
    })
    this.props.modifyCaseDetail(newCaseDetailsObj);
this.setState({editmode: false});
}
if(value === 'New')
{
  this.setState({commentValue:"", commentType: "C", commentNumber: "", purgeDate: "", newCommModal: true});
}
}
onChange = (e) => {
  this.setState({
    value: e.target.value,
  });
}
assignOIP = (oipid, oiptype) =>
{
const assignOIP = {
  "oipid": oipid,
  "caseNumber": this.state.caseNumber,
  "type": oiptype
}
this.props.assignOIP(assignOIP);
} 
  getOIPLookUpResults = (oipLookupItemObj) => 
{
this.props.getOIPLookUpResults(this.state.caseNumber, oipLookupItemObj);
}

print(ctype,ftype) {
  var content = document.getElementById(ctype);
  var pri = document.getElementById(ftype).contentWindow;
  pri.document.open();
  pri.document.write(content.innerHTML);
  var result = pri.document.execCommand('print', false, null);
  if(!result) {
  pri.document.close();
  pri.focus();
  pri.print();
  }
}


deleteOIP = (OIPId, type, CDPRTYTYP) => 
{
  const deleteOIPObj = {
    "oipid": OIPId,
    "caseNumber": this.state.caseNumber,
    "type": CDPRTYTYP
  }
  if(type === 'delete')
this.props.deleteOIP(deleteOIPObj);
if(type === 'remove')
this.props.removeOIP(deleteOIPObj);
}

removeOIP = (OIPId) => 
{
this.props.removeOIP(this.state.caseNumber, OIPId);
}

handleSuspenseSave = (type, caseSuspenseObj) =>
{
  caseSuspenseObj.CD_CASE = this.state.caseNumber;
  if(type === 'Edit')
  {
    caseSuspenseObj.SuspenseID = caseSuspenseObj.Suspense_ID;
  this.props.modifyCaseSuspense(caseSuspenseObj);
  }
  if(type === 'New')
  {
  this.props.addCaseSuspense(caseSuspenseObj);
  }
}

handleDeleteSuspense = (suspenseId) =>
{
this.props.deleteCaseSuspense(suspenseId);
}

handleSave = (OIPItemObj) =>
{
  if(OIPItemObj.OIPID !== 0)
  this.props.updateOIP(OIPItemObj.CDPRTYTYP, OIPItemObj.OIPID, OIPItemObj);
  else
  {
    OIPItemObj.CdCase = this.state.caseNumber;
  this.props.saveNewOIP(OIPItemObj.CDPRTYTYP, OIPItemObj);
  }
}

handleOk = (e) => {
  const lastnameFirst3 = this.state.caseDetailsObj.Customer.LastName.substring(0,3).toUpperCase();
  let commentData = {
    "commentTextInput": this.state.commentValue,
    "placeholder": "",
    "dlNumber": this.state.caseDetailsObj.Customer.DLNumber,
    "commentType": this.state.commentType,
    "commentNumber": this.state.commentNumber,
    "purgeDate": this.state.purgeDate.replace('-', ''),
    "lastnameFirst3": lastnameFirst3
  }
  this.props.addCaseComment(this.state.caseDetailsObj.CaseNumber, commentData);
  this.setState({newCommModal: false});
}

openDelConf = (comm_number) => 
{
  this.setState({openDelConf: !this.state.openDelConf, commentNumber: comm_number}); 
} 

closeDelConf = (e) => 
{
  this.setState({openDelConf: !this.state.openDelConf, commentNumber: ""});
}
handleDelete =(comm_Number) => {
  let commentDelObj = {
    "dlNumber": this.state.caseDetailsObj.Customer.DLNumber,
    "commentNumber": this.state.commentNumber,
    "deleteFlag": true
  }
  this.props.deleteCaseComment(this.state.caseDetailsObj.CaseNumber, commentDelObj);
  this.setState({openDelConf: false, commentNumber: ""});
}

handleCancelComm = (e) => {
  this.setState({newCommModal: false, commentValue: "", commentType: "C", commentNumber: "", purgeDate: ""});
}

handleClick = (e) => {
  
  this.setState({
    tabValue: e.key, selectedKeys: e.key
  })
  if(e.key === 'DadH6')
  {
    this.props.getH6Info(this.state.caseDetailsObj.DLNumber);
  }
  // NOU - handler option for printing cover sheet
  if (e.key === 'PrintCoversheet')
  {
    this.props.getCaseCoverSheet(this.state.caseDetailsObj.CaseNumber);
    this.setState({printModalOpen:true});
  } 
  if(e.key === 'ReConvene' || e.key === 'ReSchedule')
  {
    this.props.initRSRCCaseData(e.key, this.state.caseDetailsObj);
  }
  if(e.key === 'Schedule')
  {
    this.setState({instance: Math.random()});
    this.props.getCaseInfo(this.state.caseNumber);
    this.props.getOffices();
    
  }
  if(e.key === 'Suspense')
  {
    this.props.getCaseSuspenseDetails(this.state.caseNumber);
    this.props.getCaseSuspenseReasons();
    if(sessionStorage.getItem('userInfo') && Object.keys(JSON.parse(sessionStorage.getItem('userInfo'))).length > 0){
      this.props.getEmployeesForOffice(JSON.parse(sessionStorage.getItem('userInfo')).OfficeId);
    }
  }
}
openCaseSchedule() {
  this.props.getCaseScheduleDetail(this.state.caseDetailsObj.DLNumber, this.state.caseDetailsObj.CaseNumber);
  this.setState({caseSchedVisible: true});
}

handleCancel = (e) => {
  this.setState({
    caseSchedVisible: false,
  });
}

handleError = (e) => {
  this.setState({
    caseError: false,
  });
}

handleChange = (e,listType) => {
  if(listType === 'HRNG_TYP')
{    
  const {newCaseDetailsObj} = this.state;
  newCaseDetailsObj.CD_HRNG_TYP = e;
 this.setState({newCaseDetailsObj: newCaseDetailsObj, hearingType: e, isDirty: true});
}
if(listType === 'CASE_RSN')
{    
  const {newCaseDetailsObj} = this.state;
  newCaseDetailsObj.CD_RSN = e;
 this.setState({newCaseDetailsObj: newCaseDetailsObj, caseReason: e, isDirty: true});
}
if(listType === 'CASE_RFL')
{   
  const {newCaseDetailsObj} = this.state;
  newCaseDetailsObj.CD_REFR_SRCE_TYP = e;
 this.setState({newCaseDetailsObj: newCaseDetailsObj, caseReferral: e, isDirty: true}); 
}
if(listType === 'CASE_CERT')
{    
  const {newCaseDetailsObj} = this.state;
  newCaseDetailsObj.CD_ENDR = e;
 this.setState({newCaseDetailsObj: newCaseDetailsObj, caseCertification: e, isDirty: true});
}
}
handlePhoneChange = (e) => {
  const { value } = e.target;
  const reg = /^[0-9]*$/; 

  const {newCaseDetailsObj} = this.state;
   
   if ((!isNaN(value) && reg.test(value))) {
    newCaseDetailsObj.Customer.PhoneNumber = value;
   this.setState({
    newCaseDetailsObj: newCaseDetailsObj,
       isDirty: true
   });
  }
}
onCommentTypeChange(e)
{
  this.setState({
    commentType: e.target.value,
    commentValue: "",
    commentNumber: "",
    purgeDate: ""
  });
}
onCommentNumberChange(e)
{
  const { value } = e.target;
  const reg = /^[0-9]*$/;
  if ((!isNaN(value) && reg.test(value))) {
    this.setState({
      commentNumber: e.target.value
    });
  }
 
}
onPurgeDateChange(date, dateString)
{
  const value  = dateString;
    this.setState({
      purgeDate: value
    });
}
onCommentTextChange(e) 
{
  this.setState({ commentValue: e.target.value });
}

openNotification = (msg) => {
  notification.open({
    message: 'SUCCESS',
    description: msg,
    style: {
      width: 600,
      marginLeft: 335 - 600,
      backgroundColor: "#9cd864",
      fontWeight: 'bold'
    },
  });
}
    render() {
      
      const boxShadows = {
        boxShadow:
          "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
    };
const {caseDetailsObj} = this.state;
let scheduleTitle = "", EmpInitial = "", printheader = "", OfficeId = "";
if(caseDetailsObj !== undefined)
{
  if(sessionStorage.getItem('userInfo')){
    EmpInitial = JSON.parse(sessionStorage.getItem('userInfo')).EmpInitial;
    OfficeId = JSON.parse(sessionStorage.getItem('userInfo')).OfficeId;
  scheduleTitle = "Case schedule detail for " + caseDetailsObj.CaseNumber;
}
  printheader = "LIC #: "+caseDetailsObj.DLNumber+"            UID: "+EmpInitial+"  Trans: DAD  Date: "+moment(Date.now()).format('MM-DD-YYYY hh:mm');
 }
let accidentsList = [];
if(this.state.customerD26Info !== undefined )
{ 
 accidentsList = getAccidentsList(this.state.customerD26Info);
}
let hearingTypesList = [], caseReasonsList = [], caseReferralsList = [], caseCertificationsList = [];
if(this.state.caseDetailsObj!== undefined && this.state.hearingTypes !== undefined )
{ 
  hearingTypesList = getDropdownList(this.state.hearingTypes, this.state.caseDetailsObj.CD_HRNG_TYP);    
}
if(this.state.caseDetailsObj!== undefined && this.state.caseReasons !== undefined)
{ 
  caseReasonsList = getDropdownList(this.state.caseReasons, this.state.caseDetailsObj.CD_RSN);    
}
if(this.state.caseDetailsObj!== undefined && this.state.caseReferrals !== undefined)
{ 
  caseReferralsList = getDropdownList(this.state.caseReferrals, this.state.caseDetailsObj.CD_REFR_SRCE_TYP);    
}
if(this.state.caseDetailsObj!== undefined && this.state.caseCertifications !== undefined)
{ 
  caseCertificationsList = getDropdownList(this.state.caseCertifications, "");    
}
let data= [];
if(this.state.caseComments !== undefined)
{
this.state.caseComments.Comments.map((item) => {
  data.push({
    DT_UPDT_TRANS:  moment( item.DT_UPDT_TRANS).format("MM-DD-YYYY HH:mm:ss"),
    NBR_COMM: item.NBR_COMM,
    TXT_COMM: item.TXT_COMM,
    EmployeeFullName: item.EmployeeFullName
  });
  return "";
});
}

const {caseScheduleData} = this.state;
const {scheddata} = this.state;
const {oipdata}= this.state; 
const {rescheddata} = this.state;
const {commentType} = this.state;

        return (  
           
      //     <ScrollPanel
      //     style={{
      //         width: "100%",
      //         height: "100%",
      //         backgroundColor: "rgba(0,0,0,0)"
      //     }}
      // >
      <React-Fragment>
       {(caseDetailsObj !== undefined && this.state.hearingTypes !== undefined && this.state.caseReasons !== undefined && this.state.caseReferrals !== undefined)  ? (caseDetailsObj.CaseNumber === this.props.match.params.CaseNumber ? (
          <div> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
        { caseDetailsObj.Customer && <div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}><Icon type="idcard"  style={{ fontSize: 32 }}/> 
            {this.props.location.state !== undefined ? <span onClick={(e) => {
              if(this.props.location.state.dlNumber !== undefined)
              {
                this.props.history.push(`/customerDetails/dlNumber/${this.props.location.state.dlNumber}`);
              }
else
{
  this.props.history.push(`/customerDetails/dlNumber/${this.state.caseDetailsObj.Customer.DLNumber}`);
}
            }} style={{paddingLeft: "1%", fontSize: "xx-large", cursor: "pointer"}}>{caseDetailsObj.Customer.LastName.replace(/\s/g,'')}{", "}{caseDetailsObj.Customer.FirstName.replace(/\s/g,'')}</span>
            : <span onClick={(e) => this.props.history.push(`/customerDetails/dlNumber/${this.state.caseDetailsObj.Customer.DLNumber}`)} style={{paddingLeft: "1%", fontSize: "xx-large", cursor: "pointer"}}>{caseDetailsObj.Customer.LastName},{caseDetailsObj.Customer.FirstName}</span>}
            {this.props.location.state !== undefined && this.props.location.state.caseStatus === undefined  ? <span style={{paddingLeft: "5%", fontSize: "x-large"}}>DL#: {this.props.location.state.dlNumber}</span>
            : <span style={{paddingLeft: "5%", fontSize: "x-large"}}>DL#: {this.state.caseDetailsObj.Customer.DLNumber}</span>}
            <span style={{paddingLeft: "5%", fontSize: "x-large"}}>Case#: {this.props.match.params.CaseNumber}</span>
        </div></div> }
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['CaseDetail']}
            defaultOpenKeys={['1']}
            selectedKeys={this.state.selectedKeys || "CaseDetail"}
            style={{ height: '100%' }}
            onClick={e => this.handleClick(e)}
          >
            <Menu.Item key="CaseDetail"> <Icon type="profile" />
              <span>Case Detail</span>
</Menu.Item>
<Menu.Item key="OIP">
<Icon type="team" />
              <span>OIP</span>
              {this.state.allOIPsforaCaseNumber !== undefined && <span style ={{paddingLeft: "5%"}} ><Badge showZero={true} count={this.state.oipCount} />  </span>}
</Menu.Item>
<Menu.Item key="Comments"> 
<Icon type="message" />
              <span>Comments</span>
             {this.state.caseComments !== undefined && <span style ={{paddingLeft: "5%"}} ><Badge showZero={true} count={this.state.caseComments.TotalComments} />  </span>}
</Menu.Item>
{this.state.caseDetailsObj.Scheduled === false && <Menu.Item key="Schedule">
<Icon type="schedule" />
              <span>Schedule</span>
</Menu.Item>}
{this.state.caseDetailsObj.Scheduled && <Menu.Item key="ReSchedule">
<Icon type="schedule" />
              <span>ReSchedule</span>
</Menu.Item>}{this.state.caseDetailsObj.Reconvene && <Menu.Item key="ReConvene">
<Icon type="interation" />
              <span>ReConvene</span>
</Menu.Item>}
<Menu.Item key="Closure">
<Icon type="book" />
              <span>Closure</span>
</Menu.Item>
<Menu.Item key="Suspense">
<Icon type="pause-circle" />
              <span>Suspense</span>
</Menu.Item>
<Menu.Item key="DadH6">
<Icon type="file-text" />
              <span>DAD H6</span>
</Menu.Item>
<Menu.Item key="PrintCoversheet"> 
<Icon type="printer" />
              <span>Print Cover Sheet</span>
</Menu.Item>
          </Menu>
        </Sider>
        <Content style={{height: "650px" }}>
        <Modal
        maskClosable={false}
          title="Success" 
          visible={this.state.openstatusModal} onCancel={(e)  => {this.props.getCaseDetails(this.state.caseNumber); this.setState({openstatusModal: false, selectedKeys: "CaseDetail", tabValue: "CaseDetail"})}}  footer = { [
            <div>
            <Button type="primary" key="Ok" onClick={(e)  => {this.props.getCaseDetails(this.state.caseNumber); this.props.getCaseInfo(this.state.caseNumber); this.props.getOffices(); this.setState({instance: Math.random(), openstatusModal: false, selectedKeys: "Schedule", tabValue: "Schedule"})}}>Yes</Button>
            <Button type="default" key="Cancel" onClick={(e)  => {this.props.getCaseDetails(this.state.caseNumber); this.setState({openstatusModal: false, selectedKeys: "CaseDetail", tabValue: "CaseDetail"})}}>No</Button>
            </div>
        ]}>Case has been unscheduled for {this.state.tabValue} successfully. Do you wish to schedule this case now? </Modal>
       {this.state.tabValue === 'CaseDetail' ? (<div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
       {this.state.caseErrorData !== undefined &&  <Modal
          title="ERROR" 
          visible={this.state.caseError} onCancel={this.handleError}  footer = { [
            <div>
            <Button type="primary" key="Ok" onClick={this.handleError}>Ok</Button>
            </div>
        ]}><font size="40px">{ this.state.caseErrorData.length > 0 &&  this.state.caseErrorData.map((item) => <div dangerouslySetInnerHTML={{ __html: item.toString()}}/>)} </font></Modal>}
       {this.state.caseDetailsObj.ErrorMessage !== null ?    <div style={{border: "solid", borderColor: "#c9e3fa", height: "200px"}}> 
               <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="exclamation-circle" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>ERROR</span><div dangerouslySetInnerHTML={{ __html: this.state.caseDetailsObj.ErrorMessage}}/><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Back')}>Go Back</Button></div></div>: 
               <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> 
               <div style={{
    justify: "center",
    height: "40px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 24 }}/> <span style={{fontSize: 24, paddingLeft: '0.5%'}}>Case Detail</span>
   {(this.state.caseDetailsObj.CaseStatusCode !== 'CL' && this.state.caseDetailsObj.CaseStatusCode !== 'UP') ?
  this.state.editmode === true ?(<span style={{float: "right", marginTop: "0.5%", marginRight: "3%"}}> <Button style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button> 
  {(this.state.isDirty === true)  ? <Button  style={{ color:  "white", backgroundColor: "green"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button>
  :<Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')} disabled>Save</Button> }</span>) :
 <Button style={{float: "right", marginTop: "0.5%", marginRight:"2%"}}type="primary" size={"small"} onClick={(e) => this.onButtonClick(e,'Edit')}>Edit</Button>
   :
  <span></span>
}
</div>
       <Row type="flex" justify="space-around" >
    <Col span = {6}>
    <div style={{paddingTop: "5px"}}>
           <b>Date of Birth</b>:
        <Input value={caseDetailsObj.Customer.DOB} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/>          
            </div>
            <div style={{paddingTop: "10px"}}>
   <b>DL Number</b>:
  <Input value={caseDetailsObj.Customer.DLNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}>
       <b>License Class</b>:
        <Input value={caseDetailsObj.Customer.classLicense} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            {/* // NOU - phone# readOnly issue 8/21/2019 /> */
            this.state.editmode === true ?
            <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input maxLength={10} onChange={e => this.handlePhoneChange(e) } style={{ width: '100%'}} />  
            </div>:
          <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input value={caseDetailsObj.Customer.PhoneNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/>  
            </div> 
         }
            <div style={{paddingTop: "10px"}}> <b>Mailing Address</b>:
        <TextArea rows="5" value={caseDetailsObj.Customer.MailingAddress} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
       </Col>
        <Col span = {6}>
        <div style={{paddingTop: "5px"}}> <b>Case Number</b>:
        <Input value={caseDetailsObj.CaseNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Received Date</b>:
        <Input value={caseDetailsObj.DateReceived} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>          
            <div style={{paddingTop: "10px"}}> <b>Case Status</b>:
        <Input value={caseDetailsObj.CaseStatus} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Hearing Type</b>:
        {this.state.editmode === true ?

          <Select id="htSelect" onChange={e => this.handleChange(e, 'HRNG_TYP')}  showSearch optionFilterProp= "children" filterOption = {true} onFocus={(e) => {document.getElementById("htSelect").click()}} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                 {hearingTypesList}
                              </Select> :
                              <Select id = "htSel" onFocus={(e) => {
                                document.getElementById("htSel").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  value={caseDetailsObj.CD_HRNG_TYP} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >        
                                {hearingTypesList}               
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Reason</b>:
        {this.state.editmode === true ?
          <Select id="csSelect" onChange={e => this.handleChange(e, 'CASE_RSN')} optionFilterProp= "children" filterOption = {true}  showSearch onFocus={(e) => {document.getElementById("csSelect").click()}} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseReasonsList}
                              </Select> :
                              <Select id = "csSel" onFocus={(e) => {
                                document.getElementById("SRea2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  value={caseDetailsObj.CD_RSN} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                              {caseReasonsList}
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Referral</b>:
        {this.state.editmode === true ?
        <Select id="crSelect" onChange={e => this.handleChange(e, 'CASE_RFL')} optionFilterProp= "children" filterOption = {true}  showArrow={true} size={"default"} showSearch onFocus={(e) => {document.getElementById("crSelect").click()}} style={{ width: '100%'}} >
                               {caseReferralsList}
                            </Select> :
                            <Select value={caseDetailsObj.CD_REFR_SRCE_TYP} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                            {caseReferralsList}
                            </Select>
        }
        </div>
       { reqRsnCodesForCerts.includes(this.state.caseReason) && <div style={{paddingTop: "10px"}}> <b>Special Cert/Endorsement</b>:
        {this.state.editmode === true ?
          <Select id="ccSelect" onChange={e => this.handleChange(e, 'CASE_CERT')} optionFilterProp= "children" filterOption = {true}  showSearch onFocus={(e) => {document.getElementById("ccSelect").click()}} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseCertificationsList}
                              </Select> :
                              <Select value={caseDetailsObj.CD_ENDR} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                              </Select>
          }
        </div>
       }
            </Col>
            <Col span ={6}>
            {(this.state.customerD26Info !== undefined && this.state.caseReason === "950") &&
             <div style={{ 
              width: "100%",
              height: "50%",
              marginTop: "30%",
               border: "1px solid #c9e3fa",
               borderRadius: "6px"
             }}>
    <div style={{height: "15%", backgroundColor: "#c9e3fa",textAlign: "center"}}><div style={{paddingTop: "1%"}}>FINANCIAL RESPONSIBILITIES:</div></div>
    <div style={{paddingTop: "1%", textAlign: "center"}}><b>List of Accidents:</b> </div>
    <div style={{paddingTop: "1%", paddingLeft: "10%"}}><span  style={{paddingTop: "1%", paddingLeft: "2%"}}><b>FR Case No.</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Accident Date</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Location</b></span></div>
    {this.state.customerD26Info.Accidents.length > 0 ?
    <div style={{paddingTop: "1%", paddingLeft: "2%", overflow:"scroll", height: "61%"}}>
     {this.state.editmode === false ? <RadioGroup name="AccidentsList" onChange={this.onChange} value={this.state.value} disabled>
        {accidentsList}
      </RadioGroup> :
      <RadioGroup name="AccidentsList" onChange={this.onChange} value={this.state.value}>
      {accidentsList}
    </RadioGroup>
    }
</div>
:
<div style={{paddingLeft: "25%"}}>{this.state.customerD26Info.AccidentMessage}</div>}

          </div>}
           </Col >
            </Row>     
            {(this.state.caseDetailsObj.CaseStatusCode === 'SC' || this.state.caseDetailsObj.CaseStatusCode === 'RS') &&  <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%",
    marginTop: "25px"
   }} >
   <Button style={{marginLeft: "45%", marginTop: "4px"}} type="primary" size={"small"} onClick={this.openCaseSchedule}><Icon type="calendar" style={{ fontSize: 16 , color: "white"}}/>Schedule Detail</Button> 
<Modal  maskClosable={false}   title={scheduleTitle}
          visible={this.state.caseSchedVisible}
          onCancel={this.handleCancel}
        
          footer = { [
            <Button type="primary" key="Ok" onClick={this.handleCancel}>Ok</Button>
        ]}
          width={'60%'}> 
          {caseScheduleData && 
 <div> <Row span = {32} gutter={16}>
<Col span = {12}> <div         
                                    style={{
                                    borderRadius: "8px",
                                    border: "solid",
                                    borderColor: "#c9e3fa", 
                                    ...boxShadows
                                    }}
                                >
<div   style={{
                                    backgroundColor: "#c9e3fa",
                                    borderRadius: "8px",
                                    ...boxShadows
                                    }}>Tracking Information</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Subject: </b>{caseScheduleData.CaseDetail.SubjectName}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>DL #: </b>{caseScheduleData.CaseDetail.DLNumber}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Type: </b>{caseScheduleData.CaseDetail.HearingType}</div>       
                                     <div style={{ paddingLeft: '5%'}}><b>Reason: </b>{caseScheduleData.CaseDetail.Reason}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Receipt Date: </b>{caseScheduleData.CaseDetail.ReceiptDate}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Other Interested Parties: </b></div>
                                     <div style={{ paddingLeft: '5%'}}><div style={{ backgroundColor: '#f2efef', marginRight: "5px", marginBottom: "5px", borderRadius: "8px"}}>   
                                     { oipdata && oipdata.length !== 0 ? <Table
                                 bordered = {false} 
                                 size = 'small'                           
                                 pagination = {false}
                                 columns={oipcolumns} 
                                 dataSource={oipdata}
                                 rowKey={record => record.OIPName}
                                 showHeader
                                /> : "No OIPs"}
                                </div></div>
                                </div>
                                </Col>
                                <Col span ={12}>
                                {scheddata !== undefined ? <div         
                                    style={{
                                    borderRadius: "8px",
                                    border: "solid",
                                    borderColor: "#c9e3fa", 
                                    ...boxShadows
                                    }}
                                >
 <div   style={{
                                    backgroundColor: "#c9e3fa",
                                    borderRadius: "8px",
                                    ...boxShadows
                                    }}>Scheduling Information</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled Date: </b>{scheddata.ScheduledDate}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled Time: </b>{scheddata.StartTime} to {scheddata.EndTime}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Hearing Officer: </b>{scheddata.SCHEDBY_NME_FRST_PRSN} {scheddata.SCHEDBY_NME_SRNME_PRSN} </div>
                                     <div style={{ paddingLeft: '5%'}}><b>Location: </b>{scheddata.Location}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled By: </b>{scheddata.ScheduledBy}</div>       
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled On: </b>{scheddata.ScheduledOn}</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Status: </b><font color="red">{scheddata.Status}</font></div>
                                  </div> :  <div         
                                    style={{
                                    borderRadius: "8px",
                                    border: "solid",
                                    borderColor: "#c9e3fa", 
                                    ...boxShadows
                                    }}
                                >
 <div   style={{
                                    backgroundColor: "#c9e3fa",
                                    borderRadius: "8px",
                                    ...boxShadows
                                    }}>Scheduling Information</div>
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled Date: </b></div>
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled Time: </b></div>
                                     <div style={{ paddingLeft: '5%'}}><b>Hearing Officer: </b></div>
                                     <div style={{ paddingLeft: '5%'}}><b>Location: </b></div>
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled By: </b></div>       
                                     <div style={{ paddingLeft: '5%'}}><b>Scheduled On: </b></div>
                                     <div style={{ paddingLeft: '5%'}}><b>Status: </b></div>
                                  </div> }
                                  </Col>
    </Row>
    <Row style={{marginTop: "24px"}}>  <div
                                    style={{
                                    borderRadius: "8px",
                                    border: "solid",
                                    borderColor: "#c9e3fa", 
                                    ...boxShadows
                                    }}
                                >
                                    <div   style={{
                                    backgroundColor: "#c9e3fa",
                                    borderRadius: "8px",
                                    ...boxShadows
                                    }}>Reschedule Information</div>
                               {rescheddata && rescheddata.length !== 0 ? <Table
                                 bordered = {false} 
                                 size = 'small'                           
                                 pagination = {false}
                                 columns={reschedcolumns} 
                                 dataSource={rescheddata}
                                 rowKey={record => record.ScheduleTime}
                                 showHeader
                                /> : "No Reschedules"
                                  }
                                     </div>
                                     </Row>
                                     </div>
          }
           </Modal>
</div> }
            </div>}
  </div> ): ( this.state.tabValue === 'OIP' ? <div style={{marginLeft: "1%", marginTop: "0.5%", border: "solid", borderColor: "#c9e3fa", width: "98%"}}> <CaseOIPDetails
  getOIPLookUpResults = {this.getOIPLookUpResults}
  deleteOIP = {this.deleteOIP}
  resetlookup = {(e) => {
    this.setState({OIPLookupResults: undefined});
  }}
  removeOIP = {this.removeOIP}
  handleSave = {this.handleSave}
  OIPLookupResults = {this.state.OIPLookupResults}
  assignOIP = {this.assignOIP}
    allOIPsforaCaseNumber={this.state.allOIPsforaCaseNumber}
    OIPlanguagesData={this.state.OIPlanguagesData}      
    OIPTypesListData={this.state.OIPTypesListData}     
  ></CaseOIPDetails> {this.state.caseErrorData !== undefined &&  <Modal
    title="ERROR" 
    visible={this.state.caseError} onCancel={this.handleError}  footer = { [
      <div>
      <Button type="primary" key="Ok" onClick={this.handleError}>Ok</Button>
      </div>
       ]}><font size="40px">{ this.state.caseErrorData.length > 0 &&  this.state.caseErrorData.map((item, index) => <div key={index} style={{color: 'red'}}>{item}</div>)} </font></Modal>}</div> :

(
       this.state.tabValue === 'DadH6' ? <div>
         <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>  <div style={{border: "solid", borderColor: "#c9e3fa"}}> 
<div style={{
justify: "center",
height: "40px",
backgroundColor: "#c9e3fa",
paddingLeft: "1%"
}} ><Icon type="profile" style={{ fontSize: 24 }} /> <span style={{fontSize: 24, paddingLeft: '0.5%'}}>DAD H6 Information</span></div>{this.state.h6Info !== undefined ? <div>{(this.state.h6Info.length > 0) ?   <div>
<Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print('printareaH6','H6ifmcontentstoprint')}><Icon type="printer" theme="outlined" />Print this page</Button> <ScrollPanel  style={{
              height: "500px"
          }}>      <div id='printareaH6'> 
                   <iframe title="H6ifmcontentstoprint" id="H6ifmcontentstoprint" style={{
                        height: '0px',
                        width: '0px',
                        position: 'absolute'
                    }}></iframe>   
 <title>
  {printheader}
 </title> 
<pre> 
  <div dangerouslySetInnerHTML={{ __html: this.state.h6Info.toString()}}/>
  </pre> 
          </div></ScrollPanel></div>:
          <div>No DAD H6 info found.</div>
}</div>:<div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}</div></div></div> : <div>
{this.state.tabValue === 'Comments' ?  <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>  <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> 
<div style={{
justify: "center",
height: "40px",
backgroundColor: "#c9e3fa",
paddingLeft: "1%"
}} ><Icon type="message" style={{ fontSize: 24 }} /> <span style={{fontSize: 24, paddingLeft: '0.5%'}}>Comments</span><Button style={{marginLeft: "65%", color: "white", backgroundColor: "green"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'New')}><Icon type="plus-square"></Icon>New Comment</Button></div>
<Modal  maskClosable={false}   title="New Case Comment"
          visible={this.state.newCommModal}
          onCancel={this.handleCancelComm}    
          footer = { [
            <div>
            <Button style={{ color:  "white", backgroundColor: "red"}} type="default" key="Cancel" onClick={this.handleCancelComm}>Cancel</Button>
          {this.state.commentType === "C" ?( (this.state.commentValue.length > 0 ) ? <Button style={{ color:  "white", backgroundColor: "green"}} type="default" key="Ok" onClick={this.handleOk}>Save</Button> : <Button type="default" key="Ok" disabled>Save</Button>) :
 ( (this.state.commentValue.length > 0 && this.state.commentNumber.length > 0 && this.state.purgeDate.length > 0 ) ? <Button style={{ color:  "white", backgroundColor: "green"}} type="default" key="Ok" onClick={this.handleOk}>Save</Button> : <Button type="default" key="Ok" disabled>Save</Button> )}
            </div>
        ]}
          width={'60%'}> 
<div><RadioGroup name="commentType" value={this.state.commentType} onChange ={this.onCommentTypeChange}>
                                <Radio value={"C"}>Case Only</Radio>
                                <Radio value={"CD"}>Case and DL</Radio>
                                <Radio value={"D"}>DL Only</Radio>
                              </RadioGroup>
                              </div>
                              {commentType === "C" && <div style={{marginTop: "2%"}}>
                              <TextArea value={this.state.commentValue} rows="5" placeholder="Enter a comment" maxLength="250" style={{ width: '100%'}} onChange={this.onCommentTextChange}/> <div>
                              {250 - this.state.commentValue.length}/250</div>
                              </div>}
                              {(commentType === "CD" || commentType === "D") && <div style={{marginTop: "2%"}}>
                              <div><span><b>Comment Number:</b></span><Tooltip
        trigger={['focus']}
        title="Input a number"
        placement="topLeft"
      ><Input value={this.state.commentNumber} onChange={this.onCommentNumberChange} style={{width:"20%"}}/></Tooltip><span><b>Purge Date (ex 12-19):</b></span><Tooltip
      title="Input a date after 11-19"
      placement="topLeft"
    >
      <MonthPicker onChange={this.onPurgeDateChange} style={{width:"20%"}} placeholder="mm-yy" format={monthFormat} />
    </Tooltip></div>
                              <TextArea value={this.state.commentValue} rows="5" placeholder="Enter a comment" maxLength="63" style={{ width: '100%'}} onChange={this.onCommentTextChange}/> <div>
    {63 - this.state.commentValue.length}/63</div>
                              </div>}
                             
          </Modal>
        {this.state.caseErrorData !== undefined &&  <Modal
          title="ERROR" 
          visible={this.state.caseError} onCancel={this.handleError}  footer = { [
            <div>
            <Button type="primary" key="Ok" onClick={this.handleError}>Ok</Button>
            </div>
        ]}><font size="40px">{ this.state.caseErrorData.length > 0 &&  this.state.caseErrorData.map((item) => <div dangerouslySetInnerHTML={{ __html: item.toString()}}/>)} </font></Modal>}
  
 {this.state.caseComments.Comments.length !== 0 ? <List
    dataSource={data}
    pagination={{pageSize: 5}}
    renderItem={item => (
      <List.Item key={item.NBR_COMM}>
        <List.Item.Meta
          title={<div style={{fontSize:16,  display: "inline-block", width: "100%"}}><div style={{float:"left", width: "5%"}}>{item.NBR_COMM}-</div><div  style={{float:"left", width: "85%"}}>{item.TXT_COMM}</div></div>}
          description={<div style={{paddingLeft:"5%", fontSize:12}}><span style={{fontWeight: "bold"}}>Posted On:</span><span style={{marginLeft: "10px"}}>{item.DT_UPDT_TRANS}</span><span style={{fontWeight: "bold", marginLeft: "30px"}}>Author:</span><span style={{marginLeft: "10px"}}>{item.EmployeeFullName}</span></div>}       
        />
        <Tooltip
        title="Delete Comment"
        placement="topLeft"
      ><span style={{ marginRight: "5%", paddingLeft: "5px", cursor: "pointer"}} onClick={(e) => this.openDelConf(item.NBR_COMM)}><Icon type="delete" style={{fontSize: 16, color: "red"}}/></span></Tooltip>
      </List.Item>
    )}
  /> : <div style={{paddingLeft: "45%",paddingTop: "10%"}}><h1>No comments on this case.</h1></div>
  }
  <Modal maskClosable={false} visible={this.state.openDelConf}
  onCancel={this.closeDelConf}
  footer = { [
    <div>
       <Button style={{ color:  "white", backgroundColor: "red"}} type="default" key="Cancel" onClick={this.closeDelConf}>No</Button>
      <Button style={{ color:  "white", backgroundColor: "green"}} type="default" key="Ok" onClick={this.handleDelete}>Yes</Button>
    </div>
]}
  >
  Do you want to delete the comment #{this.state.commentNumber}?
  </Modal>
</div></div>:this.state.tabValue === "Suspense" ?
 <div style={{marginLeft: "2%", width: "95%"}}>{this.state.caseSuspenseDetails && this.state.caseSuspenseDetails.Suspense !== undefined && <CaseSuspense handleSuspenseSave={this.handleSuspenseSave} caseSuspenseDetails={this.state.caseSuspenseDetails} handleDeleteSuspense={this.handleDeleteSuspense} caseSuspenseReasonsList={this.state.caseSuspenseReasons} employeesForOfficeList={this.state.employeesForOffice}></CaseSuspense>}</div>
 :<div>  {
this.state.tabValue === "Schedule" ? <CaseSchedule key={this.state.instance} type={'casedetail'} uponSchedule={(e) => {this.setState({tabValue:"CaseDetail"});this.props.getCaseDetails(this.state.caseNumber)}} goToDUX={(DLNumber) => {  this.props.history.push(`/duxUpdate/DLNumber/${DLNumber}`);}} scheduleObj={this.state.scheduleObj} selectedOfficeId={OfficeId} timeSearchText={"Find Available Time Slots"} caseInfo={this.state.caseInfo} selectedCase={this.state.caseNumber}></CaseSchedule> : 
<div>{(this.state.tabValue === "ReSchedule" || this.state.tabValue === "ReConvene") && this.state.rsrcdataObj ? <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}><CaseReSchedReConv handleCancel={(e) => {this.setState({tabValue: 'CaseDetail', rsrcdataObj: undefined, selectedKeys: 'CaseDetail'})}} handleOk={(obj) => {this.props.updateRSRCCase(this.state.tabValue, obj)}} rsrcdataObj={this.state.rsrcdataObj} type={this.state.tabValue}></CaseReSchedReConv></div>:  this.state.tabValue ===  'PrintCoversheet' ? <div> <Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print('printareaCS','CSifmcontentstoprint')}><Icon type="printer" theme="outlined" />Print this page</Button>
  <ScrollPanel style={{height: "500px"}}>
  <div id='printareaCS'> 
                   <iframe title="CSifmcontentstoprint" id="CSifmcontentstoprint" style={{
                        height: '0px',
                        width: '0px',
                        position: 'absolute'
                    }}></iframe>   
  <div style={{width: "90%"}}>
  <ComponentToPrint caseNumber={this.state.caseNumber} coversheetJson={this.state.caseCoverSheetObj} />
  </div>
          </div>
 </ScrollPanel></div> : <div> <span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>} </div>}</div>}
{this.state.caseErrorData !== undefined &&  <Modal
          title="ERROR" 
          visible={this.state.caseError} onCancel={this.handleError}  footer = { [
            <div>
            <Button type="primary" key="Ok" onClick={this.handleError}>Ok</Button>
            </div>
        ]}><font size="40px" color="red">{ this.state.caseErrorData.length > 0 &&  this.state.caseErrorData.map((item) => <div dangerouslySetInnerHTML={{ __html: item.toString()}}/>)} </font></Modal>}

       </div>
))
       }
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    <Modal maskClosable={false} visible={this.state.open}
  onCancel={(e) => {this.setState({open: false});}}
  footer = { [
    <div>
       <Button style={{ color:  "white", backgroundColor: "red"}} type="default" key="Cancel" onClick={(e) => {this.setState({open: false});}}>No</Button>
      <Button style={{ color:  "white", backgroundColor: "green"}} type="default" key="Ok" onClick={(e) => {
    
        this.setState({printModalOpen: true, open: false});
    this.props.getCaseCoverSheet(this.state.caseNumber);}}>Yes</Button>
    </div>
]}>{this.state.printModalMsg !== undefined && this.state.printModalMsg}</Modal>
    </Row>
    </div>
       ):(<div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>)): <div style={{marginTop: "10%" }}><span style={{ paddingLeft: "40%"}}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
    {/* </ScrollPanel> */}
    </React-Fragment>
); 
    }
}

const mapStateToProps = state => {
    return {
       cases: state.cases,
       caseScheduling: state.caseScheduling,
       dataManager: state.dataManager
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
          getCaseDetails,
          getCaseCertifications,
          getCaseReasons,
          getCaseReferrals,
          getHearingTypes,
          getCustomerD26Info,
          modifyCaseDetail,
          getH6Info,
          getCaseComments,
          getCaseScheduleDetail,
          addCaseComment,
          deleteCaseComment,
          getAllOIPsforCase, getOIPTypesList, getOIPLanguages,
          getOIPLookUpResults,
          deleteOIP,
          updateOIP,
          saveNewOIP,
          removeOIP,
          assignOIP,
          getCaseCoverSheet,
          getCaseSuspenseDetails,
          getCaseSuspenseReasons,
          addCaseSuspense, 
          modifyCaseSuspense,
          deleteCaseSuspense,
          getCaseInfo,
          getOffices,
          initRSRCCaseData,
          updateRSRCCase,
          getEmployeesForOffice
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CaseDetails);