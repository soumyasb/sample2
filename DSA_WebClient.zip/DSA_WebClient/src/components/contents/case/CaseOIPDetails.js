import React, { Component } from 'react';
import { Badge, Row, Col, Collapse, Input, Button, Select, Menu, Icon } from 'antd';
import cloneDeep from 'lodash/cloneDeep';

const { Option } = Select;
const { TextArea } = Input;
const { Panel } = Collapse;

const newOIPItemObj = {
    detailsDisplayed: [
        "NME_AGENCY",
        "NBR_PHONE",
        "NBR_CELL_PHONE",
        "NBR_FAX"
    ],
    detailsCleanNames: [
        "Agency Name",
        "Phone Number",
        "Cell Number",
        "Fax Number"
    ],
    OIPID: 0,
    NbrOIP: null,
    CDUPDTTECHID: null,
    NMEFRSTPRSN: null,
    NMESURNMEPRSN: null,
    NMEMIDPRSN: null,
    NMESUFXPRSN: null,
    NBRPHONE: null,
    NBRCELLPHONE: null,
    NBRFAX: null,
    EmailAddress: null,
    ADDRLN1: null,
    CDCITY: null,
    CDSTATE: null,
    CDZIP: null,
    NMEAGENCY: null,
    TXTCOMM: null,
    CDPRTYTYP: null,
    DESCPRTYTYP: null,
    CdCase: null,
    CDLANGUAGE: null,
}

const newLookupObj = {
    NMEFRSTPRSN: null,
    NMESURNMEPRSN: null,
    NMEMIDPRSN: null,
    NMESUFXPRSN: null,
    NBRPHONE: null,
    NBRCELLPHONE: null,
    NBRFAX: null,
    EmailAddress: null,
    ADDRLN1: null,
    CDCITY: null,
    CDSTATE: null,
    CDZIP: null,
    NMEAGENCY: null,
    TXTCOMM: null,
    CDPRTYTYP: null,
    DESCPRTYTYP: null,
    CdCase: null,
    CDLANGUAGE: null,
}

const getDropdownList = (listObj, selectedValue) => {
    let list = listObj.map(item => {
        if (item.Value !== "") {
            if (item.Value === selectedValue) {
                return <Option key={item.Value} value={item.Value} selected>{item.Text}</Option>;
            }
            return <Option key={item.Value} value={item.Value}>{item.Text}</Option>;
        }
        return "";
    });
    return list;
}

class CaseOIPDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
           allOIPsforaCaseNumber: this.props.allOIPsforaCaseNumber,
           oiplookupresults: this.props.OIPLookupResults,
           oipItemObj: this.props.allOIPsforaCaseNumber[0],
           OIPlanguagesData: this.props.OIPlanguagesData,
           OIPTypesListData: this.props.OIPTypesListData,
           oipLookupItemObj: cloneDeep(newLookupObj),
            disableNewButton: false,
            displayViewList: true,
            editMode: false,
            enableSearchButton: false
        }

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleListMenuChange = this.handleListMenuChange.bind(this);
        this.handleNewOIP = this.handleNewOIP.bind(this);
        this.handleViewList = this.handleViewList.bind(this);
        this.handleLookupExisting = this.handleLookupExisting.bind(this);
        this.handleAssignToCase = this.handleAssignToCase.bind(this); 
           this.handleEditModeAndCancel = this.handleEditModeAndCancel.bind(this); 
           this.handleDelete = this.handleDelete.bind(this); 
           this.handleLookupFieldChange = this.handleLookupFieldChange.bind(this); 
           this.handleLookupReset = this.handleLookupReset.bind(this); 
         this.handleLookupSearch = this.handleLookupSearch.bind(this); 
         this.handleSave = this.handleSave.bind(this);

    }

    componentDidUpdate(prevProps) {
    
        if ( prevProps.allOIPsforaCaseNumber !== this.props.allOIPsforaCaseNumber ) {
            let count = 0;
 this.props.allOIPsforaCaseNumber.map((i) => {if(i.OIPID === this.state.selectedOIP){
     count++;
 }
 return "";
});
           if(count === 0)
           {
            this.setState({allOIPsforaCaseNumber: this.props.allOIPsforaCaseNumber, oipItemObj: this.props.allOIPsforaCaseNumber[0], editMode: false,   disableNewButton: false});
           }
           else
           {
            this.setState({allOIPsforaCaseNumber: this.props.allOIPsforaCaseNumber, oipItemObj: this.props.allOIPsforaCaseNumber.find((i) => i.OIPID === this.state.selectedOIP), editMode: false,   disableNewButton: false});
           }
    }
    }

    handleLookupExisting() {
        this.setState({ displayViewList: false, disableNewButton: true });
    }

    handleSave() {
    
        this.props.handleSave(this.state.oipItemObj);
    }

    handleViewList() {
        this.setState({ displayViewList: true, disableNewButton: false  });
    }
    handleAssignToCase(oipid, oiptype) { 
                this.props.assignOIP(oipid, oiptype);
        }     
      
    handleNewOIP() {
        const { allOIPsforaCaseNumber } = this.state;

        allOIPsforaCaseNumber.unshift(newOIPItemObj);
        this.setState({
            allOIPsforaCaseNumber,
            disableNewButton: true,
            oipItemObj: cloneDeep(newOIPItemObj),
            editMode: true
        });
    }

    handleListMenuChange(e) {
        const oipItemObj = this.state.allOIPsforaCaseNumber.find(i => i.OIPID === parseInt(e.key, 10));
        this.setState({ oipItemObj: oipItemObj, selectedOIP: oipItemObj.OIPID});
    }

    handleFieldChange(e, type) {
        const { oipItemObj } = this.state;

        switch (type) {
            case 'CDPRTYTYP':
            case 'CDLANGUAGE':
            if(!e)
            {
                oipItemObj[type] = '';
            }
            else
            {
                oipItemObj[type] = e;
            }
                break;
            case 'NMEFRSTPRSN':
            case 'NMESURNMEPRSN':
            case 'NMEMIDPRSN':
            case 'NMESUFXPRSN':
            case 'NMEAGENCY':
            case 'NBRPHONE':
            case 'NBRCELLPHONE':
            case 'NBRFAX':
            case 'EmailAddress':
            case 'ADDRLN1':
            case 'CDCITY':
            case 'CDSTATE':
            case 'CDZIP':
            case 'TXTCOMM':
            case 'DESCPRTYTYP':
            case 'CdCase':
                oipItemObj[type] = e.target.value;
                break;
            default:
                break;
        }

        this.setState({ oipItemObj });
    }
    handleDelete(oipid, type, cdprtytyp) { 
        this.setState({disableNewButton: false, editMode: false});
             this.props.deleteOIP(this.state.oipItemObj.OIPID, type, cdprtytyp);
             } 
          
    handleEditModeAndCancel() { 
                if(this.state.disableNewButton === true)
                {
                    const { allOIPsforaCaseNumber } = this.state;

                    allOIPsforaCaseNumber.shift();
                    this.setState({
                        allOIPsforaCaseNumber,
                        disableNewButton: false,
                        oipItemObj: allOIPsforaCaseNumber[0],
                        editMode: false
                    });
                }
                else
                {
                    this.setState((state) => ({ editMode: !state.editMode })); 
                }
            } 
      
    renderLeftNavOIPs() {
        const { allOIPsforaCaseNumber, oipItemObj } = this.state;

        const menuItems = allOIPsforaCaseNumber.map(item => {
            const menuText = (item.NMEFRSTPRSN && item.NMESURNMEPRSN) ? `${item.NMEFRSTPRSN} ${item.NMESURNMEPRSN}` : (item.NMEAGENCY) ? `${item.NMEAGENCY}` : 'New OIP';
            return <Menu.Item key={item.OIPID} value={item.OIPID}><div style={{width: '100%'}}><span style={{float: 'left'}}>{menuText}</span><span style={{float: 'right'}}><Badge style={{ backgroundColor: 'blue'}} count={item.CDPRTYTYP} /></span></div></Menu.Item>;
        });

        return (<Col style={{width: '25%', paddingRight: "15px" }}>
        {this.state.allOIPsforaCaseNumber && this.state.allOIPsforaCaseNumber.length > 0 &&
            <Menu
                mode="inline"
                defaultSelectedKeys={[allOIPsforaCaseNumber[0].OIPID.toString()]}
                style={{ height: '100%' }}
                onClick={this.handleListMenuChange}
                selectedKeys={[oipItemObj.OIPID.toString()]}
            >
                {menuItems}
            </Menu>
        }
        </Col>);
    }

    renderDetails() {
        const oiptypesList = getDropdownList(this.state.OIPTypesListData);
        const oiplanguagesList = getDropdownList(this.state.OIPlanguagesData);

        const { oipItemObj, editMode, disableNewButton } = this.state;

        if(oipItemObj)
        {
        const { OIPID, NMEFRSTPRSN, NMESURNMEPRSN,
            NMEMIDPRSN, NMESUFXPRSN, NBRPHONE, NBRCELLPHONE, NBRFAX,
            EmailAddress, ADDRLN1, CDCITY, CDSTATE, CDZIP, NMEAGENCY,
            TXTCOMM, CDPRTYTYP, CDLANGUAGE, Languages
        } = oipItemObj;
    
        return (<Col style={{ width: '75%', padding: "15px" }}>
            <Row>
                <div style={{ paddingTop: "15px", paddingBottom: "15px" }}>
                    <Col span={5}>
                        <b>OIP Type </b>:
                        <Select allowClear={true} id = "OT" onFocus={(e) => {
                                document.getElementById("OT").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Select an Option" onChange={e => this.handleFieldChange(e, 'CDPRTYTYP')} value={CDPRTYTYP} disabled={!disableNewButton}
                            showArrow={true} size={"default"} style={{ width: '100%' }}>
                            {oiptypesList}
                        </Select>
                    </Col>
                    <Col span={1} />
                    <Col span={7}>
                        <b>NME_AGENCY </b>: <Input placeholder="" value={NMEAGENCY}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'NMEAGENCY')} />
                    </Col>
                    <Col span={1} />
                    {(CDPRTYTYP === 'M' || CDPRTYTYP === 'N') && editMode && <Col span={5}>
                        <b>Language </b>:
                        <Select allowClear =  {true} id = "Lan" onFocus={(e) => {
                                document.getElementById("Lan").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleFieldChange(e, 'CDLANGUAGE')} value={CDLANGUAGE}
                          disabled={!editMode}  showArrow={true} size={"default"} style={{ width: '100%' }}>
                            {oiplanguagesList}
                        </Select>
                    </Col>}
                    <Col span={2} />
                </div>
            </Row>
            <Row>
              {(CDPRTYTYP === 'N' || CDPRTYTYP === 'L') ? <div></div>:<div style={{ paddingTop: "15px", paddingBottom: "15px" }}>
                    <Col span={5}>
                        <b>Last Name </b>: <Input placeholder="" value={NMESURNMEPRSN}
                        disabled={!editMode}    onChange={e => this.handleFieldChange(e, 'NMESURNMEPRSN')} />
                    </Col>
                    <Col span={1} />
                    <Col span={5}>
                        <b>First Name </b>: <Input placeholder="" value={NMEFRSTPRSN}
                       disabled={!editMode}     onChange={e => this.handleFieldChange(e, 'NMEFRSTPRSN')} />
                    </Col>
                    <Col span={1} />
                    <Col span={5}>
                        <b>Middle Name </b>: <Input placeholder="" value={NMEMIDPRSN}
                       disabled={!editMode}     onChange={e => this.handleFieldChange(e, 'NMEMIDPRSN')} />
                    </Col>
                    <Col span={1} />
                    <Col span={5}>
                        <b>Suffix </b>: <Input placeholder="" value={NMESUFXPRSN}
                         disabled={!editMode}   onChange={e => this.handleFieldChange(e, 'NMESUFXPRSN')} />
                    </Col>
                </div>}
            </Row>
            <Row>
                <div style={{ paddingTop: "15px", paddingBottom: "15px" }}>
                    <Col span={5}>
                        <b>Phone Number </b>: <Input placeholder="" value={NBRPHONE}
                         disabled={!editMode}   onChange={e => this.handleFieldChange(e, 'NBRPHONE')} />
                    </Col>
                    <Col span={1} />
                    <Col span={5}>
                        <b>Cell Phone Number </b>: <Input placeholder="" value={NBRCELLPHONE}
                         disabled={!editMode}   onChange={e => this.handleFieldChange(e, 'NBRCELLPHONE')} />
                    </Col>
                    <Col span={1} />
                    <Col span={5}>
                        <b>Fax Number </b>: <Input placeholder="" value={NBRFAX}
                         disabled={!editMode}   onChange={e => this.handleFieldChange(e, 'NBRFAX')} />
                    </Col>
                    <Col span={1} />
                    <Col span={5}>
                        <b>Email Address </b>: <Input placeholder="" value={EmailAddress}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'EmailAddress')} />
                    </Col>
                </div>
            </Row>
            <Row>
                <div style={{ paddingTop: "15px", paddingBottom: "15px" }}>
                    <Col span={8}>
                        <b>Mailing Address </b>: <Input placeholder="" value={ADDRLN1}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'ADDRLN1')} />
                    </Col>
                </div>
            </Row>
            <Row>
                <div style={{ paddingTop: "15px", paddingBottom: "15px" }}>
                    <Col span={5}>
                        <b>City </b>: <Input placeholder="" value={CDCITY}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'CDCITY')} />
                    </Col>
                    <Col span={1} />
                    <Col span={2}>
                        <b>State </b>: <Input placeholder="" value={CDSTATE}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'CDSTATE')} />
                    </Col>
                    <Col span={1} />
                    <Col span={3}>
                        <b>Zip </b>: <Input placeholder="" value={CDZIP}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'CDZIP')} />
                    </Col>
                    <Col span={1} />
                </div>
            </Row>
            <Row>
                <div style={{ paddingTop: "15px", paddingBottom: "15px" }}>
                    <Col span={7}>
                        <b>Comment </b>: <TextArea rows={5} placeholder="" value={TXTCOMM}
                          disabled={!editMode}  onChange={e => this.handleFieldChange(e, 'TXTCOMM')} />
                    </Col>
                    <Col span={1} />
                  {Languages &&  <Col span={7}>
    <b>List of Languages </b>: <div style={{border: "1px solid #d9d9d9", height: "130px", overflow: "scroll", overflowX: "hidden"}}><ul>{Languages.map((item) => <li key={item.CDLanguage}>{item.LanguageDescription}</li>)}</ul></div>
                    </Col>}
                </div>
            </Row>
            <br />
            <Row>
                

              {editMode ?  <div>
                <Button style={{ backgroundColor: 'red', color: 'white', float: 'right' }} onClick={this.handleEditModeAndCancel} disabled={!editMode}> <Icon type="close" theme="outlined" /> Cancel
                </Button><Button style={{ backgroundColor: 'green', color: 'white', float: 'right' }} onClick={this.handleSave} disabled={!editMode}> <Icon type="save" theme="outlined" /> Save
                </Button></div>:
                <div><Button style={{ backgroundColor: 'red', color: 'white' }}  onClick={(e) => this.handleDelete(OIPID,'delete',CDPRTYTYP)} ><Icon type="delete" theme="outlined"/>Delete</Button>
                              <Button style={{ backgroundColor: 'red', color: 'white', float: 'right' }} onClick={(e) => this.handleDelete(OIPID,'remove',CDPRTYTYP)}>
                              <Icon type="close" theme="outlined" />Remove
                          </Button>
                <Button style={{ float: 'right' }} onClick={this.handleEditModeAndCancel} >
                    <Icon type="edit" theme="outlined" />Edit
                </Button></div>
              }
            </Row>
        </Col>);
    }
}

    renderLookupExisiting() {
    
        const  oiplookupresults  = this.props.OIPLookupResults;
        let oipids = [];
        this.state.allOIPsforaCaseNumber.map((item) => {oipids.push(item.OIPID);
            return "";});
      if(oiplookupresults !== undefined) {
        return (
            <div style={{height: '90%'}}>
                <div>{oiplookupresults.length} results found.</div>
                <div>
            <Collapse accordion>
                {
                 oiplookupresults.map(res => {
                        const header = <div>
                            {(res.CDPRTYTYP === 'L' || res.CDPRTYTYP === 'N') ? <span>{`${res.NMEAGENCY}`}</span>:<span>{`${res.NMEFRSTPRSN} ${res.NMESURNMEPRSN}`}</span>}
                            {oipids.includes(res.OIPID) ?  <div style={{ float: 'right', marginRight: '20px', color: 'green' }}>
                            <a onClick={(e) => this.handleAssignToCase(res.OIPID, res.CDPRTYTYP)}>
                                <Icon type="check" theme="outlined" />Assigned
                            </a>
                        </div> :
                            <div style={{ float: 'right', marginRight: '20px', color: 'blue' }}>
                                <a onClick={(e) => this.handleAssignToCase(res.OIPID, res.CDPRTYTYP)}>
                                    <Icon type="link" theme="outlined" />Assign to Case
                                </a>
                            </div>
                           }
                        </div>;
                        return (<Panel header={header} key={res.OIPID}>
                            <p>{`${res.ADDRLN1} ${res.CDCITY}, ${res.CDSTATE} ${res.CDZIP}`}</p>
                            {res.NBRPHONE && <p>{`Phone Number: ${res.NBRPHONE}`}</p>}
                            {res.NBRCELLPHONE && <p>{`Cell Phone Number: ${res.NBRCELLPHONE || ''}`}</p>}
                            {res.EmailAddress && <p>{`Email Address: ${res.EmailAddress || ''}`}</p>}
                        </Panel>);
                    })
                }
            </Collapse>
            </div>
            </div>
        );
    }
    }

    handleLookupFieldChange(e, type) {
    
        const { oipLookupItemObj } = this.state;

        switch (type) {
            case 'CDPRTYTYP':
            case 'CDLANGUAGE':
                oipLookupItemObj[type] = e
                break;
            case 'NMEFRSTPRSN':
            case 'NMESURNMEPRSN':
            case 'NMEAGENCY':
            case 'NBRPHONE':
                oipLookupItemObj[type] = e.target.value;
                break;
            default:
                break;
        }
       if(oipLookupItemObj['CDPRTYTYP'] !== 'N' && oipLookupItemObj['CDPRTYTYP'] !== 'M' && oipLookupItemObj['CDPRTYTYP'] !== 'L') 
       {if((oipLookupItemObj['NMEFRSTPRSN'] === null || oipLookupItemObj['NMEFRSTPRSN'] === "") && (oipLookupItemObj['NMESURNMEPRSN'] === null || oipLookupItemObj['NMESURNMEPRSN'] === "") )
       { this.setState({ enableSearchButton: false});}
        else
       {  this.setState({ oipLookupItemObj: oipLookupItemObj, enableSearchButton: true });
    }
    }
    else if(oipLookupItemObj['CDPRTYTYP'] === 'L')
    {
        if(oipLookupItemObj['NMEAGENCY'] === null || oipLookupItemObj['NMEAGENCY'] === "")
        {
            this.setState({ enableSearchButton: false});
        }
        else
        {  this.setState({ oipLookupItemObj: oipLookupItemObj, enableSearchButton: true });
    }
     }

     else
     {
        if(oipLookupItemObj['CDLANGUAGE'] !== null && oipLookupItemObj['CDLANGUAGE'] !== "")
        {
            this.setState({ oipLookupItemObj: oipLookupItemObj, enableSearchButton: true });
        }
        else
        { 
            this.setState({ enableSearchButton: false});
         }
    }
    }

    handleLookupReset() {
        const oipLookupItemObj = cloneDeep({ ...newLookupObj });
        this.props.resetlookup();
        this.setState({ oipLookupItemObj, oiplookupresults: [] });
    }

    handleLookupSearch() {
        let { oipLookupItemObj, oiplookupresults } = this.state;
        this.setState({ oipLookupItemObj, oiplookupresults })
    
    this.props.getOIPLookUpResults(oipLookupItemObj);
    }
    render() {
        const { disableNewButton, displayViewList, oipLookupItemObj, OIPTypesListData, OIPlanguagesData, enableSearchButton } = this.state; 
        const oiptypesList = getDropdownList(OIPTypesListData); 
        const oiplanguagesList = getDropdownList(OIPlanguagesData); 

        return (
            <div>
                 <div style={{
    justify: "center",
    height: "40px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="team" style={{ fontSize: 24 }}/> <span style={{fontSize: 24, paddingLeft: '0.5%'}}>OIP</span>

                  <span style={{float: "right"}}>  <Button onClick={this.handleViewList}><Icon type="bars" theme="outlined" />View List </Button>
                    <Button type={"primary"} onClick={this.handleLookupExisting}><Icon type="search" theme="outlined" />Lookup Existing </Button>
{disableNewButton ? <Button disabled onClick={this.handleNewOIP}><Icon type="plus" theme="outlined" />New OIP </Button> : <Button style={{ backgroundColor: 'green', color: 'white' }} onClick={this.handleNewOIP}> + New OIP </Button>}</span></div>
              {this.state.allOIPsforaCaseNumber.length !== 0 ?  <div>
                    {displayViewList &&
                        <Row style={{width: "100%"}} type="flex" justify="space-around" >
                            {this.renderLeftNavOIPs()}
                            {this.renderDetails()}
                        </Row>
                    }
                    {!displayViewList &&
                       <div>
                            <Row>
                                <Col span={1} />
                                <Col span={4}>
                                    <b>OIP Type </b>:
                                    <Select allowClear={true} id = "OipT" onFocus={(e) => {
                                document.getElementById("OipT").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Select An Option" onChange={(e) => this.handleLookupFieldChange(e, 'CDPRTYTYP')} value={oipLookupItemObj.CDPRTYTYP}
                                        showArrow={true} size={"default"} style={{ width: '100%' }}>
                                        {oiptypesList}
                                    </Select>
                                </Col>
                                {(oipLookupItemObj.CDPRTYTYP === 'A' || oipLookupItemObj.CDPRTYTYP === 'B' || oipLookupItemObj.CDPRTYTYP === 'D' ||
                                    oipLookupItemObj.CDPRTYTYP === 'G' || oipLookupItemObj.CDPRTYTYP === 'O' || oipLookupItemObj.CDPRTYTYP === 'P' ||
                                    oipLookupItemObj.CDPRTYTYP === 'R' || oipLookupItemObj.CDPRTYTYP === 'T' || oipLookupItemObj.CDPRTYTYP === 'W') && <div>
                                        <Col span={4}>
                                            <b>Last Name </b>: <Input placeholder="" value={oipLookupItemObj.NMESURNMEPRSN}
                                                onChange={e => this.handleLookupFieldChange(e, 'NMESURNMEPRSN')} />
                                        </Col>
                                        <Col span={4}>
                                            <b>First Name </b>: <Input placeholder="" value={oipLookupItemObj.NMEFRSTPRSN}
                                                onChange={e => this.handleLookupFieldChange(e, 'NMEFRSTPRSN')} />
                                        </Col>
                                        <Col span={4}>
                                            <b>Phone Number </b>: <Input placeholder="" value={oipLookupItemObj.NBRPHONE}
                                                onChange={e => this.handleLookupFieldChange(e, 'NBRPHONE')} />
                                        </Col>
                                    </div>}
                                {oipLookupItemObj.CDPRTYTYP === 'L' && <div>
                                    <Col span={4}>
                                        <b>NME_AGENCY </b>: <Input placeholder="" value={oipLookupItemObj.NMEAGENCY}
                                            onChange={e => this.handleLookupFieldChange(e, 'NMEAGENCY')} />
                                    </Col>
                                </div>}
                                {(oipLookupItemObj.CDPRTYTYP === 'M' || oipLookupItemObj.CDPRTYTYP === 'N') && <div>
                                    <Col span={4}>
                                        <b>Language </b>:
                                        <Select allowClear={true} id = "Lan2" onFocus={(e) => {
                                document.getElementById("Lan2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleLookupFieldChange(e, 'CDLANGUAGE')} value={oipLookupItemObj.CDLANGUAGE}
                                            showArrow={true} size={"default"} style={{ width: '100%' }}>
                                            {oiplanguagesList}
                                        </Select>
                                    </Col>
                                </div>}
                                <Col span={4} style={{ float: 'right', verticalAlign: 'middle', marginTop: "1.5%" }}>
                                   {enableSearchButton ? <Button style={{ backgroundColor: "blue", color: "white"}} onClick={this.handleLookupSearch}><Icon type="search"  theme="outlined" />Search</Button> :
                                   <Button disabled onClick={this.handleLookupSearch}><Icon type="search"  theme="outlined" />Search</Button>}
                                    <Button style={{ marginLeft: "2%"}} onClick={this.handleLookupReset}>Reset</Button>
                                </Col>
                            </Row>
                            <br />
                            <Row>
                                {this.renderLookupExisiting()}
                            </Row>
                        </div>
                    }
                </div> : <div> {!displayViewList ?
                       <div>
                            <Row>
                                <Col span={1} />
                                <Col span={4}>
                                    <b>OIP Type </b>:
                                    <Select allowClear={true} id = "OT2" onFocus={(e) => {
                                document.getElementById("OT2").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Select An Option" onChange={(e) => this.handleLookupFieldChange(e, 'CDPRTYTYP')} value={oipLookupItemObj.CDPRTYTYP}
                                        showArrow={true} size={"default"} style={{ width: '100%' }}>
                                        {oiptypesList}
                                    </Select>
                                </Col>
                                {(oipLookupItemObj.CDPRTYTYP === 'A' || oipLookupItemObj.CDPRTYTYP === 'B' || oipLookupItemObj.CDPRTYTYP === 'D' ||
                                    oipLookupItemObj.CDPRTYTYP === 'G' || oipLookupItemObj.CDPRTYTYP === 'O' || oipLookupItemObj.CDPRTYTYP === 'P' ||
                                    oipLookupItemObj.CDPRTYTYP === 'R' || oipLookupItemObj.CDPRTYTYP === 'T' || oipLookupItemObj.CDPRTYTYP === 'W') && <div>
                                        <Col span={4}>
                                            <b>Last Name </b>: <Input placeholder="" value={oipLookupItemObj.NMESURNMEPRSN}
                                                onChange={e => this.handleLookupFieldChange(e, 'NMESURNMEPRSN')} />
                                        </Col>
                                        <Col span={4}>
                                            <b>First Name </b>: <Input placeholder="" value={oipLookupItemObj.NMEFRSTPRSN}
                                                onChange={e => this.handleLookupFieldChange(e, 'NMEFRSTPRSN')} />
                                        </Col>
                                        <Col span={4}>
                                            <b>Phone Number </b>: <Input placeholder="" value={oipLookupItemObj.NBRPHONE}
                                                onChange={e => this.handleLookupFieldChange(e, 'NBRPHONE')} />
                                        </Col>
                                    </div>}
                                {oipLookupItemObj.CDPRTYTYP === 'L' && <div>
                                    <Col span={4}>
                                        <b>NME_AGENCY </b>: <Input placeholder="" value={oipLookupItemObj.NMEAGENCY}
                                            onChange={e => this.handleLookupFieldChange(e, 'NMEAGENCY')} />
                                    </Col>
                                </div>}
                                {(oipLookupItemObj.CDPRTYTYP === 'M' || oipLookupItemObj.CDPRTYTYP === 'N') && <div>
                                    <Col span={4}>
                                        <b>Language </b>:
                                        <Select allowClear={true} id = "Lan3" onFocus={(e) => {
                                document.getElementById("Lan3").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} onChange={e => this.handleLookupFieldChange(e, 'CDLANGUAGE')} value={oipLookupItemObj.CDLANGUAGE}
                                            showArrow={true} size={"default"} style={{ width: '100%' }}>
                                            {oiplanguagesList}
                                        </Select>
                                    </Col>
                                </div>}
                                <Col span={4} style={{ float: 'right', verticalAlign: 'middle', marginTop: "1.5%" }}>
                                   {enableSearchButton ? <Button style={{ backgroundColor: "blue", color: "white"}} onClick={this.handleLookupSearch}><Icon type="search"  theme="outlined" />Search</Button> :
                                   <Button disabled onClick={this.handleLookupSearch}><Icon type="search"  theme="outlined" />Search</Button>}
                                    <Button style={{ marginLeft: "2%"}} onClick={this.handleLookupReset}>Reset</Button>
                                </Col>
                            </Row>
                            <br />
                            <Row>
                                {this.renderLookupExisiting()}
                            </Row>
                        </div>: <div style={{paddingLeft: "45%",paddingTop: "2%"}}>No OIPS have been assigned to this case.</div>
                    }</div>}
            </div >
        );
    }
}

export default CaseOIPDetails;
