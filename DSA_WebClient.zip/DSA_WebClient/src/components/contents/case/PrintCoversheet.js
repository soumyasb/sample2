import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
//import moment from "moment";
import ComponentToPrint from './CoverSheetPrintComponent';
import { Button, Icon } from 'antd';

class PrintCoversheet extends Component {

    render() {
        return (
            <div>
         <ReactToPrint copyStyles= {true}
                    trigger={(e) => <Button style={{ marginLeft:'45%'}} type="primary"><Icon type="printer" theme="outlined" />Print this page</Button>}
                    content={() => this.componentRef}
                />
                <ComponentToPrint caseNumber={this.props.caseNumber} coversheetJson={this.props.coversheetJson} ref={el => (this.componentRef = el)} />
          </div>
        );
    }
}

export default PrintCoversheet;

