import React, { Component } from 'react';
import Popout from 'react-popout';
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel"
import { getCustomerDetails, getClosedCaseDetail, getH6Info, getCaseCoverSheet } from "../../../store/actions/caseActions";
import { getCaseInfo, get2011CaseInfo, initCaseReExam, processCaseReExam } from "../../../store/actions/caseSchedulingActions";
import { setCustomerPageStatus } from "../../../store/actions/uiActions";
import Case2011Scheduling from './Case2011Scheduling';
import { withRouter } from "react-router-dom";
import ComponentToPrint from './CoverSheetPrintComponent';
import cloneDeep from 'lodash/cloneDeep';
//import ReactToPrint from 'react-to-print';
import { Modal, Checkbox, List, Table, Button, Icon, Input, Row, Col, Spin, Card } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import moment from "moment";
import "../../../Cases.css";

const { TextArea } = Input;

// const frcolumns = [
//     {
//         title: <b>FR CASE NO.</b>,
//         dataIndex: 'CaseNumber',
//         width: "30%",
//         key: 'CaseNumber'
//     },
//     {
//         title: <b>ACCIDENT DATE</b>,
//         dataIndex: 'Date',
//         width: "35%",
//         key: 'Date'
//     },
//     {
//         title: <b>LOCATION</b>,
//         dataIndex: 'City',
//         width: "35%",
//         key: 'City'
//     }];


class CustomerDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
          customerDetailsObj: props.cases.customerDetailsObj,
            closedCaseDetail: props.cases.closedCaseDetail,
            openH6Modal: false,
            modalvisible: false,
            modalTitle: "",
            openNew: false,
            ErrorMessage: '',
            ErrorObj: {},
            ErrorModalShow: false
        };

        this.columns = [
            {
                title: 'Case Number',
                dataIndex: 'CaseNumber',
                width: "20%",
                key: 'CaseNumber'
            },
            {
                title: 'Status',
                dataIndex: 'CaseStatus',
                width: "20%",
                key: 'CaseStatus'
            },
            {
                title: 'Received',
                dataIndex: 'DateReceived',
                width: "20%",
                key: 'DateReceived'
            },
            {
                title: 'Referral',
                dataIndex: 'CD_REFR_SRCE_TYP',
                width: "20%",
                key: 'CD_REFR_SRCE_TYP'
            },
            {
                title: 'Reason',
                dataIndex: 'CD_RSN',
                width: "20%",
                key: 'CD_RSN',
            render: (item, record) => {
                return (
                <div>{item} {(record.CaseStatus.includes("RER") || record.CaseStatus.includes("RES") || record.CaseStatus.includes("RSC")) && <Button type="primary"  onClick={(e) => {e.stopPropagation(); this.openModal("2011 Scheduling", record.CaseNumber)}}  style={{marginLeft: "20%"}}>2011 Scheduling</Button>}</div>
                 ); }
            }];
        this.openModal = this.openModal.bind(this);
        this.getDADH6Info = this.getDADH6Info.bind(this);
        this.print = this.print.bind(this);
        this.generate2011SchedData = this.generate2011SchedData.bind(this);
    }

    componentDidMount() {
        this.props.setCustomerPageStatus(true);
        if(this.props.history.action === "POP" || this.props.history.action === "PUSH" || this.state.customerDetailsObj === undefined || this.state.customerDetailsObj.DLNumber !== this.props.match.params.dlNumber)
       { this.props.getCustomerDetails(this.props.match.params.dlNumber); 
    }
}

    print(ctype,ftype) {
        if((ctype === 'printareaCS' && this.state.caseCoverSheetObj) || (ctype === 'printareaH6' && this.state.h6Info))
        {
        var content = document.getElementById(ctype);
        var pri = document.getElementById(ftype).contentWindow;
        pri.document.open();
        pri.document.write(content.innerHTML);
        var result = pri.document.execCommand('print', false, null);
        if(!result) {
        pri.document.close();
            pri.focus();
            pri.print();
            pri.close();
        }
        if(this.state.NewDLReExam && this.state.printH6 !== true)
{
    this.props.history.push(`/customerDetails/dlNumber/${this.state.NewDLReExam}`);
}
    }
    else
    {
        if(ctype === 'printareaCS') this.setState({ErrorMessage: "The Case Coversheet data couldn't be retrieved.", ErrorModalShow: true});
        if(ctype === 'printareaH6') this.setState({ErrorMessage: "The DAD H6 information couldn't be retrieved.", ErrorModalShow: true});
    }
      }

    handleNewCase() {
        const { customerDetailsObj } = this.state;
        this.props.history.push(
            {
                pathname: `/newcase`,
                state: { detail: customerDetailsObj }
            })
    }
    generate2011SchedData(caseReExamData, caseReExamInitData) {
             if(caseReExamInitData) 
             {
                if(caseReExamData)
                {
                    if(this.state.selected2011CaseNumber)
                    {
                        caseReExamInitData.CaseNumber = this.state.selected2011CaseNumber;
                    }
                    if(caseReExamData.RequestedBy)
                    {
                        caseReExamInitData.TechId = caseReExamData.RequestedBy;
                    }
                    if(caseReExamData.CaseReason)
                    {
                        caseReExamInitData.CaseReason = caseReExamData.CaseReason;
                    }
                    if(caseReExamData.Referral)
                    {
                        caseReExamInitData.Referral = caseReExamData.Referral;
                    }
                    if(caseReExamData.MedicalReceived)
                    {
                        caseReExamInitData.MedicalReceived = caseReExamData.MedicalReceived;
                    }
                    if(caseReExamData.MailDate)
                    {
                        caseReExamInitData.MailDate = moment(caseReExamData.MailDate,"YYYY-MM-DDThh:mm:ss").format("MM-DD-YYYY");
                    }
                    else
                    {
                        caseReExamInitData.MailDate = moment().format('MM-DD-YYYY');
                    }
                    if(caseReExamData.SuspenseReason)
                    {
                        if(caseReExamData.ModifiedHearingDate)
                        {
                            caseReExamInitData.ModifiedHearingDate = moment(caseReExamData.ModifiedHearingDate,"YYYY-MM-DDThh:mm:ss").format("MM-DD-YYYY");
                        }
                        else
                        {
                            caseReExamInitData.ModifiedHearingDate = null;
                        }
                        caseReExamInitData.EnableComment = true;
                        caseReExamInitData.EnableModificationDate = true;
                    }
                    if(caseReExamData.MailDate)
                    {
                        caseReExamInitData.MailDate = moment(caseReExamData.MailDate,"YYYY-MM-DDThh:mm:ss").format("MM-DD-YYYY");
                    }
                    else
                    {
                        caseReExamInitData.MailDate = moment().format('MM-DD-YYYY');
                    }
                    if(caseReExamData.HearingType)
                    {
                        caseReExamInitData.HearingType = caseReExamData.HearingType;
                    }
                    else
                    {
                        caseReExamInitData.HearingType = "9";
                    }
                    caseReExamInitData.SuspenseDate = caseReExamData.SuspenseDate;
                }
                if(!caseReExamInitData.MedicalReceived)
                {
                    caseReExamInitData.MedicalReceived = "0";
                }
                if(!caseReExamInitData.Comment)
                {
                    caseReExamInitData.Comment = "";
                }
                return caseReExamInitData;
             }
             else
             {
return undefined;
             }
    }
    
    componentDidUpdate(prevProps)
    {
        if(this.props.match.params && this.props.match.params.dlNumber && this.props.cases.customerDetailsObj && this.props.cases.customerDetailsObj.DLNumber !== this.props.match.params.dlNumber)
       { this.props.getCustomerDetails(this.props.match.params.dlNumber); 
    }
        if (prevProps.cases.customerDetailsObj !== this.props.cases.customerDetailsObj) {
            if (this.props.cases.customerDetailsObj !== undefined) {
                this.setState({ customerDetailsObj: this.props.cases.customerDetailsObj });
                this.props.setCustomerPageStatus(true);
            }
        }
        if (prevProps.cases.closedCaseDetail !== this.props.cases.closedCaseDetail) {
            if(this.props.cases.closedCaseDetail !== undefined)
            {
            this.setState({ closedCaseDetail: this.props.cases.closedCaseDetail});
            }
        }
        if (prevProps.caseScheduling.caseReExamUpdateData !== this.props.caseScheduling.caseReExamUpdateData) {
            if(this.props.caseScheduling.caseReExamUpdateData)
             {
                let modalvisible = true; 
                if(this.props.caseScheduling.caseReExamUpdateData.UpdateSuccessful)
                {
                    this.props.getCaseCoverSheet(this.props.caseScheduling.caseReExamUpdateData.CaseNumber);
                    modalvisible = false;
                }
            this.setState({ caseReExamUpdateData: this.props.caseScheduling.caseReExamUpdateData, modalvisible: modalvisible, showStatusModal: true});
            }
        }
        if (prevProps.cases.caseCoverSheetObj !== this.props.cases.caseCoverSheetObj) {
            this.setState({ caseCoverSheetObj: this.props.cases.caseCoverSheetObj});
            }        
        if (prevProps.cases.h6Info !== this.props.cases.h6Info) {
            if(this.props.cases.h6Info !== undefined)
            {
            this.setState({ h6Info:  Object.entries(this.props.cases.h6Info).map(([key,value])=>{
                return (value.toString());})});
            }
        }
        if ( this.props.caseScheduling.caseSchedulingErrorData  && ( prevProps.caseScheduling.caseSchedulingErrorData !== this.props.caseScheduling.caseSchedulingErrorData || prevProps.caseScheduling.emodified !== this.props.caseScheduling.emodified)) {
            if(typeof this.props.caseScheduling.caseSchedulingErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.caseScheduling.caseSchedulingErrorData.split(' RandomMathNumber')[0], ErrorModalShow: true});
            }
            else{
                let Errors = [];
                Object.keys(this.props.caseScheduling.caseSchedulingErrorData).map((keyName) => {
                    Errors.push(this.props.caseScheduling.caseSchedulingErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.caseScheduling.caseSchedulingErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }  
        }
        if (prevProps.caseScheduling.caseReExamInitData !== this.props.caseScheduling.caseReExamInitData) {
            if(this.props.caseScheduling.caseReExamInitData)
            {
               if(this.props.caseScheduling.caseReExamData && this.state.modalTitle === "2011 Scheduling")
               {
                const caseReExamInitData =  this.generate2011SchedData(this.props.caseScheduling.caseReExamData[0], this.props.caseScheduling.caseReExamInitData);
                this.setState({ caseReExamInitData: caseReExamInitData});
            } 
               else
               {
                let caseReExamInitData = this.props.caseScheduling.caseReExamInitData;
                caseReExamInitData.MedicalReceived = "0";
                    caseReExamInitData.HearingType = "9";
                    caseReExamInitData.MailDate = moment().format('MM-DD-YYYY');
                    caseReExamInitData.EnableComment = false;
                    caseReExamInitData.EnableModificationDate = false;
                
            this.setState({ caseReExamInitData: caseReExamInitData});
            }
        }
    }
        if (prevProps.caseScheduling.caseReExamData !== this.props.caseScheduling.caseReExamData) {
            if(this.props.caseScheduling.caseReExamData && this.props.caseScheduling.caseReExamInitData)
            {
              const caseReExamInitData =  this.generate2011SchedData(this.props.caseScheduling.caseReExamData[0], this.props.caseScheduling.caseReExamInitData);
            this.setState({ caseReExamData:  this.props.caseScheduling.caseReExamData, caseReExamInitData: caseReExamInitData});
            }
        }
    }
    componentWillUnmount()
    {
        this.props.setCustomerPageStatus(false);
    }    
    isArchivedRow(record) {
        if (record.Archived) {
            return {

            }
        }
    }

    openModal = (type, CaseNumber) => {
        if(type === "2011 Scheduling")
        {
               this.setState({modalvisible: true, modalTitle: "2011 Scheduling", instance: Math.random(), selected2011CaseNumber: CaseNumber});
               this.props.initCaseReExam(this.state.customerDetailsObj);
               this.props.get2011CaseInfo(CaseNumber);     
            }
            else if(type === "New 2011 Scheduling")
            {
                this.setState({modalvisible: true, modalTitle: "New 2011 Scheduling", instance: Math.random(), selected2011CaseNumber: null});
                this.props.initCaseReExam(this.state.customerDetailsObj);
            }
            else
            {
                this.props.getClosedCaseDetail(CaseNumber);
                this.setState({ modalvisible: true, modalTitle: "Closed Case Detail" });
            }
    }

    getDADH6Info = (e) => {
        this.props.getH6Info(this.state.customerDetailsObj.DLNumber);
       // this.setState({openH6Modal: true});
        this.setState({openNew: true});
    }

    render() {
        const boxShadows = {
            boxShadow:
              "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
        };      

const { closedCaseDetail } = this.state;
        const { customerDetailsObj } = this.state;
        let printheader = "", EmpInitial = "";
       if(customerDetailsObj !== undefined)
       { 
         if(sessionStorage.getItem('userInfo')){
            EmpInitial = JSON.parse(sessionStorage.getItem('userInfo')).EmpInitial;
        }  
         printheader = "LIC #: "+customerDetailsObj.DLNumber+"            UID: "+EmpInitial+"  Trans: DAD  Date: "+moment(Date.now()).format('MM-DD-YYYY hh:mm');
        }
        return (
            // <ScrollPanel
            //     style={{
            //         width: "100%",
            //         height: "100%",
            //         backgroundColor: "rgba(0,0,0,0)"
            //     }}
            // >
            <React-Fragment>
            {/* <Button onClick={(e) => { this.props.getH6Info(this.state.customerDetailsObj.DLNumber); this.setState({openNew: true});
        }}>Click Me!</Button> */}
         { this.state.openNew && <Popout options={{left: "100px", top: "100px", height: '800px', width: '800px'}}  title="H6 Information" onClosing={(e) => this.setState({openNew: false})}> {this.state.h6Info !== undefined ? <div>{(this.state.h6Info.length > 0) ? <div>
                               {/* <Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print('printareaH6', 'H6ifmcontentstoprint')}><Icon type="printer" theme="outlined" />Print this page</Button> <ScrollPanel  style={{
              height: "500px"
          }}>      <div id='printareaH6'> 
                   <iframe title="H6ifmcontentstoprint" id="H6ifmcontentstoprint" style={{
                        height: '0px',
                        width: '0px',
                        position: 'absolute'
                    }}></iframe>   <title>
                    {printheader}
                  </title> */}
                  <h3 style={{paddingLeft: "40%"}}>DAD H6 Information</h3>
                  <pre><b>{printheader}</b></pre>
            <pre><div dangerouslySetInnerHTML={{ __html: this.state.h6Info.toString()}}/></pre>
                                          {/* </div> */}
                                          {/* </ScrollPanel> */}
                                          </div>:<div>No DAD H6 info found.</div>                           
                                }</div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}
         </Popout> } {/* {this.state.openNew &&   } */}
                        <Modal visible={this.state.ErrorModalShow}
title={'Error Message'} maskClosable={false}
footer={[
<div key={`${Math.random()}`}>
<Button type="primary" key="Ok" onClick={(e) => 
{
this.setState({ErrorModalShow: false});
if(this.state.NewDLReExam)
{
    this.props.history.push(`/customerDetails/dlNumber/${this.state.NewDLReExam}`);
}
}}>OK</Button>
</div>
]}
>
{this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
<ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
: <div><font color= 'red'>{this.state.ErrorMessage}</font></div>}
</Modal>                    {this.state.caseCoverSheetObj && this.state.caseReExamUpdateData.UpdateSuccessful && <div id='printareaCS' > 
<iframe title="CSifmcontentstoprint" id="CSifmcontentstoprint" style={{
height: '100%',
opacity: '0',
width: '100%',
border: 'none',
position: 'absolute'
}}></iframe>  
<div class="print-only">{this.state.caseCoverSheetObj && <ComponentToPrint caseNumber={this.state.caseCoverSheetObj.CaseNumber} coversheetJson={this.state.caseCoverSheetObj} />}</div>
</div>}
           {this.state.caseReExamUpdateData && <Modal visible={this.state.showStatusModal}
title={ 
    this.state.caseReExamUpdateData.Error ? "Error" : this.state.caseReExamUpdateData.UpdateSuccessful ? "Success" : 'Warning'
} maskClosable={false}
footer={[
this.state.caseReExamUpdateData.UpdateSuccessful ? <div>
<Button type="primary" key="Ok" onClick={(e) => {
let openH6Modal = false;
this.print('printareaCS', 'CSifmcontentstoprint');
if(this.state.printH6)
{  
this.props.getH6Info(this.state.caseReExamUpdateData.DLNumber);
openH6Modal = true;
}
this.setState({ showStatusModal: false, openH6Modal: openH6Modal });}}>Ok</Button>{"  "}<Button style={{ color: "white", marginLeft: "2%", backgroundColor: "red" }}
type="default" key="Cancel" onClick={(e) => {        
    if(this.state.NewDLReExam){this.setState({ showStatusModal: false, modalvisible: false});  this.props.history.push(`/customerDetails/dlNumber/${this.state.NewDLReExam}`); } else{this.setState({ showStatusModal: false, modalvisible: false});  this.props.getCustomerDetails(this.state.caseReExamUpdateData.DLNumber);}      
    //this.setState({ showStatusModal: false, modalvisible: false});
}}>Cancel</Button>
</div> : <div><Button type="primary" key="Ok" onClick={(e) => { if(this.state.NewDLReExam){this.setState({ showStatusModal: false, modalvisible: false});  this.props.history.push(`/customerDetails/dlNumber/${this.state.NewDLReExam}`); }else {this.setState({ showStatusModal: false})}}}>Ok</Button></div>
]}
>

{this.state.caseReExamUpdateData.UpdateSuccessful && <div>Case 2011 scheduling successful! <br/> Please select further actions: 
<Checkbox checked={'true'}>Print Case Coversheet</Checkbox>
<Checkbox onChange={(e) => this.setState({printH6: e.target.checked})}>Print DAD/H6</Checkbox></div>} 
<div>{this.state.caseReExamUpdateData.ErrorMessage && this.state.caseReExamUpdateData.Error && <div dangerouslySetInnerHTML={{ __html: this.state.caseReExamUpdateData.ErrorMessage}}/>}</div>
</Modal>}
                <div style={{
                    justify: "center",
                    height: "90%",
                    padding: "25px",
                    margin: "15px"
                }} >
                    {customerDetailsObj !== undefined
                    
                    && this.props.match.params.dlNumber === customerDetailsObj.DLNumber ? (
                        <div>
                            <div style={{
                                justify: "center",
                                height: "30px",
                                backgroundColor: "white",
                                border: "3px solid white"
                            }} ><Icon type="idcard" /> <b>{customerDetailsObj.LastName.replace(/\s/g,'')}{", "}{customerDetailsObj.FirstName.replace(/\s/g,'')}</b></div>
                            <Row >
                                <Col span={72}>
                                    <div style={{
                                        width: "100%",
                                        height: "90%",
                                        border: "3px solid white",
                                        padding: "25px"
                                    }}>
                                        <Row gutter={64}>
                                            <Col span={6}>
                                                <Row> <b>DL Number</b>:
                                                    <Input value={customerDetailsObj.DLNumber} readOnly />
                                                </Row>
                                                <Row> <b>DOB</b>:
                                                    <Input value={customerDetailsObj.DOB} readOnly />
                                                </Row>
                                            </Col>
                                            <Col span={6}>
                                                <Row> <b>License Class</b>:
                                                    <Input value={customerDetailsObj.classLicense} readOnly />
                                                </Row>
                                                <Row> <b>Phone Number</b>:
                                                    <Input value={customerDetailsObj.PhoneNumber} readOnly />
                                                </Row>
                                            </Col>
                                            <Col span={6}>
                                                <Row> <b>Address</b>:
                                                    <TextArea rows="3" value={this.state.customerDetailsObj.MailingAddress} readOnly />
                                                </Row></Col>
                                            <Col span={6}>
                                          <Button style={{color: "#rgb(6, 13, 20)", borderRadius: "100px", borderColor: "brown", marginTop: "10%", marginLeft: "10%"}} onClick={(e) => this.getDADH6Info(e)}><Icon type="profile" style={{ fontSize: 16 }} /> View DAD H6 Information</Button>
                                          {/* <Modal maskClosable={false} width="900px" title={"DAD H6 Information"}
                                visible={this.state.openH6Modal}
                                onCancel={(e) => this.setState({openH6Modal: false})}
                                footer = { [
                                    <Button type="primary" key="Ok" onClick={(e) => {
this.setState({openH6Modal: false, ErrorModalShow: false});
if(this.state.NewDLReExam)
{
    this.props.history.push(`/customerDetails/dlNumber/${this.state.NewDLReExam}`);
}}}>Ok</Button>
                                ]}> <div>{this.state.h6Info !== undefined ? <div>{(this.state.h6Info.length > 0) ? <div>
                               <Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print('printareaH6', 'H6ifmcontentstoprint')}><Icon type="printer" theme="outlined" />Print this page</Button> <ScrollPanel  style={{
              height: "500px"
          }}>      <div id='printareaH6'> 
                   <iframe title="H6ifmcontentstoprint" id="H6ifmcontentstoprint" style={{
                        height: '0px',
                        width: '0px',
                        position: 'absolute'
                    }}></iframe>   <title>
                    {printheader}
                  </title>
            <pre><div dangerouslySetInnerHTML={{ __html: this.state.h6Info.toString()}}/></pre>
                                          </div>
                                          </ScrollPanel>
                                          </div>:<div>No DAD H6 info found.</div>                           
                                }</div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}</div> </Modal> */}
                                            </Col> 
                                        </Row>
                                        <Row span={16}>
                                            <Col span={8}>
                                                <Row>
                                                    {(customerDetailsObj.D26ValidationOK !== true) && <div><b>D26 Validation Message:</b>{customerDetailsObj.D26ValidationMessage}</div>}
                                                </Row>
                                                <Row>
                                                    {(customerDetailsObj.Message !== null) && <div><b>Message:</b>{customerDetailsObj.Message}</div>}
                                                </Row>
                                                <Row>
                                                    {(customerDetailsObj.ErrorMessage !== null) && <div><b>Message:</b>{customerDetailsObj.ErrorMessage}</div>}
                                                </Row>
                                            </Col>
                                            <Col span={8}>
                                            {customerDetailsObj.DCSDifferences.length > 0 && <div>
                                                    <List
                                                        size="small"
                                                        header={<div><b>DCS Differences</b></div>}
                                                        dataSource={customerDetailsObj.DCSDifferences}
                                                        renderItem={item => (<List.Item>{item}</List.Item>)}
                                                    />
                                                </div>}
                                            </Col>
                                        </Row>
                                    </div>
                                </Col>
                            </Row>
                            <Row>
                                <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "white",
                                    border: "3px solid white"
                                }} ><span><b>CASES</b></span></div>
                                <div style={{
                                    justify: "center",
                                    height: "350px",
                                    border: "3px solid white",
                                    padding: "25px"
                                }}>
                                    {customerDetailsObj.cases && <div><Table
                                        showHeader
                                        rowClassName={(record) => record.Archived === true ? 'archiveRowClass' : ''}
                                        size='small'
                                        style={{ align: "center", width: "100%" }}
                                        scroll={{ y: 200 }}
                                        pagination={false}
                                        onRow={(record) => ({
                                            onClick: () => {
                                                    if(record.Archived === false)
                                                    {
                                                if (record.CaseStatusCode !== 'CL') {
                                                    this.props.history.push(
                                                        { pathname: `/caseDetails/CaseNumber/${record.CaseNumber}`,
                                                        state: { dlNumber: customerDetailsObj.DLNumber }
                                                    });                                                 
                                                }
                                                else {
                                                    this.openModal('ClosedCaseDetail', record.CaseNumber);
                                                }
                                            }             
                                            }                                         
                                        }) }
                                        columns={this.columns}
                                        dataSource={customerDetailsObj.cases}
                                        rowKey={record => record.CaseNumber}
                                    />
                                    <div style={{ marginTop:"20px" }}><Button style={{ marginLeft:"35%" }} type="primary" onClick={() => this.handleNewCase()}>New Case</Button><Button style={{ marginLeft:"5%" }} type="primary" onClick={(e) => {e.stopPropagation(); this.openModal("New 2011 Scheduling")}}>New 2011 Scheduling</Button></div>
                                    </div>
                                    }
                                </div>
                                <div><font color="red" size="small">*</font> <font size="small">The cases in red are archived.</font></div>
                            </Row>
                           <Modal maskClosable={false} title={this.state.modalTitle}
                                visible={this.state.modalvisible}
                                onCancel={(e) => this.setState({ modalvisible: false })}
                                 width={'85%'}
                                 height={"800px"}
                                footer = { this.state.modalTitle === "Closed Case Detail" ? <Button type="primary" key="Ok" onClick={(e) => this.setState({ modalvisible: false })}>Ok</Button> : null }> 
                           {this.state.modalTitle === "Closed Case Detail" ? <div>{(this.state.closedCaseDetail !== undefined) ? <div>
                            <Row>
                            <Col span={32}>
                            <div>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    ...boxShadows
                                    }}
                                >
                                   <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} ><b>Subject Information</b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "30px",
                                    paddingLeft: "1%"
                                   }}>
                                   <span style={{ paddingLeft: '0.5%'}}><b>DL # :</b> {closedCaseDetail.DlNumber}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Case # : </b>{closedCaseDetail.CaseNumber}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Name : </b>{closedCaseDetail.SubjectName}</span>
                                   </div>
                                    </div>
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    ...boxShadows
                                    }}
                                >
                                   <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} ><b>DS124 Coding Strip</b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "30px",
                                    paddingLeft: "1%"
                                   }}><span><b>Type : </b>{closedCaseDetail.Type}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Hearing Date: </b>{closedCaseDetail.HearingDate}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Location: </b>{closedCaseDetail.Location}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Reason: </b>{closedCaseDetail.Reason}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Sched Results: </b>{closedCaseDetail.ScheduledResults}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Type Action: </b>{closedCaseDetail.TypeAction}</span>       
                                     <span style={{ paddingLeft: '5%'}}><b>Modified Date: </b>{closedCaseDetail.ModifiedDate}</span></div>
                                    </div>
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    ...boxShadows
                                    }}
                                >                                  
                                     <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} > <b>Action Information </b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "60px",
                                    paddingLeft: "1%"
                                   }}><div> <span><b>Authority Section: </b>{closedCaseDetail.AuthoritySection1}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Authority Section: </b>{closedCaseDetail.AuthoritySection2}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Authority Section: </b>{closedCaseDetail.AuthoritySection3}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Effective Date: </b>{closedCaseDetail.EffectiveDate}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Through Date: </b>{closedCaseDetail.ThroughDate}</span></div>

                                    <div> <span><b>Action Term Date : </b>{closedCaseDetail.ActionTermDate}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Mail Date: </b>{closedCaseDetail.MailDate}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Original Authority Section: </b>{closedCaseDetail.OriginalAuthoritySection}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Original Effective Date: </b>{closedCaseDetail.OriginalEffectiveDate}</span></div></div></div>
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    ...boxShadows
                                    }}
                                >
                                     <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} > <b>Case Closure Information </b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "60px",
                                    paddingLeft: "1%"
                                   }}><div> <span><b>Scheduled To: </b>{closedCaseDetail.ScheduledTo}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Date Updated: </b>{closedCaseDetail.DateUpdated}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Updated By: </b>{closedCaseDetail.UpdatedBy}</span></div>                               
                                    <div> <span style={{ paddingLeft: '25%'}}><b>Date Closed: </b>{closedCaseDetail.DateClosed}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Closed By: </b>{closedCaseDetail.ClosedBy}</span>
                           </div></div>
                                    </div>
                                </Card>                       
                                </div>
                            </Col>
                        </Row>
                                </div> :  <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div> }
                                </div> : <Case2011Scheduling ErrorObj={this.state.ErrorObj} closeReExam={(e) => {this.setState({modalvisible: false, ErrorObj: []})}} processCaseReExam = {(reExamObj) => {
                                   this.setState({NewDLReExam: reExamObj.NextDLNumber, ErrorObj: []}); this.props.processCaseReExam(reExamObj); }} _2011SchedulingInitData={this.state.caseReExamInitData} ref2011SchedData={cloneDeep(this.state.caseReExamInitData)} modalTitle={this.state.modalTitle}></Case2011Scheduling>
                                    } 
                                </Modal>
                        </div>
                    ) : (
                            <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>
                        )}
                </div>
            {/* </ScrollPanel> */}
            </React-Fragment>
        );
    }
}


const mapStateToProps = state => {
    return {
        cases: state.cases,
        ui: state.ui,
        caseScheduling: state.caseScheduling
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getCustomerDetails,
            getClosedCaseDetail,
            getH6Info,
            setCustomerPageStatus,
            getCaseInfo, 
            get2011CaseInfo,
            initCaseReExam, 
            processCaseReExam,
            getCaseCoverSheet
        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CustomerDetails));

