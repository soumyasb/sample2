import React, { Component } from 'react';
import { getUnScheduledCases, getCaseCoverSheet, getH6Info } from "../../../store/actions/caseActions";
import { getCaseInfo, scheduleCase, overrideCaseSchedule, getAvailableTimeSlots, getPreviousDayAvailableTimeSlots, getNextDayAvailableTimeSlots } from "../../../store/actions/caseSchedulingActions";
import { getOffices } from "../../../store/actions/dataManagerActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';
import { Select, Button, Modal, Divider, Row, Spin, Col, Card, Tooltip, Table} from 'antd'; 
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import moment from "moment"; 
import "../../../Cases.css";
import CaseSchedule from './CaseSchedule';

const { Option } = Select;

class UnScheduledCases extends Component {
    constructor(props) {
        super(props);
  this.timeSlotColumns = [
    {
        title: '',
        width: '5%',
        key: `${Math.random()}`,   
        render: (record) => {
            return (
                <div style={{textAlign: "center"}}>
                     <Button type="default" style={{ color: "white", backgroundColor: "green" }} size={"small"} onClick={e => {const {scheduleObj} = this.state;  scheduleObj.TimeSlot = cloneDeep(record); this.setState({pickedTimeSlot: record, scheduleObj: scheduleObj, openTimeSelectionModal: false, picktime: false})}} >Select</Button>
                </div>
            );
        },
    },
            {
                title: <b>Start Time</b>,
                dataIndex: 'StartTime',
                width: '6%',
                render: item => moment(item).format("HH:mm A")            
            },
            {
                title: <b>End Time</b>,
                dataIndex: 'EndTime',
                width: '6%',
                render: item => moment(item).format("HH:mm A")                 
            },
            {
                title: <b>Status</b>,
                dataIndex: 'Status',
                width: '6%',             
            },
            {
                title: <b>Hearing Officer</b>,
                dataIndex: 'EmployeeName',
                width: '6%',
            }
        ];
        this.state={
            unScheduledCasesList: this.props.cases.unScheduledCasesList,
            selectedCase: "",
            selectedDate: "",
            current: 1,
            isLoading: true,
            schedStartTime: "",
            schedEndtime: "",
            schedulingInProgress: false,
            showModal: false,
            picktime: true,
            openTimeSelectionModal: false,
            ErrorMessage: '',
            ErrorModalShow: false,
            showStatusModal: false,
            printH6: false,
            goToDUX: false,
            openH6Modal: false,
            overridden: false
        };

    }    
    componentDidMount()
    {
        
        let officeId = "";
    if(sessionStorage.getItem('userInfo')){
        officeId = JSON.parse(sessionStorage.getItem('userInfo')).OfficeId;
        this.setState({selectedOfficeId: officeId});
        this.props.getUnScheduledCases(officeId,8);
    }
        this.props.getOffices();
    }

    componentDidUpdate(prevProps) {
        if ( prevProps.dataManager.allOfficesList !== this.props.dataManager.allOfficesList && this.props.dataManager.allOfficesList !== undefined) {
            this.setState({allOfficesList: this.props.dataManager.allOfficesList});
        }
        if ( prevProps.cases.unScheduledCasesList !== this.props.cases.unScheduledCasesList && this.props.cases.unScheduledCasesList !== undefined) {
            this.setState({unScheduledCasesList: this.props.cases.unScheduledCasesList});
        }
        if ( prevProps.homePage !== this.props.homePage && this.props.homePage !== undefined) {
            this.setState({selectedOfficeId: this.props.homePage.OfficeId});
            this.props.getUnScheduledCases(this.props.homePage.OfficeId,8);
        }
    }
    static getDerivedStateFromProps(props, prevState) {
        const { unScheduledCasesList, h6Info, caseCoverSheetObj  } = props.cases;
        const { caseInfo, availableTimeSlots, modified, caseSchedulingErrorData} = props.caseScheduling;
        const { allOfficesList } = props.dataManager;
        if (unScheduledCasesList && unScheduledCasesList !== prevState.unScheduledCasesList) {
            return { unScheduledCasesList: unScheduledCasesList };
        }
        if (caseInfo && caseInfo !== prevState.caseInfo) {
            return { caseInfo: caseInfo, scheduleObj: cloneDeep(caseInfo) };
        }
        if (availableTimeSlots && (availableTimeSlots !== prevState.availableTimeSlots || modified !== prevState.modified)) {
                return { availableTimeSlots: availableTimeSlots, modified: modified };
        }
        if (allOfficesList && allOfficesList !== prevState.allOfficesList) {
            return { allOfficesList: allOfficesList };
        }
        if (caseCoverSheetObj && caseCoverSheetObj !== prevState.caseCoverSheet) {
            return { caseCoverSheet: caseCoverSheetObj };
        }
        if (h6Info && h6Info !== prevState.h6Info) {
            return { h6Info: h6Info };
        }
        if (caseSchedulingErrorData && caseSchedulingErrorData !== prevState.caseSchedulingErrorData) return {caseSchedulingErrorData, isLoading: false };
        return null;
    }

   
    showModal(actype, CD_CASE) {
        if(CD_CASE)
    {
        if(actype === "schedule")
        {
            this.setState({ schedulingInProgress: false, instance: Math.random(), ErrorMessage: '', scheduleObj: undefined, showStatusModal: false, selectedDate: "", isLoading: false, ErrorModalShow: false, schedStartTime: "", schedEndtime: "", openTimeSelectionModal: false, actionType: actype, picktime: true, pickedTimeSlot: undefined, showModal: true, modalTitle: "Case Scheduling", selectedCase: CD_CASE, timeSearchText: "Find Available Time Slots" });
        }
        this.props.getCaseInfo(CD_CASE);     
}   
}

    render() {
        const columns =[
             {
                title: <b>DL#</b>,
                dataIndex: 'NBR_DL',
                sorter: (a, b) => { return a.NBR_DL.localeCompare(b.NBR_DL)}
            },{
                title: <b>Receipt Date</b>,
                dataIndex: 'DT_RCPT',
                render: (text) => moment(text).format("MM-DD-YY"),
                sorter: (a, b) => { return a.DT_RCPT.localeCompare(b.DT_RCPT)}
            }, {
                title: <b>Case Status</b>,
                dataIndex: 'CD_STATUS_REC',
                render: (text) => 
                   {
                    let title="";   
                    switch (text)
                    {
                        case 'UN':
                        title = "Unscheduled";
                        break;
                        case 'UR':
                        title = "Unscheduled Reschedule";
                        break;
                        case 'UC':
                        title = "Unscheduled Reconvene";
                        break;
                        case "RER":
                        title = "2011";
                        break;
                        case "RES":
                        title = "2011 Extension";
                        break;
                        default:
                        title = "";
                        break;                    
                    }
                return <Tooltip title={title}>{text}</Tooltip>
                   },
                sorter: (a, b) => { return a.CD_STATUS_REC.localeCompare(b.CD_STATUS_REC)}
            }
            , {
                title: <b>Type Hearing</b>,
                dataIndex: 'CD_HRNG_TYP',
                sorter: (a, b) => { return a.CD_HRNG_TYP.localeCompare(b.CD_HRNG_TYP)}
            }, {
                title: <b>Reason</b>,
                dataIndex: 'CD_RSN',
                sorter: (a, b) => { return a.CD_RSN.localeCompare(b.CD_RSN)}
            }, {
                title: <b>Subject Name</b>,
                render: (record) => (
                    <span>
                        {`${record.PersonFirstName} ${record.PersonLastName}`}
                    </span>
                ),
                sorter: (a, b) => { 
                                         const driverNameA = a.PersonFirstName + ' ' + a.PersonLastName; 
                                         const driverNameB = b.PersonFirstName + ' ' + b.PersonLastName; 
                     
                                        return driverNameA.trim().localeCompare(driverNameB.trim()); 
                                  }                   
            }, {
                title: <b>Case#</b>,
                dataIndex: 'CD_CASE',
                key: 'CD_CASE',
                sorter: (a, b) => { return a.CD_CASE.localeCompare(b.CD_CASE)}
            },
            {
                title: <b>Action</b>,
                render: (item) => {
                    return (  <div style={{textAlign: "center"}}>
                    <Button type="primary" onClick={e => {e.stopPropagation(); this.showModal('schedule', item.CD_CASE)}} > Schedule </Button>
                    <Divider type="vertical" />
                    <Button type="primary" onClick={e => {e.stopPropagation(); this.props.history.push(
                                                { pathname: `/caseDetails/CaseNumber/${item.CD_CASE}`,
                                                state: { dlNumber: item.NBR_DL}
                                            });    } }> Detail </Button>
               </div>);
                }
            }
        ];

        const boxShadows = {
            boxShadow:
              "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
        };

        return (
        //     <ScrollPanel
        //     style={{
        //         width: "100%",
        //         height: "100%",
        //         backgroundColor: "rgba(0,0,0,0)"
        //     }}
        // >
        <React-Fragment>
        <Modal width="60%" title={this.state.modalTitle} maskClosable={false} visible={this.state.showModal}
onCancel={(e) =>  this.setState({     
showModal: false
})}

footer = { [
<div key={`${Math.random()}`}>
<Button type="primary" key="Cancel" style={{backgroundColor: "red", color: "white"}} onClick={(e) =>
{
this.setState({     
showModal: false                               
});
}}
> Close </Button> 
</div>
]}
>
<CaseSchedule closeModal={(e) => this.setState({showModal: false})} type={'unscheduledCases'} uponSchedule={(e) => {this.setState({showModal: false}); this.props.getUnScheduledCases(this.state.selectedOfficeId, 8)}} goToDUX={(DLNumber) => { this.props.history.push(`/duxUpdate/DLNumber/${DLNumber}`);}} key={this.state.instance} scheduleObj={this.state.scheduleObj} selectedOfficeId={this.state.selectedOfficeId} timeSearchText={this.state.timeSearchText} allOfficesList={this.state.allOfficesList} caseInfo={this.state.caseInfo} selectedCase={this.state.selectedCase}></CaseSchedule>


</Modal>
                               <div style={{paddingTop: "1%", paddingLeft: '1%'}}>           <div style={{width: "20%", float: "left"}}> <b style={{fontSize: '16px'}}>Pick an office (Default to Employee's office):</b></div><div style={{width: "20%", float: 'left', paddingLeft: "2%"}}><Select id = "SPOff" onFocus={(e) => {
                                document.getElementById("SPOff").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true}  value={this.state.selectedOfficeId} placeholder="Select Office" showArrow={true} 
                                            size={"default"} style={{ width: '100%' }} onChange={(e) => {this.setState({selectedOfficeId: e});
                                            this.props.getUnScheduledCases(e,8)}}>                                         
                                             {this.state.allOfficesList && this.state.allOfficesList.map(off => <Option key={off.OfficeID} value={off.OfficeID}>{off.OfficeID} - {off.Name}</Option>)}
                                        </Select></div></div><br/>
                <Row>
                    <Col span={24}>
                        <Card
                            style={{
                            marginTop: "8px",
                            borderRadius: "16px",
                            ...boxShadows
                            }}
                        > 
                            {this.state.unScheduledCasesList ? <Table 
                                rowKey='CD_CASE'
                                title={() => <div><span><h1>Unscheduled Cases for Office: {this.state.allOfficesList && this.state.allOfficesList.map((off) => {
                                    if(off.OfficeID === this.state.selectedOfficeId)
                                    {
                                        return off.Name;
                                    }
                                    return "";
                                })}</h1></span></div>} 
                                footer={() => <b>{this.state.unScheduledCasesList.length} cases unscheduled.</b>} 
                                showHeader 
                                columns={columns} 
                                size="small"
                                onRow={(record) => ({
                                    onClick: () => {                                                                        
                                            this.props.history.push(
                                                { pathname: `/caseDetails/CaseNumber/${record.CD_CASE}`,
                                                state: { dlNumber: record.NBR_DL}
                                            });                                                           
                                    }                                         
                                }) }
                                dataSource={this.state.unScheduledCasesList}
                                pagination={{ pageSize: 8 }} />
                                : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>
                            }
                        </Card>
                    </Col>
                </Row>
                {/* </ScrollPanel>    */}
                </React-Fragment>
                );
}    
}

    
const mapStateToProps = state => {
    return {
       cases: state.cases,
       dataManager: state.dataManager,
       caseScheduling: state.caseScheduling,
       homePage: state.homePage
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getH6Info, getUnScheduledCases, scheduleCase, overrideCaseSchedule, getOffices, getCaseInfo, getAvailableTimeSlots, getPreviousDayAvailableTimeSlots, getNextDayAvailableTimeSlots, getCaseCoverSheet
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(UnScheduledCases);