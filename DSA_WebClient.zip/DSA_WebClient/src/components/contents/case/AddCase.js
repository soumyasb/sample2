import React, { Component } from 'react';
import { getCreateCaseDetails, getHearingTypes, getCaseReasons, getCaseReferrals, getCaseCertifications, getCustomerD26Info, addCase } from "../../../store/actions/caseActions";
import { withRouter } from "react-router-dom";
import { Row, Col } from 'antd';
import moment from "moment";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Radio, Tooltip, notification, Spin, Input, Button, Select, Layout, Icon } from 'antd';
import "../../../Cases.css";
const {Content} = Layout;
const RadioGroup = Radio.Group;
const { TextArea } = Input;
const radioStyle = {
  display: 'block',
  height: '30px',
  lineHeight: '30px',
};
const getDropdownList = (listObj, selectedValue) =>   
{  
    let list = [];   

     listObj.map(item =>
{
  if(item.Value === selectedValue)
  {
    list.push(<option key={item.Value} value={item.Value} selected>{item.Text}</option>)
  }
  else
  {
  list.push(<option key={item.Value} value={item.Value}>{item.Text}</option>)
  }
  return "";
});
  return list;     
}


   const getAccidentsList = (accidentsObj) =>   
{  
    let list = [];   

    accidentsObj.Accidents.map(item =>
{

  list.push(<Radio style={radioStyle} value={item.CaseNumber}><span style={{paddingLeft:"5px"}}>{item.CaseNumber}</span><span style={{paddingLeft:"25px"}}>{item.Date}</span><span style={{paddingLeft:"25px"}}>{item.City}</span></Radio>)
  return "";
}
);   return list;    
   }
const reqRsnCodesForCerts = ["871","875","880","881","882","883","884","885","887","888","889","891","892","894","897","898"];


class AddCase extends Component {
    constructor(props) {
        super(props);
        this.state={
          customerDetailsObj: props.cases.customerDetailsObj,
            createCaseObj: props.cases.createCaseObj,
            hearingTypes: props.cases.hearingTypesList,
            caseReasons: props.cases.caseReasonsList,
            caseReferrals: props.cases.caseReferralsList,
            caseCertifications: props.cases.caseCertificationsList,
            customerD26Info: props.cases.customerD26Info,
            dlNumber: props.match.params.dlNumber
        };
       this.onButtonClick = this.onButtonClick.bind(this);   
       this.handleChange = this.handleChange.bind(this);
       this.textChange = this.textChange.bind(this);   
       this.openNotification = this.openNotification.bind(this);
    }    
    componentDidMount() {
      if(this.props.location.state !== undefined)
      {
      this.props.getCreateCaseDetails(this.props.location.state.detail);
      }
     else if(this.state.customerDetailsObj !== undefined)
      {
        this.props.getCreateCaseDetails(this.state.customerDetailsObj);
      }
      else
      {
        this.props.history.push(`/`);
      }
      this.props.getHearingTypes();
      this.props.getCaseReasons();
      this.props.getCaseReferrals();
      this.props.getCaseCertifications();
  }

  componentWillReceiveProps(nextProps) {
      if (this.props.cases.createCaseObj !== nextProps.cases.createCaseObj) {
          if(nextProps.cases.createCaseObj !== undefined)
          {
            if(nextProps.cases.createCaseObj.CaseNumber !== null)
            {
             this.openNotification();
              this.props.history.push({ pathname: `/caseDetails/CaseNumber/${nextProps.cases.createCaseObj.CaseNumber}`,
            state: {caseStatus: 'saved'}});
            }
          this.setState({ createCaseObj: nextProps.cases.createCaseObj});
          this.setState({ hearingType: nextProps.cases.createCaseObj.CD_HRNG_TYP});
          this.setState({ caseReason: nextProps.cases.createCaseObj.CD_RSN});
          this.setState({ caseReferral: nextProps.cases.createCaseObj.CD_REFR_SRCE_TYP});
          this.setState({ caseCertification: nextProps.cases.createCaseObj.CD_ENDR});
          this.setState({ hearingTypes: nextProps.cases.hearingTypesList});
          this.setState({ caseReasons: nextProps.cases.caseReasonsList});
          this.setState({ caseReferrals: nextProps.cases.caseReferralsList});
          this.setState({ caseCertifications: nextProps.cases.caseCertificationsList});
          this.setState({ value: nextProps.cases.createCaseObj.FRCaseNumber});
          this.setState({ phoneNumber: nextProps.cases.createCaseObj.PhoneNumber});
            this.props.getCustomerD26Info(nextProps.cases.createCaseObj.DLNumber);
          }
      }
      
     
      if (this.props.cases.customerD26Info !== nextProps.cases.customerD26Info) {
        this.setState({ customerD26Info: nextProps.cases.customerD26Info});
  }
}
onButtonClick = (e,value) => 
{

if(value === 'Cancel')
{
  this.props.history.push(`/customerDetails/dlNumber/${this.state.createCaseObj.DLNumber}`);
}
if(value === 'Save')
{
  const {createCaseObj} = this.state;
  createCaseObj.CD_HRNG_TYP= this.state.hearingType;
  createCaseObj.CD_RSN = this.state.caseReason;
  createCaseObj.CD_REFR_SRCE_TYP = this.state.caseReferral;
  createCaseObj.CD_ENDR = this.state.caseCertification;
  createCaseObj.FRCaseNumber = this.state.value;
   this.state.customerD26Info.Accidents.map(item =>
  {
    if(item.CaseNumber === createCaseObj.FRCaseNumber)
    {
        createCaseObj.AccidentDate = item.Date;
    }
    return "";
  })
 this.state.customerD26Info.Accidents.map(item =>
    {
      if(item.CaseNumber === createCaseObj.FRCaseNumber)
      {
        createCaseObj.AccidentCity =  item.City;
      }
      return "";
    })
    this.props.addCase(createCaseObj);
}
}
onChange = (e) => {
  this.setState({
    value: e.target.value,
  });
}

textChange(e) {
    const { createCaseObj } = this.state;
    createCaseObj.PhoneNumber = e.target.value;
    this.setState({ createCaseObj });
}

handleChange = (e,listType) => {

  if(listType === 'HRNG_TYP')
{    
 this.setState({hearingType: e});
}
if(listType === 'CASE_RSN')
{    
 this.setState({caseReason: e});
}
if(listType === 'CASE_RFL')
{    
 this.setState({caseReferral: e});
}
if(listType === 'CASE_CERT')
{    
 this.setState({caseCertification: e});
}
}

openNotification = () => {
  notification.open({
    message: 'SUCCESS',
    description: 'The case was added successfully!',
    style: {
      width: 600,
      marginLeft: 335 - 600,
      backgroundColor: "#9cd864",
      fontWeight: 'bold'
    },
  });
}

render() {

const {createCaseObj} = this.state;
let accidentsList = [];
if(this.state.customerD26Info !== undefined )
{ 
 accidentsList = getAccidentsList(this.state.customerD26Info);
}
let hearingTypesList = [], caseReasonsList = [], caseReferralsList = [], caseCertificationsList = [];
if(this.state.createCaseObj!== undefined && this.state.hearingTypes !== undefined )
{ 
  hearingTypesList = getDropdownList(this.state.hearingTypes, this.state.createCaseObj.CD_HRNG_TYP);    
}
if(this.state.createCaseObj!== undefined && this.state.caseReasons !== undefined)
{ 
  caseReasonsList = getDropdownList(this.state.caseReasons, this.state.createCaseObj.CD_RSN);    
}
if(this.state.createCaseObj!== undefined && this.state.caseReferrals !== undefined)
{ 
  caseReferralsList = getDropdownList(this.state.caseReferrals, this.state.createCaseObj.CD_REFR_SRCE_TYP);    
}
if(this.state.createCaseObj!== undefined && this.state.caseCertifications !== undefined)
{ 
  caseCertificationsList = getDropdownList(this.state.caseCertifications, "");    
}
        return (   
      <React-Fragment>
       {(createCaseObj !== undefined && caseReasonsList.length > 0 && caseReferralsList.length > 0 && caseCertificationsList.length > 0 && hearingTypesList.length > 0) ? (
       
                
          <React.Fragment> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
          <div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}><Icon type="idcard"  style={{ fontSize: 32 }}/> 
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>{createCaseObj.LastName},{createCaseObj.FirstName}</span>
            <span style={{paddingLeft: "5%", fontSize: "x-large"}}>DL#: {createCaseObj.DLNumber}</span>
            </div></div>
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Content style={{height: "600px" }}>
        <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
               <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> <div style={{
    justify: "center",
    height: "40px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 24 }}/> <span style={{fontSize: 24, paddingLeft: '0.5%'}}>Create New Case</span>
   {(this.state.createCaseObj.CaseStatusCode !== 'CL' && this.state.createCaseObj.CaseStatusCode !== 'UP') ?
   <span style={{float: "right", marginTop: "0.5%"}}><Button style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button>
      {(this.state.hearingType === null || this.state.caseReason === null || this.state.caseReferral === null || (reqRsnCodesForCerts.includes(this.state.caseReason) && this.state.caseCertification === null)) 
       ? <Tooltip
       title="Please select all values"
       placement="topLeft"
     > <Button  type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')} disabled>Save</Button> </Tooltip>
        : <Button  style={{color:  "white", backgroundColor: "green"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button>
   }
  </span> :
  <span></span>
}
</div>
       <Row type="flex" justify="space-around" >
    <Col span = {6}>
    <div style={{paddingTop: "5px"}}>
           <b>Date of Birth</b>:
        <Input value={createCaseObj.DOB} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/>          
            </div>
            <div style={{paddingTop: "10px"}}>
   <b>DL Number</b>:
  <Input value={createCaseObj.DLNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}>
       <b>License Class</b>:
        <Input value={createCaseObj.classLicense} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input value={createCaseObj.PhoneNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} maxLength="10" onChange={e => this.textChange(e)} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Mailing Address</b>:
        <TextArea rows="5" value={createCaseObj.MailingAddress} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
       </Col>
        <Col span = {6}>
        <div style={{paddingTop: "5px"}}> <b>Case Number</b>:
        <Input value="Case Number will be auto-generated" style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Received Date</b>:
        <Input value=   {moment(createCaseObj.DT_RCPT).format("MM-DD-YYYY")}
 style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>          
            <div style={{paddingTop: "10px"}}> <b>Case Status</b>:
        <Input value={createCaseObj.CaseStatus} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Hearing Type</b>:<font color="red">*</font>

          <Select id = "HT" onFocus={(e) => {
                                document.getElementById("HT").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleChange(e, 'HRNG_TYP')} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                 {hearingTypesList}
                              </Select>
      
        </div>
        <div style={{paddingTop: "10px"}}> <b>Reason</b>:<font color="red">*</font>
   
          <Select id = "REA" onFocus={(e) => {
                                document.getElementById("REA").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleChange(e, 'CASE_RSN')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseReasonsList}
                              </Select> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Referral</b>:<font color="red">*</font>

        <Select id = "REF" onFocus={(e) => {
                                document.getElementById("REF").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleChange(e, 'CASE_RFL')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                               {caseReferralsList}
                            </Select> 
        </div>
       { reqRsnCodesForCerts.includes(this.state.caseReason) && <div style={{paddingTop: "10px"}}> <b>Special Cert/Endorsement</b>:<font color="red">*</font>

          <Select id = "SCE" onFocus={(e) => {
                                document.getElementById("SCE").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} placeholder="Please select" onChange={e => this.handleChange(e, 'CASE_CERT')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseCertificationsList}
                              </Select>
        </div>
       }
            </Col>
            <Col span ={6}>
            {this.state.caseReason === "950" ?
             <div style={{ 
              width: "100%",
              height: "50%",
              marginTop: "30%",
               border: "1px solid #c9e3fa",
               borderRadius: "6px"
             }}>
    <div style={{height: "15%", backgroundColor: "#c9e3fa",textAlign: "center"}}><div style={{paddingTop: "1%"}}>FINANCIAL RESPONSIBILITIES:</div></div>
    <div style={{paddingTop: "1%", textAlign: "center"}}><b>List of Accidents:</b> </div>
    <div style={{paddingTop: "1%", paddingLeft: "10%"}}><span  style={{paddingTop: "1%", paddingLeft: "2%"}}><b>FR Case No.</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Accident Date</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Location</b></span></div>
    <div style={{paddingTop: "1%", paddingLeft: "2%",overflow:"scroll", height: "61%"}}> {(accidentsList.length > 0) ? this.state.editmode === false ? <RadioGroup name="AccidentsList" value={this.state.value} disabled>
        {accidentsList}
      </RadioGroup> :
      <RadioGroup name="AccidentsList" onChange={this.onChange} value={this.state.value}>
      {accidentsList}
    </RadioGroup>
     : "No accidents were found."
    }
</div>

          </div>
                 :
                 <React.Fragment></React.Fragment>}
           </Col>
            </Row>     
            </div>  
    </div>
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    </Row>
    </React.Fragment>
       ):<React.Fragment><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></React.Fragment>}
    {/* </ScrollPanel> */}</React-Fragment>
); 
    }
}

const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
          getCreateCaseDetails,
          getCaseCertifications,
          getCaseReasons,
          getCaseReferrals,
          getHearingTypes,
          getCustomerD26Info,
          addCase
        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AddCase));