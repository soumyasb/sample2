import React, { Component } from 'react';
import { Input, Button, Row, Col, Table, Icon } from 'antd'; 
import moment from "moment";
import cloneDeep from 'lodash/cloneDeep';
const { TextArea } = Input;

class CaseReSchedReConv extends Component {
    constructor(props) {
        super(props);
        this.schedInfoColumns = [
            {
                title: <b>Schedule Date</b>,
                dataIndex: 'ScheduleDate',
                width: '6%',
                render: item => moment(item, "MM-DD-YYYY").format("MM-DD-YYYY")            
            },
            {
                title: <b>Schedule Time</b>,
                dataIndex: 'ScheduleTime',
                width: '6%',
                render: item => moment(item, "HH:mm:ss").format("HH:mm A")                 
            },
            {
                title: <b>Location</b>,
                dataIndex: 'Location',
                width: '6%',             
            },
            {
                title: <b>Hearing Officer</b>,
                dataIndex: 'HearingOfficer',
                width: '6%',
            },{
                title: <b>Scheduled By</b>,
                dataIndex: 'ScheduledBy',
                width: '6%'          
            },{
                title: <b>Authorized By</b>,
                dataIndex: 'AuthorizedBy',
                width: '6%'         
            }
        ];

        this.state={ 
            rsrcdataObj: cloneDeep(this.props.rsrcdataObj),
            type: this.props.type
        }
        this.onCommentsTextChange = this.onCommentsTextChange.bind(this);

    }
    onCommentsTextChange(e) {
        const {rsrcdataObj} = this.state;
        rsrcdataObj.Comment = e.target.value;
      this.setState({rsrcdataObj});
    }

    render() {
        
        const {rsrcdataObj} = this.state;
        return ( <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> 
 <div style={{
    justify: "center",
    height: "40px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 24 }}/> <span style={{fontSize: 24, paddingLeft: '0.5%'}}>{this.props.type} Comments:</span></div>
<Row>
    <Row style={{paddingTop: "2%"}}><Col style={{paddingTop: "2%", paddingLeft: "2%"}} span={6}><div style={{ float: "right" }}><b>Reason for {this.props.type}:</b></div></Col><Col style={{paddingLeft: "2%"}} span={12}> <TextArea value={rsrcdataObj.Comment} rows="3" onChange={this.onCommentsTextChange} /></Col></Row>
    <Row style={{paddingTop: "2%"}}><Table style={{width: "99%", paddingLeft: "1%"}} size={"small"}
                    rowKey={record => record+Math.random().toString()}
                    showHeader={true}
                    dataSource={rsrcdataObj.schedules}
                    columns={this.schedInfoColumns} /></Row>
                    <Row style={{paddingTop: "2%"}}><Button style={{ color:  "white", backgroundColor: "red", float:"right", marginRight: "2%", width: "80px"}} type="default" key="Cancel" onClick={this.props.handleCancel}>Cancel</Button><Button style={{ color: "white", backgroundColor: "green", float:"right", marginRight: "2%", width: "80px"}} type="default" key="Ok" onClick={(e) => this.props.handleOk(this.state.rsrcdataObj)}>OK</Button> </Row>
</Row>
        </div>);
    }
}

export default CaseReSchedReConv;