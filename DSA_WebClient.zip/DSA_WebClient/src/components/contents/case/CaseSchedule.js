import React, { Component } from 'react';
import { Form, Checkbox, Select, Button, Modal, Row, Spin, Col, Table, Icon, InputNumber } from 'antd'; 
import moment from "moment"; 
import { getFormattedDate } from './../commonFuncs.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../../../dp.css';
import { withRouter } from "react-router-dom";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import {
    getCaseCoverSheet, getH6Info } from "../../../store/actions/caseActions";
import { scheduleCase, overrideCaseSchedule, getAvailableTimeSlots, getPreviousDayAvailableTimeSlots, getNextDayAvailableTimeSlots, getEmployeeCalendar, getPreviousDayEmployeeCalendar, getNextDayEmployeeCalendar, getEmployeesForScheduling, resetCaseSchedulingState, getDefaultHearingTimes } from "../../../store/actions/caseSchedulingActions";
import "../../../Cases.css";
import DemoApp from "./CalendarSchedule";
import ComponentToPrint from './CoverSheetPrintComponent';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import cloneDeep from 'lodash/cloneDeep';

const { Option } = Select;
const  FormItem  = Form.Item;
const formItemLayout = {
    labelCol: { span: 9 },
    wrapperCol: { span: 15 },
};
const defaultScheduleObj = {
    Userid: "",
    UserType: "",
    UserRequestorCode: "",
    UserNetName: "",
    UserID3Char: "",
    CaseNumber: "",
    OfficeName: "",
    OfficeId: "",
    DLNumber: "",
    SubjectName: "",
    DateReceived: "",
    Reason: "",
    ReasonDescription: "",
    HearingType: "",
    HearingTypeDescription: "",
    PhoneType: "",
    Room: "",
    StayRequired: true,
    ScheduledHearingDate: "",
    TimeSlot: {
      CaseNo: "",
      EmpId: 0,
      EmployeeName: "",
      EmployeeType: "",
      EmployeeOffice: "",
      CategoryId: 0,
      ReasonCode: "",
      HearingTime: 0,
      InterviewTime: 0,
      ReExamTime: 0,
      ScheduleDate: "",
      StartTime: "",
      EndTime: "",
      Authorized: true,
      Override: true,
      Message: "",
      Errors: [
        ""
      ]
    },
    CaseOIPs: [
      {
        NmE_FRST_PRSN: "",
        NmE_SURNME_PRSN: "",
        AgencyName: "",
        OIPType: "",
        Desc_prty_typ: "",
        OIPid: 0,
        Languages: [
          ""
        ]
      }
    ],
    Message: "",
    ErrorMessage: ""
  }

  class CaseSchedule extends Component {
    constructor(props) {
        super(props);
  this.timeSlotColumns = [
    {
        title: '',
        width: '5%',
        key: `${Math.random()}`,   
        render: (record) => {
            return (
                <div style={{textAlign: "center"}}>
                     <Button type="default" style={{ color: "white", backgroundColor: "green" }} size={"small"} onClick={e => this.selectTime(e,record)} >Select</Button>
                </div>
            );
        },
    },
            {
                title: <b>Start Time</b>,
                dataIndex: 'StartTime',
                width: '6%',
                render: item => moment(item).format("HH:mm A")            
            },
            {
                title: <b>End Time</b>,
                dataIndex: 'EndTime',
                width: '6%',
                render: item => moment(item).format("HH:mm A")                 
            },
            {
                title: <b>Status</b>,
                dataIndex: 'Status',
                width: '6%',             
            },
            {
                title: <b>Hearing Officer</b>,
                dataIndex: 'EmployeeName',
                width: '6%',
            }
        ];
        this.state={ scheduleObj: cloneDeep(defaultScheduleObj),
            selectedDate: "",
            current: 1,
            isLoading: true,
            schedStartTime: "",
            schedEndtime: "",
            calendarEvents: [],
            invalidHO: false,
            invalidDate: false,
            pickedTimeSlot: undefined,
            schedulingInProgress: false,
            picktime: true,
            openTimeSelectionModal: false,
            ErrorMessage: '',
            ErrorModalShow: false,
            showStatusModal: false,
            printH6: false,
            printCC: false,
            goToDUX: false,
            allOfficesList: this.props.allOfficesList,
            selectedOfficeId: this.props.selectedOfficeId,
            timeSearchText: this.props.timeSearchText,
            openH6Modal: false,
            overridden: false
        }
        this.onTimeChange = this.onTimeChange.bind(this);
        this.scheduleCase = this.scheduleCase.bind(this);
        this.selectTime = this.selectTime.bind(this); 
        this.print = this.print.bind(this);
        this.onSelectionChange = this.onSelectionChange.bind(this);
        this.fromCalendar = this.fromCalendar.bind(this);
    }

    componentDidUpdate(prevProps) {
        if ( prevProps.cases.caseCoverSheetObj !== this.props.cases.caseCoverSheetObj && this.props.cases.caseCoverSheetObj !== undefined) {
            this.print('printareaCS', 'CSifmcontentstoprint');    
            this.setState({caseCoverSheet: this.props.cases.caseCoverSheetObj});
        }
        if(prevProps.caseScheduling.defaultHearingTimesData !== this.props.caseScheduling.defaultHearingTimesData && this.props.caseScheduling.defaultHearingTimesData)
        {
            var defaultTime = 0;
           switch (this.props.caseScheduling.defaultHearingTimesData.DefaultTimeType[7])
           {
            case 'H':
            defaultTime = this.props.caseScheduling.defaultHearingTimesData.HearingTime;
            break;
            case 'R':
            defaultTime = this.props.caseScheduling.defaultHearingTimesData.ReExamTime;
            break;
            case 'I':
            defaultTime = this.props.caseScheduling.defaultHearingTimesData.InterviewTime;
            break;
            default:
            break;
           }
            this.setState({defaultTime: defaultTime});
        }
        if ( prevProps.cases.h6Info !== this.props.cases.h6Info && this.props.cases.h6Info !== undefined) {
            this.setState({h6Info: this.props.cases.h6Info});
        }
        if ( (prevProps.caseScheduling.modified !== this.props.caseScheduling.modified || prevProps.caseScheduling.availableTimeSlots !== this.props.caseScheduling.availableTimeSlots) && this.props.caseScheduling.availableTimeSlots !== undefined) {
           let selectedDate = this.state.selectedDate;
            if(this.state.isday === "prev")
            {
                selectedDate= moment(this.state.selectedDate, "MM-DD-YYYY").subtract(1, 'days').format("MM-DD-YYYY");
            }
            if(this.state.isday === "next")
            {
                selectedDate= moment(this.state.selectedDate, "MM-DD-YYYY").add(1, 'days').format("MM-DD-YYYY");
            }
            this.setState({availableTimeSlots: this.props.caseScheduling.availableTimeSlots, openTimeSelectionModal: true, current: 1,  isLoading: false, selectedDate: selectedDate});
        }
        if ( this.props.caseScheduling.caseSchedulingErrorData  && (prevProps.caseScheduling.caseSchedulingErrorData !== this.props.caseScheduling.caseSchedulingErrorData || prevProps.caseScheduling.emodified !== this.props.caseScheduling.emodified)) {
            if(typeof this.props.caseScheduling.caseSchedulingErrorData === 'string')
            {
                this.setState({ ErrorMessage:  this.props.caseScheduling.caseSchedulingErrorData.split(' RandomMathNumber')[0], ErrorModalShow: true});
            }
            else{
                let Errors = [];
                Object.keys(this.props.caseScheduling.caseSchedulingErrorData).map((keyName) => {
                    Errors.push(this.props.caseScheduling.caseSchedulingErrorData[keyName][0]);
                    return "";
                })
                this.setState({ ErrorObj: this.props.caseScheduling.caseSchedulingErrorData, ErrorMessage: Errors, ErrorModalShow: true });
            }  
        }
        if ( prevProps.caseScheduling.caseScheduleData !== this.props.caseScheduling.caseScheduleData && this.props.caseScheduling.caseScheduleData !== undefined && prevProps.caseScheduling.csmodified !== this.props.caseScheduling.csmodified) {
            this.setState({caseScheduleData: this.props.caseScheduling.caseScheduleData, showStatusModal: true, schedulingInProgress: false});
        }
        if ( prevProps.caseScheduling.overridden !== this.props.caseScheduling.overridden && this.props.caseScheduling.overridden !== undefined) {
            this.setState({overridden: true});
        }
        if ( prevProps.caseScheduling.hearingOfficersList !== this.props.caseScheduling.hearingOfficersList && this.props.caseScheduling.hearingOfficersList !== undefined) {
            
            this.setState({hearingOfficersList: this.props.caseScheduling.hearingOfficersList});
        }
    }

    static getDerivedStateFromProps(props, prevState) {
        const { h6Info, caseCoverSheetObj  } = props.cases;
        const {  availableTimeSlots, cmodified, modified, csmodified, caseScheduleData, caseSchedulingErrorData, employeeCalendar, hearingOfficersList} = props.caseScheduling;
        const { allOfficesList } = props.dataManager;
 
        if (availableTimeSlots && (availableTimeSlots !== prevState.availableTimeSlots || modified !== prevState.modified)) {
                return { availableTimeSlots: availableTimeSlots, modified: modified };
        }
        if (employeeCalendar && ( cmodified !== prevState.cmodified)) {
            const employeeCalendar1 = [];
             prevState.selectedHearingOfficer &&  employeeCalendar.map((ec) => {
                if(ec.Status === "(on break)")
                {
                    employeeCalendar1.push({id: ec.ID, title: ec.Status, start: ec.StartTime, end: ec.EndTime, backgroundColor: "lightgrey", textColor: "black"})
                }
                else if(ec.Status === "(Appointment)")
                {
                    employeeCalendar1.push({id: ec.ID, title: ec.Status, start: ec.StartTime, end: ec.EndTime, backgroundColor: "rgb(51, 153, 255)"})
                }
                else { employeeCalendar1.push({id: ec.ID, title: ec.Status, start: ec.StartTime, end: ec.EndTime})}
                return "";
            }); 
            return { calendarEvents: employeeCalendar1, cmodified: cmodified };
    }
    if (hearingOfficersList && hearingOfficersList !== prevState.hearingOfficersList) {
        
        return { hearingOfficersList: hearingOfficersList };
    }
        if (allOfficesList && allOfficesList !== prevState.allOfficesList) {
            return { allOfficesList: allOfficesList };
        }
        if (caseCoverSheetObj && caseCoverSheetObj !== prevState.caseCoverSheet) {
            
            return { caseCoverSheet: caseCoverSheetObj };
        }
        if (h6Info && h6Info !== prevState.h6Info) {
            return { h6Info: h6Info };
        }
        if (caseScheduleData && caseScheduleData !== prevState.caseScheduleData && csmodified !== prevState.csmodified) {
            
            return { caseScheduleData: caseScheduleData, csmodified: csmodified };
        }
        if (caseSchedulingErrorData && caseSchedulingErrorData !== prevState.caseSchedulingErrorData) return {caseSchedulingErrorData, isLoading: false };
        return null;
    }

    fromCalendar(info)
    {
        const pickedTimeSlot = {EmployeeName: "", StartTime: "", EndTime: ""};
        const {scheduleObj} = this.props; 
this.state.hearingOfficersList.map((hoff) => 
{if(hoff.Value === this.state.selectedHearingOfficer)
{
    pickedTimeSlot.EmployeeName = hoff.Text;
    pickedTimeSlot.EmpID = parseInt(hoff.Value, 10);
}
return "";
});
pickedTimeSlot.StartTime = moment(info.start,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]").format("YYYY-MM-DD[T]HH:mm:ss");
pickedTimeSlot.EndTime = moment(info.end,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]").format("YYYY-MM-DD[T]HH:mm:ss");
scheduleObj.TimeSlot = pickedTimeSlot;
this.setState({pickedTimeSlot: pickedTimeSlot, scheduleObj: scheduleObj, openCalendar: false, picktime: false});
    }

    selectTime(e,record)
    {
        const {scheduleObj} = this.props; 
        scheduleObj.TimeSlot = cloneDeep(record); 
        var defaultTimeValue = moment(moment(record.StartTime, 'YYYY-MM-DDTHH:mm:ss').add(this.state.defaultTime,"minutes")).format("hhmm");
        this.setState({pickedTimeSlot: record, scheduleObj: scheduleObj, openTimeSelectionModal: false, picktime: false, defaultTimeValue: defaultTimeValue});

    }

    print(ctype,ftype) {
        var content = document.getElementById(ctype);
        var pri = document.getElementById(ftype).contentWindow;
        pri.document.open();
        pri.document.write(content.innerHTML);
    var result = pri.document.execCommand('print', false, null);
    if(!result) {
      pri.document.close();
        pri.focus();

        pri.print();
        pri.close();
    }
        if(this.state.printH6 === false)
        {
            if( this.state.goToDUX )
            {
               this.props.goToDUX(this.state.caseScheduleData.DLNumber);
            } 
            else if (this.state.printH6 === false)
            {     this.props.uponSchedule();
        }
      }
    }

    onSelectionChange(type, value) {
if(type === "emp" )
{
    if(this.state.selectedDate)
    {
        this.props.getEmployeeCalendar(value,this.state.selectedOfficeId,moment(this.state.selectedDate).format("MM-DD-YYYY")); 
    }
    else
    {
        this.setState({invalidDate: true});
    }
}
if(type === "date")
{
    if(this.state.selectedHearingOfficer)
    {
    this.props.getEmployeeCalendar(this.state.selectedHearingOfficer,this.state.selectedOfficeId,moment(value).format("MM-DD-YYYY")); 
}
else{
    this.setState({invalidHO: true});
}
    }
}

      scheduleCase(e) {
        
        const {scheduleObj} = this.state;
        scheduleObj.TimeSlot.ScheduleDate =  moment(this.state.selectedDate, 'MM-DD-YYYY').toISOString();
        scheduleObj.ScheduledHearingDate =  moment(this.state.selectedDate, 'MM-DD-YYYY').toISOString();
        scheduleObj.TimeSlot.StartTime = moment(scheduleObj.TimeSlot.ScheduleDate, 'YYYY-MM-DDTHH:mm:ss').format('YYYY-MM-DD')+'T'+moment(scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss').format('HH:mm:ss');
        scheduleObj.TimeSlot.EndTime = moment(scheduleObj.TimeSlot.ScheduleDate, 'YYYY-MM-DDTHH:mm:ss').format('YYYY-MM-DD')+'T'+moment(scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss').format('HH:mm:ss');
        this.setState({scheduleObj});
        this.props.scheduleCase(scheduleObj);
        
    }

 onH6ModalOK()
 {
    if(this.state.goToDUX)
    {
        
        this.props.goToDUX(this.state.caseScheduleData.DLNumber);
    }
    else
    {
        this.props.uponSchedule();
    }
    this.setState({openH6Modal: false});
 }

    onTimeChange(e, type) {
        
        const scheduleObj  = cloneDeep(this.state.scheduleObj);
if(type === 'start')
{
    if(parseInt(moment(scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss A').format('hhmm'), 10) > e)
    {
        scheduleObj.TimeSlot.StartTime = moment(scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss A').subtract(15, 'minutes').format('YYYY-MM-DDTHH:mm:ss A');
    }
    else if(parseInt(moment(scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss A').format('hhmm'), 10) < e)
    {
        scheduleObj.TimeSlot.StartTime = moment(scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss A').add(15, 'minutes').format('YYYY-MM-DDTHH:mm:ss A');
    }
}
if(type === 'end')
{
    
    if(parseInt(moment(scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss A').format('hhmm'), 10) > e)
    {
        scheduleObj.TimeSlot.EndTime = moment(scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss A').subtract(15, 'minutes').format('YYYY-MM-DDTHH:mm:ss A');
    }
    else if(parseInt(moment(scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss A').format('hhmm'), 10) < e)
    {
        scheduleObj.TimeSlot.EndTime = moment(scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss A').add(15, 'minutes').format('YYYY-MM-DDTHH:mm:ss A');
    }
}
if(moment(scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss A').format('hhmm')-moment(scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss A').format('hhmm') < 15)
{this.setState({ErrorModalShow: true, ErrorMessage: "Time slot should be minimum of 15 minutes!"});}
else
{
    this.setState({scheduleObj});
}  
    }

    render() {
        const {caseInfo} = this.props;
        return (
            <div>
<Modal title={<h1>Employee's Calendar</h1>} width={'80%'} maskClosable={false} visible={this.state.openCalendar} onCancel={(e) => this.setState({openCalendar: false})} 
       footer={[
        <div key={Math.random()}>
            <Button style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} type="default" key="Ok" onClick={(e) => this.setState({ openCalendar: false})}>Close</Button>
        </div>
    ]}
><Row>
<Col span={6} ><Form layout={'vertical'}>
<FormItem
                     validateStatus = {(this.state.selectedHearingOfficer === undefined) && this.state.invalidHO ? 'error' : ""}
                     help = {(this.state.selectedHearingOfficer === undefined) && this.state.invalidHO ? 'Please select a hearing officer!' : ""}
                         label={<b>Select a Hearing Officer:  <font color="red">*</font></b>}
                    {...formItemLayout}
                ><Select id = "SHO" onFocus={(e) => {
                    document.getElementById("SHO").click();
                                                           }} showSearch optionFilterProp= "children" filterOption = {true} value={this.state.selectedHearingOfficer} placeholder="--Select--" showArrow={true} 
size={"default"} style={this.state.invalidHO ? {backgroundColor: "lightred", borderColor: "red", width: "100%"}:{ width: '100%' }} onChange={(e) => { this.setState({instance: Math.random(), selectedHearingOfficer: e});
this.onSelectionChange("emp", e);
// 
}}>                                  
 {this.state.hearingOfficersList && this.state.hearingOfficersList.map(hoff => <Option key={hoff.Value} value={hoff.Value}>{hoff.Value} - {hoff.Text}</Option>)}
</Select></FormItem><FormItem
   validateStatus = {!this.state.selectedDate && this.state.invalidDate ? 'error' : ""}
   help = {!this.state.selectedDate && this.state.invalidDate ? 'Please select a date!' : ""}
label={<b>Pick a Date:  <font color="red">*</font></b>}
                    {...formItemLayout}>
      <DatePicker
      className={this.state.invalidDate ? "CalClassErr":"CalClass"}
                             selected={this.state.selectedDate !== "" ? this.state.selectedDate: null}
                             dateFormat={"MM-dd-yyyy"}
                             onChange={(d) => {this.setState({instance: Math.random(), invalidDate: false, selectedDate: d}); this.onSelectionChange('date', d)}}
                             isClearable={true}
                             placeholderText="Select Date"
                           />
</FormItem></Form>
<div style={{paddingTop: "20%"}}><div style={{border: "1px solid red"}}><font color="red">*</font><b>Note:</b> <br/>Please click and drag accross multiple slots to select longer time slot for scheduling.</div></div>
</Col>
<Col span={15} style={{paddingLeft: "10%"}}>
<div title="Click and drag across multiple slots to select longer time slot."><DemoApp
validateHO={() => {this.setState({invalidHO: true})}}
selectedHO={this.state.selectedHearingOfficer} getDate={(e) => {
this.props.getEmployeeCalendar(this.state.selectedHearingOfficer,this.state.selectedOfficeId,moment(e,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]").format("MM-DD-YYYY"));
    this.setState({selectedDate: moment(e,"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]").format("MM-DD-YYYY")});}} key={this.state.instance} fromCalendar={(e) => {
this.fromCalendar(e);
}
     } calendarEvents={this.state.selectedHearingOfficer ? this.state.calendarEvents : []} Date={this.state.selectedDate !== "" ? this.state.selectedDate : null}/>
</div></Col>
</Row></Modal>
{this.state.caseCoverSheet && this.state.caseScheduleData && <div id='printareaCS' > 
<iframe title="CSifmcontentstoprint" id="CSifmcontentstoprint" style={{
height: '100%',
opacity: '0',
width: '100%',
border: 'none',
position: 'absolute'
}}></iframe>  
<div class="print-only">{this.state.caseCoverSheet && <ComponentToPrint caseNumber={this.state.caseScheduleData.CaseNumber} coversheetJson={this.state.caseCoverSheet} />}</div>
</div>}
{this.state.h6Info && <Modal width="900px" title={"DAD H6 Information"}
visible={this.state.openH6Modal}
onCancel={(e) => {this.onH6ModalOK();}}
footer = { [
<Button type="primary" key="Ok" onClick={(e) => {
this.onH6ModalOK();
}
}>Ok</Button>
]}> <div>{this.state.h6Info ? <div>{(this.state.h6Info.DLInq.length > 0) ? <div>
<Button style={{ marginLeft:'45%'}} type="primary" onClick = {(e) => this.print('printareaH6','H6ifmcontentstoprint')}><Icon type="printer" theme="outlined" />Print this page</Button> <ScrollPanel  style={{
height: "500px"
}}>      <div id='printareaH6'> 
<iframe title="H6ifmcontentstoprint" id="H6ifmcontentstoprint" style={{
height: '0px',
width: '0px',
position: 'absolute'
}}></iframe><pre><div dangerouslySetInnerHTML={{ __html: this.state.h6Info.DLInq[0].toString()}}/></pre>
</div>
</ScrollPanel>
</div>:<div>No DAD H6 info found.</div>                           
}</div>: <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>}</div> </Modal>}
{caseInfo && caseInfo.CaseNumber === this.props.selectedCase && <div><h1>Case Information for {this.props.selectedCase}</h1>    
<Row><Col span={14}><div style={{ paddingLeft: '5%'}}><Row><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={6}><b>DL Number: </b></Col><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={8}>{caseInfo.DLNumber}</Col></Row></div>
<div style={{ paddingLeft: '5%', paddingTop: '1%'}}><Row><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={6}><b>Subject Name: </b></Col><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={8}>{caseInfo.SubjectName}</Col></Row></div>
<div style={{ paddingLeft: '5%', paddingTop: '1%'}}><Row><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={6}><b>Date Received: </b></Col><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={8}>{caseInfo.DateReceived}</Col></Row></div>
<div style={{ paddingLeft: '5%', paddingTop: '1%'}}><Row><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={6}><b>Reason: </b></Col><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={8}>{caseInfo.Reason}</Col></Row></div>
<div style={{ paddingLeft: '5%', paddingTop: '1%'}}><Row><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={6}><b>Hearing Type: </b></Col><Col style={{ paddingLeft: '3%', border: "1px solid rgb(232, 232, 232)"}} span={8}>{caseInfo.HearingType}</Col></Row></div></Col>   
<Col span={8}><div><b>Other Interested Parties:</b></div>
{caseInfo.CaseOIPs && caseInfo.CaseOIPs.length > 0 ? <div>{caseInfo.CaseOIPs.map((item,index) => <div key={index}>{item.NME_SURNME_PRSN !== "" && item.NME_SURNME_PRSN !== null ? item.NME_SURNME_PRSN: ""}{item.NME_FRST_PRSN !== "" && item.NME_FRST_PRSN !== null ? `, ${item.NME_FRST_PRSN} - `: ''} {item.AgencyName !== " " && item.AgencyName !== null ? `${item.AgencyName} - `: ``}{item.desc_prty_typ}</div>)}</div>: <div>No OIPs on this case.</div>}</Col></Row>    
<br /> {this.state.picktime && <div style={{ 
border: "1px solid black"}}>{this.state.calendarView && <div><Row style={{ paddingLeft: '5%', paddingTop: '1%'}}> <h3>Select a Hearing Officer:  </h3></Row><Row style={{ paddingLeft: '5%', paddingTop: '1%', width: '40%'}}><Select id = "SHO2" onFocus={(e) => {
    document.getElementById("SHO2").click();
                                           }} showSearch optionFilterProp= "children" filterOption = {true} value={this.state.selectedHearingOfficer} placeholder="--Select--" showArrow={true} 
size={"default"} style={{ width: '100%' }} onChange={(e) => {this.setState({selectedHearingOfficer: e});
this.props.getEmployeeCalendar(e,this.state.selectedOfficeId,this.state.ScheduleDate)}}>                                         
{this.state.allEmployeesList && this.state.allEmployeesList.map(emp => <Option key={emp.EmpID} value={emp.EmpID}>{emp.EmpID} - {emp.Name}</Option>)}
</Select></Row></div>}
<Row style={{ paddingLeft: '5%', paddingTop: '1%'}}> <h3>Pick an office (Default to Employee's office):  </h3></Row><Row style={{ paddingLeft: '5%', paddingTop: '1%', width: '40%'}}><Select id = "SO" onFocus={(e) => {
                                document.getElementById("SO").click();
                                                                       }} showSearch optionFilterProp= "children" filterOption = {true} value={this.state.selectedOfficeId} placeholder="Select Office" showArrow={true} 
size={"default"} style={{ width: '100%' }} onChange={(e) => {this.setState({selectedOfficeId: e});
}}>                                         
 {this.state.allOfficesList && this.state.allOfficesList.map(off => <Option key={off.OfficeID} value={off.OfficeID}>{off.OfficeID} - {off.Name}</Option>)}
</Select></Row>
<Row style={{ paddingLeft: '5%', paddingTop: '1%'}}> <h3>Pick a Date:  </h3></Row><Row style={{ paddingLeft: '5%', paddingTop: '1%'}}>    

 <DatePicker
                             className = "CalClass"
                             style={{lineHeight : "20px"}}
                             selected={this.state.selectedDate !== "" ? this.state.selectedDate: null}
                             dateFormat={"MM-dd-yyyy"}
                             onChange={(d) => {this.setState({instance: Math.random(), selectedDate: d});}}
                             isClearable={true}
                             placeholderText="Select Date"
                           />
</Row>
<Row style={{ paddingLeft: '5%', paddingTop: '3%', paddingBottom: '1%'}}> 

 <Button type="primary" onClick={e => {
     this.setState({isLoading: true}); 
     this.props.getDefaultHearingTimes(this.props.selectedCase);
     this.props.getAvailableTimeSlots(this.state.selectedOfficeId, moment(this.state.selectedDate,"MM-DD-YYYY").format("YYYY-MM-DD[T]HH:mm:ss"))}} > {this.state.timeSearchText} </Button>
 
 </Row><br/></div>}

{this.state.picktime === false && this.state.pickedTimeSlot && <div style={{ 
border: "1px solid black"}}><Row style={{ paddingLeft: '5%', paddingTop: '1%'}}><div style={{float: 'left', width: '300px'}}><h3>The following time slot is selected:</h3></div><div style={{float: 'right'}}><Button type="default" size="small" onClick={(e) => {this.setState({picktime: true, pickedTimeSlot: undefined, timeSearchText: "Find Available Time Slots"})}}><font color="blue">Pick Another TimeSlot</font></Button></div></Row><Row><Col style={{ paddingLeft: '3%', paddingTop: '1%'}} span={6}><b>Office: </b></Col><Col style={{ paddingLeft: '3%'}} span={8}>{this.state.allOfficesList && this.state.allOfficesList.map((off) => {
if(off.OfficeID === this.state.selectedOfficeId)
{
return off.Name;
}
return "";
})}</Col></Row>
<Row><Col style={{ paddingLeft: '3%', paddingTop: '1%'}} span={6}><b>Hearing Officer: </b></Col><Col style={{ paddingLeft: '3%'}} span={8}>{this.state.pickedTimeSlot.EmployeeName}</Col></Row>
<Row><Col style={{ paddingLeft: '3%', paddingTop: '1%'}} span={6}><b>Schedule Date: </b></Col><Col style={{ paddingLeft: '3%'}} span={8}>{this.state.selectedDate && getFormattedDate(this.state.selectedDate)}</Col><Col span={4} offset={2}>{this.state.schedulingInProgress === false ? <Button  type="primary" key="OK" style={{backgroundColor: "green", color: "white"}} onClick={(e) => {this.scheduleCase(e); this.setState({schedulingInProgress: true});}}><Icon type="check" />Schedule Case</Button>:<div><Spin size="large" /> <span style={{ paddingLeft: "2%" }}><font size="large">Processing...</font></span></div>}</Col></Row>
<Row><Col style={{ paddingLeft: '3%', paddingTop: '1%'}} span={6}><b>Start Time Slot: </b></Col><Col style={{ paddingLeft: '3%'}} span={8}><InputNumber 
formatter={value => `${value}`.length === 3 ? `0${value}`.replace(/\B(?=(\d{2})+(?!\d))/g, ':') : `${value}`.replace(/\B(?=(\d{2})+(?!\d))/g, ':')}  
parser={value => value.replace(/\$\s?|(:*)/g, '')}
min={moment(this.state.pickedTimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss').format('hhmm')}
value={moment(this.state.scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss').format('hhmm')} 
max={moment(this.state.pickedTimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss').format('hhmm')} 
step={15} onChange={(e) =>{ this.onTimeChange(e, 'start')}}></InputNumber>{" "}
<b>{moment(this.state.scheduleObj.TimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss A').format('A')}</b></Col></Row>
<Row><Col style={{ paddingLeft: '3%', paddingTop: '1%'}} span={6}><b>End Time Slot: </b></Col><Col style={{ paddingLeft: '3%'}} span={8}><InputNumber 
formatter={value => `${value}`.length === 3 ? `0${value}`.replace(/\B(?=(\d{2})+(?!\d))/g, ':') : `${value}`.replace(/\B(?=(\d{2})+(?!\d))/g, ':')}
parser={value => value.replace(/\$\s?|(:*)/g, '')}
onBlur= {(e) => {}} min={moment(this.state.pickedTimeSlot.StartTime, 'YYYY-MM-DDTHH:mm:ss').format('hhmm')} defaultValue={this.state.defaultTimeValue} max={moment(this.state.pickedTimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss').format('hhmm')} step={15} onChange={(e) => this.onTimeChange(e, 'end')}></InputNumber>{" "}<b>{moment(this.state.scheduleObj.TimeSlot.EndTime, 'YYYY-MM-DDTHH:mm:ss A').format('A')}</b></Col></Row><br/></div>}</div>}   
<br />
<br />
{this.props.type !== 'casedetail' && <Button type="primary" style={{marginLeft: "5%"}} onClick={(e) => this.props.closeModal()}><Icon type="arrow-left" />Back to Case List</Button>}
<Button style={{marginLeft: "5%"}} type="primary" onClick={e => {      if(this.state.hearingOfficersList === undefined)
    {
        this.props.resetCaseSchedulingState();
        this.props.getEmployeesForScheduling(this.state.selectedOfficeId); }
        if(this.state.selectedDate === "" || !this.state.selectedDate)
        {
            this.setState({openCalendar: true, selectedDate: this.state.selectedDate, instance: Math.random(), calendarEvents: []});
        }
        else
        {
            this.setState({openCalendar: true, instance: Math.random() });
        }
    }
        
    }
    ><Icon type="calendar" />Calendar View</Button>    

{this.state.caseScheduleData && <Modal visible={this.state.showStatusModal}
title={ 
    this.state.caseScheduleData.Error ? "Error" : this.state.caseScheduleData.Message === null ? 'Warning' : "Success"
} maskClosable={false}
footer={[
(this.state.caseScheduleData.TimeSlot.Override && this.state.caseScheduleData.Error !== true && this.state.overridden !== true) ? <div>
<Button type="primary" key="Ok" onClick={(e) => {
this.props.overrideCaseSchedule(this.state.caseScheduleData);
this.setState({ showStatusModal: false, overridden: true });}}>Override</Button>
<Button type="default" key="Cancel" onClick={(e) => {
this.setState({ showStatusModal: false });}}>Cancel</Button>
</div>: <div>
<Button type="primary" key="Ok" onClick={(e) => {
let openH6Modal = false;
if(this.state.caseScheduleData && this.state.caseScheduleData.Room !== null && this.state.caseScheduleData.Room !== "" && (this.state.caseScheduleData.TimeSlot.Errors === null || this.state.caseScheduleData.TimeSlot.Errors.length === 0) && this.state.caseScheduleData.Error !== true)
{ 
    if(this.state.printCC)
    {
            this.props.getCaseCoverSheet(this.props.selectedCase);       
    }
if(this.state.printH6)
{
    
this.props.getH6Info(this.state.caseScheduleData.DLNumber);
openH6Modal = true;
}
if(!this.state.printCC && !this.state.printH6 && this.state.goToDUX)
{
       this.props.goToDUX(this.state.caseScheduleData.DLNumber);
}
if(!this.state.printCC && !this.state.printH6 && !this.state.goToDUX)
{
    this.props.uponSchedule();
}
}
this.setState({ showStatusModal: false, openH6Modal: openH6Modal, overridden: false });}}>Ok</Button>
</div>
]}
>

{(this.state.caseScheduleData.Message !== null && this.state.caseScheduleData.Message !== "" && this.state.caseScheduleData.Message.includes(' Ok')) && <div>Case is scheduled successfully! <br/> Please select further actions: 
<Checkbox onChange={(e) => this.setState({printCC: e.target.checked})}>Print Case Coversheet</Checkbox>
<Checkbox onChange={(e) => this.setState({printH6: e.target.checked})}>Print DAD/H6</Checkbox>
{this.state.caseScheduleData.StayRequired && <Checkbox onChange={(e) => this.setState({goToDUX: e.target.checked})}>Go to DUX End Stay screen</Checkbox>} </div>} <div>{this.state.caseScheduleData.ErrorMessage !== null && this.state.caseScheduleData.ErrorMessage !== "" && this.state.caseScheduleData.Error && <div dangerouslySetInnerHTML={{ __html: this.state.caseScheduleData.ErrorMessage}}/>}</div>
{ this.state.caseScheduleData.TimeSlot.Message !== null && this.state.caseScheduleData.TimeSlot.Message !== "" && <div>{this.state.caseScheduleData.TimeSlot.Message}</div>}
{ this.state.caseScheduleData.TimeSlot.Errors !== null && this.state.caseScheduleData.TimeSlot.Errors.length !== 0 && <ul>{this.state.caseScheduleData.TimeSlot.Errors.map((item) => {return <li>{item}</li>})}</ul>}
</Modal>}
<Modal visible={this.state.ErrorModalShow}
title={'Error Message'} maskClosable={false}
footer={[
<div key={`${Math.random()}`}>
<Button type="primary" key="Ok" onClick={(e) => 
{
this.setState({ErrorModalShow: false, schedulingInProgress: false, calendarEvents: [] });

}}>OK</Button>
</div>
]}
>
{this.state.ErrorMessage && (typeof this.state.ErrorMessage === 'object') ?
<ul><font color='red'>{this.state.ErrorMessage.map((item) => <li>{item}</li>)}</font></ul>
: <div><font color= 'red'>{this.state.ErrorMessage}</font></div>}
</Modal>
<Modal width="1000px"
footer = { [
<div key={`${Math.random()}`}>
<Button type="primary" key="Cancel" style={{backgroundColor: "red", color: "white"}} onClick={(e) => this.setState({openTimeSelectionModal: false})}> Close </Button> 
</div>
]}

title={<h3>Select Available Time for <b>{moment(this.state.selectedDate,"MM-DD-YYYY").format('dddd, D MMMM, YYYY')}</b> at the <b>{this.state.allOfficesList && this.state.allOfficesList.map((off) => {
if(off.OfficeID === this.state.selectedOfficeId)
{
return off.Name;
}
return "";
})}</b> office.</h3>} maskClosable={false} visible={this.state.openTimeSelectionModal}
onCancel={(e) => this.setState({openTimeSelectionModal: false})}>

{this.state.isLoading ?  <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading...</font></span></div>: this.state.availableTimeSlots && this.state.availableTimeSlots.length > 0 ? <Table size= {"small"}
rowKey = {record => record+Math.random().toString()}
showHeader = {true}
dataSource={this.state.availableTimeSlots}
columns={this.timeSlotColumns}
pagination={{ pageSize: 10, current: this.state.current, onChange:(e) =>this.setState({current : e})}}
/> : <b>No available time slots for the selected date : {this.state.selectedDate}</b>}
<Button type="primary" style={{marginLeft: "5%"}} onClick={e => {this.setState({isday: "prev", isLoading: true}); this.props.getPreviousDayAvailableTimeSlots(this.state.selectedOfficeId, moment(this.state.selectedDate,"MM-DD-YYYY").format("YYYY-MM-DD[T]HH:mm:ss"))}}><Icon type="double-left" />Previous Date</Button><Button style={{marginLeft: "5%"}} type="primary" onClick={e => {this.setState({isday: "next", isLoading: true}); this.props.getNextDayAvailableTimeSlots(this.state.selectedOfficeId, moment(this.state.selectedDate, "MM-DD-YYYY").format("YYYY-MM-DD[T]HH:mm:ss"))}}><Icon type="double-right" />Next Date</Button>
</Modal>
</div>
     );
    }    
    }

        
const mapStateToProps = state => {
    return {
       cases: state.cases,
       dataManager: state.dataManager,
       caseScheduling: state.caseScheduling,
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getH6Info, scheduleCase, overrideCaseSchedule, getAvailableTimeSlots, getPreviousDayAvailableTimeSlots, getNextDayAvailableTimeSlots, getCaseCoverSheet, getEmployeeCalendar, getPreviousDayEmployeeCalendar, getNextDayEmployeeCalendar, getEmployeesForScheduling, resetCaseSchedulingState, getDefaultHearingTimes
        },
        dispatch
    );
};

    export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CaseSchedule));