import React, { Component } from 'react';
import { getScheduledCases } from "../../../store/actions/caseActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, Table, Tooltip, Spin } from 'antd'; 
import moment from "moment"; 


class ScheduledCases extends Component {
    constructor(props) {
        super(props);

        this.state={
            scheduledCasesList: this.props.cases.scheduledCasesList
        };
    }    
componentDidMount()
{
    if(sessionStorage.getItem('userInfo')){
       var officeId = JSON.parse(sessionStorage.getItem('userInfo')).OfficeId;
        this.props.getScheduledCases(officeId,8); // API Call
    }
}

componentDidUpdate(prevProps) {
    if ( prevProps.cases.scheduledCasesList !== this.props.cases.scheduledCasesList && this.props.cases.scheduledCasesList !== undefined) {
        this.setState({scheduledCasesList: this.props.cases.scheduledCasesList});
    }
    if ( prevProps.homePage !== this.props.homePage && this.props.homePage !== undefined) {
        this.setState({selectedOfficeId: this.props.homePage.OfficeId});
        this.props.getScheduledCases(this.props.homePage.OfficeId,8);
    }
}
static getDerivedStateFromProps(props, prevState) {
    const { scheduledCasesList } = props.cases;
    if (scheduledCasesList && scheduledCasesList !== prevState.scheduledCasesList) {
        return { scheduledCasesList: scheduledCasesList };
    }
    return null;
}

    render() {
        const columns =[
            {
                title: <b>Case Status</b>,
                dataIndex: 'CD_STATUS_REC',
                render: (text) => 
                   {
                    let title="";   
                    switch (text)
                    {
                        case 'SC':
                        title = "Scheduled";
                        break;
                        case 'RC':
                        title = "Reconvene Scheduled";
                        break;
                        case 'RS':
                        title = "Rescheduled";
                        break;
                        case "RSC":
                        title = "2011 Contact";
                        break;
                        default:
                        title = "";
                        break;                    
                    }
                return <Tooltip title={title}>{text}</Tooltip>
                   },
                sorter: (a, b) => { return a.CD_STATUS_REC.localeCompare(b.CD_STATUS_REC)}
            }, {
                title: <b>Subject Name</b>,
                render: (record) => (
                    <span>
                        {`${record.PersonFirstName} ${record.PersonLastName}`}
                    </span>
                ),
                sorter: (a, b) => { 
                                        const driverNameA = a.PersonFirstName + ' ' + a.PersonLastName; 
                                         const driverNameB = b.PersonFirstName + ' ' + b.PersonLastName; 
                  
                                    return driverNameA.trim().localeCompare(driverNameB.trim()); 
                                   } 
                  

            }, {
                title: <b>DL#</b>,
                dataIndex: 'NBR_DL',
                sorter: (a, b) => { return a.NBR_DL.localeCompare(b.NBR_DL)}
            }, {
                title: <b>Case#</b>,
                dataIndex: 'CD_CASE',
                key: 'CD_CASE',
                sorter: (a, b) => { return a.CD_CASE.localeCompare(b.CD_CASE)},
                render: (item) => {
                    return <div tabIndex="0" onFocus={(e) => this.setState({selectedRow : item})}>{item}</div>
                }
            }, {
                title: <b>Reason</b>,
                dataIndex: 'CD_RSN',
                sorter: (a, b) => { return a.CD_RSN.localeCompare(b.CD_RSN)}
            }, 
            {
                title: <b>Type Hearing</b>,
                dataIndex: 'CD_HRNG_TYP',
                sorter: (a, b) => { return a.CD_HRNG_TYP.localeCompare(b.CD_HRNG_TYP)}
            }, {
                title: <b>Hearing Date</b>,
                dataIndex: 'dt_Cntct_Strt_Tim',
                key: Math.random(),
                render: (text) => moment(text).format("MM-DD-YY"),
                sorter: (a, b) => { return a.dt_Cntct_Strt_Tim.localeCompare(b.dt_Cntct_Strt_Tim)}
            }, {
                title: <b>Schedule Time</b>,
                dataIndex: 'dt_Cntct_Strt_Tim',
                render: (text) => moment(text).format('hh:mm A')
            }, {
                title: <b>Hearing Officer</b>,
                render: (record) => (
                    <span>
                        {`${record.EmployeeFirstName} ${record.EmployeeLastName}`}
                    </span>
                ),
                sorter: (a, b) => { 
                                         const employeeNameA = a.EmployeeFirstName + ' ' + a.EmployeeLastName; 
                                        const employeeNameB = b.EmployeeFirstName + ' ' + b.EmployeeLastName; 
                     
                                        return employeeNameA.localeCompare(employeeNameB); 
                                     } 
                  
            }
        ];

        const boxShadows = {
            boxShadow:
              "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
        };

    return (
    <React-Fragment>
                            <Row>
                            <Col span={24}>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.scheduledCasesList ? <Table tabIndex="0"
                                        rowKey='CD_CASE'
                                        title={() => <div><span><h1>Scheduled Cases</h1></span></div>} 
                                        footer={() => <b>{this.state.scheduledCasesList.length} cases scheduled.</b>} 
                                        showHeader 
                                        size="middle"
                                        rowClassName={(record) => {if(record.CD_CASE === this.state.selectedRow){
                                            return "selectedRowClass"
                                        }}}
                                        onRow={(record) => ({
                                            onClick: () => {                                                                        
                                                    this.props.history.push(
                                                        { pathname: `/caseDetails/CaseNumber/${record.CD_CASE}`,
                                                        state: { dlNumber: record.NBR_DL}
                                                    });                                                           
                                            }                                         
                                        }) }
                                        columns={columns} 
                                        dataSource={this.state.scheduledCasesList}
                                        pagination={{ pageSize: 8 }} />
                                        : <div><span style={{ paddingLeft: "40%" }}> <Spin size="large" /> </span><span style={{ paddingLeft: "2%" }}><font size="large">Loading data...</font></span></div>
                                    }
                                </Card>
                            </Col>
                        </Row>
                   </React-Fragment>
                   );
}    
}

    
const mapStateToProps = state => {
    return {
       cases: state.cases,
       homePage: state.homePage
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getScheduledCases
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ScheduledCases);