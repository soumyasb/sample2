import React, {Component} from "react";
import Timeline, { TimelineHeaders, SidebarHeader, DateHeader } from 'react-calendar-timeline';
// import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import 'react-calendar-timeline/lib/Timeline.css';
import { withRouter } from "react-router-dom";
import Moment from "moment";
import { extendMoment } from 'moment-range';
import cloneDeep from 'lodash/cloneDeep';
import "../../../Calendars.css";

const moment = extendMoment(Moment);
const calcRange = (t1, t2) => 
{
  return moment.range([moment(t1, 'h:mm A'), moment(t2, "h:mm A")]);
}
const getGroups = (data) =>
{
  let groups = [];
  data.map((item) => 
  {
    groups.push({id: item.EmpID, title: item.EmployeeName, role: item.EmployeeRole, LoanLocation: item.LoanLocation});
    return "";
  });
  return groups;
}
const getItems = (data) =>
{
  let items = [];
          data.map((eitem) => {
            let stime = eitem.Timeslots[0].StartTime, etime = eitem.Timeslots[0].EndTime;
            let imatch =  eitem.Timeslots.filter(e => e.StartTime === stime && e.EndTime === etime);
           let formattedTitle = "";
            if(eitem.Timeslots.length > 1 && imatch.length < 2 ){
              while(moment(stime, "h:mm A").isBefore(moment(etime, "h:mm A"))){  
                let range1 = calcRange(stime,moment(stime, "h:mm A").add(1, 'hours').format("h:mm A"));
                let counter = 1, indexA = [];
                let oCounter = 0;
                eitem.Timeslots.map((ts,index) => {
                    if(index !== 0)
                    {
                  let range2 = calcRange(ts.StartTime, ts.EndTime); 
                  if(range2.overlaps(range1))
                  {
                   oCounter++;
                   indexA.push(index);
                  }                               
                  else
                  {
                    counter++;
                  }
                  }
       
                  return "";
                  });
                            if(counter === eitem.Timeslots.length)
                  {
                    items.push(
                      {
                      id: Math.random(), group: eitem.EmpID, title: "", start_time: moment(stime, "h:mm A"), end_time: moment(moment(stime, "h:mm A").add(1, 'hours').format("h:mm A"), "h:mm A"),
                        canMove: false,
                        canResize: false,
                        canChangeGroup: false,
                        style: {
                          backgroundColor: "white"
                        }
                    })
                  }
                  if(oCounter === 1)
                  {
                    let range2 = calcRange(eitem.Timeslots[indexA[0]].StartTime, eitem.Timeslots[indexA[0]].EndTime); 
                    let formattedTitle = eitem.Timeslots[indexA[0]].SlotType.includes('on-loan') ? "Employee on loan at "+eitem.LoanLocation : eitem.Timeslots[indexA[0]].Appointment ? eitem.Timeslots[indexA[0]].SlotType+"\n Employee Name: "+eitem.Timeslots[indexA[0]].Appointment.EmployeeName+"\n Start Time: "+eitem.Timeslots[indexA[0]].Appointment.StartTime+"\n End Time: "+eitem.Timeslots[indexA[0]].Appointment.EndTime+"\n Activity: "+eitem.Timeslots[indexA[0]].Appointment.ActivityType : eitem.Timeslots[indexA[0]].CaseInfo ? eitem.Timeslots[indexA[0]].SlotType+"\n Employee Name: "+eitem.EmployeeName+"\n Case Number: "+eitem.Timeslots[indexA[0]].CaseInfo.CaseNumber+"\n DL Number: "+eitem.Timeslots[indexA[0]].CaseInfo.DLNumber+"\n Subject Name: "+eitem.Timeslots[indexA[0]].CaseInfo.SubjectName+"\n Hearing Type: "+eitem.Timeslots[indexA[0]].CaseInfo.HearingType+"\n Reason Code: "+eitem.Timeslots[indexA[0]].CaseInfo.ReasonCode+"\n Scheduled By: "+eitem.Timeslots[indexA[0]].CaseInfo.ScheduledBy+" \n Location: "+eitem.Timeslots[indexA[0]].CaseInfo.Location : eitem.Timeslots[indexA[0]].SlotType;
                    items.push({id: Math.random(), group: eitem.EmpID, title: formattedTitle, start_time: moment(eitem.Timeslots[indexA[0]].StartTime, 'h:mm A'), end_time: moment(eitem.Timeslots[indexA[0]].EndTime, 'h:mm A'),
                    canMove: false,
                    canResize: false,
                    canChangeGroup: false,
                    style: {
                    backgroundColor: eitem.Timeslots[indexA[0]].SlotColor
                    }});
                    let diff;
                    if(range1>range2)
                    {
                  diff = range1.subtract(range2);                
                      diff.map((ditem) =>
                      {
                        items.push(
                        {
                        id: Math.random(), group: eitem.EmpID, title: "", start_time: moment(ditem.start,"h:mm A"), end_time: moment(ditem.end,"h:mm A"),
                          canMove: false,
                          canResize: false,
                          canChangeGroup: false,
                          style: {
                            backgroundColor: "white"
                          }
                      })
                      return "";
                    }
                    );                                 
                    }
                  }
                  if(oCounter > 1)
                  {let diff;
                  indexA.map((indItem) => 
                  { 
                    let formattedTitle = eitem.Timeslots[indItem].SlotType.includes('on-loan') ? "Employee on loan at "+eitem.LoanLocation : eitem.Timeslots[indItem].Appointment ? eitem.Timeslots[indItem].SlotType+"\n Employee Name: "+eitem.Timeslots[indItem].Appointment.EmployeeName+"\n Start Time: "+eitem.Timeslots[indItem].Appointment.StartTime+"\n End Time: "+eitem.Timeslots[indItem].Appointment.EndTime+"\n Activity: "+eitem.Timeslots[indItem].Appointment.ActivityType : eitem.Timeslots[indItem].CaseInfo ? eitem.Timeslots[indItem].SlotType+"\n Employee Name: "+eitem.EmployeeName+"\n Case Number: "+eitem.Timeslots[indItem].CaseInfo.CaseNumber+"\n DL Number: "+eitem.Timeslots[indItem].CaseInfo.DLNumber+"\n Subject Name: "+eitem.Timeslots[indItem].CaseInfo.SubjectName+"\n Hearing Type: "+eitem.Timeslots[indItem].CaseInfo.HearingType+"\n Reason Code: "+eitem.Timeslots[indItem].CaseInfo.ReasonCode+"\n Scheduled By: "+eitem.Timeslots[indItem].CaseInfo.ScheduledBy+" \n Location: "+eitem.Timeslots[indItem].CaseInfo.Location : eitem.Timeslots[indItem].SlotType;
                    items.push({id: Math.random(), group: eitem.EmpID, title: formattedTitle, start_time: moment(eitem.Timeslots[indItem].StartTime, 'h:mm A'), end_time: moment(eitem.Timeslots[indItem].EndTime, 'h:mm A'),
                    canMove: false,
                    canResize: false,
                    canChangeGroup: false,
                    style: {
                    backgroundColor: eitem.Timeslots[indItem].SlotColor
                    }});
                    let range2 = calcRange(eitem.Timeslots[indItem].StartTime, eitem.Timeslots[indItem].EndTime);
                    diff = range1.subtract(range2);
                    if(diff.length > 0)
                    {
                    if(diff.length === 1)
                    {
                      range1 = calcRange(diff[0].start, diff[0].end); 
                    }
                    else
                    {
                      items.push(
                        {
                        id: Math.random(), group: eitem.EmpID, title: "", start_time: moment(diff[0].start,"h:mm A"), end_time: moment(diff[0].end,"h:mm A"),
                          canMove: false,
                          canResize: false,
                          canChangeGroup: false,
                          style: {
                            backgroundColor: "white"
                          }
                      })
                      range1 = calcRange(diff[1].start, diff[1].end); 
                    }
                  }
                  return "";
                  });
                  if(diff.length > 0)
                  { items.push(
                      {
                      id: Math.random(), group: eitem.EmpID, title: "", start_time: moment(diff[0].start,"h:mm A"), end_time: moment(diff[0].end,"h:mm A"),
                        canMove: false,
                        canResize: false,
                        canChangeGroup: false,
                        style: {
                          backgroundColor: "white"
                        }
                    });
                  }
                  }
                  stime = moment(stime, "h:mm A").add(1, 'hours').format("h:mm A");
                }}
      else
      {
        let item;
        if(imatch.length === 1)
        {
          item = imatch[0];
        }
        if(imatch.length > 1 )
        {
          item = imatch[1];
        }
          if(item)
          { formattedTitle = item.SlotType.includes('(Unscheduled on-loan') ? "Employee on loan at "+eitem.LoanLocation : item.Appointment ? item.SlotType+"\n Employee Name: "+item.Appointment.EmployeeName+"\n Start Time: "+item.Appointment.StartTime+"\n End Time: "+item.Appointment.EndTime+"\n Activity: "+item.Appointment.ActivityType : item.CaseInfo ? item.SlotType+"\n Employee Name: "+eitem.EmployeeName+"\n Case Number: "+item.CaseInfo.CaseNumber+"\n DL Number: "+item.CaseInfo.DLNumber+"\n Subject Name: "+item.CaseInfo.SubjectName+"\n Hearing Type: "+item.CaseInfo.HearingType+"\n Reason Code: "+item.CaseInfo.ReasonCode+"\n Scheduled By: "+item.CaseInfo.ScheduledBy+" \n Location: "+item.CaseInfo.Location : item.SlotType;

          if(item.SlotType.includes("on-loan"))
      {
             eitem.Timeslots.map((litem, index) => {
               if(!(litem.SlotType.includes("(Unscheduled on-loan") || index === 0) )
              {items.push({id: Math.random(), group: eitem.EmpID, title: litem.SlotType, start_time: moment(litem.StartTime, 'h:mm A'), end_time: moment(litem.EndTime, 'h:mm A'),
              canMove: false,
              canResize: false,
              canChangeGroup: false,
              style: {
              backgroundColor: litem.SlotColor
              }});}
              return "";
             })

      }
      items.push({id: Math.random(), group: eitem.EmpID, title: formattedTitle, start_time: moment(item.StartTime, 'h:mm A'), end_time: moment(item.EndTime, 'h:mm A'),
      canMove: false,
      canResize: false,
      canChangeGroup: false,
      style: {
      backgroundColor: item.SlotColor,
      }});
      }
            }
            return "";
      });
  return items;
}

class OfficeCalendar extends Component {
    constructor(props) {
        super(props);
        this.state={
        }
    }
    groupRenderer = ({ group }) => {
      return (
        <div>
          <div><b>{group.title}</b>
      {group.role && <span >{group.role}</span>}</div>
      {/* {group.LoanLocation && <div>Employee on loan at {group.LoanLocation}</div>} */}
        </div>
      )
    }
    itemRenderer = ({ item, itemContext, getItemProps }) => {
     let backgroundColor = itemContext.selected ? 'orange' : item.style.backgroundColor;
     let backgroundImage = null;
     if(backgroundColor === "Striped")
     {
      backgroundImage = `repeating-linear-gradient(${-45}deg, transparent 15px, 
      grey 20px)`;
      backgroundColor = 'white';
     }
    if(backgroundColor === 'white')
    {
      return (
        <div
       
          {...getItemProps({
            style: {
              backgroundColor: backgroundColor,
              backgroundImage: backgroundImage,
                                   borderColor: "black",
                                           borderRadius: 4
                                           ,
                                           opacity: 0.5
            },
            onMouseDown: () => {
            }
          })}
        >
  {item.title.includes("Employee on loan at") && 
  <div
                    style={{
                      height: itemContext.dimensions.height,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                      textAlign: "center",
                      fontSize: "18px",
                      color: "black",
                      fontWeight: "bold"
                    }}
                  >
                  
                    <font>{itemContext.title}</font>
                  </div>}
        </div>
      );
    }
    else
    {
      return (
       <div tabIndex={0}
        // onFocus={ () => 
        // {
        //   document.getElementById(item.group.toString()+moment(item.start_time).format("h:mm A")).trigger("onMouseOver");
        // }}
        id= {item.group.toString()+moment(item.start_time).format("h:mm A")}
          {...getItemProps({
            style: {
              backgroundColor: backgroundColor,
              backgroundImage: backgroundImage,
                                   borderColor: "black",
                                           borderRadius: 4
            },
            onMouseDown: () => {
              if(item.title.includes('Case Number'))
              {
              let CaseNumber = item.title.split('\n Case Number: ')[1].split('\n')[0].substring(0,12);
              let DLNumber = item.title.split('\n DL Number: ')[1].split('\n')[0].substring(0,8);
              this.props.history.push(
                { pathname: `/caseDetails/CaseNumber/${CaseNumber}`,
                state: { dlNumber: DLNumber }
            });  
          }  
            }
          })}
        >
</div>
      );
    }
  
    };
    static getDerivedStateFromProps(props, prevState) {
        const { officeCalendarsData } = props.location.state;
        if(officeCalendarsData && officeCalendarsData !== prevState.officeCalendarsData) return {officeCalendarsData: officeCalendarsData}
    }

render() {     
  
  return (
//     <ScrollPanel
//     style={{
//         width: "100%",
//         height: "100%",
//         backgroundColor: "rgba(0,0,0,0)"
//     }}
// >
<React-Fragment><h2 style={{marginLeft: "40%"}}>Office Calendar for the date: <b>{this.props.location.state.officeCalendarsData.CalendarDate}</b></h2>
<Timeline
 groups={getGroups(cloneDeep(this.props.location.state.officeCalendarsData.Employees))}
 items={getItems(cloneDeep(this.props.location.state.officeCalendarsData.Employees))}
 visibleTimeStart={moment("6:00 AM", "h:mm A").valueOf()}
 visibleTimeEnd={moment("8:00 PM", "h:mm A").valueOf()}
canvasTimeStart={moment("6:00 AM", "h:mm A").valueOf()}
canvasTimeEnd={moment("8:00 PM", "h:mm A").valueOf()}
sidebarWidth={200}
 style={{backgroundColor: "lightgrey", height: "700px", overflow: "scroll", overflowX: "hidden"}}
itemRenderer={this.itemRenderer}
      groupRenderer={this.groupRenderer}
      >
        <TimelineHeaders className= "sticky">
    <SidebarHeader>
      {({ getRootProps }) => {
        return <div {...getRootProps()} style={{backgroundColor: "#f0f0f0", width: 200}}><div style={{marginTop: "3%", marginLeft: "30%"}}><b>EMPLOYEES</b></div></div>
      }}
    </SidebarHeader>
       <DateHeader
      unit={"hour"}
      labelFormat="h:mm A"
      style={{ height: 50 }}
      intervalRenderer={({ getIntervalProps, intervalContext }) => {
        return <div {...getIntervalProps({style:{backgroundColor: "#f0f0f0", borderLeft: '1px solid black',width: "100px", lineHeight: "30px"}})} >
          {intervalContext.intervalText}
        </div>
      }}
    />
           </TimelineHeaders>
</Timeline>
{/* //</ScrollPanel> */}
</React-Fragment>
);
}
}

export default withRouter(OfficeCalendar);