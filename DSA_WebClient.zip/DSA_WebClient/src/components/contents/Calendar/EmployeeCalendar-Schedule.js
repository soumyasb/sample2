import React, {Component} from "react";
import CaseReSchedReConv from '../case/CaseReschedReconvene';
import { withRouter } from "react-router-dom";
import moment from "moment";
import cloneDeep from 'lodash/cloneDeep';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import "../../../Calendars.css";
import { getCasesAssigned } from "../../../store/actions/calendarActions";
import { getCaseDetails } from "../../../store/actions/caseActions";
import { initRSRCCaseData, updateRSRCCase } from "../../../store/actions/caseSchedulingActions";
import { Modal, Dropdown, Table, Tabs, Menu, Layout, Button, Icon } from 'antd';
const { Header, Sider, Content } = Layout;
const { TabPane } = Tabs;
const columns = [
  {
      title: <b>Sched Start</b>,
      dataIndex: 'StartTime',
      width: "10%",
      key: 'StartTime'
  },
  {
      title: <b>Sched End</b>,
      dataIndex: 'EndTime',
      width: "10%"
  },
  {
      title: <b>Location</b>,
      dataIndex: 'Location',
      width: "10%"
  },
  {
      title: <b>DL # / OIP Type</b>,
      dataIndex: 'DLOIPType',
      width: "15%",
      render: (DLOIPType) => 
      {
        return <div dangerouslySetInnerHTML={{__html: DLOIPType}} />;
      }
  },
  {
      title: <b>Name</b>,
      dataIndex: 'Name',
      width: "20%"
  },
  {
      title: <b>Case #</b>,
      dataIndex: 'CaseNumber',
      width: "15%"
  },
  {
      title: <b>Hg Type</b>,
      dataIndex: 'HearingType',
      width: "5%"
  },
  {
      title: <b>Rsn Code</b>,
      dataIndex: 'ReasonCode',
      width: "5%"
  },
  {
      title: <b>Sched By</b>,
      dataIndex: 'ScheduledBy',
      width: "10%"
  }];

  const CAColumns = [
    {
      title: <b>Status</b>,
      dataIndex: 'Status',
      width: "10%"
  },
  {
    title: <b>CaseNumber</b>,
    dataIndex: 'CaseNumber',
    width: "10%",
    key: 'CaseNumber'
},
  {
      title: <b>Sched Date</b>,
      dataIndex: 'ScheduledDate',
      width: "10%"
  },
  {
      title: <b>Name</b>,
      dataIndex: 'DriverName',
      width: "15%"
  },
  {
      title: <b>DL #</b>,
      dataIndex: 'DLNumber',
      width: "15%"
  },
  {
    title: <b>Sched Time</b>,
    dataIndex: 'ScheduledTime',
    width: "10%"
},
  {
    title: <b>Location</b>,
    dataIndex: 'Location',
    width: "10%"
},
  {
      title: <b>Hg Type</b>,
      dataIndex: 'HearingType',
      width: "5%"
  },
  {
      title: <b>Rsn Code</b>,
      dataIndex: 'Reason',
      width: "5%"
  },
  {
      title: <b>Hearing Officer</b>,
      dataIndex: 'HearingOfficer',
      width: "15%"
  }
  ];
  const addCaseInfo = (data, type) =>
  {
if(data.Case)
{
  if(type === "DLOIPType")
  {
if(data.Case.OIP)
{
  let dloip = "";
  dloip = dloip+"<b>"+data.Case.DLNumber+"</b>";
  data.Case.OIP.map((oip) =>
  {
    dloip = dloip+"<br />"+oip.OIPName;
    return "";
  }
  )
  return dloip;
}
  }
  return data.Case[type];
}
else if(type === "SubjectName")
{
return data.Status;
}
return "";
  }
 const getReportRows = (data) => {
   
    let reportRows = [];
    let index = 1;
        if(data[0].Status === "(Start/End Times)")
  {
    while(index < data.length){
      if(data[0].StartTime === data[0].EndTime)
      {
        break;
      }
      else
      {
    if(data[0].StartTime !== data[index].StartTime)
    {
      reportRows.push({
        "StartTime": data[0].StartTime,
        "EndTime": data[index].StartTime,
        "Status": "(Unscheduled)",
        "Location": addCaseInfo(data[0], 'Location'),
        "HearingType": addCaseInfo(data[0], 'HearingType'),
        "ReasonCode": addCaseInfo(data[0], 'ReasonCode'),
        "ScheduledBy": addCaseInfo(data[0], 'ScheduledBy'),
        "Name": "(Unscheduled)",
        "CaseNumber": addCaseInfo(data[0], 'CaseNumber'),
        "DLOIPType":addCaseInfo(data[0], 'DLOIPType')
      });
      reportRows.push({
        "StartTime": data[index].StartTime,
        "EndTime": data[index].EndTime,
        "Status": data[index].Status,
        "Location": addCaseInfo(data[index], 'Location'),
        "HearingType": addCaseInfo(data[index], 'HearingType'),
        "ReasonCode": addCaseInfo(data[index], 'ReasonCode'),
        "ScheduledBy": addCaseInfo(data[index], 'ScheduledBy'),
        "Name": addCaseInfo(data[index], 'SubjectName'),
        "CaseNumber": addCaseInfo(data[index], 'CaseNumber'),
        "DLOIPType":addCaseInfo(data[index], 'DLOIPType')
      });
    }
    else
    {
      reportRows.push({
        "StartTime": data[index].StartTime,
        "EndTime": data[index].EndTime,
        "Status": data[index].Status,
        "Location": addCaseInfo(data[index], 'Location'),
        "HearingType": addCaseInfo(data[index], 'HearingType'),
        "ReasonCode": addCaseInfo(data[index], 'ReasonCode'),
        "ScheduledBy": addCaseInfo(data[index], 'ScheduledBy'),
        "Name": addCaseInfo(data[index], 'SubjectName'),
        "CaseNumber": addCaseInfo(data[index], 'CaseNumber'),
        "DLOIPType":addCaseInfo(data[index], 'DLOIPType')
      });
    }
      data[0].StartTime =  data[index].EndTime;
      index = index+1;
  }
  }
if(data[0].StartTime !== data[0].EndTime)
  {
    reportRows.push({
      "StartTime": data[0].StartTime,
      "EndTime": data[0].EndTime,
      "Status": "(Unscheduled)",
      "Location": addCaseInfo(data[0], 'Location'),
      "HearingType": addCaseInfo(data[0], 'HearingType'),
      "ReasonCode": addCaseInfo(data[0], 'ReasonCode'),
      "ScheduledBy": addCaseInfo(data[0], 'ScheduledBy'),
      "Name": "(Unscheduled)",
      "CaseNumber": addCaseInfo(data[0], 'CaseNumber'),
      "DLOIPType":addCaseInfo(data[0], 'DLOIPType')
    });
  
    }
  }
  return reportRows;
  }
class EmployeeCalendar extends Component {
    constructor(props) {
        super(props);
        this.state={
          selectedKeys: ["0"],
          selectedDate: "0",
          tableRows: [],
          selectedCARow: ""
        }
    }

    static getDerivedStateFromProps(props, prevState) {
      const { employeesCalendarsData } = props.location.state;
      const { rsrcdataObj, rsrcUpdateData } = props.caseScheduling;
      const { casesAssignedList } = props.calendar;
      const { caseDetailsObj } = props.cases;
      if (employeesCalendarsData && employeesCalendarsData !== prevState.employeesCalendarsData) return {  selectedKeys: ["0"], selectedDate: "0", employeesCalendarsData: employeesCalendarsData };
      if (casesAssignedList && casesAssignedList.results !== prevState.casesAssignedList) return {  casesAssignedList: casesAssignedList.results, openCAModal: true };
      if (rsrcdataObj && rsrcdataObj !== prevState.rsrcdataObj && prevState.rsrcType ) return {  rsrcdataObj: rsrcdataObj, openReSchedReConvModal: true };
      if (caseDetailsObj && caseDetailsObj !== prevState.caseDetailsObj){
        props.initRSRCCaseData(prevState.rsrcType, caseDetailsObj);
        return {  caseDetailsObj: caseDetailsObj };
      } 
      if (rsrcUpdateData && rsrcUpdateData !== prevState.rsrcUpdateData && prevState.rsrcType ) 
      {
        if(rsrcUpdateData.Error === true)
      {
        var caseErrorData = [];
        caseErrorData.push(rsrcUpdateData.Message);
        return {caseErrorData: caseErrorData, rsrcUpdateData: rsrcUpdateData, caseError: true};
      }
      else{
        return {rsrcUpdateData: rsrcUpdateData, openstatusModal: true};
      }
      }
      return "";
    }
    componentWillUnmount()
{
  
    this.setState({selectedKeys: ["0"], selectedDate: "0"});
}  


print(type) {
  
  var content = document.getElementById("printarea"+type);
  var htmlToPrint = '' +
  '<style type="text/css">' +
  'table th, table td {' +
  'border:1px solid #000;' +
  '}' +
  'h3,p {' +
  'margin-left:40%;'+
  '}'+
  'span {' +
  'float:right;'+
  '}'+
  '</style>';
  if(type === "EC")
  {
    htmlToPrint += '<React-Fragment>'+
    `<h3>Daily Appointment Sheet</h3>`+
     `<p><b>Date:</b> ${moment(this.props.location.state.selectedDays[parseInt(this.state.selectedDate,10)],"YYYY-MM-DDTHH:mm:ssZ").format('dddd') +", "+ moment(this.props.location.state.selectedDays[parseInt(this.state.selectedDate,10)],"YYYY-MM-DDTHH:mm:ssZ").format('LL')}</p>`+
     `<div><b>Hearing Officer:</b> ${this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Text}<span><b>Printed:</b> ${moment().format("MM-DD-YYYY")} at ${moment().format("hh:mm:ss A")}</span></div>`+
     '</React-Fragment>';
  }
  htmlToPrint += content.outerHTML;
  
  var pri = document.getElementById("ECAifmcontentstoprint").contentWindow;
  pri.document.open();
  pri.document.write(htmlToPrint);
var result = pri.document.execCommand('print', false, null);
if(!result) {
pri.document.close();
  pri.focus();
  pri.print();
  pri.close();
}
}
        render() {       
          var tableRows = [];
          var message = "";
          const printMenu = (
            <Menu onClick={(e) => {this.print(e.key)}}>
              <Menu.Item key="ECA">Print All</Menu.Item>
              <Menu.Item key="EC">Print This Calendar</Menu.Item>
            </Menu>
          );  
     this.props.location.state.employeesCalendarsData.map((ec) => { if(ec.ReportDate.substring(0,10) === moment(this.props.location.state.selectedDays[parseInt(this.state.selectedDate,10)],"YYYY-MM-DDTHH:mm:ssZ").format("YYYY-MM-DD") && ec.EmpId === parseInt(this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Value,10))
          {
       if(ec.TimeSlots)
       {
        tableRows = getReportRows(cloneDeep(ec.TimeSlots));
       }
       else if(ec.Message)
       {
        message = ec.Message;
       } 
          }
          return "";
        }
            );
        return (
            <div style={{backgroundColor: 'white'}}> 

             {this.state.employeesCalendarsData && <div id='printareaECA' > 
            <iframe title="ECAifmcontentstoprint" id="ECAifmcontentstoprint" style={{
            height: '100%',
            opacity: '0',
            width: '100%',
            border: 'none',
            position: 'absolute'
            }}></iframe>  
            <div class="print-only">{this.state.employeesCalendarsData && 
            <React-fragment id="print">
              {this.state.employeesCalendarsData.map((ec) => {
                return <React-Fragment style={{pageBreakAfter: "always"}}>
               {ec.TimeSlots ? <React-Fragment> <React-Fragment>
       <h3 style={{marginLeft: "40%"}}>Daily Appointment Sheet</h3>
        <p style={{marginLeft: "40%"}}><b>Date:</b> {moment(ec.ReportDate.substring(0,10),"YYYY-MM-DD").format('dddd') +", "+ moment(ec.ReportDate.substring(0,10),"YYYY-MM-DD").format('LL')}</p>
        <p><span><b>Hearing Officer:</b> {ec.EmployeeName}</span><span style={{float: "right"}}><b>Printed:</b> {moment().format("MM-DD-YYYY")} at {moment().format("hh:mm:ss A")}</span></p>
        </React-Fragment>
                   <Table
                                        showHeader
                                        size='small'
                                        pagination={false}
                                        bordered
                                        style={{ backgroundColor: "white" }}                                     
                                        columns={columns}
                                        dataSource={getReportRows(cloneDeep(ec.TimeSlots))}
                                        rowKey={(record,index) => index}
                                    /> </React-Fragment>
               : ec.Message && <h3>{ec.Message}</h3>
                  }
                </React-Fragment>
              })}
            </React-fragment>
            }</div>
            </div>}    
            {this.state.caseErrorData !== undefined &&  <Modal
          title="ERROR" 
          visible={this.state.caseError} onCancel={(e) => {this.setState({caseError: false})}}  footer = { [
            <div>
            <Button type="primary" key="Ok" onClick={(e) => {this.setState({caseError: false})}}>Ok</Button>
            </div>
        ]}><font size="40px">{ this.state.caseErrorData.length > 0 &&  this.state.caseErrorData.map((item) => <div dangerouslySetInnerHTML={{ __html: item.toString()}}/>)} </font></Modal>} 
              <Modal
            width= "85%"
            maskClosable={false}
              title={"Cases Assigned to "+this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Text} 
              visible={this.state.openCAModal} onCancel={(e)  => {this.setState({openCAModal: false})}}  footer = { [
                <div>
                <Button disabled={this.state.selectedCARow.CaseNumber === "" ? true : false} type="primary" key="CD" onClick={(e)  => { this.props.history.push(
                                                        { pathname: `/caseDetails/CaseNumber/${this.state.selectedCARow.CaseNumber}`,
                                                        state: { dlNumber: this.state.selectedCARow.DLNumber}
                                                    });                                           }}>Case Detail</Button>
                <Button disabled={this.state.selectedCARow.CaseNumber === "" ? true : false} type="primary" key="RS" onClick={(e)  => {this.props.getCaseDetails(this.state.selectedCARow.CaseNumber); this.setState({rsrcType: 'ReSchedule'});}}>Reschedule</Button>
                <Button disabled={this.state.selectedCARow.CaseNumber === "" ? true : false} type="primary" key="RC" onClick={(e)  => {this.props.getCaseDetails(this.state.selectedCARow.CaseNumber); this.setState({rsrcType: 'ReConvene'});}}>Reconvene</Button>
                </div>
            ]}>
         { this.state.casesAssignedList && <Table
                                        showHeader
                                        rowClassName={(record) => {record.CaseNumber === this.state.selectedCARow.CaseNumber ? 'selectedRowClass' : ''}}
                                        size='small'
                                        style={{ backgroundColor: "white" }}
                                        columns={CAColumns}
                                        dataSource={this.state.casesAssignedList}
                                        rowKey={(record, index) => index}
                                            onRow={(record) => ({
                                            onClick: () => {
                                             this.setState({selectedCARow: record})
                                            }                                         
                                        }) }
                                    />
         }
             </Modal>
 <Layout>
            <Header style={{background: "white"}}><span><font size="3"><strong>Select an Employee</strong></font></span><span style={{paddingLeft: "40%"}}><font size="3"><strong>Employee Calendar</strong></font></span>
            <Dropdown overlay={printMenu}><Button  style={{float: "right", marginTop: "1%"}} type="primary" size={"small"} onClick={(e) => {}}><Icon type="printer" /> Print Calendar(s) <Icon type="down" /></Button></Dropdown><Button  style={{marginRight: "2%", float: "right", marginTop: "1%"}} type="primary" size={"small"} onClick={(e) => {this.props.getCasesAssigned(parseInt(this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Value,10), "1")}}>Cases Assigned</Button></Header>
            <Layout>
              <Sider style={{
        background: "white"}}>
               <Menu mode="inline" defaultSelectedKeys={['0']}
        defaultOpenKeys={["0"]}
        selectedKeys={this.state.selectedKeys}
        style={{ height: '100%' }}
        onClick={(e) =>{
          var selectedKeys = [];
          selectedKeys.push((e.key));
           this.setState({selectedKeys: selectedKeys});} }
        >
{this.props.location.state.selectedEmployeeDetails.map((item,index) =>
  {
    return <Menu.Item key={index}>
            <Icon type="user" />
            <span className="nav-text">{item.Text}</span>
  </Menu.Item>} 
          )}
              </Menu>              
              </Sider>
              <Content >{this.state.employeesCalendarsData &&      
         <Tabs activeKey={this.state.selectedDate} tabPosition="top" onChange={(e) => {
           
           this.setState({selectedDate: e});
         }}>
        { this.props.location.state.selectedDays && this.props.location.state.selectedDays.map((i,index) => (
          <TabPane tab={`${moment(i,"YYYY-MM-DDTHH:mm:ssZ").format("MM-DD-YYYY")}`} key={`${index}`}>
          <Modal
          width= "70%"
          maskClosable={false}
          title={this.state.rsrcType + " Case# "+this.state.selectedCARow.CaseNumber} 
          visible={this.state.openReSchedReConvModal} onCancel={(e) => {this.setState({openReSchedReConvModal: false})}}  footer = { null}>
          { this.state.rsrcdataObj && <CaseReSchedReConv handleCancel={(e) => {this.setState({openReSchedReConvModal: false})}} handleOk={(obj) => {this.props.updateRSRCCase(this.state.rsrcType, obj)}} rsrcdataObj={this.state.rsrcdataObj} type={this.state.rsrcType}></CaseReSchedReConv>}
            </Modal>  
            <Modal
        maskClosable={false}
          title="Success" 
          visible={this.state.openstatusModal} onCancel={(e)  => {this.props.getCasesAssigned(parseInt(this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Value,10), "1"); this.setState({openstatusModal: false})}}  footer = { [
            <div>
         <Button type="primary" key="Ok" onClick={(e)  => {
           this.props.getCasesAssigned(parseInt(this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Value,10), "1");
           this.props.history.push(
            { pathname: `/caseDetails/CaseNumber/${this.state.selectedCARow.CaseNumber}`,
            state: { dlNumber: this.state.selectedCARow.DLNumber,
            selectedKeys: "Schedule", tabValue: "Schedule"}
        });
          }}>Yes</Button>
            <Button type="default" key="Cancel" onClick={(e)  => {this.props.getCasesAssigned(parseInt(this.props.location.state.selectedEmployeeDetails[parseInt(this.state.selectedKeys[0],10)].Value,10), "1"); this.setState({openstatusModal: false})}}>No</Button>
            </div>
        ]}>Case has been unscheduled for {this.state.rsrcType} successfully. Do you wish to schedule this case now? </Modal>
        
        {this.state.employeesCalendarsData && message === "" ? <Table id="printareaEC"
                                        showHeader
                                        size='small'
                                        scroll={{ y: 500 }}
                                        style={{ backgroundColor: "white" }}
                                        onRow={(record) => ({
                                            onClick: () => {
                                                    if(record.CaseNumber)
                                                    {
                                                    this.props.history.push(
                                                        { pathname: `/caseDetails/CaseNumber/${record.CaseNumber}`,
                                                        state: { dlNumber: record.DLNumber }
                                                    });                                                 
                                            }             
                                            }                                         
                                        }) }
                                        columns={columns}
                                        dataSource={tableRows}
                                        rowKey={(record,index) => index}
                                    /> : <h3>{message}</h3>
                                  }
          </TabPane>
        ))}
      </Tabs>
      }</Content>
            </Layout>
          </Layout></div>);
            }
        }
                const mapDispatchToProps = dispatch => {
            return bindActionCreators(
              {
                getCasesAssigned,
                initRSRCCaseData, 
                updateRSRCCase,
                getCaseDetails
              },
              dispatch
            );
          };
          const mapStateToProps = state => {
            return {
              calendar: state.calendar,
              caseScheduling: state.caseScheduling,
              cases: state.cases
            };
          };
          
         export default withRouter(connect(mapStateToProps, mapDispatchToProps)(EmployeeCalendar));
          