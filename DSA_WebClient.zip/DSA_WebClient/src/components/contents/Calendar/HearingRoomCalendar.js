import React from "react";
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction"; // needed for dayClick
import "@fullcalendar/core/main.css";
import "@fullcalendar/timegrid/main.css";

class HearingRoomCalendar extends React.Component {
    calendarComponentRef = React.createRef();
   
     state = {
    }
    static getDerivedStateFromProps(props, prevState) {
        const { hrCalendarsData } = props.location.state;
        if(hrCalendarsData && hrCalendarsData !== prevState.hrCalendarsData) return {hrCalendarsData: hrCalendarsData}
    }
    render() {
    
        return (
         //   <div>Location Calendar details go here</div>
          <div style={{backgroundColor: "white"}} >
              <FullCalendar
                defaultView="timeGridDay"
                header={{
                  left: "Prev, Next",
                  center: "title",
                  right: "Today"
                }}
               plugins={[ timeGridPlugin, interactionPlugin]}
               ref={this.calendarComponentRef}
                events={this.state.hrCalendarsData.Appointments}
                height={650}
                titleFormat={{ year: 'numeric', month: 'long', day: 'numeric' }}
                defaultDate={this.props.location.state.selectedDate}
                minTime={"07:00:00"}
                maxTime={"18:00:00"}
                timeGridEventMinHeight={20}
               slotDuration={"00:30:00"}
               scrollTime={"08:00:00"}
               eventColor= {"Green"}        
               selectMirror={true}   
               selectable={true}
               select={
                this.selectDate}
              />
          </div>
        );
      }
    
      selectDate = info => 
      {
        if(this.props.selectedHO === undefined)
        {
          this.props.validateHO();
        }
        else
        {
        this.props.fromCalendar(info);
        }
      }
    
      handleDateButtonClick = arg => {
        if(this.props.selectedHO === undefined)
        {
          this.props.validateHO();
        }
        else
        {
          
          let calendarApi = this.calendarComponentRef.current.getApi();
          calendarApi[arg]();
          this.props.getDate(calendarApi.getDate());
        }
      };
    }  

    export default HearingRoomCalendar;