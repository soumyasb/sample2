import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { initNewsItemPage, initCreateNewsItemObj, initEditNewsItemObj, initGetOfficeDetails, initNewsItemDetails, 
    initDeleteNewsItem, initModifyNewsItem,initSaveNewsItem } from "../../../store/actions/newsItemActions";
import { Table, Tooltip, notification, Button, Icon, Divider, Row, Col, Modal } from 'antd';
import moment from "moment";
import NewsModal from './NewsModal';

class NewsItem extends React.Component {

    constructor(props) {
        super(props);
        this.columns = [
            {
                title: 'Author Name',
                dataIndex: 'AuthorName',
                width: '6%',
                key: `${Math.random()}`
                
            },
            {
                title: 'Priority',
                dataIndex: 'Priority',
                width: '6%',
                render: (Priority) =>
                {
                    if(Priority === "A")
                    {
                        return <p> Urgent </p>
                    }
                    if(Priority === "B")
                    {
                        return <p> Normal </p>
                    }
                    if(Priority === "C")
                    {
                        return <p> Low </p>
                    }
                }

            },
            {
                title: 'Subject',
                dataIndex: 'Subject',
                width: '10%',
                render: (item, record) => {
                    return <div tabIndex="0" onKeyDown={(e) => {
                        if(e.keyCode === 13)
                        {
                            document.getElementById("nid"+record.NewsId.toString()).click();
                        }
                    }} onFocus={(e) => this.setState({selectedRow : record.NewsId})}>{item}</div>
                }
            },
            {
                title: 'News Text',
                dataIndex: 'NewsText',
                width: '42%',
                className: 'newsItemsPage-newsText',
                render: (newsText,e, index) => 
                {
               return <div tabIndex="0" onFocus={(e) => {
               }}
               onBlur={() => {
                this.setState({ index: -1 });
              }} style={{wordBreak: "keep-all"}}><p>{newsText}</p></div>
                }

            },
            {
                title: 'Create Date',
                dataIndex: 'CreateDate',
                width: '8%',
                render: (createDate) =>
                moment(createDate).format("MM-DD-YYYY")
            },
            {
                title: 'Start Date',
                dataIndex: 'StartDate',
                width: '8%',
                render: (StartDate) =>
                    moment(StartDate).format("MM-DD-YYYY")
            },
            {
                title: 'End Date',
                dataIndex: 'EndDate',
                width: '8%',
                render: (EndDate) =>
                moment(EndDate).format("MM-DD-YYYY")
            },
            {
                title: 'Options',
                width: '8%',
                render: (item) => {
                    return (
                        <div style={{textAlign: "center"}}>
                             <Tooltip
       title="Edit"
       placement="topLeft"
     ><Icon tabIndex="0" id={"nie"+item.NewsId.toString()} onKeyPress={(e) => {if(e.keyCode === 13){document.getElementById("nie"+item.NewsId.toString()).click()}}} type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.NewsId)} /></Tooltip>
                             <Divider type="vertical" />
                             <Tooltip
       title="Delete"
       placement="topLeft"
     ><Icon tabIndex="0" id={"nid"+item.NewsId.toString()} onKeyPress={(e) => {if(e.keyCode === 13){document.getElementById("nid"+item.NewsId.toString()).click()}}} type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.NewsId)} /></Tooltip>
                             <Divider type="vertical" />
                             <Tooltip
       title="Details"
       placement="topLeft"
     > <Icon tabIndex="0" id={"nideet"+item.NewsId.toString()} onKeyPress={(e) => {if(e.keyCode === 13){document.getElementById("nideet  "+item.NewsId.toString()).click()}}} type="profile" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'details', item.NewsId)} /></Tooltip>
                        </div>
                    );
                },
            }
        ];

        this.state = {            
            newsItemObject: props.newsItem.newsItemObj,
            actionType: 'create',
            showModal: false,
            newOne: true,
            officeDetailsObj: this.props.newsItem.officeDetailsObj,
            list: props.newsItem.list,
            index: null       
        }

        this.showModal = this.showModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }

    componentDidMount() {
        this.props.initNewsItemPage();
        this.props.initCreateNewsItemObj();
    }
    componentDidUpdate(prevProps) {
      
        if (prevProps.newsItem.newsItemObj !== this.props.newsItem.newsItemObj) {
            this.setState({ newsItemObject: this.props.newsItem.newsItemObj });
        } 
        if (prevProps.newsItem.officeDetailsObj !== this.props.newsItem.officeDetailsObj) {
            this.setState({ officeDetailsObj: this.props.newsItem.officeDetailsObj });
        }       
        if(prevProps.newsItemObj !== undefined && this.state.newsItemObj.officeGroup === null)
        {           
            let newsItemObjectCopy = JSON.parse(JSON.stringify(this.state.newsItemObject));
            newsItemObjectCopy.officeGroup = [];
            this.setState({
                newsItemObj:newsItemObjectCopy 
             });                     
        }
        if (prevProps.newsItem.list !== undefined)
        {
           if (prevProps.newsItem.list.length < this.props.newsItem.list.length) {
                this.openNotification('added');
                this.setState({ showModal: false });
            }
            else if (prevProps.newsItem.list.length > this.props.newsItem.list.length)
            {
                this.openNotification('deleted');
                this.setState({ showModal: false });
            }
            else
            {
             if(prevProps.newsItem.modified !== this.props.newsItem.modified)
             {
                this.openNotification('modified');
                this.setState({ showModal: false });
             }
            }
        } 

        if(this.props.newsItem.newsErrorData && prevProps.newsItem.newsErrorData !== this.props.newsItem.newsErrorData)
{
  this.setState({newsErrorData: this.props.newsItem.newsErrorData, newsError: true, newOne: false});
}
    }

    static getDerivedStateFromProps(props, prevState) {
        const { newsItemObj, officeDetailsObj, newsErrorData } = props.newsItem;

        if (newsItemObj && newsItemObj !== prevState.newsItemObject) {
                props.initGetOfficeDetails(JSON.parse(sessionStorage.getItem('userInfo')).EmpID,JSON.parse(sessionStorage.getItem('userInfo')).EmpType);
            return { newsItemObject: newsItemObj};}
        if (officeDetailsObj && officeDetailsObj !== prevState.officeDetailsObj) return { officeDetailsObj: officeDetailsObj, isloading: false };
        if (newsErrorData && newsErrorData !== prevState.newsErrorData)
        {
            return {newsErrorData: newsErrorData};
        } 
        return null;
    }

    showModal(e, actype, newsId) {
        
        if (actype !== 'create') {
            if(newsId)
        {
            if(actype === 'edit') {
        this.props.initEditNewsItemObj(newsId);  
        }
        if(actype === 'details') {
            this.props.initNewsItemDetails(newsId);     
            }
            if(actype === 'delete') {
                this.props.initNewsItemDetails(newsId);     
                }
    }
}
        else
        {
            this.props.initCreateNewsItemObj();
        }

        this.setState({ actionType: actype, showModal: true, newOne: true});
    }

    handleOk(e) {
        if(this.state.actionType === 'delete')
        {
            this.props.initDeleteNewsItem(this.state.newsItemObject.NewsId);
        }
        if(this.state.actionType === 'edit')
        {
            this.props.initModifyNewsItem(this.state.newsItemObject);
        }
        if(this.state.actionType === 'create')
        {
            this.props.initSaveNewsItem(this.state.newsItemObject);
        }
        }

 handleError = (e) => {
            this.setState({
              newsError: false,
            });
}

    handleCancel(e) {
        this.setState({ showModal: false });
    }
openNotification = (type) =>
{
    notification.open({
        message: 'SUCCESS',
        description: 'The newsitem was ' +type+ ' successfully!',
        style: {
          width: 600,
          marginLeft: 335 - 600,
          backgroundColor: "#9cd864",
          fontWeight: 'bold'
        },
      });
}
    render() {      
        const newsItem = this.state.newsItemObject;
        const columns = this.columns.map((col) => {
            return {
                ...col,
                onCell: record => ({
                    record,
                    title: col.title
                }),
            };
        });

        return (
            <React.Fragment>
                <Row type="flex" justify="center">
                <Col span={24}>
            {/* <ScrollPanel
                style={{
                    width: "100%",
                    height: "calc(100% - 40px)",
                    backgroundColor: "rgba(0,0,0,0)"
                }}
            > */}
               <React.Fragment>
               
               {this.props.newsItem.list !== undefined && 
                   <Table
                        size= {"small"}
                        rowKey = "NewsId"
                        title={() => <React.Fragment><span><Button type="primary" onClick={(e) => this.showModal(e, 'create')}>Create New</Button></span><span style ={{paddingLeft: "39%", fontSize: "x-large"}}>News Items</span></React.Fragment>} 
                        showHeader = {true}
                        bordered
                        rowClassName={(record) => {if(record.NewsId === this.state.selectedRow){
                            return "selectedRowClass"
                        }}}
                       // scroll={{ y: 500}}
                        dataSource={this.props.newsItem.list}
                        columns={columns}
                        pagination={{ pageSize: 8, position: 'top'}}
                        // rowClassName={(e,index) => {
                        //     this.state.index && this.state.index === index && {backgroundColor: "lightBlue", border: "solid 1px blue"}
                        // }}
                      />
                }
                     { this.props.newsItem.list === undefined && <React.Fragment> {this.state.newsErrorData && typeof(this.state.newsErrorData) !== 'string' && <Modal
                      title="ERROR" 
                      visible={this.state.newsError} onCancel={this.handleError}  footer = { [
                        <React.Fragment>
                        <Button type="primary" key="Ok" onClick={this.handleError}>Ok</Button>
                        </React.Fragment>
                ]}><font size="40px">{this.state.newsErrorData.length > 0 &&  this.state.newsErrorData.map((item) => <div dangerouslySetInnerHTML={{ __html: item.toString()}}/>)} </font></Modal>}
                {this.state.newsErrorData && typeof(this.state.newsErrorData) === 'string' && <React.Fragment>{this.state.newsErrorData.includes('not authorized') && <h3 style={{textAlign: 'center'}}>{this.state.newsErrorData}</h3>}</React.Fragment>}</React.Fragment>
                     }    
                </React.Fragment>               
                {this.state.newsItemObject && this.state.officeDetailsObj &&
              <NewsModal 
              newOne={this.state.newOne}
              newsErrorData= {this.state.newsErrorData}
                    modalVisible={this.state.showModal}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    actionType={this.state.actionType}
                    newsItemObj={newsItem}
                    officeDetailsObj={this.state.officeDetailsObj}      
                    priorityValue={newsItem.Priority}              
                /> }
          {/* </ScrollPanel>     */}
          </Col>
          </Row>
          </React.Fragment>
        );
    }
}

const mapStateToProps = state => {
    return {
        newsItem: state.newsItem,
        ui: state.ui,
        homePage: state.homePage
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            initNewsItemDetails,
            initSaveNewsItem,
            initModifyNewsItem,
            initDeleteNewsItem,
            initGetOfficeDetails,
           initCreateNewsItemObj,
           initEditNewsItemObj,
            initNewsItemPage
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsItem);
