import React, { Component } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { getFormattedDate } from './../commonFuncs.js';
import '../../../dp.css';
import { Modal, Form, Input, Select, Checkbox, Button } from 'antd';
import "../../../App.css";

const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;

const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
};

const getModalSettings = ({ actionType, onOk, onCancel}) => {
    let title, okText = '';
    let footer = [];

    switch(actionType) {
        case 'create': 
            title = 'Create News Item';
            okText = 'Create';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'edit': 
            title = 'Edit News Item';
            okText = 'Save';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'details': 
            title = 'News Item Details';
            okText = 'Details';
            footer = [
                <Button key="Close" onClick={onCancel}>Close</Button>
            ];
            break;
        case 'delete': 
            title = 'Delete News Item';
            okText = 'Delete';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        default: 
            title = 'Create News Item';
    }

    return {
        title,
        okText,
        footer,
    }

}

const getOfficeDetails = (newsItemObj, officeDetailsObj, actionType) =>   
 {  
     let officedetails = [], officelist = [], officegrp = [];   
     if(newsItemObj.EmployeeType !== "O")
     {
 if (actionType === 'edit' || actionType === 'create') {   
    officeDetailsObj.forEach(element => {   
          if(newsItemObj.officeGroup && newsItemObj.officeGroup!== null && newsItemObj.officeGroup.includes(element.OfficeId))   
          {   
             officegrp.push(element.OfficeId);   
        officelist.push(<Option key={element.OfficeId}>{element.OfficeName}</Option>);   
          }   
         else{   
             officelist.push(<Option key={element.OfficeId}>{element.OfficeName}</Option>);   
         }   
     });      
    }
    else
    {
        officeDetailsObj.forEach(element => {
            if(newsItemObj.OfficeNewsItem && newsItemObj.OfficeNewsItem!== null)
            {
                newsItemObj.OfficeNewsItem.forEach(officeItem => {
               if(officeItem.CdOffId === element.OfficeId)
               {
                officelist.push(element.OfficeName);  
               }
        });
    }
    });
    }        
    officedetails = {officelist, officegrp};   
}
else
{
    officedetails = officeDetailsObj;   
} 

 
  return officedetails;   
} 
const getPriorityList = (newsItemObj, actionType) =>   
{  
    let prioritylist = [];   
if (actionType === 'edit' || actionType === 'create') {   
    if(actionType === 'create')
    {
        prioritylist.push(<option key="" value="" disabled>- Please Select -</option>);
    }
   newsItemObj.PriorityList &&  newsItemObj.PriorityList.map(priority =>
{
    if(actionType === "edit" && priority.Value === newsItemObj.Priority)
    {
        prioritylist.push(<option key={priority.Value} value={priority.Value}>{priority.Text}</option>);
    }  
    else
    {
    prioritylist.push(<option key={priority.Value} value={priority.Value}>{priority.Text}</option>);
   }
   return "";
})}
   return prioritylist;     
}

class NewsModal extends Component {
    constructor(props) {
        super(props);
        this.state ={
            newsItemObj: props.newsItemObj
            
    }
        this.onPriorityChange = this.onPriorityChange.bind(this);   
        this.onNewsTextChange = this.onNewsTextChange.bind(this);   
        this.onSubjectChange = this.onSubjectChange.bind(this); 
        this.onCancel = this.onCancel.bind(this); 
        this.onOk = this.onOk.bind(this);
        this.onChecked = this.onChecked.bind(this);     
        this.onDateChange = this.onDateChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.newsItemObj !== nextProps.newsItemObj) {
            this.setState({ value: nextProps.newsItemObj.officeGroup, newsItemObj: nextProps.newsItemObj});         
        } 
    
    if(nextProps.actionType === 'create')
    {
        this.setState({ value: []});
    }
    }

    onPriorityChange(event) {
        const {newsItemObj} = this.state;
        newsItemObj.Priority = event.target.value;
        this.setState({ newsItemObj });
    }

    onNewsTextChange(e) {
        const { newsItemObj } = this.state;
        newsItemObj.NewsText = e.target.value;
        this.setState({ newsItemObj });
    }

    onSubjectChange(e) {
        const { newsItemObj } = this.state;
        newsItemObj.Subject = e.target.value;
        this.setState({ newsItemObj });
    }

    onOk() {
        this.props.onOk(this.state.newsItemObj);
    }

    onCancel() {
        this.setState({value: []});
        const { newsItemObj } = this.state;
        newsItemObj.Priority = "";
        this.setState({ newsItemObj });
        this.props.onCancel();
    }

    handleChange = (value) => {
        const { newsItemObj } = this.state;
        if(!value)
        {
            newsItemObj.officeGroup = '';
        }
        else 
        {
            newsItemObj.officeGroup = value;
        }
        this.setState({ newsItemObj });      
       this.setState({value: value});
    }
   
    onDateChange(d,type) 
    {
        const { newsItemObj } = this.state;
      if(type==='startDate')  newsItemObj.StartDate = d;
      else newsItemObj.EndDate = d;
        this.setState({ newsItemObj });      
    }
    onChecked()
        {
            const { newsItemObj } = this.state;
           if(newsItemObj.AllOffices === true )
           {
            newsItemObj.AllOffices = false;
           }
           else
           {
            newsItemObj.AllOffices = true;
           }
        this.setState({ newsItemObj });
        
        }
 
        render() {
        let { newsItemObj } = this.state;
        const modalSettings = getModalSettings(this.props);
       let officedetails = [];
       let prioritylist = [];
       if(this.state.newsItemObj !== undefined)
       {
       officedetails = getOfficeDetails(this.props.newsItemObj, this.props.officeDetailsObj, this.props.actionType);    
       prioritylist = getPriorityList(this.props.newsItemObj, this.props.actionType);    
       }
     
         return (        
            <Modal
                visible={this.props.modalVisible}
                onOk={this.handleOk}
                destroyOnClose={true}
                onCancel={this.onCancel}
                title={modalSettings.title}
                maskClosable={false}
                okText={modalSettings.okText} 
                footer={modalSettings.footer}
                width={'750px'}
            >
                <React.Fragment>
                    <Form layout={'horizontal'}>
                        <FormItem
                            label="Priority"
                            {...formItemLayout}
                        > 
                            {this.props.actionType === 'create' ? <select                           
                             style={{ width: '100%', border: "1px solid #d9d9d9", height: "32px", borderRadius: "4px"} }    
                             size={"default"}        
                             defaultValue =""
                             onChange={this.onPriorityChange}   
                           >   
                          {prioritylist}
                           </select> :   this.props.actionType === 'edit' ?                             
                             <select id="priorityList"  
                             onFocus={(e) => document.getElementById("priorityList").click()}                    
                             style={{ width: '100%', border: "1px solid #d9d9d9", height: "32px", borderRadius: "4px"} }    
                              size={"default"} 
                             value = {newsItemObj.Priority || ""}      
                             placeholder="Please Select"
                             onChange={this.onPriorityChange}   
                           >   
                          {prioritylist}
                           </select>   
                            :
                            <React.Fragment>{newsItemObj.Priority === 'A' ? "Urgent" :
                            newsItemObj.Priority === 'B' ? "Normal" : "Low"
                            }</React.Fragment>                         
                            }
                        </FormItem>
                        <FormItem
                       validateStatus = {this.props.newsErrorData && this.props.newOne === false && newsItemObj.Subject === null && this.props.newsErrorData["Subject"] ? 'error' : ""}
                       help = {this.props.newsErrorData && this.props.newOne === false && newsItemObj.Subject === null  && this.props.newsErrorData["Subject"]}
                           label={<b>Subject <font color="red">*</font></b>}
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <Input value={newsItemObj.Subject} placeholder="Subject" onChange={this.onSubjectChange} />
                            :
                            <React.Fragment>{newsItemObj.Subject}</React.Fragment>                             
                            }
                        </FormItem>
                        <FormItem
                              validateStatus = {this.props.newsErrorData && this.props.newOne === false && newsItemObj.NewsText === null && this.props.newsErrorData["NewsText"] ? 'error' : ""}
                     help = {this.props.newsErrorData && this.props.newOne === false && newsItemObj.NewsText === null  && this.props.newsErrorData["NewsText"]}
                         label={<b>News Text <font color="red">*</font></b>}
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <TextArea value={newsItemObj.NewsText} rows="6" onChange={this.onNewsTextChange} />
                            :
                            <React.Fragment>{newsItemObj.NewsText}</React.Fragment>                             
                            }
                        </FormItem>
                        <FormItem
                            label="Start Date"
                            {...formItemLayout}
                        >
                        {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                           <DatePicker
                           className = "CalClass"
                           style={{lineHeight : "20px"}}
                           selected={new Date(newsItemObj.StartDate)}
                           dateFormat={"MM-dd-yyyy"}
                           onChange={(d) => this.onDateChange(d, 'startDate')}
                           isClearable={true}
                           placeholderText="Start Date"
                         />
                                :
                           <React-Fragment>{getFormattedDate(newsItemObj.StartDate)}</React-Fragment> 
                            }
                        </FormItem>
                        <FormItem
                            label="End Date"
                            {...formItemLayout}
                        >
                        {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                             <DatePicker
                             className = "CalClass"
                             style={{lineHeight : "20px"}}
                             selected={new Date(newsItemObj.EndDate)}
                             dateFormat={"MM-dd-yyyy"}
                             onChange={(d) => this.onDateChange(d, 'endDate')}
                             isClearable={true}
                             placeholderText="Start Date"
                           />
                                :   
                             <React-Fragment>{getFormattedDate(newsItemObj.EndDate)}</React-Fragment>                      
                                }
                        </FormItem>
                       {(this.props.actionType === 'create' || this.props.actionType === 'edit') && newsItemObj.EmployeeType !== 'O' ?
                       <FormItem
                            label="Publish this News Item to"
                            {...formItemLayout}
                        >
                           <Checkbox checked={newsItemObj.AllOffices} onChange={this.onChecked}  placeholder="input placeholder">
                                All offices in your region?
                            </Checkbox>                        
                       </FormItem>
                       : <FormItem
                       label="News Item is published to:"
                       {...formItemLayout}
                   >
                  
                 { officedetails.officelist ? <div style={{ width: "80%"}}>{officedetails.officelist.map((office, i) => (
        <Button>{office}</Button>
                 ))}</div> : <React-Fragment>{officedetails[0].OfficeId} - {officedetails[0].OfficeName}</React-Fragment>}                      
                  </FormItem>
                       }
                       {newsItemObj.AllOffices || newsItemObj.EmployeeType === 'O' || newsItemObj.officeGroup === undefined ? <React.Fragment></React.Fragment> :
                   <FormItem label="Select Offices:" {...formItemLayout}>      
                            {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                           <Select  allowClear={true} id="offC"
     mode="multiple"   
     style={{ width: '100%' }}   
     placeholder="Please select"   
     value={this.state.value}   
     onChange={this.handleChange}   
     showSearch optionFilterProp= "children" filterOption = {true} onFocus={(e) => {document.getElementById("offC").click()}}
   >   
   
     {officedetails.officelist}   
   </Select>
    :
    <React.Fragment></React.Fragment> 
                        }
                            </FormItem>
                       }
                    </Form>
                </React.Fragment>  
            </Modal>
        
        );
    }
}

export default NewsModal;
