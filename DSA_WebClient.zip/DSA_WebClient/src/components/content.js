import React from "react";
import { Switch, Route } from 'react-router-dom'
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import HomePage from "./contents/home/homepage";
import NewsPage from "./contents/admin/NewsItem";
import Search from "./contents/case/Search";
import CustomerDetails from "./contents/case/CustomerDetails";
import CaseDetails from "./contents/case/CaseDetails";
import ClosedCaseDetail from "./contents/case/ClosedCaseDetail";
import ScheduledCases from "./contents/case/ScheduledCases";
import UnScheduledCases from "./contents/case/UnscheduledCases";
import EmployeeProfiles from "./contents/Profiles/EmployeeProfiles";
import HearingRoomProfiles from "./contents/Profiles/HearingRoomProfiles";
import AddCase from "./contents/case/AddCase";
import EmployeeTimeOff from "./contents/Profiles/EmployeeTimeOff";
import HearingRoomUnavailability from "./contents/Profiles/HearingRoomUnavailability";
import DataManager from "./contents/DataManager/DataManager";
//import PrintCoversheet from "./contents/case/PrintCoversheet";
import DAPUpdate from "./contents/dlUpdates/DAPUpdate";
import DAMUpdate from "./contents/dlUpdates/DAMUpdate";
import DANUpdate from "./contents/dlUpdates/DANUpdate";
import DCNUpdate from "./contents/dlUpdates/DCNUpdate";
import DIEUpdate from "./contents/dlUpdates/DIEUpdate";
import DIXUpdate from "./contents/dlUpdates/DIXUpdate";
import DUAUpdate from "./contents/dlUpdates/DUAUpdate";
import DASUpdate from "./contents/dlUpdates/DASUpdate";
import DARUpdate from "./contents/dlUpdates/DARUpdate";
import DUEUpdate from "./contents/dlUpdates/DUEUpdate";
import DUZUpdate from "./contents/dlUpdates/DUZUpdate";
import DUJUpdate from "./contents/dlUpdates/DUJUpdate";
import DUVUpdate from "./contents/dlUpdates/DUVUpdate";
import DUPUpdate from "./contents/dlUpdates/DUPUpdate";
import DUNUpdate from "./contents/dlUpdates/DUNUpdate";
import DUWUpdate from "./contents/dlUpdates/DUWUpdate";
import DUXUpdate from "./contents/dlUpdates/DUXUpdate";
import DUHUpdate from "./contents/dlUpdates/DUHUpdate";
import DUFUpdate from "./contents/dlUpdates/DUFUpdate";
import DUKUpdate from "./contents/dlUpdates/DUKUpdate";
import DLUpdates from "./contents/dlUpdates/DLUpdates";
import ME2Update from "./contents/dlUpdates/ME2Update";
import ME3Update from "./contents/dlUpdates/ME3Update";
import ME4Update from "./contents/dlUpdates/ME4Update";
import ME5Update from "./contents/dlUpdates/ME5Update";
import ME6Update from "./contents/dlUpdates/ME6Update";
import DLInquiries from "./contents/dlInquiries/DLInquiries";
import EmployeeCalendarSchedule from "./contents/Calendar/EmployeeCalendar-Schedule";
import OfficeCalendar from "./contents/Calendar/OfficeCalendar";
import HearingRoomCalendar from "./contents/Calendar/HearingRoomCalendar";

const content = () => (
  <div tabIndex="-1" className="contentlayout">
 
    <Switch>
    <ScrollPanel tabIndex="-1"
                style={{
                  overflowX: "hidden",
                     width: "100%",
                    height: "calc(100% - 40px)",
                    backgroundColor: "rgba(0,0,0,0)"
                }}
            >  
            
      <Route exact path="/" component={HomePage} />
      <Route exact path="/News" component={NewsPage} />
      <Route exact path="/EmployeeProfiles" component={EmployeeProfiles} />
      <Route exact path="/HearingRoomProfiles" component={HearingRoomProfiles} />
      {/* <Route path="/search" component={Search} /> */}
      <Route path="/search/searchText/:searchText" component={Search} />
      <Route path="/customerDetails/dlNumber/:dlNumber" component={CustomerDetails} />
      <Route path="/caseDetails/CaseNumber/:CaseNumber" component={CaseDetails} />
      <Route path="/closedCaseDetails/CaseNumber/:CaseNumber" component={ClosedCaseDetail} />
      <Route path="/scheduledCases" component={ScheduledCases} /> 
      <Route path="/unScheduledCases" component={UnScheduledCases} /> 
      <Route path="/newcase" component={AddCase} />
      <Route path="/dapUpdate/DLNumber/:dlNumber" component={DAPUpdate} />
      <Route path="/damUpdate/DLNumber/:dlNumber" component={DAMUpdate} />
      <Route path="/danUpdate/DLNumber/:dlNumber" component={DANUpdate} />
      <Route path="/dcnUpdate/DLNumber/:dlNumber" component={DCNUpdate} />
      <Route path="/duaUpdate/DLNumber/:dlNumber" component={DUAUpdate} />
      <Route path="/dieUpdate/DLNumber/:dlNumber" component={DIEUpdate} />
      <Route path="/dixUpdate" component={DIXUpdate} />
      <Route path="/dasUpdate/DLNumber/:dlNumber" component={DASUpdate} />
      <Route path="/darUpdate/DLNumber/:dlNumber" component={DARUpdate} />
      <Route path="/dueUpdate/DLNumber/:dlNumber" component={DUEUpdate} />
      <Route path="/duzUpdate/DLNumber/:dlNumber" component={DUZUpdate} />
      <Route path="/dujUpdate/DLNumber/:dlNumber" component={DUJUpdate} />
      <Route path="/duhUpdate/DLNumber/:dlNumber" component={DUHUpdate} />
      <Route path="/dunUpdate/DLNumber/:dlNumber" component={DUNUpdate} />
      <Route path="/duvUpdate/DLNumber/:dlNumber" component={DUVUpdate} />
      <Route path="/dupUpdate/DLNumber/:dlNumber" component={DUPUpdate} />
      <Route path="/duxUpdate/DLNumber/:dlNumber" component={DUXUpdate} />
      <Route path="/duwUpdate/DLNumber/:dlNumber" component={DUWUpdate} />
      <Route path="/dufUpdate/DLNumber/:dlNumber" component={DUFUpdate} />
      <Route path="/dukUpdate/DLNumber/:dlNumber" component={DUKUpdate} />
      <Route path="/me2Update/DLNumber/:dlNumber" component={ME2Update} />
      <Route path="/me3Update/DLNumber/:dlNumber" component={ME3Update} />
      <Route path="/me4Update/DLNumber/:dlNumber" component={ME4Update} />
      <Route path="/me5Update/DLNumber/:dlNumber" component={ME5Update} />
      <Route path="/me6Update/DLNumber/:dlNumber" component={ME6Update} />
      <Route path="/dlUpdates" component={DLUpdates} />
      <Route path="/dlInquiries" component={DLInquiries} />
      <Route path="/EmployeeTimeOff" component={EmployeeTimeOff} /> 
      <Route path="/HearingRoomUnavailability" component={HearingRoomUnavailability} />
      <Route path="/DataManager" component={DataManager} />
      <Route path="/employeeCalendarSchedule" component={EmployeeCalendarSchedule} />
      <Route path="/officeCalendar" component={OfficeCalendar} />
      <Route path="/hearingroomCalendar" component={HearingRoomCalendar} />
      {/* <Route path="/printCaseCoversheet/CaseNumber/:CaseNumber" component={PrintCoversheet} /> */}

      {/* <Route path='/search' 
          render={ props => <Search {...props} />}
        /> */}
            </ScrollPanel>
    </Switch>

  </div>
);

export default content;














      
