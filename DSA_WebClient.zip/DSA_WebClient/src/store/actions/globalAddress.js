//const localAddress = "http://localhost:32610";
const devServerAddress = "http://dmvwebd09:4000";
// var testServerAddress = "";
// var prodServerAddress = "";
const globalAddress =  devServerAddress; // Assign address value to globally change it.
export default globalAddress;


