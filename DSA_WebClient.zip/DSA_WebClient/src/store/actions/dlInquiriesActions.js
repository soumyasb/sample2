import axios from "axios";
import globalAddress from "./globalAddress";

export const getDLInquiriesErrorData = (data) => ({
  type: "GET_DLINQUIRIESERRORDATA",
  data: data
});

// // To get ME1 data
// export const getME1DataObj = data => ({
//     type: "GET_ME1DATA",
//     data: data
//   });
  
//   export const getME1Data = (dlNumber) => {
      
//     return dispatch => {
//       axios.get(globalAddress+"/api/ME1/getME1?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
//         if(response.status === 200)
//         {dispatch(getME1DataObj(response.data));}
//       }).catch((error) => {
//         
//         if(error.response.status === 422)
//          {
         
//          dispatch(getDLInquiriesErrorData(error.response.data));
//          
//          }
//          if(error.response.status === 404)
//          {
          
//           dispatch(getDLInquiriesErrorData("DL number '"+error.response.request.responseURL.split("=")[1]+"' was not found."));
//           
//          }
//        });
//     };
//     };

    // To get inquiry data

    export const getDLInqDataObj = data => ({
      type: "GET_DLINQDATA",
      data: data
    });
    
    export const getDLINQData = (dlInqObj) => {
      return dispatch => {
        axios.post(globalAddress+"/api/Inquiry/getDLInqData",dlInqObj).then(response => {
          if(response.status === 200)
          {dispatch(getDLInqDataObj(response.data));}
        }).catch((error) => {
          
          if(error.response.status === 422)
           {
           
           dispatch(getDLInquiriesErrorData(error.response.data));
           
           }
           if(error.response.status === 404)
           {
            if(error.response.request.responseURL)
            {
              dispatch(getDLInquiriesErrorData("DL number '"+error.response.request.responseURL.split("=")[1]+"' was not found."));
            }
      else
      {
        dispatch(getDLInquiriesErrorData("The entered DL number was not found."));
      }
            
           }
         });
      };
      };

      export const resetDlInqState = () => ({
        type: "RESET_DLINQ",
        data: ""
      });
      
  
