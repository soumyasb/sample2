import axios from "axios";
import globalAddress from "./globalAddress";
// CALENDAR ACTIONS


// To get employees list for Employee Calendar
export const getCalendarEmployeesData = data => ({
    type: "GET_CALENDAREMPLOYEES",
    data: data
  });
  
  export const getCalendarEmployees= () => {
    return dispatch => {
      axios.get(globalAddress+"/api/EmployeeCalendar/GetCalendarEmployees?rand="+Math.random()).then(response => {
        dispatch(getCalendarEmployeesData(response.data));
      });
    };
  };

  // To get multiple Employees Calendars for multiple dates
export const getCalendarEmployeesCalendarsData = data => ({
    type: "GET_EMPLOYEESCALENDARS",
    data: data
  });
  
  export const getCalendarEmployeesCalendars= (officeID, empIds, dates) => {
      var restURL = "";
      empIds.map((empId) => { restURL = restURL+"&empIds="+empId;
    return ""; });
      dates.map((date) => { restURL = restURL+"&dates="+date.toISOString();
    return ""; });
    return dispatch => {
      axios.get(globalAddress+"/api/EmployeeCalendar/ProcessCalendarRequest?officeID="+officeID+restURL+"&rand="+Math.random()).then(response => {
        dispatch(getCalendarEmployeesCalendarsData(response.data));
      });
    };
  };

  // To get cases assigned to an employee
export const getCasesAssignedData = data => ({
  type: "GET_CASESASSIGNED",
  data: data
});

export const getCasesAssigned= (empId,sort) => {
  return dispatch => {
    axios.get(globalAddress+"/api/EmployeeCalendar/GetCasesAssigned?empId="+empId+"&sort="+sort+"&rand="+Math.random()).then(response => {
      dispatch(getCasesAssignedData(response.data));
    });
  };
};

// To get offices
export const getCalendarOfficesData = data => ({
  type: "GET_CALENDAROFFICES",
  data: data
});

export const getCalendarOffices= () => {
  return dispatch => {
    axios.get(globalAddress+"/api/OfficeCalendar/GetDistrictOffices?rand="+Math.random()).then(response => {
      dispatch(getCalendarOfficesData(response.data));
    });
  };
};

  // To get Office Calendar
  export const getOfficeCalendarData = data => ({
    type: "GET_OFFICECALENDARS",
    data: data
  });
  
  export const getOfficeCalendar= (officeID, date) => {
    return dispatch => {
      axios.get(globalAddress+"/api/OfficeCalendar/ProcessCalendarRequest?officeID="+officeID+"&fromDate="+date.toISOString()+"&rand="+Math.random()).then(response => {
        dispatch(getOfficeCalendarData(response.data));
      });
    };
  };

  // export const resetCalendarState = () => 
  // {
  //   return dispatch =>
  //   {
  //     dispatch({type: "RESET_CALENDAR", data: null});
  //   }
  // }

  export const resetCalendarState = () => ({
    type: "RESET_CALENDAR",
    data: ""
  });
  
  // To get Hearing Rooms
export const getHearingroomsData = data => ({
  type: "GET_HEARINGROOMS",
  data: data
});

export const getHearingRooms= () => {
  return dispatch => {
    axios.get(globalAddress+"/api/LocationCalendar/GetDistrictOffices?rand="+Math.random()).then(response => {
      dispatch(getHearingroomsData(response.data));
    });
  };
};

  // To get Hearing Room Calendar
  export const getHearingRoomCalendarData = data => ({
    type: "GET_HEARINGROOMCALENDAR",
    data: data
  });
  
  export const getHearingRoomCalendar= (offAbr, roomId, officeId, date) => {
    return dispatch => {
      axios.get(globalAddress+"/api/LocationCalendar/ProcessCalendarRequest?OfficeAbreviation="+offAbr+"&room="+roomId+"&officeId="+officeId+"&startDate="+date.toISOString()+"&rand="+Math.random()).then(response => {
        dispatch(getHearingRoomCalendarData(response.data));
      });
    };
  };