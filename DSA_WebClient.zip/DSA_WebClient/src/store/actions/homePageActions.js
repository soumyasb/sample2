import axios from "axios";
import globalAddress from "./globalAddress";
//HOMEPAGE ACTIONS
export const getHomePage = data => ({
  type: "GET_HOMEPAGE",
  data: data
});

export const initHomePage = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/HomePage?rand="+Math.random()).then(response => {
      dispatch(getHomePage(response.data));
    });
  };
};

export const resetHomeState = () => ({
  type: "RESET_HOME",
  data: ""
});
