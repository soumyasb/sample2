//UI ACTIONS
export const setNewsModal = val => ({
  type: "SET_NEWS_MODAL",
  val
});

export const setNewsIdx = idx => ({
  type: "SET_NEWS_IDX",
  idx
});

export const setCustomerPageStatus = (val) => ({
  type: "SET_CUSTOMERPAGESTATUS",
  val
});

// export const setHeaderKey = (val) => ({
//   type: "SET_HEADERKEY",
//   val
// })