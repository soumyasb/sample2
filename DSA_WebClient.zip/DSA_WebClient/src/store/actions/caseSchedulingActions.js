import axios from "axios";
import globalAddress from "./globalAddress";
// CASE SCHEDULING ACTIONS


// To get the case info

export const getCaseInfoData = data => ({
  type: "GET_CASEINFO",
  data: data
});

export const getCaseInfo = (caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/CaseScheduling/GetCaseInfo?caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
if(response.status === 200)
{
  dispatch(getCaseInfoData(response.data));
}    
}).catch((error) => {
  

  if(error.response === undefined){
    dispatch(getSchedulingErrorData(error.message));
  }
  else
  {
    if(error.response.status === 422)
    {
    dispatch(getSchedulingErrorData(error.response.data));
    }
    else{
      
        dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
      }
  }

});
  }}

  // To get the default times

export const getDefaultHearingTimesData = data => (
  {
  type: "GET_DEFAULTHEARINGTIMES",
  data: data
}
);

export const getDefaultHearingTimes = (caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/CaseScheduling/GetDefaultHearingTimes?caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
if(response.status === 200)
{
  dispatch(getDefaultHearingTimesData(response.data));
}    
}).catch((error) => {
  

  if(error.response === undefined){
    dispatch(getSchedulingErrorData(error.message));
  }
  else
  {
    if(error.response.status === 422)
    {
    dispatch(getSchedulingErrorData(error.response.data));
    }
    else{
      
        dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
      }
  }

});
  }}


  // To get available timeslots

  export const getAvailableTimeSlotsData = data => ({
    type: "GET_AVAILABLETIMESLOTSDATA",
    data: data
  });
  
  export const getAvailableTimeSlots = (officeId, fromDate) => {

    return dispatch => {
      axios.get(globalAddress+"/api/CaseScheduling/GetAvailableTimeSlots?officeId="+officeId+"&FromDate="+fromDate+"&rand="+Math.random()).then(response => {
  if(response.status === 200)
  {
    dispatch(getAvailableTimeSlotsData(response.data));
  }    
  }).catch((error) => {
  
    if(error.response === undefined){
      dispatch(getSchedulingErrorData(error.message));
    }
    else
    {
      if(error.response.status === 422)
      {
      dispatch(getSchedulingErrorData(error.response.data));
      }
      else{
        
          dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
        }
    }
  });
    }}

      // To get previous day available timeslots

  export const getPreviousDayAvailableTimeSlotsData = data => ({
    type: "GET_PREVIOUSDAYAVAILABLETIMESLOTSDATA",
    data: data
  });
  
  export const getPreviousDayAvailableTimeSlots = (officeId, fromDate) => {
    
    return dispatch => {
      axios.get(globalAddress+"/api/CaseScheduling/GetPreviousDayAvailableTimeSlots?officeId="+officeId+"&FromDate="+fromDate+"&rand="+Math.random()).then(response => {
  if(response.status === 200)
  {
    dispatch(getPreviousDayAvailableTimeSlotsData(response.data));
  }    
  }).catch((error) => {
  
    if(error.response === undefined){
      dispatch(getSchedulingErrorData(error.message));
    }
    else
    {
      if(error.response.status === 422)
      {
      dispatch(getSchedulingErrorData(error.response.data));
      }
      else{
        
          dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
        }
    }
  });
    }}

      // To get next day available timeslots

  export const getNextDayAvailableTimeSlotsData = data => ({
    type: "GET_NEXTDAYAVAILABLETIMESLOTSDATA",
    data: data
  });
  
  export const getNextDayAvailableTimeSlots = (officeId, fromDate) => {
    
    return dispatch => {
      axios.get(globalAddress+"/api/CaseScheduling/GetNextDayAvailableTimeSlots?officeId="+officeId+"&FromDate="+fromDate+"&rand="+Math.random()).then(response => {
  if(response.status === 200)
  {
    dispatch(getNextDayAvailableTimeSlotsData(response.data));
  }    
  }).catch((error) => {
  
    if(error.response === undefined){
      dispatch(getSchedulingErrorData(error.message));
    }
    else
    {
      if(error.response.status === 422)
      {
      dispatch(getSchedulingErrorData(error.response.data));
      }
      else{
        
          dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
        }
    }
  });
    }}

  export const getSchedulingErrorData = (data) => ({
    type: "GET_SCHEDULINGERRORDATA",
    data: data
  });

  // To schedule a case

  export const getScheduleCaseDataObj = data => ({
    type: "GET_SCHEDULECASEDATA",
    data: data
  });
  
  export const scheduleCase = (scheduleObj) => {
      
    return dispatch => {
      axios.post(globalAddress+"/api/CaseScheduling/ScheduleCase",scheduleObj).then(response => {
        if(response.status === 200)
        {dispatch(getScheduleCaseDataObj(response.data));}
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
        });}
    };

    // To override a case schedule

  export const getOverrideScheduleDataObj = data => ({
    type: "GET_OVERRIDESCHEDULEDATA",
    data: data
  });
  
  export const overrideCaseSchedule = (overrideObj) => {
      
    return dispatch => {
      axios.post(globalAddress+"/api/CaseScheduling/ScheduleCaseOverride",overrideObj).then(response => {
        if(response.status === 200)
        {dispatch(getOverrideScheduleDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
        });}
    };

     // To get Employee Calendar

  export const getEmployeeCalendarData = data => ({
    type: "GET_EMPLOYEECALENDARDATA",
    data: data
  });
  
  export const getEmployeeCalendar = (empId,officeId, fromDate) => {

    return dispatch => {
      axios.get(globalAddress+"/api/CaseScheduling/ GetEmployeeCalender?empId="+empId+"&officeId="+officeId+"&FromDate="+fromDate+"&rand="+Math.random()).then(response => {
  if(response.status === 200)
  {
    dispatch(getEmployeeCalendarData(response.data));
  }    
  }).catch((error) => {
  
    if(error.response === undefined){
      dispatch(getSchedulingErrorData(error.message));
    }
    else
    {
      if(error.response.status === 422)
      {
      dispatch(getSchedulingErrorData(error.response.data));
      }
      else{
        
          dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
        }
    }
  });
    }}

      // To get previous day Employee Calendar

  export const getPreviousDayEmployeeCalendarData = data => ({
    type: "GET_PREVIOUSDAYEMPLOYEECALENDARDATA",
    data: data
  });
  
  export const getPreviousDayEmployeeCalendar = (empId, officeId, fromDate) => {
    
    return dispatch => {
      axios.get(globalAddress+"/api/CaseScheduling/GetPreviousDayEmployeeCalendar?empId="+empId+"&officeId="+officeId+"&FromDate="+fromDate+"&rand="+Math.random()).then(response => {
  if(response.status === 200)
  {
    dispatch(getPreviousDayEmployeeCalendarData(response.data));
  }    
  }).catch((error) => {
  
    if(error.response === undefined){
      dispatch(getSchedulingErrorData(error.message));
    }
    else
    {
      if(error.response.status === 422)
      {
      dispatch(getSchedulingErrorData(error.response.data));
      }
      else{
        
          dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
        }
    }
  });
    }}

      // To get next day Employee Calendar

      export const getNextDayEmployeeCalendarData = data => ({
        type: "GET_NEXTDAYEMPLOYEECALENDARDATA",
        data: data
      });
      
      export const getNextDayEmployeeCalendar = (empId, officeId, fromDate) => {
        
        return dispatch => {
          axios.get(globalAddress+"/api/CaseScheduling/GetNextDayEmployeeCalendar?empId="+empId+"&officeId="+officeId+"&FromDate="+fromDate+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {
        dispatch(getNextDayEmployeeCalendarData(response.data));
      }    
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
      });
        }}
    

         // To get Employees for scheduling

      export const getEmployeesForSchedulingData = data => ({
        type: "GET_EMPLOYEESFORSCHEDULINGDATA",
        data: data
      });
      
      export const getEmployeesForScheduling = (officeId) => {
        
        return dispatch => {
          axios.get(globalAddress+"/api/CaseScheduling/ GetEmployeesForScheduling?officeId="+officeId+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {
        dispatch(getEmployeesForSchedulingData(response.data));
      }    
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
      });
        }}

// To get ReSchedule or ReConvene Case Init data

  export const initRSRCDataObj = data => ({
    type: "INIT_RSRCDATAOBJ",
    data: data
  });
  
  export const initRSRCCaseData = (type, caseDetailObj) => {
    var url = "";
      if(type === "ReSchedule")
      {
        url = globalAddress+"/api/CaseScheduling/InitReScheduleCase/"+caseDetailObj.CaseNumber;
      }
      if(type === "ReConvene")
      {
        url = globalAddress+"/api/CaseScheduling/InitReconvene/"+caseDetailObj.CaseNumber;
      }
    return dispatch => {
      axios.post(url,caseDetailObj).then(response => {
        if(response.status === 200)
        {dispatch(initRSRCDataObj(response.data));}
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
        });}
    };

    // To update ReSchedule or ReConvene option for a case

  export const updateRSRCCaseData = data => ({
    type: "GET_RSRCUPDATEDATA",
    data: data
  });
  
  export const updateRSRCCase = (type, rsrcdataobj) => {

    return dispatch => {
      axios.post(globalAddress+"/api/CaseScheduling/"+type+"Case/"+rsrcdataobj.Casenumber,rsrcdataobj).then(response => {
        if(response.status === 200)
        {dispatch(updateRSRCCaseData(response.data));}
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
        });}
    };

     // To initialize Case ReExamination screen

  export const initCaseReExamData = data => ({
    type: "GET_CASEREEXAMINITDATA",
    data: data
  });
  
  export const initCaseReExam = (customerDetailObj) => {
    return dispatch => {
      axios.post(globalAddress+"/api/ReExamination/InitializeNewReExam?dlNumber="+customerDetailObj.DLNumber,customerDetailObj).then(response => {
        if(response.status === 200)
        {dispatch(initCaseReExamData(response.data));}
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
        });}
    };

     // To process Case ReExamination

  export const processCaseReExamData = data => ({
    type: "GET_PROCESSCASEREEXAMDATA",
    data: data
  });
  
  export const processCaseReExam = (caseReExamObj) => {

    return dispatch => {
      axios.post(globalAddress+"/api/ReExamination/ProcessReExam?dlNumber="+caseReExamObj.DLNumber,caseReExamObj).then(response => {
        if(response.status === 200)
        {dispatch(processCaseReExamData(response.data));}
      }).catch((error) => {
      
        if(error.response === undefined){
          dispatch(getSchedulingErrorData(error.message));
        }
        else
        {
          if(error.response.status === 422)
          {
          dispatch(getSchedulingErrorData(error.response.data));
          }
          else{
            
              dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
            }
        }
        });}
    };

    // To get Info for Case 2011 Scheduling (ReExam)

    export const get2011CaseInfoData = data => ({
      type: "GET_2011CASEINFODATA",
      data: data
    });
    
    export const get2011CaseInfo = (caseNumber) => {
      
      return dispatch => {
        axios.get(globalAddress+"/api/ReExamination/GetCaseInfo?caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
    if(response.status === 200)
    {
      dispatch(get2011CaseInfoData(response.data));
    }    
    }).catch((error) => {
    
      if(error.response === undefined){
        dispatch(getSchedulingErrorData(error.message));
      }
      else
      {
        if(error.response.status === 422)
        {
        dispatch(getSchedulingErrorData(error.response.data));
        }
        else{
          
            dispatch(getSchedulingErrorData(error.response.status+" - "+error.response.statusText+" RandomMathNumber"+Math.random().toString()));
          }
      }
    });
      }}

      export const resetCaseSchedulingState = () => ({
        type: "RESET_CASESCHEDULING",
        data: ""
      });
      