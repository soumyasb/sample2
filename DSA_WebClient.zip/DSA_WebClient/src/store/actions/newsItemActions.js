import axios from "axios";
import globalAddress from "./globalAddress";
//NEWSITEMS ACTIONS
export const getNewsItemPage = data => ({
  type: "GET_NEWSITEMS",
  data: data
});

export const initNewsItemPage = () => {
  return dispatch => {
      axios.get(globalAddress+"/api/NewsItems?rand="+Math.random(), {crossDomain: true}).then(response => {
        dispatch(getNewsItemPage(response.data));
      }).catch((error) => {
        if(error.response.status === 401)
        {
        dispatch(getNewsErrorData("This user is not authorized to view the News Items."));
        }
        else{
          dispatch(getNewsErrorData(error.response.data));
        }
      });
  };
};

export const getCreateNewsItemObj = data => ({
  type: "GET_CREATENEWSITEM",
  data: data
});

export const initCreateNewsItemObj = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/NewsItems/CreateNewsItem?rand="+Math.random()).then(response => {
      dispatch(getCreateNewsItemObj(response.data));
    }).catch((error) => {
    });
  };
};

export const getEditNewsItemObj = data => ({
  type: "GET_EDITNEWSITEM",
  data: data
});

export const initEditNewsItemObj = (newsId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/NewsItems/EditNewsItem/"+newsId+"?rand="+Math.random()).then(response => {
      dispatch(getEditNewsItemObj(response.data));
    }).catch((error) => {
    });
  };
};

export const getNewsItemDetailsObj = data => ({
  type: "GET_NEWSITEMDETAILS",
  data: data
});

export const getNewsErrorData = data => ({
  type: "GET_NEWSITEMERRORDATA",
  data: data
});

export const initNewsItemDetails = (newsId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/NewsItems/GetNewsItemDetails/"+newsId+"?rand="+Math.random()).then(response => {
      dispatch(getNewsItemDetailsObj(response.data));
    }).catch((error) => {
    });
};
  };
  
  export const initSaveNewsItem = (newsItem) => {
    return dispatch => {
      axios.post(globalAddress+"/api/NewsItems/AddNewsItem",newsItem).then(response => {
        if(response.status === 200)
        {
          dispatch(initNewsItemPage());
        }       
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
        dispatch(getNewsErrorData(error.response.data));
       }
    });
  };
  };

  export const getModifyNewsItemData = data => ({
    type: "GET_MODIFYNEWSITEMDATA",
    data: data
  });

  export const initModifyNewsItem = (newsItem) => {
    return dispatch => {
      axios.post(globalAddress+"/api/NewsItems/ModifyNewsItem",newsItem).then(response => {
        if(response.status === 200)
        {
          dispatch(getModifyNewsItemData(response.data));
        }
    }).catch((error) => {
      if(error.response.status === 422)
       {
        dispatch(getNewsErrorData(error.response.data));
       }
    });
  };
  };
  
  export const initDeleteNewsItem = (newsId) => {
    return dispatch => {
      axios.get(globalAddress+"/api/NewsItems/DeleteNewsItem/"+newsId+"?rand="+Math.random()).then(response => {
        if(response.status === 204)
        {
          dispatch(initNewsItemPage());
        }
    }).catch((error) => {
    });
  };
  };

  export const getOfficeDetailsData = data => ({
    type: "GET_OFFICEDETAILS",
    data: data
  });
  
  export const initGetOfficeDetails = (empId, empType) => {
    return dispatch => {
      axios.get(globalAddress+"/api/NewsItems/GetUserOffices/"+empId+"/"+empType+"?rand="+Math.random()).then(response => {
        dispatch(getOfficeDetailsData(response.data));
  }).catch((error) => {
    
  });
};
  };

  export const resetNewsItemsState = () => ({
    type: "RESET_NEWSITEMS",
    data: ""
  });
  