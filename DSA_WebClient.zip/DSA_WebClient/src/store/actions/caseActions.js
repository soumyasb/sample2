import axios from "axios";
import globalAddress  from "./globalAddress";

// CASE ACTIONS

export const getCaseSearchResults = data => ({
  type: "GET_CASE_SEARCHRESULTS",
  data: data
});

export const searchCases = (seachString) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/Search/"+seachString+"?rand="+Math.random()).then(response => {
if(response.status === 200)
{
  dispatch(getCaseSearchResults(response.data));
}    
}).catch((error) => {
if(error.response.status === 422)
{
dispatch(getCaseErrorData(error.response.data));
}
else{
  if(error.response !== undefined){
    dispatch(getCaseErrorData(error.response.data));
  }
  else
  {
    dispatch(getCaseErrorData("Network Error"));
  }
}
});
  }}

export const getCustomerDetailsData = data => ({
  type: "GET_CUSTOMERDETAILS",
  data: data
});

export const getCustomerDetails = (dlNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Customer/"+dlNumber+"?rand="+Math.random()).then(response => {
      dispatch(getCustomerDetailsData(response.data));
    });
  };
};

export const getScheduledCasesData = data => ({
  type: "GET_SCHEDULEDCASES",
  data: data
});

export const getScheduledCases = (officeId, sort) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/GetScheduledCases?officeid="+officeId+"&sort="+sort+"&rand="+Math.random()).then(response => {
      dispatch(getScheduledCasesData(response.data));
    });
  };
};

export const getUnScheduledCasesData = data => ({
  type: "GET_UNSCHEDULEDCASES",
  data: data
});

export const getUnScheduledCases = (officeId, sort) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/GetUnScheduledCases?officeid="+officeId+"&sort="+sort+"&rand="+Math.random()).then(response => {
      dispatch(getUnScheduledCasesData(response.data));
    });
  };
};

export const getCustomerD26InfoData = data => ({
  type: "GET_CUSTOMERD26INFO",
  data: data
});

export const getCustomerD26Info = (dlNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Customer/GetCustomerD26Info/"+dlNumber+"?rand="+Math.random()).then(response => {
      dispatch(getCustomerD26InfoData(response.data));
    });
  };
};

export const getCaseDetailsData = data => ({
  type: "GET_CASEDETAILS",
  data: data
});

export const getCaseDetails = (caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/"+caseNumber+"?rand="+Math.random()).then(response => {
      dispatch(getCaseDetailsData(response.data));
    });
  };
};

export const getClosedCaseDetailData = data => ({
  type: "GET_CLOSEDCASEDETAILS",
  data: data
});

export const getClosedCaseDetail = (caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/ GetClosedCaseDetail?caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
      dispatch(getClosedCaseDetailData(response.data));
    });
  };
};


export const getHearingTypesData = data => ({
  type: "GET_HEARINGTYPES",
  data: data
});

export const getHearingTypes = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/GetHearingTypes?rand="+Math.random()).then(response => {
      dispatch(getHearingTypesData(response.data));
    });
  };
};

export const getCaseReasonsData = data => ({
  type: "GET_CASEREASONS",
  data: data
});

export const getCaseReasons = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/GetCaseReasons?rand="+Math.random()).then(response => {
      dispatch(getCaseReasonsData(response.data));
    });
  };
};

export const getCaseReferralsData = data => ({
  type: "GET_CASEREFERRALS",
  data: data
});

export const getCaseReferrals = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/GetCaseReferrals?rand="+Math.random()).then(response => {
      dispatch(getCaseReferralsData(response.data));
    });
  };
};

export const getCaseCertificationsData = data => ({
  type: "GET_CASECERTIFICATIONS",
  data: data
});

export const getCaseCertifications = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/ GetCaseCertifications?rand="+Math.random()).then(response => {
      dispatch(getCaseCertificationsData(response.data));
    });
  };
};


export const getCaseCoverSheetData = data => ({
  type: "GET_CASECOVERSHEET",
  data: data
});

export const getCaseCoverSheet = (caseNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/Case/GetCaseCoverSheet?caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
      dispatch(getCaseCoverSheetData(response.data));
    });
  };
};

export const getModifyCaseData = data => ({
  type: "GET_MODIFYCASEDATA",
  data: data
});

export const modifyCaseDetail = (caseDetailObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Case/ModifyCase/"+caseDetailObj.CaseNumber,caseDetailObj).then(response => {
      if(response.status === 200)
      {
       dispatch(getModifyCaseData(response.data));
      }    
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getCaseErrorData(error.response.data.CaseDetailDTO));
     }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getCreateCaseDetailsData = data => ({
  type: "GET_CREATECASEDATA",
  data: data
});

export const getCreateCaseDetails = (customerDetail) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Case/CreateNewCase", customerDetail).then(response => {
      dispatch(getCreateCaseDetailsData(response.data));
    });
  };
};

export const getCaseAddData = data => ({
  type: "GET_CASEADDDATA",
  data: data
});

export const addCase = (caseDetailObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Case/AddCase/", caseDetailObj).then(response => {
      if(response.status === 200)
      {
       dispatch(getCaseAddData(response.data));
      }    
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getCaseErrorData(error.response.data.CaseDetailForAddDTO));
     }
     else
     {
       if(error.response !== undefined){
         dispatch(getCaseErrorData(error.response.data));
       }
       else
       {
         dispatch(getCaseErrorData("Network Error"));
       }
     }
  });
};
};

export const getH6InfoData = data => ({
  type: "GET_H6INFO",
  data: data
});

export const getH6Info = (dlNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Inquiry/geth6?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getH6InfoData(response.data));
    });
  };
};

export const getDADInfoData = data => ({
  type: "GET_H6INFO",
  data: data
});

export const getDADInfo = (infoCode, dlNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Inquiry/geth6?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getH6InfoData(response.data));
    });
  };
};

export const getCaseScheduleDetailData = data => ({
  type: "GET_CASESCHEDULEDATA",
  data: data
});

export const getCaseScheduleDetail = (dlNumber, caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/GetCaseScheduleDetail?dlNumber="+dlNumber+"&caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
      dispatch(getCaseScheduleDetailData(response.data));
    });
  };
};

export const getCaseCommentsData = data => ({
  type: "GET_CASECOMMENTSDATA",
  data: data
});

export const getCaseComments = (caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Comment/"+caseNumber+"?rand="+Math.random()).then(response => {
      dispatch(getCaseCommentsData(response.data));
    });
  };
};

export const getCaseCommentAddData = (data) => ({
  type: "GET_CASECOMMENTADDDATA",
  data: data
});

export const getCaseErrorData = (data) => ({
  type: "GET_CASEERRORDATA",
  data: data
});

export const addCaseComment = (caseNumber, caseCommentObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Comment/"+ caseNumber, caseCommentObj).then(response => {
     if(response.status === 200)
      {
       dispatch(getCaseCommentAddData(response.data));
      }    
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getCaseErrorData(error.response.data.CommentDTO));
     }
     else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getCaseCommentDelData = data => ({
  type: "GET_CASECOMMENTDELDATA",
  data: data
});

export const deleteCaseComment = (caseNumber, commentDelObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Comment/DeleteCase/"+ caseNumber, commentDelObj).then(response => {
      dispatch(getCaseCommentDelData(response.data));
  }).catch((error) => {
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.CommentDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

// Case OIP Actions

export const getAllOIPsforCaseData = data => ({
  type: "GET_ALLOIPSFORCASEDATA",
  data: data
});

export const getAllOIPsforCase = (caseNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Oip/GetAll/"+ caseNumber+"?rand="+Math.random()).then(response => {
      dispatch(getAllOIPsforCaseData(response.data));
  }).catch((error) => {
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
      else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getOIPTypesListData = data => ({
  type: "GET_OIPTYPESDATA",
  data: data
});

export const getOIPTypesList = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/ GetOIPTypes?rand="+Math.random()).then(response => {
      dispatch(getOIPTypesListData(response.data));
  }).catch((error) => {
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
      else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getOIPLanguagesData = data => ({
  type: "GET_OIPLANGUAGESDATA",
  data: data
});

export const getOIPLanguages = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/ GetOIPLanguages?rand="+Math.random()).then(response => {
      if(response.status === 200)
      {
        dispatch(getOIPLanguagesData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
      else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getOIPLookUpResultsData = data => ({
  type: "GET_OIPLOOKUPRESULTSDATA",
  data: data
});

export const getOIPLookUpResults = (caseNumber, oipLookupObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Oipsearch/"+caseNumber,oipLookupObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getOIPLookUpResultsData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
      else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getOIPDeleteData = data => ({
  type: "GET_OIPDELETEDATA",
  data: data
});

export const deleteOIP = (oipDeleteObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/CaseOIP/Delete",oipDeleteObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getOIPDeleteData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.OIPDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getAssignOIPData = data => ({
  type: "GET_OIPASSIGNDATA",
  data: data
});

export const assignOIP = (oipAssignObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/CaseOIP/",oipAssignObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getAssignOIPData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.OIPDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getOIPRemoveData = data => ({
  type: "GET_OIPREMOVEDATA",
  data: data
});

export const removeOIP = (oipRemoveObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/CaseOIP/Remove",oipRemoveObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getOIPRemoveData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.OIPDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getupdateOIPData = data => ({
  type: "GET_UPDATEOIPDATA",
  data: data
});

export const updateOIP = (oipType,oipid,oipItemObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Oip/"+oipType+"/"+oipid,oipItemObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getupdateOIPData(response.data));
      }
  }).catch((error) => {
   
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.OIPDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const getSaveOIPData = data => ({
  type: "GET_SAVEOIPDATA",
  data: data
});

export const saveNewOIP = (oipType,oipItemObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Oip/"+oipType,oipItemObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getSaveOIPData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.OIPDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

// Case Suspense details

export const getCaseSuspenseData = data => ({
  type: "GET_CASESUSPENSEDATA",
  data: data
});

export const getCaseSuspenseDetails = (caseNumber) => {
  
  return dispatch => {
    axios.get(globalAddress+"/api/Case/ GetCaseSuspense?caseNumber="+caseNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {
        dispatch(getCaseSuspenseData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

// Get Employees For Office 

export const getEmployeesForOfficeData = data => ({
  type: "GET_EMPLOYEESFOROFFICE",
  data: data
});

export const getEmployeesForOffice = (officeId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/Case/GetEmployeesForMyOffice?officeid="+officeId).then(response => {
      if(response.status === 200)
      {
        dispatch(getEmployeesForOfficeData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

// Add Case Suspense

export const getAddCaseSuspenseData = data => ({
  type: "GET_ADDCASESUSPENSEDATA",
  data: data
});

export const addCaseSuspense = (addCaseSuspenseObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Case/ AddCaseSuspense",addCaseSuspenseObj).then(response => {
      if(response.status === 200)
      {
         dispatch(getAddCaseSuspenseData(response.data));
      }
  }).catch((error) => {
    
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.SuspenseCaseAddDTO));
    }

  });
};
};

// Modify Case Suspense

export const getModifyCaseSuspenseData = data => ({
  type: "GET_MODIFYCASESUSPENSEDATA",
  data: data
});

export const modifyCaseSuspense = (modifyCaseSuspenseObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/Case/ ModifyCaseSuspense",modifyCaseSuspenseObj).then(response => {
      if(response.status === 200)
      {
    dispatch(getModifyCaseSuspenseData(response.data));
      }
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.SuspenseCaseAddDTO));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

// Delete Case Suspense

export const getDeleteCaseSuspenseData = data => ({
  type: "GET_DELETECASESUSPENSEDATA",
  data: data
});

export const deleteCaseSuspense = (suspenseId) => {
  
  return dispatch => {
    axios.post(globalAddress+"/api/Case/ DeleteCaseSuspense?suspenseId="+suspenseId).then(response => {
      
      if(response.status === 200)
      {
        dispatch(getDeleteCaseSuspenseData(response.request.statusText));
      }
  }).catch((error) => {
      
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.SuspenseDelete));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

//  Get case suspense reasons

export const getCaseSuspenseReasonsData = data => ({
  type: "GET_CASESUSPENSEREASONSDATA",
  data: data
});

export const getCaseSuspenseReasons = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/case/LookupTables/GetSuspenseCaseReasons?rand="+Math.random()).then(response => {
      dispatch(getCaseSuspenseReasonsData(response.data));
  }).catch((error) => {
     
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data));
    }
    else
    {
      if(error.response !== undefined){
        dispatch(getCaseErrorData(error.response.data));
      }
      else
      {
        dispatch(getCaseErrorData("Network Error"));
      }
    }
  });
};
};

export const resetCaseState = () => ({
  type: "RESET_CASE",
  data: ""
});
