import axios from "axios";
import globalAddress from "./globalAddress";

//DATA MANAGER ACTIONS

// Employees

export const getAllEmployeesData = data => ({
  type: "GET_ALLEMPLOYEES",
  data: data
});

export const getAllEmployees = () => {
  return dispatch => {
      axios.get(globalAddress+"/api/DataManager/Employees?rand="+Math.random()).then(response => {
        dispatch(getAllEmployeesData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
};

export const getEmployeeByIdData = data => ({
  type: "GET_EMPLOYEEBYID",
  data: data
});

export const getEmployeeById = (empId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/Employees/GetEmployee/"+empId+"?rand="+Math.random()).then(response => {
      dispatch(getEmployeeByIdData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getEditEmpObj = data => ({
  type: "GET_EDITEMPLOYEEDATA",
  data: data
});

export const getEditEmployee = (empId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/Employees/EditEmployeeTemplate?id="+empId+"?rand="+Math.random()).then(response => {
      dispatch(getEditEmpObj(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getCreateEmployeeData = data => ({
  type: "GET_CREATEEMPLOYEEOBJ",
  data: data
});

export const initCreateEmployeeObj = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/Employees/CreateEmployeeTemplate?rand="+Math.random()).then(response => {
      dispatch(getCreateEmployeeData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
};
  };

  export const deleteEmployeeData = data => ({
    type: "GET_DELETEEMPLOYEEDATA",
    data: data
  });
  
  export const deleteEmployee = (empId) => {
    
    return dispatch => {
      axios.post(globalAddress+"/api/DataManager/Employees/DeleteEmployee/"+empId).then(response => {
        if(response.status === 204)
        {
          dispatch(deleteEmployeeData('terminated'));
        }
      }).catch((error) => {
        if(error.response.status === 422)
        {
         dispatch(getDMErrorData(error.response.data));
                    }
        else
        {
          dispatch(getDMErrorData(error.response.statusText));
        }
      });
  };
    };

    export const updateEmployeeData = data => ({
      type: "GET_UPDATEEMPLOYEEDATA",
      data: data
    });
    
    export const updateEmployee = (updateEmpObj) => {
      
      return dispatch => {
        axios.post(globalAddress+"/api/DataManager/Employees/UpdateEmployee", updateEmpObj).then(response => {
          
          dispatch(updateEmployeeData(response.data));
        }).catch((error) => {
          if(error.response.status === 422)
          {
           dispatch(getDMErrorData(error.response.data));
                      }
          else
          {
            dispatch(getDMErrorData(error.response.statusText));
          }
        });
    };
      };

      export const createEmployeeData = data => ({
        type: "GET_CREATEEMPLOYEEDATA",
        data: data
      });
      
      export const createEmployee = (createEmpObj) => {
        
        return dispatch => {
          axios.post(globalAddress+"/api/DataManager/Employees/CreateEmployee", createEmpObj).then(response => {
            
            dispatch(createEmployeeData(response.data));          
          }).catch((error) => {
            if(!error.response)
            {
              dispatch(getDMErrorData(error.message));
            }
            else  if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            
          });
      };
        };
  

        // Activity Types

        export const getAllActivityTypesData = data => ({
          type: "GET_ALLACTIVITYTYPES",
          data: data
        });
        
        export const getAllActivityTypes = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/ActivityType/GetActTypes?rand="+Math.random()).then(response => {
                dispatch(getAllActivityTypesData(response.data));
              }).catch((error) => {
                if(error.response.status === 422)
                {
                 dispatch(getDMErrorData(error.response.data));
                            }
                else
                {
                  dispatch(getDMErrorData(error.response.statusText));
                }
              });
          };
        };
        
        export const getActTypeDetailsByIdData = data => ({
          type: "GET_ACTTYPEDETAILSBYID",
          data: data
        });
        
        export const getActTypeDetailsById = (actId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/ActivityType/Details/"+actId+"?rand="+Math.random()).then(response => {
              dispatch(getActTypeDetailsByIdData(response.data));
            }).catch((error) => {
              if(error.response.status === 422)
              {
               dispatch(getDMErrorData(error.response.data));
                          }
              else
              {
                dispatch(getDMErrorData(error.response.statusText));
              }
            });
          };
        };
        
        export const getEditActTypeObj = data => ({
          type: "GET_EDITACTTYPEDATA",
          data: data
        });
        
        export const getEditActType = (actId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/ActivityType/Edit/",actId+"?rand="+Math.random()).then(response => {
              dispatch(getEditActTypeObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateActTypeData = data => ({
          type: "GET_CREATEACTTYPEDATA",
          data: data
        });
        
        export const initCreateActTypeObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/ActivityType/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateActTypeData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteActTypeData = data => ({
            type: "GET_DELETEACTTYPEDATA",
            data: data
          });
          
          export const initDeleteActTypeObj = (actId) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/ActivityType/Delete/"+actId+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteActTypeData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };

          export const deleteConfirmedActTypeData = data => ({
            type: "GET_DELETECONFIRMEDACTTYPEDATA",
            data: data
          });
          
          export const deleteConfirmedActType = (actId) => {
            
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/ActivityType/DeleteConfirmed/"+actId).then(response => {
             if(response.status === 200)
             {
              dispatch(deleteConfirmedActTypeData(response.data));
             }
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateActTypeData = data => ({
              type: "GET_UPDATEACTTYPEDATA",
              data: data
            });
            
            export const updateActType = (updateActTypeObj) => {
              
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/ActivityType/Edit",updateActTypeObj).then(response => {
                  dispatch(updateActTypeData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
                  {
                   dispatch(getDMErrorData(error.response.data));
                              }
                  else
                  {
                    dispatch(getDMErrorData(error.response.statusText));
                  }
                });
            };
              };
        
              export const createActTypeData = data => ({
                type: "GET_CREATEACTTYPEDATA",
                data: data
              });
              
              export const createActType = (createActTypeObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/ActivityType/Create",createActTypeObj).then(response => {
                    dispatch(createActTypeData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
                    {
                     dispatch(getDMErrorData(error.response.data));
                                }
                    else
                    {
                      dispatch(getDMErrorData(error.response.statusText));
                    }
                  });
              };
                };


 // Hearing Rooms

 export const getInitHearingRoomData = data => ({
  type: "GET_INITHEARINGROOMDATA",
  data: data
});

export const getInitHearingRoom = () => {
  return dispatch => {
      axios.get(globalAddress+"/api/DataManager/HearingRoom/InitializeHearingRoom?rand="+Math.random()).then(response => {
        dispatch(getInitHearingRoomData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
};

export const getHearingRoomsByOfficeIdData = data => ({
  type: "GET_HEARINGROOMSBYOFFICEID",
  data: data
});

export const getHearingRoomsByOfficeId = (officeId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/HearingRoom/GetHearingRooms/"+officeId+"?rand="+Math.random()).then(response => {
      dispatch(getHearingRoomsByOfficeIdData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getEditHRObj = data => ({
  type: "GET_EDITHRDATA",
  data: data
});

export const getEditHR = (officeId, roomNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/HearingRoom/EditTemplateOffice/"+officeId+roomNumber+"?rand="+Math.random()).then(response => {
      dispatch(getEditHRObj(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getCreateHRObj = data => ({
  type: "GET_CREATEHROBJ",
  data: data
});

export const initCreateHRObj = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/HearingRoom/CreateTemplateForHearingRoom?rand="+Math.random()).then(response => {
      dispatch(getCreateHRObj(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
};
  };

  export const getDeleteHRData = data => ({
    type: "GET_DELETEHRDATA",
    data: data
  });
  
  export const initDeleteHRObj = (officeId, roomNo) => {
    return dispatch => {
      axios.get(globalAddress+"/api/DataManager/HearingRoom/DeleteHearingRoom/"+officeId+"/"+roomNo+"?rand="+Math.random()).then(response => {
        dispatch(getDeleteHRData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
    };

  export const deleteConfirmedHRData = data => ({
    type: "GET_DELETECONFIRMEDHRDATA",
    data: data
  });
  
  export const deleteConfirmedHR = (roomId) => {
    
    return dispatch => {
      axios.post(globalAddress+"/api/DataManager/HearingRoom/DeleteConfirmed/"+roomId).then(response => {
        dispatch(deleteConfirmedHRData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
    };

    export const updateHRData = data => ({
      type: "GET_UPDATEHRDATA",
      data: data
    });
    
    export const updateHR = (updateHRObj) => {
      return dispatch => {
        axios.post(globalAddress+"/api/DataManager/HearingRoom/EditHearingRoom",updateHRObj).then(response => {
          dispatch(updateHRData(response.data));
        }).catch((error) => {
          if(error.response.status === 422)
          {
           dispatch(getDMErrorData(error.response.data));
                      }
          else
          {
            dispatch(getDMErrorData(error.response.statusText));
          }
        });
    };
      };

      export const createHRData = data => ({
        type: "GET_CREATEHRDATA",
        data: data
      });
      
      export const createHR = (createHRObj) => {
        return dispatch => {
          axios.post(globalAddress+"/api/DataManager/HearingRoom/CreateHearingRoom",createHRObj).then(response => {
           
          if(response.data.message !== undefined)
           {
            dispatch(getDMErrorData(response.data.message));
           } 
           else
           {
            dispatch(createHRData(response.data));
           }          
          }).catch((error) => {
            
            if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            } 
          } );
      };
        };

        // Hearing Times

 export const getHearingTimesData = data => ({
  type: "GET_HEARINGTIMESDATA",
  data: data
});

export const getHearingTimes = () => {
  return dispatch => {
      axios.get(globalAddress+"/api/DataManager/HearingTime/GetHearingTimes?rand="+Math.random()).then(response => {
        dispatch(getHearingTimesData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
};

export const getHearingTimeDetailsByIdData = data => ({
  type: "GET_HEARINGTIMEDETAILSBYID",
  data: data
});

export const getHearingTimeDetailsById = (hTId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/HearingTime/Details/"+hTId+"?rand="+Math.random()).then(response => {
      dispatch(getHearingTimeDetailsByIdData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getEditHTObj = data => ({
  type: "GET_EDITHTDATA",
  data: data
});

export const getEditHT = (hTId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/HearingTime/Edit/"+hTId+"?rand="+Math.random()).then(response => {
      dispatch(getEditHTObj(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getCreateHTData = data => ({
  type: "GET_CREATEHTDATA",
  data: data
});

export const initCreateHTObj = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/HearingTime/Create?rand="+Math.random()).then(response => {
      dispatch(getCreateHTData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
};
  };

  export const getDeleteHTData = data => ({
    type: "GET_DELETEHTDATA",
    data: data
  });
  
  export const initDeleteHTObj = (hTId) => {
    return dispatch => {
      axios.get(globalAddress+"/api/DataManager/HearingTime/Delete/"+hTId+"?rand="+Math.random()).then(response => {
        dispatch(getDeleteHTData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
    };

  export const deleteConfirmedHTData = data => ({
    type: "GET_DELETECONFIRMEDHTDATA",
    data: data
  });
  
  export const deleteConfirmedHT = (hTId) => {
    
    return dispatch => {
      axios.post(globalAddress+"/api/DataManager/HearingTime/DeleteConfirmed/"+hTId).then(response => {
        dispatch(deleteConfirmedHTData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
    };

    export const updateHTData = data => ({
      type: "GET_UPDATEHTDATA",
      data: data
    });
    
    export const updateHT = (updateHTObj) => {
      
      return dispatch => {
        axios.post(globalAddress+"/api/DataManager/HearingTime/Edit",updateHTObj).then(response => {
          dispatch(updateHTData(response.data));
        }).catch((error) => {
          if(error.response.status === 422)
          {
           dispatch(getDMErrorData(error.response.data));
                      }
          else
          {
            dispatch(getDMErrorData(error.response.statusText));
          }
        });
    };
      };

      export const createHTData = data => ({
        type: "GET_CREATEHTDATA",
        data: data
      });
      
      export const createHT = (createHTObj) => {
        return dispatch => {
          axios.post(globalAddress+"/api/DataManager/HearingTime/Create",createHTObj).then(response => {
            dispatch(createHRData(response.data));
          }).catch((error) => {
            if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
          });
      };
        };

          // Holidays

 export const getHolidaysData = data => ({
  type: "GET_HOLIDAYSDATA",
  data: data
});

export const getHolidays = () => {
  return dispatch => {
      axios.get(globalAddress+"/api/DataManager/Holiday/GetHolidays?rand="+Math.random()).then(response => {
        dispatch(getHolidaysData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
};

export const getHolidayDetailsByIdData = data => ({
  type: "GET_HOLIDAYDETAILSBYID",
  data: data
});

export const getHolidayDetailsById = (holId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/Holiday/Details/"+holId+"?rand="+Math.random()).then(response => {
      dispatch(getHolidayDetailsByIdData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getEditHolidayObj = data => ({
  type: "GET_EDITHOLIDAYDATA",
  data: data
});

export const getEditHoliday = (holId) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/Holiday/Edit/"+holId+"?rand="+Math.random()).then(response => {
      dispatch(getEditHolidayObj(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
  };
};

export const getCreateHolidayData = data => ({
  type: "GET_CREATEHOLIDAYDATA",
  data: data
});

export const initCreateHolidayObj = () => {
  return dispatch => {
    axios.get(globalAddress+"/api/DataManager/Holiday/Create?rand="+Math.random()).then(response => {
      dispatch(getCreateHolidayData(response.data));
    }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
    });
};
  };

  export const getDeleteHolidayData = data => ({
    type: "GET_DELETEHOLIDAYDATA",
    data: data
  });
  
  export const initDeleteHolidayObj = (holId) => {
    return dispatch => {
      axios.get(globalAddress+"/api/DataManager/Holiday/Delete/"+holId+"?rand="+Math.random()).then(response => {
        dispatch(getDeleteHolidayData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
    };

  export const deleteConfirmedHolidayData = data => ({
    type: "GET_DELETECONFIRMEDHOLIDAYDATA",
    data: data
  });
  
  export const deleteConfirmedHoliday = (holId) => {
    return dispatch => {
      axios.post(globalAddress+"/api/DataManager/Holiday/Delete?id="+holId).then(response => {
        dispatch(deleteConfirmedHolidayData(response.data));
      }).catch((error) => {
     if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
      });
  };
    };

    export const updateHolidayData = data => ({
      type: "GET_UPDATEHOLIDAYDATA",
      data: data
    });
    
    export const updateHoliday = (updateHolidayObj) => {
      return dispatch => {
        axios.post(globalAddress+"/api/DataManager/Holiday/Edit?ID="+updateHolidayObj.ID+"&HolidayDate="+updateHolidayObj.HolidayDate+"&TermDate="+updateHolidayObj.TermDate+"&LastUpdatedBy="+updateHolidayObj.LastUpdatedBy+"&LastUpdatedDate="+updateHolidayObj.LastUpdatedDate+"&CCYY="+updateHolidayObj.CCYY).then(response => {
          dispatch(updateHolidayData(response.data));
        }).catch((error) => {
          if(error.response.status === 422)
          {
           dispatch(getDMErrorData(error.response.data));
                      }
          else
          {
            dispatch(getDMErrorData(error.response.statusText));
          }
        });
    };
      };

      export const createHolidayData = data => ({
        type: "GET_CREATEHOLIDAYDATA",
        data: data
      });
      
      export const createHoliday = (createHolidayObj) => {
        return dispatch => {
          axios.post(globalAddress+"/api/DataManager/Holiday/Create?ID="+createHolidayObj.ID+"&HolidayDate="+createHolidayObj.HolidayDate+"&TermDate="+createHolidayObj.TermDate+"&LastUpdatedBy="+createHolidayObj.LastUpdatedBy+"&LastUpdatedDate="+createHolidayObj.LastUpdatedDate+"&CCYY="+createHolidayObj.CCYY).then(response => {
            dispatch(createHolidayData(response.data));
          }).catch((error) => {
            if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
          });
      };
        };

        // Languages 

        export const getLanguagesData = data => ({
          type: "GET_LANGUAGESDATA",
          data: data
        });

        export const getLanguages = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Language/GetLanguages?rand="+Math.random()).then(response => {
                dispatch(getLanguagesData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
        
        export const getLanguageDetailsByIdData = data => ({
          type: "GET_LANGUAGEDETAILSBYID",
          data: data
        });
        
        export const getLanguageDetailsById = (lanId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Language/Details/"+lanId+"?rand="+Math.random()).then(response => {
              dispatch(getLanguageDetailsByIdData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getEditLanguageObj = data => ({
          type: "GET_EDITLANGUAGEDATA",
          data: data
        });
        
        export const getEditLanguage = (lanId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Language/Edit/"+lanId+"?rand="+Math.random()).then(response => {
              dispatch(getEditLanguageObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateLanguageData = data => ({
          type: "GET_CREATELANGUAGEDATA",
          data: data
        });
        
        export const initCreateLanguageObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Language/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateLanguageData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteLanguageData = data => ({
            type: "GET_DELETELANGUAGEDATA",
            data: data
          });
          
          export const initDeleteLanguageObj = (lanId) => {
            
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Language/Delete/"+lanId+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteLanguageData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedLanguageData = data => ({
            type: "GET_DELETECONFIRMEDLANGUAGEDATA",
            data: data
          });
          
          export const deleteConfirmedLanguage = (lanId) => {
            
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/Language/Delete?id="+lanId).then(response => {
                dispatch(deleteConfirmedLanguageData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateLanguageData = data => ({
              type: "GET_UPDATELANGUAGEDATA",
              data: data
            });
            
            export const updateLanguage = (updateLanguageObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/Language/Edit?CdLanguage="+updateLanguageObj.CdLanguage+"&DescLanguage="+updateLanguageObj.DescLanguage+"&DtTerm="+updateLanguageObj.DtTerm).then(response => {
                  
                dispatch(updateLanguageData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
                  {
                   dispatch(getDMErrorData(error.response.data));
                              }
                  else
                  {
                    dispatch(getDMErrorData(error.response.statusText));
                  }
                });
            };
              };
        
              export const createLanguageData = data => ({
                type: "GET_CREATELANGUAGEDATA",
                data: data
              });
              
              export const createLanguage = (createLanguageObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/Language/Create?CdLanguage="+createLanguageObj.CdLanguage+"&DescLanguage="+createLanguageObj.DescLanguage+"&DtTerm="+createLanguageObj.DtTerm).then(response => {
                    
                  dispatch(createLanguageData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
                    {
                     dispatch(getDMErrorData(error.response.data));
                                }
                    else
                    {
                      dispatch(getDMErrorData(error.response.statusText));
                    }
                  });
              };
                };

                //  Offices

        export const getOfficesData = data => ({
          type: "GET_OFFICESDATA",
          data: data
        });

        export const getOffices = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Office/GetAllOffices?rand="+Math.random()).then(response => {
                dispatch(getOfficesData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
        
        export const getOfficeDetailsByIdData = data => ({
          type: "GET_OFFICEDETAILSBYID",
          data: data
        });
        
        export const getOfficeDetailsById = (officeId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Office/GetOffice/"+officeId+"?rand="+Math.random()).then(response => {
              dispatch(getOfficeDetailsByIdData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getEditOfficeObj = data => ({
          type: "GET_EDITOFFICEDATA",
          data: data
        });
        
        export const getEditOffice = (officeId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Office/EditTemplateOffice/"+officeId+"?rand="+Math.random()).then(response => {
              dispatch(getEditOfficeObj(response.data));
            }).catch((error) => {
              if(error.response.status === 422)
              {
               dispatch(getDMErrorData(error.response.data));
               
              }
            });
          };
        };
        
        export const getCreateOfficeData = data => ({
          type: "GET_CREATEOFFICEDATA",
          data: data
        });
        
        export const initCreateOfficeObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Office/CreateTemplateForOffice?rand="+Math.random()).then(response => {
              dispatch(getCreateOfficeData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteOfficeData = data => ({
            type: "GET_DELETEOFFICEDATA",
            data: data
          });
          
          export const initDeleteOfficeObj = (officeId) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Office/DeleteOffice/"+officeId+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteOfficeData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedOfficeData = data => ({
            type: "GET_DELETECONFIRMEDOFFICEDATA",
            data: data
          });
          
          export const deleteConfirmedOffice = (officeId) => {
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/Office/DeleteConfirmed/"+officeId).then(response => {
                dispatch(deleteConfirmedOfficeData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateOfficeData = data => ({
              type: "GET_UPDATEOFFICEDATA",
              data: data
            });
            
            export const updateOffice = (updateOfficeObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/Office/EditOffice",updateOfficeObj).then(response => {
                  dispatch(updateOfficeData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
                  {
                   dispatch(getDMErrorData(error.response.data));
                              }
                  else
                  {
                    dispatch(getDMErrorData(error.response.statusText));
                  } 
                });
            };
              };
        
              export const createOfficeData = data => ({
                type: "GET_CREATEOFFICEDATA",
                data: data
              });
              
              export const createOffice = (createOfficeObj) => {
                
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/Office/CreateOffice",createOfficeObj).then(response => {
                    dispatch(createOfficeData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
                    {
                     dispatch(getDMErrorData(error.response.data));
                                }
                    else
                    {
                      dispatch(getDMErrorData(error.response.statusText));
                    }
                  });
              };
                };

                 //  OIP Types

        export const getOIPTypesData = data => ({
          type: "GET_OIPTYPESDATA",
          data: data
        });

        export const getOIPTypes = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/OIPType/GetOIPTypes?rand="+Math.random()).then(response => {
                dispatch(getOIPTypesData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
        
        export const getOIPTypeDetailsByTypeData = data => ({
          type: "GET_OIPTYPEDETAILSBYTYPE",
          data: data
        });
        
        export const getOIPTypeDetailsByType = (oipType) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/OIPType/Details/"+oipType+"?rand="+Math.random()).then(response => {
              dispatch(getOIPTypeDetailsByTypeData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getEditOIPTypeObj = data => ({
          type: "GET_EDITOIPTYPEDATA",
          data: data
        });
        
        export const getEditOIPType = (oipType) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/OIPType/Edit/"+oipType+"?rand="+Math.random()).then(response => {
              dispatch(getEditOIPTypeObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateOIPTypeData = data => ({
          type: "GET_CREATEOIPTYPEDATA",
          data: data
        });
        
        export const initCreateOIPTypeObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/OIPType/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateOIPTypeData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteOIPTypeData = data => ({
            type: "GET_DELETEOIPTYPEDATA",
            data: data
          });
          
          export const initDeleteOIPTypeObj = (oipType) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/OIPType/Delete/"+oipType+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteOIPTypeData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedOIPTypeData = data => ({
            type: "GET_DELETECONFIRMEDOIPTYPEDATA",
            data: data
          });
          
          export const deleteConfirmedOIPType = (oipType) => {
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/OIPType/DeleteConfirmed/"+oipType).then(response => {
                dispatch(deleteConfirmedOIPTypeData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateOIPTypeData = data => ({
              type: "GET_UPDATEOIPTYPEDATA",
              data: data
            });
            
            export const updateOIPType = (updateOIPTypeObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/OIPType/Edit/{updateOIPTypeObj.Type}?Description="+updateOIPTypeObj.Description+"&TermDate="+updateOIPTypeObj.TermDate).then(response => {
                  dispatch(updateOIPTypeData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
                  {
                   dispatch(getDMErrorData(error.response.data));
                              }
                  else
                  {
                    dispatch(getDMErrorData(error.response.statusText));
                  }
                });
            };
              };
        
              export const createOIPTypeData = data => ({
                type: "GET_CREATEOIPTYPEDATA",
                data: data
              });
              
              export const createOIPType = (createOIPTypeObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/OIPType/Create?Type="+createOIPTypeObj.Type+"&Description="+createOIPTypeObj.Description+"&TermDate="+createOIPTypeObj.TermDate).then(response => {
                    dispatch(createOIPTypeData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
                  });
              };
                };

        //  Reason Categories

        export const getReasonCategoriesData = data => ({
          type: "GET_REASONCATEGORIESDATA",
          data: data
        });

        export const getReasonCategories = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/ReasonCategory/GetReasonCategories?rand="+Math.random()).then(response => {
                dispatch(getReasonCategoriesData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
        
        export const getRCDetailsByIdData = data => ({
          type: "GET_RCDETAILSBYID",
          data: data
        });
        
        export const getRCDetailsById = (RCId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/ReasonCategory/Details/"+RCId+"?rand="+Math.random()).then(response => {
              dispatch(getRCDetailsByIdData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getEditRCObj = data => ({
          type: "GET_EDITRCDATA",
          data: data
        });
        
        export const getEditRC = (RCId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/ReasonCategory/Edit/"+RCId+"?rand="+Math.random()).then(response => {
              dispatch(getEditRCObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateRCData = data => ({
          type: "GET_CREATERCDATA",
          data: data
        });
        
        export const initCreateRCObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/ReasonCategory/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateRCData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteRCData = data => ({
            type: "GET_DELETERCDATA",
            data: data
          });
          
          export const initDeleteRCObj = (RCId) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/ReasonCategory/Delete/"+RCId+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteRCData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedRCData = data => ({
            type: "GET_DELETECONFIRMEDRCDATA",
            data: data
          });
          
          export const deleteConfirmedRC = (RCId) => {
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/ReasonCategory/DeleteConfirmed/"+RCId).then(response => {
                dispatch(deleteConfirmedRCData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateRCData = data => ({
              type: "GET_UPDATERCDATA",
              data: data
            });
            
            export const updateRC = (updateRCObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/ReasonCategory/Edit?ID="+updateRCObj.ID+"&FromCategory="+updateRCObj.FromCategory+"&ToCategory="+updateRCObj.ToCategory+"&Description="+updateRCObj.Description+"&SpecialCert="+updateRCObj.SpecialCert+"&UpdatedBy="+updateRCObj.UpdatedBy+"&UpdateDay="+updateRCObj.UpdateDay+"&TermDate="+updateRCObj.TermDate).then(response => {
                  dispatch(updateRCData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
                  {
                   dispatch(getDMErrorData(error.response.data));
                              }
                  else
                  {
                    dispatch(getDMErrorData(error.response.statusText));
                  }
                });
            };
              };
        
              export const createRCData = data => ({
                type: "GET_CREATERCDATA",
                data: data
              });
              
              export const createRC = (createRCObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/ReasonCategory/Edit?ID="+createRCObj.ID+"&FromCategory="+createRCObj.FromCategory+"&ToCategory="+createRCObj.ToCategory+"&Description="+createRCObj.Description+"&SpecialCert="+createRCObj.SpecialCert+"&UpdatedBy="+createRCObj.UpdatedBy+"&UpdateDay="+createRCObj.UpdateDay+"&TermDate="+createRCObj.TermDate).then(response => {
                    dispatch(createRCData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
                  });
              };
                };

                   //  Referrals

        export const getReferralsData = data => ({
          type: "GET_REFERRALSDATA",
          data: data
        });

        export const getReferrals = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Referral/GetReferrals?rand="+Math.random()).then(response => {
                dispatch(getReferralsData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
        
        export const getReferralDetailsByTypeData = data => ({
          type: "GET_REFERRALDETAILSBYTYPE",
          data: data
        });
        
        export const getReferralDetailsByType = (RefType) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Referral/Details/"+RefType+"?rand="+Math.random()).then(response => {
              dispatch(getReferralDetailsByTypeData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getEditReferralObj = data => ({
          type: "GET_EDITREFERRALDATA",
          data: data
        });
        
        export const getEditReferral = (RefType) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Referral/Edit/"+RefType+"?rand="+Math.random()).then(response => {
              dispatch(getEditReferralObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateReferralData = data => ({
          type: "GET_CREATEREFERRALDATA",
          data: data
        });
        
        export const initCreateReferralObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Referral/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateReferralData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteReferralData = data => ({
            type: "GET_DELETEREFERRALDATA",
            data: data
          });
          
          export const initDeleteReferralObj = (RefType) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Referral/Delete/"+RefType+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteReferralData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedReferralData = data => ({
            type: "GET_DELETECONFIRMEDREFERRALDATA",
            data: data
          });
          
          export const deleteConfirmedReferral = (RefType) => {
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/Referral/DeleteConfirmed/"+RefType).then(response => {
                dispatch(deleteConfirmedReferralData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateReferralData = data => ({
              type: "GET_UPDATEREFERRALDATA",
              data: data
            });
            
            export const updateReferral = (updateReferralObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/ReasonCategory/Edit?Type="+updateReferralObj.Type+"&Description="+updateReferralObj.Description+"&TermDate="+updateReferralObj.TermDate).then(response => {
                  dispatch(updateReferralData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
                });
            };
              };
        
              export const createReferralData = data => ({
                type: "GET_CREATEREFERRALDATA",
                data: data
              });
              
              export const createReferral = (createReferralObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/Referral/Create?Type="+createReferralObj.Type+"&Description="+createReferralObj.Description+"&TermDate="+createReferralObj.TermDate).then(response => {
                    dispatch(createReferralData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
                    {
                     dispatch(getDMErrorData(error.response.data));
                                }
                    else
                    {
                      dispatch(getDMErrorData(error.response.statusText));
                    }
                  });
              };
                };

                 //  Regions

        export const getRegionsData = data => ({
          type: "GET_REGIONSDATA",
          data: data
        });

        export const getRegions = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Region/GetRegions?rand="+Math.random()).then(response => {
                dispatch(getRegionsData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
             
        export const getEditRegionObj = data => ({
          type: "GET_EDITREGIONDATA",
          data: data
        });
        
        export const getEditRegion = (regId, distId) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Region/Edit/"+regId+"/"+distId+"?rand="+Math.random()).then(response => {
              dispatch(getEditRegionObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateRegionObj = data => ({
          type: "GET_CREATEREGIONOBJ",
          data: data
        });
        
        export const initCreateRegionObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/Region/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateRegionObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteRegionData = data => ({
            type: "GET_DELETEREGIONDATA",
            data: data
          });
          
          export const initDeleteRegionObj = (regId, distId) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/Region/Delete/"+regId+"/"+distId+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteRegionData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedRegionData = data => ({
            type: "GET_DELETECONFIRMEDREGIONDATA",
            data: data
          });
          
          export const deleteConfirmedRegion = (regId, distId) => {
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/Region/DeleteConfirmed/"+regId+"/"+distId).then(response => {
                dispatch(deleteConfirmedRegionData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateRegionData = data => ({
              type: "GET_UPDATEREGIONDATA",
              data: data
            });
            
            export const updateRegion = (updateRegionObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/Region/Edit",updateRegionObj).then(response => {
                  dispatch(updateRegionData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
                });
            };
              };
        
              export const createRegionData = data => ({
                type: "GET_CREATEREGIONDATA",
                data: data
              });
              
              export const createRegion = (createRegionObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/Region/Create",createRegionObj).then(response => {
                    dispatch(createRegionData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
                    {
                     dispatch(getDMErrorData(error.response.data));
                                }
                    else
                    {
                      dispatch(getDMErrorData(error.response.statusText));
                    }
                  });
              };
                };

                             //  Suspense Reasons

        export const getSuspenseReasonsData = data => ({
          type: "GET_SUSPENSEREASONSDATA",
          data: data
        });

        export const getSuspenseReasons = () => {
          return dispatch => {
              axios.get(globalAddress+"/api/DataManager/SuspenseReason/GetSuspenseReasons?rand="+Math.random()).then(response => {
                dispatch(getSuspenseReasonsData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
        };
             
        export const getSRDetailsByTypeData = data => ({
          type: "GET_SRDETAILSBYTYPE",
          data: data
        });
        
        export const getSRDetailsByType = (SRType) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/SuspenseReason/Details/"+SRType+"?rand="+Math.random()).then(response => {
              dispatch(getSRDetailsByTypeData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };

        export const getEditSRObj = data => ({
          type: "GET_EDITSRDATA",
          data: data
        });
        
        export const getEditSR = (SRCode) => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/SuspenseReason/Edit/"+SRCode+"?rand="+Math.random()).then(response => {
              dispatch(getEditSRObj(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
          };
        };
        
        export const getCreateSRData = data => ({
          type: "GET_CREATESRDATA",
          data: data
        });
        
        export const initCreateSRObj = () => {
          return dispatch => {
            axios.get(globalAddress+"/api/DataManager/SuspenseReason/Create?rand="+Math.random()).then(response => {
              dispatch(getCreateSRData(response.data));
            }).catch((error) => {
             if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
            });
        };
          };
        
          export const getDeleteSRData = data => ({
            type: "GET_DELETESRDATA",
            data: data
          });
          
          export const initDeleteSRObj = (SRCode) => {
            return dispatch => {
              axios.get(globalAddress+"/api/DataManager/SuspenseReason/Delete/"+SRCode+"?rand="+Math.random()).then(response => {
                dispatch(getDeleteSRData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
          export const deleteConfirmedSRData = data => ({
            type: "GET_DELETECONFIRMEDSRDATA",
            data: data
          });
          
          export const deleteConfirmedSR = (SRCode) => {
            return dispatch => {
              axios.post(globalAddress+"/api/DataManager/SuspenseReason/DeleteConfirmed/"+SRCode).then(response => {
                dispatch(deleteConfirmedSRData(response.data));
              }).catch((error) => {
               if(error.response.status === 422)
            {
             dispatch(getDMErrorData(error.response.data));
                        }
            else
            {
              dispatch(getDMErrorData(error.response.statusText));
            }
              });
          };
            };
        
            export const updateSRData = data => ({
              type: "GET_UPDATESRDATA",
              data: data
            });
            
            export const updateSR = (updateSRObj) => {
              return dispatch => {
                axios.post(globalAddress+"/api/DataManager/SuspenseReason/Edit?Code="+updateSRObj.Code+"&Description="+updateSRObj.Description+"&TermDate="+updateSRObj.TermDate).then(response => {
                  dispatch(updateSRData(response.data));
                }).catch((error) => {
                  if(error.response.status === 422)
                  {
                   dispatch(getDMErrorData(error.response.data));
                              }
                  else
                  {
                    dispatch(getDMErrorData(error.response.statusText));
                  }
                });
            };
              };
        
              export const createSRData = data => ({
                type: "GET_CREATESRDATA",
                data: data
              });
              
              export const createSR = (createSRObj) => {
                return dispatch => {
                  axios.post(globalAddress+"/api/DataManager/SuspenseReason/Create?Code="+createSRObj.Code+"&Description="+createSRObj.Description+"&TermDate="+createSRObj.TermDate).then(response => {
                    dispatch(createSRData(response.data));
                  }).catch((error) => {
                    if(error.response.status === 422)
                    {
                     dispatch(getDMErrorData(error.response.data));
                                }
                    else
                    {
                      dispatch(getDMErrorData(error.response.statusText));
                    }
                  });
              };
                };

                // To get the error data
export const getDMErrorData = (data) => ({
  type: "GET_DMERRORDATA",
  data: data
});

export const resetDataManagerState = () => ({
  type: "RESET_DATAMANAGER",
  data: ""
});
