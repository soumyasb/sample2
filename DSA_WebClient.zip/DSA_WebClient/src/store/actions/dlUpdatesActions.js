import axios from "axios";
import globalAddress from "./globalAddress";

export const getDLUpdatesErrorData = (data) => ({
  type: "GET_DLUPDATESERRORDATA",
  data: data
});

// To get DL Initial data
export const getDLInitData = data => ({
    type: "GET_DLINITDATA",
    data: data
  });
  
  export const getDLInitialData = (dlNumber) => {
  
    return dispatch => {
      axios.get(globalAddress+"/api/DLSearch/GetDlData?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
        if(response.status === 200)
        {dispatch(getDLInitData(response.data));}
      }).catch((error) => {
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
              if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
         }
      });
    };
    };


// To get DAP Update form Initial data
export const getDAPInitData = data => ({
    type: "GET_DAPINITDATA",
    data: data
  });
  
  export const getDAPInitialPage = (dlNumber) => {
  
    return dispatch => {
      axios.get(globalAddress+"/api/DAP/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
        dispatch(getDAPInitData(response.data));
      });
    };
  };


  // To post the DAP update
  export const getDAPUpdateSaveData = data => ({
    type: "GET_DAPUPDATESAVEDATA",
    data: data
  });

  export const saveDAPUpdate = (dapUpdateObj) => {

    return dispatch => {
      axios.post(globalAddress+"/api/DAP/ProcessDAP",dapUpdateObj).then(response => {
        if(response.status === 200)
        {    
          dispatch(getDAPUpdateSaveData(response.data));
        }
    }).catch((error) => {
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
    });
  };
  };

// To get DAM Update form Initial data
export const getDAMInitData = data => ({
  type: "GET_DAMINITDATA",
  data: data
});

export const getDAMInitialPage = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DAM/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getDAMInitData(response.data));
    });
  };
};


// To post the DAM update
export const getDAMUpdateSaveData = data => ({
  type: "GET_DAMUPDATESAVEDATA",
  data: data
});

export const saveDAMUpdate = (damUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DAM/ProcessDAM",damUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDAMUpdateSaveData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To get DAN Update form Initial data
export const getDANInitData = data => ({
  type: "GET_DANINITDATA",
  data: data
});

export const getDANInitialPage = (dlNumber) => {

  return dispatch => {
    
    axios.get(globalAddress+"/api/DAN/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getDANInitData(response.data));
    });
  };
};


// To post the DAN update
export const getDANUpdateSaveData = data => ({
  type: "GET_DANUPDATESAVEDATA",
  data: data
});

export const saveDANUpdate = (danUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DAN/ProcessDAN",danUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDANUpdateSaveData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To get DCN Update form Initial data
export const getDCNInitData = data => ({
  type: "GET_DCNINITDATA",
  data: data
});

export const getDCNInitialPage = (dlNumber) => {

  return dispatch => {
    
    axios.get(globalAddress+"/api/DCN/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getDCNInitData(response.data));
    });
  };
};


// To post the DCN update
export const getDCNUpdateSaveData = data => ({
  type: "GET_DCNUPDATESAVEDATA",
  data: data
});

export const saveDCNUpdate = (dcnUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DCN/ProcessDCN",dcnUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDCNUpdateSaveData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To get DIE Update form Initial data
export const getDIEInitData = data => ({
  type: "GET_DIEINITDATA",
  data: data
});

export const getDIEInitialPage = (dlNumber) => {

  return dispatch => {
    
    axios.get(globalAddress+"/api/DIE/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getDIEInitData(response.data));
    });
  };
};


// To post the DIE update
export const getDIEUpdateSaveData = data => ({
  type: "GET_DIEUPDATESAVEDATA",
  data: data
});

export const saveDIEUpdate = (dieUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DIE/ProcessDIE",dieUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDIEUpdateSaveData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To get DIX Update form Initial data
export const getDIXInitData = data => ({
  type: "GET_DIXINITDATA",
  data: data
});

export const getDIXInitialPage = () => {

  return dispatch => {
    
    axios.get(globalAddress+"/api/DIX/InitialPage?rand="+Math.random()).then(response => {
      dispatch(getDIXInitData(response.data));
    });
  };
};


// To assign the X number
export const getXNumberAssignData = data => ({
  type: "GET_XNUMBERASSIGNDATA",
  data: data
});

export const assignXNumber = (dixUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DIX/AssignXNumber",dixUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getXNumberAssignData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To post ANI transaction
export const getANITransactionData = data => ({
  type: "GET_ANITRANSACTIONDATA",
  data: data
});

export const processANITransaction = (aniTransObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DIX/ProcessANI",aniTransObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getANITransactionData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To post A04 transaction
export const getA04TransactionData = data => ({
  type: "GET_A04TRANSACTIONDATA",
  data: data
});

export const processA04Transaction = (a04TransObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DIX/ProcessA04",a04TransObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getA04TransactionData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To get DUA Update form Initial data
export const getDUAInitData = data => ({
  type: "GET_DUAINITDATA",
  data: data
});

export const getDUAInitialPage = (dlNumber) => {

  return dispatch => {
    
    axios.get(globalAddress+"/api/DUA/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getDUAInitData(response.data));
    });
  };
};


// To post the DUA update
export const getDUAUpdateSaveData = data => ({
  type: "GET_DUAUPDATESAVEDATA",
  data: data
});

export const saveDUAUpdate = (duaUpdateObj) => {
  
  return dispatch => {
    axios.post(globalAddress+"/api/DUA/ProcessDUA",duaUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDUAUpdateSaveData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};

// To get DAS Update form Initial data
export const getDASInitData = data => ({
  type: "GET_DASINITDATA",
  data: data
});

export const getDASInitialPage = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DAS/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      dispatch(getDASInitData(response.data));
    });
  };
};


// To post the DAS update
export const getDASUpdateSaveData = data => ({
  type: "GET_DASUPDATESAVEDATA",
  data: data
});

export const saveDASUpdate = (dasUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DAS/ProcessDAS",dasUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDASUpdateSaveData(response.data));
      }
  }).catch((error) => {
    
    if(error.response !== undefined)
    {
    if(error.response.status === 422)
     {
    dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
    }
     else
     {
      dispatch(getDLUpdatesErrorData(error.message+" RandomMathNumber"+Math.random().toString()));
     }
  });
};
};

// To get DAR Update form Initial data
export const getDARInitData = data => ({
  type: "GET_DARINITDATA",
  data: data
});

export const getDARInitialPage = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DAR/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {
      dispatch(getDARInitData(response.data));
      }
    }).catch((error) => {
        dispatch(getDLUpdatesErrorData(error));
       
    });
  };
};


// To post the DAR update
export const getDARUpdateSaveData = data => ({
  type: "GET_DARUPDATESAVEDATA",
  data: data
});

export const saveDARUpdate = (darUpdateObj) => {
  return dispatch => {
    axios.post(globalAddress+"/api/DAR/ProcessDAR",darUpdateObj).then(response => {
      if(response.status === 200)
      {
        dispatch(getDARUpdateSaveData(response.data));
      }
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
  });
};
};
  
 // To get ME2 data

 export const getME2DataObj = data => ({
  type: "GET_ME2DATA",
  data: data
});

export const getME2Data = (dlNumber, lastName) => {

  return dispatch => {
    axios.get(globalAddress+"/api/ME2/InitialPage?dlNumber="+dlNumber+"&lastName="+lastName+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getME2DataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };

  // To post ME2 data

  export const saveME2DataObj = data => ({
    type: "GET_SAVEME2DATA",
    data: data
  });
  
  export const saveME2Data = (me2Obj) => {
    return dispatch => {
      axios.post(globalAddress+"/api/ME2/ProcessME2",me2Obj).then(response => {
        if(response.status === 200)
        {dispatch(saveME2DataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

    // To get ME3 data

export const getME3DataObj = data => ({
type: "GET_ME3DATA",
data: data
});

export const getME3Data = (dlNumber, lastName) => {
return dispatch => {
  axios.get(globalAddress+"/api/ME3/InitialPage?dlNumber="+dlNumber+"&lastName="+lastName+"&rand="+Math.random()).then(response => {
    if(response.status === 200)
    {dispatch(getME3DataObj(response.data));}
  }).catch((error) => {
    
    if(error.response.status === 422)
     {
  
     dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
     if(error.response.status === 404)
     {
  
        if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
      
     }
   });
};
};

// To post ME3 data

export const saveME3DataObj = data => ({
  type: "GET_SAVEME3DATA",
  data: data
});

export const saveME3Data = (me3Obj) => {

  return dispatch => {
    axios.post(globalAddress+"/api/ME3/ProcessME3",me3Obj).then(response => {
      if(response.status === 200)
      {dispatch(saveME3DataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };

  // To get ME4 data

export const getME4DataObj = data => ({
type: "GET_ME4DATA",
data: data
});

export const getME4Data = (dlNumber, lastName) => {
return dispatch => {
  axios.get(globalAddress+"/api/ME4/InitialPage?dlNumber="+dlNumber+"&lastName="+lastName+"&rand="+Math.random()).then(response => {
    if(response.status === 200)
    {dispatch(getME4DataObj(response.data));}
  }).catch((error) => {
    
    if(error.response.status === 422)
     {
  
     dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
     if(error.response.status === 404)
     {
  
        if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
      
     }
   });
};
};

// To post ME4 data

export const saveME4DataObj = data => ({
  type: "GET_SAVEME4DATA",
  data: data
});

export const saveME4Data = (me4Obj) => {

  return dispatch => {
    axios.post(globalAddress+"/api/ME4/ProcessME4",me4Obj).then(response => {
      if(response.status === 200)
      {dispatch(saveME4DataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };

  // To get ME5 data

export const getME5DataObj = data => ({
type: "GET_ME5DATA",
data: data
});

export const getME5Data = (dlNumber, lastName) => {
return dispatch => {
  axios.get(globalAddress+"/api/ME5/InitialPage?dlNumber="+dlNumber+"&lastName="+lastName+"&rand="+Math.random()).then(response => {
    if(response.status === 200)
    {dispatch(getME5DataObj(response.data));}
  }).catch((error) => {
    
    if(error.response.status === 422)
     {
  
     dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
     if(error.response.status === 404)
     {
  
        if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
      
     }
   });
};
};

// To post ME5 data

export const saveME5DataObj = data => ({
  type: "GET_SAVEME5DATA",
  data: data
});

export const saveME5Data = (me5Obj) => {

  return dispatch => {
    axios.post(globalAddress+"/api/ME5/ProcessME5",me5Obj).then(response => {
      if(response.status === 200)
      {dispatch(saveME5DataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };

  // To get ME6 data

export const getME6DataObj = data => ({
type: "GET_ME6DATA",
data: data
});

export const getME6Data = (dlNumber, lastName) => {
return dispatch => {
  axios.get(globalAddress+"/api/ME6/InitialPage?dlNumber="+dlNumber+"&lastName="+lastName+"&rand="+Math.random()).then(response => {
    if(response.status === 200)
    {dispatch(getME6DataObj(response.data));}
  }).catch((error) => {
    
    if(error.response.status === 422)
     {
  
     dispatch(getDLUpdatesErrorData(error.response.data));
     
     }
     if(error.response.status === 404)
     {
  
        if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
      
     }
   });
};
};

// To post ME6 data

export const saveME6DataObj = data => ({
  type: "GET_SAVEME6DATA",
  data: data
});

export const saveME6Data = (me6Obj) => {

  return dispatch => {
    axios.post(globalAddress+"/api/ME6/ProcessME6",me6Obj).then(response => {
      if(response.status === 200)
      {dispatch(saveME6DataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };

  // To get DUE data

export const getDUEDataObj = data => ({
  type: "GET_DUEDATA",
  data: data
  });
  
  export const getDUEData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUE/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUEDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUE data
  
  export const saveDUEDataObj = data => ({
    type: "GET_SAVEDUEDATA",
    data: data
  });
  
  export const saveDUEData = (dueObj) => {

    return dispatch => {
      axios.post(globalAddress+"/api/DUE/ProcessDUE",dueObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUEDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

     // To get DUZ data

export const getDUZDataObj = data => ({
  type: "GET_DUZDATA",
  data: data
  });
  
  export const getDUZData = (dlNumber) => {
  return dispatch => {
    axios.get(globalAddress+"/api/DUZ/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUZDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUZ data
  
  export const saveDUZDataObj = data => ({
    type: "GET_SAVEDUZDATA",
    data: data
  });
  
  export const saveDUZData = (duzObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUZ/ProcessDUZ",duzObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUZDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

     // To get DUJ data

export const getDUJDataObj = data => ({
  type: "GET_DUJDATA",
  data: data
  });
  
  export const getDUJData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUJ/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUJDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUJ data
  
  export const saveDUJDataObj = data => ({
    type: "GET_SAVEDUJDATA",
    data: data
  });
  
  export const saveDUJData = (dujObj) => {
    return dispatch => {
      axios.post(globalAddress+"/api/DUJ/ProcessDUJ",dujObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUJDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

         // To get DUH data

export const getDUHDataObj = data => ({
  type: "GET_DUHDATA",
  data: data
  });
  
  export const getDUHData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUH/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUHDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUH data
  
  export const saveDUHDataObj = data => ({
    type: "GET_SAVEDUHDATA",
    data: data
  });
  
  export const saveDUHData = (duhObj) => {
    
    return dispatch => {
      axios.post(globalAddress+"/api/DUH/ProcessDUH",duhObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUHDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

       // To get DUF data

export const getDUFDataObj = data => ({
  type: "GET_DUFDATA",
  data: data
  });
  
  export const getDUFData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUF/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUFDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUF data
  
  export const saveDUFDataObj = data => ({
    type: "GET_SAVEDUFDATA",
    data: data
  });
  
  export const saveDUFData = (dufObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUF/ProcessDUF",dufObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUFDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

       // To get DUP data

export const getDUPDataObj = data => ({
  type: "GET_DUPDATA",
  data: data
  });
  
  export const getDUPData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUP/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUPDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };    
  
  // To post DUP data
  
  export const saveDUPDataObj = data => ({
    type: "GET_SAVEDUPDATA",
    data: data
  });
  
  export const saveDUPData = (dupObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUP/ProcessDUP",dupObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUPDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

  
   // To get DUN data

export const getDUNDataObj = data => ({
  type: "GET_DUNDATA",
  data: data
  });
  
  export const getDUNData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUN/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUNDataObj(response.data));}
    }).catch((error) => {
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };

  // To post DUN data
  
  export const saveDUNDataObj = data => ({
    type: "GET_SAVEDUNDATA",
    data: data
  });
  
  export const saveDUNData = (dunObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUN/ProcessDUN",dunObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUNDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

       // To get DUV data

export const getDUVDataObj = data => ({
  type: "GET_DUVDATA",
  data: data
  });
  
  export const getDUVData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUV/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUVDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUV data
  
  export const saveDUVDataObj = data => ({
    type: "GET_SAVEDUVDATA",
    data: data
  });
  
  export const saveDUVData = (duvObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUV/ProcessDUV",duvObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUVDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

       // To get DUX data

export const getDUXDataObj = data => ({
  type: "GET_DUXDATA",
  data: data
  });
  
  export const getDUXData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUX/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUXDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUX data
  
  export const saveDUXDataObj = data => ({
    type: "GET_SAVEDUXDATA",
    data: data
  });
  
  export const saveDUXData = (duxObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUX/ProcessDUX",duxObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUXDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

     // To get DUW data

export const getDUWDataObj = data => ({
  type: "GET_DUWDATA",
  data: data
  });
  
  export const getDUWData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUW/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUWDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To post DUW data
  
  export const saveDUWDataObj = data => ({
    type: "GET_SAVEDUWDATA",
    data: data
  });
  
  export const saveDUWData = (duwObj) => {
  
    return dispatch => {
      axios.post(globalAddress+"/api/DUW/ProcessDUW",duwObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUWDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };


       // To get DUK data

export const getDUKDataObj = data => ({
  type: "GET_DUKDATA",
  data: data
  });
  
  export const getDUKData = (dlNumber) => {

  return dispatch => {
    axios.get(globalAddress+"/api/DUK/InitialPage?dlNumber="+dlNumber+"&rand="+Math.random()).then(response => {
      if(response.status === 200)
      {dispatch(getDUKDataObj(response.data));}
    }).catch((error) => {
      
      if(error.response.status === 422)
       {
    
       dispatch(getDLUpdatesErrorData(error.response.data));
       
       }
       if(error.response.status === 404)
       {
    
          if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
        
       }
     });
  };
  };
  
  // To get DUK dropdown data 

  export const getDropDownDataObj = data => ({
    type: "GET_DUKDROPDOWNDATA",
    data: data
    });
    
    export const getDropDownData = (code) => {
  
    return dispatch => {
      axios.get(globalAddress+"/api/DUK/GetDropDownData?code="+code+"&rand="+Math.random()).then(response => {
        if(response.status === 200)
        {dispatch(getDropDownDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
          dispatch(getDLUpdatesErrorData("Dropdown data for the code '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          
         }
       });
    };
    };

  // To post DUK data
  
  export const saveDUKDataObj = data => ({
    type: "GET_SAVEDUKDATA",
    data: data
  });
  
  export const saveDUKData = (dukObj) => {
    return dispatch => {
      axios.post(globalAddress+"/api/DUK/ProcessDUK",dukObj).then(response => {
        if(response.status === 200)
        {dispatch(saveDUKDataObj(response.data));}
      }).catch((error) => {
        
        if(error.response.status === 422)
         {
      
         dispatch(getDLUpdatesErrorData(error.response.data));
         
         }
         if(error.response.status === 404)
         {
      
            if(error.response.request.responseURL)
          {
            dispatch(getDLUpdatesErrorData("DL number '"+error.response.request.responseURL.split("=")[1].split("&")[0]+"' was not found."));
          }
    else
    {
      dispatch(getDLUpdatesErrorData("The entered DL number was not found."));
    }
          
         }
       });
    };
    };

    export const resetDlUpdatesState = () => ({
      type: "RESET_DLUPDATES",
      data: ""
    });
    