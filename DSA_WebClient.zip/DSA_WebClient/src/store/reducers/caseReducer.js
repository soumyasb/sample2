const caseReducerDefaultState = {
  modified: false
};

const casereducer = (state = caseReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_CASE_SEARCHRESULTS": {
      return { ...state, searchList: action.data };
    }
    case "GET_CUSTOMERDETAILS": {
      return { ...state, customerDetailsObj: action.data };
    }
    case "GET_CUSTOMERD26INFO":
    {
      return { ...state, customerD26Info: action.data };
    }
    case "GET_CASEDETAILS": {
      return { ...state, caseDetailsObj: action.data, modified: false };
    }
    case "GET_EMPLOYEESFOROFFICE": {
      return { ...state, employeesForOffice: action.data };
    }
    case "GET_CLOSEDCASEDETAILS": {
      return { ...state, closedCaseDetail: action.data };
    }
    case "GET_CREATECASEDATA": {
      return { ...state, createCaseObj: action.data };
    }
    case "GET_HEARINGTYPES": {
      return { ...state, hearingTypesList: action.data };
    }
    case "GET_CASEREASONS": {
      return { ...state, caseReasonsList: action.data };
    }
    case "GET_CASEREFERRALS": {
      return { ...state, caseReferralsList: action.data };
    }
    case "GET_CASECERTIFICATIONS": {
      return { ...state, caseCertificationsList: action.data };
    }
    case "GET_SCHEDULEDCASES": {
      return { ...state, scheduledCasesList: action.data.results };
    }
    case "GET_UNSCHEDULEDCASES": {
      return { ...state, unScheduledCasesList: action.data.results };
    }
    case "GET_OIPTYPES": {
      return { ...state, caseOIPTypesList: action.data };
    }
    case "GET_CASEADDDATA": {
      return { ...state, createCaseObj: action.data, modified: false };
    }
    case "GET_MODIFYCASEDATA": {
      return { ...state, caseDetailsObj: action.data, modified: true };
    }
    case "GET_OIPLANGUAGESDATA": {
      return { ...state, OIPlanguagesData: action.data };
    }
    case "GET_CASECOVERSHEET": {
      return { ...state, caseCoverSheetObj: action.data };
    }
    case "GET_H6INFO": {
      return { ...state, h6Info: JSON.parse(action.data) };
    }
    case "GET_CASESCHEDULEDATA": {
      return { ...state, caseScheduleData: action.data };
    }
    case "GET_CASECOMMENTSDATA": {
    return { ...state, caseComments: action.data };
    }
    case "GET_CASECOMMENTADDDATA": {
    return { ...state, addCaseCommentData: action.data };
    }
    case "GET_CASECOMMENTDELDATA": {
      return { ...state, commentDelData: action.data };
      }
    case "GET_CASEERRORDATA": {
      return { ...state, caseErrorData: action.data };
    }
    case "GET_ALLOIPSFORCASEDATA":
    {
      return { ...state, caseOIPsData: action.data };
    }
    case "GET_OIPTYPESDATA":
    {
      return { ...state, OIPTypesListData: action.data };
    }
    case "GET_OIPLOOKUPRESULTSDATA":
    {
      return { ...state, OIPLookupResults: action.data };
    }
    case "GET_OIPDELETEDATA":
    {
      return { ...state, OIPDeleteData: action.data };
    }
    case "GET_UPDATEOIPDATA":
    {
      return { ...state, OIPUpdateData: action.data };
    }
    case "GET_SAVEOIPDATA":
    {
      return { ...state, OIPSaveData: action.data };
    }
    case "GET_OIPREMOVEDATA":
    {
      return { ...state, OIPRemoveData: action.data };
    }
    case "GET_OIPASSIGNDATA":
    {
      return { ...state, OIPAssignData: action.data };
    }
    case "GET_CASESUSPENSEDATA":
    {
      return { ...state, caseSuspenseDetails: action.data };
    }
    case "GET_ADDCASESUSPENSEDATA":
    {
      return { ...state, addCaseSuspenseData: action.data };
    }
    case "GET_MODIFYCASESUSPENSEDATA":
    {
      return { ...state, modifyCaseSuspenseData: action.data };
    }
    case "GET_DELETECASESUSPENSEDATA":
    {
      return { ...state, deleteCaseSuspenseData: action.data };
    }
    case "GET_CASESUSPENSEREASONSDATA":
    {
      return { ...state, caseSuspenseReasons: action.data };
    }
    default:
      return state;
  }
};

export default casereducer;
