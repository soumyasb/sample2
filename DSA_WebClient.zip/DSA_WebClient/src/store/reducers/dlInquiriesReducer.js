const dlInquiriesReducerDefaultState = {
  dlInquriesErrorData: undefined,
  DLInqData: undefined,
  DLInqDataModified: undefined
};

const dlInquiriesreducer = (state = dlInquiriesReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_DLINQDATA": {
      return { ...state, DLInqData: action.data, DLInqDataModified: Math.random(), dlInquriesErrorData: undefined };
    }
    case "GET_DLINQUIRIESERRORDATA": {
      return { ...state, dlInquriesErrorData: action.data, deModified: Math.random() };
    }
    case "RESET_DLINQ": {
      return dlInquiriesReducerDefaultState;
    }
    default:
    return state;
}
};

export default dlInquiriesreducer;