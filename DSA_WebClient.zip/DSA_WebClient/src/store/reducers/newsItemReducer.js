const newsItemReducerDefaultState = {
  newsErrorData: undefined
};

const newsitemreducer = (state = newsItemReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_NEWSITEMS": {
      return { ...state, list: action.data, newsErrorData: undefined };
    }
    case "GET_CREATENEWSITEM":
    {
      return { ...state, newsItemObj: action.data, newsErrorData: undefined};
    }
    case "GET_EDITNEWSITEM":
    {
      if(action.data.officeGroup === null)
      {
        const newsItem = action.data;
        newsItem.officeGroup = [];

        return { ...state, newsItemObj: newsItem, newsErrorData: undefined};
      }
      else
      {
        return { ...state, newsItemObj: action.data, newsErrorData: undefined};
      }
      
    }
    case "GET_MODIFYNEWSITEMDATA":
    {
      return {...state, list: action.data, modified: Math.random(), newsErrorData: undefined};
    }
    case "GET_OFFICEDETAILS":
    {
      return { ...state, officeDetailsObj: action.data, newsErrorData: undefined};
    }
    case "GET_NEWSITEMDETAILS":
    {
      return { ...state, newsItemObj: action.data, newsErrorData: undefined};
    }
    case "GET_EDITDATA":
    {
      return { ...state, isLoading: true, newsErrorData: undefined};
    }
    case "GET_NEWSITEMERRORDATA":
    {
      return { ...state, newsErrorData: action.data};
    }
    default:
      return state;
  }
};

export default newsitemreducer;
