const uiReducerDefaultState = {
  newsModalVisible: false,
  newsIdx: 0,
  modalVisible: false,
  actionType: "",
  newsItemObj: []
};

const uireducer = (state = uiReducerDefaultState, action) => {
  switch (action.type) {
    case "SET_NEWS_MODAL": {
      return { ...state, newsModalVisible: action.val };
    }
    case "SET_NEWS_IDX": {
      return { ...state, newsIdx: action.idx };
    }
    case "SET_CUSTOMERPAGESTATUS":
    {
      return { ...state, onCustomerPage: action.val};
    }
    // case "SET_HEADERKEY":
    // {
    //   return { ...state, headerKey: action.val, randomN: Math.random()};
    // }
    default:
      return state;
  }
};

export default uireducer;
