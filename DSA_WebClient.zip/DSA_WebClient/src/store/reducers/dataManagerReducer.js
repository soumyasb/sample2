const dataManagerReducerDefaultState = {
  DMErrorData: undefined
};

const dataManagerReducer = (state = dataManagerReducerDefaultState, action) => {
  switch (action.type) {
    // Employees
    case "GET_ALLEMPLOYEES": {
      return { ...state, allEmployeesList: action.data, DMErrorData: undefined };
    }
    case "GET_EMPLOYEEBYID": {
        return { ...state, empDetailsbyId: action.data, DMErrorData: undefined };
      }
      case "GET_EDITEMPLOYEEDATA": {
        return { ...state, editEmpObj: action.data, DMErrorData: undefined };
      }
    case "GET_CREATEEMPLOYEEOBJ":
    {
        return { ...state, createEmpObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEEMPLOYEEDATA":
    {
      return { ...state, deleteEmpObj: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEEMPLOYEEDATA":
    {
      return { ...state, updateEmpData: action.data, allEmployeesList: undefined, DMErrorData: undefined };
    }
    case "GET_CREATEEMPLOYEEDATA":
    {
      return { ...state, createEmpData: action.data, DMErrorData: undefined };
    }
    // Activity Types
    case "GET_ALLACTIVITYTYPES": {
      return { ...state, allActTypesList: action.data, DMErrorData: undefined };
    }
    case "GET_ACTTYPEDETAILSBYID": {
      return { ...state, actTypeDetailsByIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITACTTYPEDATA": {
      return { ...state, editActTypeObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEACTTYPEDATA": {
      return { ...state, createActTypeObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEACTTYPEDATA": {
      return { ...state, deleteActTypeObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDACTTYPEDATA": {
      return { ...state, dleteConfirmedActTypeData: action.data, DMErrorData: undefined};
    }
    case "GET_UPDATEACTTYPEDATA": {
      return { ...state, updateActTypeData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATEACTTYPEDATA": {
    //   return { ...state, createActTypeData: action.data };
    // }
    // Hearing Rooms
    case "GET_INITHEARINGROOMDATA": {
      return { ...state, initHRData: action.data, DMErrorData: undefined };
    }
    case "GET_HEARINGROOMSBYOFFICEID": {
      return { ...state, hRsByOfficeIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITHRDATA": {
      return { ...state, editHRObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEHROBJ": {
      return { ...state, createHRObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEHRDATA": {
      return { ...state, deleteHRObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDHRDATA": {
      return { ...state, dleteConfirmedHRData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEHRDATA": {
      return { ...state, updateHRData: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEHRDATA": {
      return { ...state, createHRData: action.data, DMErrorData: undefined };
    }
    // Hearing Times
    case "GET_HEARINGTIMESDATA": {
      return { ...state, allHearingTimesList: action.data, DMErrorData: undefined };
    }
    case "GET_HEARINGTIMEDETAILSBYID": {
      return { ...state, hTDetailsByIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITHTDATA": {
      return { ...state, editHTObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEHTDATA": {
      return { ...state, createHTObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEHTDATA": {
      return { ...state, deleteHTObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDHTDATA": {
      return { ...state, dleteConfirmedHTData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEHTDATA": {
      return { ...state, updateHTData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATEHTDATA": {
    //   return { ...state, createHTData: action.data };
    // }
    // Holidays
    case "GET_HOLIDAYSDATA": {
      return { ...state, allHolidaysList: action.data, DMErrorData: undefined };
    }
    case "GET_HOLIDAYDETAILSBYID": {
      return { ...state, holidayDetailsByIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITHOLIDAYDATA": {
      return { ...state, editHolidayObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEHOLIDAYDATA": {
      return { ...state, createHolidayObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEHOLIDAYDATA": {
      return { ...state, deleteHolidayObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDHOLIDAYDATA": {
      return { ...state, dleteConfirmedHolidayData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEHOLIDAYDATA": {
      return { ...state, updateHolidayData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATEHOLIDAYDATA": {
    //   return { ...state, createHolidayData: action.data };
    // }
    // Languages
    case "GET_LANGUAGESDATA": {
      return { ...state, allLanguagesList: action.data, DMErrorData: undefined };
    }
    case "GET_LANGUAGEDETAILSBYID": {
      return { ...state, languageDetailsByIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITLANGUAGEDATA": {
      return { ...state, editLanguageObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATELANGUAGEDATA": {
      return { ...state, createLanguageObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETELANGUAGEDATA": {
      return { ...state, deleteLanguageObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDLANGUAGEDATA": {
      return { ...state, dleteConfirmedLanguageData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATELANGUAGEDATA": {
      return { ...state, updateLanguageData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATELANGUAGEDATA": {
    //   return { ...state, createLanguageData: action.data };
    // }
    // Offices
    case "GET_OFFICESDATA": {
      return { ...state, allOfficesList: action.data, DMErrorData: undefined };
    }
    case "GET_OFFICEDETAILSBYID": {
      return { ...state, officeDetailsByIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITOFFICEDATA": {
      return { ...state, editOfficeObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEOFFICEDATA": {
      return { ...state, createOfficeObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEOFFICEDATA": {
      return { ...state, deleteOfficeObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDOFFICEDATA": {
      return { ...state, dleteConfirmedOfficeData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEOFFICEDATA": {
      return { ...state, updateOfficeData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATEOFFICEDATA": {
    //   return { ...state, createOfficeData: action.data };
    // }
    // OIP Types
    case "GET_OIPTYPESDATA": {
      return { ...state, allOIPTypesList: action.data, DMErrorData: undefined };
    }
    case "GET_OIPTYPEDETAILSBYTYPE": {
      return { ...state, OIPTypeDetailsByTypeData: action.data, DMErrorData: undefined};
    }
    case "GET_EDITOIPTYPEDATA": {
      return { ...state, editOIPTypeObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEOIPTYPEDATA": {
      return { ...state, createOIPTypeObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEOIPTYPEDATA": {
      return { ...state, deleteOIPTypeObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDOIPTYPEDATA": {
      return { ...state, dleteConfirmedOIPTypeData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEOIPTYPEDATA": {
      return { ...state, updateOIPTypeData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATEOIPTYPEDATA": {
    //   return { ...state, createOIPTypeData: action.data };
    // }
    // Reason Categories
    case "GET_REASONCATEGORIESDATA": {
      return { ...state, allReasonCategoriesList: action.data, DMErrorData: undefined };
    }
    case "GET_RCDETAILSBYID": {
      return { ...state, RCDetailsByIdData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITRCDATA": {
      return { ...state, editRCObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATERCDATA": {
      return { ...state, createRCObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETERCDATA": {
      return { ...state, deleteRCObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDRCDATA": {
      return { ...state, dleteConfirmedRCData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATERCDATA": {
      return { ...state, updateRCData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATERCDATA": {
    //   return { ...state, createRCData: action.data };
    // }
    // Referrals
    case "GET_REFERRALSDATA": {
      return { ...state, allReferralsList: action.data, DMErrorData: undefined };
    }
    case "GET_REFERRALDETAILSBYTYPE": {
      return { ...state, ReferralDetailsByTypeData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITREFERRALDATA": {
      return { ...state, editReferralObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEREFERRALDATA": {
      return { ...state, createReferralObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEREFERRALDATA": {
      return { ...state, deleteReferralObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDREFERRALDATA": {
      return { ...state, dleteConfirmedReferralData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEREFERRALDATA": {
      return { ...state, updateReferralData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATEREFERRALDATA": {
    //   return { ...state, createReferralData: action.data, DMErrorData: undefined };
    // }
    // Regions
    case "GET_REGIONSDATA": {
      return { ...state, allRegionsList: action.data, DMErrorData: undefined };
    }
    case "GET_EDITREGIONDATA": {
      return { ...state, editRegionObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEREGIONOBJ": {
      return { ...state, createRegionObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETEREGIONDATA": {
      return { ...state, deleteRegionObj: action.data };
    }
    case "GET_DELETECONFIRMEDREGIONDATA": {
      return { ...state, dleteConfirmedRegionData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATEREGIONDATA": {
      return { ...state, updateRegionData: action.data, DMErrorData: undefined };
    }
    case "GET_CREATEREGIONDATA": {
      return { ...state, createRegionData: action.data, DMErrorData: undefined };
    }
    // Suspense Reasons
    case "GET_SUSPENSEREASONSDATA": {
      return { ...state, allSuspenseReasonsList: action.data, DMErrorData: undefined };
    }
    case "GET_SRDETAILSBYTYPE": {
      return { ...state, SRDetailsByTypeData: action.data, DMErrorData: undefined };
    }
    case "GET_EDITSRDATA": {
      return { ...state, editSRObj: action.data, DMErrorData: undefined };
    }
    case "GET_CREATESRDATA": {
      return { ...state, createSRObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETESRDATA": {
      return { ...state, deleteSRObj: action.data, DMErrorData: undefined };
    }
    case "GET_DELETECONFIRMEDSRDATA": {
      return { ...state, dleteConfirmedSRData: action.data, DMErrorData: undefined };
    }
    case "GET_UPDATESRDATA": {
      return { ...state, updateSRData: action.data, DMErrorData: undefined };
    }
    // case "GET_CREATESRDATA": {
    //   return { ...state, createSRData: action.data };
    // }
    case "GET_DMERRORDATA":
    {
      return { ...state, DMErrorData: action.data, errMod: Math.random()}
    }
      default:
      return state;
  }
};

export default dataManagerReducer;