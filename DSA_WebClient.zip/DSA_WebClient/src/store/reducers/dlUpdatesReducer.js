const dlUpdatesReducerDefaultState = {
  dlUpdatesErrorData: undefined
};

const dlUpdatesreducer = (state = dlUpdatesReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_DLINITDATA": {
      return { ...state, dlInitData: action.data, modified: Math.random(), dlUpdatesErrorData: undefined };
    }
    case "GET_DAPINITDATA": {
      return { ...state, dapInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DAPUPDATESAVEDATA": {
      return { ...state, dapUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DAMINITDATA": {
      return { ...state, damInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DAMUPDATESAVEDATA": {
      return { ...state, damUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DANINITDATA": {
      return { ...state, danInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DANUPDATESAVEDATA": {
      return { ...state, danUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DCNINITDATA": {
      return { ...state, dcnInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DCNUPDATESAVEDATA": {
      return { ...state, dcnUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DIEINITDATA": {
      return { ...state, dieInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DIEUPDATESAVEDATA": {
      return { ...state, dieUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DIXINITDATA": {
      return { ...state, dixInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_XNUMBERASSIGNDATA": {
      return { ...state, assignXNumberData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_ANITRANSACTIONDATA": {
      return { ...state, aniTransData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_A04TRANSACTIONDATA": {
      return { ...state, a04TransData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DUAINITDATA": {
      return { ...state, duaInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DUAUPDATESAVEDATA": {
      return { ...state, duaUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DASINITDATA": {
      return { ...state, dasInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DASUPDATESAVEDATA": {
      return { ...state, dasUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DARINITDATA": {
      return { ...state, darInitPageData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DARUPDATESAVEDATA": {
      return { ...state, darUpdateSaveData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_ME2DATA": {
      return { ...state, ME2InitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEME2DATA": {
      return { ...state, saveME2Data: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_ME3DATA": {
      return { ...state, ME3InitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEME3DATA": {
      return { ...state, saveME3Data: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_ME4DATA": {
      return { ...state, ME4InitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEME4DATA": {
      return { ...state, saveME4Data: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_ME5DATA": {
      return { ...state, ME5InitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEME5DATA": {
      return { ...state, saveME5Data: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_ME6DATA": {
      return { ...state, ME6InitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEME6DATA": {
      return { ...state, saveME6Data: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DUEDATA": {
      return { ...state, DUEInitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEDUEDATA": {
      return { ...state, saveDUEData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DUZDATA": {
      return { ...state, DUZInitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEDUZDATA": {
      return { ...state, saveDUZData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_DUJDATA": {
      return { ...state, DUJInitData: action.data, dlUpdatesErrorData: undefined  };
    }
    case "GET_SAVEDUJDATA": {
      return { ...state, saveDUJData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUHDATA": {
      return { ...state, DUHInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUHDATA": {
      return { ...state, saveDUHData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUWDATA": {
      return { ...state, DUWInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUWDATA": {
      return { ...state, saveDUWData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUVDATA": {
      return { ...state, DUVInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUVDATA": {
      return { ...state, saveDUVData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUXDATA": {
      return { ...state, DUXInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUXDATA": {
      return { ...state, saveDUXData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUPDATA": {
      return { ...state, DUPInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUPDATA": {
      return { ...state, saveDUPData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUNDATA": {
      return { ...state, DUNInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUNDATA": {
      return { ...state, saveDUNData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUFDATA": {
      return { ...state, DUFInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUFDATA": {
      return { ...state, saveDUFData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUKDATA": {
      return { ...state, DUKInitData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DUKDROPDOWNDATA": {
      return { ...state, DUKDropDownData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_SAVEDUKDATA": {
      return { ...state, saveDUKData: action.data, dlUpdatesErrorData: undefined };
    }
    case "GET_DLUPDATESERRORDATA": {
      return { ...state, dlUpdatesErrorData: action.data, duModified: Math.random() };
    }
      default:
      return state;
  }
};

export default dlUpdatesreducer;