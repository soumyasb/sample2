const caseSchedulingReducerDefaultState = {
    modified: false,
    caseSchedulingErrorData: undefined,
    availableTimeSlots: undefined,
    caseScheduleData: undefined,
    employeeCalendar: undefined,
    rsrcdataObj: undefined,
    rsrcUpdateData: undefined,
    hearingOfficersList: undefined,
    caseReExamInitData: undefined,
    caseReExamUpdateData: undefined,
    caseReExamData: undefined,
    caseInfo: undefined
  };
  
  const caseSchedulingReducer = (state = caseSchedulingReducerDefaultState, action) => {
    switch (action.type) {
        case "GET_SCHEDULINGERRORDATA": {
            return { ...state, caseSchedulingErrorData: action.data, emodified: Math.random() };
          }
      case "GET_CASEINFO": {
        return { ...state, caseInfo: action.data };
      }   
      case "GET_AVAILABLETIMESLOTSDATA": {
        return { ...state, availableTimeSlots: action.data, caseSchedulingErrorData: undefined, modified: Math.random() };
      } 
      case "GET_PREVIOUSDAYAVAILABLETIMESLOTSDATA": {
        return { ...state, availableTimeSlots: action.data, caseSchedulingErrorData: undefined, modified: Math.random() };
      } 
      case "GET_NEXTDAYAVAILABLETIMESLOTSDATA": {
        return { ...state, availableTimeSlots: action.data, caseSchedulingErrorData: undefined, modified: Math.random() };
      } 
      case "GET_SCHEDULECASEDATA": {
        return { ...state, caseScheduleData: action.data, csmodified: Math.random() };
      } 
      case "GET_OVERRIDESCHEDULEDATA": {
        return { ...state, caseScheduleData: action.data, caseSchedulingErrorData: undefined, csmodified: Math.random(), overridden: Math.random() };
      } 
      case "GET_EMPLOYEECALENDARDATA": {
        return { ...state, employeeCalendar: action.data, caseSchedulingErrorData: undefined, cmodified: Math.random() };
      } 
      case "GET_PREVIOUSDAYEMPLOYEECALENDARDATA": {
        return { ...state, employeeCalendar: action.data, caseSchedulingErrorData: undefined, cmodified: Math.random() };
      } 
      case "GET_NEXTDAYEMPLOYEECALENDARDATA": {
        return { ...state, employeeCalendar: action.data, caseSchedulingErrorData: undefined, cmodified: Math.random() };
      } 
      case "INIT_RSRCDATAOBJ": {
        return { ...state, rsrcdataObj: action.data, caseSchedulingErrorData: undefined }
      }
      case "GET_RSRCUPDATEDATA": {
        return { ...state, rsrcUpdateData: action.data, caseSchedulingErrorData: undefined }
      }
      case "GET_EMPLOYEESFORSCHEDULINGDATA": {
        return { ...state, hearingOfficersList: action.data, caseSchedulingErrorData: undefined };
      } 
      case "GET_CASEREEXAMINITDATA": {
        return { ...state, caseReExamInitData: action.data, caseSchedulingErrorData: undefined }
      }
      case "GET_PROCESSCASEREEXAMDATA": {
        return { ...state, caseReExamUpdateData: action.data, caseSchedulingErrorData: undefined };
      } 
      case "GET_2011CASEINFODATA": {
        return { ...state, caseReExamData: action.data, caseSchedulingErrorData: undefined };
      }
      case "GET_DEFAULTHEARINGTIMES": {
        return { ...state, defaultHearingTimesData: action.data, caseSchedulingErrorData: undefined };
      }
      case "RESET_CASESCHEDULING": {
        return caseSchedulingReducerDefaultState;
      }
      default:
      return state;
  }
};

export default caseSchedulingReducer;
