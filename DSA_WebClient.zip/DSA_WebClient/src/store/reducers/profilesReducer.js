const employeeProfilesReducerDefaultState = {
  profilesErrorData: undefined
};

const employeeProfilesReducer = (state = employeeProfilesReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_EMPPROFILESINITIAL_DATA": {
      return { ...state, employeeProfilesInitialData: action.data, profilesErrorData: undefined };
    }
    case "GET_EMPPROFILES_DATA": {
      return { ...state, employeeProfilesData: action.data, profilesErrorData: undefined };
    }   
    case "GET_CREATEPROFILE_DATA":
    {
      return { ...state, createProfileData: action.data, profilesErrorData: undefined };
    }
    case "GET_PROFILECREATED_DATA":
    {
      return { ...state, profileCreatedData: action.data, profilesErrorData: undefined };
    }
    case "GET_EMPLOYEEPROFDELETED_DATA":
    {
      return { ...state, employeeProfilesData: action.data, profilesErrorData: undefined };
    }
    case "GET_EMPLOYEEHEARINGAUTH_DATA":
    {
      return { ...state, hearingAuthData: action.data, profilesErrorData: undefined }
    }
    case "GET_HAUTHEDITED_DATA":
    {
      return { ...state, hearingAuthEditedData: action.data, profilesErrorData: undefined }
    }
    case "GET_HEARINGLOCATION_DATA":
    {
      return { ...state, hearingLocationsData: action.data, profilesErrorData: undefined }
    }
    case "GET_HEARINGROOMPROFILES_DATA":
    {
      return { ...state, hearingRoomProfilesData: action.data, profilesErrorData: undefined }
    }
    case "GET_DISTRICTOFFICES_DATA":
    {
      return { ...state, districtOfficesData: action.data, profilesErrorData: undefined }
    }
    case "GET_HEARINGROOMPROFILEBYLOCATION_DATA":
    {
      return { ...state, hearingRoomProfilebyLocation: action.data, profilesErrorData: undefined }
    }
    case "GET_EMPLOYEELIST_DATA":
    {
      return { ...state, employeeList: action.data, profilesErrorData: undefined }
    }
    case "GET_EMPLOYEEAPPMNT_DATA":
    {
      return { ...state, employeeappmnt : action.data, profilesErrorData: undefined }
    }
    case "GET_UPDATEDROOMPROF_DATA":
    {
      return { ...state, updatedRoomProfile: action.data, profilesErrorData: undefined }
    }
    case "GET_CREATEEMPTIMEOFF_DATA":
    {
      return { ...state, employeeApptCreateData: action.data, profilesErrorData: undefined }
    }
    case "GET_PROFILESERRORDATA":
    {
      return { ...state, profilesErrorData: action.data, profErrRandom: Math.random()}
    }
    case "GET_DEFAULTROOMPROFILE_DATA":
    {
      return { ...state, defaultRoomProfileData: action.data, profilesErrorData: undefined}
    }
    case "GET_CREATETIMEOFF_DATA":
    {
      return { ...state, createTimeOffData: action.data, profilesErrorData: undefined}
    }
    case "GET_EMPAPPBYREACNO_DATA":
    {
      return { ...state, editTimeOffData: action.data, profilesErrorData: undefined}
    }
    case "GET_EMPLOYEETOEDITED_DATA":
    {
      return { ...state, editedTimeOffData: action.data, profilesErrorData: undefined}
    }
    case "GET_EMPLOYEETODELETED_DATA":
    {
      return { ...state, deletedTimeOffData: action.data, profilesErrorData: undefined}
    }
    case "GET_HEARINGROOMTIMEOFF_DATA":
    {
      return { ...state, hearingRoomTOData: action.data, profilesErrorData: undefined}
    }
    case "GET_HEARINGROOMTIMEOFFDEFAULT_DATA":
    {
      return { ...state, hearingRoomTOData: action.data, profilesErrorData: undefined}
    }
    case "GET_HEARINGROOMTIMEOFFEDIT_DATA":
    {
      return { ...state, hearingRoomEditData: action.data, profilesErrorData: undefined}
    }
    case "GET_HEARINGROOMTOCREATED_DATA":
    {
      return { ...state, hearingRoomTOData: action.data, profilesErrorData: undefined}
    }
    case "GET_HRTOEDITED_DATA":
    {
      return { ...state, hearingRoomTOData: action.data, profilesErrorData: undefined}
    }
    case "GET_HEARINGROOMTODELETED_DATA":
    {
      return { ...state, hearingRoomTOData: action.data, profilesErrorData: undefined}
    }   
    default:
      return state;
  }
};

export default employeeProfilesReducer;