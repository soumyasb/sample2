const calendarReducerDefaultState = {
  calendarEmployeesList: undefined,
  employeesCalendarsData: undefined,
  casesAssignedList: undefined,
  calendarOfficesList: undefined,
  officeCalendarsData: undefined
  };
  
  const calendarReducer = (state = calendarReducerDefaultState, action) => {
    switch (action.type) {
      case "GET_CALENDAREMPLOYEES": {
        return { ...state, calendarEmployeesList: action.data };
      }
      case "GET_EMPLOYEESCALENDARS": {
        return { ...state, employeesCalendarsData: action.data };
      }
      case "RESET_CALENDAR": {
        return calendarReducerDefaultState;
      }
      case "GET_CASESASSIGNED": {
        return { ...state, casesAssignedList: action.data }
      }
      case "GET_CALENDAROFFICES": {
        return { ...state, calendarOfficesList: action.data }
      }
      case "GET_OFFICECALENDARS": {
        return { ...state, officeCalendarsData: action.data }
      }
      case "GET_HEARINGROOMS": {
        return { ...state, hearingRoomsList: action.data }
      }
      case "GET_HEARINGROOMCALENDAR": {
        return { ...state, hearingRoomCalendarData: action.data }
      }
      default:
      return state;
  }
};

export default calendarReducer;