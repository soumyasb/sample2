import React from "react";

import { Row } from "antd";
import MainHeader from "../components/header";
import MainContent from "../components/content";
import MainFooter from "../components/footer";

const mainLayout = () => (
  <Row id="ML" onClick={(e) => {document.getElementById("ML").blur()}} tabIndex="-1" style={{ height: "100%" }}>
    <MainHeader />
    <MainContent />
    <MainFooter />
  </Row>
);

export default mainLayout;
