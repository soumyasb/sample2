const { injectBabelPlugin } = require("react-app-rewired");

module.exports = function override(config, env) {
  // do stuff with the webpack config...
  config = injectBabelPlugin(
    [
      "import",
      { libraryName: "antd", libraryDirectory: "es", style: "css" },
      "import",
      {
        libraryName: "primereact",
        libraryDirectory: "components",
        style: "css"
      }
    ],
    config
  );
  return config;
};
