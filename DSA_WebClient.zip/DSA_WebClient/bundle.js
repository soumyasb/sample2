process.env.NODE_ENV = "production";
var BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
  .BundleAnalyzerPlugin;

const webpackConfigProd = require("react-scripts/config/webpack.config.prod");

webpackConfigProd.plugins.push(
  new BundleAnalyzerPlugin({
    analyzerMode: "static",
    reportFilename: "report.html"
  })
);

webpackConfigProd.plugins.push(    
  new webpack.optimize.UglifyJsPlugin({
  mangle: true,
  compress: {
    warnings: false, // Suppress uglification warnings
    pure_getters: true,
    unsafe: true,
    unsafe_comps: true,
    screw_ie8: true
  },
  output: {
    comments: false,
  },
  exclude: [/\.min\.js$/gi] // skip pre-minified libs
}));

webpackConfigProd.plugins.push(
  new webpack.IgnorePlugin(/^\.\/locale$/, [/moment$/])
);

webpackConfigProd.push(
  {devtool: 'source-map'}
);
webpackConfigProd.plugins.push(
  new webpack.optimize.DedupePlugin())
  ;

webpackConfigProd.plugins.push(new webpack.NoErrorsPlugin());
webpackConfigProd.plugins.push(new CompressionPlugin({
  asset: "[path].gz[query]",
  algorithm: "gzip",
  test: /\.js$|\.css$|\.html$/,
  threshold: 10240,
  minRatio: 0
}));
require("react-scripts/scripts/build");
