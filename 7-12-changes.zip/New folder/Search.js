import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/commonActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table } from 'antd';

const columns = [{
  title: 'First Name',
  dataIndex: 'FirstName',
  key: 'FirstName',
  width: 150,
  render: text => <a href="javascript:;">{text}</a>,
}, {
  title: 'Last Name',
  dataIndex: 'LastName',
  key: 'LastName',
  width: 150,
}, {
  title: 'DL Number',
  dataIndex: 'dlNumber',
  key: 'dlNumber',
}];


// remove this json data import....
//import searchDataJson from '../mocks/searchcasebystring.json'

class Search extends Component {
    constructor(props) {
        super(props);

        this.state={
            searchList: props.common.searchList
        };
    }    

    componentDidMount() {
        debugger;
        // TODO - Call your search api action here....
        const params = new URLSearchParams(this.props.location.search);
        const searchText =  params.get('searchText') ? params.get('searchText') : '';

        this.props.searchCases(searchText);

    }

    componentWillReceiveProps(nextProps) {
        debugger;
        if (this.props.location.search !== nextProps.location.search) {
            // Whenever the search text changes.. call the search api again here...
            // remove the existing line below...
            const params = new URLSearchParams(nextProps.location.search);
            const searchText =  params.get('searchText') ? params.get('searchText') : '';

            //api call - parameter as searchtext
            this.props.searchCases(searchText);
        }

        if (this.props.common.searchList !== nextProps.common.searchList) {
            this.setState({ searchList: nextProps.common.searchList});
        }
    }

    render() {
        const params = new URLSearchParams(this.props.location.search);
        const searchText =  params.get('searchText') ? params.get('searchText') : '';

        // We have the searched results in the state.searchList... I am displaying it ul format for testing.. 
        // we can display the same in the table using the same data... 
        debugger;
     
        let results = [];
    // if(this.state.searchList !== undefined)
    // {
    // results = this.state.searchList.results.map((item, index) => {
    //         return (<ul key={`sRow${index}`} >
    //             <li key={`fn${index}`}>{item.FirstName}</li>
    //             <li key={`ln${index}`}>{item.LastName}</li>
    //             <li key={`dl${index}`}>{item.dlNumber}</li>
    //         </ul>);
    //     });
    // }
// const searchResults = this.state.searchList.results;
// const count = searchResults.length;
    return (
        <div>
        {this.state.searchList && <Table rowKey = "dlNumber" bordered = {false} size = 'default' showHeader
    scroll="none" title={() => <div><span><h1>Search Results for:</h1></span><span>{searchText}</span></div>} footer={() => <p>{this.state.searchList.results.length} results found</p>} columns={columns} dataSource={this.state.searchList.results} />
    }
    </div>
    );
}

        // return (<div><h1> Search Results: </h1>
        //     {results}
        // </div>
        // );
    
}

    
const mapStateToProps = state => {
    return {
       common: state.common
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            searchCases
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(Search);
//export default Search;
