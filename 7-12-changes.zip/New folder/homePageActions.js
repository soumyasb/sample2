import axios from "axios";

//HOMEPAGE ACTIONS
export const getHomePage = data => ({
  type: "GET_HOMEPAGE",
  data: data
});

export const initHomePage = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HomePage").then(response => {
      console.log("Getting news Items");
      dispatch(getHomePage(response.data));
      // return { ...state, data };
    });
  };
};
