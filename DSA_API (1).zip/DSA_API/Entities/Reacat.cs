﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Reacat
    {
        public int Id { get; set; }
        public string CdBgnRsn { get; set; }
        public string CdEndRsn { get; set; }
        public string DescCatgry { get; set; }
        public string CdNodef { get; set; }
        public DateTime? DtTerm { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }
}
