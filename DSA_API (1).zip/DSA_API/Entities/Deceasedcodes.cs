﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Deceasedcodes
    {
        public string CdDeceased { get; set; }
        public string DescDeceased { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
