﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Authoritysection
    {
        public int Id { get; set; }
        public string CdTransaction { get; set; }
        public string CdVc { get; set; }
        public string DescAuthority { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
