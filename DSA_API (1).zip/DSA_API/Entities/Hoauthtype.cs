﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Hoauthtype
    {
        public int Id { get; set; }
        public int EmpId { get; set; }
        public string CdEmpId { get; set; }
        public string CdRsn { get; set; }
        public DateTime DtEffStrt { get; set; }
        public DateTime? DtEffEnd { get; set; }
        public string TmeDefault { get; set; }
        public string CdHrngTyp { get; set; }

        public Employee Emp { get; set; }
    }
}
