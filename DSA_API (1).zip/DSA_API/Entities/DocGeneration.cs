﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class DocGeneration
    {
        public string CdCase { get; set; }
        public string CdTypDoc { get; set; }
        public DateTime DtDocCreated { get; set; }
        public string CdUpdtTechId { get; set; }
        public long NbrDoc { get; set; }

        public Dsrcase CdCaseNavigation { get; set; }
    }
}
