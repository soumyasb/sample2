﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Pullnotice
    {
        public string CdPullnotice { get; set; }
        public string DescPullnotice { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
