﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Docimage
    {
        public long NbrDoc { get; set; }
        public byte[] CdDoc { get; set; }
    }
}
