﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class Apperrlog
    {
        public int Id { get; set; }
        public DateTime DtErr { get; set; }
        public string NmeModule { get; set; }
        public string NmeProc { get; set; }
        public int? NbrErrLine { get; set; }
        public string CdErrTyp { get; set; }
        public string NbrErr { get; set; }
        public string NmeOperId { get; set; }
        public string ValErrKey1 { get; set; }
    }
}
