﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class SuspenseReason
    {
        public string CdReason { get; set; }
        public string DescReason { get; set; }
        public DateTime? DtTerm { get; set; }
    }
}
