﻿using System;
using System.Collections.Generic;

namespace DSA_API.Entities
{
    public partial class ApptCntl
    {
        public int Id { get; set; }
        public short? NbrTyp { get; set; }
        public int? NbrSeq { get; set; }
    }
}
