﻿using AutoMapper;
using DSA_API.Entities;
using DSA_API.Helpers;
using DSA_API.Models.Admin;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace DSA_API.Controllers.Admin
{
    [Produces("application/json")]
    [Route("api/NewsItems")]
    public class NewsItemsController : Controller
    {
        private INewsOfficesRepository _newsOfficesRepository;
        private IUserRepository _userRepository;
        private IDSOfficeRepository _dSOfficeRepository;
        private Employee _user;

        public NewsItemsController(IHomePageRepository homePageRepository, INewsOfficesRepository newsOfficesRepository, IUserRepository userRepository,
            IDSOfficeRepository dSOfficeRepository, DSAContext context)
        {
            _newsOfficesRepository = newsOfficesRepository;
            _userRepository = userRepository;
            _dSOfficeRepository = dSOfficeRepository;
           // _context = context;
        }
        [HttpGet]
        public IActionResult GetNewsItemsForUser()
        {
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //_user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
    
            if (_user.CdEmpTyp != "D" & _user.CdEmpTyp != "R" & _user.CdEmpTyp != "O")
            {
                return BadRequest();
            }
            var newsItems = _newsOfficesRepository.GetNewsItems(_user.EmpId);

            return Ok(newsItems);
        }
        // GET: NewsItems/Details/5
        [HttpGet("GetNewsItemDetails/{id}", Name = "GetNewsItem")]
        public IActionResult GetNewsItemDetails(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            NewsItem newsItem = _newsOfficesRepository.GetNewsItem(id);
            if (newsItem == null)
            {
                return NotFound();
            }
            return Ok(newsItem);
        }

        // GET: NewsItems/Create
        [HttpGet("CreateNewsItem")]
        public IActionResult CreateNewsItem()
        {
            //_officeRepo = new DSOfficeRepository();
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
            if (_user.CdEmpTyp != "O" & _user.CdEmpTyp != "R" & _user.CdEmpTyp != "D")
            {
                  ModelState.AddModelError(nameof(NewsItemDTO),
                        "Only managers can create news items.");
            }
            
            NewsItemDTO newsItem = new NewsItemDTO();
            newsItem.EmpId = _user.EmpId;
            newsItem.AuthorName = _user.NmeFrstPrsn + " " + _user.NmeSurnmePrsn;
            newsItem.StartDate = DateTime.Now;
            newsItem.EndDate = DateTime.Now;
            newsItem.EmployeeType = _user.CdEmpTyp;
            switch (_user.CdEmpTyp)
            {
                case "D":
                    newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "D", null);
                    break;
                case "O":
                    newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "O", _user.CdOffId);
                    break;
                case "R":
                    newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "R", _user.CdOffId);
                    break;
                default:
                    break;
            }
            return Ok(newsItem);
        }

        // GET: NewsItems/EditNewsItem/5
        [HttpGet("EditNewsItem/{id}", Name = "EditNewsItem")]
        public IActionResult EditNewsItem(int id)
        {
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            _user = _userRepository.GetEmployee("MWMPG4");
            if (_user == null)
            {
                return NotFound();
            }
            if (id == 0)
            {
                return BadRequest();
            }

            var newsItemFromRepo = _newsOfficesRepository.GetNewsItem(id);
            if (newsItemFromRepo == null)
            {
                return NotFound();
            }

            var newsItemForUser = Mapper.Map<NewsItemDTO>(newsItemFromRepo);


            newsItemForUser.EmployeeType = _user.CdEmpTyp;
            switch (_user.CdEmpTyp)
            {
                case "D":
                    newsItemForUser.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "D", null);
                    break;
                case "O":
                    newsItemForUser.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "O", _user.CdOffId);
                    break;
                case "R":
                    newsItemForUser.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "R", _user.CdOffId);
                    break;
                default:
                    break;
            }
            //  the following are a list of offices that are assigned to the newsitem (get via officenewsitem entity)
            List<string> offices = new List<string>();

            var officeNewsItems = _newsOfficesRepository.GetOfficeNewsItems(id);

            foreach (OfficeNewsItem o in officeNewsItems)
            {
                offices.Add(o.CdOffId);
            }
            if (offices.Count == 0)
                newsItemForUser.officeGroup = null;   // officegroup contains only offices assigned to the newsitem
            else
                newsItemForUser.officeGroup = offices;
            return Ok(newsItemForUser);
        }

        // POST: NewsItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost ("ModifyNewsItem")]
        // [ValidateAntiForgeryToken]
        public IActionResult ModifyNewsItem([FromBody] NewsItemDTO newsItem)
        {
            if (newsItem == null)
            {
                return BadRequest();
            }

            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }

            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = userRepo.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");

            List<string> offices = new List<string>();
            if (newsItem.AllOffices || newsItem.EmployeeType == "O")   // AllOffices checkbox is checked or the manager is an office manager
            {
                switch (newsItem.EmployeeType)
                {
                    case "D":
                        newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "D", null);
                        foreach (var item in newsItem.Offices)
                        {
                            offices.Add(item.OfficeId);
                        }
                        break;
                    case "R":
                        newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "R", _user.CdEmpId);
                        foreach (var item in newsItem.Offices)
                        {
                            offices.Add(item.OfficeId);
                        }
                        break;
                    case "O":
                        offices.Add(_user.CdOffId);
                        break;
                    default:
                        break;
                }
            }
            bool updateOk = _newsOfficesRepository.ModifyNewsItems(newsItem);
            bool modifyOk = _newsOfficesRepository.ModifyOfficeNewsItems(newsItem, offices);
            return CreatedAtRoute("GetNewsItem",
                new { id = newsItem.NewsId },
                newsItem);
        }

        // POST: NewsItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("AddNewsItem")]
        //  [ValidateAntiForgeryToken]
        public ActionResult AddNewsItem([FromBody] NewsItemDTO newsItem)
        {
            if (newsItem == null)
            {
                return BadRequest();
            }

            if (!ModelState.IsValid)
            {
                return new UnprocessableEntityObjectResult(ModelState);
            }
            //ClaimsIdentity identity = new ClaimsIdentity();
            //identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            // _user = _userRepository.GetEmployee(identity.Name, true);
            _user = _userRepository.GetEmployee("MWMPG4");
          

            List<string> offices = new List<string>();
            if (newsItem.officeGroup == null)   // AllOffices checkbox is checked or the manager is an office manager
            {
                switch (newsItem.EmployeeType)
                {
                    case "D":
                        newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "D", null);
                        foreach (var item in newsItem.Offices)
                        {
                            offices.Add(item.OfficeId);
                        }
                        break;
                    case "R":
                        newsItem.Offices = _dSOfficeRepository.GetRegionOffices(_user.EmpId, "R", _user.CdOffId);
                        foreach (var item in newsItem.Offices)
                        {
                            offices.Add(item.OfficeId);
                        }
                        break;
                    case "O":
                        offices.Add(_user.CdOffId);
                        break;
                    default:
                        break;
                }
            }
            int newsId = _newsOfficesRepository.CreateNewsItems(newsItem, offices);
            return CreatedAtRoute("GetNewsItem",
                          new { id = newsId },
                          newsItem);
        }
        [HttpGet("DeleteNewsItem/{id}")]
        public IActionResult DeleteNewsItem(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            NewsItem newsitem = _newsOfficesRepository.GetNewsItem(id);
            _newsOfficesRepository.DeleteNewsItem(newsitem);
            return NoContent();
        }
       
    }
}