﻿using DSA_API.Entities;
using DSA_API.Models.Customer;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;

namespace DSA_API.Controllers.Case
{

    [Produces("application/json")]
    [Route("api/Case")]
    public class CaseController : Controller
    {
        private ICustomerRepository _customerRepository;
        private ICaseRepository _caseRepository;
        private IOIPRepository _oIPRepository;
        private ISearchRepository _searchRepository;
        private IUrlHelper _urlHelper;
        private Employee _user;
        private IConfiguration _configuration { get; }

        public CaseController(ICaseRepository caseRepository, 
            ICustomerRepository customerRepository, 
            IOIPRepository oIPRepository, 
            ISearchRepository searchRepository,
            IUrlHelper urlHelper,
            IConfiguration configuration)
        {
            _caseRepository = caseRepository;
            _customerRepository = customerRepository;
            _oIPRepository = oIPRepository;
            _searchRepository = searchRepository;
            _urlHelper = urlHelper;
            _configuration = configuration;
        }
        // GET api/Case/Detail
        /// <summary>
        /// Get case detail 
        /// </summary>
        /// <remarks> This API will retreive case detail for the case number provided</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("{caseNumber}")]
        public IActionResult Detail(string caseNumber, CaseDetailDTO CaseDetailModel)
        {
            if (caseNumber == null)
            {
                return NotFound();
            }
            //var caseNum = Server.HtmlEncode(caseNumber);
            //  CaseDetailDTO CaseDetailModel = new CaseDetailDTO();
            CaseDetailModel = new CaseDetailDTO();
            CaseDetailModel = _caseRepository.GetCaseDetails(caseNumber, false);
            var CustModel = _customerRepository.getCustomerDetail(CaseDetailModel.DLNumber);
            CaseDetailModel.HearingType = _caseRepository.GetHearingTypes();
            CaseDetailModel.Reasons = _caseRepository.GetReasons();
            CaseDetailModel.Referrals = _caseRepository.GetReferrals();
            CaseDetailModel.Certs = _caseRepository.GetCerts();
            CaseDetailModel.CaseComments = _caseRepository.GetCaseComments(caseNumber, 1);
            CaseDetailModel.Customer = CustModel;
            CaseDetailModel.CaseOIPs = new CaseOIPDTO();
            CaseDetailModel.CaseOIPs.OIPs = GetCaseOIPs(caseNumber);
            CaseDetailModel.CaseOIPs.OIP_TYPES = _oIPRepository.getOIPTypes();
            CaseDetailModel.CaseOIPs.Language = _oIPRepository.getLanguages();
            CaseDetailModel.CaseContacts = _caseRepository.GetCaseContacts(caseNumber);
            CaseDetailModel.EmployeeContacts = _caseRepository.GetCaseEmployeeContacts(caseNumber);
            CaseDetailModel.RescheduleList = _caseRepository.GetCaseReschedules(caseNumber);
            //  Patch for Razor
            //  Check for Selected OIPTYPE for first OIP. RAZOR is Unable
            //  to Match Selected if Char is used as option value.
            //  Added additional fix for null check on first OIP record
            foreach (var i in CaseDetailModel.CaseOIPs.OIP_TYPES)
            {
                if (CaseDetailModel.CaseOIPs.OIPs.Count > 0)
                {
                    if (i.Value == CaseDetailModel.CaseOIPs.OIPs[0].CD_PRTY_TYP)
                    {
                        i.Selected = true;
                    }
                }
            }
            return Ok(CaseDetailModel);
        }
        // GET api/Case/Search
        /// <summary>
        /// Search DS database for subject, case 
        /// </summary>
        /// <remarks> This API will search and retreive the DS database for subject and it's cases</remarks>
        /// <param name="keyword"></param>
        /// <returns>JSON</returns>
        [HttpGet("Search/{keyword}")]
        public IActionResult Search(string keyword)
        {
            keyword = keyword.Trim().ToLower();
            var model = _searchRepository.CaseSearch(keyword);
            return Ok(model);
        }

        // POST api/geth6
        /// <summary>
        /// GET H6 Information for driver
        /// </summary>
        /// <remarks> This API will get H6 information from the driver record</remarks>
        /// <param name="h6dto"></param>
        /// <returns>JSON</returns>
        [HttpPost("geth6")]
      //  [ValidateAntiForgeryToken]
        public IActionResult geth6([FromBody] H6DTO h6dto)
        {
            string dlNumber = h6dto.DLNumber;
            string outputType = "application/json";
            string json;

            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;

            //string requestorCode = identity.FindFirst("RequestorCode").Value;
            //string netName = identity.FindFirst("NetName").Value;
            //string employeeThreeDigit = identity.FindFirst("EmployeeThreeDigit").Value;

            string requestorCode = "86301";
            string netName = "#ADMV6LI";
            string employeeThreeDigit = "MPG";
            try
            {
                using (var client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //client.BaseAddress = new Uri(ConfigurationManager.AppSettings["MQWebServiceBaseURI"].ToString());
                    client.BaseAddress = new Uri(_configuration["MQWebServiceBaseURI"].ToString());
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue(outputType));
                    client.DefaultRequestHeaders.Add("MQ-Tame", "MWHSS1");
                    client.DefaultRequestHeaders.Add("MQ-NetName", netName.ToUpper());
                   // client.DefaultRequestHeaders.Add("MQ-RACFID", identity.Name.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-RACFID", "MWMPG4");
                    client.DefaultRequestHeaders.Add("MQ-EmployeeID", employeeThreeDigit.ToUpper());
                    client.DefaultRequestHeaders.Add("MQ-EmployeeRequestorCode", requestorCode);
                    var response = client.GetAsync("inquiry/DAD/H6/" + dlNumber).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        json = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        json = "error";
                    }
                }
            }
            catch (Exception e)
            {
                json = "Unable to connect to MQ Service at this time";
            }


            return Ok(json);
        }
        // GET api/Case/GetScheduledCases
        /// <summary>
        /// Get scheduled cases assigned to the user's office 
        /// </summary>
        /// <remarks> This API will retreive scheduled cases for the user's office.
        /// sort 1 - contact start date, dlNumber
        /// sort 2 - Office name, dlNumber
        /// sort 3 - Dl Number
        /// sort 4 - Employee last name, first name, DL number
        /// sort 5 - Person last name, person first name, Dl number
        /// sort 6 - Reason, DL number
        /// sort 7 - Type, Dl number
        /// sort 8 - Location, Dl number</remarks>
        /// <param name="officeid"></param>
        /// <param name="sort"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetScheduledCases")]
        public IActionResult GetScheduledCases(string officeid, string sort)
        {
            //string json = "";
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            //sort = "1";

            //var results = _caseRepository.GetScheduledCases(identity.Name.ToUpper());
            var results = _caseRepository.GetScheduledCases(officeid, sort);
            return Ok(results);
        }
        // GET api/Case/GetUnscheduledCases
        /// <summary>
        /// Get unscheduled cases assigned to the user's office 
        /// </summary>
        /// <remarks> This API will retreive unscheduled cases for the user's office.
        /// sort 1 - Case number, dlNumber
        /// sort 2 - receipt date, dlNumber
        /// sort 3 - Dl Number
        /// sort 4 - location, DL number
        /// sort 5 - Person last name, person first name, Dl number
        /// sort 6 - Reason, DL number
        /// sort 7 - Type, Dl number
        /// sort 8 - DL number, receipt date, reason</remarks>
        /// <param name="officeid"></param>
        /// <param name="sort"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetUnScheduledCases")]
        public IActionResult GetUnScheduledCases(string officeid, string sort)
        {
            //string json = "";
            //var identity = (ClaimsIdentity)User.Identity;
            //IEnumerable<Claim> claims = identity.Claims;
            //sort = "1";

            //var results = _caseRepository.GetScheduledCases(identity.Name.ToUpper());
            var results = _caseRepository.GetUnScheduledCases(officeid, sort);
            
            return Ok(results);
        }

        //public string jwt()
        //{
        //    string jwt = "eyJ1bmlxdWVfbmFtZSI6Im13ZHdzNCIsIm5hbWVpZCI6Im13ZHdzNCIsIk5ldE5hbWUiOiIjQURNVjJZVCIsIlJlcXVlc3RvckNvZGUiOiI4NjMwMSIsIkVtcGxveWVlSUQiOiIzMjciLCJFbXBsb3llZVRocmVlRGlnaXQiOiJEV1MiLCJyb2xlIjpbIkRTQSIsIkRTQV9SX0RFVkVMT1BFUiIsIklUSU1fUl9VU0VSIl0sImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6MzYzNDAvIiwiZXhwIjoxNDk5MzY1OTU0LCJuYmYiOjE0OTkzNjQxNTR9";
        //    byte[] data = Convert.FromBase64String(jwt);
        //    string decodedString = Encoding.UTF8.GetString(data);
        //    return decodedString;
        //}

        //[System.Web.Http.HttpPost]
        //public string headers()
        //{
        //    var headers = Request.Headers;

        //    return headers.ToString();
        //}


        //public string cookie()
        //{
        //    var cookies = Request.Cookies.Keys;

        //    string output = "";

        //    foreach (var c in cookies)
        //    {
        //        output += c + ", ";
        //    }

        //    return output;
        //}

        // GET api/Case/GetCaseOIPs
        /// <summary>
        /// Get case's Other interested parties
        /// </summary>
        /// <remarks> This API will retreive the cases' OIPs</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        private List<OIPDTO> GetCaseOIPs(string caseNumber)
        {
            List<OIPDTO> OIPs = new List<OIPDTO>();
            OIPs = _caseRepository.GetAssignedOIPs(caseNumber);
            foreach (OIPDTO o in OIPs)
            {
                o.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = o.OIPID, type = o.CD_PRTY_TYP });
                o.caseAssignURI = _urlHelper.RouteUrl("OIPCaseAssign", new { oipid = o.OIPID, casenumber = caseNumber, type = o.CD_PRTY_TYP });
            }
            return OIPs;
        }


        // GET api/Case/GetCaseCoverSheet
        /// <summary>
        /// Get case's coversheet data when creating or closing a case.
        /// </summary>
        /// <remarks> This API will retreive the cases' OIPs</remarks>
        /// <param name="caseNumber"></param>
        /// <returns>JSON</returns>
        [HttpGet("GetCaseCoverSheet")]
        public IActionResult GetCaseCoverSheet(string caseNumber)
        {
            CaseCoverSheetDTO coversheet = new CaseCoverSheetDTO();
            coversheet = _caseRepository.GetCaseCoverSheetInfo(caseNumber);
            //foreach (OIPDTO o in OIPs)
            //{
            //    o.resourceURI = _urlHelper.RouteUrl("OIPID", new { oipid = o.OIPID, type = o.CD_PRTY_TYP });
            //    o.caseAssignURI = _urlHelper.RouteUrl("OIPCaseAssign", new { oipid = o.OIPID, casenumber = caseNumber, type = o.CD_PRTY_TYP });
            //}
            return Ok(coversheet);
        }
    }
}
