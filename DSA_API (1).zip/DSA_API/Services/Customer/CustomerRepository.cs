﻿using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Models.Customer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class CustomerRepository : ICustomerRepository
    {
        private DSAContext _context;
        private DSARCHIVEContext _archived_context;
        public CustomerRepository(DSAContext context, DSARCHIVEContext archive_context  )
        {
            _context = context;
            _archived_context = archive_context;
        }
        public CustomerDTO getCustomerDetail(string dlNumber)
        {
            var archived = _archived_context.Person.AsNoTracking()
                .Where(c => c.NbrDl == dlNumber)
                .Select(cust => new CustomerDTO()
                {
                    Message = dlNumber + " All Cases for this Drivers License are archived - please contact LOD MIS Group for Information "
                }).FirstOrDefault();
            if (archived != null)
            {
                return archived;
            }

            var customerDetail = _context.Person.AsNoTracking()
                .Where(c => c.NbrDl == dlNumber)
                .Select(cust => new CustomerDTO()
                {
                    DLNumber = cust.NbrDl,
                    FirstName = cust.NmeFrstPrsn,
                    LastName = cust.NmeSurnmePrsn,
                    MiddleName = cust.NmeMidPrsn,
                    Suffix = cust.NmeSufxPrsn,
                    DT_BIRTH_PRSN = cust.DtBirthPrsn,
                    Address1 = cust.AddrLn1,
                    City = cust.CdCity,
                    State = cust.CdState,
                    classLicense = cust.CdClassLic,
                    Class1 = cust.CdClassLic,
                    Class2 = cust.CdClassLic2,
                    ZipFull = cust.CdZip + "-" + cust.CdZipAddrLst4,
                    Zip = cust.CdZip
                })
                .FirstOrDefault();

            return customerDetail;
        }
        public bool UpdatePersonFromDCS(string dlNumber, string address1, string city,
          string class1, string class2, string state, string zip, string birthdate,
          string flgAddr, string ssn, string firstname, string middlename, string suffix,
          string lastname)
        {
            Entities.Person result = (from p in _context.Person
                             where p.NbrDl == dlNumber
                             select p).SingleOrDefault();
            result.AddrLn1 = address1;
            result.CdCity = city;
            result.CdClassLic = class1;
            result.CdClassLic2 = class2;
            result.CdState = state;
            result.CdZip = zip;
            result.DtBirthPrsn = Convert.ToDateTime(birthdate);
            result.FlgAddrConfdntl = flgAddr;
            result.NbrSsnPrsn = Convert.ToInt32(ssn);
            result.NmeFrstPrsn = firstname;
            result.NmeMidPrsn = middlename;
            result.NmeSufxPrsn = suffix;
            result.NmeSurnmePrsn = lastname;
            return (_context.SaveChanges() >= 0);
        }
        public CustomerDTO AddCustomer(D26ResultsDTO dlResults)
        {
            CustomerDTO customer = new CustomerDTO();
            Entities.Person p = new Entities.Person()
            {
                NbrDl = dlResults.dlNumber,
                AddrLn1 = dlResults.MAddr,
                CdCity = dlResults.MCity,
                CdClassLic = dlResults.Class1,
                CdClassLic2 = dlResults.Class2,
                CdState = dlResults.MState,
                CdZip = dlResults.ZIP,
                DtBirthPrsn = Convert.ToDateTime(dlResults.BirthDate),
                FlgAddrConfdntl = dlResults.flgAddr,
                NbrSsnPrsn = Convert.ToInt32(dlResults.SSN.Replace("-", "")),
                NmeFrstPrsn = dlResults.firstName,
                NmeMidPrsn = dlResults.middleName,
                NmeSufxPrsn = dlResults.suffix,
                NmeSurnmePrsn = dlResults.lastName
            };

            _context.Person.Add(p);
            _context.SaveChanges();

            customer.DLNumber = dlResults.dlNumber;
            customer.Address1 = dlResults.MAddr;
            customer.City = dlResults.MCity;
            customer.Class1 = dlResults.Class1;
            customer.Class2 = dlResults.Class2;
            customer.State = dlResults.MState;
            customer.Zip = dlResults.ZIP;
            customer.DT_BIRTH_PRSN = Convert.ToDateTime(dlResults.BirthDate);
            customer.SSN = dlResults.SSN;
            customer.FirstName = dlResults.firstName;
            customer.MiddleName = dlResults.middleName;
            customer.Suffix = dlResults.suffix;
            customer.LastName = dlResults.lastName;
            return customer;
        }
    }
}
