﻿using DSA_API.Entities;
using DSA_API.Models.Customer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class PersonRepository : IPersonRepository
    {
        private DSAContext _context;
        public PersonRepository(DSAContext context)
        {
            _context = context;
        }
        public bool UpdatePersonFromDCS(string dlNumber, string address1, string city,
            string class1, string class2, string state, string zip, string birthdate,
            string flgAddr, string ssn, string firstname, string middlename, string suffix,
            string lastname)
        {
            Person result = (from p in _context.Person
                             where p.NbrDl == dlNumber
                             select p).SingleOrDefault();
            result.AddrLn1 = address1;
            result.CdCity = city;
            result.CdClassLic = class1;
            result.CdClassLic2 = class2;
            result.CdState = state;
            result.CdZip = zip;
            result.DtBirthPrsn = Convert.ToDateTime(birthdate);
            result.FlgAddrConfdntl = flgAddr;
            result.NbrSsnPrsn = Convert.ToInt32(ssn);
            result.NmeFrstPrsn = firstname;
            result.NmeMidPrsn = middlename;
            result.NmeSufxPrsn = suffix;
            result.NmeSurnmePrsn = lastname;
            return (_context.SaveChanges() >= 0);
        }
        public CustomerDTO AddPerson(D26ResultsDTO dlResults)
        {
            CustomerDTO customer = new CustomerDTO();
            Entities.Person p = new Entities.Person()
            {
                NbrDl = dlResults.dlNumber,
                AddrLn1 = dlResults.MAddr,
                CdCity = dlResults.MCity,
                CdClassLic = dlResults.Class1,
                CdClassLic2 = dlResults.Class2,
                CdState = dlResults.MState,
                CdZip = dlResults.ZIP,
                DtBirthPrsn = Convert.ToDateTime(dlResults.BirthDate),
                FlgAddrConfdntl = dlResults.flgAddr,
                NbrSsnPrsn = Convert.ToInt32(dlResults.SSN.Replace("-", "")),
                NmeFrstPrsn = dlResults.firstName,
                NmeMidPrsn = dlResults.middleName,
                NmeSufxPrsn = dlResults.suffix,
                NmeSurnmePrsn = dlResults.lastName
            };
            
            _context.Person.Add(p);
            _context.SaveChanges();

            return customer;
        }
    }
}
