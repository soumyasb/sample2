﻿using DSA_API.Entities;
using DSA_API.Models.User;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services 
{
    public class UserRepository : IUserRepository
    {
        private DSAContext _context;
        public UserRepository(DSAContext context)
        {
            _context = context;
        }
        public UserDTO GetUser(string UserName)
        {
            var user = (from u in _context.Employee
                        join o in _context.Dsoffice on u.CdOffId equals o.CdOffId
                        where u.CdLgnId == UserName
                        select new UserDTO()
                        {
                            EmployeeID = u.EmpId,
                            FirstName = u.NmeFrstPrsn,
                            LastName = u.NmeSurnmePrsn,
                            EmployeeClass = u.CdEmpClass,
                            EmployeeType = u.CdEmpTyp,
                            RACFID = u.CdLgnId,
                            RequestorCode = o.CdRqstr,
                            OfficeID = o.CdOffId,
                            AssignedOfficeName = o.NmeOff,
                            Office = o
                        }).FirstOrDefault();
            return user;
        }

        public Employee GetEmployee(string loginId)
        {
            
            var employee = _context.Employee.AsNoTracking()
               .Where(e => e.CdLgnId == loginId)
               //.Include(a => a.CdOff)
               .FirstOrDefault();

           return employee;
        }


    }
}
