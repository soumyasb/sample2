﻿using System.Collections.Generic;
using DSA_API.Models;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DSA_API.Services
{
    public interface ICaseRepository
    {
        bool AssignAgencyByCaseNumber(OIPDTO newOIP);
        bool AssignOIPByCaseNumber(OIPDTO newOIP);
        OIPDTO GetAgency(int OIPID);
        List<OIPDTO> GetAssignedOIPs(string CaseNumber);
        CaseCommentsDTO GetCaseComments(string CaseNumber, int page);
        CaseDetailDTO GetCaseDetails(string CaseNumber, bool Archive);
        List<CaseDetailDTO> GetCasesByDLNumber(string dlNumber);
        IEnumerable<SelectListItem> GetCerts();
        IEnumerable<SelectListItem> GetHearingTypes();
        OIPDTO GetOIP(int OIPID);
        IEnumerable<SelectListItem> GetReasons();
        IEnumerable<SelectListItem> GetReferrals();
        int NewAgency(OIPDTO OIPObj);
        int NewOIP(OIPDTO OIPObj);
        bool RemoveAssignedAgencyByCaseNumber(OIPDTO oipdto);
        bool RemoveAssignedOIPByCaseNumber(OIPDTO oipdto);
        bool SaveNewComment(string CaseNumber, string Comment, string Employee3Digit, string DLNumber);
        OIPDTO UpdateAgency(OIPDTO OIPObj);
        OIPDTO UpdateOIP(OIPDTO OIPObj);
        ScheduledCasesDTO GetScheduledCases(string officeId, string sort);
        UnScheduledCasesDTO GetUnScheduledCases(string officeId, string sort);
        CaseContactsDTO GetCaseContacts(string caseNumber);
        EmployeeContactsDTO GetCaseEmployeeContacts(string caseNumber);
        CaseRescheduleListDTO GetCaseReschedules(string caseNumber);
        CaseCoverSheetDTO GetCaseCoverSheetInfo(string casenumber);
    }
}