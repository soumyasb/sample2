﻿using AutoMapper;
using DSA_API.Entities;
using DSA_API.Entities.Archive;
using DSA_API.Helpers;
using DSA_API.Models.Customer;
using DSA_API.Models;
using DSA_API.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class CaseRepository : ICaseRepository
    {
        private DSAContext _context;
        private DSARCHIVEContext _archived_context;

        private MapperConfiguration _config;
        private IMapper _mapper;
        public CaseRepository(DSAContext context, DSARCHIVEContext archived_context)
        {
            _context = context;
            _archived_context = archived_context;
            _config = new MapperConfiguration(cfg => {
                cfg.CreateMap<OIPDTO, Oippersn>();
                cfg.CreateMap<OIPDTO, Agency>();
                cfg.CreateMap<OIPDTO, Caseoip>();
                cfg.CreateMap<OIPDTO, Caseagny>();
            });
            _mapper = _config.CreateMapper();
        }


        /// <summary>
        /// GET Case Details by CaseNumber
        /// </summary>
        /// <param name="CaseNumber"></param>
        /// <param name="Archived"></param>
        /// <returns></returns>
        public CaseDetailDTO GetCaseDetails(string CaseNumber, bool Archived)
        {
            var casedetail = new CaseDetailDTO();

            var result = _context.Dsrcase.AsNoTracking()
                    .Where(e => e.CdCase == CaseNumber)
                    .FirstOrDefault();
            if (result == null)
                Archived = true;

            if (!Archived)
            {
                casedetail = (from c in _context.Dsrcase.AsNoTracking()

                                      //Left Join Alternative(one liner)
                                  from r in _context.Reason.Where(r => r.CdRsn == c.CdRsn).DefaultIfEmpty()
                                  from h in _context.Hearingtype.Where(h => h.CdHrngTyp == c.CdHrngTyp).DefaultIfEmpty()
                                  from p in _context.Person.Where(p => p.NbrDl == c.NbrDl).DefaultIfEmpty()

                                      //Simulated Left Join(Long Way)
                                      //join r in _context.REASONs.AsNoTracking().DefaultIfEmpty() on c.CD_RSN equals r.CD_RSN into trsn
                                      //from newrsn in trsn.DefaultIfEmpty()

                                      //Simple Join (No Good)
                                      //join r in _context.REASONs.AsNoTracking() on c.CD_RSN equals r.CD_RSN
                                      //join h in _context.HEARINGTYPEs.AsNoTracking() on c.CD_HRNG_TYP equals h.CD_HRNG_TYP
                                      //join p in _context.People.AsNoTracking() on c.NBR_DL equals p.NBR_DL
                                  where c.CdCase == CaseNumber
                                  select new CaseDetailDTO()
                                  {
                                      CaseNumber = c.CdCase,
                                      DLNumber = c.NbrDl,
                                      lastName = p.NmeSurnmePrsn,
                                      firstName = p.NmeFrstPrsn,
                                      CD_HRNG_TYP = c.CdHrngTyp,
                                      DESC_HRNG_TYP = h.DescHrngTyp,
                                      DT_ORIG_TRANS = c.DtOrigTrans,
                                      CaseStatus = c.CdStatusRec + c.CdStatusRec2,
                                      DT_RCPT = c.DtRcpt,
                                      CD_REFR_SRCE_TYP = c.CdRefrSrceTyp,
                                      CD_RSN = c.CdRsn,
                                      CD_ENDR = c.CdEndr,
                                      DESC_RSN = r.DescRsn,
                                      Archived = false
                                  }).FirstOrDefault();
            }
            else
            {
                casedetail.CaseNumber = CaseNumber;
                casedetail.CaseStatus = "35";
                casedetail.Archived = true;
            }
            return casedetail;
        }
        public IEnumerable<SelectListItem> GetHearingTypes()
        {
            var HearingTypes = (from h in _context.Hearingtype
                                orderby h.CdHrngTyp ascending
                                select new SelectListItem()
                                {
                                    Text = h.CdHrngTyp + " - " + h.DescHrngTyp,
                                    Value = h.CdHrngTyp
                                }).ToList();

            HearingTypes.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });

            return HearingTypes;
        }



        public IEnumerable<SelectListItem> GetReasons()
        {
            var reasons = (from r in _context.Reason
                            orderby r.CdRsn ascending
                            select new SelectListItem()
                            {
                                Text = r.CdRsn + " - " + r.DescRsn,
                                Value = r.CdRsn
                            }).ToList();
            reasons.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return reasons;
        }



        public IEnumerable<SelectListItem> GetReferrals()
        {
            var referrals = (from r in _context.Referral
                                orderby r.CdRefrSrceTyp ascending
                                select new SelectListItem()
                                {
                                    Text = r.CdRefrSrceTyp + " - " + r.DescRefrSrceTyp,
                                    Value = r.CdRefrSrceTyp
                                }).ToList();
            referrals.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return referrals;
        }




        public IEnumerable<SelectListItem> GetCerts()
        {
            var certs = (from c in _context.Cert
                            orderby c.CdCertEndr ascending
                            select new SelectListItem()
                            {
                                Text = c.CdCertEndr + " - " + c.DescCertEndr,
                                Value = c.CdCertEndr
                            }).ToList();
            certs.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return certs;
        }



        public List<CaseDetailDTO> GetCasesByDLNumber(string dlNumber)
        {
            List<CaseDetailDTO> casesDetailed = new List<CaseDetailDTO>();

            var archive_cases = (from c in _archived_context.Dsrcase
                         where c.NbrDl == dlNumber
                         orderby c.DtOrigTrans descending
                         select c.CdCase)
                            .ToArray();

            var cases = (from c in _context.Dsrcase
                            where c.NbrDl == dlNumber
                            orderby c.DtOrigTrans descending
                            select c.CdCase)
                            .ToArray();
           

            foreach (var i in archive_cases)
            {
                casesDetailed.Add(GetCaseDetails(i, true));
            }
            foreach (var i in cases)
            {
                casesDetailed.Add(GetCaseDetails(i, false));
            }
            return casesDetailed;
        }

        public CaseCommentsDTO GetCaseComments(string CaseNumber, int page)
        {
            const int PAGE_SIZE = 5;
            var query = (from c in _context.Dsrcomm
                            join emp in _context.Employee on c.CdUpdtTechId equals emp.CdEmpId
                            where c.CdCase == CaseNumber
                            select new CustomerCommentDTO()
                            {
                                TXT_COMM = c.TxtComm,
                                CD_UPDT_TECH_ID = c.CdUpdtTechId,
                                DT_UPDT_TRANS = c.DtUpdtTrans,
                                NBR_COMM = c.NbrComm,
                                EmployeeFullName = emp.NmeFrstPrsn + " " + emp.NmeSurnmePrsn
                            })
                            .AsQueryable();
            var TotalCount = query.Count();
            var TotalPages = Math.Ceiling((double)TotalCount / PAGE_SIZE);

            var results = query.OrderByDescending(c => c.DT_UPDT_TRANS)
                            .Skip(PAGE_SIZE * (page - 1))
                            .Take(PAGE_SIZE);

            return new CaseCommentsDTO()
            {
                TotalComments = TotalCount,
                TotalPages = TotalPages,
                Comments = results.ToList(),
                CurrentPage = page
            };
        }



        public bool SaveNewComment(string CaseNumber, string Comment, string Employee3Digit, string DLNumber)
        {
            int newestCommentNumber = 0;

            var caseCount = (from c in _context.Dsrcomm.AsNoTracking()
                                where c.CdCase == CaseNumber
                                select c.NbrComm
                                        ).ToArray();

            if (caseCount.Count() != 0)
            {
                newestCommentNumber = caseCount.Max();
            }

            try
            {
                using (_context)
                {
                    _context.Dsrcomm.Add(new Dsrcomm
                    {
                        TxtComm = Comment,
                        CdCase = CaseNumber,
                        CdUpdtTechId = Employee3Digit,
                        NbrDl = DLNumber,
                        NbrComm = ++newestCommentNumber,
                        CdFldDsoAlpha = "SAC",
                        DtUpdtTrans = System.DateTime.Now
                    });

                    _context.SaveChanges();
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }



        public List<OIPDTO> GetAssignedOIPs(string CaseNumber)
        {
            List<OIPDTO> OIPs = new List<OIPDTO>();
            List<OIPDTO> Agencies = new List<OIPDTO>();

            OIPs = (from p in _context.Oippersn
                    join c in _context.Caseoip.AsNoTracking() on p.Oipid equals c.Oipid
                    join d in _context.Dsrcase.AsNoTracking() on c.CdCase equals d.CdCase
                    join t in _context.Oiptype.AsNoTracking() on p.CdPrtyTyp equals t.CdPrtyTyp
                    where d.CdCase == CaseNumber
                    select new OIPDTO()
                    {
                        NME_FRST_PRSN = p.NmeFrstPrsn,
                        NME_SURNME_PRSN = p.NmeSurnmePrsn,
                        NME_MID_PRSN = p.NmeMidPrsn,
                        NME_SUFX_PRSN = p.NmeSufxPrsn,
                        NBR_PHONE = p.NbrPhone,
                        NBR_CELL_PHONE = p.NbrCellPhone,
                        NBR_FAX = p.NbrFax,
                        EmailAddress = p.EmailAddress,
                        NME_AGENCY = p.NmeAgency,
                        ADDR_LN1 = p.AddrLn1,
                        CD_CITY = p.CdCity,
                        CD_STATE = p.CdState,
                        CD_ZIP = p.CdZip,
                        TXT_COMM = p.TxtComm,
                        CD_PRTY_TYP = p.CdPrtyTyp,
                        DESC_PRTY_TYP = t.DescPrtyTyp,
                        OIPID = p.Oipid,
                        NBR_OIP = p.NbrOip
                    }).OrderBy(m => m.NME_SURNME_PRSN).ThenBy(m => m.NME_FRST_PRSN).ToList();

            Agencies = (from a in _context.Agency
                        join c in _context.Caseagny.AsNoTracking() on a.Oipid equals c.Oipid
                        join d in _context.Dsrcase.AsNoTracking() on c.CdCase equals d.CdCase
                        join t in _context.Oiptype.AsNoTracking() on a.CdPrtyTyp equals t.CdPrtyTyp
                        where d.CdCase == CaseNumber
                        select new OIPDTO()
                        {
                            NME_AGENCY = a.NmeAgency,
                            NBR_PHONE = a.NbrPhone,
                            NBR_CELL_PHONE = a.NbrCellPhone,
                            NBR_FAX = a.NbrFax,
                            EmailAddress = a.EmailAddress,
                            CD_CITY = a.CdCity,
                            CD_STATE = a.CdState,
                            CD_ZIP = a.CdZip,
                            TXT_COMM = a.TxtComm,
                            CD_PRTY_TYP = a.CdPrtyTyp,
                            DESC_PRTY_TYP = t.DescPrtyTyp,
                            OIPID = a.Oipid,
                            NBR_OIP = a.NbrOip
                        }).OrderBy(m => m.NME_AGENCY).ToList();

            foreach (OIPDTO vm in OIPs)
            {
                
                
                //vm.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = vm.OIPID, type = vm.CD_PRTY_TYP });
                //vm.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = vm.OIPID, casenumber = CaseNumber, type = vm.CD_PRTY_TYP });
            }

            foreach (OIPDTO vm in Agencies)
            {
                //vm.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = vm.OIPID, type = vm.CD_PRTY_TYP });
                //vm.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = vm.OIPID, casenumber = CaseNumber, type = vm.CD_PRTY_TYP });
            }

            OIPs.AddRange(Agencies);

            return OIPs;
        }


        public OIPDTO GetOIP(int OIPID)
        {
            var OIP = (from p in _context.Oippersn
                        where p.Oipid == OIPID
                        select new OIPDTO()
                        {
                            OIPID = p.Oipid,
                            NBR_OIP = p.NbrOip,
                            NME_FRST_PRSN = p.NmeFrstPrsn,
                            NME_SURNME_PRSN = p.NmeSurnmePrsn,
                            NME_MID_PRSN = p.NmeMidPrsn,
                            NME_SUFX_PRSN = p.NmeSufxPrsn,
                            NBR_PHONE = p.NbrPhone,
                            NBR_CELL_PHONE = p.NbrCellPhone,
                            NBR_FAX = p.NbrFax,
                            EmailAddress = p.EmailAddress,
                            NME_AGENCY = p.NmeAgency,
                            ADDR_LN1 = p.AddrLn1,
                            CD_CITY = p.CdCity,
                            CD_STATE = p.CdState,
                            CD_ZIP = p.CdZip,
                            TXT_COMM = p.TxtComm,
                            CD_PRTY_TYP = p.CdPrtyTyp
                        }).First();
            return OIP;
        }


        public OIPDTO GetAgency(int OIPID)
        {
            OIPDTO OIPVM = new OIPDTO();
            try
            {
                var OIP = (from a in _context.Agency
                            where a.Oipid == OIPID
                            select new OIPDTO()
                            {
                                OIPID = a.Oipid,
                                NBR_OIP = a.NbrOip,
                                NBR_PHONE = a.NbrPhone,
                                NBR_CELL_PHONE = a.NbrCellPhone,
                                NBR_FAX = a.NbrFax,
                                EmailAddress = a.EmailAddress,
                                NME_AGENCY = a.NmeAgency,
                                ADDR_LN1 = a.AddrLn1,
                                CD_CITY = a.CdCity,
                                CD_STATE = a.CdState,
                                CD_ZIP = a.CdZip,
                                TXT_COMM = a.TxtComm,
                                CD_PRTY_TYP = a.CdPrtyTyp
                            }).First();
                return OIP;
            }
            catch (Exception e)
            {
                return OIPVM;
            }
        }


        public OIPDTO UpdateOIP(OIPDTO OIPObj)
        {
            Oippersn mappedObj = _mapper.Map<OIPDTO, Oippersn>(OIPObj);

            try
            {
                _context.Oippersn.Attach(mappedObj);

                var update = _context.Entry(mappedObj);
                update.State = EntityState.Modified;

                update.Property(e => e.DtUpdtTrans).IsModified = false;

                _context.SaveChanges();

                OIPObj.Error = false;
            }
            catch (Exception e)
            {
                OIPObj.Error = true;
            }

            return OIPObj;
        }


        public int NewOIP(OIPDTO OIPObj)
        {
            Oippersn mappedObj = _mapper.Map<OIPDTO, Oippersn>(OIPObj);
            int OIPID;
            try
            {
                _context.Oippersn.Add(mappedObj);

                _context.SaveChanges();

                OIPID = mappedObj.Oipid;

                _context.Caseoip.Add(new Caseoip
                {
                    CdCase = OIPObj.CdCase,
                    Oipid = OIPID,
                    CdUpdtTechId = OIPObj.CD_UPDT_TECH_ID
                });

                _context.SaveChanges();
              

                return OIPID;
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        public int NewAgency(OIPDTO OIPObj)
        {
            Agency mappedObj = _mapper.Map<OIPDTO, Agency>(OIPObj);
            int OIPID;
            try
            {
                
                _context.Agency.Add(mappedObj);

                _context.SaveChanges();

                OIPID = mappedObj.Oipid;

                _context.Caseagny.Add(new Caseagny
                {
                    CdCase = OIPObj.CdCase,
                    Oipid = OIPID,
                    CdUpdtTechId = OIPObj.CD_UPDT_TECH_ID
                });

                _context.SaveChanges();
               

                return OIPID;
            }
            catch (Exception e)
            {
                return 0;
            }
        }


        public OIPDTO UpdateAgency(OIPDTO OIPObj)
        {
            Agency mappedObj = _mapper.Map<OIPDTO, Agency>(OIPObj);

            try
            {
                _context.Agency.Attach(mappedObj);

                var update = _context.Entry(mappedObj);
                update.State = EntityState.Modified;

                update.Property(e => e.DtUpdtTrans).IsModified = false;

                _context.SaveChanges();

                OIPObj.Error = false;
            }
            catch (Exception e)
            {
                OIPObj.Error = true;
            }

            return OIPObj;
        }


        public bool AssignOIPByCaseNumber(OIPDTO newOIP)
        {
            try
            {
                var exists = (from c in _context.Caseoip
                                where c.Oipid == newOIP.OIPID && c.CdCase == newOIP.CdCase
                                select c.CdCase).Count();

                if (exists == 0)
                {
                    _context.Caseoip.Add(new Caseoip
                    {
                        CdCase = newOIP.CdCase,
                        Oipid = newOIP.OIPID,
                        CdUpdtTechId = newOIP.CD_UPDT_TECH_ID
                    });

                    _context.SaveChanges();
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool AssignAgencyByCaseNumber(OIPDTO newOIP)
        {
            try
            {
               
                var exists = (from c in _context.Caseagny
                                where c.Oipid == newOIP.OIPID && c.CdCase == newOIP.CdCase
                                select c.CdCase).Count();

                if (exists == 0)
                {
                    _context.Caseagny.Add(new Caseagny
                    {
                        CdCase = newOIP.CdCase,
                        Oipid = newOIP.OIPID,
                        CdUpdtTechId = newOIP.CD_UPDT_TECH_ID
                    });

                    _context.SaveChanges();
                }
                else
                {
                    return false;
                }
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool RemoveAssignedOIPByCaseNumber(OIPDTO oipdto)
        {
            Caseoip mappedOIP = _mapper.Map<OIPDTO, Caseoip>(oipdto);
            try
            {
               
                _context.Caseoip.Attach(mappedOIP);
                _context.Caseoip.Remove(mappedOIP);
                _context.SaveChanges();
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


        public bool RemoveAssignedAgencyByCaseNumber(OIPDTO oipdto)
        {
            Caseagny mappedOIP = _mapper.Map<OIPDTO, Caseagny>(oipdto);
            try
            {
               
                _context.Caseagny.Attach(mappedOIP);
                _context.Caseagny.Remove(mappedOIP);
                _context.SaveChanges();
                
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public ScheduledCasesDTO GetScheduledCases(string officeId, string sort)
        {
            ScheduledCasesDTO scheduledCases = new ScheduledCasesDTO();
           
            scheduledCases.results = new List<ScheduledCaseDTO>();

            if (String.IsNullOrEmpty(officeId))
            {
                return scheduledCases;
            }
            if (sort == "1")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cnt.DtCntctStrtTim, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "2")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby dso.NmeOff, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "3")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "4")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby emp.NmeSurnmePrsn, emp.NmeFrstPrsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "5")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby per.NmeSurnmePrsn, per.NmeFrstPrsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "6")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdRsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "7")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdHrngTyp, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }


            if (sort == "8")
            {
                var results = (from cnt in _context.Contact.AsNoTracking()
                               join dso in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals dso.CdOffId
                               join cse in _context.Dsrcase.AsNoTracking() on cnt.CdCase equals cse.CdCase
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                               where cnt.CdStatus2 == "3" && cse.CdStatusRec2 != "5" && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby dso.CdOffAbbr, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cnt.DtCntctStrtTim,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSufxPrsn,
                                   per.NmeSurnmePrsn,
                                   employeeFirstName = emp.NmeFrstPrsn,
                                   employeeLastName = emp.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    scheduledCases.results.Add(
                    new ScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        dt_Cntct_Strt_Tim = r.DtCntctStrtTim,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        cd_Off_Abbr = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        EmployeeFirstName = r.employeeFirstName,
                        EmployeeLastName = r.employeeLastName,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            return scheduledCases;
        }
        public UnScheduledCasesDTO GetUnScheduledCases(string officeId, string sort)
        {
            UnScheduledCasesDTO UnscheduledCases = new UnScheduledCasesDTO();

            UnscheduledCases.results = new List<UnScheduledCaseDTO>();
           
            if (String.IsNullOrEmpty(officeId))
            {
                return UnscheduledCases;
            }
            if (sort == "1")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdCase, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "2")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.DtRcpt, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "3")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "4")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdFldDsoAlpha, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            if (sort == "5")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby per.NmeSurnmePrsn, per.NmeFrstPrsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = r.CdStatusRec,
                       // CD_STATUS_REC2 = r.CdStatusRec2,
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "6")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdRsn, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }

            if (sort == "7")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.CdHrngTyp, cse.NbrDl
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }


            if (sort == "8")
            {
                var results = (from dso in _context.Dsoffice.AsNoTracking()
                               join cse in _context.Dsrcase.AsNoTracking() on dso.CdOffAbbr equals cse.CdFldDsoAlpha
                               join per in _context.Person.AsNoTracking() on cse.NbrDl equals per.NbrDl
                               where Convert.ToInt16(cse.CdStatusRec2) < 3 && cse.CdHrngTyp.Any(c => char.IsDigit(c)) && dso.CdDistId == officeId && dso.DtTerm == null
                               orderby cse.NbrDl, cse.DtRcpt, cse.CdRsn
                               select new
                               {
                                   cse.CdStatusRec,
                                   cse.CdStatusRec2,
                                   cse.NbrDl,
                                   cse.CdCase,
                                   cse.CdRsn,
                                   cse.DtRcpt,
                                   dso.CdOffAbbr,
                                   per.NmeFrstPrsn,
                                   per.NmeSurnmePrsn,
                                   cse.CdHrngTyp
                               }).AsQueryable();

                //results.OrderBy(o => o.NbrDl).ThenBy(o => o.DtRcpt).ThenBy(o => o.CdRsn).ToList();

                foreach (var r in results)
                {
                    UnscheduledCases.results.Add(
                    new UnScheduledCaseDTO()
                    {
                        CD_STATUS_REC = BusinessFunctions.GetCaseStatus(r.CdStatusRec, r.CdStatusRec2),
                        DT_RCPT = r.DtRcpt,
                        NBR_DL = r.NbrDl,
                        CD_CASE = r.CdCase,
                        CD_RSN = r.CdRsn,
                        CD_FLD_DSO_ALPHA = r.CdOffAbbr,
                        PersonFirstName = r.NmeFrstPrsn,
                        PersonLastName = r.NmeSurnmePrsn,
                        CD_HRNG_TYP = r.CdHrngTyp
                    });
                }
            }
            return UnscheduledCases;
        }
       
        public CaseContactsDTO GetCaseContacts(string caseNumber)
        {
            CaseContactsDTO CaseContacts = new CaseContactsDTO();

            CaseContacts.results = new List<CaseContactDTO>();

            if (String.IsNullOrEmpty(caseNumber))
            {
                return CaseContacts;
            }

            var results = (from cnt in _context.Contact.AsNoTracking()
                           join emp in _context.Employee.AsNoTracking() on cnt.CdEmpId equals emp.CdEmpId
                           join off in _context.Dsoffice.AsNoTracking() on cnt.CdOffId equals off.CdOffId
                           where cnt.CdCase == caseNumber && Convert.ToInt16(cnt.CdStatus2) == 3 && off.DtTerm == null
                           select new
                           {
                               cnt.DtCntctStrtTim,
                               cnt.DtCntctEndTim,
                               off.NmeOff,
                               emp.NmeFrstPrsn,
                               emp.NmeSurnmePrsn,
                               cnt.DtSchedTrans,
                               cnt.CdStatus,
                               cnt.CdStatus2,
                               cnt.NbrRoom
                           }).AsQueryable();


            foreach (var r in results)
            {
                CaseContacts.results.Add(
                new CaseContactDTO()
                {
                    SCHEDBY_NME_FRST_PRSN = r.NmeFrstPrsn,
                    SCHEDBY_NME_SRNME_PRSN = r.NmeSurnmePrsn,
                    dt_cntct_strt_tim = Convert.ToString(r.DtCntctStrtTim),
                    dt_cntct_end_tim = Convert.ToString(r.DtCntctEndTim),
                    Nme_Off = r.NmeOff,
                    DT_SCHED_TRANS = Convert.ToString(r.DtSchedTrans),
                    Status = BusinessFunctions.GetCaseStatusText(r.CdStatus, r.CdStatus2),
                    ROOM = "Rm: " + r.NbrRoom
                });
            }

            return CaseContacts;
        }
        public EmployeeContactsDTO GetCaseEmployeeContacts(string caseNumber)
        {
            EmployeeContactsDTO EmployeeContacts = new EmployeeContactsDTO();

            EmployeeContacts.results = new List<EmployeeContactDTO>();

            if (String.IsNullOrEmpty(caseNumber))
            {
                return EmployeeContacts;
            }
            var results = (from cnt in _context.Contact.AsNoTracking()
                           join emp in _context.Employee.AsNoTracking() on cnt.CdUpdtTechId equals emp.CdEmpId
                           where cnt.CdCase == caseNumber && Convert.ToInt16(cnt.CdStatus2) == 3   
                           select new
                           {
                               emp.NmeFrstPrsn,
                               emp.NmeSurnmePrsn
                           }).AsQueryable();


            foreach (var r in results)
            {
                EmployeeContacts.results.Add(
                new EmployeeContactDTO
                {
                    NME_FRST_PRSN = r.NmeFrstPrsn,
                    NME_SURNME_PRSN = r.NmeSurnmePrsn
                });
            }

            return EmployeeContacts;
        }
        public CaseRescheduleListDTO GetCaseReschedules(string caseNumber)
        {
            CaseRescheduleListDTO reschedules = new CaseRescheduleListDTO();

            reschedules.results = new List<CaseRescheduleDTO>();

            if (String.IsNullOrEmpty(caseNumber))
            {
                return reschedules;
            }

            var results = _context.LoadStoredProc("SelReschedList")
                             .WithSqlParam("Case", caseNumber)
                             .ExecuteStoredProc<CaseRescheduleDTO>();

            foreach (var r in results)
            {
                reschedules.results.Add(
                new CaseRescheduleDTO
                {
                    DT_CNTCT_STRT_TIM = r.DT_CNTCT_STRT_TIM,
                    CD_OFF_ABBR = r.CD_OFF_ABBR,
                    TXT_COMMENT = r.TXT_COMMENT,
                    HO_NME_FRST_PRSN = r.HO_NME_FRST_PRSN,
                    HO_NME_SURNME_PRSN = r.HO_NME_SURNME_PRSN,
                    SCHEDBY_NME_FRST_PRSN = r.SCHEDBY_NME_FRST_PRSN,
                    SCHEDBY_NME_SRNME_PRSN = r.SCHEDBY_NME_SRNME_PRSN,
                    AUTHORIZED_NME_FRST_PRSN = r.AUTHORIZED_NME_FRST_PRSN,
                    AUTHORIZED_NME_SRNME_PRSN = r.AUTHORIZED_NME_SRNME_PRSN
                });
            }


            return reschedules;
        }
        public CaseCoverSheetDTO GetCaseCoverSheetInfo(string casenumber)
        {
            CaseCoverSheetDTO coversheet = new CaseCoverSheetDTO();

            var results = (from c in _context.Dsrcase.AsNoTracking()
                           join p in _context.Person.AsNoTracking() on c.NbrDl equals p.NbrDl
                           where c.CdCase == casenumber 
                           select new
                           {
                               p.NbrDl,
                               p.DtBirthPrsn,
                               p.NmeSurnmePrsn,
                               p.NbrPhone
                           }).SingleOrDefault();
            coversheet.DLNumber = results.NbrDl;
            coversheet.BirthDate = Convert.ToDateTime(results.DtBirthPrsn);
            coversheet.LastName = results.NmeSurnmePrsn;
            coversheet.PhoneNumber = results.NbrPhone;

            CoverSheetOIPPersonListDTO oippersons = new CoverSheetOIPPersonListDTO();
            oippersons.results = new List<CoverSheetOIPPersonDTO>();

            var oip = (from co in _context.Caseoip.AsNoTracking()
                       join op in _context.Oippersn.AsNoTracking() on co.Oipid equals op.Oipid
                       where co.CdCase == casenumber
                       select new
                       {
                           op.CdPrtyTyp,
                           op.NbrPhone,
                           op.NmeFrstPrsn,
                           op.NmeSurnmePrsn,
                           op.NmeAgency,
                           op.AddrLn1,
                           op.CdCity,
                           op.CdState,
                           op.CdZip
                       }).AsQueryable();

            foreach (var r in oip)
            {
                oippersons.results.Add(
                    new CoverSheetOIPPersonDTO        
                    {
                        OIP_CD_PRTY_TYP = r.CdPrtyTyp,
                        OIP_NBR_PHONE = r.NbrPhone,
                        OIP_NME_FRST_PRSN = r.NmeFrstPrsn,
                        OIP_NME_SURNME_PRSN = r.NmeSurnmePrsn,
                        OIP_ADDR_LN1 = r.AddrLn1,
                        OIP_CITY = r.CdCity,
                        OIP_STATE = r.CdState,
                        OIP_ZIP = r.CdZip
                     });
            }
            coversheet.OIPPersons = oippersons;

            return coversheet;
        }

    }

}



