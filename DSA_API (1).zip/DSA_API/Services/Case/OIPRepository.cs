﻿using DSA_API.Entities;
using DSA_API.Models.Customer;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Services
{
    public class OIPRepository : IOIPRepository
    {
        private DSAContext _context;
        public OIPRepository(DSAContext context)
        {
            _context = context;
        }
        public IEnumerable<OIPDTO> OIPPersonSearchByType(OIPDTO oipdto, string caseNumber)
        {
            string AreaCode = "";
            List<OIPDTO> finalList = new List<OIPDTO>();

            if (!String.IsNullOrEmpty(oipdto.NBR_PHONE))
            {
                AreaCode = oipdto.NBR_PHONE.Substring(0, 3).ToString();
            }

            try
            {
                //  Get's list of OIPID's assigned to case
                var minusQuery = (from c in _context.Caseoip.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();

                //  Get's List of 
                var query = (from o in _context.Oippersn.AsNoTracking()
                                where o.CdPrtyTyp == oipdto.CD_PRTY_TYP && !o.DtTerm.HasValue
                                && (
                                    (
                                    (String.IsNullOrEmpty(oipdto.NME_FRST_PRSN) || o.NmeFrstPrsn.StartsWith(oipdto.NME_FRST_PRSN))
                                    && (String.IsNullOrEmpty(oipdto.NME_SURNME_PRSN) || o.NmeSurnmePrsn.StartsWith(oipdto.NME_SURNME_PRSN))
                                    )
                                    && (String.IsNullOrEmpty(oipdto.NBR_PHONE) || (
                                        (o.NbrPhone.Substring(0, 3) == AreaCode && o.NbrPhone != "")
                                        || (o.NbrCellPhone.Substring(0, 3) == AreaCode && o.NbrCellPhone != "")
                                        || (o.NbrFax.Substring(0, 3) == AreaCode && o.NbrFax != "")
                                    )
                                    )
                                )

                                select new OIPDTO()
                                {
                                    OIPID = o.Oipid,
                                    CD_PRTY_TYP = o.CdPrtyTyp,
                                    NME_FRST_PRSN = o.NmeFrstPrsn,
                                    NME_SURNME_PRSN = o.NmeSurnmePrsn,
                                    NBR_PHONE = o.NbrPhone,
                                    NBR_CELL_PHONE = o.NbrCellPhone,
                                    NBR_FAX = o.NbrFax,
                                    ADDR_LN1 = o.AddrLn1,
                                    CD_CITY = o.CdCity,
                                    CD_STATE = o.CdState,
                                    CD_ZIP = o.CdZip,
                                    NME_AGENCY = o.NmeAgency
                                }).Distinct().ToList();

                for (int i = 0; i < query.Count; i++)
                {
                    if (!minusQuery.Contains(query[i].OIPID))
                    {
                        finalList.Add(query[i]);
                    }
                }

                //foreach (OIPDTO dto in finalList)
                //{
                //    dto.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = dto.OIPID, type = dto.CD_PRTY_TYP });
                //    dto.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = dto.OIPID, casenumber = caseNumber, type = dto.CD_PRTY_TYP });
                //}
                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }
        }


        public IEnumerable<OIPDTO> LawEnforcementAgencySearch(OIPDTO oipdto, string caseNumber)
        {
            List<OIPDTO> finalList = new List<OIPDTO>();

            try
            {
                var minusQuery = (from c in _context.Caseagny.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();


                var agencies = (from a in _context.Agency
                                where a.CdPrtyTyp == oipdto.CD_PRTY_TYP
                                && a.NmeAgency.Contains(oipdto.NME_AGENCY)
                                && !a.DtTerm.HasValue
                                select new OIPDTO()
                                {
                                    OIPID = a.Oipid,
                                    CD_PRTY_TYP = a.CdPrtyTyp,
                                    NBR_PHONE = a.NbrPhone,
                                    ADDR_LN1 = a.AddrLn1,
                                    CD_CITY = a.CdCity,
                                    CD_STATE = a.CdState,
                                    CD_ZIP = a.CdZip,
                                    NME_AGENCY = a.NmeAgency
                                }).Distinct().ToList();

                for (int i = 0; i < agencies.Count; i++)
                {
                    if (!minusQuery.Contains(agencies[i].OIPID))
                    {
                        finalList.Add(agencies[i]);
                    }
                }

                //foreach (OIPDTO dto in finalList)
                //{
                //    dto.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = dto.OIPID, type = dto.CD_PRTY_TYP });
                //    dto.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = dto.OIPID, casenumber = caseNumber, type = dto.CD_PRTY_TYP });
                //}
                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }

        }


        public IEnumerable<OIPDTO> InterpreterAgencySearch(OIPDTO oipdto, string caseNumber)
        {
            List<OIPDTO> finalList = new List<OIPDTO>();

            try
            {
                var minusQuery = (from c in _context.Caseagny.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();

                var agencies = (from a in _context.Agency
                                join i in _context.Interpre on a.Oipid equals i.Oipid
                                where a.CdPrtyTyp == oipdto.CD_PRTY_TYP
                                && i.CdLanguage == oipdto.CD_LANGUAGE
                                && !a.DtTerm.HasValue
                                select new OIPDTO()
                                {
                                    OIPID = a.Oipid,
                                    CD_PRTY_TYP = a.CdPrtyTyp,
                                    NBR_PHONE = a.NbrPhone,
                                    ADDR_LN1 = a.AddrLn1,
                                    CD_CITY = a.CdCity,
                                    CD_STATE = a.CdState,
                                    CD_ZIP = a.CdZip,
                                    NME_AGENCY = a.NmeAgency
                                }).Distinct().ToList();

                for (int i = 0; i < agencies.Count; i++)
                {
                    if (!minusQuery.Contains(agencies[i].OIPID))
                    {
                        finalList.Add(agencies[i]);
                    }
                }

                //foreach (OIPDTO dto in finalList)
                //{
                //    dto.resourceURI = WebApiLinkHelper.RouteUrl("OIPID", new { oipid = dto.OIPID, type = dto.CD_PRTY_TYP });
                //    dto.caseAssignURI = WebApiLinkHelper.RouteUrl("OIPCaseAssign", new { oipid = dto.OIPID, casenumber = caseNumber, type = dto.CD_PRTY_TYP });
                //}
                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }

        }


        public IEnumerable<OIPDTO> InterpreterOIPPersonSearch(OIPDTO oipdto, string caseNumber)
        {
            List<OIPDTO> finalList = new List<OIPDTO>();

            try
            {
                //  Get's list of OIPID's assigned to case
                var minusQuery = (from c in _context.Caseoip.AsNoTracking()
                                    where c.CdCase == caseNumber
                                    select c.Oipid).Distinct().ToArray();

                var OIPS = (from p in _context.Oippersn
                            join i in _context.Interpre on p.Oipid equals i.Oipid
                            where p.CdPrtyTyp == oipdto.CD_PRTY_TYP
                            && i.CdLanguage == oipdto.CD_LANGUAGE
                            && !i.DtTerm.HasValue

                            select new OIPDTO()
                            {
                                OIPID = p.Oipid,
                                CD_PRTY_TYP = p.CdPrtyTyp,
                                NME_FRST_PRSN = p.NmeFrstPrsn,
                                NME_SURNME_PRSN = p.NmeSurnmePrsn,
                                NBR_PHONE = p.NbrPhone,
                                NBR_CELL_PHONE = p.NbrCellPhone,
                                NBR_FAX = p.NbrFax,
                                ADDR_LN1 = p.AddrLn1,
                                CD_CITY = p.CdCity,
                                CD_STATE = p.CdState,
                                CD_ZIP = p.CdZip,
                                NME_AGENCY = p.NmeAgency
                            }).Distinct().ToList();

                for (int i = 0; i < OIPS.Count; i++)
                {
                    if (!minusQuery.Contains(OIPS[i].OIPID))
                    {
                        finalList.Add(OIPS[i]);
                    }
                }

                return finalList;
                
            }
            catch (Exception e)
            {
                return new List<OIPDTO>();
            }
        }


        //
        //  Get's All OIP Types into Select List (UI Utility)
        //
        public IEnumerable<SelectListItem> getOIPTypes()
        {
           
            var types = (from o in _context.Oiptype
                            where !o.DtTerm.HasValue
                            orderby o.CdPrtyTyp ascending
                            select new SelectListItem()
                            {
                                Text = o.CdPrtyTyp + " - " + o.DescPrtyTyp,
                                Value = o.CdPrtyTyp.ToString()
                            }).ToList();
            types.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return types;
            
        }


        //
        //  Get's All Interpreter Languages into Select List (UI Utility)
        //
        public IEnumerable<SelectListItem> getLanguages()
        {
            var types = (from l in _context.Language
                            where !l.DtTerm.HasValue
                            orderby l.DescLanguage ascending
                            select new SelectListItem()
                            {
                                Text = l.DescLanguage,
                                Value = l.CdLanguage.ToString()
                            }).ToList();
            types.Insert(0, new SelectListItem()
            {
                Text = "Select Option",
                Value = ""
            });
            return types;
        }

    }
}
