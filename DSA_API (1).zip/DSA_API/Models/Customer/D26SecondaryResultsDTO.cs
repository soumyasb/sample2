﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class D26SecondaryResultsDTO
    {
        public string AccidentMessage { get; set; }
        public List<AccidentDTO> Accidents { get; set; }
        public string OwnerResponsbilityMessage { get; set; }
        public List<OwnerResponsibilityDTO> Responsibilities { get; set; }
        public List<LicenseRestrictionsDTO> Restrictions { get; set; }

    }
}
