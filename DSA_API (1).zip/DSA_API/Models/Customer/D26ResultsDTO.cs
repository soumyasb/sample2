﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Customer
{
    public class D26ResultsDTO
    {
        private string _classLicense1;
        private string _classLicense2;

        public string dlNumber { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string middleName { get; set; }
        public string suffix { get; set; }

        public string BirthDate { get; set; }
        public string flgAddr { get; set; }
        public string MAddrDate { get; set; }
        public string MAddr { get; set; }
        public string MCity { get; set; }
        public string MState { get; set; }
        public string ZIP { get; set; }
        public string RAddr { get; set; }
        public string RCity { get; set; }
        public string RState { get; set; }
        public string OAddrDate { get; set; }
        public string OAddr { get; set; }
        public string OCity { get; set; }
        public string OState { get; set; }
        public string SSN { get; set; }
    //    public string Class1 { get; set; }
    //    public string Class2 { get; set; }
       
        public string Class1
        {
            get
            {
                return DetermineLicenseClass(_classLicense1);
            }

            set
            {
                _classLicense1 = value;
            }
        }
        public string Class2
        {
            get
            {
                return DetermineLicenseClass(_classLicense2);
            }

            set
            {
                _classLicense2 = value;
            }
        }
        public string AccidentMessage { get; set; }
        // public List<string> Accidents { get; set; }
        public ICollection<AccidentDTO> Accidents { get; set; }
             = new List<AccidentDTO>();
        public string OwnerResponsbilityMessage { get; set; }
        public ICollection<OwnerResponsibilityDTO> Responsibilities { get; set; }
                 = new List<OwnerResponsibilityDTO>();
        public ICollection<LicenseRestrictionsDTO> Restrictions { get; set; }
           = new List<LicenseRestrictionsDTO>();
        public string DoubledDLNumber { get; set; }
        public int DoubledDLCounter { get; set; }
        public string Message { get; set; }
        public string ErrorMessage { get; set; }
        public string ValidationMessage { get; set; }
        public bool ValidationOK { get; set; }
        private string DetermineLicenseClass(string licclass)
        {
            string output = "";
            switch (licclass)
            {
                case "A":
                case "D":
                    output = "A";
                    break;
                case "B":
                case "E":
                    output = "B";
                    break;
                case "C":
                case "F":
                    output = "C";
                    break;
                case "N":
                    output = "1";
                    break;
                case "P":
                    output = "2";
                    break;
                case "R":
                    output = "3";
                    break;
                case "S":
                    output = "4";
                    break;
                case "U":
                    output = "M1";
                    break;
                case "Y":
                    output = "M2";
                    break;
                default:
                    output = licclass;
                    break;
            }
            return output;
        }
    }
}
