﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Home
{
    public class SuspenseDTO
    {
        [Display(Name = "DL#")]
        public string NBR_DL { get; set; }
        [Display(Name = "Case#")]
        public string CD_CASE { get; set; }
        [Display(Name = "Subject Name")]
        public string NME_SURNME_PRSN { get; set; }
        [Display(Name = "Reason")]
        public string CD_RSN { get; set; }
        [Display(Name = "Due Date")]
        public DateTime DT_SUSP { get; set; }
        [Display(Name = "Text")]
        public string CD_SUSP_RSN { get; set; }
        [Display(Name = "Description")]
        public string DESC_SUSP_RSN { get; set; }
    }
}
