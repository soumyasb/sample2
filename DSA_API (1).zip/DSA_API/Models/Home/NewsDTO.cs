﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.Home
{
    public class NewsDTO
    {
        public string AuthorName { get; set; }
        public string Priority { get; set; }
        public string Subject { get; set; }
        public string NewsText { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime CreateDate { get; set; }

    }
}
