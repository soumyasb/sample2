﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CaseCoverSheetDTO
    {
        private string _phoneNumber;
      
        public string DLNumber { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public string PhoneNumber
        {
            set
            {
                _phoneNumber = String.IsNullOrEmpty(value) ? value : value.Trim();
            }
            get
            {
                return String.IsNullOrEmpty(_phoneNumber) ? "" : String.Format("{0:(###) ###-####}", double.Parse(_phoneNumber));
            }
        }
        public CoverSheetOIPPersonListDTO OIPPersons { get; set; }
        public List<CoverSheetOIPAgencyDTO> OIPAgencies { get; set; }
        public List<CoverSheetContactsDTO> Contacts { get; set; }
        public List<CoverSheetCommentsDTO> Comments { get; set; }

    }
}
