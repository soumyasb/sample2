﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CaseRescheduleDTO
    {
        public DateTime DT_CNTCT_STRT_TIM { get; set; }
        public string CD_OFF_ABBR { get; set; }
        public string TXT_COMMENT { get; set; }
        public string HO_NME_FRST_PRSN { get; set; }
        public string HO_NME_SURNME_PRSN { get; set; }
        public string SCHEDBY_NME_FRST_PRSN { get; set; }
        public string SCHEDBY_NME_SRNME_PRSN { get; set; }
        public string AUTHORIZED_NME_FRST_PRSN { get; set; }
        public string AUTHORIZED_NME_SRNME_PRSN { get; set; }
    }
}
