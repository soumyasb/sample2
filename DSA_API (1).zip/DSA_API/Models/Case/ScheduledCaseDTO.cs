﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class ScheduledCaseDTO
    {
        public string CD_STATUS_REC { get; set; }
        public DateTime dt_Cntct_Strt_Tim { get; set; }
        public string NBR_DL { get; set; }
        public string CD_CASE { get; set; }
        public string CD_RSN { get; set; }
        public string cd_Off_Abbr { get; set; }
        public string PersonFirstName { get; set; }
        public string PersonLastName { get; set; }
        public string EmployeeFirstName { get; set; }
        public string EmployeeLastName { get; set; }
        public string CD_HRNG_TYP { get; set; }
    }
}
