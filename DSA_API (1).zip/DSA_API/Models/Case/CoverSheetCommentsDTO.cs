﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CoverSheetCommentsDTO
    {
        public string DT_UPDT_TRANS { get; set; }
        public string CD_UPDT_TECH_ID { get; set; }
        public string CD_FLD_DSO_ALPHA { get; set; }
        public string TXT_COMMENT { get; set; }
    }
}
