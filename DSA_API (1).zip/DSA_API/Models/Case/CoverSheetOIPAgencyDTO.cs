﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CoverSheetOIPAgencyDTO
    {
        private string _oipPhoneNumber;
        public string AGENCY_CD_PRTY_TYP { get; set; }
        public string AGENCY_NBR_PHONE
        {
            set
            {
                _oipPhoneNumber = String.IsNullOrEmpty(value) ? value : value.Trim();
            }
            get
            {
                return String.IsNullOrEmpty(_oipPhoneNumber) ? "" : String.Format("{0:(###) ###-####}", double.Parse(_oipPhoneNumber));
            }
        }
        public string AGENCY_NME_FRST_PRSN { get; set; }
        public string AGENCY_NME_SURNME_PRSN { get; set; }
        public string AGENCY_ADDR_LN1 { get; set; }
        public string AGENCY_CITY { get; set; }
        public string AGENCY_STATE { get; set; }
        public string AGENCY_ZIP { get; set; }
    }
}
