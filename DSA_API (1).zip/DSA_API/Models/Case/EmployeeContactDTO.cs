﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class EmployeeContactDTO
    {
        public string NME_FRST_PRSN { get; set; }
        public string NME_SURNME_PRSN { get; set; }
    }
}
