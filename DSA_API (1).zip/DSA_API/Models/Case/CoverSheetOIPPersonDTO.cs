﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models 
{
    public class CoverSheetOIPPersonDTO
    {
        private string _oipPhoneNumber;
        public string OIP_CD_PRTY_TYP { get; set; }
        public string OIP_NBR_PHONE
        {
            set
            {
                _oipPhoneNumber = String.IsNullOrEmpty(value) ? value : value.Trim();
            }
            get
            {
                return String.IsNullOrEmpty(_oipPhoneNumber) ? "" : String.Format("{0:(###) ###-####}", double.Parse(_oipPhoneNumber));
            }
        }
        public string OIP_NME_FRST_PRSN { get; set; }
        public string OIP_NME_SURNME_PRSN { get; set; }
        public string OIP_ADDR_LN1 { get; set; }
        public string OIP_CITY { get; set; }
        public string OIP_STATE { get; set; }
        public string OIP_ZIP { get; set; }
    }
}
