﻿using DSA_API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.User
{
    public class UserDTO
    {
        private string _empthreedigit;
        public int EmployeeID { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public string UserName { get; set; }
        public string RequestorCode { set; get; }
        public string NetName { get; set; }
        public string TAMe { set; get; }
        public string RACFID { set; get; }
        public string OfficeID { set; get; }
        public string AssignedOfficeName { set; get; }
        public string EmployeeClass { set; get; }
        public string EmployeeType { set; get; }
        public string EmployeeThreeDigit
        {
            get
            {
                return this.UserName.Substring(2, 3).ToUpper();
            }
        }
        public List<string> Roles { set; get; }
        public Dsoffice Office { set; get; }
    }
}
