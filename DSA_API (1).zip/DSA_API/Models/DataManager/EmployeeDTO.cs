﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DSA_API.Models.DataManager
{
    public class EmployeeDTO
    {

        public int Empid { get; set; }

        [Required]
        [Display(Name = "User ID")]
        public string UserID { get; set; }

        [Required]
        [StringLength(3, ErrorMessage = "Employee ID must be 3 characters.", MinimumLength = 3)]
        [Display(Name = "Employee ID")]
        public string ShortID { get; set; }

        [Required]
        [RegularExpression(@"^\S+[a-zA-Z0-9-_\s]+$", ErrorMessage = "Invalid Name")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [StringLength(1)]
        [Display(Name = "Middle Initial")]
        public string MiddleName { get; set; }

        [Required]
        [RegularExpression(@"^\S+[a-zA-Z0-9-_\s]+$", ErrorMessage = "Invalid Name")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [StringLength(5)]
        [Display(Name = "Suffix")]
        public string NameSuffix { get; set; }

        [Required]
        [RegularExpression(@"\d{3}", ErrorMessage = "Must be three cheracters")] //three digits
        [Display(Name = "Office ID")]
        public string OfficeID { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Last Updated Date")]
        public DateTime? DateUpdated { get; set; }

        [Display(Name = "Last Updated By")]
        public string LastUpdBy { get; set; }

        [Required]
        [Display(Name = "Classification")]
        public string Classification { get; set; }

        [Required]
        [Display(Name = "Class")]
        public string EmployeeClass { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "End Access Effective Date")]
        public DateTime? DateTerminated { get; set; }

        [Display(Name = "Loan")]
        public bool LoanFlag { get; set; }

        [Display(Name = "Transfer")]
        public bool TransferFlag { get; set; }

        [RegularExpression(@"\d{3}", ErrorMessage = "Office ID must be 3 digits")] //three digits
        [Display(Name = "Transfer Office")]
        public string TransferOffice { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Transfer Date")]
        public DateTime? TransferDate { get; set; }

        [RegularExpression(@"\d{3}")] //three digits
        [Display(Name = "Loan Office")]
        public string LoanOffice { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Loan Start Date")]
        public DateTime? LoanStart { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Loan End Date")]
        public DateTime? LoanEnd { get; set; }

        public IEnumerable<SelectListItem> OfficeList { get; set; }
        public IEnumerable<SelectListItem> ClassificationList { get; set; }
        public IEnumerable<SelectListItem> ClassList { get; set; }
    }
}
