const homePageReducerDefaultState = {};

const homepagereducer = (state = homePageReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_HOMEPAGE": {
      return { ...state, ...action.data };
    }

    default:
      return state;
  }
};

export default homepagereducer;
