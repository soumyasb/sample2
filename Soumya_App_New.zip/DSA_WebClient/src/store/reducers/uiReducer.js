const uiReducerDefaultState = {
  newsModalVisible: false,
  newsIdx: 0,
  modalVisible: false,
  actionType: "",
  newsItemObj: []
};

const uireducer = (state = uiReducerDefaultState, action) => {
  switch (action.type) {
    case "SET_NEWS_MODAL": {
      return { ...state, newsModalVisible: action.val };
    }
    case "SET_NEWS_IDX": {
      return { ...state, newsIdx: action.idx };
    }
    case "SHOW_MODAL":
    {
      return { ...state, modalVisible: action.val};
    }
    default:
      return state;
  }
};

export default uireducer;
