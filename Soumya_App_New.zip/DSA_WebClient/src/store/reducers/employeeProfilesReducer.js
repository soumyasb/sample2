const employeeProfilesReducerDefaultState = {
};

const employeeProfilesReducer = (state = employeeProfilesReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_EMPPROFILESINITIAL_DATA": {
      return { ...state, employeeProfilesInitialData: action.data };
    }
    case "GET_EMPPROFILES_DATA": {
      return { ...state, employeeProfilesData: action.data };
    }   
    case "GET_CREATEROFILE_DATA":
    {
      return { ...state, createProfileData: action.data };
    }
    default:
      return state;
  }
};

export default employeeProfilesReducer;