import axios from "axios";
import caseDetails from "../../mocks/casedetails.json";
import caseModifyResults from "../../mocks/CaseModifyResults.json";
//COMMON ACTIONS
export const getCaseSearchResults = data => ({
  type: "GET_CASE_SEARCHRESULTS",
  data: data
});

export const searchCases = (seachString) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/Search/"+seachString).then(response => {
      dispatch(getCaseSearchResults(response.data));
    });
  };
};

export const getCustomerDetailsData = data => ({
  type: "GET_CUSTOMERDETAILS",
  data: data
});

export const getCustomerDetails = (dlNumber) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/Customer/"+dlNumber).then(response => {
      dispatch(getCustomerDetailsData(response.data));
    });
   // dispatch(getCustomerDetailsData(customerDetails))
  };
};

export const getScheduledCasesData = data => ({
  type: "GET_SCHEDULEDCASES",
  data: data
});

export const getScheduledCases = (officeId, sort) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/GetScheduledCases?officeid="+officeId+"&sort="+sort).then(response => {
      dispatch(getScheduledCasesData(response.data));
    });
  };
};

export const getUnScheduledCasesData = data => ({
  type: "GET_UNSCHEDULEDCASES",
  data: data
});

export const getUnScheduledCases = (officeId, sort) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/GetUnScheduledCases?officeid="+officeId+"&sort="+sort).then(response => {
      dispatch(getUnScheduledCasesData(response.data));
    });
  };
};

export const getCustomerD26InfoData = data => ({
  type: "GET_CUSTOMERD26INFO",
  data: data
});

export const getCustomerD26Info = (dlNumber) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/Customer/GetCustomerD26Info/"+dlNumber).then(response => {
      dispatch(getCustomerD26InfoData(response.data));
    });
  };
};

export const getCaseDetailsData = data => ({
  type: "GET_CASEDETAILS",
  data: data
});

export const getCaseDetails = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/"+caseNumber).then(response => {
      dispatch(getCaseDetailsData(response.data));
    });
  };
};

export const getClosedCaseDetailData = data => ({
  type: "GET_CLOSEDCASEDETAILS",
  data: data
});

export const getClosedCaseDetail = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/ GetClosedCaseDetail?caseNumber="+caseNumber).then(response => {
      dispatch(getClosedCaseDetailData(response.data));
    });
  };
};


export const getHearingTypesData = data => ({
  type: "GET_HEARINGTYPES",
  data: data
});

export const getHearingTypes = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetHearingTypes").then(response => {
      dispatch(getHearingTypesData(response.data));
    });
  };
};

export const getCaseReasonsData = data => ({
  type: "GET_CASEREASONS",
  data: data
});

export const getCaseReasons = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetCaseReasons").then(response => {
      dispatch(getCaseReasonsData(response.data));
    });
  };
};

export const getCaseReferralsData = data => ({
  type: "GET_CASEREFERRALS",
  data: data
});

export const getCaseReferrals = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/GetCaseReferrals").then(response => {
      dispatch(getCaseReferralsData(response.data));
    });
  };
};

export const getCaseCertificationsData = data => ({
  type: "GET_CASECERTIFICATIONS",
  data: data
});

export const getCaseCertifications = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetCaseCertifications").then(response => {
      dispatch(getCaseCertificationsData(response.data));
    });
  };
};

export const getOIPTypes = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetOIPTypes").then(response => {
      return {
        type: "GET_OIPTYPES",
        data: response.data
      }
    });
  };
};

export const getOIPLanguages = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/case/LookupTables/ GetOIPLanguages").then(response => {
      return {
        type: "GET_OIPLANGUAGES",
        data: response.data
      }
    });
  };
};

export const getCaseCoverSheet = (caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/GetCaseCoverSheet?caseNumber="+caseNumber).then(response => {
      return {
        type: "GET_CASECOVERSHEET",
        data: response.data
      }
    });
  };
};

export const getModifyCaseData = data => ({
  type: "GET_MODIFYCASEDATA",
  data: data
});

export const modifyCaseDetail = (caseDetailObj) => {
  return dispatch => {
    axios.post("http://localhost:32610/api/Case/ModifyCase/"+caseDetailObj.CaseNumber,caseDetailObj).then(response => {
      dispatch(getModifyCaseData(response.data));
  }).catch((error) => {
    console.log(error);
  });
  //dispatch(getModifyCaseData(caseModifyResults));
};
};

export const getCreateCaseDetailsData = data => ({
  type: "GET_CREATECASEDATA",
  data: data
});

export const getCreateCaseDetails = (customerDetail) => {
  return dispatch => {
    axios.post("http://localhost:32610/api/Case/CreateNewCase", customerDetail).then(response => {
      dispatch(getCreateCaseDetailsData(response.data));
    });
  };
};

export const getCaseAddData = data => ({
  type: "GET_CASEADDDATA",
  data: data
});

export const addCase = (caseDetailObj) => {
  return dispatch => {
    axios.post("http://localhost:32610/api/Case/AddCase/", caseDetailObj).then(response => {
      dispatch(getCaseAddData(response.data));
  }).catch((error) => {
    console.log(error);
  });
};
};

export const getH6InfoData = data => ({
  type: "GET_H6INFO",
  data: data
});

export const getH6Info = (dlNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Inquiry/geth6?dlNumber="+dlNumber).then(response => {
      dispatch(getH6InfoData(response.data));
    });
  };
};

export const getCaseScheduleDetailData = data => ({
  type: "GET_CASESCHEDULEDATA",
  data: data
});

export const getCaseScheduleDetail = (dlNumber, caseNumber) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/Case/GetCaseScheduleDetail?dlNumber="+dlNumber+"&caseNumber="+caseNumber).then(response => {
      dispatch(getCaseScheduleDetailData(response.data));
    });
  };
};