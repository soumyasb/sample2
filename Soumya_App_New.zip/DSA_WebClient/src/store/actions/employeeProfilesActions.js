import axios from "axios";

// EMPLOYEE PROFILES ACTIONS

export const getEmployeeProfilesInitialPageData = data => ({
  type: "GET_EMPPROFILESINITIAL_DATA",
  data: data
});

export const getEmployeeProfilesInitialPage = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeProfile/IntitialPage").then(response => {
      dispatch(getEmployeeProfilesInitialPageData(response.data));
    });
  };
};

export const getEmployeeProfilesbyIdData = data => ({
    type: "GET_EMPPROFILES_DATA",
    data: data
  });
  
  export const getEmployeeProfilesbyId = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/GetAllProfilesForEmployee/"+empid).then(response => {
        dispatch(getEmployeeProfilesbyIdData(response.data));
      });
    };
  };

  export const getCreateProfileData = data => ({
    type: "GET_CREATEROFILE_DATA",
    data: data
  });
  
  export const getCreateProfile= (empid, profid) => {
      debugger;
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
        dispatch(getCreateProfileData(response.data));
      });
    };
  };

  export const saveEmployeeProfile = (employeeProfDataObj) => {
      debugger;
    return dispatch => {
      axios.post("http://localhost:32610/api/EmployeeProfile/CreateEmployeeProfile",employeeProfDataObj).then(response => {
        if(response.status === 200)
        {
          console.log(response);
        }
    }).catch((error) => {
      console.log(error);
    });

  };
  };

//   export const getEmployeeProfileData = data => ({
//     type: "GET_CREATEROFILE_DATA",
//     data: data
//   });
  
//   export const getEmployeeProfile= (profid) => {
//       debugger;
//     return dispatch => {
//       axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
//         dispatch(getEmployeeProfileData(response.data));
//       });
//     };
//   };