import React from "react";
import { Switch, Route } from 'react-router-dom'

import HomePage from "./contents/home/homepage";
import NewsPage from "./contents/admin/NewsItem";
import Search from "./contents/case/Search";
import CustomerDetails from "./contents/case/CustomerDetails";
import CaseDetails from "./contents/case/CaseDetails";
import ScheduledCases from "./contents/case/ScheduledCases";
import UnScheduledCases from "./contents/case/UnScheduledCases";

const content = () => (
  <div className="contentlayout">
    <Switch>
      <Route exact path="/" component={HomePage} />
      <Route exact path="/news" component={NewsPage} />
      {/* <Route path="/search" component={Search} /> */}
      <Route path="/search/searchText/:searchText" component={Search} />
      <Route path="/customerDetails/dlNumber/:dlNumber" component={CustomerDetails} />
      <Route path="/caseDetails/CaseNumber/:CaseNumber" component={CaseDetails} />
      <Route path="/scheduledCases" component={ScheduledCases} /> 
      <Route path="/unScheduledCases" component={UnScheduledCases} /> 


      {/* <Route path='/search' 
          render={ props => <Search {...props} />}
        /> */}
    </Switch>
  </div>
);

export default content;














      
