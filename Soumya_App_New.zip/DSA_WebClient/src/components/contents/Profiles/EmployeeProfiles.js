import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, List, Spin, Modal, Radio, Input, Tooltip, Button, Select, Layout, Menu, Icon, Badge, DatePicker } from 'antd';

const {Content,Sider } = Layout;

class EmployeeProfiles extends Component {
    constructor(props) {
        super(props);
        this.state={
        
        };    
    }
    render() {
        return (     <ScrollPanel
            style={{
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0,0,0,0)"
            }}>
            <Row type="flex" justify="center">
            <Col span = {22}><div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}>
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>Employee Profiles</span>
        </div></div>     </Col></Row>
        <div></div></ScrollPanel>);
}
}
const mapStateToProps = state => {
    return {
       
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
        
      
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeProfiles);
