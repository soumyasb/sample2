import React, { Component } from 'react';
import { getCaseDetails, getHearingTypes, getCaseReasons, getCaseReferrals, getCaseCertifications, getCustomerD26Info, modifyCaseDetail
, getH6Info, getCaseComments } from "../../../store/actions/caseActions";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { List, Spin, Modal, Card, Radio, Input, Button, Select, Layout, Menu, Icon } from 'antd';
import styles from "../../../Cases.css"


const {Content,Sider } = Layout;
const RadioGroup = Radio.Group;
const { TextArea } = Input;
const { Option } = Select;
const radioStyle = {
  display: 'block',
  height: '30px',
  lineHeight: '30px',
};
const getDropdownList = (listObj, selectedValue) =>   
{  
    let list = [];   

     listObj.map(item =>
{
  if(item.Value === selectedValue)
  {
    list.push(<option key={item.Value} value={item.Value} selected>{item.Text}</option>)
  }
  else
  {
  list.push(<option key={item.Value} value={item.Value}>{item.Text}</option>)
  }

});
    
    return list;     
   }


   const getAccidentsList = (accidentsObj) =>   
{  
  debugger;
    let list = [];   

    accidentsObj.Accidents.map(item =>
{

  list.push(<Radio style={radioStyle} value={item.CaseNumber}><span style={{paddingLeft:"5px"}}>{item.CaseNumber}</span><span style={{paddingLeft:"25px"}}>{item.Date}</span><span style={{paddingLeft:"25px"}}>{item.City}</span></Radio>)
  }

);
    
    return list;     
   }
const reqRsnCodesForCerts = ["871","875","880","881","882","883","884","885","887","888","889","891","892","894","897","898"];


class CaseDetails extends Component {
    constructor(props) {
        super(props);
        this.state={
          caseNumber: props.match.params.CaseNumber,
            editmode: false,
            caseDetailsObj: props.cases.caseDetailsObj,
            hearingTypes: props.cases.hearingTypesList,
            caseReasons: props.cases.caseReasonsList,
            caseReferrals: props.cases.caseReferralsList,
            caseCertifications: props.cases.caseCertificationsList,
            customerD26Info: props.cases.customerD26Info,
            isRequired: false,
            tabValue: 'CaseDetail',
            caseSchedVisible: false,
            caseComments: props.cases.caseComments
        };
       this.onButtonClick = this.onButtonClick.bind(this);   
       this.handleChange = this.handleChange.bind(this);
       this.handleClick = this.handleClick.bind(this);
       this.openCaseSchedule = this.openCaseSchedule.bind(this);
    }    
    componentDidMount() {
      this.props.getCaseDetails(this.state.caseNumber);
      this.props.getHearingTypes();
      this.props.getCaseReasons();
      this.props.getCaseReferrals();
      this.props.getCaseCertifications();
      this.props.getCaseComments(this.state.caseNumber);
  }

  componentWillReceiveProps(nextProps) {
      debugger;
      if (this.props.cases.caseDetailsObj !== nextProps.cases.caseDetailsObj) {
          if(nextProps.cases.caseDetailsObj !== undefined)
          {
          this.setState({ caseDetailsObj: nextProps.cases.caseDetailsObj});
          this.setState({ hearingType: nextProps.cases.caseDetailsObj.CD_HRNG_TYP});
          this.setState({ caseReason: nextProps.cases.caseDetailsObj.CD_RSN});
          this.setState({ caseReferral: nextProps.cases.caseDetailsObj.CD_REFR_SRCE_TYP});
          this.setState({ caseCertification: nextProps.cases.caseDetailsObj.CD_ENDR});
          this.setState({ hearingTypes: nextProps.cases.hearingTypesList});
          this.setState({ caseReasons: nextProps.cases.caseReasonsList});
          this.setState({ caseReferrals: nextProps.cases.caseReferralsList});
          this.setState({ caseCertifications: nextProps.cases.caseCertificationsList});
          this.setState({ value: nextProps.cases.caseDetailsObj.FRCaseNumber});
            this.props.getCustomerD26Info(nextProps.cases.caseDetailsObj.DLNumber);
          }
      }
      if(this.props.cases.caseComments !== nextProps.cases.caseComments)
      {
        this.setState({caseComments: nextProps.cases.caseComments});
      }

     
      if (this.props.cases.customerD26Info !== nextProps.cases.customerD26Info) {
        this.setState({ customerD26Info: nextProps.cases.customerD26Info});
  }
  if (this.props.cases.h6Info !== nextProps.cases.h6Info) {
    if(nextProps.cases.h6Info !== undefined)
    {
    this.setState({ h6Info: nextProps.cases.h6Info});
    }
}
}
onButtonClick = (e,value) => 
{
if(value === 'Edit')
{
this.setState({editmode: true});
}
if(value === 'Back')
{
  this.props.getCaseDetails(this.state.caseNumber);
}
if(value === 'Cancel')
{
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_HRNG_TYP});
  this.setState({caseReason: this.props.cases.caseDetailsObj.CD_RSN});
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_REFR_SRCE_TYP});
  this.setState({hearingType: this.props.cases.caseDetailsObj.CD_HRNG_TYP});
  this.setState({caseCertification: this.props.cases.caseDetailsObj.CD_ENDR});
  this.setState({editmode: false});
  this.setState({ value: this.props.cases.caseDetailsObj.FRCaseNumber});
}
if(value === 'Save')
{
  debugger;
  const {caseDetailsObj} = this.state;
  caseDetailsObj.CD_HRNG_TYP= this.state.hearingType;
  caseDetailsObj.CD_RSN = this.state.caseReason;
  caseDetailsObj.CD_REFR_SRCE_TYP = this.state.caseReferral;
  caseDetailsObj.CD_ENDR = this.state.caseCertification;
  caseDetailsObj.FRCaseNumber = this.state.value;
   this.state.customerD26Info.Accidents.map(item =>
  {
    if(item.CaseNumber === caseDetailsObj.FRCaseNumber)
    {
      caseDetailsObj.AccidentDate = item.Date;
    }
  })
 this.state.customerD26Info.Accidents.map(item =>
    {
      if(item.CaseNumber === caseDetailsObj.FRCaseNumber)
      {
        caseDetailsObj.AccidentCity =  item.City;
      }
    })
    this.props.modifyCaseDetail(caseDetailsObj);
this.setState({editmode: false});
}
}
onChange = (e) => {
  console.log('radio checked', e.target.value);
  this.setState({
    value: e.target.value,
  });
}
handleClick = (e) => {
  this.setState({
    tabValue: e.key
  })
  if(e.key === 'DadH6')
  {
    this.props.getH6Info(this.state.caseDetailsObj.DLNumber);
  }
}
openCaseSchedule() {
  debugger;
  this.setState({caseSchedVisible: true});
    // this.props.history.push(
    //     {pathname:`/caseSchedule`,
    //   state: { detail:  customerDetailsObj}
    // })
}
handleOk = (e) => {
  console.log(e);
  this.setState({
    caseSchedVisible: false,
  });
}

handleCancel = (e) => {
  console.log(e);
  this.setState({
    caseSchedVisible: false,
  });
}
handleChange = (e,listType) => {
  if(listType === 'HRNG_TYP')
{    
 this.setState({hearingType: e});
}
if(listType === 'CASE_RSN')
{    
 this.setState({caseReason: e});
}
if(listType === 'CASE_RFL')
{    
 this.setState({caseReferral: e});
}
if(listType === 'CASE_CERT')
{    
 this.setState({caseCertification: e});
}
}
    render() {

const {caseDetailsObj} = this.state;
let accidentsList = [];
let h6Info = [];
if(this.state.customerD26Info !== undefined )
{ 
 accidentsList = getAccidentsList(this.state.customerD26Info);
}
let hearingTypesList = [], caseReasonsList = [], caseReferralsList = [], caseCertificationsList = [];
if(this.state.caseDetailsObj!== undefined && this.state.hearingTypes !== undefined )
{ 
  hearingTypesList = getDropdownList(this.state.hearingTypes, this.state.caseDetailsObj.CD_HRNG_TYP);    
}
if(this.state.caseDetailsObj!== undefined && this.state.caseReasons !== undefined)
{ 
  caseReasonsList = getDropdownList(this.state.caseReasons, this.state.caseDetailsObj.CD_RSN);    
}
if(this.state.caseDetailsObj!== undefined && this.state.caseReferrals !== undefined)
{ 
  caseReferralsList = getDropdownList(this.state.caseReferrals, this.state.caseDetailsObj.CD_REFR_SRCE_TYP);    
}
if(this.state.caseDetailsObj!== undefined && this.state.caseCertifications !== undefined)
{ 
  caseCertificationsList = getDropdownList(this.state.caseCertifications, "");    
}
if(this.state.h6Info !== undefined)
{
   h6Info = Object.entries(this.state.h6Info).map(([key,value])=>{
  return (
      <div><b>{key}</b> :<div dangerouslySetInnerHTML={{ __html: value.toString()}}/> </div>
  );
})
}
let data= [];
if(this.state.caseComments !== undefined)
{
data = this.state.caseComments.Comments;
}
        return (   
          <ScrollPanel
          style={{
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(0,0,0,0)"
          }}
      >
       {caseDetailsObj !== undefined ? (
          <div> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
          <div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}><Icon type="idcard"  style={{ fontSize: 32 }}/> 
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>{caseDetailsObj.Customer.LastName},{caseDetailsObj.Customer.FirstName}</span>
            <span style={{paddingLeft: "5%", fontSize: "x-large"}}>DL#: {caseDetailsObj.Customer.DLNumber}</span>
            <span style={{paddingLeft: "5%", fontSize: "x-large"}}>Case#: {caseDetailsObj.CaseNumber}</span>
            </div></div>
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      {/* <Breadcrumb style={{ margin: '16px 0' }}>
        <Breadcrumb.Item>Home</Breadcrumb.Item>
        <Breadcrumb.Item>List</Breadcrumb.Item>
        <Breadcrumb.Item>App</Breadcrumb.Item>
      </Breadcrumb> */}
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['1']}
            style={{ height: '100%' }}
            onClick={e => this.handleClick(e)}
          >
            <Menu.Item key="CaseDetail"> <Icon type="profile" />
              <span>Case Detail</span>
</Menu.Item>
<Menu.Item key="OIP">
<Icon type="team" />
              <span>OIP</span>
</Menu.Item>
<Menu.Item key="Comments"> 
<Icon type="message" />
              <span>Comments</span>
</Menu.Item>
<Menu.Item key="Schedule">
<Icon type="schedule" />
              <span>Schedule</span>
</Menu.Item>
<Menu.Item key="Closure">
<Icon type="book" />
              <span>Closure</span>
</Menu.Item>
<Menu.Item key="Suspense">
<Icon type="pause-circle" />
              <span>Suspense</span>
</Menu.Item>
<Menu.Item key="DadH6">
<Icon type="file-text" />
              <span>DAD H6</span>
</Menu.Item>
          </Menu>
        </Sider>
        <Content style={{height: "600px" }}>
       {this.state.tabValue === 'CaseDetail' ? (<div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
       {this.state.caseDetailsObj.ErrorMessage !== null ?    <div style={{border: "solid", borderColor: "#c9e3fa", height: "200px"}}> 
               <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="exclamation-circle" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>ERROR</span><div dangerouslySetInnerHTML={{ __html: this.state.caseDetailsObj.ErrorMessage}}/><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Back')}>Go Back</Button></div></div>: 
               <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> 
               <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>Case Detail</span>
   {(this.state.caseDetailsObj.CaseStatusCode !== 'CL' && this.state.caseDetailsObj.CaseStatusCode !== 'UP') ?
  <span> {this.state.editmode === true ?( <span style={{paddingLeft: '82%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button> 
   <Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button></span>) :
    <span style={{paddingLeft: '87%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Edit')}>Edit</Button></span>
  } </span> :
  <span></span>
}
</div>
       <Row type="flex" justify="space-around" >
    <Col span = {6}>
    <div style={{paddingTop: "5px"}}>
           <b>Date of Birth</b>:
        <Input value={caseDetailsObj.Customer.DOB} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/>          
            </div>
            <div style={{paddingTop: "10px"}}>
   <b>DL Number</b>:
  <Input value={caseDetailsObj.Customer.DLNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}>
       <b>License Class</b>:
        <Input value={caseDetailsObj.Customer.classLicense} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input value={caseDetailsObj.Customer.PhoneNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Mailing Address</b>:
        <TextArea rows="5" value={caseDetailsObj.Customer.MailingAddress} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
       </Col>
        <Col span = {6}>
        <div style={{paddingTop: "5px"}}> <b>Case Number</b>:
        <Input value={caseDetailsObj.CaseNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Received Date</b>:
        <Input value={caseDetailsObj.DateReceived} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>          
            <div style={{paddingTop: "10px"}}> <b>Case Status</b>:
        <Input value={caseDetailsObj.CaseStatus} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Hearing Type</b>:
        {this.state.editmode === true ?

          <Select value={this.state.hearingType} onChange={e => this.handleChange(e, 'HRNG_TYP')} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                 {hearingTypesList}
                              </Select> :
                              <Select value={this.state.hearingType} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >        
                                {hearingTypesList}               
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Reason</b>:
        {this.state.editmode === true ?
          <Select value={this.state.caseReason} onChange={e => this.handleChange(e, 'CASE_RSN')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseReasonsList}
                              </Select> :
                              <Select value={this.state.caseReason} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                              {caseReasonsList}
                              </Select>
          }
        </div>
        <div style={{paddingTop: "10px"}}> <b>Referral</b>:
        {this.state.editmode === true ?
        <Select value={this.state.caseReferral} onChange={e => this.handleChange(e, 'CASE_RFL')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                               {caseReferralsList}
                            </Select> :
                            <Select value={caseDetailsObj.CD_REFR_SRCE_TYP} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                            {caseReferralsList}
                            </Select>
        }
        </div>
       { reqRsnCodesForCerts.includes(this.state.caseReason) && <div style={{paddingTop: "10px"}}> <b>Special Cert/Endorsement</b>:
        {this.state.editmode === true ?
          <Select value={this.state.caseCertification} onChange={e => this.handleChange(e, 'CASE_CERT')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseCertificationsList}
                              </Select> :
                              <Select value={caseDetailsObj.CD_ENDR} showArrow={true} size={"default"} style={{ width: '100%'}} disabled >
                              </Select>
          }
        </div>
       }
            </Col>
            <Col span ={6}>
            {this.state.caseReason === "950" ?
             <div style={{ 
              width: "100%",
              height: "50%",
              marginTop: "30%",
               border: "1px solid #c9e3fa",
               borderRadius: "6px"
             }}>
    <div style={{height: "15%", backgroundColor: "#c9e3fa",textAlign: "center"}}><div style={{paddingTop: "1%"}}>FINANCIAL RESPONSIBILITIES:</div></div>
    <div style={{paddingTop: "1%", textAlign: "center"}}><b>List of Accidents:</b> </div>
    <div style={{paddingTop: "1%", paddingLeft: "10%"}}><span  style={{paddingTop: "1%", paddingLeft: "2%"}}><b>FR Case No.</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Accident Date</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Location</b></span></div>
    <div style={{paddingTop: "1%", paddingLeft: "2%",overflow:"scroll", height: "61%"}}> {this.state.editmode === false ? <RadioGroup onChange={this.onChange} value={this.state.value} disabled>
        {accidentsList}
      </RadioGroup> :
      <RadioGroup onChange={this.onChange} value={this.state.value}>
      {accidentsList}
    </RadioGroup>
    }
</div>

          </div>
                 :
                 <div></div>}
           </Col>
            </Row>     
            {(this.state.caseDetailsObj.CaseStatusCode === 'SC') ?  <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%",
    marginTop: "25px"
   }} >
   <Button style={{marginLeft: "45%", marginTop: "4px"}} type="default" size={"small"} onClick={this.openCaseSchedule}><Icon type="calendar" style={{ fontSize: 16 }}/>Schedule Detail</Button> 
<Modal     title="Basic Modal"
          visible={this.state.caseSchedVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}> Hi There! </Modal>
</div>:<div></div>
            }
            </div>}
  </div> ):
(
       this.state.tabValue === 'DadH6' ? <div>
         {(h6Info !== undefined) ? <div>{h6Info}</div> : <div>:(
        <Spin size="large" />
      )}</div>}
       </div> : <div>
{this.state.tabValue === 'Comments' ?   <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>  <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> 
<div style={{
justify: "center",
height: "30px",
backgroundColor: "#c9e3fa",
paddingLeft: "1%"
}} ><Icon type="message" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>Comments</span><Button style={{marginLeft: "80%"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}><Icon type="plus-square"></Icon>New Comment</Button></div>
 <List
    itemLayout="horizontal"
    bordered={true}
    dataSource={data}
    renderItem={item => (
      <List.Item>
        <List.Item.Meta
          title={<div style={{fontSize:16}}>{item.NBR_COMM}-{item.TXT_COMM}</div>}
          description={<div  style={{fontSize:12}}><b>Date:</b><span>{item.DT_UPDT_TRANS}</span><b>Author:</b><span>{item.EmployeeFullName}</span></div>}
          pagination = "true"
        />
      </List.Item>
    )}
  /> </div></div>:
<div></div>
}

       </div>
)
       }
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    </Row>
    </div>
       ):<div></div>}
    </ScrollPanel>
); 
    }
}

const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
          getCaseDetails,
          getCaseCertifications,
          getCaseReasons,
          getCaseReferrals,
          getHearingTypes,
          getCustomerD26Info,
          modifyCaseDetail,
          getH6Info,
          getCaseComments
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CaseDetails);