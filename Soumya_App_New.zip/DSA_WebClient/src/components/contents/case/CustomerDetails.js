import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel"
import { getCustomerDetails } from "../../../store/actions/caseActions";
import { withRouter } from "react-router-dom";
import { List, Table, Radio, Button, Icon, Card, Input, Row, Col, Spin } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import styles from "../../../Cases.css"

const { TextArea } = Input;
// const RadioGroup = Radio.Group;
// const radioStyle = {
//     display: 'block',
//     height: '30px',
//     lineHeight: '30px',
//   };

// const getAccidentsList = (accidentsObj) =>   
// {  
//   debugger;
//     let list = [];   

//     accidentsObj.map(item =>
// {

//   list.push(<Radio style={radioStyle} value={item.CaseNumber}><span style={{paddingLeft:"5%"}}>{item.CaseNumber}</span><span style={{paddingLeft:"15%"}}>{item.Date}</span><span style={{paddingLeft:"15%"}}>{item.City}</span></Radio>)
//   }

// );
    
//     return list;     
//    }
const frcolumns = [
    {
        title: <b>FR CASE NO.</b>,
        dataIndex: 'CaseNumber',
       width: "30%",
        key: 'CaseNumber',
        //render: text =><a href="">{text}</a>,
      },
      {
        title: <b>ACCIDENT DATE</b>,
        dataIndex: 'Date',
       width: "35%",
        key: 'Date',
        render: text => <span style={{paddingLeft: "2%"}}>{text}</span>
      },
      {
        title: <b>LOCATION</b>,
        dataIndex: 'City',
       width: "35%",
        key: 'City'
      }];
const columns = [
    {
        title: 'Case Number',
        dataIndex: 'CaseNumber',
        width: 50,
        key: 'CaseNumber',
        render: text =><a href="">{text}</a>,
      },
      {
        title: 'Status',
        dataIndex: 'CaseStatus',
        width: 50,
        key: 'CaseStatus'
      },
      {
        title: 'Received',
        dataIndex: 'DateReceived',
        width: 50,
        key: 'DateReceived'
      },
      {
        title: 'Referral',
        dataIndex: 'CD_REFR_SRCE_TYP',
        width: 50,
        key: 'CD_REFR_SRCE_TYP'
      },
      {
        title: 'Reason',
        dataIndex: 'CD_RSN',
        width: 50,
        key: 'CD_RSN'
      }];


class CustomerDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
            dlNumber: props.match.params.dlNumber,
            customerDetailsObj: props.cases.customerDetailsObj
        };
    }    
    componentDidMount() {
        debugger;
        this.props.getCustomerDetails(this.state.dlNumber);
    }
    handleNewCase() {
        const {customerDetailsObj} = this.state;
          this.props.history.push(
              {pathname:`/newcase`,
            state: { detail:  customerDetailsObj}
          })
      }
    componentWillReceiveProps(nextProps) {
        debugger;
        if (this.props.cases.customerDetailsObj !== nextProps.cases.customerDetailsObj) {
            if(nextProps.cases.customerDetailsObj !== undefined)
            {
            this.setState({ customerDetailsObj: nextProps.cases.customerDetailsObj});
            }
        }
    }
    isArchivedRow(record)
    {
        if(record.Archived)
        {
            return {

            }
        }
    }
render() {
    debugger;

const {customerDetailsObj} = this.state;
// let accidentsList = [];
// if(customerDetailsObj !== undefined )
// { 
//  accidentsList = getAccidentsList(customerDetailsObj.Accidents);
// }
    return (
        <ScrollPanel
        style={{
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0)"
        }}
    >
 <div style={{
    justify: "center",
    // width: "80%",
    height: "90%",
    // border: "1px solid white",
    padding: "25px",
    margin: "15px"}} >
      {customerDetailsObj !== undefined ? (
          <div>
                <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "white",
    border: "3px solid white"}} ><Icon type="idcard" /> <b>{customerDetailsObj.LastName},{customerDetailsObj.FirstName}</b></div>
        <Row >
            <Col span = {72}>
    <div style={{
   width: "100%",
    height: "90%",
    border: "3px solid white",
    padding: "25px"}}>
    <Row gutter={64}>
    <Col span = {6}>
 <Row> <b>DL Number</b>:
        <Input value={customerDetailsObj.DLNumber} readOnly/>
  {/* <Input value="DL Number" disabled/>  */}
            </Row>
            <Row> <b>DOB</b>:
        <Input value={customerDetailsObj.DOB} readOnly/>
        {/* <Input value="DOB" disabled/>  */}
            </Row>
        </Col>
        <Col span = {6}>
        <Row> <b>License Class</b>:
        <Input value={customerDetailsObj.classLicense} readOnly/>
        {/* <Input value="License Class" disabled/>  */}
            </Row>
            <Row> <b>Phone Number</b>:
        <Input value={customerDetailsObj.PhoneNumber} readOnly/>
        {/* <Input value="Phone Number" disabled/>  */}
            </Row>
            </Col>
            <Col span ={6}>
            <Row> <b>Address</b>:
        <TextArea rows="3" value={this.state.customerDetailsObj.MailingAddress} readOnly/>
        {/* <Input value="AddressAddressAddress" disabled/>  */}
        </Row></Col>
           <Col span={6}>
    {/* <div style={{ height: "90%",
                    border: "3px solid white",
                    padding: "25px"}}>
    */}
                    {/* <div  style={{ 
              width: "70%",
               border: "1px solid white",
               marginBottom:"5%"
             }}>  */}
             <Row>
                <b> FINANCIAL RESPONSIBILITIES: List of Accidents </b>
                 </Row>
             <Row>
    {customerDetailsObj.Accidents && <Table rowKey = "CaseNumber" 
        bordered = {false} 
        size = 'small'
        //style= {{align: "center", width: "100%", height: "100%"}}
        scroll={{ y: 200, x: 200 }}
        pagination = {false}
        columns={frcolumns} 
        dataSource={customerDetailsObj.Accidents}
        rowKey={record => record.CaseNumber}
        showHeader
       />
        }
        </Row>
        {/* </div> */}
        {/* </div> */}
    </Col>
            </Row>
            <Row span ={16}>
                <Col span = {8}>
                <Row>
                {(customerDetailsObj.D26ValidationOK === true) ? <div></div>: <div><b>D26 Validation Message:</b>{customerDetailsObj.D26ValidationMessage}</div>}
                </Row>
                <Row>
                {(customerDetailsObj.Message === null) ? <div></div>: <div><b>Message:</b>{customerDetailsObj.Message}</div>}
                </Row>
                <Row>
                {(customerDetailsObj.ErrorMessage === null) ? <div></div>: <div><b>Message:</b>{customerDetailsObj.ErrorMessage}</div>}
                </Row>
                </Col>
                <Col span = {8}>
               {(customerDetailsObj.DCSDifferences.length > 0) ? <div>
                <List
      size="small"
      header={<div><b>DCS Differences</b></div>}
      dataSource={customerDetailsObj.DCSDifferences}
      renderItem={item => (<List.Item>{item}</List.Item>)}
    />
                    </div>
                        :
                        <div></div>
                                   }
                </Col>
                </Row>
    </div>

    </Col>
   
    </Row>
    <Row>
   
       <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "white",
    border: "3px solid white"}} ><span><b>CASES</b></span><span style={{paddingLeft: "90%"}}><Button type="primary" onClick={() => this.handleNewCase()}>Add a Case</Button></span></div>
    <div style={{
    justify: "center",
    // width: "80%",
    height: "300px",
    border: "3px solid white",
    padding: "25px"}}>

     {customerDetailsObj.cases && <Table rowKey = "caseNumber" 
        bordered = {false} 
        showHeader
        
  rowClassName={(record) => record.Archived === true ? 'archiveRowClass' : '' }

        size = 'small'
           style= {{align: "center", width: "100%", height: "300px"}}
        scroll={{ y: 200, x: 200 }}
        pagination = {false}
        onRow={(record) => {
            return {
              onClick: () => {
                debugger;
                if (record.CaseNumber) {
                    this.props.history.push(`/caseDetails/CaseNumber/${record.CaseNumber}`);
                  }
            }
            };
          }}
        columns={columns} 
        dataSource={customerDetailsObj.cases}
        rowKey={record => record.id}
       />
        }
 
    </div>

        </Row>
        
        </div>

      ):(
        <Spin size="large" />
      )}
    </div>
    </ScrollPanel>
); 
}
}


const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getCustomerDetails

        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CustomerDetails));