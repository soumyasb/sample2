import React, { Component } from 'react';
import { getH26Info } from "../../../store/actions/caseActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card } from 'antd'; 
import moment from "moment"; 


class H26Ino extends Component {
    constructor(props) {
        super(props);

        this.state={
            dlNumber: props.match.params.dlNumber,
            h26Info: this.props.cases.h26Info
        };
    }    
componentDidMount()
{
    debugger;
    this.props.getH26Info(this.state.dlNumber);
}
componentWillReceiveProps(nextProps) {
    debugger;
    if (this.props.cases.h26Info !== nextProps.cases.h26Info) {
        if(nextProps.cases.h26Info !== undefined)
        {
        this.setState({ h26Info: nextProps.cases.h26Info});
        }
    }

}
    render() {
       // console.log(JSON.parse(localStorage.getItem('userInfo')));
       const boxShadows = {
        boxShadow:
          "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
    };
    const {closedCaseDetail} = this.state;

    return (
        <div>
                            <Row>
                            <Col span={32}>
                            <div style={{
                                    height: "100px",
                                    paddingLeft: "15%"
                                   }}>
                                   <div style={{
                                    textAlign: "center",
                                    height: "30px",
                                    width: "80%",
                                    backgroundColor: "white",
                                    paddingLeft: "1%"
                                   }}> <b> CLOSED CASE DETAIL </b></div>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                   <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} >Subject Information</div>
                                    <div style={{
                                    justify: "center",
                                    height: "30px",
                                    paddingLeft: "1%"
                                   }}>
                                   <span style={{ paddingLeft: '0.5%'}}>DL # : {closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Case # : {this.state.caseNumber}</span>
                                   <span style={{ paddingLeft: '5%'}}>Name : {closedCaseDetail.SUBJECT_FIRST_NAME} {closedCaseDetail.SUBJECT_LAST_NAME}</span>
                                   </div>
                                    </div>}
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                   <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} >DS124 Coding Strip</div>
                                    <div style={{
                                    justify: "center",
                                    height: "30px",
                                    paddingLeft: "1%"
                                   }}>  <span>Type : 4{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Hearing Date: 11-12-2005{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Location: APL{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Reason: 657{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Sched Results: 1{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Type Action: 13{closedCaseDetail.NBR_DL}</span>       
                                     <span style={{ paddingLeft: '5%'}}>Modified Date: 05-26-2006{closedCaseDetail.NBR_DL}</span></div>
                                    </div>}
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                     <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} > Action Information </div>
                                    <div style={{
                                    justify: "center",
                                    height: "60px",
                                    paddingLeft: "1%"
                                   }}><div> <span>Type : 4{closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Hearing Date: 11-12-2005{closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Location: APL{closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Reason: 657{closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Sched Results: 1{closedCaseDetail.NBR_DL}</span></div>

                                    <div> <span>Type : 4{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Hearing Date: 11-12-2005{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Location: APL{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Reason: 657{closedCaseDetail.NBR_DL}</span></div></div></div>}
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                     <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} > Case Closure Information </div>
                                    <div style={{
                                    justify: "center",
                                    height: "60px",
                                    paddingLeft: "1%"
                                   }}><div> <span>Type : 4{closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Hearing Date: 11-12-2005{closedCaseDetail.NBR_DL}</span>
                                   <span style={{ paddingLeft: '5%'}}>Location: APL{closedCaseDetail.NBR_DL}</span></div>                               
                                    <div> <span>Type : 4{closedCaseDetail.NBR_DL}</span>
                                     <span style={{ paddingLeft: '5%'}}>Hearing Date: 11-12-2005{closedCaseDetail.NBR_DL}</span>
                           </div></div>
                                    </div>}
                                </Card>
                                </div>
                            </Col>
                        </Row>
                    </div>);
}    
}

    
const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getH26Info
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(H26Ino);