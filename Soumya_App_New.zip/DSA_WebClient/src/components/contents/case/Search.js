import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { withRouter } from "react-router-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Icon, Table, Row, Col } from 'antd';

const columns = [
    {
        title: 'DL Number',
        dataIndex: 'dlNumber',
        width: 150,
        key: 'dlNumber',
        render: text =><a href=""><Icon type="idcard" /> {text}</a>,
      },{
  title: 'Full Name',
  dataIndex: 'fullName',
  key: 'fullName',
  width: 150,
  render: text => <a href="">{text}</a>,
}];


class Search extends Component {
    constructor(props) {
        super(props);

        this.state={
            searchList: props.cases.searchList
        };
        this.opencustomerpage = this.opencustomerpage.bind(this);
    }    

    componentDidMount() {
        const searchText =  this.props.match.params.searchText || '';
        this.props.searchCases(searchText);

    }

    componentWillReceiveProps(nextProps) {
        if (this.props.match.params !== nextProps.match.params) {
            const searchText =  nextProps.match.params.searchText || '';
            this.props.searchCases(searchText);
        }

        if (this.props.cases.searchList !== nextProps.cases.searchList) {
            this.setState({ searchList: nextProps.cases.searchList});
        }
    }

   opencustomerpage = (e, dlNumber) =>
   {
    this.props.history.push(
        { pathname: `/customerDetails/dlNumber/${dlNumber}`,
        state: { dlNumber: dlNumber }
   });
}

    render() {
        let results = [];
        if(this.state.searchList !== undefined)
        {
        results = this.state.searchList.results.map(result => {
            return {
                dlNumber: result.dlNumber,
                fullName: result.FirstName +' '+result.LastName
            }
        });
    }
        const searchText =  this.props.match.params.searchText || '';
    return (
        <div>
                <Row type="flex" justify="center">
                <Col span={15}>
        <div >
        {this.state.searchList && <Table rowKey = "dlNumber" 
        bordered = {false} 
        size = 'default'
        onRow={(record) => {
            return {
              onClick: (e) => {
               this.opencustomerpage(e,record.dlNumber)
            }
            };
          }}
        
        scroll={{}}
        title={() => <div><span><h1>Search Results for:</h1></span><span>{searchText}</span></div>} 
        footer={() => <p>{this.state.searchList.ResultCount} results found</p>} 
        showHeader 
        columns={columns} 
        dataSource={results}
       />
    }
    </div>
 
    </Col>
    </Row>
    </div>   );
}    
}

    
const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            searchCases
        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Search));

