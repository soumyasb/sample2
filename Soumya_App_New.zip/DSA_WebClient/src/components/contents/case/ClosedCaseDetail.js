import React, { Component } from 'react';
import { getClosedCaseDetail } from "../../../store/actions/caseActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, Button } from 'antd'; 


class ClosedCaseDetail extends Component {
    constructor(props) {
        super(props);

        this.state={
            caseNumber: props.match.params.CaseNumber,
            closedCaseDetail: this.props.cases.closedCaseDetail
        };
        this.onButtonClick = this.onButtonClick.bind(this);   
    }    
componentDidMount()
{
    this.props.getClosedCaseDetail(this.state.caseNumber);
}
componentWillReceiveProps(nextProps) {
    if (this.props.cases.closedCaseDetail !== nextProps.cases.closedCaseDetail) {
        if(nextProps.cases.closedCaseDetail !== undefined)
        {
        this.setState({ closedCaseDetail: nextProps.cases.closedCaseDetail});
        }
    }

}
onButtonClick = (e,value) => {
    if(value === 'Back')
{
    this.props.history.push(`/customerDetails/dlNumber/${this.state.closedCaseDetail.DlNumber}`);
}
}
    render() {
       // console.log(JSON.parse(localStorage.getItem('userInfo')));
       const boxShadows = {
        boxShadow:
          "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
    };
    const {closedCaseDetail} = this.state;

    return (
        <div>
                            <Row>
                            <Col span={32}>
                            <div style={{
                                    height: "100px",
                                    paddingLeft: "15%"
                                   }}>
                                   <div style={{
                                    textAlign: "center",
                                    height: "30px",
                                    width: "80%",
                                    backgroundColor: "white",
                                    paddingLeft: "1%"
                                   }}> <b> CLOSED CASE DETAIL </b></div>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                   <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} ><b>Subject Information</b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "30px",
                                    paddingLeft: "1%"
                                   }}>
                                   <span style={{ paddingLeft: '0.5%'}}><b>DL # :</b> {closedCaseDetail.DlNumber}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Case # : </b>{closedCaseDetail.CaseNumber}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Name : </b>{closedCaseDetail.SubjectName}</span>
                                   </div>
                                    </div>}
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                   <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} ><b>DS124 Coding Strip</b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "30px",
                                    paddingLeft: "1%"
                                   }}>  <span><b>Type : </b>{closedCaseDetail.Type}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Hearing Date: </b>{closedCaseDetail.HearingDate}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Location: </b>{closedCaseDetail.Location}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Reason: </b>{closedCaseDetail.Reason}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Sched Results: </b>{closedCaseDetail.ScheduledResults}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Type Action: </b>{closedCaseDetail.TypeAction}</span>       
                                     <span style={{ paddingLeft: '5%'}}><b>Modified Date: </b>{closedCaseDetail.ModifiedDate}</span></div>
                                    </div>}
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                     <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} > <b>Action Information </b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "60px",
                                    paddingLeft: "1%"
                                   }}><div> <span><b>Authority Section: </b>{closedCaseDetail.AuthoritySection1}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Authority Section: </b>{closedCaseDetail.AuthoritySection2}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Authority Section: </b>{closedCaseDetail.AuthoritySection3}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Effective Date: </b>{closedCaseDetail.EffectiveDate}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Through Date: </b>{closedCaseDetail.ThroughDate}</span></div>

                                    <div> <span><b>Action Term Date : </b>{closedCaseDetail.ActionTermDate}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Mail Date: </b>{closedCaseDetail.MailDate}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Original Authority Section: </b>{closedCaseDetail.OriginalAuthoritySection}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Original Effective Date: </b>{closedCaseDetail.OriginalEffectiveDate}</span></div></div></div>}
                                </Card>
                                <Card
                                    style={{
                                    marginTop: "8px",
                                    borderRadius: "16px",
                                    width: "80%",
                                    ...boxShadows
                                    }}
                                >
                                    {this.state.closedCaseDetail && 
                                     <div> <div style={{
                                    justify: "center",
                                    height: "30px",
                                    backgroundColor: "#c9e3fa",
                                    paddingLeft: "1%"
                                   }} > <b>Case Closure Information </b></div>
                                    <div style={{
                                    justify: "center",
                                    height: "60px",
                                    paddingLeft: "1%"
                                   }}><div> <span><b>Scheduled To: </b>{closedCaseDetail.ScheduledTo}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Date Updated: </b>{closedCaseDetail.DateUpdated}</span>
                                   <span style={{ paddingLeft: '5%'}}><b>Updated By: </b>{closedCaseDetail.UpdatedBy}</span></div>                               
                                    <div> <span style={{ paddingLeft: '25%'}}><b>Date Closed: </b>{closedCaseDetail.DateClosed}</span>
                                     <span style={{ paddingLeft: '5%'}}><b>Closed By: </b>{closedCaseDetail.ClosedBy}</span>
                           </div></div>
                                    </div>}
                                </Card>
                                <div><Button type="primary" style={{marginLeft: "36%", marginTop: "1%"}} size={"small"} onClick={(e) => this.onButtonClick(e,'Back')}>Go Back</Button></div>
                                </div>
                            </Col>
                        </Row>
                    </div>);
}    
}

    
const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getClosedCaseDetail
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(ClosedCaseDetail);