import React, { Component } from 'react';
import { getCreateCaseDetails, getHearingTypes, getCaseReasons, getCaseReferrals, getCaseCertifications, getCustomerD26Info, addCase } from "../../../store/actions/caseActions";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { withRouter } from "react-router-dom";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Card, Radio, Input, Button, Select, Layout, Menu, Icon } from 'antd';
import styles from "../../../Cases.css"


const {Content,Sider } = Layout;
const RadioGroup = Radio.Group;
const { TextArea } = Input;
const { Option } = Select;
const radioStyle = {
  display: 'block',
  height: '30px',
  lineHeight: '30px',
};
const getDropdownList = (listObj, selectedValue) =>   
{  
    let list = [];   

     listObj.map(item =>
{
  if(item.Value === selectedValue)
  {
    list.push(<option key={item.Value} value={item.Value} selected>{item.Text}</option>)
  }
  else
  {
  list.push(<option key={item.Value} value={item.Value}>{item.Text}</option>)
  }

});
    
    return list;     
   }


   const getAccidentsList = (accidentsObj) =>   
{  
  debugger;
    let list = [];   

    accidentsObj.Accidents.map(item =>
{

  list.push(<Radio style={radioStyle} value={item.CaseNumber}><span style={{paddingLeft:"5px"}}>{item.CaseNumber}</span><span style={{paddingLeft:"25px"}}>{item.Date}</span><span style={{paddingLeft:"25px"}}>{item.City}</span></Radio>)
  }

);
    
    return list;     
   }
const reqRsnCodesForCerts = ["871","875","880","881","882","883","884","885","887","888","889","891","892","894","897","898"];


class AddCase extends Component {
    constructor(props) {
        debugger;
        super(props);
        this.state={
            createCaseObj: props.cases.createCaseObj,
            hearingTypes: props.cases.hearingTypesList,
            caseReasons: props.cases.caseReasonsList,
            caseReferrals: props.cases.caseReferralsList,
            caseCertifications: props.cases.caseCertificationsList,
            customerD26Info: props.cases.customerD26Info,
            isRequired: false,
            dlNumber: props.match.params.dlNumber
        };
       this.onButtonClick = this.onButtonClick.bind(this);   
       this.handleChange = this.handleChange.bind(this);
       this.textChange = this.textChange.bind(this);   
    }    
    componentDidMount() {
      this.props.getCreateCaseDetails(this.props.location.state.detail);
      this.props.getHearingTypes();
      this.props.getCaseReasons();
      this.props.getCaseReferrals();
      this.props.getCaseCertifications();
  }

  componentWillReceiveProps(nextProps) {
      debugger;
      if (this.props.cases.createCaseObj !== nextProps.cases.createCaseObj) {
          if(nextProps.cases.createCaseObj !== undefined)
          {
            if(nextProps.cases.createCaseObj.CaseNumber !== null)
            {
              this.props.history.push(`/caseDetails/CaseNumber/${nextProps.cases.createCaseObj.CaseNumber}`);
            }
          this.setState({ createCaseObj: nextProps.cases.createCaseObj});
          this.setState({ hearingType: nextProps.cases.createCaseObj.CD_HRNG_TYP});
          this.setState({ caseReason: nextProps.cases.createCaseObj.CD_RSN});
          this.setState({ caseReferral: nextProps.cases.createCaseObj.CD_REFR_SRCE_TYP});
          this.setState({ caseCertification: nextProps.cases.createCaseObj.CD_ENDR});
          this.setState({ hearingTypes: nextProps.cases.hearingTypesList});
          this.setState({ caseReasons: nextProps.cases.caseReasonsList});
          this.setState({ caseReferrals: nextProps.cases.caseReferralsList});
          this.setState({ caseCertifications: nextProps.cases.caseCertificationsList});
          this.setState({ value: nextProps.cases.createCaseObj.FRCaseNumber});
          this.setState({ phoneNumber: nextProps.cases.createCaseObj.PhoneNumber});
            this.props.getCustomerD26Info(nextProps.cases.createCaseObj.DLNumber);
          }
      }
      
     
      if (this.props.cases.customerD26Info !== nextProps.cases.customerD26Info) {
        this.setState({ customerD26Info: nextProps.cases.customerD26Info});
  }
}
onButtonClick = (e,value) => 
{

if(value === 'Cancel')
{
  this.props.history.push(`/customerDetails/dlNumber/${this.state.createCaseObj.DLNumber}`);
}
if(value === 'Save')
{
  debugger;
  const {createCaseObj} = this.state;
  createCaseObj.CD_HRNG_TYP= this.state.hearingType;
  createCaseObj.CD_RSN = this.state.caseReason;
  createCaseObj.CD_REFR_SRCE_TYP = this.state.caseReferral;
  createCaseObj.CD_ENDR = this.state.caseCertification;
  createCaseObj.FRCaseNumber = this.state.value;
   this.state.customerD26Info.Accidents.map(item =>
  {
    if(item.CaseNumber === createCaseObj.FRCaseNumber)
    {
        createCaseObj.AccidentDate = item.Date;
    }
  })
 this.state.customerD26Info.Accidents.map(item =>
    {
      if(item.CaseNumber === createCaseObj.FRCaseNumber)
      {
        createCaseObj.AccidentCity =  item.City;
      }
    })
    this.props.addCase(createCaseObj);
}
}
onChange = (e) => {
  debugger;
  console.log('radio checked', e.target.value);
  this.setState({
    value: e.target.value,
  });
}

textChange(e) {
    const { createCaseObj } = this.state;
    createCaseObj.PhoneNumber = e.target.value;
    this.setState({ createCaseObj });
}

handleChange = (e,listType) => {
    debugger;
  if(listType === 'HRNG_TYP')
{    
 this.setState({hearingType: e});
}
if(listType === 'CASE_RSN')
{    
 this.setState({caseReason: e});
}
if(listType === 'CASE_RFL')
{    
 this.setState({caseReferral: e});
}
if(listType === 'CASE_CERT')
{    
 this.setState({caseCertification: e});
}
}
    render() {

const {createCaseObj} = this.state;
let accidentsList = [];
if(this.state.customerD26Info !== undefined )
{ 
 accidentsList = getAccidentsList(this.state.customerD26Info);
}
let hearingTypesList = [], caseReasonsList = [], caseReferralsList = [], caseCertificationsList = [];
if(this.state.createCaseObj!== undefined && this.state.hearingTypes !== undefined )
{ 
  hearingTypesList = getDropdownList(this.state.hearingTypes, this.state.createCaseObj.CD_HRNG_TYP);    
}
if(this.state.createCaseObj!== undefined && this.state.caseReasons !== undefined)
{ 
  caseReasonsList = getDropdownList(this.state.caseReasons, this.state.createCaseObj.CD_RSN);    
}
if(this.state.createCaseObj!== undefined && this.state.caseReferrals !== undefined)
{ 
  caseReferralsList = getDropdownList(this.state.caseReferrals, this.state.createCaseObj.CD_REFR_SRCE_TYP);    
}
if(this.state.createCaseObj!== undefined && this.state.caseCertifications !== undefined)
{ 
  caseCertificationsList = getDropdownList(this.state.caseCertifications, "");    
}
        return (   
          <ScrollPanel
          style={{
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(0,0,0,0)"
          }}
      >
       {createCaseObj !== undefined ? (
          <div> 
          <Row type="flex" justify="center">
     <Col span = {22}>     
          <div style={{
            justify: "center",
            height: "80px",
            paddingLeft: "1%",
            border: "3px solid white"}} ><div style={{paddingTop: "10px"}}><Icon type="idcard"  style={{ fontSize: 32 }}/> 
            <span style={{fontSize: "xx-large"}}>{createCaseObj.LastName},{createCaseObj.FirstName}</span>
            <span style={{fontSize: "x-large"}}>DL: {createCaseObj.DLNumber}</span>
            </div></div>
 
 
    <Layout style={{ height: '100%'}}>
     <Content>
      {/* <Breadcrumb style={{ margin: '16px 0' }}>
        <Breadcrumb.Item>Home</Breadcrumb.Item>
        <Breadcrumb.Item>List</Breadcrumb.Item>
        <Breadcrumb.Item>App</Breadcrumb.Item>
      </Breadcrumb> */}
      <Layout style={{ height: '100%', background: '#fff' }}>
        <Sider width={200} style={{ background: '#fff' }}>
          <Menu
            mode="inline"
            defaultSelectedKeys={['1']}
            defaultOpenKeys={['1']}
            style={{ height: '100%' }}
          >
            <Menu.Item key="1"> <Icon type="profile" />
              <span>Case Detail</span>
</Menu.Item>
<Menu.Item key="2">
<Icon type="team" />
              <span>OIP</span>
</Menu.Item>
<Menu.Item key="3"> 
<Icon type="message" />
              <span>Comments</span>
</Menu.Item>
<Menu.Item key="4">
<Icon type="schedule" />
              <span>Schedule</span>
</Menu.Item>
<Menu.Item key="5">
<Icon type="book" />
              <span>Closure</span>
</Menu.Item>
<Menu.Item key="6">
<Icon type="pause-circle" />
              <span>Suspense</span>
</Menu.Item>
<Menu.Item key="7">
<Icon type="file-text" />
              <span>DAD H6</span>
</Menu.Item>
          </Menu>
        </Sider>
        <Content style={{height: "600px" }}>
        <div style={{paddingLeft: '2%', paddingTop: '1%',justify: "center", width: '95%'}}>
               <div style={{border: "solid", borderColor: "#c9e3fa", height: "500px"}}> <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} ><Icon type="profile" style={{ fontSize: 16 }}/> <span style={{fontSize: 'large', paddingLeft: '0.5%'}}>Create New Case</span>
   {(this.state.createCaseObj.CaseStatusCode !== 'CL' && this.state.createCaseObj.CaseStatusCode !== 'UP') ?
  <span><span style={{paddingLeft: '80%'}}><Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button> 
   <Button type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button></span>
  </span> :
  <span></span>
}
</div>
       <Row type="flex" justify="space-around" >
    <Col span = {6}>
    <div style={{paddingTop: "5px"}}>
           <b>Date of Birth</b>:
        <Input value={createCaseObj.DOB} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/>          
            </div>
            <div style={{paddingTop: "10px"}}>
   <b>DL Number</b>:
  <Input value={createCaseObj.DLNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}>
       <b>License Class</b>:
        <Input value={createCaseObj.classLicense} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Phone Number</b>:
        <Input value={createCaseObj.PhoneNumber} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} maxlength="10" onChange={e => this.textChange(e)} readOnly/> 
            </div>
            <div style={{paddingTop: "10px"}}> <b>Mailing Address</b>:
        <TextArea rows="5" value={createCaseObj.MailingAddress} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
       </Col>
        <Col span = {6}>
        <div style={{paddingTop: "5px"}}> <b>Case Number</b>:
        <Input value="Case Number will be auto-generated" style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Received Date</b>:
        <Input value=   {createCaseObj.DT_RCPT}
 style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>          
            <div style={{paddingTop: "10px"}}> <b>Case Status</b>:
        <Input value={createCaseObj.CaseStatus} style={{ width: '100%', backgroundColor: "#f2efef", pointerEvents: "none"}} readOnly/> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Hearing Type</b>:

          <Select value={this.state.hearingType} onChange={e => this.handleChange(e, 'HRNG_TYP')} showArrow={true} size={"default"} style={{ width: '100%'}}>
                                 {hearingTypesList}
                              </Select>
      
        </div>
        <div style={{paddingTop: "10px"}}> <b>Reason</b>:
   
          <Select value={this.state.caseReason} onChange={e => this.handleChange(e, 'CASE_RSN')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseReasonsList}
                              </Select> 
        </div>
        <div style={{paddingTop: "10px"}}> <b>Referral</b>:

        <Select value={this.state.caseReferral} onChange={e => this.handleChange(e, 'CASE_RFL')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                               {caseReferralsList}
                            </Select> 
        </div>
       { reqRsnCodesForCerts.includes(this.state.caseReason) && <div style={{paddingTop: "10px"}}> <b>Special Cert/Endorsement</b>:

          <Select value={this.state.caseCertification} onChange={e => this.handleChange(e, 'CASE_CERT')} showArrow={true} size={"default"} style={{ width: '100%'}} >
                                 {caseCertificationsList}
                              </Select>
        </div>
       }
            </Col>
            <Col span ={6}>
            {this.state.caseReason === "950" ?
             <div style={{ 
              width: "100%",
              height: "50%",
              marginTop: "30%",
               border: "1px solid #c9e3fa",
               borderRadius: "6px"
             }}>
    <div style={{height: "15%", backgroundColor: "#c9e3fa",textAlign: "center"}}><div style={{paddingTop: "1%"}}>FINANCIAL RESPONSIBILITIES:</div></div>
    <div style={{paddingTop: "1%", textAlign: "center"}}><b>List of Accidents:</b> </div>
    <div style={{paddingTop: "1%", paddingLeft: "10%"}}><span  style={{paddingTop: "1%", paddingLeft: "2%"}}><b>FR Case No.</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Accident Date</b></span> 
    <span  style={{paddingTop: "1%", paddingLeft: "8%"}}><b>Location</b></span></div>
    <div style={{paddingTop: "1%", paddingLeft: "2%",overflow:"scroll", height: "61%"}}> {this.state.editmode === false ? <RadioGroup onChange={this.onChange} value={this.state.value} disabled>
        {accidentsList}
      </RadioGroup> :
      <RadioGroup onChange={this.onChange} value={this.state.value}>
      {accidentsList}
    </RadioGroup>
    }
</div>

          </div>
                 :
                 <div></div>}
           </Col>
            </Row>     
            </div>  
    </div>
        </Content>
      </Layout>
    </Content>
    </Layout>
    </Col>
    </Row>
    </div>
       ):<div></div>}
    </ScrollPanel>
); 
    }
}

const mapStateToProps = state => {
    return {
       cases: state.cases
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
          getCreateCaseDetails,
          getCaseCertifications,
          getCaseReasons,
          getCaseReferrals,
          getHearingTypes,
          getCustomerD26Info,
          addCase
        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AddCase));