import React, { Component } from "react";

import {
  Row,
  Col,
  Card,
  Spin,
  Modal,
  Collapse,
  Badge,
  notification,
  Table
} from "antd";
import { withRouter } from "react-router-dom";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Slider from "react-slick";
import moment from "moment";
import { initHomePage } from "../../../store/actions/homePageActions";
import { setNewsModal, setNewsIdx } from "../../../store/actions/uiActions";

class homepage extends Component {
  localState = {};

  componentWillMount() {
    this.props.initHomePage();
  }

  showModal = (e, idx) => {
    this.props.setNewsModal(true);
    this.props.setNewsIdx(idx);
  };
  handleOk = e => {
    this.props.setNewsModal(false);
  };
  handleCancel = e => {
    this.props.setNewsModal(false);
  };
  handleRowClick = e => { 
       this.props.history.push(`/casedetails/caseId/${e.cD_CASE}`); 
     } 
  
  render() {
    const { homePage } = this.props;
    const newsChars = 250;

    const boxShadows = {
      boxShadow:
        "0 1px 3px 0 rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.12), 0 0 2px 0 rgba(0, 0, 0, 0.14)"
    };

    const welcome =
      this.props.homePage.FirstName !== undefined ? (
        <div>
          <h2>
            {"Welcome, " +
              this.props.homePage.FirstName +
              " " +
              this.props.homePage.LastName +
              "!"}
          </h2>
          <h3>
            {"Your current office is " +
              this.props.homePage.Office.NmeOff +
              " | " +
              this.props.homePage.Office.CdOffId}
          </h3>
        </div>
      ) : (
        <Spin size="large" />
      );

    const listData =
    homePage.News !== undefined
        ? (homePage.News !== [] ? homePage.News.map((i, idx) => (
            <div key={idx}>
              <Card
                style={{
                  height: "280px",
                  borderRadius: "16px",
                  marginRight: "1px"
                }}
              >
                <h2>{i.Subject}</h2>
                <h4>
                  {"by: " +
                    i.AuthorName +
                    " | priority: " +
                    (i.Priority === "A" ? "Urgent" : "Normal") +
                    " | date: " +
                    i.CreateDate.slice(0, 10)}
                </h4>
                <p>
                  {i.NewsText.length > newsChars &&
                    i.NewsText.slice(0, newsChars) + "..."}
                  {i.NewsText.length <= newsChars &&
                    i.NewsText.slice(0, newsChars)}
                </p>
                <a
                  href="#"
                  onClick={e => this.showModal(e, idx)}
                  style={{ color: "blue" }}
                >
                  {i.NewsText.length > newsChars && "Read More..."}
                  {i.NewsText.length <= newsChars && ""}
                </a>
              </Card>
            </div>
          )) :<div> "No News Items"</div>)
        : "";

    const settings = {
      dots: true,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      arrows: true,
      autoplaySpeed: 5000
      // beforeChange: function(currentSlide, nextSlide) {
      //   console.log("before change", currentSlide, nextSlide);
      // },
      // afterChange: function(currentSlide) {
      //   console.log("after change", currentSlide);
      // }
    };
    const columns = [ 
           { 
             title: 'Case #', 
              dataIndex: 'CD_CASE', 
              key: 'CD_CASE', 
          }, { 
            title: 'DL #', 
              dataIndex: 'NBR_DL', 
              key: 'NBR_DL', 
            }, { 
              title: 'Subject Name', 
              dataIndex: 'NME_SURNME_PRSN', 
              key: 'NME_SURNME_PRSN', 
             }, { 
              title: 'Due Date', 
              dataIndex: 'dT_SUSP', 
              key: 'dT_SUSP', 
              render: (text) => moment(text).format("MMM Do YYYY") 
             }, { 
               title: 'Reason', 
               dataIndex: 'CD_RSN', 
              key: 'CD_RSN', 
            }, { 
              title: 'Description', 
               dataIndex: 'DESC_SUSP_RSN', 
               key: 'DESC_SUSP_RSN', 
             } 
           ]; 
    
    const openNotificationWithIcon = (e, type) => {
      notification[type]({
        message: "Selected Suspense Case",
        description: "You selected case #" + e.cD_CASE
      });
    };
    return (
      <ScrollPanel
        style={{
          width: "100%",
          height: "calc(100% - 40px)",
          backgroundColor: "rgba(0,0,0,0)"
        }}
      >
        <Col lg={24} xl={{ span: 22, offset: 1 }} xxl={{ span: 20, offset: 2 }}>
          <div style={{ paddingRight: "1.5em", lineHeight: "1.5" }}>
            <Card
              style={{ backgroundColor: "rgba(0,0,0,0)" }}
              bordered={false}
              bodyStyle={{ padding: "5px" }}
            >
              <Row gutter={12}>
                <Col span={12}>
                  <Card
                    style={{
                      borderRadius: "16px",
                      height: "400px",
                      ...boxShadows
                    }}
                  >
                    {welcome}
                  </Card>
                </Col>
                <Col span={12}>
                  <Card
                    style={{
                      borderRadius: "16px",
                      height: "400px",
                      overflow: "hidden",
                      ...boxShadows
                    }}
                    title="News"
                    bodyStyle={{
                      padding: "5px 30px"
                    }}
                  >
                    <Slider {...settings}>{listData}</Slider>
                  </Card>
{  this.props.homePage.News && this.props.homePage.News[this.props.ui.newsIdx] !== undefined ? 
                  <Modal
                    title={
                      homePage.News !== undefined ? (
                
                        <h2>{homePage.News[this.props.ui.newsIdx].subject}</h2>
                      ) : (
                        ""
                      )
                    }
                    visible={this.props.ui.newsModalVisible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                  >
                    <h3>
                      {homePage.News !== undefined
                        ? "by: " +
                          homePage.News[this.props.ui.newsIdx].authorName +
                          " | date: " +
                          moment(
                            homePage.News[this.props.ui.newsIdx].createDate
                          ).format("MMM Do YYYY") +
                          " | priority: " +
                          (homePage.News[this.props.ui.newsIdx].priority === "A"
                            ? "Urgent"
                            : "Normal")
                        : ""}
                    </h3>
                    <p>
                      {homePage.News !== undefined
                        ? homePage.News[this.props.ui.newsIdx].newsText
                        : ""}
                    </p>
                  </Modal>
                  : <Modal></Modal>}
                </Col>
              </Row>
              <Row>
                <Col span={24}>
                  <Card
                    style={{
                      marginTop: "8px",
                      borderRadius: "16px",
                      ...boxShadows
                    }}
                  >
                    <Collapse>
                      <Collapse.Panel
                        header={
                          <div>
                            <h3>
                              Suspense Cases{" "}
                              <Badge count={homePage.SuspenseCount} />
                            </h3>
                          </div>
                        }
                        key="1"
                      >
         <Table 
                                      columns={columns} 
                                          pagination={{ pageSize: 5 }} 
                            onRowClick={(e) => this.handleRowClick(e)}  
                                      dataSource={homePage.Suspense} /> 
                             </Collapse.Panel> 
                    </Collapse>
                  </Card>
                </Col>
              </Row>
            </Card>
          </div>
        </Col>
      </ScrollPanel>
    );
  }
}

const mapStateToProps = state => {
  return {
    homePage: state.homePage,
    ui: state.ui
  };
};

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      initHomePage,
      setNewsModal,
      setNewsIdx
    },
    dispatch
  );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(homepage));
