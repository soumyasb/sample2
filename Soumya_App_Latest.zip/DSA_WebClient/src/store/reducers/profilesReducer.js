const employeeProfilesReducerDefaultState = {
  profilesErrorData: undefined
};

const employeeProfilesReducer = (state = employeeProfilesReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_EMPPROFILESINITIAL_DATA": {
      return { ...state, employeeProfilesInitialData: action.data };
    }
    case "GET_EMPPROFILES_DATA": {
      return { ...state, employeeProfilesData: action.data };
    }   
    case "GET_CREATEROFILE_DATA":
    {
      return { ...state, createProfileData: action.data };
    }
    case "GET_EMPLOYEEHEARINGAUTH_DATA":
    {
      return { ...state, hearingAuthData: action.data }
    }
    case "GET_HEARINGLOCATION_DATA":
    {
      return { ...state, hearingLocationsData: action.data }
    }
    case "GET_HEARINGROOMPROFILES_DATA":
    {
      return { ...state, hearingRoomProfilesData: action.data }
    }
    case "GET_DISTRICTOFFICES_DATA":
    {
      return { ...state, districtOfficesData: action.data }
    }
    case "GET_HEARINGROOMPROFILEBYLOCATION_DATA":
    {
      return { ...state, hearingRoomProfilebyLocation: action.data }
    }
    case "GET_EMPLOYEELIST_DATA":
    {
      return { ...state, employeeList: action.data }
    }
    case "GET_EMPLOYEEAPPMNT_DATA":
    {
      return { ...state, employeeappmnt : action.data }
    }
    case "GET_UPDATEDROOMPROF_DATA":
    {
      return { ...state, hearingRoomProfilebyLocation: action.data, updatedStatus: action.status }
    }
    case "GET_PROFILESERRORDATA":
    {
      return { ...state, profilesErrorData: action.data}
    }
    case "GET_DEFAULTROOMPROFILE_DATA":
    {
      return { ...state, defaultRoomProfileData: action.data}
    }
    default:
      return state;
  }
};

export default employeeProfilesReducer;