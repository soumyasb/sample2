import axios from "axios";

//HOMEPAGE ACTIONS
export const getHomePage = data => ({
  type: "GET_HOMEPAGE",
  data: data
});

export const initHomePage = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/HomePage").then(response => {
      dispatch(getHomePage(response.data));
    });
  };
};
