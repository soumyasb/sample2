import axios from "axios";
import employeelistdata from "../../components/contents/mocks/ListOFEmployees.json"
import officeslistdata from "../../components/contents/mocks/ListOfOffices.json"
import hearinglocationsdata from "../../components/contents/mocks/ListOfHearingLocations.json"
import initialempprofdata from "../../components/contents/mocks/employeeprofInitData.json"
import empprofsdata from "../../components/contents/mocks/employeeprofilesbyId.json"
import hearingauthdata from "../../components/contents/mocks/hearingAuthData.json"
import hearingroomsperlocationdata from "../../components/contents/mocks/gethearingroomprofilesforroom.json"
import hearingroomprofbyprofiddata from "../../components/contents/mocks/gethearingroomprofbyid.json"
import timeoffforanempidanddate from "../../components/contents/mocks/TimeOffForAnEmpIdAndDate.json"

// EMPLOYEE PROFILES ACTIONS


// Initial Employee Profiles page data
export const getEmployeeProfilesInitialPageData = data => ({
  type: "GET_EMPPROFILESINITIAL_DATA",
  data: data
});

export const getEmployeeProfilesInitialPage = () => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeProfile/IntitialPage").then(response => {
      dispatch(getEmployeeProfilesInitialPageData(response.data));
 // dispatch(getEmployeeProfilesInitialPageData(initialempprofdata));
    });
  };
};


// Get profiles of an employee
export const getEmployeeProfilesbyIdData = data => ({
    type: "GET_EMPPROFILES_DATA",
    data: data
  });
  
  export const getEmployeeProfilesbyId = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/GetAllProfilesForEmployee/"+empid).then(response => {
       dispatch(getEmployeeProfilesbyIdData(response.data));
     // dispatch(getEmployeeProfilesbyIdData(empprofsdata));
      });
    };
  };


  // Get hearing Authorization of an employee
  export const getHearingAuthorizationData = data => ({
    type: "GET_EMPLOYEEHEARINGAUTH_DATA",
    data: data
  });
  
  export const getHearingAuthorization = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingAuth/"+empid).then(response => {
        dispatch(getHearingAuthorizationData(response.data));
    // dispatch(getHearingAuthorizationData(hearingauthdata));
      });
    };
  };

  // // Get list of hearing rooms per location
  // export const getHearingRoomProfilesForRoomData = data => ({
  //   type: "GET_HEARINGROOMPROFILES_DATA",
  //   data: data
  // });
  
  // export const getHearingRoomProfilesForRoom = (locationId) => {
  //   return dispatch => {
  //     axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingRoomProfilesForRoom"+locationId).then(response => {
  //       dispatch(getHearingRoomProfilesForRoomData(response.data));
  //    // dispatch(getHearingRoomProfilesForRoomData(hearingroomsperlocationdata));
  //     });
  //   };
  // };

  // Get hearing room prof detail by id
  export const getHearingRoomProfileByLocationData = data => ({
    type: "GET_HEARINGROOMPROFILEBYLOCATION_DATA",
    data: data
  });
  
  export const getHearingRoomProfileByLocation = (locationId) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingRoomProfilesForRoom"+locationId).then(response => {
       dispatch(getHearingRoomProfileByLocationData(response.data));
     // dispatch(getHearingRoomProfileByIdData(hearingroomprofbyprofiddata));
      });
    };
  };

  // To get list of offices
  export const getMyDistrictOfficesData = data => ({
    type: "GET_DISTRICTOFFICES_DATA",
    data: data
  });
  
  export const getMyDistrictOffices = () => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/GetMyDistrictOffices").then(response => {
     dispatch(getMyDistrictOfficesData(response.data));
// dispatch(getMyDistrictOfficesData(officeslistdata));
      });
    };
  };

  export const getCreateProfileData = data => ({
    type: "GET_CREATEROFILE_DATA",
    data: data
  });
  
  export const getCreateProfile= (empid, profid) => {
      debugger;
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
        dispatch(getCreateProfileData(response.data));
      });
    };
  };

  export const saveEmployeeProfile = (employeeProfDataObj) => {
      debugger;
    return dispatch => {
      axios.post("http://localhost:32610/api/EmployeeProfile/CreateEmployeeProfile",employeeProfDataObj).then(response => {
        if(response.status === 200)
        {
          console.log(response);
        }
    }).catch((error) => {
      console.log(error);
    });

  };
  };

  export const saveHearingAuth = (hearingAuthData) => {
    debugger;
  return dispatch => {
    axios.post("http://localhost:32610/api/HearingAuth/CreateHearingAuth",hearingAuthData).then(response => {
      if(response.status === 200)
      {
        dispatch(getHearingAuthorizationData(JSON.parse(response.config.data)));
      }
  }).catch((error) => {
    console.log(error);
  });

};
};

export const deleteEmployeeProfile = (profid, endDate) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeProfile/DeleteEmployeeProfile/"+profid+"?EndEffectiveDate=",endDate).then(response => {
    if(response.status === 200)
    {
     //dispatch(getHearingAuthorizationData(JSON.parse(response.config.data)));
    }
}).catch((error) => {
  console.log(error);
});

};
};
//   export const getEmployeeProfile= (profid) => {
//       debugger;
//     return dispatch => {
//       axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
//         dispatch(getEmployeeProfileData(response.data));
//       });
//     };
//   };


// To get list of hearing locations
export const hearingLocationsProfileData = data => ({
  type: "GET_HEARINGLOCATION_DATA",
  data: data
});

export const getHearingLocation= (officeId) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingLocation"+officeId).then(response => {
      dispatch(hearingLocationsProfileData(response.data));
  // dispatch(hearingLocationsProfileData(hearinglocationsdata));
    });
  };
};


// To get the list of Employees
export const getlistOfEmployeesData = data => ({
  type: "GET_EMPLOYEELIST_DATA",
  data: data
});

export const getListOfEmployeesForOffice= () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeesForMyOffice").then(response => {
    //  dispatch(getlistOfEmployeesData(response.data));
    dispatch(getlistOfEmployeesData(response.data));
    });
  };
};

// Get timeoff details search results for emp id and date
export const getTimeOffDetailsforEmployeeData = data => ({
  type: "GET_EMPLOYEEAPPMNT_DATA",
  data: data
});

export const getTimeOffDetailsforEmployee= (empidlist,month,year ) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentByEmployee?empIDList="+empidlist+"&month="+month+"&year="+year).then(response => {
    //  dispatch(getlistOfEmployeesData(response.data));
    dispatch(getTimeOffDetailsforEmployeeData(response.data));
    });
  };
};

// Get timeoff details search results for emp id and date
export const getTimeOffCreateScreenData = data => ({
  type: "GET_CREATETIMEOFF_DATA",
  data: data
});

export const getTimeOffCreateScreen= () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentForCreate").then(response => {
    //  dispatch(getlistOfEmployeesData(response.data));
    dispatch(getTimeOffCreateScreenData(response.data));
    });
  };
};

// Get timeoff detail for app id
export const getEmployeeAppointmentData = data => ({
  type: "GET_EMPAPPBYREACNO_DATA",
  data: data
});

export const getEmployeeAppointment= (reacNo, apptNo) => {
  debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentForEdit"+reacNo+"?AppintmentNumber="+apptNo).then(response => {
    //  dispatch(getlistOfEmployeesData(response.data));
    if(response.status === 200)
   { dispatch(getEmployeeAppointmentData(response.data));
   }
    });
  };
};

// To get default room profile
export const defaultRoomProfileData = data => ({
  type: "GET_DEFAULTROOMPROFILE_DATA",
  data: data
});

export const getDefaultRoomProfile = (locationId) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoomProfile/DefultRoomProfile"+locationId).then(response => {
      dispatch(defaultRoomProfileData(response.data));
    });
  };
};



// To update the room profile
export const updatedHearingRoomProfileData = udata => ({
  type: "GET_UPDATEDROOMPROF_DATA",
  data: udata.data,
  status: udata.status
});

export const updateHearingRoomProfile = (modifiedRoomProfile) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/HearingRoomProfile/UpdateHearingRoomProfile",modifiedRoomProfile).then(response => {
    if(response.status === 200)
    {
      //console.log(response);
      dispatch(updatedHearingRoomProfileData(response));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
     debugger;
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};


// To create the employee timeoff
export const createEmployeeTimeOffData = ectodata => ({
  type: "GET_CREATEEMPTIMEOFF_DATA",
  data: ectodata.data,
  status: ectodata.status
});

export const createEmployeeTimeOff = (newEmpTimeOffData) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeAppointment/CreateEmployeeAppointment",newEmpTimeOffData).then(response => {
    if(response.status === 200)
    {
      //console.log(response);
     // dispatch(createEmployeeTimeOffData(response));
     dispatch(getTimeOffDetailsforEmployee(response.data.empid));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
     debugger;
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To update the employee timeoff
export const editEmployeeTimeOffData = eudata => ({
  type: "GET_EMPLOYEETOEDITED_DATA",
  data: eudata.data,
  status: eudata.status
});

export const editEmployeeTimeOff = (updatedEmpTimeOffData) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeAppointment/EditEmployeeAppointment",updatedEmpTimeOffData).then(response => {
    if(response.status === 200)
    {
      //console.log(response);
      dispatch(editEmployeeTimeOffData(response));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
     debugger;
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To delete the employee timeoff
export const deleteEmployeeTimeOffData = eddata => ({
  type: "GET_EMPLOYEETODELETED_DATA",
  data: eddata.data,
  status: eddata.status
});

export const deleteEmployeeTimeOff = (reacNo, apptNo) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeAppointment/DeleteEmployeeAppointment?ReaccuranceNumber="+reacNo+"&AppintmentNumber="+apptNo).then(response => {
    if(response.status === 200)
    {
      //console.log(response);
      dispatch(deleteEmployeeTimeOffData(response));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
     debugger;
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To get the erroe data
export const getProfilesErrorData = (data) => ({
  type: "GET_PROFILESERRORDATA",
  data: data
});
