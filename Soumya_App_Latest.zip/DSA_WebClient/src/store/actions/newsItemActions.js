import axios from "axios";

//NEWSITEMS ACTIONS
export const getNewsItemPage = data => ({
  type: "GET_NEWSITEMS",
  data: data
});

export const initNewsItemPage = () => {
  return dispatch => {
      axios.get("http://dmvwebd09:4000/api/NewsItems", {crossDomain: true}).then(response => {
        dispatch(getNewsItemPage(response.data));
      }).catch((error) => {
      });
    
    ;
     
  };
};

export const getCreateNewsItemObj = data => ({
  type: "GET_CREATENEWSITEM",
  data: data
});

export const initCreateNewsItemObj = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/NewsItems/CreateNewsItem").then(response => {
      dispatch(getCreateNewsItemObj(response.data));
    }).catch((error) => {
    });
  };
};

export const getEditNewsItemObj = data => ({
  type: "GET_EDITNEWSITEM",
  data: data
});

export const initEditNewsItemObj = (newsId) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/NewsItems/EditNewsItem/"+newsId).then(response => {
      dispatch(getEditNewsItemObj(response.data));
    }).catch((error) => {
    });
  };
};

export const getNewsItemDetailsObj = data => ({
  type: "GET_NEWSITEMDETAILS",
  data: data
});

export const getNewsErrorData = data => ({
  type: "GET_NEWSITEMERRORDATA",
  data: data
});

export const initNewsItemDetails = (newsId) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/NewsItems/GetNewsItemDetails/"+newsId).then(response => {
      dispatch(getNewsItemDetailsObj(response.data));
    }).catch((error) => {
    });
};
  };
  
  export const initSaveNewsItem = (newsItem) => {
    return dispatch => {
      axios.post("http://dmvwebd09:4000/api/NewsItems/AddNewsItem",newsItem).then(response => {
        if(response.status === 200)
        {
          dispatch(initNewsItemPage());
        }       
    }).catch((error) => {
      if(error.response.status === 422)
       {
        dispatch(getNewsErrorData(error.response.data.NewsItemDTO));
       }
    });
  };
  };

  export const getModifyNewsItemData = data => ({
    type: "GET_MODIFYNEWSITEMDATA",
    data: data
  });

  export const initModifyNewsItem = (newsItem) => {
    return dispatch => {
      axios.post("http://dmvwebd09:4000/api/NewsItems/ModifyNewsItem",newsItem).then(response => {
        debugger;
        if(response.status === 200)
        {
          dispatch(getModifyNewsItemData(response.data));
        }
    }).catch((error) => {
      if(error.response.status === 422)
       {
        dispatch(getNewsErrorData(error.response.data.NewsItemDTO));
       }
    });
  };
  };
  
  export const initDeleteNewsItem = (newsId) => {
    return dispatch => {
      axios.get("http://dmvwebd09:4000/api/NewsItems/DeleteNewsItem/"+newsId).then(response => {
        if(response.status === 204)
        {
          dispatch(initNewsItemPage());
        }
    }).catch((error) => {
    });
  };
  };

  export const getOfficeDetailsData = data => ({
    type: "GET_OFFICEDETAILS",
    data: data
  });
  
  export const initGetOfficeDetails = (empId, empType) => {
    return dispatch => {
      axios.get("http://dmvwebd09:4000/api/NewsItems/GetUserOffices/"+empId+"/"+empType).then(response => {
        dispatch(getOfficeDetailsData(response.data));
  }).catch((error) => {
  });
};
  };