import React, { Component } from "react";
import moment from 'moment';
import { Modal, Form, Input, Select, Checkbox, DatePicker, Button } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;

const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
};

const getModalSettings = ({ actionType, onOk, onCancel}) => {
    let title, okText = '';
    let footer = [];

    switch(actionType) {
        case 'create': 
            title = 'Create News Item';
            okText = 'Create';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'edit': 
            title = 'Edit News Item';
            okText = 'Save';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'details': 
            title = 'News Item Details';
            okText = 'Details';
            footer = [
                <Button key="Close" onClick={onCancel}>Close</Button>
            ];
            break;
        case 'delete': 
            title = 'Delete News Item';
            okText = 'Delete';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        default: 
            title = 'Create News Item';
    }

    return {
        title,
        okText,
        footer,
    }

}

const getOfficeDetails = (newsItemObj, officeDetailsObj, actionType) =>   
 {  
     let officedetails = [], officelist = [], officegrp = [];   
 if (actionType === 'edit' || actionType === 'create') {   
    officeDetailsObj.forEach(element => {   
          if(newsItemObj.officeGroup && newsItemObj.officeGroup!== null && newsItemObj.officeGroup.includes(element.OfficeId))   
          {   
             officegrp.push(element.OfficeId);   
        officelist.push(<Option key={element.OfficeId}>{element.OfficeName}</Option>);   
          }   
         else{   
             officelist.push(<Option key={element.OfficeId}>{element.OfficeName}</Option>);   
         }   
     });      
    }
    else
    {
        officeDetailsObj.forEach(element => {
            if(newsItemObj.OfficeNewsItem && newsItemObj.OfficeNewsItem!== null)
            {
                newsItemObj.OfficeNewsItem.forEach(officeItem => {
               if(officeItem.CdOffId === element.OfficeId)
               {
                officelist.push(element.OfficeName);  
               }
        });
    }
    });
    }         

 officedetails = {officelist, officegrp};    
  return officedetails;   
} 
const getPriorityList = (newsItemObj, actionType) =>   
{  
    let prioritylist = [];   
if (actionType === 'edit' || actionType === 'create') {   
    if(actionType === 'create')
    {
        prioritylist.push(<option key="" value="" disabled>- Please Select -</option>);
    }
   {newsItemObj.PriorityList &&  newsItemObj.PriorityList.map(priority =>
{
    if(actionType === "edit" && priority.Value === newsItemObj.Priority)
    {
        prioritylist.push(<option key={priority.Value} value={priority.Value} selected='true'>{priority.Text}</option>);
    }  
    else
    {
    prioritylist.push(<option key={priority.Value} value={priority.Value}>{priority.Text}</option>);
   }
})}}
   return prioritylist;     
}

class NewsModal extends Component {
    constructor(props) {
        super(props);
        this.state ={
            newsItemObj: props.newsItemObj
           // priorityValue: props.priorityValue
    }
        this.onPriorityChange = this.onPriorityChange.bind(this);   
        this.onNewsTextChange = this.onNewsTextChange.bind(this);   
        this.onSubjectChange = this.onSubjectChange.bind(this); 
        this.onCancel = this.onCancel.bind(this); 
        this.onOk = this.onOk.bind(this);
        this.onChecked = this.onChecked.bind(this);     
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.newsItemObj !== nextProps.newsItemObj) {
            this.setState({ value: nextProps.newsItemObj.officeGroup, newsItemObj: nextProps.newsItemObj});         
        } 
    
    if(nextProps.actionType === 'create')
    {
        this.setState({ value: []});
    }
    }

    onPriorityChange(event) {
        const {newsItemObj} = this.state;
        newsItemObj.Priority = event.target.value;
        this.setState({ newsItemObj });
    }

    onNewsTextChange(e) {
        const { newsItemObj } = this.state;
        newsItemObj.NewsText = e.target.value;
        this.setState({ newsItemObj });
    }

    onSubjectChange(e) {
        const { newsItemObj } = this.state;
        newsItemObj.Subject = e.target.value;
        this.setState({ newsItemObj });
    }

    onOk() {
        this.props.onOk(this.state.newsItemObj);
    }

    onCancel() {
        this.setState({value: []});
        const { newsItemObj } = this.state;
        newsItemObj.Priority = "";
        this.setState({ newsItemObj });
        this.props.onCancel();
    }

    handleChange = (value) => {
        const { newsItemObj } = this.state;
        newsItemObj.officeGroup = value;
        this.setState({ newsItemObj });      
       this.setState({value: value});
    }
   
    onChecked()
        {
            const { newsItemObj } = this.state;
           if(newsItemObj.AllOffices === true )
           {
            newsItemObj.AllOffices = false;
           }
           else
           {
            newsItemObj.AllOffices = true;
           }
        this.setState({ newsItemObj });
        
        }
 
        render() {
        let { newsItemObj } = this.state;
      //  const {priorityValue} = this.state;
        const modalSettings = getModalSettings(this.props);
       let officedetails = [];
       let prioritylist = [];
       if(this.state.newsItemObj !== undefined)
       {
       officedetails = getOfficeDetails(this.props.newsItemObj, this.props.officeDetailsObj, this.props.actionType);    
       prioritylist = getPriorityList(this.props.newsItemObj, this.props.actionType);    
       }
         return (        
            <Modal
                visible={this.props.modalVisible}
                onOk={this.handleOk}
                destroyOnClose={true}
                onCancel={this.onCancel}
                title={modalSettings.title}
                okText={modalSettings.okText} 
                footer={modalSettings.footer}
                width={'750px'}
            >
                <div>
                {/* {this.state.newsItemObj.Priority !== null ? */}
                    <Form layout={'horizontal'}>
                        <FormItem
                            label="Priority"
                            {...formItemLayout}
                        > 
                            {this.props.actionType === 'create' ? <select                           
                             style={{ width: '100%', border: "1px solid #d9d9d9", height: "32px", borderRadius: "4px"} }    
                             showArrow={true} size={"default"}        
                             defaultValue= ""
                             onChange={this.onPriorityChange}   
                           >   
                          {prioritylist}
                           </select> :   this.props.actionType === 'edit' ?                             
                             <select                           
                             style={{ width: '100%', border: "1px solid #d9d9d9", height: "32px", borderRadius: "4px"} }    
                             showArrow={true} size={"default"}        
                             placeholder="Please Select"
                             onChange={this.onPriorityChange}   
                           >   
                          {prioritylist}
                           </select>   
                            :
                            <div>{newsItemObj.Priority === 'A' ? "Urgent" :
                            newsItemObj.Priority === 'B' ? "Normal" : "Low"
                            }</div>                         
                            }
                        </FormItem>
                        <FormItem
                            label="Subject"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <Input value={newsItemObj.Subject} placeholder="Subject" onChange={this.onSubjectChange} />
                            :
                            <div>{newsItemObj.Subject}</div>                             
                            }
                        </FormItem>
                        <FormItem
                            label="News Text"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <TextArea value={newsItemObj.NewsText} rows="6" onChange={this.onNewsTextChange} />
                            :
                            <div>{newsItemObj.NewsText}</div>                             
                            }
                        </FormItem>
                        <FormItem
                            label="Start Date"
                            {...formItemLayout}
                        >
                        {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <DatePicker placeholder="Start Date"
                                defaultValue={moment(newsItemObj.StartDate, 'YYYY-MM-DD')} onChange={() => {}} />
                                :
                            <div>{moment(newsItemObj.StartDate).format("MM/DD/YYYY").toString()}</div>      
                                            
                            }
                        </FormItem>
                        <FormItem
                            label="End Date"
                            {...formItemLayout}
                        >
                        {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <DatePicker placeholder="End Date"
                                defaultValue={moment(newsItemObj.EndDate, 'YYYY-MM-DD')} onChange={() => {}} />
                                :
                                <div>{moment(newsItemObj.EndDate).format("MM/DD/YYYY").toString()}</div>                             
                                }
                        </FormItem>
                       {(this.props.actionType === 'create' || this.props.actionType === 'edit') && newsItemObj.EmployeeType !== 'O' ?
                       <FormItem
                            label="Publish this News Item to"
                            {...formItemLayout}
                        >
                           <Checkbox checked={newsItemObj.AllOffices} onChange={this.onChecked}  placeholder="input placeholder">
                                All offices in your region?
                            </Checkbox>                        
                       </FormItem>
                       : <FormItem
                       label="News Item is published to:"
                       {...formItemLayout}
                   >
                  
                     <div style={{ width: "80%"}}>{officedetails.officelist.map((office, i) => (
        <Button>{office}</Button>
    ))}</div>                       
                  </FormItem>
                       }
                       {newsItemObj.AllOffices|| newsItemObj.EmployeeType === 'O' || newsItemObj.officeGroup === undefined ? <div></div> :
                        <FormItem label="Select Offices:" {...formItemLayout}>      
                            {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <Select   
     mode="multiple"   
     style={{ width: '100%' }}   
     placeholder="Please select"   
     value={this.state.value}   
     onChange={this.handleChange}   
   >   
   
     {officedetails.officelist}   
   </Select>   
    :
    <div></div> 
                        }
                            </FormItem> 
                       }
                    </Form>
                        {/* :
                        <div>{}</div>
                                    } */}
                </div>  
            </Modal>
        
        );
    }
}

export default NewsModal;
