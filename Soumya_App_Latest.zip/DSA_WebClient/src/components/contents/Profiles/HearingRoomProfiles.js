import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import {  getHearingLocation, getHearingRoomProfilesForRoom, getMyDistrictOffices, getHearingRoomProfileById, updateHearingRoomProfile } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import moment from "moment";
import { Table, Dropdown, List, Spin, Modal, Radio, notification, Input, Tooltip, Button, Select, Layout, Menu, Icon, Badge, DatePicker, TimePicker, Checkbox, InputNumber } from 'antd';
import "../../../emp.css";
import cloneDeep from 'lodash/cloneDeep';

const { Content, Sider } = Layout;
const format = 'HH:mm';

const hearingLocationcolumns = [
    {
        title: <b>Room Number</b>,
        dataIndex: 'roomNumber',
        width: "30%",
        key: 'roomNumber'
    },
    {
        title: <b>Room Description</b>,
        dataIndex: 'roomDescription',
        width: "35%",
        key: 'roomDescription'
    },
    {
        title: <b>Closed Date</b>,
        dataIndex: 'closedDate',
        width: "35%",
        key: 'closedDate',
        render: (item) =>
        {
           if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM/DD/YYYY");
           }
        }
    }];

    const hearingRoomProfilescolumns = [
        {
            title: <b>Profile Id</b>,
            dataIndex: 'id',
            width: "33%",
            key: 'id',
            render: (item) =>
            {
                return item.toString();
            }
        },{
            title: <b>Active</b>,
            dataIndex: 'isActive',
            width: "33%",
            key: 'isActive',
            render: (item) =>
            {
                if(item===true)
                {
                    return "Yes";
                }
                else
                {
                    return "No";
                }
            }},
        // },
        // {
        //     title: <b>Efefct Start Date</b>,
        //     dataIndex: 'effectiveStartDate',
        //     width: "20%",
        //     key: 'effectiveStartDate',
        //     render: (item) =>
        //     {
        //        if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
        //        {
        //            return "-";
        //        }
        //        else
        //        {
        //            return moment(item).format("MM/DD/YYYY");
        //        }
        //     }
        // },
        // {
        //     title: <b>Effective End Date</b>,
        //     dataIndex: 'effectiveEndDate',
        //     width: "20%",
        //     key: 'effectiveEndDate',
        //     render: (item) =>
        //     {
        //        if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
        //        {
        //            return "-";
        //        }
        //        else
        //        {
        //            return moment(item).format("MM/DD/YYYY");
        //        }
        //     }
        // },
        {
            title: <b>Updated Date</b>,
            dataIndex: 'updatedDate',
            width: "33%",
            key: 'updatedDate',
            render: (item) =>
            {
               if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return moment(item).format("MM/DD/YYYY");
               }
            }
        }];
//const { Option } = Select

 
class HearingRoomProfiles extends Component {
    constructor(props) {
        super(props);
        this.state={
            districtOffices: props.profiles.districtOfficesData,
            hearingLocationsData: props.profiles.hearingLocationsData,
            editmode: false,
            // modifiedRoomProfile: {
            //     "id": 0,
            //     "hearingRoomId": 0,
            //     "updatedBy": 0,
            //     "updatedDate": "2018-09-04T20:17:50.992Z",
            //     "isActive": true,
            //     "monStartTime": "string",
            //     "monEndTime": "string",
            //     "tueStartTime": "string",
            //     "tueEndTime": "string",
            //     "wedStartTime": "string",
            //     "wedEndTime": "string",
            //     "thuStartTime": "string",
            //     "thuEndTime": "string",
            //     "friStartTime": "string",
            //     "friEndTime": "string",
            //     "satStartTime": "string",
            //     "satEndTime": "string",
            //     "sunStartTime": "string",
            //     "sunEndTime": "string"
            //   }
        };    
        this.onTimeChange = this.onTimeChange.bind(this);
      //  this.isChecked = this.isChecked.bind(this);
        this.onValueChange =  this.onValueChange.bind(this);
        this.onHrngRoomListRowClick = this.onHrngRoomListRowClick.bind(this);
        this.officesList = this.officesList.bind(this);  
        this.handleChange = this.handleChange.bind(this);
        this.openNotification = this.openNotification.bind(this);
        this.onButtonClick = this.onButtonClick.bind(this);
    }
    componentDidMount()
    {
        this.props.getMyDistrictOffices();
    }
  
componentWillReceiveProps(nextProps) {
    if(this.props.profiles.districtOfficesData !== nextProps.profiles.districtOfficesData && nextProps.profiles.districtOfficesData !== undefined )
    {
        this.setState({districtOffices: nextProps.profiles.districtOfficesData});
        debugger;
        if(nextProps.profiles.districtOfficesData.length >0){this.props.getHearingLocation(parseInt(nextProps.profiles.districtOfficesData[0].officeID));}
    }
    if(this.props.profiles.profilesErrorData !== nextProps.profiles.profilesErrorData)
    {
        let errors = [];
        debugger;
        if(nextProps.profiles.profilesErrorData.status === 422)
        {
    
           Object.keys(nextProps.profiles.profilesErrorData.data).map((keyName, keyIndex) =>
        {
            errors.push(nextProps.profiles.profilesErrorData.data[keyName][0]);
        })
        }
        this.setState({updateErrors: errors});
    }
    if(this.props.profiles.hearingLocationsData !== nextProps.profiles.hearingLocationsData)
    {
        if(nextProps.profiles.hearingLocationsData.length >0)
        {
            this.setState({hearingLocationsData: nextProps.profiles.hearingLocationsData, selectedHearingRoom: nextProps.profiles.hearingLocationsData[0]});
            this.props.getHearingRoomProfilesForRoom( nextProps.profiles.hearingLocationsData[0].hearingLocationId);
        }
        else
        {
            this.setState({hearingRoomProfilesData: []});
        }
    }   
    if(this.props.profiles.hearingRoomProfileById !== nextProps.profiles.hearingRoomProfileById)
    {
  this.setState({selectedRoomProfile: nextProps.profiles.hearingRoomProfileById});
  const modifiedRoomProfile = cloneDeep(nextProps.profiles.hearingRoomProfileById);
  this.setState({ modifiedRoomProfile: modifiedRoomProfile});
  if(nextProps.profiles.updatedStatus === 200)
  {
      this.openNotification('updated');
  }
    }   
    if(this.props.profiles.hearingRoomProfilesData !== nextProps.profiles.hearingRoomProfilesData)
    {
        const hearingRoomProfilesData = [];
        if(nextProps.profiles.hearingRoomProfilesData !== {})
        {
            hearingRoomProfilesData.push(nextProps.profiles.hearingRoomProfilesData.hearingRoomProfile);
     
       if( hearingRoomProfilesData[0] !== null)
       { this.setState({hearingRoomProfilesData: hearingRoomProfilesData, selectedProfId: hearingRoomProfilesData[0].id, selectedRoomProfile: hearingRoomProfilesData[0]});
       const modifiedRoomProfile = cloneDeep( hearingRoomProfilesData[0]);
  this.setState({ modifiedRoomProfile: modifiedRoomProfile});
    }
    else
    {
        this.setState({hearingRoomProfilesData: [],  selectedRoomProfile: {}, modifiedRoomProfile: {}});
        //, selectedProfId: hearingRoomProfilesData[0].id, selectedRoomProfile: {}
        debugger;
    }
}
}
}
onHrngRoomListRowClick = (value) =>
{
    const selectedHearingRoom = this.state.hearingLocationsData.find((item) => {
        return item.hearingLocationId.toString() === value;
    });
this.setState({selectedHearingRoom});
debugger;
this.props.getHearingRoomProfilesForRoom(selectedHearingRoom.hearingLocationId);
}

officesList(districtOffices)
{
let officesList = [];
districtOffices.map((item) => {
    // if(item.officeID === officeID)
    // {
    //     officesList.push(<option key={item.value} selected value={item.value}>{item.text}</option>)
    // } else
    // {
        officesList.push(<option key={item.officeID} value={item.officeID}>{item.name} ({item.officeID})</option>)
   // }
});
return officesList;
}

handleChange = (e) =>
{
    debugger;
    this.props.getHearingLocation(parseInt(e.target.value));
}

onValueChange = (e, idx, field) =>
{
    debugger;
    const { newHearingAuthData } = this.state;
    if(field === 'active')
{
    newHearingAuthData[idx].active = e.target.checked;
    if(e.target.checked === false)
    {
    newHearingAuthData[idx].hearingTime = 0;
    newHearingAuthData[idx].interviewTime = 0;
    newHearingAuthData[idx].reExamTime = 0;
    }
}
else if(field === 'categoryName')
{
    newHearingAuthData[idx].categoryName = e.target.value;
}
else{
    newHearingAuthData[idx][field] = e;
}
    this.setState({newHearingAuthData});
}


// isChecked = (e, idx) =>
// {
//     let { newCreateProfileObj } = this.state;
//     let dayActive = newCreateProfileObj.profileDays[idx].dayActive;
//     newCreateProfileObj.profileDays[idx].dayActive = !dayActive;
//     this.setState({newCreateProfileObj})
// }

getMenuList(hearingLocationsData)
{
let hearingLocationsList = [];
hearingLocationsData.map((item) =>
{
    hearingLocationsList.push(<Menu.Item key={item.hearingLocationId}>{<div style={{textAlign: "center"}}><div style={{ fontSize:16, fontWeight: "bold"}}>Room Number: {item.roomNumber}</div> 
    <div style={{marginTop: "-18px"}}><b>Id:</b> {item.hearingLocationId}<b> |</b> {item.roomDescription}</div></div>}</Menu.Item>)
})
return hearingLocationsList;
}

onTimeChange = (t,ts,v) =>
{
const { modifiedRoomProfile } = this.state;
debugger;
if(t !== null)
{
    modifiedRoomProfile[v] = ts;
}

this.setState({modifiedRoomProfile});
}

openNotification = (type) => {
    notification.open({
      message: 'SUCCESS',
      description: 'The room profile was ' + type + ' successfully!',
      style: {
        width: 600,
        marginLeft: 335 - 600,
        backgroundColor: "#9cd864",
        fontWeight: 'bold'
      },
    });
  }

  onButtonClick = (type) => 
  {
if(type === 'edit')
{
    this.setState({editmode: true});
}
if(type === 'save')
{
    this.setState({editmode: false});
    this.props.updateHearingRoomProfile(this.state.modifiedRoomProfile);
}
if(type === 'cancel')
{
    debugger;
    const modifiedRoomProfile = cloneDeep(this.state.selectedRoomProfile);
    this.setState({editmode: false, modifiedRoomProfile: modifiedRoomProfile}); 
}
  }

    render() {
const {hearingRoomProfilesData} = this.state;
const {modifiedRoomProfile} = this.state;
        let HearingRoomList, selectedRowKeys =[];
        let officesList = [];
        if(this.state.districtOffices !== undefined ) {  officesList=  this.officesList(this.state.districtOffices); }
        {
if(this.state.hearingLocationsData !== undefined)
{            HearingRoomList = this.getMenuList(this.state.hearingLocationsData);
            }    }
            if(this.state.hearingRoomProfilesData !== undefined && this.state.hearingRoomProfilesData !== [])
            {
             //  if(this.state.hearingRoomProfilesData.id === undefined){ 
                   
                this.state.hearingRoomProfilesData.map((item, idx) => 
              {
                  debugger;
                        if(item.id === this.state.selectedProfId)
                        {
                            selectedRowKeys[0] = item.id;
                            return selectedRowKeys;
                        }
              })
            // }
            // else
            // {
            //     selectedRowKeys[0] = this.state.hearingRoomProfilesData.id;
            // }
            }
            const rowSelection = {
                selectedRowKeys: selectedRowKeys,
                  onChange: (selectedRowKeys, selectedRows) => {
                   this.setState({selectedProfId: selectedRows[0].id});
                  },
                  type: "radio"            
                };
        return (  
      <ScrollPanel
            style={{
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0,0,0,0)"
            }}>
            <Row style={{
            marginLeft: "2.5%",
            width: "95%",
            height: "800px",
            border: "2px solid white"}}>
          <div style={{height: "7%", border: "1px solid white"}} >
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>Hearing Room Profiles</span></div>
            <Col span={5} style={{
             height: "93%",
            border: "1px solid white"}}>
            <div style={{
             height: "5%",  paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"}}>Select An Office</div>
             <select  
     style={{ width: '100%' }}   
     value={this.state.value}   
     onChange={this.handleChange} >{officesList}</select>
           <div style={{
             height: "5%",  paddingTop: "7px",  marginTop: "4%", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"}}>Select A Hearing Room</div>
              <ScrollPanel
            style={{
                // width: "95%",
                height: "85%",
                backgroundColor: "#c9e3fa"
            }}>

{this.state.hearingLocationsData && <Menu onClick={(e) => this.onHrngRoomListRowClick(e.key)}
mode = "vertical"
        //  style={{ width: 256 }}
      defaultSelectedKeys={[this.state.selectedHearingRoom.hearingLocationId.toString()]}
        //  defaultOpenKeys={[this.state.selectedEmployee.empid]}
         // selectedKeys={[this.state.selectedEmployee.empid]}
>
{HearingRoomList}

</Menu>
}

 </ScrollPanel></Col>
             <Col style={{
             height: "93%",
            border: "1px solid white"}}>
            
            <div style={{height: "50%", border: "1px solid white", backgroundColor: "#d5d5d5"}}>
            {this.state.selectedHearingRoom && <div style={{
                height: "10%",  paddingTop: "7px", backgroundColor: "#d5d5d5", border: "1px solid white"}}><div style={{paddingLeft: "1%", width: "60%", float: "left"}}>Hearing Room profiles for: <span style={{fontWeight: "bold"}}><b>Room </b>{this.state.selectedHearingRoom.roomNumber}</span></div><div>
                <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}}>
                <Icon type="plus-square"></Icon> New Profile
                </Button>
            
              {/* <Button type="primary"size="small" style={{ marginLeft: 8 , marginTop: "-10px"}} onClick={(e) => this.openModal(e, 'hear')}>
                Hearing Authorization
                </Button><Button type="primary" size="small" style={{ marginLeft: 8 , marginTop: "-10px"}} disabled>
               Add End Date
                </Button> */}
                
                </div></div>}
                <div style={{ height: "100%", overflow: "hidden"}}>                 
                {this.state.hearingRoomProfilesData &&  <Table
                    scroll = {{ y: 250}}
                    bordered={false}
                    size='small'
                    style={{ width: "98%", marginLeft: "1%"}}
                    pagination={false}
                    columns={hearingRoomProfilescolumns}
                    dataSource={hearingRoomProfilesData}
                    rowKey={record => record.id}
                    showHeader
                    rowSelection={rowSelection}
                    onRow={(record) => ({
                        onClick: () => {
                            this.props.getHearingRoomProfileById(record.id);
                            this.setState({selectedProfId: record.id});
                        },
                      })}
                    /> }
                </div>
                </div>
                <div style={{height: "50%", border: "1px solid #d5d5d5",backgroundColor: "#d5d5d5"}}><div style={{
                    height: "10%", paddingTop: "7px", backgroundColor: "#d5d5d5", border: "2px solid white"}}><span style={{paddingLeft: "1%"}}>Profile Detail for the selected hearing room profile.</span> 
                    {this.state.editmode === false ? <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}} onClick={(e) => {
                      this.onButtonClick('edit');  
                    }}>
                  <Icon type="edit"></Icon> Edit Profile
                    </Button> : <span style={{float: "right", marginRight: "10px"}}><Button size="small" type="default" style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} onClick={(e) => {
                            this.onButtonClick('cancel');  
                    }}>
                  <Icon type="close"></Icon> Cancel
                    </Button><Button size="small" type="default" style={{ color:  "white", backgroundColor: "green"}} onClick={(e) => {
                    this.onButtonClick('save');
                    }}>
                  <Icon type="check"></Icon> Save
                </Button></span>}</div>
                       {this.state.modifiedRoomProfile !== undefined && this.state.modifiedRoomProfile.id !== undefined ?  <div style={{ height: "100%", overflow: "hidden"}}>                
                     <Row> <Col span={3} style={{marginTop: "2%"}}><b>Day of Week</b></Col><Col span={3} style={{marginTop: "2%"}}><b>Sunday</b></Col><Col span={3} style={{marginTop: "2%"}}><b>Monday</b></Col><Col span={3} style={{marginTop: "2%"}}><b>Tuesday</b></Col><Col span={3} style={{marginTop: "2%"}}><b>Wednesday</b></Col><Col span={3} style={{marginTop: "2%"}}><b>Thursday</b></Col>
          <Col span={3} style={{marginTop: "2%"}}><b>Friday</b></Col><Col span={3} style={{marginTop: "2%"}}><b>Saturday</b></Col>    
            {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
          <div><Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Col><Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.sunStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'sunStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.monStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'monStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.tueStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'tueStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.wedStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'wedStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.thuStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'thuStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.friStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'friStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.satStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'satStartTime')} /></Col>

            <Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Col><Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.sunEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'sunEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.monEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'monEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.tueEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'tueEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.wedEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'wedEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.thuEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'thuEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.friEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'friEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.satEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'satEndTime')} /></Col>
 </div>
                {this.state.updateErrors !== undefined && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><div> {this.state.updateErrors}</div></div>} </Row>
                    
               </div> : <div>No Profile Selected.</div>}
               </div></Col>
        </Row></ScrollPanel>);
}
}
const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getHearingLocation,
            getHearingRoomProfilesForRoom,
            getMyDistrictOffices,
            getHearingRoomProfileById,
            updateHearingRoomProfile
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(HearingRoomProfiles);
