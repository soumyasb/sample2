import React, { Component } from "react";
import moment from 'moment';
import { Modal, Form, Input, Select, Checkbox, DatePicker, Button } from 'antd';
//import { bindInstanceMethods } from '../../../utils';

const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;

const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
};

const getModalSettings = ({ actionType, onOk, onCancel }) => {
    let title, okText = '';
    let footer = [];

    switch(actionType) {
        case 'create': 
            title = 'Create News Item';
            okText = 'Create';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'edit': 
            title = 'Edit News Item';
            okText = 'Save';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        case 'details': 
            title = 'News Item Details';
            okText = 'Details';
            footer = [
                <Button key="Close" onClick={onCancel}>Close</Button>
            ];
            break;
        case 'delete': 
            title = 'Delete News Item';
            okText = 'Delete';
            footer = [
                <Button key="Cancel" onClick={onCancel}>Cancel</Button>,
                <Button type="primary" key="Ok" onClick={onOk}>{okText}</Button>
            ];
            break;
        default: 
            title = 'Create News Item';
    }

    return {
        title,
        okText,
        footer,
    }

}
const getOfficeDetails = (newsItemObj, officeDetailsObj, actionType) =>   
 {  
     debugger; 
     let officedetails = [], officelist = [], officegrp = [];   
     if(actionType === 'create')   
     {   
      officelist = officeDetailsObj.offices.map((office) =>    
     <Option key={office.officeId}>{office.officeName}</Option>   
     );   
 }   
 else if (actionType === 'edit') {   
     debugger;
    officeDetailsObj.offices.forEach(element => {   
          if(newsItemObj.officeGroup!== null && newsItemObj.officeGroup.includes(element.officeId))   
          {   
             officegrp.push(element.officeId);   
        officelist.push(<Option key={element.officeId}>{element.officeName}</Option>);   
          }   
         else{   
             officelist.push(<Option key={element.officeId}>{element.officeName}</Option>);   
         }   
     });      
         
 }   
 else
 {

 }
 officedetails = {officelist, officegrp};   
    
  return officedetails;   
} 

// getPriority = (priority) =>
// {
//     switch(priority)
//            {
//                case 'A':
//                return "High";
//                case 'B':
//                return "Medium";
//                case 'C':
//                return "Low";
//            }
// }
class NewsModal extends Component {
    constructor(props) {
        super(props);
      if(props.actionType === 'create')
      {
        this.state ={
            newsItemObj: props.newsItemObj,
            value: [],
            checked: false
        }
      }
       else
       { this.state ={
            newsItemObj: props.newsItemObj,
            value: props.newsItemObj.officeGroup,
            checked: false
        }
    }
        this.onPriorityChange = this.onPriorityChange.bind(this);   
        this.onNewsTextChange = this.onNewsTextChange.bind(this);   
        this.onSubjectChange = this.onSubjectChange.bind(this); 
        this.onCancel = this.onCancel.bind(this); 
      //  this.onchecked = this.onchecked.bind(this);
       // this.handleChange = this.handleChange.bind(this);
        //bindInstanceMethods(this);
    }
    // componentWillMount()
    // {
    //     if(this.props.actionType === 'edit')
    //     {
    //     this.setState({value: this.props.newsItemObj.officeGroup});
    //     }
    //     else{
    //         this.setState({value: []});
    //     }
    // }

    componentWillReceiveProps(nextProps) {
        if (this.props.newsItemObj !== nextProps.newsItemObj) {
            
            this.setState({ value: nextProps.newsItemObj.officeGroup, newsItemObj: nextProps.newsItemObj });
           
        } 
    
    if(nextProps.actionType === 'create')
    {
        this.setState({ value: []});
    }
    }

//     static getDerivedStateFromProps(nextProps, prevState)
//     {
//         debugger;
//         if(nextProps.newsItemObj !== prevState.newsItemObj)
//         return {
// newsItemObj: nextProps.newsItemObj
//         }
//         else
//         return null
//     }

    onPriorityChange(e, val) {
        const { newsItemObj } = this.state;
        newsItemObj.priority = val;
        this.setState({ newsItemObj });
    }

    onNewsTextChange(e) {
        const { newsItemObj } = this.state;
        newsItemObj.newsText = e.target.value;
        this.setState({ newsItemObj });
    }

    onSubjectChange(e) {
        const { newsItemObj } = this.state;
        newsItemObj.subject = e.target.value;
        this.setState({ newsItemObj });
    }

    handleOk() {
        debugger;
        this.props.onOk(this.state.newsItemObj);
    }

    onCancel() {
        this.setState({value: []});
        this.props.onCancel();
    }

    handleChange = (value) => {
        debugger;
       this.setState({value: value});
    }

    // onchecked()
    //     {
    //     this.setState({checked: !this.state.checked});
    //     }
    
     

    render() {
        let { newsItemObj } = this.state;
        const modalSettings = getModalSettings(this.props);
       let officedetails = [];
       officedetails = getOfficeDetails(this.props.newsItemObj, this.props.officeDetailsObj, this.props.actionType);
      // const newsPriority = getPriority(this.props.newsItemObj.priority);  
       
       

        return (
         
            <Modal
                visible={this.props.modalVisible}
                onOk={this.handleOk}
                destroyOnClose={true}
                onCancel={this.onCancel}
                title={modalSettings.title}
                okText={modalSettings.okText} 
                footer={modalSettings.footer}
                width={'750px'}
            >
                <div>
                {this.state.newsItemObj !== undefined || this.state.newsItemObj !== null ?
                    <Form layout={'horizontal'}>
                        <FormItem
                            label="Priority"
                            {...formItemLayout}
                        > 
                            {this.props.actionType === 'create' || this.props.actionType === 'edit' ?                             
                            <Select value={newsItemObj.priority} onChange={this.onPriorityChange}>
                               <Option value="A">Urgent</Option>
                               <Option value="B">Normal</Option>
                               <Option value="C">Low</Option>
                            </Select>
                            :
                            <div>{newsItemObj.priority === 'A' ? "High" :
                            this.props.priority === 'B' ? "Medium" : "Low"
                            }</div>                         
                            }
                        </FormItem>
                        <FormItem
                            label="Subject"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <Input value={newsItemObj.subject} placeholder="Subject" onChange={this.onSubjectChange} />
                            :
                            <div>{newsItemObj.subject}</div>                             
                            }
                        </FormItem>
                        <FormItem
                            label="News Text"
                            {...formItemLayout}
                        >
                         {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <TextArea value={newsItemObj.newsText} rows="6" onChange={this.onNewsTextChange} />
                            :
                            <div>{newsItemObj.newsText}</div>                             
                            }
                        </FormItem>
                        <FormItem
                            label="Start Date"
                            {...formItemLayout}
                        >
                        {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <DatePicker placeholder="Start Date"
                                defaultValue={moment(newsItemObj.startDate, 'YYYY-MM-DD')} onChange={() => {}} />
                                :
                            <div>{moment(newsItemObj.startDate).format("MM/DD/YYYY").toString()}</div>      
                                            
                            }
                        </FormItem>
                        <FormItem
                            label="End Date"
                            {...formItemLayout}
                        >
                        {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <DatePicker placeholder="End Date"
                                defaultValue={moment(newsItemObj.endDate, 'YYYY-MM-DD')} onChange={() => {}} />
                                :
                                <div>{moment(newsItemObj.endDate).format("MM/DD/YYYY").toString()}</div>                             
                                }
                        </FormItem>
                       {(this.props.actionType === 'create' || this.props.actionType === 'edit') && newsItemObj.employeeType !== 'O' ?
                       <FormItem
                            label=""
                            {...formItemLayout}
                        >
                           <Checkbox checked={this.state.checked} onChange={this.onchecked}  placeholder="input placeholder">
                                All offices in your region?
                            </Checkbox>                        
                       </FormItem>
                       : <div></div>
                       }
                       {this.state.checked || newsItemObj.employeeType === 'O'? <div></div> :
                        <FormItem label="News Item published to:" {...formItemLayout}>      
                            {this.props.actionType === 'create' || this.props.actionType === 'edit' ? 
                            <Select   
     mode="multiple"   
     style={{ width: '100%' }}   
   //  defaultValue={newsItemObj.officeGroup}
     placeholder="Please select"   
     value={this.state.value}   
     onChange={this.handleChange}   
   >   
   
     {officedetails.officelist}   
   </Select>   
    :
    <div></div> 
                        }
                            </FormItem> 
                       }
                    </Form>
                        :
                        <div></div>
                                    }
                </div>  
            </Modal>
        
        );
    }
}

export default NewsModal;
