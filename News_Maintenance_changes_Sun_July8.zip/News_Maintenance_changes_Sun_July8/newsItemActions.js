import newsItemData from '../.././mocks/getnewsitems.json'
import createNewsItemData from '../.././mocks/createnewsitem.json'
import editNewsItemData from '../.././mocks/Editnewsitem.json'
import newsItemDetailsData from '../.././mocks/newsitembyid.json'
import officeDetailsData from '../.././mocks/officedetails.json'

//NEWS ITEMS PAGE ACTIONS
export const getNewsItemPage = data => ({
  type: "GET_NEWSITEMS",
  data: data
});

export const initNewsItemPage = () => {
  debugger;
  return dispatch => {
      dispatch(getNewsItemPage(newsItemData));
  };
};

export const getCreateNewsItemObj = data => ({
  type: "GET_CREATENEWSITEM",
  data: data
});

export const initCreateNewsItemObj = () => {
  return dispatch => {
    dispatch(getCreateNewsItemObj(createNewsItemData));
};
};

export const getEditNewsItemObj = data => ({
  type: "GET_EDITNEWSITEM",
  data: data
});

export const startGettingEditData = () => ({
  type: "START_GET_EDITDATA"
});

export const initEditNewsItemObj = (newsId) => {
  
  return dispatch => {
   // dispatch(startGettingEditData());
    // axios.get("http://localhost:32610/api/NewsItems/EditNewsItem/"+newsId).then(response => {
    //   dispatch(getEditNewsItemObj(response.data));
    //   console.log ("data from get edit news items api");
    //   console.log(response.data);
    // });
    dispatch(getEditNewsItemObj(editNewsItemData));
};
  };

  export const getNewsItemDetailsObj = data => ({
    type: "GET_NEWSITEMDETAILS",
    data: data
  });

  export const startGettingDetailsData = () => ({
    type: "START_GET_DETAILSDATA"
  });
  
  export const initNewsItemDetails = (newsId) => {
    
    return dispatch => {
     // dispatch(startGettingDetailsData());
      // axios.get("http://localhost:32610/api/NewsItems/EditNewsItem/"+newsId).then(response => {
      //   dispatch(getEditNewsItemObj(response.data));
      //   console.log ("data from get edit news items api");
      //   console.log(response.data);
      // });
      dispatch(getNewsItemDetailsObj(newsItemDetailsData));
  };
    };

    export const getSaveNewsItemStatus = data => ({
      type: "GET_SAVENEWSITEM",
      data: data
    });
    
    export const initSaveNewsItem = () => {
      return dispatch => {
        dispatch(getSaveNewsItemStatus(createNewsItemData));
    };
    };

    export const getModifyNewsItemStatus = data => ({
      //save operation
    });
    
    export const initModifyNewsItem = (newsItem) => {
      return dispatch => {
        dispatch(getModifyNewsItemStatus(newsItem));
    };
    };

    export const getDeleteNewsItemStatus = data => ({
      type: "GET_DELETETENEWSITEM",
      data: data
    });
    
    export const initDeleteNewsItem = () => {
      return dispatch => {
        dispatch(getDeleteNewsItemStatus(createNewsItemData));
    };
    };

    export const getOfficeDetailsData = data => ({
      type: "GET_OFFICEDETAILS",
      data: data
    });
    
    export const initGetOfficeDetails = () => {
      return dispatch => {
        dispatch(getOfficeDetailsData(officeDetailsData));
    };
    };
