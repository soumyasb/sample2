import { Form, Input, Button, Checkbox } from 'antd';
import React from 'react';

const FormItem = Form.Item;

class createnewsitem extends React.Component {
      render() {
 
          return (
            <Form onSubmit={this.handleSubmit}>
              <FormItem
                label="Priority"
              >
                {
                  (<Input />)
                }
              </FormItem>
              <FormItem
                label="Subject"
              >
                {(
                  <Input />
                )}
              </FormItem>
              <FormItem
                label="News Text"
              >
                {(
                  <Input />
                )}
              </FormItem>
              <FormItem
                label= "Start Date">   
               {(
                  <Input />
                )}
              </FormItem>
              <FormItem
                label="End Date"
              >
                {(
                  <Input />
                )}
              </FormItem>
              <FormItem>
              <Checkbox>All offices in your region?</Checkbox>
              </FormItem>
              <FormItem >
                <Button type="primary" htmlType="submit">Create</Button>
              </FormItem>
            </Form>
          );
}
}


export default createnewsitem;