import React, { Component } from 'react';
import { searchCases, getCustomerDetails } from "../../../store/actions/caseActions";
import { withRouter } from "react-router-dom";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

class CustomerDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
            dlNumber: this.props.match.params.dlNumber,
            customerDetailsObj: this.props.case.customerDetailsObj
            // whatever the props needed
        };
    }    
    componentDidMount() {
        debugger;
        this.props.getCustomerDetails(this.state.dlNumber);
        //this.setState({ customerDetailsObj: this.props.case.customerDetailsObj});
    }

    componentWillReceiveProps(nextProps) {
        debugger;
        if (this.props.match.params !== nextProps.match.params) {
        //     // const params = new URLSearchParams(nextProps.location.search);
        //     // const searchText =  params.get('searchText') ? params.get('searchText') : '';
        //     // const params = nextProps.location.search.split("=");
        //     // const searchText = params[1];
            const dlNumber =  nextProps.match.params.dlNumber || '';
            this.props.getCustomerDetails(dlNumber);
        }

        if (this.props.case.customerDetailsObj !== nextProps.case.customerDetailsObj) {
            if(nextProps.case.customerDetailsObj !== undefined)
            {
            this.setState({ customerDetailsObj: nextProps.case.customerDetailsObj});
            }
        }
    }
render() {

    return (
  <div>
    <Row type="flex" justify="center">
    <Row>
        {this.state.customerDetailsObj && this.state.customerDetailsObj.City}
    </Row>
   <Row>
     <Col>
      <Row gutter={16}>     
        <Col span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
        <Col  span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
        <Col  span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
        <Col span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
     </Col>
    </Row>

    <Row>
      <Col >
      D26 validation message (If D26 validationOK === false)
      Usual message (If present)
      Usual Error messages (If present)
      </Col>
    </Row>

    <Row>
        <Col>
        <Row>
          To display the DCS differences if any. Hide if none
          </Row>
          <Row>
          To display the financial responsibilities if any. Hide if none
        </Row>
        </Col>
    </Row>

    <Row>
      <Col > 
      Title - 'Cases', Add a case button
      List of the cases under Customer's name. Scrollable list (Not pagination)
      </Col>
    </Row>
    </Row>
    </div>
); 
}
}


const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getCustomerDetails
           // Whatever the actions needed 
        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CustomerDetails));