import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { withRouter } from "react-router-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Row, Col } from 'antd';

const columns = [
    {
        title: 'DL Number',
        dataIndex: 'dlNumber',
        width: 150,
        key: 'dlNumber',
        render: text =><a href="">{text}</a>,
      },{
  title: 'Full Name',
  dataIndex: 'fullName',
  key: 'fullName',
  width: 150,
  render: text => <a href="">{text}</a>,
}];
// , {
//   title: 'Last Name',
//   dataIndex: 'LastName',
//   key: 'LastName',
//   width: 150,
// } ];

class Search extends Component {
    constructor(props) {
        super(props);

        this.state={
            searchList: props.case.searchList
        };
    }    

    componentDidMount() {
        debugger;
        // const params = new URLSearchParams(this.props.location.search);
        // const searchText =  params.get('searchText') ? params.get('searchText') : '';
        // const params = this.props.location.search.split("=");
        // const searchText = params[1];
        const searchText =  this.props.match.params.searchText || '';
        this.props.searchCases(searchText);

    }

    componentWillReceiveProps(nextProps) {
        debugger;
        if (this.props.match.params !== nextProps.match.params) {
            // const params = new URLSearchParams(nextProps.location.search);
            // const searchText =  params.get('searchText') ? params.get('searchText') : '';
            // const params = nextProps.location.search.split("=");
            // const searchText = params[1];
            const searchText =  nextProps.match.params.searchText || '';
            this.props.searchCases(searchText);
        }

        if (this.props.case.searchList !== nextProps.case.searchList) {
            this.setState({ searchList: nextProps.case.searchList});
        }
    }

   

    render() {
        // const params = new URLSearchParams(this.props.location.search);
        // const searchText =  params.get('searchText') ? params.get('searchText') : '';
        // const params = this.props.location.search.split("=");
        // const searchText = params[1];
        let results = [];
        if(this.state.searchList !== undefined)
        {
        results = this.state.searchList.results.map(result => {
            return {
                dlNumber: result.dlNumber,
                fullName: result.FirstName +' '+result.LastName
            }
        });
    }
        const searchText =  this.props.match.params.searchText || '';
        debugger;
    return (
        <div>
                <Row type="flex" justify="center">
                <Col span={15}>
        <div >
        {this.state.searchList && <Table rowKey = "dlNumber" 
        bordered = {false} 
        size = 'default'
        onRow={(record) => {
            return {
              onClick: () => {
                debugger;
                if (record.dlNumber) {
                    this.props.history.push(`/customerDetails/dlNumber/${record.dlNumber}`);
                  }
            }
            };
          }}
        
        scroll={{}}
        title={() => <div><span><h1>Search Results for:</h1></span><span>{searchText}</span></div>} 
        footer={() => <p>{this.state.searchList.ResultCount} results found</p>} 
        showHeader 
        columns={columns} 
        dataSource={results}
       />
    }
    </div>
 
    </Col>
    </Row>
    </div>   );
}    
}

    
const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            searchCases
        },
        dispatch
    );
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Search));

