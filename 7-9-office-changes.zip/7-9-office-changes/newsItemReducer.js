const newsItemReducerDefaultState = {
};

const newsitemreducer = (state = newsItemReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_NEWSITEMS": {
      return { ...state, list: action.data };
    }
    case "GET_CREATENEWSITEM":
    {
      return { ...state, newsItemObj: action.data};
    }
    case "GET_EDITNEWSITEM":
    {
      return { ...state, newsItemObj: action.data};
    }
    case "GET_OFFICEDETAILS":
    {
      return { ...state, officeDetailsObj: action.data};
    }
    case "GET_NEWSITEMDETAILS":
    {
      return { ...state, newsItemObj: action.data};
    }
    case "GET_EDITDATA":
    {
      return { ...state, isLoading: true};
    }
    default:
      return state;
  }
};

export default newsitemreducer;
