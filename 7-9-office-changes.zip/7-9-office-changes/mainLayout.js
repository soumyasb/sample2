import React from "react";

import { Row } from "antd";
import MainHeader from "../components/header";
import MainSider from "../components/sider";
import MainContent from "../components/content";
import MainFooter from "../components/footer";

const mainLayout = () => (
  <Row style={{ height: "100%" }}>
    <MainHeader />
  {/* <MainSider /> */}
    <MainContent />
    <MainFooter />
  </Row>
);

export default mainLayout;
