import { createStore, combineReducers, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";

import homePageReducer from "../store/reducers/homePageReducer";
import uiReducer from "../store/reducers/uiReducer";
import newsitemreducer from "../store/reducers/newsItemReducer";

export default () => {
  const composeEnhancers =
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
  const store = createStore(
    combineReducers({
      homePage: homePageReducer,
      ui: uiReducer,
      newsItem: newsitemreducer
    }),
    composeEnhancers(applyMiddleware(thunk))
  );
  return store;
};
