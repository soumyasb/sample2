const newsItemReducerDefaultState = {};

const newsitemreducer = (state = newsItemReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_NEWSITEMS": {
      return { ...state, ...action.data };
    }

    default:
      return state;
  }
};

export default newsitemreducer;
