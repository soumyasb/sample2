import newsItemData from '../.././mocks/getnewsitems.json'

//HOMEPAGE ACTIONS
export const getNewsItemPage = data => ({
  type: "GET_NEWSITEMS",
  data: data
});

export const initNewsItemPage = () => {
  return dispatch => {
      dispatch(getNewsItemPage(newsItemData));
  };
};
