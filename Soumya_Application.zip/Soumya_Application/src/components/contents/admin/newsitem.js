import React, { Component } from "react";
import ReactDOM from 'react-dom';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import {DataTable} from 'primereact/components/datatable/DataTable';
import {Column} from 'primereact/components/column/Column';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { initNewsItemPage, getNewsItemPage } from "../../../store/actions/newsItemActions";
import {Input, Table, Icon, Switch, Radio, Divider, Form, Modal, Button } from 'antd';
import { showModal } from "../../../store/actions/uiActions";
import moment, { calendarFormat } from "moment";

const data = [];

const FormItem = Form.Item;

const title = () => 'News Items';
const showHeader = true;
const scroll = { y: 240 };
const pagination = { position: 'bottom' };



class newsitem extends React.Component {
    localState = {};
    componentWillMount(){
        this.props.initNewsItemPage();
        this.setState({newsItem:data});
    }

    showModal = (e,actype) => {
            this.props.showModal(true);
      };
      handleOk = e => {
        this.props.showModal(false);
      };
      handleCancel = e => {
        this.props.showModal(false);
      };
    constructor(props) {
        super(props);
        this.columns = [
            {
                title: 'Author Name',
                dataIndex: 'authorName',
                width: '10%',
                key: 'authorName'
                
            },
            {
                title: 'Priority',
                dataIndex: 'priority',
                width: '5%',
                key: 'priority'

            },
            {
                title: 'Subject',
                dataIndex: 'subject',
                width: '10%',
                key: 'subject'
            },
            {
                title: 'News Text',
                dataIndex: 'newsText',
                width: '50%',
                key: 'newsText',
                render: (newsText) => 
                {
                    return <div style={{wordBreak: "keep-all"}}><p>{newsText}</p></div>
                }

            },
            {
                title: 'Create Date',
                dataIndex: 'createDate',
                width: '7%',
                key: 'createDate',
                render: (createDate) =>
                    moment(createDate).format("MM/DD/YYYY")
            },
            {
                title: 'Start Date',
                dataIndex: 'startDate',
                width: '7%',
                key: 'startDate',
                render: (startDate) =>
                    moment(startDate).format("MM/DD/YYYY")
            },
            {
                title: 'End Date',
                dataIndex: 'endDate',
                width: '7%',
                key: 'endDate',
                render: (endDate) =>
                moment(endDate).format("MM/DD/YYYY")
            },
            {
                 width: '4%',
                render: () => {
                    return (
                        <div style={{textAlign: "center"}}>
                            <a onClick={e => this.showModal(e)}>Edit</a>
                            <br/><a onClick={e => this.showModal(e)}>Details</a>
                            <br/><a onClick={e => this.showModal(e)}>Delete</a>
                        </div>
                    );
                },
            },
        ];
    }

    render() {
        const newsItemProps = this.props.newsItem;
        const result = Object.keys(newsItemProps).map(function (key) {
            return newsItemProps[key];
        });
        console.log(result);
        console.log(this.props.result);
        this.state = {result};

        const columns = this.columns.map((col) => {
            return {
                ...col,
                onCell: record => ({
                    record,
                    // inputType: col.dataIndex,
                    // dataIndex: col.dataIndex,
                    title: col.title
                }),
            };
        });


        return (
            <ScrollPanel
                style={{
                    width: "100%",
                    height: "calc(100% - 40px)",
                    backgroundColor: "rgba(0,0,0,0)"
                }}
            >
                <div>
<div>

    </div>
                   <Table
                        size= {"small"}
                        rowKey = "newsId"
                        title={() => <div><div><h4>News Items</h4>  <div><Button type="primary" onClick={(e) => this.showModal(e,"create")}>Create New</Button></div>
                        <Modal
            visible={this.props.ui.modalVisible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
            title="Create a new News Item"
            okText={this.props.ui.actype}      
          >
        Hello World
          </Modal></div>
              </div>} 
              showHeader = {true}
                        bordered
                        expandRowByClick={true}
                        dataSource={this.state.result}
                        expandedRowRender={record => <p style={{ margin:10 }}>{record.newsText}</p>}
                        columns={columns}
                        pagination={{ pageSize: 8}}
                        scroll={{ y: 800, x: 800 }}
                      />
                </div>
             </ScrollPanel>
        );
    }
}

const mapStateToProps = state => {
    return {
        newsItem: state.newsItem,
        ui: state.ui
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getNewsItemPage,
            initNewsItemPage,
            showModal
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(newsitem);
