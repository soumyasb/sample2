import React, { Component } from "react";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { initNewsItemPage, getNewsItemPage, initCreateNewsItemObj, getCreateNewsItemObj } from "../../../store/actions/newsItemActions";
import { Table, Button } from 'antd';
import { showModal } from "../../../store/actions/uiActions";
import moment from "moment";
import NewsModal from './NewsModal';

// const data = [];

// //const FormItem = Form.Item;

// const title = () => 'News Items';
// const showHeader = true;
// const scroll = { y: 240 };
// const pagination = { position: 'bottom' };



class newsitem extends React.Component {
//     // localState = {};
//     // componentWillMount(){
//     //     this.props.initNewsItemPage();
//     //     this.setState({newsItem:data});
//     // }

//     // showModal = (e,actype) => {
//     //         this.props.showModal(true);
//     //   };
//     //   handleOk = e => {
//     //     this.props.showModal(false);
//     //   };
//     //   handleCancel = e => {
//     //     this.props.showModal(false);
//     //   };
    constructor(props) {
        super(props);
        this.columns = [
            {
                title: 'Author Name',
                dataIndex: 'authorName',
                width: '80px',
                key: 'authorName'
                
            },
            {
                title: 'Priority',
                dataIndex: 'priority',
                width: '50px',
                key: 'priority',
                render: (priority) =>
                {
                    if(priority == "A")
                    {
                        return <p> Urgent </p>
                    }
                    if(priority == "B")
                    {
                        return <p> Normal </p>
                    }
                    if(priority == "C")
                    {
                        return <p> Low </p>
                    }
                }

            },
            {
                title: 'Subject',
                dataIndex: 'subject',
                width: '100px',
                key: 'subject'
            },
            // {
            //     title: 'News Text',
            //     dataIndex: 'newsText',
            //     width: '50%',
            //     key: 'newsText',
            //     render: (newsText) => 
            //     {
            //         return <div style={{wordBreak: "keep-all"}}><p>{newsText}</p></div>
            //     }

            // },
            {
                title: 'Create Date',
                dataIndex: 'createDate',
                width: '70px',
                key: 'createDate',
                render: (createDate) =>
                    moment(createDate).format("MM/DD/YYYY")
            },
            {
                title: 'Start Date',
                dataIndex: 'startDate',
                width: '70px',
                key: 'startDate',
                render: (startDate) =>
                    moment(startDate).format("MM/DD/YYYY")
            },
            {
                title: 'End Date',
                dataIndex: 'endDate',
                width: '70px',
                key: 'endDate',
                render: (endDate) =>
                moment(endDate).format("MM/DD/YYYY")
            },
            {
                 width: '40px',
                render: (text, item) => {
                    return (
                        <div style={{textAlign: "center"}}>
                            <a onClick={e => this.showModal(e, 'edit', item.newsId)}>Edit</a>
                            <br/><a onClick={e => this.showModal(e, 'details', item.newsId)}>Details</a>
                            <br/><a onClick={e => this.showModal(e, 'delete', item.newsId)}>Delete</a>
                        </div>
                    );
                },
            },
        ];

        // this.state = {
        //     newsItemObj}

        this.showModal = this.showModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
    }

    componentWillMount() {
        this.props.initNewsItemPage();
        this.props.initCreateNewsItemObj();
    }

    // showModal(e, actype, newsItemObj) {
    //     this.props.showModal(true, actype, newsItemObj);
    // }
    showModal(e, actype, newsId) {
        this.props.showModal(true, actype );
        if(newsId) { 
                        const newsItemObj =  this.props.newsItem.newsItem.list.find(n => n.newsId === newsId); 
                        this.setState({ newsItemObj });  
                 } 
          
    }

    handleOk(e) {
        this.props.showModal(false);
    }

    handleCancel(e) {
        this.props.showModal(false);
    }

    render() {      

        // const newsItemProps = this.props.newsItem;
        // const result = Object.keys(newsItemProps).map(function (key) {
        //     return newsItemProps[key];
        // });
        // this.state = {result};
        debugger;
        console.log(this.props.newsItem.newsItem);
      // const data = this.props.newsItem.newsItem.list;
        const columns = this.columns.map((col) => {
            return {
                ...col,
                onCell: record => ({
                    record,
                    // inputType: col.dataIndex,
                    // dataIndex: col.dataIndex,
                    title: col.title
                }),
            };
        });

        return (
            <ScrollPanel
                style={{
                    width: "100%",
                    height: "calc(100% - 40px)",
                    backgroundColor: "rgba(0,0,0,0)"
                }}
            >
               <div style ={{ alignContent: "center"}}>

                   <Table
                        size= {"small"}
                       style= {{width: "80%", height: "80%"}}
                        rowKey = "newsId"
                        title={() => <div>
                            {/* <div> */}
                                News Items<div><Button type="primary" onClick={(e) => this.showModal(e, 'create')}>Create New</Button></div>                      
              </div>} 
              showHeader = {true}
                        bordered
                        //backgroundColor= {"white"}
                        expandRowByClick={true}
                        dataSource={this.props.newsItem.newsItem}
                        //dataSource ={this.state.result}
                        expandedRowRender={record => <p style={{ margin:10, wordBreak: "keep-all" }}>{record.newsText}</p>}
                        columns={columns}
                        pagination={{ pageSize: 8}}
                        //scroll={{ y: 800, x: 200 }}
                      />
                </div>
                
             
                    <NewsModal 
                      modalVisible={this.props.ui.modalVisible} 
                     onOk={this.handleOk} 
                      onCancel={this.handleCancel} 
                      actionType={this.props.ui.actionType} 
                       newsItemObj={this.props.newsItem.newsItemObj} 
                 /> 
               
                
        
          </ScrollPanel>
     
        );
    }
}

const mapStateToProps = state => {
    return {
        newsItem: state.newsItem,
        newsItemObj: state.newsItemObj,
        ui: state.ui
        //newsItemObj: state.ui.newsItemObj
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getCreateNewsItemObj,
           getNewsItemPage,
           initCreateNewsItemObj,
            initNewsItemPage,
            showModal
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(newsitem);
