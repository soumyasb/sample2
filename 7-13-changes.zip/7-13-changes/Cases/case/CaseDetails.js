import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

class CaseDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
            // whatever the props needed
        };
    }    

    render() {

        return (
  <div>
    <Row type="flex" justify="center">
    <Row>
        document Icon, Title, Edit, Cancel, Save buttons
    </Row>
   <Row>
     <Col>
      <Row gutter={0}>     
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
     </Col>
     <Col>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={0}>
        <Col span={0}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      </Col>
     <Col>
     Show financial responsibilities list when selected reason is 950
     </Col>
    </Row>
    </Row>
    </div>
); 
    }
}

const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
           // Whatever the actions needed 
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CaseDetails);