import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

class CustomerDetails extends Component {
    constructor(props) {
        super(props);

        this.state={
            // whatever the props needed
        };
    }    

render() {

    return (
  <div>
    <Row type="flex" justify="center">
    <Row>
        id card Icon, Customer name, Edit, Cancel, Save buttons
    </Row>
   <Row>
     <Col>
      <Row gutter={16}>     
        <Col span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
        <Col  span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
        <Col  span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
        <Col span={6}>
        <div className="gutter-box">col-6</div>
        </Col>
      </Row>
     </Col>
    </Row>

    <Row>
      <Col >
      D26 validation message (If D26 validationOK === false)
      Usual message (If present)
      Usual Error messages (If present)
      </Col>
    </Row>

    <Row>
        <Col>
        <Row>
          To display the DCS differences if any. Hide if none
          </Row>
          <Row>
          To display the financial responsibilities if any. Hide if none
        </Row>
        </Col>
    </Row>

    <Row>
      <Col > 
      Title - 'Cases', Add a case button
      List of the cases under Customer's name. Scrollable list (Not pagination)
      </Col>
    </Row>
    </Row>
    </div>
); 
}
}


const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
           // Whatever the actions needed 
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(CustomerDetails);