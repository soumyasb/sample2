import React, { Component } from 'react';
import { searchCases } from "../../../store/actions/caseActions";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Row, Col } from 'antd';

const columns = [
    {
        title: 'DL Number',
        dataIndex: 'dlNumber',
        width: 150,
        key: 'dlNumber',
      },{
  title: 'First Name',
  dataIndex: 'FirstName',
  key: 'FirstName',
  width: 150,
  render: text => <a href="">{text}</a>,
}, {
  title: 'Last Name',
  dataIndex: 'LastName',
  key: 'LastName',
  width: 150,
} ];

class Search extends Component {
    constructor(props) {
        super(props);

        this.state={
            searchList: props.case.searchList
        };
    }    

    componentDidMount() {
        debugger;
        // const params = new URLSearchParams(this.props.location.search);
        // const searchText =  params.get('searchText') ? params.get('searchText') : '';
        const params = this.props.location.search.split("=");
        const searchText = params[1];
        this.props.searchCases(searchText);

    }

    componentWillReceiveProps(nextProps) {
        debugger;
        if (this.props.location.search !== nextProps.location.search) {
            // const params = new URLSearchParams(nextProps.location.search);
            // const searchText =  params.get('searchText') ? params.get('searchText') : '';
            const params = nextProps.location.search.split("=");
            const searchText = params[1];
            this.props.searchCases(searchText);
        }

        if (this.props.case.searchList !== nextProps.case.searchList) {
            this.setState({ searchList: nextProps.case.searchList});
        }
    }

    render() {
        // const params = new URLSearchParams(this.props.location.search);
        // const searchText =  params.get('searchText') ? params.get('searchText') : '';
        const params = this.props.location.search.split("=");
        const searchText = params[1];
        debugger;
    return (
        <div>
                <Row type="flex" justify="center">
                <Col span={15}>
        <div >
        {this.state.searchList && <Table rowKey = "dlNumber" 
        bordered = {false} 
        size = 'default'
        scroll="none" 
        title={() => <div><span><h1>Search Results for:</h1></span><span>{searchText}</span></div>} 
        footer={() => <p>{this.state.searchList.results.length} results found</p>} 
        showHeader 
        columns={columns} 
        dataSource={this.state.searchList.results}
        onRow={(record) => {
            return {
              onClick: () => {}
            };
          }} />
    }
    </div>
 
    </Col>
    </Row>
    </div>   );
}    
}

    
const mapStateToProps = state => {
    return {
       case: state.case
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            searchCases
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(Search);

