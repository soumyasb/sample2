import React from "react";
import { Switch, Route } from 'react-router-dom'

import HomePage from "./contents/home/homepage";
import NewsPage from "./contents/admin/NewsItem";
import Search from "./contents/case/Search";
const content = () => (
  <div className="contentlayout">
    <Switch>
      <Route exact path="/" component={HomePage} />
      <Route exact path="/news" component={NewsPage} />
      <Route path="/search" component={Search} />
      {/* <Route path='/search' 
          render={ props => <Search {...props} />}
        /> */}
    </Switch>
  </div>
);

export default content;














      
