import React from "react";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { initNewsItemPage, initCreateNewsItemObj, initEditNewsItemObj, initGetOfficeDetails, initNewsItemDetails, 
    initDeleteNewsItem, initModifyNewsItem,initSaveNewsItem } from "../../../store/actions/newsItemActions";
import { Table, Button, Icon, Divider } from 'antd';
import { showModal } from "../../../store/actions/uiActions";
import moment from "moment";
import NewsModal from './NewsModal';

class NewsItem extends React.Component {

    constructor(props) {
        super(props);
        this.columns = [
            {
                title: 'Author Name',
                dataIndex: 'AuthorName',
                width: '6%',
                key: 'AuthorName'
                
            },
            {
                title: 'Priority',
                dataIndex: 'Priority',
                width: '6%',
                key: 'Priority',
                render: (Priority) =>
                {
                    if(Priority === "A")
                    {
                        return <p> Urgent </p>
                    }
                    if(Priority === "B")
                    {
                        return <p> Normal </p>
                    }
                    if(Priority === "C")
                    {
                        return <p> Low </p>
                    }
                }

            },
            {
                title: 'Subject',
                dataIndex: 'Subject',
                width: '10%',
                key: 'Subject'
            },
            {
                title: 'News Text',
                dataIndex: 'NewsText',
                width: '42%',
                key: 'NewsText',
                className: 'newsItemsPage-newsText',
                render: (newsText) => 
                {
                    return <div style={{wordBreak: "keep-all"}}><p>{newsText}</p></div>
                }

            },
            {
                title: 'Create Date',
                dataIndex: 'CreateDate',
                width: '8%',
                key: 'CreateDate',
                render: (createDate) =>
                    moment(createDate).format("MM/DD/YYYY")
            },
            {
                title: 'Start Date',
                dataIndex: 'StartDate',
                width: '8%',
                key: 'StartDate',
                render: (StartDate) =>
                    moment(StartDate).format("MM/DD/YYYY")
            },
            {
                title: 'End Date',
                dataIndex: 'EndDate',
                width: '8%',
                key: 'EndDate',
                render: (EndDate) =>
                moment(EndDate).format("MM/DD/YYYY")
            },
            {
                title: 'Options',
                width: '8%',
                render: (item) => {
                    return (
                        <div style={{textAlign: "center"}}>
                             <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.NewsId)} />
                             <Divider type="vertical" />
                             <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.NewsId)} />
                             <Divider type="vertical" />
                             <Icon type="profile" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'details', item.NewsId)} />
                        </div>
                    );
                },
            },
        ];

        this.state = {            
            newsItemObject: this.props.newsItem.newsItemObj,
            actionType: 'create',
            showModal: false,
            officeDetailsObj: this.props.newsItem.officeDetailsObj
          
        }

        this.showModal = this.showModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.getnewsItemObject = this.getnewsItemObject.bind(this);
    }

    componentWillMount() {
        this.props.initNewsItemPage();
        this.props.initCreateNewsItemObj();
       this.props.initGetOfficeDetails(220, 'R');
    }
    componentDidMount()
        {
           
        }
    
    componentWillReceiveProps(nextProps) {
        debugger;
        if (this.props.newsItem.newsItemObj !== nextProps.newsItem.newsItemObj) {
            this.setState({ newsItemObject: nextProps.newsItem.newsItemObj });
        } 
        if (this.props.newsItem.officeDetailsObj !== nextProps.newsItem.officeDetailsObj) {
            this.setState({ officeDetailsObj: nextProps.newsItem.officeDetailsObj });
        }       
        if(this.state.newsItemObj !== undefined && this.state.newsItemObj.officeGroup === null)
        {           
            let newsItemObjectCopy = JSON.parse(JSON.stringify(this.state.newsItemObject));
            newsItemObjectCopy.officeGroup = [];
            this.setState({
                newsItemObj:newsItemObjectCopy 
             });                     
        }      
    }

    showModal(e, actype, newsId) {
        if (actype !== 'create') {
            if(newsId)
        {
            if(actype === 'edit') {
                debugger;
        this.props.initEditNewsItemObj(newsId);  
        }
        if(actype === 'details') {
            this.props.initNewsItemDetails(newsId);     
            }
            if(actype === 'delete') {
                this.props.initNewsItemDetails(newsId);     
                }
    }
}
    
        else
        {
            this.props.initCreateNewsItemObj();
            debugger;
        }
        this.setState({ actionType: actype, showModal: true });
    }

    getnewsItemObject()
    {
        debugger;
        if(this.state.newsItemObject !== undefined && this.state.newsItemObject.officeGroup === null)
        {
          const {newsItemObject} = this.state;
          newsItemObject.officeGroup = [];
          this.setState({newsItemObject});
        }
        return this.state.newsItemObject;
    }
    handleOk(e) {
        debugger;
        if(this.state.actionType === 'delete')
        {
            this.props.initDeleteNewsItem(this.state.newsItemObject.NewsId);
        }
        if(this.state.actionType === 'edit')
        {
            this.props.initModifyNewsItem(this.state.newsItemObject);
        }
        if(this.state.actionType === 'create')
        {
            this.props.initSaveNewsItem(this.state.newsItemObject);
        }
            this.setState({ showModal: false });
        }

    handleCancel(e) {
        console.log("Canceled from news modal");
        this.setState({ showModal: false });
    }

    render() {      
        const newsItem = this.getnewsItemObject();
        const columns = this.columns.map((col) => {
            return {
                ...col,
                onCell: record => ({
                    record,
                    title: col.title
                }),
            };
        });

        return (
            <ScrollPanel
                style={{
                    width: "100%",
                    height: "calc(100% - 40px)",
                    backgroundColor: "rgba(0,0,0,0)"
                }}
            >
               <div>
{this.props.newsItem.list !==undefined ||this.props.newsItem.list !== null ? 
                   <Table
                        size= {"small"}
                       //style= {{width: "80%", height: "80%"}}
                        rowKey = "NewsId"
                        title={() => <div>

                                News Items<div><Button type="primary" onClick={(e) => this.showModal(e, 'create')}>Create New</Button></div>                      
              </div>} 
              showHeader = {true}
                        bordered

                        expandRowByClick={false}
                        dataSource={this.props.newsItem.list}

                        expandedRowRender={record => <p style={{ margin:0, wordBreak: "keep-all" }}>{record.NewsText}</p>}
                        columns={columns}
                        pagination={{ pageSize: 8}}
                        //scroll={{ y: 800, x: 200 }}
                      />
                      :
                      <div></div>
                        }
                </div>
                
                {this.state.newsItemObject && this.state.officeDetailsObj &&
              <NewsModal 
                    modalVisible={this.state.showModal}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    actionType={this.state.actionType}
                    newsItemObj={newsItem}
                    officeDetailsObj={this.state.officeDetailsObj}
                />
              }
          </ScrollPanel>    
        );
    }
}

const mapStateToProps = state => {
    return {
        newsItem: state.newsItem,
        ui: state.ui,
        homePage: state.homePage
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            initNewsItemDetails,
            initSaveNewsItem,
            initModifyNewsItem,
            initDeleteNewsItem,
            initGetOfficeDetails,
           initCreateNewsItemObj,
           initEditNewsItemObj,
            initNewsItemPage,
            showModal
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsItem);
