import axios from "axios";
import employeelistdata from "../../components/contents/mocks/ListOFEmployees.json"
import officeslistdata from "../../components/contents/mocks/ListOfOffices.json"
import hearinglocationsdata from "../../components/contents/mocks/ListOfHearingLocations.json"
import initialempprofdata from "../../components/contents/mocks/employeeprofInitData.json"
import empprofsdata from "../../components/contents/mocks/employeeprofilesbyId.json"
import hearingauthdata from "../../components/contents/mocks/hearingAuthData.json"
import hearingroomsperlocationdata from "../../components/contents/mocks/gethearingroomprofilesforroom.json"
import hearingroomprofbyprofiddata from "../../components/contents/mocks/gethearingroomprofbyid.json"
import timeoffforanempidanddate from "../../components/contents/mocks/TimeOffForAnEmpIdAndDate.json"

// EMPLOYEE PROFILES ACTIONS


// Initial Employee Profiles page data
export const getEmployeeProfilesInitialPageData = data => ({
  type: "GET_EMPPROFILESINITIAL_DATA",
  data: data
});

export const getEmployeeProfilesInitialPage = () => {
  debugger;
  return dispatch => {
   // axios.get("http://localhost:32610/api/EmployeeProfile/IntitialPage").then(response => {
  //    dispatch(getEmployeeProfilesInitialPageData(response.data));
  dispatch(getEmployeeProfilesInitialPageData(initialempprofdata));
   // });
  };
};


// Get profiles of an employee
export const getEmployeeProfilesbyIdData = data => ({
    type: "GET_EMPPROFILES_DATA",
    data: data
  });
  
  export const getEmployeeProfilesbyId = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/GetAllProfilesForEmployee/"+empid).then(response => {
      //  dispatch(getEmployeeProfilesbyIdData(response.data));
      dispatch(getEmployeeProfilesbyIdData(empprofsdata));
      });
    };
  };


  // Get hearing Authorization of an employee
  export const getHearingAuthorizationData = data => ({
    type: "GET_EMPLOYEEHEARINGAUTH_DATA",
    data: data
  });
  
  export const getHearingAuthorization = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingAuth/"+empid).then(response => {
     //   dispatch(getHearingAuthorizationData(response.data));
     dispatch(getHearingAuthorizationData(hearingauthdata));
      });
    };
  };

  // Get list of hearing rooms per location
  export const getHearingRoomProfilesForRoomData = data => ({
    type: "GET_HEARINGROOMPROFILES_DATA",
    data: data
  });
  
  export const getHearingRoomProfilesForRoom = (locationId) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingRoomProfilesForRoom"+locationId).then(response => {
      //  dispatch(getHearingRoomProfilesForRoomData(response.data));
      dispatch(getHearingRoomProfilesForRoomData(hearingroomsperlocationdata));
      });
    };
  };

  // Get hearing room prof detail by id
  export const getHearingRoomProfileByIdData = data => ({
    type: "GET_HEARINGROOMPROFILEBYID_DATA",
    data: data
  });
  
  export const getHearingRoomProfileById = (profId) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/"+profId).then(response => {
      //  dispatch(getHearingRoomProfileByIdData(response.data));
      dispatch(getHearingRoomProfileByIdData(hearingroomprofbyprofiddata));
      });
    };
  };

  // To get list of offices
  export const getMyDistrictOfficesData = data => ({
    type: "GET_DISTRICTOFFICES_DATA",
    data: data
  });
  
  export const getMyDistrictOffices = () => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/GetMyDistrictOffices").then(response => {
     //   dispatch(getMyDistrictOfficesData(response.data));
     dispatch(getMyDistrictOfficesData(officeslistdata));
      });
    };
  };

  export const getCreateProfileData = data => ({
    type: "GET_CREATEROFILE_DATA",
    data: data
  });
  
  export const getCreateProfile= (empid, profid) => {
      debugger;
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
        dispatch(getCreateProfileData(response.data));
      });
    };
  };

  export const saveEmployeeProfile = (employeeProfDataObj) => {
      debugger;
    return dispatch => {
      axios.post("http://localhost:32610/api/EmployeeProfile/CreateEmployeeProfile",employeeProfDataObj).then(response => {
        if(response.status === 200)
        {
          console.log(response);
        }
    }).catch((error) => {
      console.log(error);
    });

  };
  };

  export const saveHearingAuth = (hearingAuthData) => {
    debugger;
  return dispatch => {
    axios.post("http://localhost:32610/api/HearingAuth/CreateHearingAuth",hearingAuthData).then(response => {
      if(response.status === 200)
      {
        dispatch(getHearingAuthorizationData(JSON.parse(response.config.data)));
      }
  }).catch((error) => {
    console.log(error);
  });

};
};

export const deleteEmployeeProfile = (profid, endDate) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeProfile/DeleteEmployeeProfile/"+profid+"?EndEffectiveDate=",endDate).then(response => {
    if(response.status === 200)
    {
     //dispatch(getHearingAuthorizationData(JSON.parse(response.config.data)));
    }
}).catch((error) => {
  console.log(error);
});

};
};
//   export const getEmployeeProfile= (profid) => {
//       debugger;
//     return dispatch => {
//       axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
//         dispatch(getEmployeeProfileData(response.data));
//       });
//     };
//   };


// To get list of hearing locations
export const hearingLocationsProfileData = data => ({
  type: "GET_HEARINGLOCATION_DATA",
  data: data
});

export const getHearingLocation= (officeId) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingLocation"+officeId).then(response => {
   //   dispatch(hearingLocationsProfileData(response.data));
   dispatch(hearingLocationsProfileData(hearinglocationsdata));
    });
  };
};


// To get the list of Employees
export const getlistOfEmployeesData = data => ({
  type: "GET_EMPLOYEELIST_DATA",
  data: data
});

export const getListOfEmployeesForOffice= () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeesForMyOffice").then(response => {
    //  dispatch(getlistOfEmployeesData(response.data));
    dispatch(getlistOfEmployeesData(employeelistdata));
    });
  };
};

// Get timeoff details search results for emp id and date
export const getTimeOffDetailsforEmployeeData = data => ({
  type: "GET_EMPLOYEEAPPMNT_DATA",
  data: data
});

// export const getTimeOffDetailsforEmployee= (empidlist,month,year ) => {
//   return dispatch => {
//     axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentByEmployee?empIDList="+empidList+"&month="+month+"&year="+year).then(response => {
//     //  dispatch(getlistOfEmployeesData(response.data));
//     dispatch(getTimeOffDetailsforEmployeeData(timeoffforanempidanddate));
//     });
//   };
// };
