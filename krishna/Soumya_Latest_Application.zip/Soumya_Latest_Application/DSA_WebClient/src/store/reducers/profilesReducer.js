const employeeProfilesReducerDefaultState = {
};

const employeeProfilesReducer = (state = employeeProfilesReducerDefaultState, action) => {
  switch (action.type) {
    case "GET_EMPPROFILESINITIAL_DATA": {
      return { ...state, employeeProfilesInitialData: action.data };
    }
    case "GET_EMPPROFILES_DATA": {
      return { ...state, employeeProfilesData: action.data };
    }   
    case "GET_CREATEROFILE_DATA":
    {
      return { ...state, createProfileData: action.data };
    }
    case "GET_EMPLOYEEHEARINGAUTH_DATA":
    {
      return { ...state, hearingAuthData: action.data }
    }
    case "GET_HEARINGLOCATION_DATA":
    {
      return { ...state, hearingLocationsData: action.data }
    }
    case "GET_HEARINGROOMPROFILES_DATA":
    {
      return { ...state, hearingRoomProfilesData: action.data }
    }
    case "GET_DISTRICTOFFICES_DATA":
    {
      return { ...state, districtOfficesData: action.data }
    }
    case "GET_HEARINGROOMPROFILEBYID_DATA":
    {
      return { ...state, hearingRoomProfileById: action.data }
    }
    case "GET_EMPLOYEELIST_DATA":
    {
      return { ...state, employeeList: action.data }
    }
    case "GET_EMPLOYEEAPPMNT_DATA":
    {
      return { ...state, employeeappmnt : action.data }
    }
    default:
      return state;
  }
};

export default employeeProfilesReducer;