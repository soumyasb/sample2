import axios from "axios";
import homepage from "../../mocks/homepage.json";

//HOMEPAGE ACTIONS
export const getHomePage = data => ({
  type: "GET_HOMEPAGE",
  data: data
});

export const initHomePage = () => {
  return dispatch => {
    // axios.get("http://localhost:32610/api/HomePage").then(response => {
    //   dispatch(getHomePage(response.data));
    // });
    dispatch(getHomePage(homepage));
  };
};
