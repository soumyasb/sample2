import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { getEmployeeProfilesInitialPage, getEmployeeProfilesbyId, getCreateProfile, saveEmployeeProfile, getHearingAuthorization, saveHearingAuth, deleteEmployeeProfile } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import moment from "moment";
import { Table, Dropdown, List, Spin, Modal, Input, Tooltip, Button, Select, Layout, Menu, Icon, Badge, DatePicker, notification, TimePicker, Checkbox, Popconfirm, InputNumber } from 'antd';
import "../../../emp.css";
import cloneDeep from 'lodash/cloneDeep';

const { Content, Sider } = Layout;
const format = 'HH:mm';
//const { Option } = Select
const empProfcolumns = [
    {
        title: <b>Office</b>,
        dataIndex: 'office',
        width: "34%",
        key: 'office'
    },
    {
        title: <b>Effective Start Date</b>,
        dataIndex: 'effectiveStartDate',
        width: "33%",
        key: 'effectiveStartDate',
        render: (item) =>
        {
           if(item.includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
    },
    {
        title: <b>Effective End Date</b>,
        dataIndex: 'effectiveEndDate',
        width: "33%",
        key: 'effectiveEndDate',
        render: (item) =>
        {
           if(item.includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
    }];

    const hearingAuthColumns = [  {
        title: <b>Category</b>,
        dataIndex: 'categoryName',
       width: "20%",
        key: 'categoryName'
      },
      {
        title: <b>Hearing</b>,
        dataIndex: 'hearingTime',
       width: "20%",
        key: 'hearingTime',
        render: (item) =>
        {
           if( item === 0)
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
      },
      {
        title: <b>Interview</b>,
        dataIndex: 'interviewTime',
       width: "20%",
        key: 'interviewTime',
        render: (item) =>
        {
           if( item === 0)
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
      },
      {
        title: <b>Re-Examination</b>,
        dataIndex: 'reExamTime',
       width: "20%",
        key: 'reExamTime',
        render: (item) =>
        {
           if( item === 0)
           {
               return "-";
           }
           else
           {
               return item;
           }
        }
      },
      {
        title: <b>Last Updated</b>,
        dataIndex: 'lastUpdated',
       width: "20%",
        key: 'lastUpdated',
        render: (item) =>
        {
           if( moment(item).format("MM/DD/YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM/DD/YYYY");
           }
        }
      }];

    const empProfDetailcolumns = [
        {
            title: <b>Day</b>,
            dataIndex: 'day',
            width: "7%",
            key: 'day'
        },
        {
            title: <b>Day Start</b>,
            dataIndex: 'dayStart',
            width: "9%",
            key: 'dayStart',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>AM Break</b>,
            dataIndex: 'amBreak',
            width: "15%",
            key: 'amBreak',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Lunch</b>,
            dataIndex: 'lunch',
            width: "15%",
            key: 'lunch',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>PM Break</b>,
            dataIndex: 'pmBreak',
            width: "15%",
            key: 'pmBreak',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Day End</b>,
            dataIndex: 'dayEnd',
            width: "9%",
            key: 'dayEnd',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Travel Time To Office</b>,
            dataIndex: 'travelTimeToOffice',
            width: "15%",
            key: 'travelTimeToOffice',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        },
        {
            title: <b>Travel Time From Office</b>,
            dataIndex: 'travelTimeFromOffice',
            width: "15%",
            key: 'travelTimeFromOffice',
            render: (item) =>
            {
               if(item.includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return item;
               }
            }
        }];

class EmployeeProfiles extends Component {
    constructor(props) {
        super(props);
        this.state={
            employeeProfilesInitialData: props.profiles.employeeProfilesInitialData,
            modalVisible: false,
            sameSched: false,
            daySelected: true,
            autheditmode: false,
            delModal1Visible: false      
        };    
        this.onEmpListRowClick = this.onEmpListRowClick.bind(this);
        this.getMenuList = this.getMenuList.bind(this);
        this.getEmpProfiles = this.getEmpProfiles.bind(this);
        this.getEmpProfDetail = this.getEmpProfDetail.bind(this);
        this.openModal = this.openModal.bind(this);      
        this.handleOk = this.handleOk.bind(this);     
        this.handleCancel = this.handleCancel.bind(this);   
        this.officesList = this.officesList.bind(this);  
        this.handleChange = this.handleChange.bind(this);
        this.onChange = this.onChange.bind(this);
        this.onTimeChange = this.onTimeChange.bind(this);
        this.onDateChange = this.onDateChange.bind(this);
        this.isChecked = this.isChecked.bind(this);
        this.onButtonClick = this.onButtonClick.bind(this);
        this.onValueChange =  this.onValueChange.bind(this);
        this.disabledDate = this.disabledDate.bind(this);
        this.openNotification = this.openNotification.bind(this);
    }
    componentDidMount()
    {
       this.props.getEmployeeProfilesInitialPage();
    }
  
componentWillReceiveProps(nextProps) {
    if(this.props.profiles.employeeProfilesInitialData !== nextProps.profiles.employeeProfilesInitialData)
    {
       // this.setState({employeeProfilesInitialData: nextProps.employee.employeeProfilesInitialData});
        // this.setState({selectedEmployee: nextProps.employee.employeeProfilesInitialData.empProfiles.find((item) => {
        //     return item.empID === nextProps.employee.employeeProfilesInitialData.selectedEmployeeId;
        // })});
        const selectedEmp =  nextProps.profiles.employeeProfilesInitialData.employeeListForRegion.find((item) => {
            return item.empid === nextProps.profiles.employeeProfilesInitialData.selectedEmployeeId;
        });
        let name = "";
        if(selectedEmp.firstName != null)
        {
            name = name+selectedEmp.firstName;
        }
        if(selectedEmp.middleName != null)
        {
            name = name+" "+selectedEmp.middleName;
        }
        if(selectedEmp.lastName != null)
        {
            name = name+" "+selectedEmp.lastName;
        }
        let classification = "";
        nextProps.profiles.employeeProfilesInitialData.classificationList.map((citem) => {
            if(citem.value === selectedEmp.classification)
            {
               classification = citem.text.substring(4);  
               return classification;    
            }
        } )
        name = name+" - "+classification;
        this.setState({selectedEmployeeName: name, selectedEmployee: selectedEmp,
             selectedProfId: nextProps.profiles.employeeProfilesInitialData.empProfiles[0].profileId,
             employeeProfilesData: nextProps.profiles.employeeProfilesInitialData.empProfiles,
             officeListForRegionData: nextProps.profiles.employeeProfilesInitialData.officeListForRegion,
             classificationList: nextProps.profiles.employeeProfilesInitialData.classificationList,
             employeeListForRegionData: nextProps.profiles.employeeProfilesInitialData.employeeListForRegion,
           //  value: nextProps.employee.employeeProfilesInitialData.officeListForRegion[0].value
            });
    }

    if(this.props.profiles.hearingAuthData !== nextProps.profiles.hearingAuthData)
    {
        this.setState({hearingAuthData: nextProps.profiles.hearingAuthData});
        const newHearingAuthData = cloneDeep(nextProps.profiles.hearingAuthData);
        this.setState({ newHearingAuthData: newHearingAuthData});
    }

    if(this.props.profiles.hearingAuthEditedData !== nextProps.profiles.hearingAuthEditedData)
    {
        this.openNotification("Hearing Authorization updated successfulyy!");
        this.setState({hearingAuthData: nextProps.profiles.hearingAuthEditedData});
        const newHearingAuthData = cloneDeep(nextProps.profiles.hearingAuthEditedData);
        this.setState({ newHearingAuthData: newHearingAuthData});
    }

    if(this.props.profiles.profilesErrorData !== nextProps.profiles.profilesErrorData)
    {
        const conflicts = [];
        if(nextProps.profiles.profilesErrorData !== undefined)
        {
            nextProps.profiles.profilesErrorData.Conflict.map((item, index) => 
        {
            conflicts.push(<li key={index}>{item}</li>);
        })
        }
        this.setState({conflicts: conflicts, conflictModalVisible: true});
    }
    if(this.props.profiles.employeeProfilesData !== nextProps.profiles.employeeProfilesData)
    {
        if(nextProps.profiles.employeeProfilesData.profileId !== undefined)
        {
            this.openNotification(nextProps.profiles.employeeProfilesData.actionStatus);
            this.props.getEmployeeProfilesbyId(this.state.selectedEmployee.empid);
        }
        else
        {
            if(nextProps.profiles.employeeProfilesData.length !== 0)
            {
                this.setState({employeeProfilesData: nextProps.profiles.employeeProfilesData,
                    selectedProfId: nextProps.profiles.employeeProfilesData[0].profileId
                });
            }
            else
            {
                this.setState({employeeProfilesData: nextProps.profiles.employeeProfilesData, selectedProfId: undefined});
            }

    }
    }
    
    if(this.props.profiles.profileCreatedData !== nextProps.profiles.profileCreatedData)
    {
        this.openNotification("The Employee Profile has been created successfully!");
        this.props.getEmployeeProfilesbyId(this.state.selectedEmployee.empid);
        // this.setState({profileCreatedData: nextProps.profiles.profileCreatedData, value: nextProps.profiles.profileCreatedData.officeID});
        // const newCreateProfileObj = cloneDeep(nextProps.profiles.createProfileData);
        // this.setState({ newCreateProfileObj: newCreateProfileObj});
    }

    if(this.props.profiles.createProfileData !== nextProps.profiles.createProfileData)
    {
        this.setState({createProfileData: nextProps.profiles.createProfileData, value: nextProps.profiles.createProfileData.officeID});
        const newCreateProfileObj = cloneDeep(nextProps.profiles.createProfileData);
        this.setState({ newCreateProfileObj: newCreateProfileObj});
    }
}
getMenuList(employeeListForRegionData, classificationList)
{
let EmployeeList = [];
employeeListForRegionData.map((item) =>
{
    let classification = classificationList.map((citem) => {
            if(citem.value.toString() === item.classification)
            {
               return citem.text.substring(4);      
            }
        } )
    EmployeeList.push(<Menu.Item key={item.empid}>{<div style={{ textAlign: "center" }}><div style={{ fontSize:16, fontWeight: "bold"}}>{item.firstName} {item.middleName} {item.lastName}</div> 
    <div style={{marginTop: "-18px"}}>{item.userID}  |  {classification}</div></div>}</Menu.Item>)
})
return EmployeeList;
}

openNotification = (msg) => {
    notification.open({
      message: 'SUCCESS',
      description: msg,
      style: {
        width: 600,
        marginLeft: 335 - 600,
        backgroundColor: "#9cd864",
        fontWeight: 'bold'
      },
    });
  }

onValueChange = (e, idx, field) =>
{
    const { newHearingAuthData } = this.state;
    if(field === 'active')
{
    newHearingAuthData[idx].active = e.target.checked;
    if(e.target.checked === false)
    {
    newHearingAuthData[idx].hearingTime = 0;
    newHearingAuthData[idx].interviewTime = 0;
    newHearingAuthData[idx].reExamTime = 0;
    }
}
else if(field === 'categoryName')
{
    newHearingAuthData[idx].categoryName = e.target.value;
}
else{
    newHearingAuthData[idx][field] = e;
}
    this.setState({newHearingAuthData});
}

onDateChange = (date, dateString, type) =>
{
    let { newCreateProfileObj } = this.state;
    if(type === 'ESS' && date !== null)
    {
        newCreateProfileObj.effectiveStartDate = date.format();
    }
    if(type === 'EES' && date !== null)
    {
        newCreateProfileObj.effectiveEndDate = date.format();
    }
    if(type === 'EED' && date !== null)
    {
        this.setState({effectiveEndDate: date.format()});
    }
    this.setState({newCreateProfileObj})
}

onButtonClick= (e,value) => 
{
if(value === 'Edit')
{
    const newHearingAuthData =cloneDeep(this.state.hearingAuthData);
    this.setState({newHearingAuthData});
    this.setState({autheditmode: true});
}
if(value === 'Save')
{
    this.props.saveHearingAuth(this.state.newHearingAuthData);
    this.setState({autheditmode : false});
}
if(value === 'Cancel')
{
    this.setState({autheditmode: false});
}
}

isChecked = (e, idx) =>
{
    let { newCreateProfileObj } = this.state;
    let dayActive = newCreateProfileObj.profileDays[idx].dayActive;
    newCreateProfileObj.profileDays[idx].dayActive = !dayActive;
    this.setState({newCreateProfileObj})
}

officesList(officeListForRegionData)
{
let officesList = [];
officeListForRegionData.map((item) => {
    // if(item.officeID === officeID)
    // {
    //     officesList.push(<option key={item.value} selected value={item.value}>{item.text}</option>)
    // } else
    // {
        officesList.push(<option key={item.value} value={item.value}>{item.text}</option>)
   // }
});
return officesList;
}

handleChange = (e) =>
{
    this.setState({value: e.target.value});
    const { newCreateProfileObj } = this.state;
newCreateProfileObj.officeID = e.target.value;
this.setState({newCreateProfileObj});
}

onTimeChange = (t,ts,v,idx) =>
{
const { newCreateProfileObj } = this.state;
if(t !== null)
{
if(idx !== 'same')
{
    newCreateProfileObj.profileDays[idx][v] = t.format();
}
else{
    newCreateProfileObj.profileDays.map((item,index) =>
{
    if(item.dayCount !== 1 && item.dayCount !== 7)
    {
    newCreateProfileObj.profileDays[index][v] = t.format();
    }
})
}
}
this.setState({newCreateProfileObj});
}

openModal = (value, type) =>
{
   if( type === 'new' && this.state.selectedEmployee !== undefined)
   {{value.key ==="1" ? this.props.getCreateProfile(this.state.selectedEmployee.empid) : this.props.getCreateProfile(this.state.selectedEmployee.empid, this.state.selectedProfId)}
   this.setState({modalVisible: true, empProfType: type, modalTitle: "Create New Employee Profile"});
   if(value.key === "1")
   {
       this.setState({sameSched: false});
   }
}
if(type === 'hear' && this.state.selectedEmployee !== undefined) 
 {
     this.props.getHearingAuthorization(this.state.selectedEmployee.empid);
     this.setState({modalVisible: true, empProfType: type, modalTitle: "Hearing Authorization"});
}
if(type === 'delete' )
{
    this.setState({delModal1Visible: true});
}
}

handleCancel = (e) =>
{
     const newCreateProfileObj = cloneDeep(this.state.createProfileData);
    this.setState({newCreateProfileObj: newCreateProfileObj, modalVisible: false, autheditmode: false})
}

handleOk = (e) =>
{
    this.props.saveEmployeeProfile(this.state.newCreateProfileObj);
    this.setState({modalVisible: false});
}

onChange = (e) =>
{
    let { sameSched, newCreateProfileObj } = this.state;
    sameSched = !sameSched; 
    this.setState({ sameSched });
    if(sameSched === true)
    {
        newCreateProfileObj.profileDays.map((item) => 
        {
            if(item.dayCount !== 1 && item.dayCount !== 7)
            {
            item.dayActive = true;
            }
        });
    }
    else{
        const newCreateProfileObj = cloneDeep(this.state.createProfileData);
        this.setState({ newCreateProfileObj: newCreateProfileObj});
    }
}

getEmpProfiles(employeeProfilesData, officeListForRegionData)
{
let EmployeeProfilesList = [];
employeeProfilesData.map((item) =>
{
    let office ="";
     officeListForRegionData.map((oitem) => {
            if(oitem.value === item.officeID)
            {
               office = oitem.text;     
               return office; 
            }      
        } )
        EmployeeProfilesList.push({profileID: item.profileId, office: office, effectiveStartDate: moment(item.effectiveStartDate).format("MM/DD/YYYY") , effectiveEndDate:  moment(item.effectiveEndDate).format("MM/DD/YYYY")});
    })
return EmployeeProfilesList;
}

getEmpProfDetail(empProfDetailData)
{
    let EmployeeProfileDetail = [];
    empProfDetailData.map((item) =>
{
    let day = "";
      switch(item.dayCount)
            {
               case 1:
               day = "Sunday";
               break;
               case 2:
               day = "Monday";
               break;
               case 3:
               day = "Tuesday";
               break;
               case 4:
               day = "Wednesday";
               break;
               case 5:
               day = "Thursday";
               break;
               case 6:
               day = "Friday";
               break;
               case 7:
               day = "Saturday";
               break;
               default:
               day = "";
               break;     
            }
 const ttto = moment(item.travelToStart).format("HH:mm A")+"-"+moment(item.travelToEnd).format("HH:mm A");
 const ttfo =   moment(item.travelFromStart).format("HH:mm A")+"-"+moment(item.travelFromEnd).format("HH:mm A")
 const ds = moment(item.dayStart).format("HH:mm A");
 const amb = moment(item.amBreakStart).format("HH:mm A")+"-"+moment(item.amBreakEnd).format("HH:mm A");
 const lb = moment(item.lunchBreakStart).format("HH:mm A")+"-"+moment(item.lunchBreakEnd).format("HH:mm A");
 const pmb = moment(item.pmBreakStart).format("HH:mm A")+"-"+moment(item.pmBreakEnd).format("HH:mm A");
 const de = moment(item.dayEnd).format("HH:mm A");

     if(item.dayActive=== true){   EmployeeProfileDetail.push({day: day, dayStart: ds , amBreak: amb , lunch: lb, pmBreak: pmb, dayEnd: de, travelTimeToOffice: ttto,travelTimeFromOffice: ttfo});
 } })
return EmployeeProfileDetail;
}
disabledDate(current) {
    // Can not select days before today and today
    return current && current.valueOf() < Date.now();
  }
  
onEmpListRowClick(value)
{
    this.props.getEmployeeProfilesbyId(value);
    const selectedEmp = this.state.employeeListForRegionData.find((item) => {
        return item.empid.toString() === value;
    });
    let name = "";
    if(selectedEmp.firstName != null)
    {
        name = name+selectedEmp.firstName;
    }
    if(selectedEmp.middleName != null)
    {
        name = name+" "+selectedEmp.middleName;
    }
    if(selectedEmp.lastName != null)
    {
        name = name+" "+selectedEmp.lastName;
    }
    let classification = "";
    this.state.classificationList.map((citem) => {
        if(citem.value === selectedEmp.classification)
        {
           classification = citem.text.substring(4);  
           return classification;    
        }
    } )
    name = name+" - "+classification;
    this.setState({selectedEmployee: selectedEmp, selectedEmployeeName: name});
}


    render() {
        const menu = (
            <Menu onClick={(e) => this.openModal(e, 'new')}>
              <Menu.Item key="1">Add New Profile</Menu.Item>
              <Menu.Item key="2">Create New Profile from Selected Profile</Menu.Item>
            </Menu>
          );       
         let officesList = [];
        let EmployeeList, EmployeeProfilesList, EmployeeProfileDetail = [];
        let selectedRowKeys=[];
       if(this.state.newCreateProfileObj !== undefined ) {  officesList=  this.officesList(this.state.officeListForRegionData); }
        if(this.state.employeeProfilesData !== undefined && this.state.officeListForRegionData !== undefined && this.state.employeeListForRegionData !== undefined && this.state.classificationList !== undefined)
       {        
            EmployeeList = this.getMenuList(this.state.employeeListForRegionData, this.state.classificationList);
            EmployeeProfilesList = this.getEmpProfiles(this.state.employeeProfilesData, this.state.officeListForRegionData);
          if(this.state.selectedProfId !== undefined && this.state.employeeProfilesData !== undefined) { EmployeeProfileDetail = this.getEmpProfDetail((this.state.employeeProfilesData.find((item) =>
             {return item.profileId === this.state.selectedProfId})).profileDays);
          }  }
          if(EmployeeProfilesList !== undefined && EmployeeProfilesList !== [])
          {
            EmployeeProfilesList.map((item, idx) => 
            {
                      if(item.profileID === this.state.selectedProfId)
                      {
                          selectedRowKeys[0] = item.profileID;
                          return selectedRowKeys;
                      }
            })
          }
          const dayOfWeek = ['Sunday','Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          const rowSelection = {
              selectedRowKeys: selectedRowKeys,
                onChange: (selectedRowKeys, selectedRows) => {
                  this.setState({selectedProfId: selectedRows[0].profileID});
                },
                type: "radio"            
              };
        return (     <ScrollPanel
            style={{
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0,0,0,0)"
            }}>
            <Row style={{
            marginLeft: "2.5%",
            width: "95%",
            height: "800px",
            border: "2px solid white"}}>
          <div style={{height: "7%", border: "1px solid white"}} >
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>Employee Profiles</span></div>
         <Col style={{width:"22%",
         float: "left",
             height: "93%",
            border: "1px solid white"}}>
           <div style={{
             height: "5%",  paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"}}>Select An Employee</div>
              <ScrollPanel
            style={{
                // width: "95%",
                height: "95%",
                backgroundColor: "#c9e3fa"
            }}>

{this.state.selectedEmployee &&<Menu  onClick={(e) => this.onEmpListRowClick(e.key)}
style ={{}}
mode = "vertical"
        //  style={{ width: 256 }}
        defaultSelectedKeys={[this.state.selectedEmployee.empid.toString()]}
        //  defaultOpenKeys={[this.state.selectedEmployee.empid]}
         // selectedKeys={[this.state.selectedEmployee.empid]}
>
{EmployeeList}

</Menu>
}

 </ScrollPanel></Col>
             <Col style={{
                 width: "78%",
                 float: "right",
             height: "93%",
            border: "1px solid white"}}><div style={{height: "50%", border: "1px solid white", backgroundColor: "#d5d5d5"}}><div style={{
                height: "10%",  paddingTop: "7px", backgroundColor: "#d5d5d5", border: "1px solid white"}}><span style={{paddingLeft: "1%", float: "left"}}>Employee Profiles for <span style={{fontWeight: "bold"}}>{this.state.selectedEmployeeName}</span></span>
              <span  style={{float: "right"}}> <Dropdown overlay={menu}>
                <Button size="small" type="primary">
                <Icon type="plus-square"></Icon> New Profile <Icon type="down" />
                </Button>
              </Dropdown>
             <Modal  visible={this.state.modalVisible}
             width= "80%"
          title={this.state.modalTitle}
          onCancel={this.handleCancel}
          footer={[
            <span> {this.state.empProfType === "new" && 
            <span> <Button key="cancel" onClick={this.handleCancel}>Cancel</Button>
           <Button key="ok" type="primary" onClick={this.handleOk}>
              Create
          </Button></span>}</span>,
          <span>{this.state.empProfType === "hear" && 
          <Button disabled={this.state.autheditmode} key="cancel" type="primary" onClick={this.handleCancel}>OK</Button>}</span>
          ]}>
       {this.state.empProfType === "new" &&
        <div> {this.state.selectedEmployeeName && <div><span style={{marginLeft: "1%"}}>Employee:  {this.state.selectedEmployeeName.split("-")[0]}</span><span style={{marginLeft: "3%"}}>User ID: {this.state.selectedEmployee.userID}</span></div>}
         {this.state.newCreateProfileObj && <div style={{marginTop: "2%"}}><span style={{marginLeft: "1%"}}>Office:</span><span style={{marginLeft: "1%"}}>
         
         <select  
     style={{ width: '20%' }}   
     value={this.state.value}   
     onChange={this.handleChange} >{officesList}</select>
     
     </span><span style={{marginLeft: "2%"}}>Effective Start Date:</span><span style={{marginLeft: "1%"}}><DatePicker defaultValue={moment(this.state.newCreateProfileObj.effectiveStartDate)} onChange={(date, dateString) => this.onDateChange(date,dateString,'ESS')}></DatePicker></span><span style={{marginLeft: "2%"}}>Effective End Date:</span><span style={{marginLeft: "1%"}}><DatePicker placeholder="Select End Date" onChange={(date, dateString) => this.onDateChange(date,dateString,'EES')}></DatePicker></span></div>}
         <div style={{marginTop: "2%", marginLeft: "1%"}}><Checkbox checked={this.state.sameSched} onChange={this.onChange}></Checkbox><span style={{marginLeft: "1%"}}>Apply same schedule from Monday through Friday</span></div> 
         <Row gutter ={8}> <Col span={3} style={{marginTop: "2%"}}><Row style={{height: "32px"}}><b>Day of Week</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>AM Break Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>AM Break End</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Lunch Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Lunch End</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>PM Break Start</b></Row><Row style={{height: "32px", marginTop: "5%"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>PM Break End</b></Row></Col>
        <div>{this.state.newCreateProfileObj &&<div> {this.state.sameSched === false ?  this.state.newCreateProfileObj.profileDays.map((item,idx) => {
            return <Col span={3} style={{marginTop: "2%"}} key={item.dayCount}><Row  style={{height: "32px"}}><Checkbox checked={item.dayActive} key={item.dayCount+idx} onChange={(e) => this.isChecked(e,idx)}><b>{dayOfWeek[idx]}</b></Checkbox></Row>
            {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.dayStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-ds"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.dayEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-de"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayEnd', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.amBreakStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-abs"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'amBreakStart', idx)}  /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.amBreakEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-abe"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'amBreakEnd', idx)}  /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.lunchBreakStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-ls"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'lunchBreakStart', idx)}  /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.lunchBreakEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-le"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'lunchBreakEnd', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.pmBreakStart)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-pbs"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'pmBreakStart', idx)} /></Row>
            <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(item.pmBreakEnd)} use12Hours={true} style={{width: "80%", height: "100%"}} disabled={!item.dayActive} format={format} key={item.dayCount+"-pbe"} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'pmBreakEnd', idx)} /></Row></Col>
        }) : <Col span={3} style={{marginTop: "2%"}}><Row  style={{height: "32px"}}><b>Monday-Friday</b></Row>
        {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].dayStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].dayEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayEnd', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].amBreakStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'amBreakStart', 'same')}  /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].amBreakEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'amBreakEnd', 'same')}  /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].lunchBreakStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'lunchBreakStart', 'same')}  /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].lunchBreakEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'lunchBreakEnd', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].pmBreakStart)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'pmBreakStart', 'same')} /></Row>
        <Row style={{height: "32px", marginTop: "5%"}}><TimePicker value={moment(this.state.newCreateProfileObj.profileDays[1].pmBreakEnd)} use12Hours={true} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'pmBreakEnd', 'same')} /></Row></Col>}</div>}</div> </Row>
    </div> }
    {this.state.empProfType === "hear" && <div>
   {this.state.selectedEmployeeName && <div><span style={{marginLeft: "1%"}}>Employee:  {this.state.selectedEmployeeName.split("-")[0]}</span><span style={{marginLeft: "3%"}}>User ID: {this.state.selectedEmployee.userID}</span></div>}
   
   <div style={{
    justify: "center",
    height: "30px",
    backgroundColor: "#c9e3fa",
    paddingLeft: "1%"
   }} >{this.state.autheditmode === true ? (<div style={{marginTop: "1%"}}><span style={{fontSize: '15px', paddingLeft: '0.5%'}}>Schedule Authorization Update</span><span style={{float: "right", marginRight: "3%"}}> <Button style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Cancel')}>Cancel</Button> 
   <Button  style={{ color:  "white", backgroundColor: "green"}} type="default" size={"small"} onClick={(e) => this.onButtonClick(e,'Save')}>Save</Button></span></div>) :
 <div style={{marginTop: "1%"}}><span style={{fontSize: '15px', paddingLeft: '0.5%'}}>Existing Schedule Authorization </span><Button style={{float: "right", marginRight:"2%"}}type="primary" size={"small"} onClick={(e) => this.onButtonClick(e,'Edit')}> <Icon type="edit"/>Edit</Button></div>}</div>
   
   {this.state.autheditmode === true ? this.state.newHearingAuthData && <div> <Row style={{marginTop: "1%"}}><Col span={1}><b>Active</b></Col><Col span={5}><b>Category</b></Col><Col span={5}><b>Hearing</b></Col><Col span={5}><b>Interview</b></Col><Col span={5}><b>Re-Examinatiion</b></Col></Row>
   
   {this.state.newHearingAuthData.map((item,idx) => {
           return( 
            <Row style={{marginTop: "1%"}} key={item.id}><Col  span={1} ><Checkbox checked={item.active} key={item.id+idx} onChange={(e) => this.onValueChange(e,idx,'active')}></Checkbox></Col>
            <Col span={5} ><Input defaultValue={item.categoryName} style={{width: "80%", height: "100%"}} disabled={!item.active} key={item.id+"-cn"} onChange={(e) => this.onValueChange(e,idx,'categoryName')} /></Col>
            <Col span={5} ><InputNumber step={15} min={0} max={60} defaultValue={item.hearingTime} style={{width: "80%", height: "100%"}} disabled={!item.active} key={item.id+"-ht"} onChange={(e) => this.onValueChange(e,idx,'hearingTime')} /></Col>
            <Col span={5} ><InputNumber step={15} min={0} max={60} defaultValue={item.interviewTime} style={{width: "80%", height: "100%"}} disabled={!item.active} key={item.id+"-int"} onChange={(e) => this.onValueChange(e,idx,'interviewTime')}  /></Col>
   <Col  span={5} ><InputNumber step={15} min={0} max={60} defaultValue={item.reExamTime} style={{width: "80%", height: "100%"}} disabled={!item.active}  key={item.id+"-reex"} onChange={(e) => this.onValueChange(e,idx,'reExamTime')} /></Col></Row>);
   })
   }
           </div>  
            :<Table
                                 bordered = {false} 
                                 size = 'small'                           
                                 pagination = {false}
                                 columns={hearingAuthColumns} 
                                 dataSource={this.state.hearingAuthData}
                               //  rowKey={record => record.OIPName}
                                 showHeader
                                />}
    </div>}

    {this.state.empProfType === "delete" && <div>
              
        </div>
    }

         </Modal> 
              <Button type="primary"size="small" style={{marginLeft: "20px", marginRight:"10px"}} onClick={(e) => this.openModal(e, 'hear')}>
                Hearing Authorization
                </Button></span></div>
                <div style={{ height: "100%", overflow: "hidden"}}>                 
                {EmployeeProfilesList && EmployeeProfilesList.length !== 0 ?  <Table
                    scroll = {{ y: 250}}
                    bordered={false}
                    size='small'
                    style={{ width: "98%", marginLeft: "1%"}}
                    pagination={false}
                    columns={empProfcolumns}
                    dataSource={EmployeeProfilesList}
                    rowKey={record => record.profileID}
                    showHeader
                    rowSelection={rowSelection}
                    onRow={(record) => ({
                        onClick: () => {
                          this.setState({selectedProfId: record.profileID});
                        },
                      })}
                    /> : <h3>No profiles for this employee. Please add a new one.</h3>}
                </div>
                </div>
                <div style={{height: "50%", border: "1px solid #d5d5d5",backgroundColor: "#d5d5d5"}}><div style={{
                    height: "10%", paddingTop: "7px", backgroundColor: "#d5d5d5", border: "2px solid white"}}><span style={{paddingLeft: "1%"}}>Employee Profile Detail</span>
                    
                    <Modal
          title="Delete the profile"
          style={{ bottom: 20 }}
          visible={this.state.delModal1Visible}
          onOk={() => {this.props.deleteEmployeeProfile(this.state.selectedProfId, this.state.effectiveEndDate);
            this.setState({delModal1Visible: false});
        }}
          onCancel={() => this.setState({delModal1Visible: false})}
        >
                        <div>Please select an effective end date for this profile.
                        <DatePicker  disabledDate={this.disabledDate} onChange={(date, dateString) => this.onDateChange(date,dateString,'EED')}></DatePicker>
                        </div>
                        </Modal>

                    <Button type="primary" size="small" style={{ float: 'right' , marginRight: "10px"}} onClick={(e) => this.openModal(e,'delete')} >       
                    Add End Date
                     </Button>
                 </div>
                        <div style={{ height: "100%", overflow: "hidden"}}>         
                        <Modal visible={this.state.conflictModalVisible}   title={this.state.modalTitle}
          onCancel={(e) => {this.setState({conflictModalVisible: false})}}  onOk={(e) => {this.setState({conflictModalVisible: false})}}>Please correct the following conflicts!:<ul>{this.state.conflicts}</ul></Modal>       
                 <Table
                   scroll = {{ y: 250}}
                   bordered={false}
                   size='small'
                   style={{ width: "98%", marginLeft: "1%"}}
                  // scroll={{ y: 200, x: 200 }}
                   pagination={false}
                   columns={empProfDetailcolumns}
                   dataSource={EmployeeProfileDetail}
                   rowKey={record => record.empID}
                   showHeader /> 
               </div>
               </div></Col>
        </Row></ScrollPanel>);
}
}
const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getEmployeeProfilesInitialPage,
            getEmployeeProfilesbyId,
            getCreateProfile,
            saveEmployeeProfile,
            getHearingAuthorization,
            saveHearingAuth,
            deleteEmployeeProfile
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeProfiles);
