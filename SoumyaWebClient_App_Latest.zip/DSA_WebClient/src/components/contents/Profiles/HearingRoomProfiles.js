import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import {  getHearingLocation, getMyDistrictOffices, getDefaultRoomProfile, getHearingRoomProfileByLocation, updateHearingRoomProfile } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import moment from "moment";
import { Table, Dropdown, List, Spin, Modal, Radio, notification, Input, Tooltip, Button, Select, Layout, Menu, Icon, Badge, DatePicker, TimePicker, Checkbox, InputNumber } from 'antd';
import "../../../emp.css";
import cloneDeep from 'lodash/cloneDeep';

const { Content, Sider } = Layout;
const format = 'HH:mm';

const hearingLocationcolumns = [
    {
        title: <b>Location Id</b>,
        dataIndex: 'hearingLocationId',
        width: "15%",
        key: 'hearingLocationId'
    },
    {
        title: <b>Room Number</b>,
        dataIndex: 'roomNumber',
        width: "15%",
        key: 'roomNumber'
    },
    {
        title: <b>Room Description</b>,
        dataIndex: 'roomDescription',
        width: "35%",
        key: 'roomDescription'
    },
    {
        title: <b>Closed Date</b>,
        dataIndex: 'closedDate',
        width: "35%",
        key: 'closedDate',
        render: (item) =>
        {
           if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
           {
               return "-";
           }
           else
           {
               return moment(item).format("MM/DD/YYYY");
           }
        }
    }];

    const hearingRoomProfilescolumns = [
        {
            title: <b>Profile Id</b>,
            dataIndex: 'id',
            width: "33%",
            key: 'id',
            render: (item) =>
            {
                return item.toString();
            }
        },{
            title: <b>Active</b>,
            dataIndex: 'isActive',
            width: "33%",
            key: 'isActive',
            render: (item) =>
            {
                if(item===true)
                {
                    return "Yes";
                }
                else
                {
                    return "No";
                }
            }},
        // },
        // {
        //     title: <b>Efefct Start Date</b>,
        //     dataIndex: 'effectiveStartDate',
        //     width: "20%",
        //     key: 'effectiveStartDate',
        //     render: (item) =>
        //     {
        //        if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
        //        {
        //            return "-";
        //        }
        //        else
        //        {
        //            return moment(item).format("MM/DD/YYYY");
        //        }
        //     }
        // },
        // {
        //     title: <b>Effective End Date</b>,
        //     dataIndex: 'effectiveEndDate',
        //     width: "20%",
        //     key: 'effectiveEndDate',
        //     render: (item) =>
        //     {
        //        if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
        //        {
        //            return "-";
        //        }
        //        else
        //        {
        //            return moment(item).format("MM/DD/YYYY");
        //        }
        //     }
        // },
        {
            title: <b>Updated Date</b>,
            dataIndex: 'updatedDate',
            width: "33%",
            key: 'updatedDate',
            render: (item) =>
            {
               if(moment(item).format("MM/DD/YYYY").includes("Invalid"))
               {
                   return "-";
               }
               else
               {
                   return moment(item).format("MM/DD/YYYY");
               }
            }
        }];
//const { Option } = Select

 
class HearingRoomProfiles extends Component {
    constructor(props) {
        super(props);
        this.state={
            districtOffices: props.profiles.districtOfficesData,
            hearingLocationsData: props.profiles.hearingLocationsData,
            editmode: false,
            newprofModalVisible: false
            // modifiedRoomProfile: {
            //     "id": 0,
            //     "hearingRoomId": 0,
            //     "updatedBy": 0,
            //     "updatedDate": "2018-09-04T20:17:50.992Z",
            //     "isActive": true,
            //     "monStartTime": "string",
            //     "monEndTime": "string",
            //     "tueStartTime": "string",
            //     "tueEndTime": "string",
            //     "wedStartTime": "string",
            //     "wedEndTime": "string",
            //     "thuStartTime": "string",
            //     "thuEndTime": "string",
            //     "friStartTime": "string",
            //     "friEndTime": "string",
            //     "satStartTime": "string",
            //     "satEndTime": "string",
            //     "sunStartTime": "string",
            //     "sunEndTime": "string"
            //   }
        };    
        this.onTimeChange = this.onTimeChange.bind(this);
        this.onValueChange =  this.onValueChange.bind(this);
        this.onOfficeListRowClick = this.onOfficeListRowClick.bind(this);
        this.openNotification = this.openNotification.bind(this);
        this.onButtonClick = this.onButtonClick.bind(this);
        this.changeSelection = this.changeSelection.bind(this);
        this.onToggle = this.onToggle.bind(this);
    }
    componentDidMount()
    {
        this.props.getMyDistrictOffices();
    }
  
componentWillReceiveProps(nextProps) {
    if(this.props.profiles.districtOfficesData !== nextProps.profiles.districtOfficesData && nextProps.profiles.districtOfficesData !== undefined )
    {
        this.setState({districtOffices: nextProps.profiles.districtOfficesData});
        if(nextProps.profiles.districtOfficesData.length >0){this.setState({selectedOffice: nextProps.profiles.districtOfficesData[0]});
        this.props.getHearingLocation(parseInt(nextProps.profiles.districtOfficesData[0].officeID));}
    }
    if(this.props.profiles.defaultRoomProfileData !== nextProps.profiles.defaultRoomProfileData)
    {
        this.setState({newRoomProfile: nextProps.profiles.defaultRoomProfileData.hearingRoomProfile});
        // if(nextProps.profiles.districtOfficesData.length >0){this.setState({selectedOffice: nextProps.profiles.districtOfficesData[0]});
        // this.props.getHearingLocation(parseInt(nextProps.profiles.districtOfficesData[0].officeID));}
    }
    if(this.props.profiles.updatedRoomProfile !== nextProps.profiles.updatedRoomProfile)
    {
        this.openNotification("The hearing room's profile has been updated successfully!");
        this.props.getHearingRoomProfileByLocation(this.state.selectedRoomId);
        // if(nextProps.profiles.districtOfficesData.length >0){this.setState({selectedOffice: nextProps.profiles.districtOfficesData[0]});
        // this.props.getHearingLocation(parseInt(nextProps.profiles.districtOfficesData[0].officeID));}
    }
    if(this.props.profiles.profilesErrorData !== nextProps.profiles.profilesErrorData)
    {
        let errors = [];
        if(nextProps.profiles.profilesErrorData.status === 422)
        {
    
           Object.keys(nextProps.profiles.profilesErrorData.data).map((keyName, keyIndex) =>
        {
            errors.push(nextProps.profiles.profilesErrorData.data[keyName][0]);
        })
        }
        this.setState({updateErrors: errors});
    }
    if(this.props.profiles.hearingLocationsData !== nextProps.profiles.hearingLocationsData)
    {
        if(nextProps.profiles.hearingLocationsData.length >0)
        {
            this.setState({hearingLocationsData: nextProps.profiles.hearingLocationsData, selectedHearingRoom: nextProps.profiles.hearingLocationsData[0]});
            if(nextProps.profiles.hearingLocationsData[0].hearingLocationId !== undefined || nextProps.profiles.hearingLocationsData[0].hearingLocationId !== null)
            {
             this.props.getHearingRoomProfileByLocation(nextProps.profiles.hearingLocationsData[0].hearingLocationId);
             this.setState({selectedRoomId: nextProps.profiles.hearingLocationsData[0].hearingLocationId});
            }
        }
        else
        {
            this.setState({hearingLocationsData: []});
        }
    }   
    if(this.props.profiles.hearingRoomProfilebyLocation !== nextProps.profiles.hearingRoomProfilebyLocation)
    {
        if(nextProps.profiles.hearingRoomProfilebyLocation.id !== undefined)
  {
  this.setState({selectedRoomProfile: nextProps.profiles.hearingRoomProfilebyLocation});
  const modifiedRoomProfile = cloneDeep(nextProps.profiles.hearingRoomProfilebyLocation);
  this.setState({ modifiedRoomProfile: modifiedRoomProfile});
  this.setState({newprofModalVisible: false, updateErrors: []});
      this.openNotification('updated');
  }
  else
  {
    this.setState({selectedRoomProfile: nextProps.profiles.hearingRoomProfilebyLocation.hearingRoomProfile});
    const modifiedRoomProfile = cloneDeep(nextProps.profiles.hearingRoomProfilebyLocation.hearingRoomProfile);
    this.setState({ modifiedRoomProfile: modifiedRoomProfile});
  }
    }   
}
changeSelection = (selection) =>
{
    this.setState({selectedRoomId: selection});
}
onOfficeListRowClick = (value) =>
{
    const selectedHearingRoom = this.state.hearingLocationsData.find((item) => {
        return item.hearingLocationId.toString() === value;
    });
this.setState({selectedHearingRoom});
this.props.getHearingLocation(parseInt(value));
}

onValueChange = (e, idx, field) =>
{
    const { newHearingAuthData } = this.state;
    if(field === 'active')
{
    newHearingAuthData[idx].active = e.target.checked;
    if(e.target.checked === false)
    {
    newHearingAuthData[idx].hearingTime = 0;
    newHearingAuthData[idx].interviewTime = 0;
    newHearingAuthData[idx].reExamTime = 0;
    }
}
else if(field === 'categoryName')
{
    newHearingAuthData[idx].categoryName = e.target.value;
}
else{
    newHearingAuthData[idx][field] = e;
}
    this.setState({newHearingAuthData});
}

getMenuList(districtOffices)
{
    let officesList = [];
    districtOffices.map((item) =>
{
    officesList.push(<Menu.Item key={item.officeID}>{<div style={{textAlign: "center"}}><div style={{height: "35px",fontSize:16, fontWeight: "bold"}}>{item.officeID}-{item.name}</div> 
    <div style={{height: "35px",marginTop: "-18px", fontSize:11}}>{item.addressLineOne}</div>
    <div  style={{height: "35px",marginTop: "-18px", fontSize:11}}>{item.city}-{item.zip}.  <b>Ph:</b>{item.phoneNumber}</div></div>}</Menu.Item>)
})
return officesList;

}

onTimeChange = (t,ts,v,type) =>
{
    if(type !== 'new')
    {
const { modifiedRoomProfile } = this.state;
if(t !== null)
{
    modifiedRoomProfile[v] = ts;
}

this.setState({modifiedRoomProfile});
    }
    else{
        const { newRoomProfile } = this.state;
if(t !== null)
{
    newRoomProfile[v] = ts;
}

this.setState({newRoomProfile});
    }
}

openNotification = (msg) => {
    notification.open({
      message: 'SUCCESS',
      description: msg,
      style: {
        width: 600,
        marginLeft: 335 - 600,
        backgroundColor: "#9cd864",
        fontWeight: 'bold'
      },
    });
  }

  onButtonClick = (type) => 
  {
if(type === 'edit')
{
    this.setState({editmode: true});
}
if(type === 'save')
{
    this.setState({editmode: false});
    this.props.updateHearingRoomProfile(this.state.modifiedRoomProfile);
}
if(type === 'cancel')
{
    const modifiedRoomProfile = cloneDeep(this.state.selectedRoomProfile);
    this.setState({editmode: false, modifiedRoomProfile: modifiedRoomProfile}); 
}
if(type=='add')
{
    this.props.updateHearingRoomProfile(this.state.newRoomProfile);
}
if(type === 'new')
{
    this.props.getDefaultRoomProfile(this.state.selectedRoomId);
    this.setState({newprofModalVisible: true});
}
  }

  onToggle = () =>
  {
      const {modifiedRoomProfile} = this.state;
      modifiedRoomProfile.isActive = !modifiedRoomProfile.isActive;
      this.setState({modifiedRoomProfile});
  }

    render() {
const {hearingRoomProfilesData} = this.state;
const {hearingLocationsData} = this.state;
const {modifiedRoomProfile} = this.state;
const {newRoomProfile} = this.state;

let HearingRoomList, selectedRowKeys =[];
        let officesList = [];
        if(this.state.districtOffices !== undefined ) {  officesList=  this.getMenuList(this.state.districtOffices); }
 
        if(this.state.hearingLocationsData !== undefined && this.state.hearingLocationsData !== [])
            {                   
                this.state.hearingLocationsData.map((item, idx) => 
              {
                        if(item.hearingLocationId === this.state.selectedRoomId)
                        {
                            selectedRowKeys[0] = item.hearingLocationId;
                            return selectedRowKeys;
                        }
              })
          
            }
            const rowSelection = {
                selectedRowKeys: selectedRowKeys,
                  onChange: (selectedRowKeys, selectedRows) => {
                      this.props.getHearingRoomProfileByLocation( selectedRows[0].hearingLocationId);
                 this.changeSelection(selectedRows[0].hearingLocationId);
                  },
                  type: "radio"            
                };
        return (  
      <ScrollPanel
            style={{
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0,0,0,0)"
            }}>
            <Row style={{
            marginLeft: "2.5%",
            width: "95%",
            height: "800px",
            border: "2px solid white"}}>
          <div style={{height: "7%", border: "1px solid white"}} >
            <span style={{paddingLeft: "1%", fontSize: "xx-large"}}>Hearing Room Profiles</span></div>
            <Col span={5} style={{
             height: "93%",
            border: "1px solid white"}}>
           <div style={{
             height: "5%",  paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"}}>Select An Office</div>
              <ScrollPanel
            style={{
                // width: "95%",
                height: "95%",
                backgroundColor: "#c9e3fa"
            }}>

{this.state.selectedOffice && <Menu onClick={(e) => this.onOfficeListRowClick(e.key)}
mode = "vertical"
      defaultSelectedKeys={[this.state.selectedOffice.officeID.toString()]}
>
{officesList}

</Menu>
}

 </ScrollPanel></Col>
             <Col style={{
             height: "93%",
            border: "1px solid white"}}>
            
            <div style={{height: "50%", border: "1px solid white", backgroundColor: "#d5d5d5"}}>
           <div style={{
                height: "10%",  paddingTop: "7px", backgroundColor: "#d5d5d5", border: "1px solid white"}}><span style={{paddingLeft: "1%", width: "60%", float: "left"}}>Hearing Rooms at the office: {this.state.selectedOffice &&  <span style={{fontWeight: "bold"}}><b>{this.state.selectedOffice.officeID}-{this.state.selectedOffice.name}</b></span>}</span> <div>
                {/* <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}}>
                <Icon type="plus-square"></Icon> New Profile
                </Button> */}
                </div></div>          <div style={{ height: "100%", overflow: "hidden"}}>                 
                {this.state.hearingLocationsData ? <div>{this.state.hearingLocationsData.length > 0 ? <Table
                    scroll = {{ y: 250}}
                    bordered={false}
                    size='small'
                    style={{ width: "98%", marginLeft: "1%"}}
                    pagination={false}
                    columns={hearingLocationcolumns}
                    dataSource={hearingLocationsData}
                    rowKey={record => record.hearingLocationId}
                    showHeader
                    rowSelection={rowSelection}
                    onRow={(record) => ({
                        onClick: (e) => {
                            this.props.getHearingRoomProfileByLocation(record.hearingLocationId);
                            this.setState({selectedRoomId: record.hearingLocationId});
                        },
                      })}
                    /> : <div style={{textAlign:"center", marginTop: "10%"}}>No hearing rooms at this location.</div>}</div> : <div></div> }
                </div>
                </div>
                <div style={{height: "50%", border: "1px solid #d5d5d5",backgroundColor: "#d5d5d5"}}>
                
                <div style={{
    height: "10%", paddingTop: "7px", backgroundColor: "#d5d5d5", border: "2px solid white"}}> <span style={{paddingLeft: "1%", width: "60%", float: "left"}}>Hearing Room profile detail for  {this.state.selectedHearingRoom && <span style={{fontWeight: "bold"}}><b>Location Id: </b>{this.state.selectedRoomId}</span>}</span>
                  { this.state.hearingLocationsData && this.state.hearingLocationsData.length >0 ? this.state.modifiedRoomProfile !== undefined && (this.state.modifiedRoomProfile !== null && this.state.modifiedRoomProfile.id !== undefined) ?
                  <div>  {this.state.editmode === false ? <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}} onClick={(e) => {
                      this.onButtonClick('edit');  
                    }}>
                  <Icon type="edit"></Icon> Edit Profile
                    </Button> : <span style={{float: "right", marginRight: "10px"}}><Button size="small" type="default" style={{marginRight: "10px", color:  "white", backgroundColor: "red"}} onClick={(e) => {
                            this.onButtonClick('cancel');  
                    }}>
                  <Icon type="close"></Icon> Cancel
                    </Button><Button size="small" type="default" style={{ color:  "white", backgroundColor: "green"}} onClick={(e) => {
                    this.onButtonClick('save');
                    }}>
                  <Icon type="check"></Icon> Save
                </Button>
                   {/* */}</span>}</div> : <Button size="small" type="primary" style={{float: "right", marginRight: "10px", marginTop: "-2 px"}} onClick={(e) => {
                    this.onButtonClick('new');
                }}>
                <Icon type="plus-square"></Icon> New Profile
                </Button>:<span></span> }</div>
                <Modal visible={this.state.newprofModalVisible}
             width= "60%"
          title= "Create New Room Profile"
          onCancel={(e) => this.setState({newprofModalVisible: false})}
          footer={[
              <div>{this.props.profiles.profilesErrorData === undefined ?
           <span><Button key="cancel" onClick={(e) => this.setState({newprofModalVisible: false})}>Cancel</Button>
           <Button key="ok" type="primary" onClick={(e) => {this.onButtonClick('add')}}>
              Create
          </Button></span> : <span> <Button key="ok" type="primary" onClick={(e) => {this.onButtonClick('new')}}>
              OK
          </Button></span>}</div>]}><div> {this.state.newRoomProfile !== undefined && (this.state.newRoomProfile !== null && this.state.newRoomProfile.id !== undefined) && <div style={{ height: "100%", overflow: "hidden"}}>                
                      <div style={{marginLeft: "10px", marginTop: "1%", width: "98%"}}><div style={{height: "5%", backgroundColor: "white"}}>Connections:</div><Row gutter={16} style={{marginTop: "2%"}}><Col span= {8}><Checkbox style={{marginRight: "2%"}} checked={newRoomProfile.isActive} onChange={this.onToggle}></Checkbox>Is Active?</Col></Row><div style={{height: "5%", backgroundColor: "white", marginBottom: "1%", marginTop: "2%"}}>Availability:</div><Row><Col span={3}><b>Day of Week</b></Col><Col span={3}><b>Sunday</b></Col><Col span={3}><b>Monday</b></Col><Col span={3}><b>Tuesday</b></Col><Col span={3}><b>Wednesday</b></Col><Col span={3}><b>Thursday</b></Col>
          <Col span={3}><b>Friday</b></Col><Col span={3}><b>Saturday</b></Col>    
            {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
          <div><Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Col><Col span={3}><TimePicker value={moment(newRoomProfile.sunStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'sunStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.monStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'monStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.tueStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'tueStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.wedStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'wedStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.thuStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'thuStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.friStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'friStartTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.satStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'satStartTime', 'new')} /></Col>

            <Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Col><Col span={3}><TimePicker value={moment(newRoomProfile.sunEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'sunEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.monEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'monEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.tueEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'tueEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.wedEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'wedEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.thuEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'thuEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.friEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'friEndTime', 'new')} /></Col>
            <Col span={3}><TimePicker value={moment(newRoomProfile.satEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'satEndTime', 'new')} /></Col>
 </div>
                {this.state.updateErrors && this.state.updateErrors.length > 0 && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><div> {this.state.updateErrors}</div></div>} </Row>
                    
              </div> </div>}</div></Modal>
                    {this.state.hearingLocationsData && this.state.hearingLocationsData.length >0 ? <div> {this.state.modifiedRoomProfile !== undefined && (this.state.modifiedRoomProfile !== null && this.state.modifiedRoomProfile.id !== undefined) && <div style={{ height: "100%", overflow: "hidden"}}>                
                      <div style={{marginLeft: "10px", marginTop: "1%", width: "98%"}}><div style={{height: "5%", backgroundColor: "white"}}>Connections:</div><Row gutter={16} style={{marginTop: "2%"}}><Col span= {8}><Checkbox style={{marginRight: "2%"}} checked={modifiedRoomProfile.isActive} onChange={this.onToggle} disabled= {!this.state.editmode}></Checkbox>Is Active?</Col></Row><div style={{height: "5%", backgroundColor: "white", marginBottom: "1%", marginTop: "2%"}}>Availability:</div><Row><Col span={3}><b>Day of Week</b></Col><Col span={3}><b>Sunday</b></Col><Col span={3}><b>Monday</b></Col><Col span={3}><b>Tuesday</b></Col><Col span={3}><b>Wednesday</b></Col><Col span={3}><b>Thursday</b></Col>
          <Col span={3}><b>Friday</b></Col><Col span={3}><b>Saturday</b></Col>    
            {/* If default time needs to be shown <TimePicker format={format} key={item.dayCount+"-ds"} defaultValue={moment(this.state.createProfileData.profileDays[idx].dayStart, format)} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'dayStart', idx)} /> */}
          <div><Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day Start</b></Col><Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.sunStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'sunStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.monStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'monStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.tueStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'tueStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.wedStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'wedStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.thuStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'thuStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.friStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'friStartTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.satStartTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'satStartTime')} /></Col>

            <Col span={3} style={{height: "32px"}}><b style={{verticalAlign: "-moz-middle-with-baseline"}}>Day End</b></Col><Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.sunEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'sunEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.monEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'monEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.tueEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'tueEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.wedEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'wedEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.thuEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'thuEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.friEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'friEndTime')} /></Col>
            <Col span={3}><TimePicker disabled= {!this.state.editmode} value={moment(modifiedRoomProfile.satEndTime,format)} use12Hours={true} style={{width: "80%", height: "100%"}} format={format} onChange={(time, timeString) => this.onTimeChange(time, timeString, 'satEndTime')} /></Col>
 </div>
                {this.state.updateErrors && this.state.updateErrors.length > 0  && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><div> {this.state.updateErrors}</div></div>} </Row>
                    
              </div> </div>}</div> : <div style={{textAlign:"center", marginTop: "10%"}}>No Profiles.</div>}
              
               </div></Col>
        </Row></ScrollPanel>);
}
}
const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getHearingLocation,
            getMyDistrictOffices,
            getHearingRoomProfileByLocation,
            updateHearingRoomProfile,
            getDefaultRoomProfile
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(HearingRoomProfiles);
