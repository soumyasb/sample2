import React, { Component } from 'react';
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import { Row, Col } from 'antd';
import { bindActionCreators } from "redux";
import { getListOfEmployeesForOffice, getTimeOffDetailsforEmployee, getTimeOffCreateScreen, getEmployeeAppointment, createEmployeeTimeOff
, editEmployeeTimeOff, deleteEmployeeTimeOff } from "../../../store/actions/profilesActions";
import { connect } from "react-redux";
import "../../../Prof.css";
import moment from "moment";
import cloneDeep from 'lodash/cloneDeep';
import {
    Table, Tabs, DatePicker, InputNumber, Divider, Modal, Input, Tooltip, Button, TimePicker,
    Select, Menu, Icon, Checkbox, Form, Radio, notification
} from 'antd';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;
const { TabPane } = Tabs;
const RadioGroup = Radio.Group;
const { MonthPicker } = DatePicker;
const monthFormat = 'MM-YYYY';
const timeFormat = 'HH:mm';
const dateFormat = 'YYYY/MM/DD';

const formItemLayout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
};

const occuranceType = {
    D: 'Daily',
    W: 'Weekly',
    B: 'Bi-Weekly',
    M: 'Monthly',
    Y: 'Yearly'
}

class EmployeeTimeOff extends Component {
    constructor(props) {
        super(props);

        this.appointmentColumns = [
            {
                title: <b>Date</b>,
                dataIndex: 'startTime',
                width: "25%",
                key: 'startDate',
                render: item => {
                    return moment(item).format("MM/DD/YYYY");
                }
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: "25%",
                key: 'time'
            },
            {
                title: <b>Description</b>,
                dataIndex: 'activityType',
                key: 'activityType',
                // render: (item) => {
                //     this.state.
                // }
            },
            {
                title: 'Options',
                width: '10%',
                render: (item) => {
                
                    return (
                        <div>
                            <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.reacurrenceNumber, item.appointmentNumber, false)} />
                            <Divider type="vertical" />
                            <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.reacurrenceNumber, item.appointmentNumber, false)} />
                            {/* <Divider type="vertical" />
                            <Icon type="profile" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'details', item.appointmentId)} /> */}
                        </div>
                    );
                },
            }
        ];

        this.conflictsColumns = [
            {
                title: <b>Case Number</b>,
                dataIndex: 'caseNumber',
                width: "25%",
                key: 'caseNumber'
            },
            {
                title: <b>Start Date</b>,
                dataIndex: 'conflictDateTimeStart',
                width: "20%",
                key: 'conflictDateTimeStart',
                render: (item) => {
                    return moment(item).format("MM/DD/YYYY")
                }
            }, 
            {
                title: <b>End Date</b>,
                dataIndex: 'confilctDateTimeEnd',
                width: "20%",
                key: 'confilctDateTimeEnd',
                render: (item) => {
                    return moment(item).format("MM/DD/YYYY")
                }
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: "35%",
                key: 'time'
            }
        ];

        this.recurringColumns = [
            {
                title: <b>Occurs</b>,
                dataIndex: 'occuranceType',
                width: '10%',
                key: 'occuranceType',
                render: item => occuranceType[item]
            },
            {
                title: <b>Start Date</b>,
                dataIndex: 'startTime',
                key: 'startDate',
                width: '15%',
                render: item => moment(item).format("MM/DD/YYYY")
            },
            {
                title: <b>End Date</b>,
                dataIndex: 'endTime',
                width: '15%',
                key: 'endDate',
                render: item => moment(item).format("MM/DD/YYYY").includes("9999") ? "NO END DATE" : moment(item).format("MM/DD/YYYY")
            },
            {
                title: <b>Time</b>,
                dataIndex: 'time',
                width: '20%',
                key: 'time'
            },
            {
                title: <b>Description</b>,
                dataIndex: 'activityType',
                key: 'description'
            },
            {
                title: 'Options',
                width: '10%',
                render: (item) => {
                    return (
                        <div>
                            <Icon type="edit" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'edit', item.reacurrenceNumber, item.appointmentNumber, true)} />
                            <Divider type="vertical" />
                            <Icon type="delete" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'delete', item.reacurrenceNumber, item.appointmentNumber, true)} />
                            {/* <Divider type="vertical" />
                            <Icon type="profile" style={{ cursor: 'pointer' }} onClick={e => this.showModal(e, 'details', item.appointmentId)} /> */}
                        </div>
                    );
                },
            }
        ];

        this.state = {
            selectedEmp: null,
            employeeList: props.profiles.employeeList,
            employeeappmnt: props.profiles.employeeappmnt,
            isNewModalVisible: false,
            isRecurringModalVisible: false,
            modalTitle: 'New Appointment',
            newAppointmentObj: {},
            recurringObj: {},
            timeOffSelectedMonth: moment(),
            recurringSelectedMonth: moment(),
            isDirty: false,
            disablefield: false,
            value:[]
        };

        this.handleMonthChange = this.handleMonthChange.bind(this);
        this.showModal = this.showModal.bind(this);
      //  this.handleCancel = this.handleCancel.bind(this);
        this.handleOk = this.handleOk.bind(this);
        this.onEmpListRowClick = this.onEmpListRowClick.bind(this);
        this.handleTimeOffFieldChange = this.handleTimeOffFieldChange.bind(this);
        this.handleRecurringFieldChange = this.handleRecurringFieldChange.bind(this);
        this.checkStateChange = this.checkStateChange.bind(this);
        this.openNotification = this.openNotification.bind(this);
     //   this.getradiovalue = this.getradiovalue.bind(this);
    }

    componentDidMount() {
        this.props.getListOfEmployeesForOffice();
        this.props.getTimeOffCreateScreen();
    }

 componentDidUpdate(prevProps) {
        debugger;
        if ( prevProps.profiles.editedTimeOffData !== this.props.profiles.editedTimeOffData ) {
                this.openNotification("The employee time-off is updated successfully!");
                this.setState({isRecurringModalVisible: false, isNewModalVisible: false});
        }
        if ( prevProps.profiles.deletedTimeOffData !== this.props.profiles.deletedTimeOffData ) {
            this.openNotification("The employee time-off is deleted successfully!");
            this.setState({isRecurringModalVisible: false, isNewModalVisible: false});
    }
    if ( prevProps.profiles.employeeApptCreateData !== this.props.profiles.employeeApptCreateData ) {
        this.openNotification("The employee time-off is created successfully!");
        this.setState({isRecurringModalVisible: false, isNewModalVisible: false});
}
    }
   

    static getDerivedStateFromProps(props, prevState) {
    
        const { employeeList, employeeappmnt, editTimeOffData, createTimeOffData, editedTimeOffData, profilesErrorData, deletedTimeOffData, employeeApptCreateData} = props.profiles;

        if (employeeList !== prevState.employeeList) return { employeeList };

        if (employeeappmnt !== prevState.employeeappmnt) return { employeeappmnt };

        if (deletedTimeOffData !== prevState.deletedTimeOffData && prevState.selectedEmp !== null)
        {
            const [month, year] = prevState.timeOffSelectedMonth.format("MM-YYYY").split('-');
            props.getTimeOffDetailsforEmployee(prevState.selectedEmp.empid, month, year);
            return {deletedTimeOffData};
        } 
        if (profilesErrorData !== prevState.profilesErrorData) 
        {      
            return {profilesErrorData, errorModalVisible: true};
        }

        if(editedTimeOffData !== prevState.editedTimeOffData && prevState.selectedEmp !== null)
        {
         const [month, year] = prevState.timeOffSelectedMonth.format("MM-YYYY").split('-');
         props.getTimeOffDetailsforEmployee(prevState.selectedEmp.empid, month, year);
        return {editedTimeOffData};
        }

        if(employeeApptCreateData !== prevState.employeeApptCreateData && prevState.selectedEmp !== null)
        {
            debugger;
         const [month, year] = prevState.timeOffSelectedMonth.format("MM-YYYY").split('-');
         props.getTimeOffDetailsforEmployee(prevState.selectedEmp.empid, month, year);
        return {employeeApptCreateData};
        }

        if (editTimeOffData !== prevState.editTimeOffData) 
        {
            if(editTimeOffData !== undefined && editTimeOffData.employeeProfileList.length > 0)
            {
                let emplist = [];
                editTimeOffData.employeeProfileList.map((item) => {emplist.push(item.empId)});
            
                switch(editTimeOffData.employeeProfileList[0].occuranceType)
                {
                 
                    case 'M':
                    {
                        if(editTimeOffData.employeeProfileList[0].dayType !== null && editTimeOffData.employeeProfileList[0].dayOfTheWeek !== null)
                        {
                            editTimeOffData.employeeProfileList[0].selectedRadio = "1";
                        }
                        else
                        {
                            editTimeOffData.employeeProfileList[0].selectedRadio = "2";
                        }
                        break;
                    }
                    case 'Y':
                    {
                        if(editTimeOffData.employeeProfileList[0].dayOfTheMonth !== null && editTimeOffData.employeeProfileList[0].monthOfTheYear !== null)
                        {
                            editTimeOffData.employeeProfileList[0].selectedRadio = "1";
                        }
                        else
                        {
                            editTimeOffData.employeeProfileList[0].selectedRadio = "2";
                        }
                        break;
                        
                    }
                    default:
                    editTimeOffData.employeeProfileList[0].selectedRadio = "1";
                    break;
                }
                if((moment(editTimeOffData.employeeProfileList[0].endTime).format("MM/DD/YYYY")).includes("9999"))
                {
                      editTimeOffData.employeeProfileList[0].endDateOption = "N";
                }
                else
                {
                    editTimeOffData.employeeProfileList[0].endDateOption = "Y";
                }
                editTimeOffData.employeeProfileList[0].startDate = cloneDeep(editTimeOffData.employeeProfileList[0].startTime);
                editTimeOffData.employeeProfileList[0].endDate = cloneDeep(editTimeOffData.employeeProfileList[0].endTime);
                return {editTimeOffData: editTimeOffData , value: emplist, newAppointmentObj: cloneDeep(editTimeOffData.employeeProfileList[0]), recurringObj: cloneDeep(editTimeOffData.employeeProfileList[0])};
            }
            else
            {
                return {editTimeOffData: editTimeOffData, value: []}
            }
    }

        if (createTimeOffData !== prevState.createTimeOffData)
        {
            if(prevState.modalmode === 'new')
            {
                createTimeOffData.defultAppointment.startDate = cloneDeep(createTimeOffData.defultAppointment.startTime);            
                createTimeOffData.defultAppointment.endDate = cloneDeep(createTimeOffData.defultAppointment.endTime);
                return { newAppointmentObj: cloneDeep(createTimeOffData.defultAppointment), recurringObj: cloneDeep(createTimeOffData.defultAppointment), modalmode: "enew"};
            }
        } 
        return null;
    }

    // componentWillReceiveProps(nextProps) {
    //    
    //     if(this.props.profiles.employeeList !== nextProps.profiles.employeeList)
    //     {
    //         this.setState({employeeList: nextProps.profiles.employeeList});
    //     }
    //     if(this.props.profiles.employeeappmnt !== nextProps.profiles.employeeappmnt)
    //     {
    //         this.setState({employeeappmnt: nextProps.profiles.employeeappmnt});
    //     }
    // }

    openNotification = (msg) => {
        notification.open({
          message: 'SUCCESS',
          description: msg,
          style: {
            width: 600,
            marginLeft: 335 - 600,
            backgroundColor: "#9cd864",
            fontWeight: 'bold'
          },
        });
      }

    onEmpListRowClick(value) {
        const selectedEmp = this.state.employeeList.find(emp => emp.empid === parseInt(value));

        const selectvalue = [];
        selectvalue.push(selectedEmp.empid);
        this.setState({ selectedEmp: selectedEmp, value: selectvalue});

        const dateString = moment().format(monthFormat);
        const [month, year] = dateString.split('-');

        this.props.getTimeOffDetailsforEmployee(value, month, year);
        // TODO...
        // If you have anyother call for recurring you need to call here so that the recurring data is also populated when the user selects an employee...
    }

    handleMonthChange(date, dateString, isRecurring = false) {
        if (dateString) {
            const [month, year] = dateString.split('-');
            this.props.getTimeOffDetailsforEmployee(this.state.selectedEmp.empid, month, year);

            if (isRecurring) this.setState({ recurringSelectedMonth: date });
            else this.setState({ timeOffSelectedMonth: date });
        }
    }


    showModal(e, actype, reacNo, apptNo, isRecurring = false) {
    
        // const employeeSelectListData = [];
        // if(this.state.employeeList && (this.state.modalmode === 'edit' || this.state.modalmode === 'delete')){        
        //         this.state.employeeList.map((item) => { if(this.state.value.includes(item.empid)) {
        //             employeeSelectListData.push(item.empid);
        //     }});}
        //     this.setState({employeeSelectListData});
        let modalTitle = 'New Appointment';
// const {newAppointmentObj} = this.state;
// const {recurringObj} = this.state;
      //  let newAppointmentObj = {}, recurringObj = {};

      

        switch (actype) {
            case 'new':
            const selectvalue = [];
            selectvalue.push(this.state.selectedEmp.empid);
            this.setState({value: selectvalue, modalmode: 'new', allSelected: false , disablefield: false});
                if (isRecurring) modalTitle = 'New Recurring Appointment';
                else modalTitle = 'New Appointment';
                this.props.getTimeOffCreateScreen();
                // newAppointmentObj = {};
                // recurringObj = {};
                break;
            case 'edit':
            {
                this.setState({modalmode: 'edit', disablefield: false});
                this.props.getEmployeeAppointment(reacNo, apptNo);
                if (isRecurring)
                {
                  //  this.props.getEmployeeAppointmentByRecNoandAppId()
                     modalTitle = 'Update Recurring Appointment';                 
        }
                else modalTitle = 'Update Appointment';
                break;
    }
            case 'delete':
            this.setState({modalmode: 'delete', disablefield: true});
            this.props.getEmployeeAppointment(reacNo, apptNo);
                if (isRecurring) modalTitle = 'Delete Recurring Appointment';
                else modalTitle = 'Delete Appointment';
                break;
            default:
                break;
        }
        if(isRecurring)
        {
            this.setState({isRecurringModalVisible: true});
        }
        else
        {
            this.setState({isNewModalVisible: true});
        }
        this.setState({ modalTitle});
    }
   checkStateChange =(e, type) => {
    
  if(type === 'checkall')
  { 
      if(e.target.checked === true)
   {
    const value = [];
    if(this.state.modalmode === 'edit' || this.state.modalmode === 'delete')
    {
       if(this.state.editTimeOffData) { this.state.editTimeOffData.employeeProfileList.map((item) => {
            value.push(item.empId);
        });
    }
    }
    else {   this.state.employeeList.map((item) => {
           value.push(item.empid);
       });
    }
       this.setState({value: value, allSelected: true});
   }
   else{
    const value = [];
    value.push(this.state.selectedEmp.empid);
    this.setState({value: value, allSelected: false});
   }
}
else
{
    let {value} = this.state;
    value = e;
  //  if(value.length < this.state.editTimeOffData.employeeProfileList.length)
this.setState({value: value}); 
// if(value.length === this.state.editTimeOffData.employeeProfileList.length)
//    {
//     this.setState({value: value, allSelected: true});
//    } 
}
    }
    handleOk(type, mode) {
    
       if(mode === 'delete')
{
    this.props.deleteEmployeeTimeOff(this.state.newAppointmentObj.reacurrenceNumber, this.state.newAppointmentObj.appointmentNumber);
}
   
       const appointmentsArray = [];
       if(type === 'nonrec')
       {
        this.state.value.map((item) =>
    {
        const timeoffItem = cloneDeep(this.state.newAppointmentObj);
        timeoffItem.empId = item;
        appointmentsArray.push(timeoffItem);
    })
}
if(type === 'rec')
{
    debugger;
    const {recurringObj} = this.state;
    recurringObj.startTime = recurringObj.startDate.split("T")[0]+"T"+recurringObj.startTime.split("T")[1];
    recurringObj.endTime = recurringObj.endDate.split("T")[0]+"T"+recurringObj.endTime.split("T")[1];
    this.setState({recurringObj});
    this.state.value.map((item) =>
    {
        const timeoffItem = cloneDeep(this.state.recurringObj);
        timeoffItem.empId = item;
        appointmentsArray.push(timeoffItem);
    })
}
if(mode === 'enew')
{
    debugger;
    this.props.createEmployeeTimeOff(appointmentsArray);
    this.setState({isNewModalVisible: false, isRecurringModalVisible: false})
}
if(mode === 'edit')
{
    appointmentsArray.map((item, idx) => {
        this.state.editTimeOffData.employeeProfileList.map((toitem) => {
            if(item.empId === toitem.empId)
            {
            appointmentsArray[idx].appointmentId = toitem.appointmentId;
            }
        })
    });

    this.props.editEmployeeTimeOff(appointmentsArray);
}

//this.setState({ isRecurringModalVisible: false, isNewModalVisible: false });
    }

    handleTimeOffFieldChange(e, type) {
    
        const { newAppointmentObj } = this.state;

        switch (type) {
            case 'activityType':
                newAppointmentObj.activityType = e;
                break;
            case 'date':
                const date = e.startOf('date');
                newAppointmentObj.date = date.format();
                newAppointmentObj.startTime = date.format();
                newAppointmentObj.endTime = date.format();
                break;
            case 'isAllDay':
                newAppointmentObj.isAllDay = e.target.checked;
              //  newAppointmentObj.disableTime = e.target.checked;
                break;
            case 'startTime':
                newAppointmentObj.startTime = e.format();
                break;
            case 'endTime':
                newAppointmentObj.endTime = e.format();
                break;
            case 'comment':
                newAppointmentObj.comment = e.target.value;
                break;
            case 'isDispayComment':
                newAppointmentObj.isDispayComment = e.target.checked;
                break;
            default:
                break;
        }

        this.setState({ newAppointmentObj });
    }
  
    handleRecurringFieldChange(e, type) {
        debugger;
        const { recurringObj } = this.state;
    
        switch (type) {
            case 'activityType':
                recurringObj.activityType = e;
                break;
            case 'startDate':
                recurringObj.startDate = e.format();
                break;
            case 'endDate':
                recurringObj.endDate = e.format();
                break;
            case 'occuranceType':
               { recurringObj.occuranceType = e.target.value;
                const crecurringObj = this.state.recurringObj;
                crecurringObj.dayType ="";
                crecurringObj.dayOfTheMonth = "";
                crecurringObj.dayOfTheWeek = "";
                crecurringObj.monthOfTheYear = "";
                this.setState({recurringObj: crecurringObj});
               }
                break;
            case 'isAllDay':
                recurringObj.isAllDay = e.target.checked;
               // recurringObj.disableTime = e.target.checked;
                break;
            case 'startTime':
                recurringObj.startTime = e.format();
                break;
            case 'endTime':
                recurringObj.endTime = e.format();
                break;
            case 'comment':
                recurringObj.comment = e.target.value;
                break;
            case 'isDispayComment':
                recurringObj.isDispayComment = e.target.checked;
                break;
            case 'dayType':
                recurringObj.dayType = e.target.value;
                break;
            case 'dayOfTheWeek':
                recurringObj.dayOfTheWeek = e.target.value;
                break;
            case 'dayOfTheMonth':
        
                recurringObj.dayOfTheMonth = e;
                break;
            case 'selectedRadio':
            
                recurringObj.selectedRadio = e.target.value;
                break;
            case 'endDateOption':
            
                recurringObj.endDateOption = e.target.value;
                if(e.target.value === 'Y')
                {
                    recurringObj.endDate = moment().format();
                }
                else
                {
                    recurringObj.endDate = "9999-12-27T12:00:00";
                }
                break;
            default:
                break;
        }
            this.setState({ recurringObj });
    }

    render() {
    
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
          };
        const { selectedEmp, newAppointmentObj, recurringObj, timeOffSelectedMonth, recurringSelectedMonth, editTimeOffData } = this.state;
        const { createTimeOffData } = this.props.profiles;
    
        const employeeSelectList = [];
        if(this.state.employeeList){
            if(this.state.modalmode === 'enew')
            {
        this.state.employeeList.map((item) =>{
            employeeSelectList.push(<Option key={item.empid} value={item.empid}>{`${item.shortID}- ${item.lastName}, ${(item.firstName).substring(0,1)}.`}</Option>);}) 
            }
    
           if(this.state.editTimeOffData) { if(this.state.modalmode === 'delete' || this.state.modalmode === 'edit')
            {
                this.state.employeeList.map((item) =>{ this.state.editTimeOffData.employeeProfileList.map((empitem)=> {
                  if(item.empid === empitem.empId) { employeeSelectList.push(<Option key={item.empid} value={item.empid}>{`${item.shortID}- ${item.lastName}, ${(item.firstName).substring(0,1)}.`}</Option>)
               }
                });           
                } );
            }
        }
        }
            
        let nonrecurringappmnts = [], recurringappmnts = [], conflictsList = [];

        if(this.state.profilesErrorData) {
            this.state.profilesErrorData.map((item) => 
        {
                item.time = moment(item.conflictDateTimeStart).format("h:mm A") +"-"+ moment(item.confilctDateTimeEnd).format("h:mm A");
                conflictsList.push(item);
            })
        }
   
        const activityTypeList = createTimeOffData ?
            createTimeOffData.activityTypeList
                .filter(act => act.types === 'H')
                .sort((a, b) => {
                    const actA = a.description.toLowerCase(), actB = b.description.toLowerCase();
                    if (actA < actB) return -1;
                    else if (actA > actB) return 1;
                    else return 0;
                })
            : [];
            if(this.state.employeeappmnt) {
                this.state.employeeappmnt.map((item) => 
            {
            
                if(item.isAllDay)
                {
                    item.time = 'ALL DAY';
                }
                else
                {
                    item.time = moment(item.startTime).format("h:mm A") +"-"+ moment(item.endTime).format("h:mm A");
                }
                if(activityTypeList !== [])
                {
                    let description = "";
                    activityTypeList.map((actitem) =>{
                        if(actitem.code === item.activityType)
                        {
                          return  item.activityType = actitem.description;
                          
                        }
                    }  );
                    
                }
                if(item.occuranceType === null || item.occuranceType === "")
                {  
                    nonrecurringappmnts.push(item);
                }
                else
                {
                    recurringappmnts.push(item);
                }
            })
                        }
        return (<ScrollPanel
            style={{
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0,0,0,0)"
            }}>
            <Row style={{
                marginLeft: "2.5%",
                width: "95%",
                height: "800px",
                border: "2px solid white"
            }}>
                <div style={{ height: "7%", border: "1px solid white" }} >
                    <span style={{ paddingLeft: "1%", fontSize: "xx-large" }}>Employee Time-Off</span>
                </div>
                <Col style={{
                    width: "22%",
                    float: "left",
                    height: "93%",
                    border: "1px solid white"
                }}>
                    <div style={{
                        height: "5%", paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"
                    }}>
                        Select An Employee
                    </div>
                    <ScrollPanel
                        style={{
                            // width: "95%",
                            height: "95%",
                            backgroundColor: "#c9e3fa"
                        }}>
                        <Menu mode="vertical" onClick={(e) => this.onEmpListRowClick(e.key)}>
                            {
                                this.state.employeeList && this.state.employeeList.map(item => <Menu.Item key={item.empid}>
                                    <div style={{ textAlign: "center" }}>
                                        <div style={{ fontSize: 16, fontWeight: "bold" }}>
                                            {`${item.firstName} ${item.middleName || ''} ${item.lastName}`}
                                        </div>
                                    </div>
                                </Menu.Item>)
                            }
                        </Menu>
                    </ScrollPanel>
                </Col>
                <Col style={{
                    width: "78%",
                    float: "right",
                    height: "93%",
                    border: "1px solid white"
                }}>
                <div style={{
                        height: "5%", paddingTop: "7px", backgroundColor: "#d5d5d5", textAlign: "center", border: "1px solid white"
                    }}>Time Off Details</div>
                    <div style={{ height: "100%", border: "1px solid white", paddingLeft: "15px" }}>
                   
                     {this.state.profilesErrorData && <Modal title="Conflicts" visible={this.state.errorModalVisible}
                       onCancel={(e) => this.setState({errorModalVisible: false})}
                       onOk={(e) => this.setState({errorModalVisible: false})}> 
                     <div><b> The employee time-off couldn't be created due to the following conflicts:</b></div>
                      <Table
                                       // scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "100%", height: "50%"}}
                                        pagination={false}
                                        columns={this.conflictsColumns}
                                        dataSource={conflictsList}
                                      //  rowKey={record => record.appointmentId}
                                        showHeader
                                    />
                     </Modal>}
                        {selectedEmp ? <Tabs defaultActiveKey="1" onChange={() => { }}>
                            <TabPane style={{height: "100%"}} tab={<b>Single Appointment</b>} key="1">
                                <div style={{ height: "10%"}}>
                                    <span style={{ float: "left" }}>
                                        Time Off for - <span style={{ fontWeight: "bold" }}>
                                            {selectedEmp && `${selectedEmp.firstName} ${selectedEmp.lastName}`}
                                        </span>
                                    </span>
                                    <span style={{ float: "right" }}>
                                        <Button size="small" type="primary" onClick={e => this.showModal(e, 'new', null, null, false)}>
                                            <Icon type="plus" theme="outlined" />New Appointment
                                        </Button>
                                        <Modal visible={this.state.isNewModalVisible}
                                            title={this.state.modalTitle}
                                            onCancel={(e) => this.setState({isNewModalVisible: false, modalmode: 'new'})}
                                          //  onOk={(e) => this.handleOk('nonrec',this.state.modalmode)}
                                        footer={[
                                            <span>
                                                {this.state.modalmode === "new" || this.state.modalmode === 'enew' &&
                                                    <span>
                                                        <Button key="cancel" onClick={(e) => this.setState({isNewModalVisible: false})}>Cancel</Button>
                                                        <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec',this.state.modalmode)}>
                                                            Create
                                                </Button>
                                                    </span>}
                                            </span>,
                                            <span>
                                                {this.state.modalmode === "edit" &&
                                                      <span>
                                                      <Button key="cancel" onClick={(e) => this.setState({isNewModalVisible: false})}>Cancel</Button>
                                                      <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec',this.state.modalmode)}>
                                                          Update
                                              </Button>
                                                  </span>}
                                            </span>,
                                            <span>
                                            {this.state.modalmode === "delete" &&
                                                  <span>
                                                  <Button key="cancel" onClick={(e) => this.setState({isNewModalVisible: false})}>Cancel</Button>
                                                  <Button key="ok" type="primary" onClick={(e) => this.handleOk('nonrec',this.state.modalmode)}>
                                                      Delete
                                          </Button>
                                              </span>}
                                        </span>

                                        ]}
                                        >
                                          {this.state.newAppointmentObj &&  <Form layout={'horizontal'}>
                                            <FormItem
                                                    label="Time Off For"
                                                    {...formItemLayout}
                                                >
                                               {/* <Select  style={{ width: '100%' }}
                                                        placeholder="Please select"> {employeeSelectList}</Select> */}
                                                              <span><Select disabled={this.state.disablefield} style={{ width: '70%' }}
                                                        placeholder="Please select"
                                                        value={this.state.value}
                                                        mode="multiple"
                                                        onChange={e => this.checkStateChange(e, 'checkbox')}>
                                                      {/* //  value={newAppointmentObj.activityType}
                                                      //  onChange={e => this.handleTimeOffFieldChange(e, 'activityType')} */}
                                                        {employeeSelectList}
                                                    </Select></span><span><Checkbox disabled={this.state.disablefield} onChange={e => this.checkStateChange(e, 'checkall')}></Checkbox>{this.state.allSelected ? "DeSelect All" : "Select All"}</span>
                                            </FormItem>
                                                <FormItem
                                                    label="Activity Type"
                                                    {...formItemLayout}
                                                >
                                                    <Select
                                                    disabled={this.state.disablefield}
                                                        style={{ width: '100%' }}
                                                        placeholder="Please select"
                                                        value={newAppointmentObj.activityType}
                                                        onChange={e => this.handleTimeOffFieldChange(e, 'activityType')}
                                                    >
                                                        {activityTypeList.map(item => <Option key={`${item.code}`}>{item.description}</Option>)}
                                                    </Select>
                                                </FormItem>
                                                <FormItem
                                                    label="Date"
                                                    {...formItemLayout}
                                                >
                                                    <DatePicker disabled={this.state.disablefield} value={moment(newAppointmentObj.startTime, dateFormat)} format={dateFormat} onChange={e => this.handleTimeOffFieldChange(e, 'date')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Is All Day"
                                                    {...formItemLayout}
                                                >
                                                    <Checkbox disabled={this.state.disablefield} checked={newAppointmentObj.isAllDay} onChange={e => this.handleTimeOffFieldChange(e, 'isAllDay')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Start Time"
                                                    {...formItemLayout}
                                                >
                                                 {this.state.disablefield ? <TimePicker disabled value={moment(newAppointmentObj.startTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'startTime')} />
                                                 :<TimePicker disabled={newAppointmentObj.isAllDay} value={moment(newAppointmentObj.startTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'startTime')} />} </FormItem>
                                                <FormItem
                                                    label="End Time"
                                                    {...formItemLayout}
                                                >
                                                   {this.state.disablefield ? <TimePicker disabled value={moment(newAppointmentObj.endTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'endTime')} />
                                                   : <TimePicker disabled={newAppointmentObj.isAllDay} value={moment(newAppointmentObj.endTime)} format={timeFormat} onChange={e => this.handleTimeOffFieldChange(e, 'endTime')} />} </FormItem>
                                                <FormItem
                                                    label="Comments"
                                                    {...formItemLayout}
                                                >
                                                    <TextArea disabled={this.state.disablefield} rows="3" value={newAppointmentObj.comment} onChange={e => this.handleTimeOffFieldChange(e, 'comment')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Display on Schedule"
                                                    {...formItemLayout}
                                                >
                                                    <Checkbox disabled={this.state.disablefield} checked={newAppointmentObj.isDispayComment} onChange={e => this.handleTimeOffFieldChange(e, 'isDispayComment')} />
                                                </FormItem>
                                            </Form>}

                                        </Modal>
                                    </span>
                                </div>
                                <br /><br />
                                <div>
                                    <div>
                                        Pick Month-Year:
                                        <MonthPicker format={monthFormat} value={timeOffSelectedMonth} onChange={(date, dateString) => this.handleMonthChange(date, dateString)} />
                                        <br /><br />
                                    </div>
                                    {this.state.employeeappmnt ? <Table
                                        scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "98%", height: "50%", marginLeft: "1%" }}
                                        pagination={false}
                                        columns={this.appointmentColumns}
                                        dataSource={nonrecurringappmnts}
                                        rowKey={record => record.appointmentId}
                                        showHeader
                                    // rowSelection={rowSelection}
                                    // onRow={(record) => ({
                                    //     onClick: () => {
                                    //         this.setState({ selectedAppointmentId: record.appointmentId });
                                    //     },
                                    // })}
                                    /> : <div />}
                                </div>
                            </TabPane>
                                    <TabPane style={{height: "100%"}} tab={<b>Recurring Appointment</b>} key="2">
                                <div style={{ height: "10%" }}>
                                    <span style={{ float: "left" }}>
                                        Recurring Appointments for - <span style={{ fontWeight: "bold" }}>
                                            {selectedEmp && `${selectedEmp.firstName} ${selectedEmp.lastName}`}
                                        </span>
                                    </span>
                                    <span style={{ float: "right" }}>
                                        <Button size="small" type="primary" onClick={e => this.showModal(e, 'new', null, null, true)}>
                                            <Icon type="plus" theme="outlined" />New Recurring Appointment
                                        </Button>
                                        <Modal visible={this.state.isRecurringModalVisible}
                                        width= "50%"
                                            title={this.state.modalTitle}
                                            onCancel={(e) => this.setState({isRecurringModalVisible: false, errors: []})}
                                            onOk={(e) => this.handleOk('rec', this.state.modalmode)}
                                        // footer={[
                                        //     <span>
                                        //         {this.state.empProfType === "new" &&
                                        //             <span>
                                        //                 <Button key="cancel" onClick={this.handleCancel}>Cancel</Button>
                                        //                 <Button key="ok" type="primary" onClick={this.handleOk}>
                                        //                     Create
                                        //         </Button>
                                        //             </span>}
                                        //     </span>,
                                        //     <span>
                                        //         {this.state.empProfType === "hear" &&
                                        //             <Button key="cancel" type="primary" onClick={this.handleCancel}>OK</Button>}
                                        //     </span>
                                        // ]}
                                        >
                                          {this.state.errors && this.state.errors.length > 0 && <div style={{color: 'red'}}><div> ERROR! Please correct the following:</div><ul> {this.state.errors}</ul></div>}
                                       {this.state.recurringObj &&     <Form layout={'horizontal'}>
                                       <FormItem
                                                    label="Recurring Time Off For"
                                                    {...formItemLayout}
                                                >
                                               {/* <Select  style={{ width: '100%' }}
                                                        placeholder="Please select"> {employeeSelectList}</Select> */}
                                                              <span><Select style={{ width: '70%' }}
                                                              disabled={this.state.disablefield}
                                                        placeholder="Please select"
                                                        value={this.state.value}
                                                        mode="multiple"
                                                        onChange={e => this.checkStateChange(e, 'checkbox')}>
                                                      {/* //  value={newAppointmentObj.activityType}
                                                      //  onChange={e => this.handleTimeOffFieldChange(e, 'activityType')} */}
                                                        {employeeSelectList}
                                                    </Select></span><span><Checkbox disabled={this.state.disablefield} onChange={e => this.checkStateChange(e, 'checkall')}></Checkbox>{this.state.allSelected ? "DeSelect All" : "Select All"}</span>
                                            </FormItem>
                                                <FormItem
                                                    label="Occurs"
                                                    {...formItemLayout}
                                                >
                                                    <div><RadioGroup disabled={this.state.disablefield} onChange={e => this.handleRecurringFieldChange(e, 'occuranceType')} value={recurringObj.occuranceType}>
                                                        <Radio value={'D'}>Daily</Radio>
                                                        <Radio value={'W'}>Weekly</Radio>
                                                        {/* <Radio value={'B'}>Bi-Weekly</Radio> */}
                                                        <Radio value={'M'}>Monthly</Radio>
                                                        <Radio value={'Y'}>Yearly</Radio>
                                                    </RadioGroup>
                                                    {recurringObj.occuranceType &&   
                                                   <div style={{ fontSize: "12px"}}> {recurringObj.occuranceType === 'D' && <RadioGroup disabled={this.state.disablefield} size="small" onChange={e => this.handleRecurringFieldChange(e, 'dayType')} value={recurringObj.dayType}>
                                                        <Radio style={{fontSize: "12px"}}  value={'1'}>Every Day</Radio>
                                                        <Radio style={{fontSize: "12px"}}  value={'2'}>Every Week Day</Radio>
                                                    </RadioGroup>}
                                                    {recurringObj.occuranceType === 'W' && <span>Every week on:<RadioGroup disabled={this.state.disablefield} size="small" onChange={e => this.handleRecurringFieldChange(e, 'dayOfTheWeek')} value={recurringObj.dayOfTheWeek}>
                                                        <Radio style={{fontSize: "12px"}} value={'1'}>Mon</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'2'}>Tue</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'3'}>Wed</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'4'}>Thu</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'5'}>Fri</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'6'}>Sat</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'7'}>Sun</Radio>
                                                        {/* <Radio style={{fontSize: "12px"}} value={'W'}>WeekDay</Radio>
                                                        <Radio style={{fontSize: "12px"}} value={'E'}>WeekEnd</Radio> */}
                                                    </RadioGroup></span> }
                                                    {recurringObj.occuranceType === 'M' && <span>Every month on: <RadioGroup disabled={this.state.disablefield} value={recurringObj.selectedRadio} onChange={e => 
                                                   
                            //  {if(e.target.value === '1'){
                            //                             this.setState({firstOption: true});
                            //                         }
                            //                         else{
                            //                             this.setState({firstOption: false});
                            //                         }}
                            this.handleRecurringFieldChange(e, 'selectedRadio')
                                                    } >
                                                        <Radio value={'1'}>The <select disabled={recurringObj.selectedRadio ===  "2"} onChange={e => this.handleRecurringFieldChange(e, 'dayType')}  value={recurringObj.dayType}>
                                                        <option key="1" value="1">First</option>
                                                        <option key="2" value="2">Second</option>
                                                        <option key="3" value="3">Third</option>
                                                        <option key="4" value="4">Fourth</option>
                                                        <option key="L" value="L">Last</option>
                                                        </select>
                                                        <select disabled={recurringObj.selectedRadio ===  "2"} onChange={e => this.handleRecurringFieldChange(e, 'dayOfTheWeek')}  value={recurringObj.dayOfTheWeek}> 
                                                        <option key="1" value="1">Sunday</option>
                                                        <option key="2" value="2">Monday</option>
                                                        <option key="3" value="3">Tuesday</option>
                                                        <option key="4" value="4">Wednesday</option>
                                                        <option key="5" value="5">Thursday</option>
                                                        <option key="6" value="6">Friday</option>
                                                        <option key="7" value="7">Saturday</option>
                                                        <option key="W" value="W">Weekday</option>
                                                        <option key="E" value="E">Weekend</option></select> </Radio>of every month.
                                                        <Radio value={'2'}>Day<InputNumber disabled={recurringObj.selectedRadio ===  "1"} min={1} max={31} onChange={e => this.handleRecurringFieldChange(e, 'dayOfTheMonth')} value={recurringObj.dayOfTheMonth}/> of every month.</Radio>
                                                    </RadioGroup></span>}
                                                    {recurringObj.occuranceType === 'Y' && <span>Every year on: <RadioGroup disabled={this.state.disablefield} value={recurringObj.selectedRadio} onChange={e =>
                                                   
                                                   this.handleRecurringFieldChange(e, 'selectedRadio')}>
                                                    <Radio value={'1'}><select disabled={recurringObj.selectedRadio ===  "2"} onChange={e => this.handleRecurringFieldChange(e, 'monthOfTheYear')} value={recurringObj.monthOfTheYear}> <option key="1" value="1">January</option>
                                                    <option key="2" value="2">February</option>
                                                    <option key="3" value="3">March</option>
                                                    <option key="4" value="4">April</option>
                                                    <option key="5" value="5">May</option>
                                                    <option key="6" value="6">June</option>
                                                    <option key="7" value="7">July</option>
                                                    <option key="8" value="8">August</option>
                                                    <option key="9" value="9">September</option>
                                                    <option key="10" value="10">October</option>
                                                    <option key="11" value="11">November</option>
                                                    <option key="12" value="12">December</option>
                                                   </select> on the day <InputNumber disabled={recurringObj.selectedRadio ===  "2"}min={1} max={31} onChange={e => this.handleRecurringFieldChange(e, 'dayOfTheMonth')} value={recurringObj.dayOfTheMonth}/></Radio>
                                                    <Radio value={'2'}>The <select disabled={recurringObj.selectedRadio ===  "1"} onChange={e => this.handleRecurringFieldChange(e, 'dayType')} value={recurringObj.dayType}>
                                                    <option key="1" value="1">First</option>
                                                    <option key="2" value="2">Second</option>
                                                    <option key="3" value="3">Third</option>
                                                    <option key="4" value="4">Fourth</option>
                                                    <option key="L" value="L">Last</option>
                                                    </select><select disabled={recurringObj.selectedRadio ===  "1"} onChange={e => this.handleRecurringFieldChange(e, 'dayOfTheWeek')} value={recurringObj.dayOfTheWeek}> <option key="1" value="1">Sunday</option>
                                                    <option key="2" value="2">Monday</option>
                                                    <option key="3" value="3">Tuesday</option>
                                                    <option key="4" value="4">Wednesday</option>
                                                    <option key="5" value="5">Thursday</option>
                                                    <option key="6" value="6">Friday</option>
                                                    <option key="7" value="7">Saturday</option>
                                                   </select> of <select disabled={recurringObj.selectedRadio ===  "1"} onChange={e => this.handleRecurringFieldChange(e, 'monthOfTheYear')} value={recurringObj.monthOfTheYear}> <option key="1" value="1">January</option>
                                                    <option key="2" value="2">February</option>
                                                    <option key="3" value="3">March</option>
                                                    <option key="4" value="4">April</option>
                                                    <option key="5" value="5">May</option>
                                                    <option key="6" value="6">June</option>
                                                    <option key="7" value="7">July</option>
                                                    <option key="8" value="8">August</option>
                                                    <option key="9" value="9">September</option>
                                                    <option key="10" value="10">October</option>
                                                    <option key="11" value="11">November</option>
                                                    <option key="12" value="12">December</option>
                                                   </select> </Radio>
                                                    </RadioGroup></span>}
                                                    </div>}
                                                    </div>
                                                </FormItem>
                                                {/* {recurringObj.occuranceType && <FormItem
                                                    label="Details"
                                                    {...formItemLayout}
                                                >
                                                </FormItem>} */}
                                                <FormItem
                                                    label="Activity Type"
                                                    {...formItemLayout}
                                                >
                                                    <Select
                                                        style={{ width: '100%' }}
                                                        placeholder="Please select"
                                                        value={recurringObj.activityType}
                                                        onChange={e => this.handleRecurringFieldChange(e, 'activityType')}
                                                        disabled={this.state.disablefield}
                                                    >
                                                        {activityTypeList.map(item => <Option key={`${item.code}`}>{item.description}</Option>)}
                                                    </Select>
                                                </FormItem>
                                                <FormItem
                                                    label="Duration"
                                                    {...formItemLayout}
                                                >
                                                  <div><div><div style={{width: "50%", float: "left"}}>Start Date: <DatePicker disabled={this.state.disablefield} placeholder="Start Date" value={moment(recurringObj.startDate, dateFormat)} format={dateFormat} onChange={(e) => this.handleRecurringFieldChange(e, 'startDate')} /></div>
                                                  <RadioGroup disabled={this.state.disablefield} onChange={e => this.handleRecurringFieldChange(e, 'endDateOption')} value={recurringObj.endDateOption}>
                                                        <Radio style={radioStyle} value={'Y'}>End Date: {recurringObj.endDateOption !== 'N' ? <DatePicker placeholder="End Date" value={moment(recurringObj.endDate, dateFormat)} format={dateFormat} onChange={e => this.handleRecurringFieldChange(e, 'endDate')} /> : 
                                                        <DatePicker disabled placeholder="Start Date" value={moment(recurringObj.endDate, dateFormat)} format={dateFormat}  /> }
                                                        </Radio>
                                                        <Radio style={radioStyle}  value={'N'}>No End Date</Radio>
                                                        </RadioGroup></div>
                                                {/* </FormItem>
                                                <FormItem
                                                    label="Is All Day"
                                                    {...formItemLayout}
                                                > */}
                                                   <div><span> <Checkbox disabled={this.state.disablefield} checked={recurringObj.isAllDay} onChange={e => this.handleRecurringFieldChange(e, 'isAllDay')}>Is All Day</Checkbox></span>
                                                {/* </FormItem>
                                                <FormItem
                                                    label="Start Time"
                                                    {...formItemLayout} value={moment(newAppointmentObj.startTime)} format={timeFormat}
                                                > */}
                                                <span>  Start Time: {this.state.disablefield ? <TimePicker disabled value={moment(recurringObj.startTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'startTime')} /> 
                                                : <TimePicker disabled={this.state.disablefield} disabled={recurringObj.isAllDay} value={moment(recurringObj.startTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'startTime')} /> }
                                                {/* </FormItem>
                                                <FormItem
                                                    label="End Time"
                                                    {...formItemLayout}
                                                > */}</span><span>
                                                   End Time: {this.state.disablefield ? <TimePicker disabled value={moment(recurringObj.endTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'endTime')} />
                                                   : <TimePicker disabled={this.state.disablefield} disabled={recurringObj.isAllDay} value={moment(recurringObj.endTime)} format={timeFormat} onChange={e => this.handleRecurringFieldChange(e, 'endTime')} />}</span></div></div> </FormItem>
                                                <FormItem
                                                    label="Comments"
                                                    {...formItemLayout}
                                                >
                                                     <TextArea disabled={this.state.disablefield} rows="3" value={recurringObj.comment} onChange={e => this.handleRecurringFieldChange(e, 'comment')} />
                                                </FormItem>
                                                <FormItem
                                                    label="Display on Schedule"
                                                    {...formItemLayout}
                                                >
                                                     <Checkbox disabled={this.state.disablefield} checked={recurringObj.isDispayComment} onChange={e => this.handleRecurringFieldChange(e, 'isDispayComment')} />
                                                </FormItem>
                                            </Form>
                                       }
                                        </Modal>
                                    </span>
                                </div>
                                <br /><br />
                                <div>
                                    {/* <div>
                                        Pick Month-Year:
                                        <MonthPicker format={monthFormat} value={recurringSelectedMonth} onChange={(date, dateString) => this.handleMonthChange(date, dateString, true)} />
                                        <br /><br />
                                    </div> */}
                                    {this.state.employeeappmnt ? <Table
                                        scroll={{ y: 500 }}
                                        bordered={false}
                                        size='small'
                                        style={{ width: "98%", height: "50%", marginLeft: "1%" }}
                                        pagination={false}
                                        columns={this.recurringColumns}
                                        dataSource={recurringappmnts}
                                        rowKey={record => record.appointmentId}
                                        showHeader
                                    // rowSelection={rowSelection}
                                    // onRow={(record) => ({
                                    //     onClick: () => {
                                    //         this.setState({ selectedAppointmentId: record.appointmentId });
                                    //     },
                                    // })}
                                    /> : <div />}
                                </div>
                            </TabPane>
                        </Tabs>: <h3>Please select an employee from the menu on the left side to continue.</h3>}
                    </div>
                </Col>
            </Row>
        </ScrollPanel>);
    }
}

const mapStateToProps = state => {
    return {
        profiles: state.profiles
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators(
        {
            getListOfEmployeesForOffice,
            getTimeOffDetailsforEmployee,
            getTimeOffCreateScreen,
            getEmployeeAppointment,
            createEmployeeTimeOff,
            editEmployeeTimeOff,
            deleteEmployeeTimeOff
        },
        dispatch
    );
};

export default connect(mapStateToProps, mapDispatchToProps)(EmployeeTimeOff);

