import axios from "axios";
import { Route, Redirect } from 'react-router';
import React from 'react';


// CASE ACTIONS

export const getCaseSearchResults = data => ({
  type: "GET_CASE_SEARCHRESULTS",
  data: data
});

export const searchCases = (seachString) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/Search/"+seachString).then(response => {
      dispatch(getCaseSearchResults(response.data));
    });
  };
};

export const getCustomerDetailsData = data => ({
  type: "GET_CUSTOMERDETAILS",
  data: data
});

export const getCustomerDetails = (dlNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Customer/"+dlNumber).then(response => {
      dispatch(getCustomerDetailsData(response.data));
    });
  };
};

export const getScheduledCasesData = data => ({
  type: "GET_SCHEDULEDCASES",
  data: data
});

export const getScheduledCases = (officeId, sort) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/GetScheduledCases?officeid="+officeId+"&sort="+sort).then(response => {
      dispatch(getScheduledCasesData(response.data));
    });
  };
};

export const getUnScheduledCasesData = data => ({
  type: "GET_UNSCHEDULEDCASES",
  data: data
});

export const getUnScheduledCases = (officeId, sort) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/GetUnScheduledCases?officeid="+officeId+"&sort="+sort).then(response => {
      dispatch(getUnScheduledCasesData(response.data));
    });
  };
};

export const getCustomerD26InfoData = data => ({
  type: "GET_CUSTOMERD26INFO",
  data: data
});

export const getCustomerD26Info = (dlNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Customer/GetCustomerD26Info/"+dlNumber).then(response => {
      dispatch(getCustomerD26InfoData(response.data));
    });
  };
};

export const getCaseDetailsData = data => ({
  type: "GET_CASEDETAILS",
  data: data
});

export const getCaseDetails = (caseNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/"+caseNumber).then(response => {
      dispatch(getCaseDetailsData(response.data));
    });
  };
};

export const getClosedCaseDetailData = data => ({
  type: "GET_CLOSEDCASEDETAILS",
  data: data
});

export const getClosedCaseDetail = (caseNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/ GetClosedCaseDetail?caseNumber="+caseNumber).then(response => {
      dispatch(getClosedCaseDetailData(response.data));
    });
  };
};


export const getHearingTypesData = data => ({
  type: "GET_HEARINGTYPES",
  data: data
});

export const getHearingTypes = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/case/LookupTables/GetHearingTypes").then(response => {
      dispatch(getHearingTypesData(response.data));
    });
  };
};

export const getCaseReasonsData = data => ({
  type: "GET_CASEREASONS",
  data: data
});

export const getCaseReasons = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/case/LookupTables/GetCaseReasons").then(response => {
      dispatch(getCaseReasonsData(response.data));
    });
  };
};

export const getCaseReferralsData = data => ({
  type: "GET_CASEREFERRALS",
  data: data
});

export const getCaseReferrals = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/case/LookupTables/GetCaseReferrals").then(response => {
      dispatch(getCaseReferralsData(response.data));
    });
  };
};

export const getCaseCertificationsData = data => ({
  type: "GET_CASECERTIFICATIONS",
  data: data
});

export const getCaseCertifications = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/case/LookupTables/ GetCaseCertifications").then(response => {
      dispatch(getCaseCertificationsData(response.data));
    });
  };
};

export const getOIPTypes = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/case/LookupTables/ GetOIPTypes").then(response => {
      return {
        type: "GET_OIPTYPES",
        data: response.data
      }
    });
  };
};

export const getOIPLanguages = () => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/case/LookupTables/ GetOIPLanguages").then(response => {
      return {
        type: "GET_OIPLANGUAGES",
        data: response.data
      }
    });
  };
};

export const getCaseCoverSheet = (caseNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/GetCaseCoverSheet?caseNumber="+caseNumber).then(response => {
      return {
        type: "GET_CASECOVERSHEET",
        data: response.data
      }
    });
  };
};

export const getModifyCaseData = data => ({
  type: "GET_MODIFYCASEDATA",
  data: data
});

export const modifyCaseDetail = (caseDetailObj) => {
  return dispatch => {
    axios.post("http://dmvwebd09:4000/api/Case/ModifyCase/"+caseDetailObj.CaseNumber,caseDetailObj).then(response => {
      if(response.status === 200)
      {
       dispatch(getModifyCaseData(response.data));
      }    
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getCaseErrorData(error.response.data.CaseDetailDTO));
     }
    console.log(error);
  });
};
};

export const getCreateCaseDetailsData = data => ({
  type: "GET_CREATECASEDATA",
  data: data
});

export const getCreateCaseDetails = (customerDetail) => {
  return dispatch => {
    axios.post("http://dmvwebd09:4000/api/Case/CreateNewCase", customerDetail).then(response => {
      dispatch(getCreateCaseDetailsData(response.data));
    });
  };
};

export const getCaseAddData = data => ({
  type: "GET_CASEADDDATA",
  data: data
});

export const addCase = (caseDetailObj) => {
  return dispatch => {
    axios.post("http://dmvwebd09:4000/api/Case/AddCase/", caseDetailObj).then(response => {
      if(response.status === 200)
      {
       dispatch(getCaseAddData(response.data));
      }    
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getCaseErrorData(error.response.data.CaseDetailForAddDTO));
     }
    console.log(error);
  });
};
};

export const getH6InfoData = data => ({
  type: "GET_H6INFO",
  data: data
});

export const getH6Info = (dlNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Inquiry/geth6?dlNumber="+dlNumber).then(response => {
      dispatch(getH6InfoData(response.data));
    });
  };
};

export const getCaseScheduleDetailData = data => ({
  type: "GET_CASESCHEDULEDATA",
  data: data
});

export const getCaseScheduleDetail = (dlNumber, caseNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Case/GetCaseScheduleDetail?dlNumber="+dlNumber+"&caseNumber="+caseNumber).then(response => {
      dispatch(getCaseScheduleDetailData(response.data));
    });
  };
};

export const getCaseCommentsData = data => ({
  type: "GET_CASECOMMENTSDATA",
  data: data
});

export const getCaseComments = (caseNumber) => {
  return dispatch => {
    axios.get("http://dmvwebd09:4000/api/Comment/"+caseNumber).then(response => {
      dispatch(getCaseCommentsData(response.data));
    });
  };
};

export const getCaseCommentAddData = (data) => ({
  type: "GET_CASECOMMENTADDDATA",
  data: data
});

export const getCaseErrorData = (data) => ({
  type: "GET_CASEERRORDATA",
  data: data
});

export const addCaseComment = (caseNumber, caseCommentObj) => {
  return dispatch => {
    axios.post("http://dmvwebd09:4000/api/Comment/"+ caseNumber, caseCommentObj).then(response => {
     if(response.status === 200)
      {
       dispatch(getCaseCommentAddData(response.data));
      }    
  }).catch((error) => {
    if(error.response.status === 422)
     {
      dispatch(getCaseErrorData(error.response.data.CommentDTO));
     }
    console.log(error);
  });
};
};

export const getCaseCommentDelData = data => ({
  type: "GET_CASECOMMENTDELDATA",
  data: data
});

export const deleteCaseComment = (caseNumber, commentDelObj) => {
  return dispatch => {
    axios.post("http://dmvwebd09:4000/api/Comment/DeleteCase/"+ caseNumber, commentDelObj).then(response => {
      dispatch(getCaseCommentDelData(response.data));
  }).catch((error) => {
    if(error.response.status === 422)
    {
     dispatch(getCaseErrorData(error.response.data.CommentDTO));
    }
    console.log(error);
  });
};
};