import axios from "axios";

// EMPLOYEE PROFILES ACTIONS


// Initial Employee Profiles page data
export const getEmployeeProfilesInitialPageData = data => ({
  type: "GET_EMPPROFILESINITIAL_DATA",
  data: data
});

export const getEmployeeProfilesInitialPage = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeProfile/IntitialPage").then(response => {
      dispatch(getEmployeeProfilesInitialPageData(response.data));
    });
  };
};


// Get profiles of an employee
export const getEmployeeProfilesbyIdData = data => ({
    type: "GET_EMPPROFILES_DATA",
    data: data
  });
  
  export const getEmployeeProfilesbyId = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/GetAllProfilesForEmployee/"+empid).then(response => {
       dispatch(getEmployeeProfilesbyIdData(response.data));
      });
    };
  };


  // Get hearing Authorization of an employee
  export const getHearingAuthorizationData = data => ({
    type: "GET_EMPLOYEEHEARINGAUTH_DATA",
    data: data
  });
  
  export const getHearingAuthorization = (empid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingAuth/"+empid).then(response => {
        dispatch(getHearingAuthorizationData(response.data));
      });
    };
  };

  // Get hearing room prof detail by id
  export const getHearingRoomProfileByLocationData = data => ({
    type: "GET_HEARINGROOMPROFILEBYLOCATION_DATA",
    data: data
  });
  
  export const getHearingRoomProfileByLocation = (locationId) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingRoomProfilesForRoom"+locationId).then(response => {
       dispatch(getHearingRoomProfileByLocationData(response.data));
      });
    };
  };

  // To get list of offices
  export const getMyDistrictOfficesData = data => ({
    type: "GET_DISTRICTOFFICES_DATA",
    data: data
  });
  
  export const getMyDistrictOffices = () => {
    return dispatch => {
      axios.get("http://localhost:32610/api/HearingRoomProfile/GetMyDistrictOffices").then(response => {
     dispatch(getMyDistrictOfficesData(response.data));
      });
    };
  };

  export const getCreateProfileData = data => ({
    type: "GET_CREATEPROFILE_DATA",
    data: data
  });
  
  export const getCreateProfile= (empid, profid) => {
    return dispatch => {
      axios.get("http://localhost:32610/api/EmployeeProfile/CreateTemplateForEmployee/"+empid+"?ProfileID="+profid).then(response => {
        dispatch(getCreateProfileData(response.data));
      });
    };
  };

  export const saveEmployeeProfileData = data => ({
    type: "GET_PROFILECREATED_DATA",
    data: data
  });

  export const saveEmployeeProfile = (employeeProfDataObj) => {
    return dispatch => {
      axios.post("http://localhost:32610/api/EmployeeProfile/CreateEmployeeProfile",employeeProfDataObj).then(response => {
        if(response.status === 200)
        {
          debugger;
          dispatch(saveEmployeeProfileData(response.data));
        }
    }).catch((error) => {
      if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response.data));
    console.log(error.response);
   }
    });

  };
  };

  export const getHearingAuthorizationEditedData = data => ({
    type: "GET_HAUTHEDITED_DATA",
    data: data
  });

  export const saveHearingAuth = (hearingAuthData) => {
  return dispatch => {
    axios.post("http://localhost:32610/api/HearingAuth/CreateHearingAuth",hearingAuthData).then(response => {
      if(response.status === 200)
      {
        dispatch(getHearingAuthorizationEditedData(JSON.parse(response.config.data)));
      }
  }).catch((error) => {
    console.log(error);
  });

};
};

export const deleteEmployeeProfileData = (data) => ({
  type: "GET_EMPLOYEEPROFDELETED_DATA",
  data: data
});

export const deleteEmployeeProfile = (profid, endDate) => {
  debugger;
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeProfile/DeleteEmployeeProfile/"+profid+"?EndEffectiveDate=",endDate).then(response => {
    if(response.status === 200)
    {
      console.log(response.data);
      debugger;
      response.data.actionStatus = "The Employee Profile's end date updated successfully!";
     dispatch(deleteEmployeeProfileData(response.data));
    }
}).catch((error) => {
  console.log(error.response);
});

};
};

// To get list of hearing locations
export const hearingLocationsProfileData = data => ({
  type: "GET_HEARINGLOCATION_DATA",
  data: data
});

export const getHearingLocation= (officeId) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoomProfile/GetHearingLocation"+officeId).then(response => {
      dispatch(hearingLocationsProfileData(response.data));
    });
  };
};


// To get the list of Employees
export const getlistOfEmployeesData = data => ({
  type: "GET_EMPLOYEELIST_DATA",
  data: data
});

export const getListOfEmployeesForOffice= () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeesForMyOffice").then(response => {
    dispatch(getlistOfEmployeesData(response.data));
    });
  };
};

// Get timeoff details search results for emp id and date
export const getTimeOffDetailsforEmployeeData = data => ({
  type: "GET_EMPLOYEEAPPMNT_DATA",
  data: data
});

export const getTimeOffDetailsforEmployee= (empidlist,month,year ) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentByEmployee?empIDList="+empidlist+"&month="+month+"&year="+year).then(response => {
    dispatch(getTimeOffDetailsforEmployeeData(response.data));
    });
  };
};

// Get timeoff details search results for emp id and date
export const getTimeOffCreateScreenData = data => ({
  type: "GET_CREATETIMEOFF_DATA",
  data: data
});

export const getTimeOffCreateScreen= () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentForCreate").then(response => {
    //  dispatch(getlistOfEmployeesData(response.data));
    dispatch(getTimeOffCreateScreenData(response.data));
    });
  };
};

// Get timeoff detail for app id
export const getEmployeeAppointmentData = data => ({
  type: "GET_EMPAPPBYREACNO_DATA",
  data: data
});

export const getEmployeeAppointment= (reacNo, apptNo) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/EmployeeAppointment/GetEmployeeAppointmentForEdit"+reacNo+"?AppintmentNumber="+apptNo).then(response => {
    if(response.status === 200)
   { dispatch(getEmployeeAppointmentData(response.data));
   }
    });
  };
};

// To get default room profile
export const defaultRoomProfileData = data => ({
  type: "GET_DEFAULTROOMPROFILE_DATA",
  data: data
});

export const getDefaultRoomProfile = (locationId) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoomProfile/DefultRoomProfile"+locationId).then(response => {
      dispatch(defaultRoomProfileData(response.data));
    });
  };
};



// To update the room profile
export const updatedHearingRoomProfileData = data => ({
  type: "GET_UPDATEDROOMPROF_DATA",
  data: data
});

export const updateHearingRoomProfile = (modifiedRoomProfile) => {
return dispatch => {
  axios.post("http://localhost:32610/api/HearingRoomProfile/UpdateHearingRoomProfile",modifiedRoomProfile).then(response => {
    if(response.status === 200)
    {
      debugger;
      dispatch(updatedHearingRoomProfileData(response.data));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
   }

});

};
};


// To create the employee timeoff
export const createEmployeeTimeOffData = data => ({
  type: "GET_CREATEEMPTIMEOFF_DATA",
  data: data
});

export const createEmployeeTimeOff = (newEmpTimeOffData) => {
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeAppointment/CreateEmployeeAppointment",newEmpTimeOffData).then(response => {
    if(response.status === 200)
    {
     dispatch(createEmployeeTimeOffData(response.data));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
   }
   if(error.response.status === 423)
   {
    dispatch(getProfilesErrorData(error.response.data));
   }
});

};
};

// To update the employee timeoff
export const editEmployeeTimeOffData = eudata => ({
  type: "GET_EMPLOYEETOEDITED_DATA",
  data: eudata.data,
  status: eudata.status
});

export const editEmployeeTimeOff = (updatedEmpTimeOffData) => {
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeAppointment/EditEmployeeAppointment",updatedEmpTimeOffData).then(response => {
    if(response.status === 200)
    {
      //console.log(response);
      dispatch(editEmployeeTimeOffData(response));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To delete the employee timeoff
export const deleteEmployeeTimeOffData = data => ({
  type: "GET_EMPLOYEETODELETED_DATA",
  data: data
});

export const deleteEmployeeTimeOff = (reacNo, apptNo) => {
return dispatch => {
  axios.post("http://localhost:32610/api/EmployeeAppointment/DeleteEmployeeAppointment?ReaccuranceNumber="+reacNo+"&AppintmentNumber="+apptNo).then(response => {
    if(response.status === 200)
    {
      debugger;
      response.data = response.config.url.split("=")[1].split("&")[0];
      dispatch(deleteEmployeeTimeOffData(response.data));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To get the hearing room appointment by recurrence number

export const hearingRoomTimeOffData = data => ({
  type: "GET_HEARINGROOMTIMEOFF_DATA",
  data: data
});

export const getHearingRoomTimeOff = (locationId, month, year) => {
 // debugger;
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoom/GetHearingRoomAppointmentByHearingRoom"+locationId+"?month="+month+"&year="+year).then(response => {
      dispatch(hearingRoomTimeOffData(response.data));
    });
  };
};

// To get the default hearing room time off data for create

export const hearingRoomTimeOffDefaultData = data => ({
  type: "GET_HEARINGROOMTIMEOFFDEFAULT_DATA",
  data: data
});

export const getHearingRoomTimeOffDefaultData = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoom/GetHearingRoomAppointmentForCreate").then(response => {
      dispatch(hearingRoomTimeOffDefaultData(response.data));
    });
  };
};

// To get the hearing room time off data for a location for editing

export const hearingRoomTimeOffEditData = data => ({
  type: "GET_HEARINGROOMTIMEOFFEDIT_DATA",
  data: data
});

export const getHearingRoomTimeOffEditData = (reacNo, apptNo) => {
  return dispatch => {
    axios.get("http://localhost:32610/api/HearingRoom/GetHearingRoomAppointmentForEdit"+reacNo+"?AppintmentNumber="+apptNo).then(response => {
      dispatch(hearingRoomTimeOffEditData(response.data));
    });
  };
};


// To create the hearing room timeoff
export const createHearingRoomTimeOffData = data => ({
  type: "GET_HEARINGROOMTOCREATED_DATA",
  data: data
});

export const createHearingRoomTimeOff = (newHRTimeOffObj) => {
return dispatch => {
  axios.post("http://localhost:32610/api/HearingRoom/CreateHearingRoomAppointment",newHRTimeOffObj).then(response => {
    if(response.status === 200)
    {
      response.data[0].updateStatus = "The time-off is created successfully!"
      dispatch(createHearingRoomTimeOffData(response.data[0]));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To update the hearing room timeoff
export const editHRTimeOffData = data => ({
  type: "GET_HRTOEDITED_DATA",
  data: data
});

export const editHRTimeOff = (updatedHRTimeOffData) => {
return dispatch => {
  axios.post("http://localhost:32610/api/HearingRoom/EditHearingRoomAppointment",updatedHRTimeOffData).then(response => {
    if(response.status === 200)
    {
      response.data[0].updateStatus = "The time-off details are updated successfully!"
      dispatch(editHRTimeOffData(response.data[0]));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};


// To delete the hearing room timeoff
export const deleteHearingRoomTimeOffData = data => ({
  type: "GET_HEARINGROOMTODELETED_DATA",
  data: data
});

export const deleteHearingRoomTimeOff = (apptNo) => {
return dispatch => {
  axios.post("http://localhost:32610/api/HearingRoom/DeleteHearingRoomAppointment?AppointmentId="+apptNo).then(response => {
    if(response.status === 200)
    {
      const data = {updateStatus: "The time-off is deleted successfully!"};
      dispatch(deleteHearingRoomTimeOffData(data));
    }
}).catch((error) => {
  if(error.response.status === 422)
   {
    dispatch(getProfilesErrorData(error.response));
    console.log(error.response);
   }

});

};
};

// To get the error data
export const getProfilesErrorData = (data) => ({
  type: "GET_PROFILESERRORDATA",
  data: data
});
