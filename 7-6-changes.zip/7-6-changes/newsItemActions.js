import axios from "axios";

//NEWSITEMS ACTIONS
export const getNewsItemPage = data => ({
  type: "GET_NEWSITEMS",
  data: data
});

export const initNewsItemPage = () => {
  return dispatch => {
      axios.get("http://localhost:32610/api/NewsItems").then(response => {
        dispatch(getNewsItemPage(response.data));
        console.log ("data from get news items api");
        console.log(response.data);
      });
     
  };
};

export const getCreateNewsItemObj = data => ({
  type: "GET_CREATENEWSITEM",
  data: data
});

export const initCreateNewsItemObj = () => {
  return dispatch => {
    axios.get("http://localhost:32610/api/NewsItems/CreateNewsItem").then(response => {
      dispatch(getCreateNewsItemObj(response.data));
      console.log ("data from get create news items api");
      console.log(response.data);
    });
  };
};

export const getEditNewsItemObj = data => ({
  type: "GET_EDITNEWSITEM",
  data: data
});

export const initEditNewsItemObj = (newsId) => {
  console.log("edit api getting called");
  return dispatch => {
    axios.get("http://localhost:32610/api/NewsItems/EditNewsItem/"+newsId).then(response => {
      dispatch(getEditNewsItemObj(response.data));
      console.log ("data from get edit news items api");
      console.log(response.data);
    });
  };
};